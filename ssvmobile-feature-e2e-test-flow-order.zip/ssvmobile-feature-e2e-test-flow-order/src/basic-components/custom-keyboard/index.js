/**
 * Keyboard
 */
'use strict'

import React, { Component } from 'react'
import { Image, Platform, TouchableOpacity, View } from 'react-native'
import { isTablet } from 'react-native-device-info'
import { getBottomSpace } from 'react-native-iphone-x-helper'
import { TouchableRipple } from 'react-native-paper'
import { Button } from 'native-base'
import PropTypes from 'prop-types'

import { dimensions, fontSizes } from '../../styles'
import { FormatNumber } from '../../utils'
import Text from '../Text'
import styles, { BG_COLOR, keyStyle } from './styles'

const IOS = Platform.OS === 'ios' ? true : false
const TouchComponent = IOS ? TouchableOpacity : TouchableRipple

const numberKeys = [
    [
        { mainText: '1', otherText: '' },
        { mainText: '2', otherText: 'ABC' },
        { mainText: '3', otherText: 'DEF' },
    ],
    [
        { mainText: '4', otherText: 'GHI' },
        { mainText: '5', otherText: 'JKL' },
        { mainText: '6', otherText: 'MNO' },
    ],
    [
        { mainText: '7', otherText: 'PQRS' },
        { mainText: '8', otherText: 'TUV' },
        { mainText: '9', otherText: 'WXYZ' },
    ],
]

class Keyboard extends Component {
    constructor(props) {
        super(props)
    }

    _clearAll() {
        this.props.onClear()
    }

    _onPress(key) {
        if (key === '') {
            return

            // delete key
        } else if (key === 'del') {
            this.props.onDelete()

            // number key
        } else {
            this.props.onKeyPress(key)
        }
    }

    _renderOtherText(key) {
        if (this.props.disableOtherText !== true) {
            return <Text style={keyStyle.otherText}>{key.otherText}</Text>
        }
        return null
    }

    _disableClearButtonBackground() {
        if (this.props.disableClearButtonBackground !== true) {
            return keyStyle.bg_d2d5dc
        }

        return keyStyle.bgLess
    }

    _clearBtnUnderlayColor() {
        if (this.props.disableClearButtonBackground !== true) {
            return '#ffffff'
        }
        return '#d2d5dc'
    }

    _renderKey(key, index) {
        return (
            <TouchComponent
                key={index}
                style={[keyStyle.wrapper, { backgroundColor: this.props.styles.KEYBOARD__BG }]}
                underlayColor={BG_COLOR}
                onPress={this._onPress.bind(this, key.mainText)}
            >
                <View style={[keyStyle.bd, { borderColor: this.props.styles.KEYBOARD__BORDER }]}>
                    <Text style={[keyStyle.mainText, { color: this.props.styles.PRIMARY__CONTENT__COLOR }]}>{key.mainText}</Text>
                </View>
            </TouchComponent>
        )
    }

    _renderNumberKeys() {
        return numberKeys.map((group, groupIndex) => {
            return (
                <View key={groupIndex} style={styles.row}>
                    {group.map(this._renderKey.bind(this))}
                </View>
            )
        })
    }

    _isDecimalPad() {
        return this.props.keyboardType === 'decimal-pad'
    }

    _renderDotKey() {
        if (this.props.disableDot !== true) {
            let dotNode = null,
                dotText = ''
            if (this._isDecimalPad()) {
                dotText = '.'
                dotNode = <Text style={[keyStyle.mainText, keyStyle.dot, { color: this.props.styles.PRIMARY__CONTENT__COLOR }]}>.</Text>
            }
            if (dotNode) {
                return (
                    <TouchComponent
                        style={[keyStyle.wrapper, keyStyle.bg_d2d5dc, { backgroundColor: this.props.styles.KEYBOARD__BG }]}
                        underlayColor="#ffffff"
                        onPress={this._onPress.bind(this, dotText)}
                    >
                        <View style={[keyStyle.bd, { borderColor: this.props.styles.KEYBOARD__BORDER }]}>{dotNode}</View>
                    </TouchComponent>
                )
            } else {
                return (
                    <View
                        style={[keyStyle.wrapper, keyStyle.bg_d2d5dc, { backgroundColor: this.props.styles.KEYBOARD__BG }]}
                        underlayColor="#ffffff"
                        onPress={this._onPress.bind(this, dotText)}
                    >
                        <View style={[keyStyle.bd, { borderColor: this.props.styles.KEYBOARD__BORDER }]}>{dotNode}</View>
                    </View>
                )
            }
        }

        return (
            <View style={keyStyle.wrapper}>
                <View />
            </View>
        )
    }

    shouldComponentUpdate(nextProps, nextState) {
        if (nextProps.orderTps !== this.props.orderTps || nextProps.qty !== this.props.qty || nextProps.inputModal !== this.props.inputModal) {
            return true
        }
        return false
    }

    render() {
        const { orderTps, setPriceOrderTp, inputModal, qty, setQtyKeyboard, hideKeyboard, placeOrder } = this.props
        return (
            <View style={styles.wrapper}>
                <View style={styles.main}>
                    <View
                        style={{
                            backgroundColor: this.props.styles.KEYBOARD__BG,
                            flexDirection: 'row',
                            justifyContent: 'center',
                            height: isTablet() ? dimensions.vertical(45, 0.5) : 45,
                        }}
                    >
                        <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', alignContent: 'stretch' }}>
                            {inputModal === 'price'
                                ? orderTps.map((e) => (
                                      <Button
                                          key={e.key}
                                          style={{
                                              paddingHorizontal: dimensions.indent,
                                              paddingVertical: 10,
                                              alignContent: 'center',
                                              justifyContent: 'center',
                                              alignSelf: 'center',
                                          }}
                                          transparent
                                          onPress={() => setPriceOrderTp(e)}
                                      >
                                          <Text style={{ color: this.props.styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.medium }}>{e.name}</Text>
                                      </Button>
                                  ))
                                : qty
                                ? [qty * 10, qty * 100].map((e) => (
                                      <Button
                                          key={e}
                                          style={{
                                              paddingHorizontal: dimensions.indent,
                                              paddingVertical: 10,
                                              alignContent: 'center',
                                              justifyContent: 'center',
                                              alignSelf: 'center',
                                          }}
                                          transparent
                                          onPress={() => setQtyKeyboard(e)}
                                      >
                                          <Text
                                              numberOfLines={1}
                                              style={{ color: this.props.styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.xxmedium, maxWidth: 130 }}
                                          >
                                              {FormatNumber(e)}
                                          </Text>
                                      </Button>
                                  ))
                                : null}
                        </View>
                        <TouchComponent style={{ justifyContent: 'center', flexDirection: 'row', alignItems: 'center', padding: 10 }} onPress={hideKeyboard}>
                            <Text numberOfLines={1} style={{ fontSize: fontSizes.xxmedium, color: this.props.styles.PRIMARY }}>
                                {this.props.t('common_Close')}
                            </Text>
                        </TouchComponent>
                    </View>
                    {this._renderNumberKeys()}
                    <View style={styles.row}>
                        {this._renderDotKey()}
                        <TouchComponent
                            style={[keyStyle.wrapper, { backgroundColor: this.props.styles.KEYBOARD__BG }]}
                            underlayColor={BG_COLOR}
                            onPress={this._onPress.bind(this, '0')}
                        >
                            <View style={[keyStyle.bd, { borderColor: this.props.styles.KEYBOARD__BORDER }]}>
                                <Text style={[keyStyle.mainText, { color: this.props.styles.PRIMARY__CONTENT__COLOR }]}>0</Text>
                            </View>
                        </TouchComponent>

                        <TouchComponent
                            style={[keyStyle.wrapper, this._disableClearButtonBackground(), { backgroundColor: this.props.styles.KEYBOARD__BG }]}
                            underlayColor={this._clearBtnUnderlayColor()}
                            onLongPress={this._clearAll.bind(this)}
                            onPress={this._onPress.bind(this, 'del')}
                        >
                            <View style={[keyStyle.bd, { borderColor: this.props.styles.KEYBOARD__BORDER }]}>
                                <Image
                                    resizeMode="contain"
                                    source={require('./images/icon_delete.png')}
                                    style={{ tintColor: this.props.styles.PRIMARY__CONTENT__COLOR, height: 30, width: 40 }}
                                />
                            </View>
                        </TouchComponent>
                    </View>
                    {this.props.isPlaceOrder ? null : <View style={{ height: getBottomSpace(), backgroundColor: this.props.styles.KEYBOARD__BG }} />}
                </View>
            </View>
        )
    }
}

Keyboard.propTypes = {
    // 是否显示小数点符号
    keyboardType: PropTypes.oneOf(['number-pad', 'decimal-pad']),
    // 点击键盘按键
    onKeyPress: PropTypes.func,
    // 点击删除按钮
    onDelete: PropTypes.func,
    // 长按删除按钮
    onClear: PropTypes.func,
}

Keyboard.defaultProps = {
    keyboardType: 'number-pad',
    onKeyPress: () => {},
    onDelete: () => {},
    onClear: () => {},
    setPriceOrderTp: () => {},
}

export default Keyboard
