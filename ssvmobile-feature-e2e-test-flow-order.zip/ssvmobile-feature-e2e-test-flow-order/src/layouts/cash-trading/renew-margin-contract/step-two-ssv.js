import React, { useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { StyleSheet, View } from 'react-native'
import moment from 'moment'

import { CustomFloatInput } from '../../../basic-components'
import { ButtonCustom, RowData } from '../../../components/trading-component'
import { useUpdateEffect } from '../../../hoc'
import { StoreContext } from '../../../store'
import { StoreTrading } from '../../../store-trading'
import { dimensions as dm } from '../../../styles'
import FormatNumber from '../../../utils/formatNumber/FormatNumber'

// Khai báo ServiceInfo (nếu có)

// Khai báo component
const StepTwo = ({ switchStep, contractSelect, dateRenew, reasonContent, setReasonContent, _validateValue }) => {
    const { t } = useTranslation()
    const { styles } = useContext(StoreContext)
    const { userInfo } = useContext(StoreTrading)

    useUpdateEffect(() => _validateValue(0), [dateRenew])

    return (
        <View>
            <View style={{ flex: 1, marginRight: dm.halfIndent }}>
                <RowData textLeft={t('contract_num')} textRight={contractSelect.c0} />

                <RowData dataSub={[contractSelect.c7, userInfo.sub_curr]} textLeft={t('acnt_no')} />

                <RowData textLeft={t('loan_term')} textRight={contractSelect.c1} />

                <RowData textLeft={t('date_loan')} textRight={moment(contractSelect.c3, 'DDMMYYYY').format('DD/MM/YYYY')} />

                <RowData textLeft={t('date_due')} textRight={moment(contractSelect.c4, 'DDMMYYYY').format('DD/MM/YYYY')} />

                <RowData textLeft={t('loan_amount')} textRight={FormatNumber(contractSelect.c27, 0, 0)} />

                <RowData textLeft={t('outstanding_balance')} textRight={FormatNumber(contractSelect.c28, 0, 0)} />

                <RowData
                    last
                    textLeft={t('extended_until_date')}
                    textRight={contractSelect?.c54 ? moment(contractSelect?.c54, 'DDMMYYYY').format('DD/MM/YYYY') : ''}
                />

                <View style={UI.RowInput}>
                    <CustomFloatInput
                        // errCtrl={t(errCtrl[0])}
                        animationDuration={100}
                        label={t('reason_extension')}
                        placeholderTextColor={styles.PLACEHODLER__COLOR}
                        value={reasonContent}
                        onChangeText={(value) => setReasonContent(value)}
                    />
                </View>

                <ButtonCustom text={t('common_confirm')} type="confirm" onPress={() => switchStep.onFinish()} />
                <ButtonCustom last text={t('common_back')} type="back" onPress={() => switchStep.prev()} />
            </View>
        </View>
    )
}
const UI = StyleSheet.create({
    Badge_Sub: {
        alignItems: 'center',
        borderRadius: 4,
        height: dm.moderate(20),
        justifyContent: 'center',
        marginLeft: 4,
        width: dm.moderate(20),
    },
    Button: {
        alignItems: 'center',
        borderRadius: 4,
        height: dm.moderate(20),
        justifyContent: 'center',
        width: dm.moderate(20),
    },
    GroupInput: {
        marginVertical: dm.halfVerticalIndent,
        paddingHorizontal: dm.halfIndent,
    },
    RowInput: {
        marginLeft: dm.moderate(8),
        marginVertical: dm.vertical(8),
    },
})
export default StepTwo
