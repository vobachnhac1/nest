import React, { forwardRef } from 'react'
import { Image, InteractionManager, Keyboard, Pressable, ScrollView, StyleSheet, TextInput, TouchableOpacity, View } from 'react-native'
import DateTimePickerModal from 'react-native-modal-datetime-picker'
import { KeyboardAwareScrollView } from '@codler/react-native-keyboard-aware-scroll-view'
import EkycButton from '@mts-layouts/eKYCFPT/components/EkycButton'
import { InputJobInfo } from '@mts-layouts/eKYCFPT/components/InputOccupationPosition'
import { removeSpecialSymbolForAddress } from '@mts-layouts/eKYCFPT/helpers'
import moment from 'moment'

import { Text } from '../../../../basic-components'
import { ButtonCustom } from '../../../../components/trading-component'
import { ISwitchStep } from '../../../../layouts/eKYCFPT'
import { dimensions, fontSizes, fontWeights, IconSvg } from '../../../../styles'
import { glb_sv } from '../../../../utils'
import { InputContactAdress } from '../../components/InputContactAdress'
import { useStepEkycInfo } from '../hooks/useStepEkycInfo'

interface ConfirmInfo {
    navigation: any
    userData: {
        imagesFront?: string
        imagesBack?: string
        imagesFace?: string
    }
    switchStep: ISwitchStep
}

const ConfirmInfo = forwardRef(({ switchStep, navigation }, ref) => {
    const {
        setID,
        nameRef,
        hintCommonEmail,
        idRef,
        id,
        setHintCommonEmail,
        setEmail,
        email,
        scrollViewRef,
        styles,
        phoneRef,
        t,
        phone,
        setPhone,
        emailRef,
        addrContactRef,
        fullName,
        setFullName,
        setModalBirthday,
        birthdayEditable,
        idPlaceRef,
        birthday,
        setGender,
        issueDateEditable,
        setModalIssueDate,
        gender,
        setIDPlace,
        idDate,
        issuePlaceEditable,
        idPlace,
        addrRef,
        permanentAddressEditable,
        setAddr,
        addr,
        imageFront,
        imageBack,
        imageFace,
        onChangeContactAddress,
        onChangedJobInfo,
        isAuthen,
        validate,
        theme,
        modalBirthday,
        language,
        setBirthday,
        modalIssueDate,
        hideDatePicker,
        setIDDate,
        handleContinueAndSaveData,
    } = useStepEkycInfo({ navigation, userData: {}, switchStep })

    return (
        <>
            <KeyboardAwareScrollView extraHeight={100} extraScrollHeight={100} ref={scrollViewRef}>
                <View>
                    <Text style={{ textAlign: 'center', color: styles.PRIMARY, fontSize: fontSizes.xmedium, fontWeight: fontWeights.bold }}>
                        {t('personal_info')}
                    </Text>
                </View>
                <View style={[UI.row, { alignItems: 'center' }]}>
                    <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small, flex: 4, textAlignVertical: 'center' }}>
                        {t('phone')}
                        <Text style={{ color: 'red' }}>*</Text>
                    </Text>
                    <TextInput
                        keyboardType="number-pad"
                        maxLength={10}
                        placeholder={t('phone')}
                        ref={phoneRef}
                        returnKeyType="next"
                        style={{
                            color: styles.PRIMARY__CONTENT__COLOR,
                            backgroundColor: styles.INPUT__BG,
                            ...UI.RowEditAbleStyle,
                        }}
                        value={phone}
                        onChangeText={(value) => {
                            setPhone(value)
                        }}
                        onSubmitEditing={() => {
                            if (glb_sv.objUserInfo && (glb_sv.objUserInfo.c32?.trim() === '' || glb_sv.objUserInfo.c33 === 'Y')) {
                                emailRef.current.focus()
                            } else {
                                addrContactRef.current?.focus()
                            }
                        }}
                        placeholderTextColor={styles.SECOND__CONTENT__COLOR}
                        // editable={glb_sv.objUserInfo ? (glb_sv.objUserInfo.c35.trim() === '' ? true : glb_sv.objUserInfo.c36 === 'Y' ? true : false) : true}
                        editable={false}
                    />
                </View>

                <View style={[UI.row, { alignItems: 'center' }]}>
                    <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small, flex: 4, textAlignVertical: 'center' }}>
                        {t('email')} <Text style={{ color: 'red' }}>*</Text>
                    </Text>
                    <TextInput
                        autoCapitalize="none"
                        keyboardType="email-address"
                        placeholder={t('email')}
                        placeholderTextColor={styles.SECOND__CONTENT__COLOR}
                        ref={emailRef}
                        returnKeyType="next"
                        style={{
                            color: styles.PRIMARY__CONTENT__COLOR,
                            backgroundColor: styles.INPUT__BG,
                            ...UI.RowEditAbleStyle,
                        }}
                        onBlur={() => {
                            setHintCommonEmail(false)
                        }}
                        onChangeText={(value) => {
                            setEmail(value)
                        }}
                        onFocus={() => {
                            setHintCommonEmail(true)
                        }}
                        onSubmitEditing={() => {
                            addrContactRef.current?.focus()
                        }}
                        value={email}
                        // editable={glb_sv.objUserInfo ? (glb_sv.objUserInfo.c32.trim() == '' ? true : glb_sv.objUserInfo.c33 === 'Y' ? true : false) : true}
                        editable={false}
                    />
                </View>
                {hintCommonEmail ? (
                    <View style={{ flex: 1, justifyContent: 'flex-end', flexDirection: 'row', paddingTop: 8, marginRight: 16 }}>
                        <TouchableOpacity onPress={() => setEmail(`${email}@gmail.com`)}>
                            <View style={{ paddingHorizontal: 8, paddingVertical: 4, borderRadius: 4, marginLeft: 8, backgroundColor: styles.INPUT__BG }}>
                                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR }}>@gmail.com</Text>
                            </View>
                        </TouchableOpacity>
                        <TouchableOpacity onPress={() => setEmail(`${email}@icloud.com`)}>
                            <View style={{ paddingHorizontal: 8, paddingVertical: 4, borderRadius: 4, marginLeft: 8, backgroundColor: styles.INPUT__BG }}>
                                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR }}>@icloud.com</Text>
                            </View>
                        </TouchableOpacity>
                        <TouchableOpacity onPress={() => setEmail(`${email}@yahoo.com`)}>
                            <View style={{ paddingHorizontal: 8, paddingVertical: 4, borderRadius: 4, marginLeft: 8, backgroundColor: styles.INPUT__BG }}>
                                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR }}>@yahoo.com</Text>
                            </View>
                        </TouchableOpacity>
                    </View>
                ) : null}

                <View style={[UI.row]}>
                    <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small, flex: 4, textAlignVertical: 'center' }}>
                        {t('id_card_number')} <Text style={{ color: 'red' }}>*</Text>
                    </Text>
                    <TextInput
                        editable={false}
                        keyboardType="number-pad"
                        placeholderTextColor={styles.SECOND__CONTENT__COLOR}
                        ref={idRef}
                        returnKeyType="next"
                        style={{
                            color: styles.PRIMARY__CONTENT__COLOR,
                            backgroundColor: styles.INPUT__BG,
                            ...UI.RowEditAbleStyle,
                        }}
                        value={id}
                        onBlur={() => (id === '' ? setID('-') : null)}
                        onChangeText={(value) => {
                            setID(value)
                        }}
                        onFocus={() => (id === '-' ? setID('') : null)}
                        onSubmitEditing={() => {
                            nameRef.current.focus()
                        }}
                    />
                </View>

                <View style={[UI.row]}>
                    <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small, flex: 4, textAlignVertical: 'center' }}>
                        {t('common_full_name')} <Text style={{ color: 'red' }}>*</Text>
                    </Text>
                    <TextInput
                        editable={false}
                        placeholderTextColor={styles.SECOND__CONTENT__COLOR}
                        ref={nameRef}
                        returnKeyType="next"
                        style={{
                            color: styles.PRIMARY__CONTENT__COLOR,
                            backgroundColor: styles.INPUT__BG,
                            ...UI.RowEditAbleStyle,
                        }}
                        value={fullName}
                        onBlur={() => (fullName === '' ? setFullName('-') : null)}
                        onChangeText={(value) => {
                            setFullName(value)
                        }}
                        onFocus={() => (fullName === '-' ? setFullName('') : null)}
                        onSubmitEditing={() => {
                            Keyboard.dismiss()
                            setModalBirthday(true)
                        }}
                    />
                </View>

                <View style={[UI.row]}>
                    <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small, flex: 4, textAlignVertical: 'center' }}>
                        {t('ekyc_birthday')} <Text style={{ color: 'red' }}>*</Text>
                    </Text>
                    <Pressable
                        style={{
                            backgroundColor: styles.INPUT__BG,
                            ...UI.RowEditAbleStyle,
                        }}
                        onPress={() => {
                            if (!birthdayEditable) return
                            Keyboard.dismiss()
                            setModalBirthday(true)
                            idPlaceRef.current.focus()
                        }}
                    >
                        <Text
                            style={{
                                color: styles.PRIMARY__CONTENT__COLOR,
                            }}
                            onPress={() => {
                                if (!birthdayEditable) return
                                Keyboard.dismiss()
                                setModalBirthday(true)
                                idPlaceRef.current.focus()
                            }}
                        >
                            {birthday ? moment(birthday).format('DD/MM/YYYY') : '---'}
                        </Text>
                    </Pressable>
                </View>

                <View style={[UI.row]}>
                    <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small, flex: 4, textAlignVertical: 'center' }}>
                        {t('common_your_sex')} <Text style={{ color: 'red' }}>*</Text>
                    </Text>
                    <View style={{ flex: 5, alignItems: 'center', flexDirection: 'row', justifyContent: 'space-between' }}>
                        <Pressable style={UI.flexRow} onPress={() => setGender('M')}>
                            {/* <IconSvg.RadioButtonIcon active={gender === 'M'} colorActive={styles.PRIMARY} colorunActive={styles.SECOND__CONTENT__COLOR} /> */}
                            <IconSvg.CheckboxIcon active={gender === 'M'} colorActive={styles.PRIMARY} colorunActive={styles.PRIMARY__CONTENT__COLOR} />
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small, padding: 0 }}>{t('common_male')}</Text>
                        </Pressable>
                        <Pressable style={UI.flexRow} onPress={() => setGender('F')}>
                            {/* <IconSvg.RadioButtonIcon active={gender === 'F'} colorActive={styles.PRIMARY} colorunActive={styles.SECOND__CONTENT__COLOR} /> */}
                            <IconSvg.CheckboxIcon active={gender === 'F'} colorActive={styles.PRIMARY} colorunActive={styles.PRIMARY__CONTENT__COLOR} />
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small, padding: 0 }}>{t('common_female')}</Text>
                        </Pressable>
                        {/* <Pressable onPress={() => setGender('O')} style={UI.flexRow}>
                        <IconSvg.CheckboxIcon active={gender === 'O'} colorActive={styles.PRIMARY} colorunActive={styles.PRIMARY__CONTENT__COLOR} />
                        <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small, padding: 0 }}>{t('common_other')}</Text>
                    </Pressable> */}
                    </View>
                </View>

                <View style={[UI.row]}>
                    <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small, flex: 4, textAlignVertical: 'center' }}>
                        {t('ekyc_issue_date')} <Text style={{ color: 'red' }}>*</Text>
                    </Text>
                    <Pressable
                        style={{
                            backgroundColor: styles.INPUT__BG,
                            ...UI.RowEditAbleStyle,
                        }}
                        onPress={() => {
                            if (!issueDateEditable) return
                            Keyboard.dismiss()
                            setModalIssueDate(true)
                            idPlaceRef.current?.focus()
                        }}
                    >
                        <Text
                            style={{
                                color: styles.PRIMARY__CONTENT__COLOR,
                            }}
                            onPress={() => {
                                if (!issueDateEditable) return
                                Keyboard.dismiss()
                                setModalIssueDate(true)
                                idPlaceRef.current?.focus()
                            }}
                        >
                            {idDate ? moment(idDate).format('DD/MM/YYYY') : '---'}
                        </Text>
                    </Pressable>
                </View>

                <View style={[UI.row, { alignItems: 'center' }]}>
                    <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small, flex: 4 }}>
                        {t('common_register_place')} <Text style={{ color: 'red' }}>*</Text>
                    </Text>
                    <TextInput
                        editable={issuePlaceEditable}
                        multiline
                        numberOfLines={1}
                        placeholderTextColor={styles.SECOND__CONTENT__COLOR}
                        ref={idPlaceRef}
                        returnKeyType="next"
                        style={{
                            color: styles.PRIMARY__CONTENT__COLOR,
                            backgroundColor: styles.INPUT__BG,
                            ...UI.RowEditAbleStyle,
                        }}
                        value={idPlace}
                        onBlur={() => (idPlace === '' ? setIDPlace('-') : null)}
                        onChangeText={(value) => {
                            setIDPlace(value.replace(/\r?\n|\r/g, ''))
                        }}
                        onFocus={() => (idPlace === '-' ? setIDPlace('') : null)}
                        onSubmitEditing={() => {
                            Keyboard.dismiss()
                            // scrollViewRef.current?.scrollToEnd({ animated: true })
                        }}
                    />
                </View>

                <View style={[UI.column]}>
                    <Text
                        style={{
                            color: styles.SECOND__CONTENT__COLOR,
                            fontSize: fontSizes.small,
                            paddingVertical: 2,
                        }}
                    >
                        {t('addr_regit_per')} <Text style={{ color: 'red' }}>*</Text>
                    </Text>
                    <Pressable
                        style={{
                            flex: 1,
                            width: '100%',
                            justifyContent: 'flex-start',
                            borderRadius: 8,
                            backgroundColor: styles.INPUT__BG,
                            padding: dimensions.moderate(8),
                        }}
                        onPress={() => {
                            if (permanentAddressEditable) return
                            addrRef.current?.focus()
                        }}
                    >
                        <TextInput
                            editable={permanentAddressEditable}
                            maxLength={100}
                            multiline
                            numberOfLines={3}
                            placeholderTextColor={styles.SECOND__CONTENT__COLOR}
                            ref={addrRef}
                            returnKeyType="next"
                            style={{
                                color: styles.PRIMARY__CONTENT__COLOR,
                                ...UI.RowEditAbleStyle,
                            }}
                            value={addr}
                            onBlur={() => (addr === '' ? setAddr('-') : null)}
                            onChangeText={(value) => {
                                setAddr(removeSpecialSymbolForAddress(value))
                            }}
                            onFocus={() => (addr === '-' ? setAddr('') : null)}
                            onSubmitEditing={() => {
                                addrContactRef.current?.focus()
                                // Keyboard.dismiss();
                                // scrollViewRef.current?.scrollToEnd({ animated: true })
                            }}
                        />
                    </Pressable>
                </View>
                <View
                    style={{
                        flexDirection: 'row',
                        justifyContent: 'center',
                        marginHorizontal: dimensions.moderate(1),
                        marginVertical: 16,
                    }}
                >
                    <View style={{ marginHorizontal: 5 }}>
                        <Image source={{ uri: imageFront || '' }} style={{ height: 70, width: 110, borderRadius: 10 }} />
                    </View>
                    <View style={{ marginHorizontal: 5 }}>
                        <Image source={{ uri: imageBack || '' }} style={{ height: 70, width: 110, borderRadius: 10 }} />
                    </View>
                    <View style={{ marginHorizontal: 5 }}>
                        <Image source={{ uri: imageFace || '' }} style={{ height: 70, width: 70, borderRadius: 35 }} />
                    </View>
                </View>

                <InputContactAdress onChangeContactAddress={onChangeContactAddress} />
                <InputJobInfo onChangedJobInfo={onChangedJobInfo} />
            </KeyboardAwareScrollView>
            <View style={{ flexDirection: 'row', paddingHorizontal: 16 }}>
                <EkycButton
                    customStyle={{ flex: 1, marginEnd: 16 }}
                    text={t('common_button_previous')}
                    onPress={() => switchStep.prev({ step: 1, subStep: 3 })}
                />
                <EkycButton customStyle={{ flex: 1 }} isLoading={false} text={t('common_button_next')} onPress={handleContinueAndSaveData} />
            </View>
            {!isAuthen ? (
                <ButtonCustom
                    // onPress={authenEkyc}
                    style={{
                        backgroundColor: styles.PRIMARY,
                        marginTop: 12,
                    }}
                    text={t('reauthen_ekyc')}
                    onPress={() => null}
                />
            ) : (
                // <ButtonCustom
                //     style={{
                //         marginTop: 12,
                //     }}
                //     onPress={handleContinueAndSaveData}
                //     disabled={!validate()}
                //     // isLoading={loading}
                //     text={t('common_button_next')}
                // />
                <></>
            )}

            {modalBirthday ? (
                <DateTimePickerModal
                    cancelTextIOS={t('common_Cancel')}
                    confirmTextIOS={t('common_Ok')}
                    date={birthday ? birthday : moment().subtract(20, 'year').toDate()}
                    headerTextIOS={t('ekyc_birthday')}
                    isDarkModeEnabled={theme.includes('DARK')}
                    isVisible={modalBirthday}
                    locale={language === 'VI' ? 'vi_VN' : 'en_US'}
                    mode="date"
                    onCancel={hideDatePicker}
                    onConfirm={(value) => {
                        hideDatePicker()
                        setBirthday(value)
                        InteractionManager.runAfterInteractions(() => {
                            idPlaceRef.current.focus()
                        })
                    }}
                />
            ) : null}

            {modalIssueDate ? (
                <DateTimePickerModal
                    cancelTextIOS={t('common_Cancel')}
                    confirmTextIOS={t('common_Ok')}
                    date={idDate ? idDate : moment().subtract(20, 'year').toDate()}
                    headerTextIOS={t('ekyc_issue_date')}
                    isDarkModeEnabled={theme.includes('DARK')}
                    isVisible={modalIssueDate}
                    locale={language === 'VI' ? 'vi_VN' : 'en_US'}
                    mode="date"
                    onCancel={hideDatePicker}
                    onConfirm={(value) => {
                        hideDatePicker()
                        setIDDate(value)
                        InteractionManager.runAfterInteractions(() => {
                            idPlaceRef.current.focus()
                        })
                    }}
                />
            ) : null}
        </>
    )
})

const UI = StyleSheet.create({
    RowEditAbleStyle: {
        borderRadius: 4,
        flex: 5,
        fontSize: fontSizes.small,
        padding: 0,
        paddingHorizontal: 5,
        paddingVertical: 8,
        textAlignVertical: 'top',
    },
    bottomModal: {
        justifyContent: 'flex-end',
        margin: 0,
    },
    column: {
        alignItems: 'flex-start',
        borderRadius: 12,
        flexDirection: 'column',
        marginHorizontal: dimensions.moderate(16),
        marginTop: dimensions.vertical(6),
        paddingVertical: 2,
    },
    flexRow: {
        alignContent: 'center',
        alignItems: 'center',
        flexDirection: 'row',
        justifyContent: 'center',
    },
    modal: {
        justifyContent: 'flex-end',
        margin: 0,
    },
    preview: {
        alignItems: 'center',
        flexDirection: 'row',
        height: 250,
        justifyContent: 'center',
    },
    row: {
        alignItems: 'center',
        borderRadius: 12,
        flexDirection: 'row',
        marginHorizontal: dimensions.moderate(16),
        marginTop: dimensions.vertical(12),
    },
})

export default ConfirmInfo
