import React, { useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { StyleSheet, TextInput, View } from 'react-native'

import { Text } from '../../../../basic-components'
import { StoreContext } from '../../../../store'
import { dimensions as dm, fontSizes as fs } from '../../../../styles'

export const CommonInputPhoneNumber = ({ onChangePhoneNumber = () => null, defaultPhoneNumber = '' }) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()

    return (
        <>
            <View style={[UI.row]}>
                <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fs.small, flex: 4 }}>{t('phone')}</Text>
                <View style={[UI.wrapInput, { backgroundColor: styles.INPUT__BG }]}>
                    <TextInput
                        autoCorrect={false}
                        placeholderTextColor={styles.PLACEHODLER__COLOR}
                        style={{
                            fontSize: fs.small,
                            color: styles.PRIMARY__CONTENT__COLOR,
                            textAlignVertical: 'center',
                            flex: 1,
                        }}
                        value={defaultPhoneNumber}
                        onChangeText={(value) => {
                            onChangePhoneNumber(value)
                        }}
                        placeholder={t('phone')}
                        // returnKeyType="next"
                        keyboardType="numeric"
                    />
                </View>
            </View>
        </>
    )
}

const UI = StyleSheet.create({
    GroupInput: {
        marginVertical: dm.halfVerticalIndent,
        paddingHorizontal: dm.halfIndent,
    },
    RowInput: {
        marginLeft: dm.moderate(8),
        marginVertical: dm.vertical(8),
    },
    row: {
        alignItems: 'center',
        borderRadius: 12,
        display: 'flex',
        flexDirection: 'row',
        marginHorizontal: dm.moderate(16),
        marginTop: dm.vertical(12),
    },
    wrapInput: {
        borderRadius: 4,
        flex: 5,
        flexDirection: 'row',
        paddingHorizontal: 10,
        paddingVertical: 8,
    },
})
