import React, { useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { View } from 'react-native'
import RNRestart from 'react-native-restart'
import axios from 'axios'
import { Body, Container, Content, Icon, Left, List, ListItem, Right } from 'native-base'
import SyncStorage from 'sync-storage'

import { Text } from '../../basic-components'
import HeaderComponent from '../../components/header'
import { StoreContext } from '../../store'
import { fontSizes } from '../../styles'
import { UIbasic } from '../../styles/appUI'
import { socket_sv } from '../../utils'
import STORE_KEY from '../../utils/constant/store_key'

const pingValue = {}
export default function ServerStack({ navigation }) {
    const { currentNodeServer, styles } = useContext(StoreContext)
    const [selected, setSelected] = useState(currentNodeServer)
    const { t } = useTranslation()
    const [ping, setPing] = useState({})

    const cancelRef = useRef(false)

    useEffect(() => {
        const axiosTiming = (instance) => {
            instance.interceptors.request.use((request) => {
                request.ts = Date.now()
                return request
            })

            instance.interceptors.response.use((response) => {
                const timeInMs = `${Number(Date.now() - response.config.ts).toFixed()}`
                response.latency = timeInMs
                return response
            })
        }
        axiosTiming(axios)
        //----- ping lần đầu --------
        pingToServer()
        // ----- ping interval -------
        const pingNext = setInterval(() => {
            pingToServer()
        }, 3000)

        return () => {
            clearInterval(pingNext)
            cancelRef.current = true
        }
    }, [])

    const pingToServer = () => {
        socket_sv.server_node_list.map((node, index) => {
            axios
                .get(node.trading_server.ip_address[0])
                .then(function (response) {
                    if (cancelRef.current) return
                    pingValue[node.index] = response.latency + 'ms'
                    setPing({ ...pingValue })
                })
                .catch(function (error) {
                    if (cancelRef.current) return
                    pingValue[node.index] = '999 ms'
                    setPing({ ...pingValue })
                })
        })
    }

    return (
        <Container
            style={{
                backgroundColor: styles.PRIMARY__BG__COLOR,
            }}
        >
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft
                navigation={navigation}
                title={t('server_selection')}
                titleAlgin="flex-start"
                transparent
            />
            <Content>
                <List style={{ paddingHorizontal: 20 }}>
                    <ListItem noBorder underlayColor="transparent">
                        <Left>
                            <Text
                                style={{
                                    ...UIbasic.Text__Small,
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                }}
                            >
                                {t('server_node')}
                            </Text>
                        </Left>
                        <Right>
                            <Text
                                style={{
                                    ...UIbasic.Text__Small,
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                }}
                            >
                                {t('server_delay')}
                            </Text>
                        </Right>
                    </ListItem>
                    {socket_sv.server_node_list.map((item) => (
                        <React.Fragment key={item.index}>
                            <ListItem
                                activeOpacity={0.6}
                                disabled={selected === item.index || ping[item.index] === 'error'}
                                icon
                                noBorder
                                selected={selected === item.index}
                                underlayColor="transparent"
                                onPress={() => {
                                    if (selected !== item.index) setSelected(item.index)
                                    SyncStorage.set(STORE_KEY.SERVER, item.index)
                                    RNRestart.Restart()
                                }}
                            >
                                <Body>
                                    <Text
                                        style={{
                                            fontSize: fontSizes.medium,
                                            color:
                                                selected === item.index
                                                    ? styles.PRIMARY
                                                    : ping[item.index] === 'error'
                                                    ? styles.DOWN__COLOR
                                                    : styles.PRIMARY__CONTENT__COLOR,
                                        }}
                                    >
                                        {t(item.key_name) + ' ' + t(item.key_name_note)}
                                    </Text>
                                </Body>
                                <Right>
                                    <Text
                                        style={{
                                            fontSize: fontSizes.medium,
                                            color:
                                                selected === item.index
                                                    ? styles.PRIMARY
                                                    : ping[item.index] === 'error'
                                                    ? styles.DOWN__COLOR
                                                    : styles.PRIMARY__CONTENT__COLOR,
                                        }}
                                    >
                                        {ping[item.index]}
                                    </Text>
                                    {selected === item.index ? (
                                        <Icon name="check" style={{ color: styles.PRIMARY }} type="AntDesign" />
                                    ) : (
                                        <View style={{ width: 30 }} />
                                    )}
                                </Right>
                            </ListItem>
                            <View style={{ borderBottomColor: styles.DIVIDER__COLOR, borderBottomWidth: 1 }} />
                        </React.Fragment>
                    ))}
                </List>
            </Content>
        </Container>
    )
}
