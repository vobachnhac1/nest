import React, { memo, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { FlatList, InteractionManager, StyleSheet, View } from 'react-native'
import DeviceInfo from 'react-native-device-info'
import { SafeAreaView } from 'react-native-safe-area-context'
import debounce from 'lodash/debounce'
import isEqual from 'lodash/isEqual'
import { Button, Row } from 'native-base'

import IconBack from '../../assets/images/common/ic_back.svg'
import { Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { dimensions, fontSizes, fontWeights } from '../../styles'
import { eventList, FormatNumber, glb_sv, Screens, subcribeFunctStream } from '../../utils'

const isTablet = DeviceInfo.isTablet()
const viewabilityConfig = {
    minimumViewTime: 100,
    viewAreaCoveragePercentThreshold: 5,
    waitForInteraction: true,
}

const StockItem = memo(({ item, styles, onChangeStkInfo }) => {
    return (
        <Row style={UI.HeaderTop_view} onPress={() => onChangeStkInfo(item)}>
            <View style={UI.flex1}>
                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.verySmall, fontWeight: fontWeights.medium }}>{item.t55}</Text>
            </View>
            <View style={UI.flex1}>
                {item.t31 ? (
                    <Text
                        style={{
                            color: glb_sv.getColor(item.t31, item, styles),
                            fontSize: fontSizes.verySmall,
                            textAlign: 'right',
                            fontWeight: fontWeights.medium,
                        }}
                    >
                        {item.t31_incr_per > 0 ? '+' : ''}
                        {FormatNumber(item.t31_incr_per, 2)}%
                    </Text>
                ) : null}
            </View>
            <View style={UI.flex1}>
                <Text
                    style={{
                        color: glb_sv.getColor(item.t260, item, styles),
                        fontSize: fontSizes.verySmall,
                        textAlign: 'right',
                        fontWeight: fontWeights.medium,
                    }}
                >
                    {FormatNumber(item.t137, 0, 1)}
                </Text>
            </View>
            <View style={UI.flex1}>
                <Text
                    style={{
                        color: glb_sv.getColor(item.t31, item, styles),
                        fontSize: fontSizes.verySmall,
                        textAlign: 'right',
                        fontWeight: fontWeights.medium,
                    }}
                >
                    {FormatNumber(item.t31 || item.t260, 0, 1)}
                </Text>
            </View>
            <View style={UI.flex1}>
                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.verySmall, textAlign: 'right', fontWeight: fontWeights.medium }}>
                    {FormatNumber(item.t391, 0, 1, 'short')}
                </Text>
            </View>
        </Row>
    )
}, compareStockItem)

function compareStockItem(prev, next) {
    if (
        prev.item.t31 === next.item.t31 &&
        prev.item.t260 === next.item.t260 &&
        prev.item.t137 === next.item.t137 &&
        prev.item.t391 === next.item.t391 &&
        prev.item.t31_incr_per === next.item.t31_incr_per
    )
        return true
    return false
}
const RenderSeparator = memo(() => {
    const { styles } = useContext(StoreContext)
    return (
        <View
            style={{
                height: 1,
                backgroundColor: styles.DIVIDER__COLOR,
            }}
        />
    )
})

function ListStockAll({ navigation, route }) {
    const { listStock, indexCode } = route.params

    const { styles } = useContext(StoreContext)
    const [list, setList] = useState(listStock)
    const { t } = useTranslation()

    // const [index, setIndex] = useState(glb_sv.IndexMarket[indexCode])

    const list_subscribe = useRef([])
    const timeoutChangeView = useRef(null)

    const throttled = useRef(
        debounce(
            () => {
                const newList = listStock.map((e) => {
                    return glb_sv.StockMarket[e.t55] ? { ...glb_sv.StockMarket[e.t55] } : { t55: e.t55, U9: '', t31: 0, t31_incr_per: 0 }
                })
                setList(newList)
            },
            500,
            { trailing: true },
        ),
    )

    const handleViewableItemsChanged = useRef(({ viewableItems }) => {
        if (!viewableItems.length) return
        if (
            isEqual(
                list_subscribe.current,
                viewableItems.map((e) => e.key),
            )
        )
            return
        if (timeoutChangeView.current) clearTimeout(timeoutChangeView.current)
        timeoutChangeView.current = setTimeout(() => {
            if (list_subscribe.current.length) subcribeFunctStream('UNSUB', ['MDDS|SI'], list_subscribe.current)
            list_subscribe.current = viewableItems.map((e) => e.key)
            subcribeFunctStream('SUB', ['MDDS|SI'], list_subscribe.current)
        }, 400)
    })

    useEffect(() => {
        list_subscribe.current = listStock.map((e) => e.t55)
        subcribeFunctStream('SUB', ['MDDS|SI'], list_subscribe.current)
        InteractionManager.runAfterInteractions(() => {
            setList(listStock)
        })
        subcribeFunctStream('UNSUB', ['MDDS|SI'], list_subscribe.current.slice(20))
        list_subscribe.current = list_subscribe.current.slice(0, 20)
        const eventMarket = glb_sv.eventMarket.subscribe((msg) => {
            if (msg.type === eventList.SUB_STOCK && msg.message === 'SI' && msg.isUpdateWatchlistMobile) {
                throttled.current()
            }
            if (msg.type === eventList.RECONNECT_MARKET) {
                subcribeFunctStream('SUB', ['MDDS|SI'], list_subscribe.current)
            }
        })

        return () => {
            eventMarket.unsubscribe()
            throttled.current.cancel()
            subcribeFunctStream('UNSUB', ['MDDS|SI'], list_subscribe.current)
        }
    }, [])

    const onChangeStkInfo = useCallback((item) => {
        throttled.current.cancel()
        navigation.replace(Screens.STOCK_INFO, { stockCode: item.t55 })
    }, [])

    const renderItem = useCallback(({ item }) => {
        return <StockItem item={item} styles={styles} onChangeStkInfo={onChangeStkInfo} />
    })

    const StyleContainer = useMemo(() => StyleSheet.flatten([{ flex: 1, backgroundColor: styles.PRIMARY__BG__COLOR }]), [styles])

    const StyleHeader = useMemo(() => StyleSheet.flatten([{ flexDirection: 'row', height: isTablet ? 50 : 35, paddingHorizontal: 5 }]), [])

    const StyleTextHeader = useMemo(() => StyleSheet.flatten([{ fontSize: fontSizes.xmedium, color: styles.PRIMARY__CONTENT__COLOR }]), [styles])

    const StyleViewTitle = useMemo(() => StyleSheet.flatten([UI.row_header, { borderBottomColor: styles.DIVIDER__COLOR }]), [styles])

    const StyleTitle = useMemo(() => StyleSheet.flatten([{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small }]), [styles])

    const StyleTitleRight = useMemo(
        () => StyleSheet.flatten([{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small, textAlign: 'right' }]),
        [styles],
    )

    return (
        <SafeAreaView style={StyleContainer}>
            <View style={StyleHeader}>
                <Button style={UI.header_view_left} transparent onPress={() => navigation.pop()}>
                    <IconBack height={dimensions.moderate(24)} style={{ color: styles.ICON__PRIMARY }} width={dimensions.moderate(24)} />
                </Button>
                <View style={UI.header_view_center}>
                    <Text style={StyleTextHeader}>{t('list_stock')}</Text>
                </View>
                <View style={UI.header_view_right} />
            </View>
            <View style={UI.flex1_all}>
                <View style={StyleViewTitle}>
                    <View style={UI.flex1}>
                        <Text style={StyleTitle}>{t('short_symbol')}</Text>
                    </View>
                    <View style={UI.flex1}>
                        <Text style={StyleTitleRight}>%</Text>
                    </View>
                    <View style={UI.flex1}>
                        <Text style={StyleTitleRight}>{t('open')}</Text>
                    </View>
                    <View style={UI.flex1}>
                        <Text style={StyleTitleRight}>{t('current')}</Text>
                    </View>
                    <View style={UI.flex1}>
                        <Text style={StyleTitleRight}>{t('volume')}</Text>
                    </View>
                </View>
                <FlatList
                    data={list}
                    extraData={list}
                    ItemSeparatorComponent={RenderSeparator}
                    keyExtractor={(item, index) => item?.t55 || index.toString()}
                    ListEmptyComponent={
                        <View style={{ height: 200, justifyContent: 'center', alignItems: 'center' }}>
                            <Text style={{ color: styles.SECOND__CONTENT__COLOR }}>{t('common_NoDataFound')}</Text>
                        </View>
                    }
                    renderItem={renderItem}
                    scrollEventThrottle={100}
                    style={UI.flatlist}
                    viewabilityConfig={viewabilityConfig}
                    onViewableItemsChanged={handleViewableItemsChanged.current}
                />
            </View>
        </SafeAreaView>
    )
}

const UI = StyleSheet.create({
    HeaderTop_view: {
        paddingVertical: 5,
    },
    container: {
        marginVertical: dimensions.halfIndent,
        paddingHorizontal: dimensions.moderate(16),
    },
    flatlist: {
        paddingHorizontal: dimensions.moderate(16),
    },
    flex1: {
        flex: 1,
    },
    flex1_all: { flex: 1, flexGrow: 1, flexShrink: 1 },
    header: {
        paddingVertical: 6,
    },
    header_view_center: { alignItems: 'center', flex: 1, justifyContent: 'center' },
    header_view_left: { height: 35, paddingBottom: 0, paddingTop: 0 },
    header_view_right: { height: 35, width: 35 },
    item: {
        alignItems: 'center',
    },
    row_header: {
        borderBottomWidth: 1,
        flexDirection: 'row',
        paddingHorizontal: dimensions.moderate(16),
        paddingVertical: 8,
    },
    title: {
        fontSize: fontSizes.small,
        paddingVertical: 8,
    },
})

export default ListStockAll
