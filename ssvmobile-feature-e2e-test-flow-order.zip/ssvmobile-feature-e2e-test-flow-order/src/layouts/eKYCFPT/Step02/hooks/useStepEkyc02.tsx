import React, { useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Image, InteractionManager, Platform } from 'react-native'
import { RNCamera, TakePictureOptions, TakePictureResponse } from 'react-native-camera'
import ModalController from '@mts-components/appModal/modalControlller'
import Analytics, { EkycAnalyticEvents } from '@mts-utils/TrackingData/Analytics'
import { useNavigation } from '@react-navigation/native'
import isEmpty from 'lodash/isEmpty'
import moment from 'moment'

// import Spinner from 'react-native-loading-spinner-overlay'
import { useLoading } from '../../../../hoc'
import { StoreContext } from '../../../../store'
import { IconSvg } from '../../../../styles'
import { eventList, glb_sv, Screens } from '../../../../utils'
import ekycService, { IBackData } from '../../ekycService'
import { apiFPT, createFormData, fetchTimeout } from '../../middleProcess'

export const useStepEkyc02 = ({ onProcessUploaded = (data) => {}, isClearDataAndStartFromBegin, switchStep }) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()
    const navigation = useNavigation()
    const [isAllowNextStep, setIsAllowNextStep] = useState(false) // if user has data image one server auto passed next step button
    const cameraRef = useRef<RNCamera>(null)
    const [forceUpdate, setForceUpdate] = useState({})

    const [fileInfo, setFileInfo] = useState<TakePictureResponse | { uri: string }>({ uri: '' })
    const [loading, setLoading] = useLoading(false)
    const [uploaded, setUploaded] = useState<boolean | null>(null)
    const [urlSuccess, setUrlSuccess] = useState('')
    const [idImage, setIdImage] = useState('')

    const [listMessage, setListMessage] = useState<string[]>([])
    // modal when capture image failed
    const [alertModal, setAlertModal] = useState(false)

    useEffect(() => {
        if (listMessage.length !== 0) {
            InteractionManager.runAfterInteractions(() => {
                setTimeout(() => {
                    setAlertModal(true)
                }, 10)
            })
        }
    }, [listMessage])

    useEffect(() => {
        const commonEvent = glb_sv.commonEvent.subscribe((msg: any) => {
            if (msg.type === eventList.RESET_FPT_EKYC_DATA) {
                setFileInfo({ uri: '' })
                setLoading(false)
                setUploaded(null)
                setUrlSuccess('')
                setListMessage([])
            }
        })

        return () => {
            commonEvent.unsubscribe()
        }
    }, [])

    useEffect(() => {
        if (!isEmpty(ekycService.imageData.back_id)) {
            setUrlSuccess(`data:image/jpeg;base64,${ekycService.imageData.back_id}`)
            setIsAllowNextStep(true)
        }
    }, [])

    useEffect(() => {
        if (isClearDataAndStartFromBegin) {
            onRemoveImages()
        }
    }, [isClearDataAndStartFromBegin])

    const onRemoveImages = () => {
        setFileInfo({ uri: '' })
        setUploaded(null)
        setUrlSuccess('')
        setLoading(false)
        setIdImage('')
        setListMessage([])
        setIsAllowNextStep(false)
        Analytics.logEvent(EkycAnalyticEvents.ekyc_step_two_take_back_again)
        glb_sv.sendEKYCLogNewTracking({
            sEKYCLog: EkycAnalyticEvents.ekyc_step_two_take_back_again,
            reason: 'Chụp lại CMND mặt sau',
            eKYCType: '4',
            ekycStep: '2',
        })
    }

    const renderFileUri = () => {
        if (fileInfo.uri || urlSuccess) {
            return (
                <Image
                    source={{ uri: fileInfo.uri || urlSuccess }}
                    style={{ height: '100%', width: '100%', borderRadius: 5, backgroundColor: styles.PRIMARY__BORDER__COLOR }}
                />
            )
        }
    }

    const takePicture = async () => {
        if (cameraRef.current) {
            const iosOptions: TakePictureOptions = { quality: 0.7, base64: false, width: 2000, orientation: 'portrait' }
            const androidOptions: TakePictureOptions = { quality: 0.9, base64: false, orientation: 'portrait' }
            const data = await cameraRef.current.takePictureAsync(Platform.OS === 'ios' ? iosOptions : androidOptions)
            const { uri } = data
            setFileInfo(data)
            setUrlSuccess(uri)
        }
    }

    const onUploadData = async () => {
        if (isAllowNextStep === true) {
            switchStep.next()
            return
        }
        if (!urlSuccess) return
        try {
            const urlEnd = Platform.OS === 'ios' ? urlSuccess.replace('file://', '') : urlSuccess
            const fileData = await fetch(urlEnd)
            const {
                // @ts-expect-error
                _bodyBlob: { _data: data },
            } = fileData
            const sec = glb_sv.activeCode
            const step = '2'
            const userId = glb_sv.objShareGlb.sessionInfo.userID
            const type = 'IMAGE'
            const timeout = 30000
            const mdmTp = Platform.OS === 'android' ? '03' : '04'
            const mwLoginID = Platform.OS === 'android' ? 'Android' : 'IOS'
            const body = createFormData(fileInfo, null, {
                sec,
                fileName: data.name,
                fileType: data.type,
                userId,
                size: data.size,
                step,
                type,
                timeout,
                Mdmtp: mdmTp,
                MWLoginID: mwLoginID,
            })
            setLoading(true)
            //Gửi request
            fetchTimeout(`${apiFPT}/upload/`, timeout, fetchingCallback, {
                method: 'POST',
                headers: { 'Content-Type': 'multipart/form-data' },
                body,
            })
                .then((response) => response.json())
                .then((data) => {
                    const dataLog = { ...data }
                    dataLog.cropped_idcard_base64 = ''
                    dataLog.face_base64 = ''
                    Analytics.logEvent(EkycAnalyticEvents.ekyc_step_two_take_back_upload)
                    glb_sv.sendEKYCLogNewTracking({
                        sEKYCLog: EkycAnalyticEvents.ekyc_step_two_take_back_upload,
                        eKYCType: '3',
                        reason: 'Chụp ảnh mặt sau CMND và upload đến bước tiếp theo',
                        ekycStep: '2',
                    })
                    if (data.success == true) {
                        onProcessUploaded(data)
                        checkDataBackIDCard(dataLog)
                        setLoading(false)
                        if (data.errorCode !== 0) {
                            setUploaded(false)
                            setListMessage(data.errorMessage)
                        }
                    } else {
                        setUploaded(null)
                        setListMessage([data.error?.['message']])
                    }
                })
                .catch((error) => {
                    setLoading(false)
                    setUploaded(null)
                    if (error.name === 'AbortError') {
                        // Processing timeout
                        setListMessage(['request_hanlde_not_success_try_again'])
                    } else {
                        // network error or json parsing error
                        setListMessage(['Can_not_connected_to_server_plz_check_your_network'])
                    }
                })
        } catch (error) {
            setUploaded(null)
            setListMessage(['file_is_error_please_take_again'])
        }
    }

    const fetchingCallback = () => {
        setLoading(false)
        setUploaded(null)

        // ToastGlobal.show({
        //     text2: t('common_server_no_response'),
        //     type: 'warning'
        // })
    }
    const checkDataBackIDCard = (data: IBackData) => {
        // 1. Check ngày hết hạn CMND = Ngày cấp + 15 năm
        // 2. Check mờ nhòe
        // ------
        if (data.issue_date && moment().isAfter(moment(data.issue_date, 'DD/MM/YYYY').add(15, 'years'))) {
            InteractionManager.runAfterInteractions(() => {
                ModalController.showModal({
                    icon: <IconSvg.ErrorIcon color={styles.INFO__COLOR} />,
                    title: t('common_notify').toLocaleUpperCase(),
                    colorTitle: styles.EKYC__COLOR,
                    content: t('notify_info_ekyc_issue_loc_expired'),
                    titleOK: t('continue').toLocaleUpperCase(),
                    typeColor: styles.INFO__COLOR,
                    showCancel: true,
                    linkCallback: () => {
                        navigation.replace(Screens.SIGN_IN)
                    },
                })
            })
        }
    }

    return {
        styles,
        forceUpdate,
        t,
        alertModal,
        setAlertModal,
        loading,
        uploaded,
        urlSuccess,
        takePicture,
        renderFileUri,
        cameraRef,
        listMessage,
        onRemoveImages,
        onUploadData,
        setLoading,
        switchStep,
    }
}
