/* eslint-disable no-restricted-syntax */
import React, { useContext, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { InteractionManager, RefreshControl, StyleSheet, View } from 'react-native'
import Modal from 'react-native-modal'
import StepIndicator from 'react-native-step-indicator'
import Svg, { Circle, Path } from 'react-native-svg'
import ToastGlobal from 'react-native-toast-message'
import ModalController from '@mts-components/appModal/modalControlller'
import { Container, Content, Tab, Tabs } from 'native-base'

import HeaderComponent from '../../../components/header'
import ModalLoading from '../../../components/modal-loading'
import { ButtonCustom, ModalContent, RowDataModal } from '../../../components/trading-component'
import { allowCompanyRender, useAlertModal, useAlertModalCommonCode, useModalOtpWhenErr } from '../../../hoc'
import { StoreContext } from '../../../store'
import { StoreTrading } from '../../../store-trading'
import { dimensions as dm, IconSvg } from '../../../styles'
import { FormatNumber, glb_sv, reqFunct, Screens, wait } from '../../../utils'
import sendRequest from '../../../utils/sendRequest'
import StepOne from './step-one'
import StepTwo from './step-two'

// Khai báo ServiceInfo (nếu có)
const ServiceInfo = {
    ADD_NEW_WITH_DRAWAL: {
        reqFunct: reqFunct.ADD_NEW_WITH_DRAWAL,
        WorkerName: 'FOSxCash',
        ServiceName: 'FOSxCash_0201_2',
        ClientSentTime: '0',
        Operation: 'I',
    },
    CHECK_WITHDRAWAL: {
        reqFunct: reqFunct.CHECK_WITHDRAWAL,
        WorkerName: 'FOSqCash',
        ServiceName: 'FOSqCash_0201_2',
        ClientSentTime: '0',
        Operation: 'Q',
    },
}

const initErrCtrl = [
    {
        error: false,
        message: 'warning_heir_account',
    },
    {
        error: false,
        message: 'warning_cash_input',
    },
]

// Khai báo component
const BankWithDrawal = ({ navigation }) => {
    const { styles } = useContext(StoreContext)
    const { userInfo } = useContext(StoreTrading)

    const { t } = useTranslation()
    // All orther state
    const [activeStep, setActiveStep] = useState(0)
    const [isOpenModal, setIsOpenModal] = useState(false)
    const [refreshing, setRefreshing] = React.useState(false)

    // Start define all bussiness state
    const [currentSubCash, setCurrentSubCash] = useState({})
    const [actReceive, setActReceive] = useState({})
    const [bankReceive, setBankReceive] = useState({})
    const [amountWithDrawal, setAmountWithDrawal] = useState(0)
    const [hisWithDrawalList, setHisWithDrawalList] = useState([])
    const [errCtrl, setErrCtrl] = useState(initErrCtrl)
    const [loadingConfirm, setLoadingConfirm] = useState(false)

    // End define form bussiness state
    // -------------------------------------------   Dùng useEffect get các dữ liệu cần thiết còn thiếu
    // -------------------------------------------   Viết các hàm để set lại bussiness form state. Nên viết đúng một chuẩn duy nhất để dễ control
    const onRefresh = React.useCallback(() => {
        setRefreshing(true)
        wait(300).then(() => setRefreshing(false))
    }, [])

    const switchStep = {
        goTo: (step) => {
            setActiveStep(step)
        },
        next: () => {
            setActiveStep(activeStep + 1)
        },
        prev: () => {
            setActiveStep(activeStep - 1)
        },
        submit: () => confirmWithDrawal(),
        onFinish: () => _checkValueBfSend(),
        getCurrent: () => {
            return activeStep
        },
    }

    const hideModal = () => {
        setIsOpenModal(false)
    }

    const _resetInput = () => {
        glb_sv.checkLoadHistory = !glb_sv.checkLoadHistory

        setActReceive({})
        setBankReceive({})
        setAmountWithDrawal(0)
    }
    const _onClickBackButton = () => {
        if (activeStep > 0) switchStep.prev()
        if (activeStep === 0) navigation.goBack()
    }

    const _checkValueBfSend = (isAuthen) => {
        hideModal()
        _validateValue()

        if (errCtrl.filter((item) => item.error === true).length === 0) {
            if (!isAuthen) {
                if (allowCompanyRender(['081'])) {
                    // SSV-493: Kiểm tra khả năng rút tiền trước khi thực hiện rút tiền
                    checkWithDrawal()
                    return
                }
                navigation.navigate(Screens.OTP_MODAL, {
                    transactionOTP: true,
                    otp_Type: Number(glb_sv.objShareGlb.userInfo.c6),
                    functCallback: _checkValueBfSend,
                })
                return
            }
            setIsOpenModal(true)
        }
    }

    const checkWithDrawal = () => {
        const inputParams = ['1', userInfo.actn_curr, userInfo.sub_curr]
        sendRequest(ServiceInfo.CHECK_WITHDRAWAL, inputParams, handleCheckWithDrawalResult, true, handleCheckWithDrawalTimeout)
    }

    const handleCheckWithDrawalResult = (reqInfoMap, message) => {
        // console.log('handleCheckWithDrawalResult: ', reqInfoMap, message)
        if (Number(message.Result) === 0) {
            // Kiểm tra tiền khả dụng lỗi => Bỏ qua
            requestOTP()
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {}
            if (jsondata.length <= 0 || Number(jsondata[0].c5) === Number(currentSubCash.c5)) {
                // Kiểm tra tiền khả dụng lỗi hoặc tiền khả dụng không thay đổi => Tạo OTP tiếp tục thực hiện
                requestOTP()
            } else {
                // Tiền khả dụng hiện tại và tiền khả dụng hiển thị đang chênh lệnh => Show thông báo confirm
                // Đồng ý => Tiếp tục gửi yêu cầu rút tiền
                // Huỷ => Set tiền khả dụng mới vào form hiện tại và đóng thông báo
                // navigation.navigate(Screens.ALERT_MODAL, {
                // icon: <IconSvg.ErrorIcon color={styles.WARN__COLOR} />,
                // title: t('common_notify'),
                // content: t('cash_available_is_changed_note'),
                // typeColor: styles.WARN__COLOR,
                // showCancel: true,
                // linkCallback: () => {
                //     setCurrentSubCash(jsondata[0])
                //     requestOTP()
                // },
                // cancelCallBack: () => {
                //     setCurrentSubCash(jsondata[0])
                // },
                // })
                ModalController.showModal({
                    icon: <IconSvg.ErrorIcon color={styles.WARN__COLOR} />,
                    title: t('common_notify'),
                    content: t('cash_available_is_changed_note'),
                    typeColor: styles.WARN__COLOR,
                    showCancel: true,
                    linkCallback: () => {
                        setCurrentSubCash(jsondata[0])
                        requestOTP()
                    },
                    cancelCallBack: () => {
                        setCurrentSubCash(jsondata[0])
                    },
                })
            }
        }
    }

    const handleCheckWithDrawalTimeout = () => {
        ToastGlobal.show({
            text2: t('request_hanlde_not_success_try_again'),
            type: 'warning',
        })
    }

    const requestOTP = () => {
        // Tạo yêu cầu sinh OTP
        navigation.navigate(Screens.OTP_MODAL, {
            transactionOTP: true,
            otp_Type: Number(glb_sv.objShareGlb.userInfo.c6),
            functCallback: _checkValueBfSend,
        })
    }

    const _validateValue = (inputIndex) => {
        const newErrCtrl = [...initErrCtrl]

        if (inputIndex === 0) newErrCtrl[0].error = !actReceive?.value?.c1
        if (inputIndex === 1) newErrCtrl[1].error = Number(amountWithDrawal) <= 0 || !amountWithDrawal
        if (!inputIndex && inputIndex !== 0) {
            newErrCtrl[0].error = !actReceive?.value?.c1
            newErrCtrl[1].error = Number(amountWithDrawal) <= 0
        }

        newErrCtrl[0].message = t(initErrCtrl[0].message)
        newErrCtrl[1].message = t(initErrCtrl[1].message)

        setErrCtrl(newErrCtrl)
    }

    // -------------------------------------------   Khai báo các hàm gửi (request) lên server
    const confirmWithDrawal = () => {
        hideModal()
        const isAuthenOTP = glb_sv.checkOtp(navigation, () => {
            setTimeout(() => {
                confirmWithDrawal()
            }, 100)
        })
        if (!isAuthenOTP) return

        InteractionManager.runAfterInteractions(() => {
            const inputParams = [
                userInfo.actn_curr,
                userInfo.sub_curr,
                '2',
                '1',
                actReceive?.value?.c3,
                actReceive?.value?.c1,
                String(amountWithDrawal), // Số tiền rút
                '0',
                '', // Ghi chú
            ]

            ServiceInfo.SubNo = userInfo.sub_curr
            sendRequest(ServiceInfo.ADD_NEW_WITH_DRAWAL, inputParams, handleConfirmWithDrawal)
            setLoadingConfirm(true)
        })
    }

    // -------------------------------------------   Khai báo các hàm gửi (request) và nhận (handle respone) dữ liệu từ server
    const handleConfirmWithDrawal = (reqInfoMap, message) => {
        setLoadingConfirm(false)
        // _resetInput()
        // -- process after get result --
        if (Number(message.Result) === 0) {
            const { hasAlertCommonCode } = useAlertModalCommonCode(message, {})
            const { hasAlertErrOtp } = useModalOtpWhenErr(message, { continueVerify: !hasAlertCommonCode, callback: () => confirmWithDrawal() })
            useAlertModal(message, { continueVerify: !hasAlertErrOtp })
        } else {
            _resetInput()

            ToastGlobal.show({
                text2: message.Message,
                type: 'success',
            })
            switchStep.goTo(0)
        }
        // setIsOpenModal(false)
    }

    const renderStepIndicator = (params) => {
        if (params.position === 0) {
            return (
                <View>
                    <Svg fill="none" height={30} viewBox="0 0 30 30" width={30} xmlns="http://www.w3.org/2000/svg">
                        <Circle cx={15} cy={15} fill={params.position <= switchStep.getCurrent() ? '#60B44A' : '#D1D5DB'} r={15} />
                        <Path
                            d="M15 21.916l1.469-.339-1.13-1.13-.34 1.47zM14.71 20.949l.243-1.053.002-.008a.493.493 0 01.004-.013l.004-.012a.176.176 0 01.015-.032.27.27 0 01.008-.013l.005-.008a.21.21 0 01.015-.02l.01-.01.004-.005 3.275-3.275c-.914-1.88-2.605-3-4.545-3-1.423 0-2.737.609-3.7 1.714C9.078 16.328 8.531 17.88 8.5 19.6c.574.289 2.93 1.401 5.249 1.401.32 0 .641-.018.96-.051zM15.548 19.951l3.889-3.888 1.414 1.414-3.889 3.888-1.414-1.414zM13.75 13a2.5 2.5 0 100-5 2.5 2.5 0 000 5zM21.5 16.416a1 1 0 00-1.707-.707l1.414 1.414a.994.994 0 00.293-.707z"
                            fill="#fff"
                        />
                    </Svg>
                </View>
            )
        }
        if (params.position === 1) {
            return (
                <View>
                    <Svg fill="none" height={30} viewBox="0 0 30 30" width={30} xmlns="http://www.w3.org/2000/svg">
                        <Circle cx={15} cy={15} fill={params.position <= switchStep.getCurrent() ? '#60B44A' : '#D1D5DB'} opacity={1} r={15} />
                        <Path
                            d="M15 8.5A6.507 6.507 0 008.5 15c0 3.584 2.916 6.5 6.5 6.5s6.5-2.916 6.5-6.5-2.916-6.5-6.5-6.5zm-1.188 9.762l-2.518-2.8.743-.668 1.75 1.944 4.15-4.942.767.642-4.892 5.824z"
                            fill={'#fff'}
                        />
                    </Svg>
                </View>
            )
        }
    }

    return (
        <Container>
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft
                leftButtonLink={_onClickBackButton}
                navigation={navigation}
                title={t('title_money_withdrawal')}
                titleAlgin="flex-start"
                transparent
            />
            <Content
                refreshControl={
                    <RefreshControl
                        refreshing={refreshing}
                        onRefresh={onRefresh} // title={t('pull_refresh')}
                        // titleColor={styles.PRIMARY__CONTENT__COLOR}
                        tintColor={styles.PRIMARY__CONTENT__COLOR}
                    />
                }
                style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}
            >
                <View style={UI.stepIndicator}>
                    <StepIndicator
                        customStyles={secondIndicatorStyles}
                        labels={[t('choose_account'), t('trading_confirm')]}
                        stepCount={2}
                        currentPosition={activeStep}
                        // onPress={switchStep.goTo}
                        renderStepIndicator={renderStepIndicator}
                    />
                </View>
                <Tabs locked page={activeStep} renderTabBar={() => <View />} style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
                    <Tab heading={<View />} style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
                        <StepOne
                            currentSubCash={currentSubCash}
                            hisWithDrawalList={hisWithDrawalList}
                            navigation={navigation}
                            refreshing={refreshing}
                            setActReceive={setActReceive}
                            setAmountWithDrawal={setAmountWithDrawal}
                            setCurrentSubCash={setCurrentSubCash}
                            setHisWithDrawalList={setHisWithDrawalList}
                            setRefreshing={setRefreshing}
                            switchStep={switchStep}
                        />
                    </Tab>
                    <Tab heading={<View />} style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
                        <StepTwo
                            _validateValue={_validateValue}
                            actReceive={actReceive}
                            amountWithDrawal={amountWithDrawal}
                            currentSubCash={currentSubCash}
                            errCtrl={errCtrl}
                            navigation={navigation}
                            setActReceive={setActReceive}
                            setAmountWithDrawal={setAmountWithDrawal}
                            setErrCtrl={setErrCtrl}
                            switchStep={switchStep}
                        />
                    </Tab>
                </Tabs>
            </Content>
            {/* **************************************** Modal submit ******************************************/}
            {isOpenModal && (
                <Modal isVisible={isOpenModal} useNativeDriver={true} onBackButtonPress={hideModal} onBackdropPress={hideModal}>
                    <ModalContent
                        iconComponent={
                            <Svg fill="none" height="32" viewBox="0 0 33 32" width="33" xmlns="http://www.w3.org/2000/svg">
                                <Path
                                    d="M7.53452 6.48793L20.2914 3.00584L19.6158 1.64032C19.1738 0.752727 18.0958 0.386191 17.2082 0.82819L5.78809 6.48793H7.53452Z"
                                    fill="#2ECC71"
                                />
                                <Path
                                    d="M24.2509 3.10547C24.0928 3.10547 23.9346 3.12703 23.7765 3.17015L20.7796 3.98946L11.627 6.48693H22.0157H26.5435L25.9829 4.43146C25.7673 3.63012 25.0414 3.10547 24.2509 3.10547Z"
                                    fill="#2ECC71"
                                />
                                <Path
                                    d="M28.4164 7.74609H28.0068H27.4498H26.8928H22.6417H7.02082H4.97253H3.24766H2.92784H1.85698C1.28921 7.74609 0.782525 8.00842 0.451924 8.42167C0.300998 8.61212 0.186006 8.83133 0.121323 9.07209C0.081795 9.22302 0.0566406 9.38113 0.0566406 9.54284V9.75845V11.8067V29.5622C0.0566406 30.554 0.861582 31.3589 1.85338 31.3589H28.4128C29.4047 31.3589 30.2096 30.554 30.2096 29.5622V24.5492H19.5477C17.8624 24.5492 16.4932 23.1801 16.4932 21.4948V19.849V19.292V18.735V17.4988C16.4932 16.6723 16.8238 15.9213 17.3593 15.3715C17.8336 14.8828 18.4697 14.5522 19.1812 14.4695C19.2998 14.4552 19.4219 14.4479 19.5441 14.4479H28.7147H29.2717H29.8287H30.2096V9.54284C30.2132 8.55103 29.4082 7.74609 28.4164 7.74609Z"
                                    fill="#2ECC71"
                                />
                                <Path
                                    d="M31.47 16.1641C31.2903 15.9988 31.0783 15.873 30.8411 15.7903C30.6578 15.7293 30.4638 15.6934 30.259 15.6934H30.2123H30.1763H29.6193H27.6106H19.5468C18.5549 15.6934 17.75 16.4983 17.75 17.4901V18.3848V18.9418V19.4988V21.4896C17.75 22.4814 18.5549 23.2864 19.5468 23.2864H30.2123H30.259C30.4638 23.2864 30.6578 23.2504 30.8411 23.1893C31.0783 23.1103 31.2903 22.9809 31.47 22.8156C31.8293 22.4886 32.0557 22.0143 32.0557 21.4897V17.4901C32.0557 16.9654 31.8293 16.491 31.47 16.1641ZM23.2984 19.8474C23.2984 20.3433 22.8959 20.7458 22.4 20.7458H21.8035C21.3076 20.7458 20.9051 20.3433 20.9051 19.8474V19.2509C20.9051 18.9634 21.0381 18.7082 21.2501 18.5465C21.4046 18.4279 21.5951 18.3525 21.8035 18.3525H21.9544H22.4C22.8959 18.3525 23.2984 18.7549 23.2984 19.2509V19.8474Z"
                                    fill="#2ECC71"
                                />
                            </Svg>
                        }
                        title={t('confirm_request_withd')}
                        type="confirm"
                    >
                        <RowDataModal dataSub={[userInfo.actn_curr, userInfo.sub_curr]} textLeft={t('acnt_no')} textRight={userInfo.actn_curr} />

                        <RowDataModal textLeft={t('acc_number_full')} textRight={actReceive?.value?.c3} />

                        <RowDataModal textLeft={t('bank_cd')} textRight={actReceive?.value?.c6} />

                        <RowDataModal last textLeft={t('amount_drawal')} textRight={FormatNumber(amountWithDrawal)} />

                        <ButtonCustom text={t('common_button_confirm')} type="confirm" onPress={confirmWithDrawal} />
                        <ButtonCustom last text={'common_Cancel'} type="back" onPress={hideModal} />
                    </ModalContent>
                </Modal>
            )}
            {loadingConfirm && <ModalLoading content={t('common_processing')} visible={loadingConfirm} />}
        </Container>
    )
}

export default BankWithDrawal

const UI = StyleSheet.create({
    Button: {
        alignItems: 'center',
        borderRadius: 8,
        height: dm.moderate(20),
        justifyContent: 'center',
        width: dm.moderate(20),
    },
    Row_Modal: {
        height: dm.vertical(24),
        marginVertical: dm.vertical(16),
    },
    container: {
        backgroundColor: '#ffffff',
        flex: 1,
    },
    page: {
        flex: 1,
        flexDirection: 'column',
    },
    stepIndicator: {
        marginBottom: dm.vertical(8),
        marginTop: dm.vertical(24),
        // marginVertical: 50,
    },
})

const secondIndicatorStyles = {
    stepIndicatorSize: 32,
    currentStepIndicatorSize: 32,
    separatorStrokeWidth: 3,
    currentStepStrokeWidth: 4,
    stepStrokeCurrentColor: '#60B44A',
    stepStrokeWidth: 2,
    separatorStrokeFinishedWidth: 4,
    stepStrokeFinishedColor: '#60B44A',
    stepStrokeUnFinishedColor: '#aaaaaa',
    separatorFinishedColor: '#60B44A',
    separatorUnFinishedColor: '#aaaaaa',
    stepIndicatorFinishedColor: '#60B44A',
    stepIndicatorUnFinishedColor: '#ffffff',
    stepIndicatorCurrentColor: '#ffffff',
    stepIndicatorLabelFontSize: 13,
    currentStepIndicatorLabelFontSize: 13,
    stepIndicatorLabelCurrentColor: '#60B44A',
    stepIndicatorLabelFinishedColor: '#ffffff',
    stepIndicatorLabelUnFinishedColor: '#aaaaaa',
    labelColor: '#999999',
    labelSize: 13,
    currentStepLabelColor: '#60B44A',
}
