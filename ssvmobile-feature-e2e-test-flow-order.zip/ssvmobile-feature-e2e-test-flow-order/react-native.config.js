module.exports = {
    dependencies: {
        'react-native-camera': {
            platforms: {
                android: null,
                ios: null,
            },
        },
    },
}
