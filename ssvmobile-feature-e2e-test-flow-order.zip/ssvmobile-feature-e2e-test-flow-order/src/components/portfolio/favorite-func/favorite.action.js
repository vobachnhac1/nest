import SyncStorage from 'sync-storage'

import { eventList, glb_sv, saveStatisticTrackingStock } from '../../../utils'

function getAllLocalFavList() {
    return SyncStorage.get('FAV_LIST_LS') || []
}

function clearAllLocalFavList() {
    SyncStorage.remove('FAV_LIST_LS')
}

function saveNewFavList(listName, isOddlot) {
    let currentFavList = [...glb_sv.allListFav]
    const curFav = {
        c1: String(Math.random()), // ID
        c2: listName, // Name List
        type: 'watchlist',
        ListStock: [],
        isOddlot,
    }

    if (glb_sv.configInfo.application_style.default_style === '2.0') {
        const listFixed = currentFavList.filter((item) => item.type === 'fixed')
        currentFavList = currentFavList.filter((item) => item.type !== 'fixed')
        currentFavList.push(curFav)
        currentFavList = currentFavList.concat(listFixed)
        glb_sv.allListFav = currentFavList
        glb_sv.commonEvent.next({ type: eventList.CHANGE_LIST_FAV })
    } else {
        currentFavList.push(curFav)
        glb_sv.allListFav = currentFavList
        glb_sv.activeList = curFav
        glb_sv.commonEvent.next({ type: eventList.CHANGE_LIST_ACTIVE })
    }
    SyncStorage.set(
        'FAV_LIST_LS',
        currentFavList.filter((e) => e.type === 'watchlist'),
    )
}

function editFavListName(listName, IDList) {
    const currentFavList = [...glb_sv.allListFav]
    const curFav = currentFavList.find((e) => e.c1 === IDList)
    if (curFav) {
        curFav.c2 = listName
        glb_sv.allListFav = currentFavList
        SyncStorage.set(
            'FAV_LIST_LS',
            currentFavList.filter((e) => e.type === 'watchlist'),
        )

        if (glb_sv.configInfo.application_style.default_style === '2.0') {
            glb_sv.commonEvent.next({ type: eventList.CHANGE_LIST_FAV })
        } else {
            if (glb_sv.activeList.c1 === IDList) {
                glb_sv.activeList.c2 = listName
                glb_sv.commonEvent.next({ type: eventList.CHANGE_LIST_ACTIVE })
            } else glb_sv.commonEvent.next({ type: eventList.CHANGE_LIST_FAV })
        }
    }
}

function delFavList(IDList) {
    const currentFavList = glb_sv.allListFav.filter((e) => e.c1 !== IDList)
    glb_sv.allListFav = currentFavList
    if (glb_sv.configInfo.application_style.default_style === '2.0') {
        glb_sv.commonEvent.next({ type: eventList.CHANGE_LIST_FAV })
    } else {
        const newActiveList = glb_sv.allListFav[0]
        glb_sv.activeList = newActiveList ? { ...newActiveList } : { ListStock: [] }
        glb_sv.commonEvent.next({ type: eventList.CHANGE_LIST_ACTIVE })
    }
    SyncStorage.set(
        'FAV_LIST_LS',
        currentFavList.filter((e) => e.type === 'watchlist'),
    )
}

function AddStockToListFav(IDList, StockCode) {
    const currentFavList = [...glb_sv.allListFav]
    const curFav = currentFavList.find((e) => e.c1 === IDList)
    if (curFav) {
        // if (curFav.ListStock.some(e => e === StockCode)) return;
        curFav.ListStock.push(StockCode)
        glb_sv.allListFav = currentFavList
        glb_sv.activeList = curFav
        glb_sv.commonEvent.next({ type: eventList.CHANGE_LIST_STOCK, value: StockCode, isSub: true })
        SyncStorage.set(
            'FAV_LIST_LS',
            currentFavList.filter((e) => e.type === 'watchlist'),
        )
    }

    saveStatisticTrackingStock(StockCode)
}

function RemoveStockInListFav(IDList, StockCode) {
    const currentFavList = [...glb_sv.allListFav]
    const curFav = currentFavList.find((e) => e.c1 === IDList)
    if (curFav) {
        if (!curFav.ListStock.some((e) => e === StockCode)) return
        curFav.ListStock = curFav.ListStock.filter((e) => e !== StockCode)
        glb_sv.allListFav = currentFavList
        glb_sv.activeList = curFav
        glb_sv.commonEvent.next({ type: eventList.CHANGE_LIST_STOCK, value: StockCode, isSub: false })
        SyncStorage.set(
            'FAV_LIST_LS',
            currentFavList.filter((e) => e.type === 'watchlist'),
        )
    }
}

function SortStockInListFav() {}

export { AddStockToListFav, clearAllLocalFavList, delFavList, editFavListName, getAllLocalFavList, RemoveStockInListFav, saveNewFavList, SortStockInListFav }
