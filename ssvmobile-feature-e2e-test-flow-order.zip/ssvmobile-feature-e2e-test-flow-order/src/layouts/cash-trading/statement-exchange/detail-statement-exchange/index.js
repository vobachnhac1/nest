import React, { useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { StyleSheet } from 'react-native'
import { Container, Content } from 'native-base'

import HeaderComponent from '../../../../components/header'
import { RowData } from '../../../../components/trading-component'
import { StoreContext } from '../../../../store'
import { dimensions as dm } from '../../../../styles'
// Khai báo component
export default function DetailAnnouncementOrder({ navigation, route }) {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()
    const { params = {} } = route
    const { data = {} } = params
    // Start define all bussiness state
    // End define form bussiness state
    // -------------------------------------------   Dùng useEffect get các dữ liệu cần thiết còn thiếu

    // -------------------------------------------   Viết các hàm để set lại bussiness form state. Nên viết đúng một chuẩn duy nhất để dễ control

    // -------------------------------------------   Khai báo các hàm gửi (request) lên server
    // -------------------------------------------   Khai báo các hàm gửi (request) và nhận (handle respone) dữ liệu từ server

    const renderStockSymbolView = () => {
        if (data.c4.trim() === '') {
            return null
        } else {
            return <RowData textLeft={t('hint_stock_search')} textRight={data.c4} />
        }
    }
    const getColorTransaction = (oparator) => {
        if (oparator === '+') return styles.GREEN__COLOR
        if (oparator === '-') return styles.NOTIFY__ERROR
        return styles.PRIMARY__CONTENT__COLOR
    }

    return (
        <Container style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft
                navigation={navigation}
                title={t('sb_orderHis_dt_vise')}
                titleAlgin="flex-start"
                transparent
            />
            <Content>
                <RowData dataSub={[data.c2, data.c3]} textLeft={t('acnt_no')} />
                <RowData textLeft={t('date_trading')} textRight={data.c0} />
                <RowData textLeft={t('transaction_type')} textRight={data.c12} />
                {renderStockSymbolView()}
                <RowData rightColor={getColorTransaction(data.c5)} textLeft={t('value')} textRight={`${data.c5}${data.c6}`} />
                <RowData textLeft={t('hist_ord_dt_channel_trading')} textRight={data.c9} />
                <RowData
                    textLeft={t('common_work_user')}
                    textRight={data.c10}
                    // rightColor={getColor(data.c15)}
                />
                <RowData last textLeft={t('common_work_time')} textRight={data.c11} />
                {/* -------------- */}
            </Content>
        </Container>
    )
}

const UI = StyleSheet.create({
    Badge_Sub: {
        alignItems: 'center',
        borderRadius: 4,
        height: dm.moderate(20),
        justifyContent: 'center',
        marginLeft: 4,
        width: dm.moderate(20),
    },
    Button: {
        alignItems: 'center',
        borderRadius: 8,
        height: dm.moderate(28),
        justifyContent: 'center',
        width: dm.moderate(28),
    },
    Row_Modal: {
        height: dm.vertical(24),
        marginVertical: dm.vertical(12),
    },
})
