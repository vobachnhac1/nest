import React, { useMemo } from 'react'
import { StyleSheet, TouchableOpacity, View } from 'react-native'

import { Text } from '../../../basic-components'
import { dimensions, fontSizes, fontWeights } from '../../../styles'

const listTimeHis = ['1W', '1M', '3M', '6M', '1Y', '2Y', '3Y']

export default ({ title, typeTop, value, valueCol3, ratioValue, navigateStockInfo, styles, item, value_market, activeOtp }) => {
    const getColor = (value, item) => {
        // REF__COLOR: '#f1c40f',
        // UP__COLOR: '#2ECC71',
        // DOWN__COLOR: '#EB5C55',
        // CEIL__COLOR: '#f618fb',
        // FLOOR__COLOR: '#00d3b8',
        if (value > 0 && value > item.FL && value < item.REF) return styles.DOWN__COLOR
        else if (value > 0 && value < item.CE && value > item.REF) return styles.UP__COLOR
        else if (value === 0 || value === item.REF) return styles.REF__COLOR
        else if (value > 0 && value >= item.CE) return styles.CEIL__COLOR
        else if (value > 0 && value <= item.FL) return styles.FLOOR__COLOR
        return styles.REF__COLOR
    }

    const getColorHis = () => {
        if (item.CHGR > 0) return styles.UP__COLOR
        if (item.CHGR < 0) return styles.DOWN__COLOR
        return styles.REF__COLOR
    }
    const HeaderItemUI = useMemo(
        () =>
            StyleSheet.flatten([
                { borderBottomColor: styles.DIVIDER__COLOR, paddingVertical: dimensions.vertical(12), borderBottomWidth: 1, flexDirection: 'row' },
            ]),
        [styles],
    )
    const FlexStartUI = useMemo(() => StyleSheet.flatten([{ flex: 1, justifyContent: 'flex-start' }]), [styles])
    const FlexEndUI = useMemo(() => StyleSheet.flatten([{ flex: 1, justifyContent: 'flex-start' }]), [styles])

    const TextTitleUI = useMemo(
        () =>
            StyleSheet.flatten([
                {
                    color: listTimeHis.includes(activeOtp) ? styles.PRIMARY__CONTENT__COLOR : getColor(item.C, item),
                    fontSize: title?.length > 3 ? fontSizes.verySmall : fontSizes.small,
                    fontWeight: fontWeights.medium,
                },
            ]),
        [styles, activeOtp, item.C],
    )

    const TextRatioUI = useMemo(
        () =>
            StyleSheet.flatten([
                {
                    color: listTimeHis.includes(activeOtp) ? getColorHis() : getColor(item.C, item),
                    fontSize: fontSizes.verySmall,
                    textAlign: 'right',
                    fontWeight: fontWeights.medium,
                },
            ]),
        [styles, activeOtp, item.C, item.ChgRatio],
    )

    const TextCol3UI = useMemo(
        () =>
            StyleSheet.flatten([
                {
                    color: listTimeHis.includes(activeOtp) || typeTop === 'FRG_VAL_UP' ? styles.PRIMARY__CONTENT__COLOR : getColor(item.O, item),
                    fontSize: fontSizes.verySmall,
                    fontWeight: fontWeights.medium,
                    textAlign: 'right',
                },
            ]),
        [styles, activeOtp, typeTop, item.O],
    )
    const TextValueUI = useMemo(
        () =>
            StyleSheet.flatten([
                {
                    color: listTimeHis.includes(activeOtp) || typeTop === 'FRG_VAL_UP' ? styles.PRIMARY__CONTENT__COLOR : getColor(item.C, item),
                    fontSize: fontSizes.verySmall,
                    fontWeight: fontWeights.medium,
                    textAlign: 'right',
                },
            ]),
        [styles, activeOtp, typeTop, item.C],
    )
    const TextValueMarketUI = useMemo(
        () =>
            StyleSheet.flatten([{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.verySmall, fontWeight: fontWeights.medium, textAlign: 'right' }]),
        [styles, activeOtp, typeTop, item.C],
    )

    return (
        <TouchableOpacity style={HeaderItemUI} onPress={() => navigateStockInfo(title)}>
            <View style={FlexStartUI}>
                <Text style={TextTitleUI}>{title}</Text>
            </View>
            <View style={FlexEndUI}>
                <Text style={TextRatioUI}>
                    {item.CHGR > 0 ? '+' : ''}
                    {ratioValue}%
                </Text>
            </View>
            <View style={FlexEndUI}>
                <Text style={TextCol3UI}>{valueCol3}</Text>
            </View>
            <View style={FlexEndUI}>
                <Text style={TextValueUI}>{value}</Text>
            </View>
            <View style={FlexEndUI}>
                <Text style={TextValueMarketUI}>{value_market}</Text>
            </View>
        </TouchableOpacity>
    )
}
