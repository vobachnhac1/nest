import React, { useContext, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Container, Content, Icon, Left, List, ListItem, Right, Toast, View } from 'native-base'
// import Spinner from 'react-native-loading-spinner-overlay';
import SyncStorage from 'sync-storage'

import { Text } from '../../basic-components'
import HeaderComponent from '../../components/header'
import ModalLoading from '../../components/modal-loading'
import { StoreContext } from '../../store'
import { fontSizes } from '../../styles'
import { eventList, glb_sv, InfoStock, reqFunct, sendRequest } from '../../utils'
import STORE_KEY from '../../utils/constant/store_key'

function sortAsc(a, b) {
    if (a.t55 > b.t55) return 1
    if (a.t55 < b.t55) return -1
    return 0
}

const ServiceInfo = {
    GET_VERSION_STKLIST: {
        reqFunct: reqFunct.GET_VERSION_STKLIST,
        WorkerName: 'FOSqMkt01',
        ServiceName: 'FOSqMkt01_StockListVersion',
        Operation: 'Q',
        ClientSentTime: '0',
    },
    GET_STKLIST: {
        reqFunct: reqFunct.GET_STKLIST,
        WorkerName: 'FOSqMkt01',
        ServiceName: 'FOSqMkt01_StockListVersion',
        Operation: 'Q',
        ClientSentTime: '0',
    },
}

export default function LanguageStack({ navigation }) {
    const { language, setLanguage, styles } = useContext(StoreContext)
    const { t, i18n } = useTranslation()

    const languageList = glb_sv.configInfo.language_list?.length ? glb_sv.configInfo.language_list : ['vi', 'en']

    const jsonRef = useRef([])

    const [loading, setLoading] = useState(false)

    // useEffect(() => {

    //     return () => {
    //         navigation.dispatch(
    //             CommonActions.reset({
    //                 index: 1,
    //                 routes: [
    //                     { name: Screens.SETTINGS }
    //                 ],
    //             })
    //         );
    //     }
    // }, [])

    const changeLanguage = (key) => {
        if (language === key) return
        if (!glb_sv.isConnectApp) {
            Toast.show({
                text: t('Can_not_connected_to_server_plz_check_your_network'),
                type: 'warning',
            })
            return
        }
        setLoading(true)
        setTimeout(() => {
            i18n.changeLanguage(key)
            setLanguage(key)
            SyncStorage.set(STORE_KEY.LANGAGE, key)
            glb_sv.language = key
            glb_sv.eventMarket.next({ type: eventList.CHANGE_LANGUAGE })
            getStockList('01,03,05')

            // clear danh sach industry
            glb_sv.industryTab = {
                list: [],
                activeCode: '',
                activeList: [],
                activeName: '',
            }
        }, 200)
    }

    const loadStkListLocal = () => {
        const STOCK_INFO_HSX = SyncStorage.get(STORE_KEY.STOCK_INFO_HSX)
        const STOCK_INFO_HNX = SyncStorage.get(STORE_KEY.STOCK_INFO_HNX)
        const STOCK_INFO_UPC = SyncStorage.get(STORE_KEY.STOCK_INFO_UPC)

        const data = []
        if (glb_sv.language === 'VI') {
            data[0] = STOCK_INFO_HSX || require('../../assets/STOCK_INFO.OTS.01.json')
            data[1] = STOCK_INFO_HNX || require('../../assets/STOCK_INFO.OTS.03.json')
            data[2] = STOCK_INFO_UPC || require('../../assets/STOCK_INFO.OTS.05.json')
        } else {
            data[0] = STOCK_INFO_HSX || require('../../assets/STOCK_INFO.OTS.01.EN.json')
            data[1] = STOCK_INFO_HNX || require('../../assets/STOCK_INFO.OTS.03.EN.json')
            data[2] = STOCK_INFO_UPC || require('../../assets/STOCK_INFO.OTS.05.EN.json')
        }

        if (data && data.length === 3) {
            glb_sv.IndexMarket.HSXIndex.STOCK_INFO = data[0].filter((e) => e.t167 === 'ST').sort(sortAsc)
            glb_sv.IndexMarket.HSXIndex.warrant_list = data[0].filter((e) => e.t167 === 'CW').sort(sortAsc)
            glb_sv.IndexMarket.HSXIndex.bonds_list = data[0].filter((e) => e.t167 === 'BO').sort(sortAsc)
            glb_sv.IndexMarket.HSXIndex.etf_list = data[0].filter((e) => e.t167 === 'EF' || e.t167 === 'MF').sort(sortAsc)

            glb_sv.IndexMarket.HNXIndex.STOCK_INFO = data[1].filter((e) => e.t167 === 'ST').sort(sortAsc)
            glb_sv.IndexMarket.HNXIndex.bonds_list = data[1].filter((e) => e.t167 === 'BO').sort(sortAsc)
            glb_sv.IndexMarket.HNXIndex.etf_list = data[1].filter((e) => e.t167 === 'EF' || e.t167 === 'MF').sort(sortAsc)

            glb_sv.IndexMarket.HNXUpcomIndex.STOCK_INFO = data[2].sort(sortAsc)

            glb_sv.mrk_stklist = data[0].concat(data[1].concat(data[2]))
            glb_sv.mrk_stklist_lang = glb_sv.language
            glb_sv.mrk_stklist.sort(sortAsc)
            glb_sv.mrk_stklist.forEach((msgObj) => {
                let stkMsgObj = glb_sv.StockMarket[msgObj.t55]
                if (!stkMsgObj) {
                    stkMsgObj = new InfoStock()
                    stkMsgObj.t55 = msgObj.t55
                    stkMsgObj.U10 = msgObj.U10
                    stkMsgObj.U9 = msgObj.U9
                    stkMsgObj.U34 = msgObj.U34
                    stkMsgObj.t167 = msgObj.t167
                } else {
                    stkMsgObj.U10 = msgObj.U10
                    stkMsgObj.U9 = msgObj.U9
                    stkMsgObj.t167 = msgObj.t167
                }
            })
        }

        navigation.pop()
    }

    const getStockList = (type) => {
        const InputParams = ['download', type]
        sendRequest(ServiceInfo.GET_VERSION_STKLIST, InputParams, getStockListResult, true, getStockListTimeout)
        jsonRef.current = []
    }

    const getStockListTimeout = () => {
        navigation.pop()
    }

    const getStockListResult = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            getStockListTimeout()
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(glb_sv.filterStrBfParse(message.Data)) : []
            } catch (err) {
                getStockListTimeout()
                return
            }
            jsonRef.current = jsonRef.current.concat(jsondata)
            if (Number(message.Packet) <= 0) {
                workletData()
            }
        }
    }

    const workletData = () => {
        if (jsonRef.current.length) {
            const dataHSX = jsonRef.current
                .filter((e) => e.c0 === 'HSX')
                .map((e) => {
                    return {
                        t55: e.c1,
                        U9: e.c2,
                        U10: e.c0 === 'HSX' ? '01' : e.c0 === 'HNX' ? '03' : '05',
                        t167: e.c3,
                        U34: e.c5,
                    }
                })
            const dataHNX = jsonRef.current
                .filter((e) => e.c0 === 'HNX')
                .map((e) => {
                    return {
                        t55: e.c1,
                        U9: e.c2,
                        U10: e.c0 === 'HSX' ? '01' : e.c0 === 'HNX' ? '03' : '05',
                        t167: e.c3,
                        U34: e.c5,
                    }
                })
            const dataUPC = jsonRef.current
                .filter((e) => e.c0 === 'UPC')
                .map((e) => {
                    return {
                        t55: e.c1,
                        U9: e.c2,
                        U10: e.c0 === 'HSX' ? '01' : e.c0 === 'HNX' ? '03' : '05',
                        t167: e.c3,
                        U34: e.c5,
                    }
                })
            if (dataHSX.length) SyncStorage.set(STORE_KEY.STOCK_INFO_HSX, dataHSX)
            if (dataHNX.length) SyncStorage.set(STORE_KEY.STOCK_INFO_HNX, dataHNX)
            if (dataUPC.length) SyncStorage.set(STORE_KEY.STOCK_INFO_UPC, dataUPC)
            loadStkListLocal()
        } else {
            getStockListTimeout()
        }
    }

    return (
        <Container
            style={{
                backgroundColor: styles.PRIMARY__BG__COLOR,
            }}
        >
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft
                navigation={navigation}
                title={t('language')}
                titleAlgin="flex-start"
                transparent
            />
            <Content>
                <List>
                    <ListItem
                        activeOpacity={0.6}
                        noBorder
                        selected={language === 'VI' ? true : false}
                        underlayColor="transparent"
                        onPress={() => changeLanguage('VI')}
                    >
                        <Left>
                            <Text
                                style={{
                                    fontSize: fontSizes.normal,
                                    color: language === 'VI' ? styles.PRIMARY : styles.PRIMARY__CONTENT__COLOR,
                                }}
                            >
                                Tiếng Việt
                            </Text>
                        </Left>
                        <Right>{language === 'VI' ? <Icon name="check" style={{ color: styles.PRIMARY }} type="AntDesign" /> : null}</Right>
                    </ListItem>

                    <View style={{ borderBottomColor: styles.DIVIDER__COLOR, borderBottomWidth: 1 }} />

                    <ListItem
                        activeOpacity={0.6}
                        noBorder
                        selected={language === 'EN' ? true : false}
                        underlayColor="transparent"
                        onPress={() => changeLanguage('EN')}
                    >
                        <Left>
                            <Text
                                style={{
                                    fontSize: fontSizes.normal,
                                    color: language === 'EN' ? styles.PRIMARY : styles.PRIMARY__CONTENT__COLOR,
                                }}
                            >
                                English
                            </Text>
                        </Left>
                        <Right>{language === 'EN' ? <Icon name="check" style={{ color: styles.PRIMARY }} type="AntDesign" /> : null}</Right>
                    </ListItem>

                    <View style={{ borderBottomColor: styles.DIVIDER__COLOR, borderBottomWidth: 1 }} />

                    {languageList.includes('cn') && (
                        <>
                            <ListItem
                                activeOpacity={0.6}
                                noBorder
                                selected={language === 'CN' ? true : false}
                                underlayColor="transparent"
                                onPress={() => changeLanguage('CN')}
                            >
                                <Left>
                                    <Text
                                        style={{
                                            fontSize: fontSizes.normal,
                                            color: language === 'CN' ? styles.PRIMARY : styles.PRIMARY__CONTENT__COLOR,
                                        }}
                                    >
                                        中文(CN)
                                    </Text>
                                </Left>
                                <Right>{language === 'CN' ? <Icon name="check" style={{ color: styles.PRIMARY }} type="AntDesign" /> : null}</Right>
                            </ListItem>
                            <View style={{ borderBottomColor: styles.DIVIDER__COLOR, borderBottomWidth: 1 }} />
                        </>
                    )}

                    {languageList.includes('zh') && (
                        <>
                            <ListItem
                                activeOpacity={0.6}
                                noBorder
                                selected={language === 'ZH' ? true : false}
                                underlayColor="transparent"
                                onPress={() => changeLanguage('ZH')}
                            >
                                <Left>
                                    <Text
                                        style={{
                                            fontSize: fontSizes.normal,
                                            color: language === 'ZH' ? styles.PRIMARY : styles.PRIMARY__CONTENT__COLOR,
                                        }}
                                    >
                                        中文(ZH)
                                    </Text>
                                </Left>
                                <Right>{language === 'ZH' ? <Icon name="check" style={{ color: styles.PRIMARY }} type="AntDesign" /> : null}</Right>
                            </ListItem>
                            <View style={{ borderBottomColor: styles.DIVIDER__COLOR, borderBottomWidth: 1 }} />
                        </>
                    )}

                    {languageList.includes('ko') && (
                        <ListItem
                            activeOpacity={0.6}
                            noBorder
                            selected={language === 'KO' ? true : false}
                            underlayColor="transparent"
                            onPress={() => changeLanguage('KO')}
                        >
                            <Left>
                                <Text
                                    style={{
                                        fontSize: fontSizes.normal,
                                        color: language === 'KO' ? styles.PRIMARY : styles.PRIMARY__CONTENT__COLOR,
                                    }}
                                >
                                    한국어
                                </Text>
                            </Left>
                            <Right>{language === 'KO' ? <Icon name="check" style={{ color: styles.PRIMARY }} type="AntDesign" /> : null}</Right>
                        </ListItem>
                    )}
                </List>
            </Content>
            {loading ? <ModalLoading content={t('common_processing')} visible={loading} /> : null}
            {/* <Spinner visible={loading} /> */}
        </Container>
    )
}
