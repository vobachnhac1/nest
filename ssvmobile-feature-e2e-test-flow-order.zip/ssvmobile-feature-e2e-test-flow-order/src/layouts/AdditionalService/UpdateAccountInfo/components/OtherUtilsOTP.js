import React, { useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { StyleSheet, TouchableOpacity, View } from 'react-native'

import { Text } from '../../../../basic-components'
import { StoreContext } from '../../../../store'
import { dimensions as dm, fontSizes as fs, fontWeights, IconSvg } from '../../../../styles'

export const OtherUtilsOTP = ({ isOtpStatic, setIsOtpStatic = () => null, isOtpMatrix, setIsOtpMatrix = () => null, isOtpSMS, setIsOtpSMS = () => null }) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()

    const [isCheckContent, setIsCheckContent] = useState(isOtpStatic || false)
    const [isCheckContent02, setIsCheckContent02] = useState(isOtpMatrix || false)
    const [isCheckContent03, setIsCheckContent03] = useState(isOtpSMS || false)

    useEffect(() => {
        setIsOtpStatic(isCheckContent)
    }, [isCheckContent])

    useEffect(() => {
        setIsOtpMatrix(isCheckContent02)
    }, [isCheckContent02])

    useEffect(() => {
        setIsOtpSMS(isCheckContent03)
    }, [isCheckContent03])

    return (
        <>
            <View style={[UI.RowAction]}>
                <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fs.normal, fontWeight: fontWeights.bold }}>{t('change_otp_type')}</Text>
            </View>
            <View style={UI.row}>
                <TouchableOpacity
                    activeOpacity={0.9}
                    style={{ flexDirection: 'row', alignItems: 'center', marginTop: dm.vertical(16) }}
                    onPress={() => {
                        setIsCheckContent((value) => !value)
                        setIsCheckContent02(false)
                        setIsCheckContent03(false)
                    }}
                >
                    <View style={{ paddingTop: 2 }}>
                        <IconSvg.CheckboxIcon active={isCheckContent} colorActive={styles.PRIMARY} colorunActive={styles.PRIMARY__CONTENT__COLOR} />
                    </View>
                    <View>
                        <View>
                            <Text
                                style={{
                                    fontSize: fs.normal,
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                    marginLeft: dm.moderate(8),
                                    marginRight: 16,
                                }}
                            >
                                {t('static_OTP')}
                            </Text>
                        </View>
                        {/* <View>
                            <Text
                                style={{
                                    fontSize: fs.verySmall,
                                    color: styles.SECOND__CONTENT__COLOR,
                                    marginLeft: dm.moderate(8),
                                    marginRight: 16,
                                }}>
                                {t('free_sms_note')}
                            </Text>
                        </View> */}
                    </View>
                </TouchableOpacity>
            </View>
            <View style={UI.row}>
                <TouchableOpacity
                    activeOpacity={0.9}
                    style={{ flexDirection: 'row', alignItems: 'center', marginTop: dm.vertical(16) }}
                    onPress={() => {
                        setIsCheckContent(false)
                        setIsCheckContent02((value) => !value)
                        setIsCheckContent03(false)
                    }}
                >
                    <View style={{ paddingTop: 2 }}>
                        <IconSvg.CheckboxIcon active={isCheckContent02} colorActive={styles.PRIMARY} colorunActive={styles.PRIMARY__CONTENT__COLOR} />
                    </View>
                    <View>
                        <View>
                            <Text
                                style={{
                                    fontSize: fs.normal,
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                    marginLeft: dm.moderate(8),
                                    marginRight: 16,
                                }}
                            >
                                {t('matrix_code')}
                            </Text>
                        </View>
                        {/* <View>
                            <Text
                                style={{
                                    fontSize: fs.verySmall,
                                    color: styles.SECOND__CONTENT__COLOR,
                                    marginLeft: dm.moderate(8),
                                    marginRight: 16,
                                }}>
                                {t('notify_sms_note')}
                            </Text>
                        </View> */}
                    </View>
                </TouchableOpacity>
            </View>
            <View style={UI.row}>
                <TouchableOpacity
                    activeOpacity={0.9}
                    style={{ flexDirection: 'row', alignItems: 'center', marginTop: dm.vertical(16) }}
                    onPress={() => {
                        setIsCheckContent(false)
                        setIsCheckContent02(false)
                        setIsCheckContent03((value) => !value)
                    }}
                >
                    <View style={{ paddingTop: 2 }}>
                        <IconSvg.CheckboxIcon active={isCheckContent03} colorActive={styles.PRIMARY} colorunActive={styles.PRIMARY__CONTENT__COLOR} />
                    </View>
                    <View>
                        <View>
                            <Text
                                style={{
                                    fontSize: fs.normal,
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                    marginLeft: dm.moderate(8),
                                    marginRight: 16,
                                }}
                            >
                                {t('SMS')}
                            </Text>
                        </View>
                        {/* <View>
                            <Text
                                style={{
                                    fontSize: fs.verySmall,
                                    color: styles.SECOND__CONTENT__COLOR,
                                    marginLeft: dm.moderate(8),
                                    marginRight: 16,
                                }}>
                                {t('advance_sms_note')}
                            </Text>
                        </View> */}
                    </View>
                </TouchableOpacity>
            </View>
        </>
    )
}

const UI = StyleSheet.create({
    RowAction: { alignItems: 'center', flexDirection: 'row', paddingHorizontal: dm.moderate(16), paddingTop: dm.vertical(16) },
    row: {
        alignItems: 'center',
        borderRadius: 12,
        flexDirection: 'row',
        marginHorizontal: dm.moderate(16),
    },
})
