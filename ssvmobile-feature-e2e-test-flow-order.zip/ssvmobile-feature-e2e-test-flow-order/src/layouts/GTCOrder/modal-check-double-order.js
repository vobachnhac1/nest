import React, { memo, useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { View } from 'react-native'
import Modal from 'react-native-modal'
import { Button } from 'native-base'

import { Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { dimensions, fontSizes, IconSvg } from '../../styles'

function ModalCheckDoubleOrder({ modalCheckDoubleOrder, hanldeCheckDoubOrder, onHideModalCheckDoub }) {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()

    return (
        <Modal
            isVisible={modalCheckDoubleOrder}
            useNativeDriver={true}
            onBackButtonPress={() => hanldeCheckDoubOrder(false)}
            onBackdropPress={() => hanldeCheckDoubOrder(false)}
            onModalHide={onHideModalCheckDoub}
        >
            <View
                style={{
                    backgroundColor: styles.HEADER__BG__COLOR,
                    paddingHorizontal: 20,
                    paddingTop: 32,
                    paddingBottom: 8,
                    justifyContent: 'flex-start',
                    borderRadius: 4,
                    borderColor: 'rgba(0, 0, 0, 0.1)',
                }}
            >
                <View style={{ alignItems: 'center' }}>
                    <IconSvg.ErrorIcon color={styles.WARN__COLOR} />
                </View>
                <Text style={{ marginVertical: 22, fontSize: fontSizes.big, color: styles.PRIMARY__CONTENT__COLOR, textAlign: 'center' }}>
                    {t('common_notify')}
                </Text>

                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal }}>{t('confirm_send_the_same_order')}</Text>

                <Button
                    block
                    style={{
                        backgroundColor: styles.PRIMARY,
                        justifyContent: 'center',
                        alignSelf: 'center',
                        marginTop: dimensions.vertical(25),
                        borderRadius: 8,
                        width: '100%',
                    }}
                    transparent
                    onPress={() => hanldeCheckDoubOrder(true)}
                >
                    <Text style={{ color: '#FFF', fontSize: fontSizes.small }}>{t('common_Ok')}</Text>
                </Button>

                <Button block style={{ justifyContent: 'center', alignSelf: 'center', width: '100%' }} transparent onPress={() => hanldeCheckDoubOrder(false)}>
                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small, opacity: 0.34 }}>{t('common_Cancel')}</Text>
                </Button>
            </View>
        </Modal>
    )
}

export default memo(ModalCheckDoubleOrder, areEqual)

function areEqual(prev, next) {
    if (prev.modalCheckDoubleOrder === next.modalCheckDoubleOrder) return true
    return false
}
