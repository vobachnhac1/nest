import React, { memo } from 'react'
import { Pressable, StyleSheet, View } from 'react-native'
import deviceInfoModule from 'react-native-device-info'

import ICON_LINK_INDEX from '../../assets/images/common/ic_link_index.svg'
import { StyledView, Text } from '../../basic-components'
import { dimensions, fontSizes, fontWeights } from '../../styles'
import { FormatNumber, glb_sv } from '../../utils'
import SparklinesChartIndex from '../victory-chart/area/sparklines-chart-index'

const isTablet = deviceInfoModule.isTablet()

const getWidthIndex = (type, index) => {
    const WIDTH = (dimensions.WIDTH - dimensions.moderate(12, 0.3) * 2) / 3 - dimensions.moderate(2, 0.3) * 2 - 20
    if (!glb_sv.IndexMarket[index]?.totalStock) {
        if (type === 'ref') return WIDTH
        return 0
    }
    if (type === 'down') {
        if (glb_sv.IndexMarket[index]?.decrease) {
            return (glb_sv.IndexMarket[index]?.decrease / glb_sv.IndexMarket[index]?.totalStock) * WIDTH
        } else return 0
    }
    if (type === 'ref') {
        if (glb_sv.IndexMarket[index]?.noChange) {
            return (glb_sv.IndexMarket[index]?.noChange / glb_sv.IndexMarket[index]?.totalStock) * WIDTH
        } else return 0
    }
}

const WIDTH = isTablet ? 160 : (dimensions.WIDTH - dimensions.moderate(12, 0.3) * 2) / 3 - dimensions.moderate(2, 0.3) * 2

function ViewIndex({ color, title, value, ratioValue, active, onChange, type, styles, valueChang, showLineIncDec, showChart, showPoint }) {
    const getColor = (value, ref, color) => {
        // REF__COLOR: '#f1c40f',
        // UP__COLOR: '#2ECC71',
        // DOWN__COLOR: '#EB5C55',
        if (value > ref) return color.UP__COLOR
        if (value < ref) return color.DOWN__COLOR
        return color.REF__COLOR
    }

    const widthDown = getWidthIndex('down', type)
    const widthRef = getWidthIndex('ref', type)

    return (
        <Pressable onPress={() => onChange(type)}>
            <StyledView
                backgroundColor={styles.BUTTON__SECONDARY}
                borderColor={active === type ? styles.PRIMARY : styles.BUTTON__SECONDARY}
                borderRadius={8}
                borderWidth={StyleSheet.hairlineWidth}
                marginRight={dimensions.moderate(2)}
                paddingBottom={dimensions.vertical(9)}
                paddingLeft={10}
                paddingRight={10}
                paddingTop={dimensions.vertical(5)}
                width={WIDTH}
            >
                <View style={UI.row}>
                    {showPoint && <View style={[UI.circle, { backgroundColor: color }]} />}
                    <Text numberOfLines={1} style={[UI.title, { color: styles.PRIMARY__CONTENT__COLOR }]}>
                        {' '}
                        {title}
                    </Text>
                </View>

                {showChart && <SparklinesChartIndex height={50} index={type} styles={styles} width={WIDTH} />}

                <Text style={{ ...UI.value, color: getColor(valueChang, 0, styles) }}>{FormatNumber(value, 2)}</Text>
                <Text style={{ ...UI.ratioValue, color: getColor(valueChang, 0, styles) }}>
                    {valueChang > 0 ? '+' : ''}
                    {FormatNumber(valueChang, 2)} ({ratioValue > 0 ? '+' : ''}
                    {FormatNumber(ratioValue, 2)}%)
                </Text>
                {active === type && !showLineIncDec && (
                    <View style={{ position: 'absolute', bottom: 3, right: 3 }}>
                        <ICON_LINK_INDEX />
                    </View>
                )}
                {showLineIncDec && (
                    <StyledView flexDirection="row" marginTop={5} width="100%">
                        <StyledView backgroundColor={styles.UP__COLOR} borderRadius={2} height={3} width="100%" />
                        <StyledView
                            backgroundColor={styles.DOWN__COLOR}
                            borderBottomLeftRadius={2}
                            borderTopLeftRadius={2}
                            height={3}
                            left={-0.5}
                            position="absolute"
                            width={widthDown}
                            zIndex={1}
                        />
                        <StyledView
                            backgroundColor={styles.REF__COLOR}
                            borderRadius={2}
                            height={3}
                            left={widthDown - 0.5}
                            position="absolute"
                            width={widthRef}
                            zIndex={1}
                        />
                    </StyledView>
                )}
            </StyledView>
        </Pressable>
    )
}

export default memo(ViewIndex)

const UI = StyleSheet.create({
    circle: {
        borderRadius: 4,
        height: 8,
        marginTop: dimensions.vertical(7, 0.3),
        width: 8,
    },
    ratioValue: {
        fontSize: fontSizes.smallest,
        fontWeight: fontWeights.medium,
    },
    row: {
        flexDirection: 'row',
    },
    title: {
        fontSize: fontSizes.verySmall,
        fontWeight: fontWeights.normal,
        lineHeight: dimensions.moderate(22, 0.3),
    },
    value: {
        fontSize: fontSizes.medium,
        fontWeight: fontWeights.medium,
        lineHeight: dimensions.moderate(22, 0.3),
    },
    view: {
        borderRadius: 8,
        marginHorizontal: dimensions.moderate(2, 0.3),
        paddingBottom: dimensions.vertical(9, 0.3),
        paddingHorizontal: 10,
        paddingTop: dimensions.vertical(5, 0.3),
        width: (dimensions.WIDTH - dimensions.moderate(12, 0.3) * 2) / 3 - dimensions.moderate(2, 0.3) * 2,
    },
})
