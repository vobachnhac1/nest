import React, { useContext, useEffect, useRef } from 'react'
import { useTranslation } from 'react-i18next'
import { StyleSheet, View } from 'react-native'
import Animated, {
    Easing,
    Extrapolate,
    interpolate,
    interpolateColors,
    useAnimatedStyle,
    useSharedValue,
    withDelay,
    withRepeat,
    withTiming,
} from 'react-native-reanimated'

import { StoreContext } from '../../../../store'
import { dimensions as dm } from '../../../../styles'

export const ProgressByDot = ({ progress = 0, zIndex }: { progress: 0 | 1 | 2 | 3 | 4 | number; zIndex: number }) => {
    const { styles, theme, language } = useContext(StoreContext)
    const { t } = useTranslation()
    // const animation = useSharedValue(0)
    // const delay = 500
    // const repeat = false
    // const intervalColor = useRef(null)

    // useEffect(() => {
    //     clearInterval(intervalColor.current)
    //     animation.value = 4
    //     intervalColor.current = setInterval(() => {
    //         animation.value = (animation.value + 1) % 5
    //     }, 300)

    //     return () => {
    //         clearInterval(intervalColor.current)
    //         animation.value = 4
    //     }
    // }, [progress])

    // const bgColor = interpolateColors(animation.value, {
    //     inputRange: [0, 1, 2, 3, 4],
    //     outputColorRange: [styles.ERROR__COLOR, styles.WARN__COLOR, styles.INFO__COLOR, styles.CEIL__COLOR, styles.PRIMARY],
    // })
    // console.log('interpolateColors', animation.value)

    return (
        <View style={[UI.row, { zIndex }]}>
            {/* <Animated.View style={[UI.circle_style, { backgroundColor: progress === 0 ? bgColor : progress >= 1 ? styles.PRIMARY : styles.INPUT__BG }]} />
            <Animated.View style={[UI.circle_style, { backgroundColor: progress === 1 ? bgColor : progress >= 2 ? styles.PRIMARY : styles.INPUT__BG }]} />
            <Animated.View style={[UI.circle_style, { backgroundColor: progress === 2 ? bgColor : progress >= 3 ? styles.PRIMARY : styles.INPUT__BG }]} />
            <Animated.View style={[UI.circle_style, { backgroundColor: progress === 3 ? bgColor : progress >= 4 ? styles.PRIMARY : styles.INPUT__BG }]} /> */}

            <Animated.View style={[UI.circle_style, { backgroundColor: progress >= 1 ? styles.PRIMARY : styles.INPUT__BG }]} />
            <Animated.View style={[UI.circle_style, { backgroundColor: progress >= 2 ? styles.PRIMARY : styles.INPUT__BG }]} />
            <Animated.View style={[UI.circle_style, { backgroundColor: progress >= 3 ? styles.PRIMARY : styles.INPUT__BG }]} />
            <Animated.View style={[UI.circle_style, { backgroundColor: progress >= 4 ? styles.PRIMARY : styles.INPUT__BG }]} />
        </View>
    )
}
const UI = StyleSheet.create({
    circle_style: {
        alignSelf: 'center',
        borderRadius: 50,
        height: 8,
        marginHorizontal: 3,
        width: 8,
    },
    row: {
        alignItems: 'center',
        flexDirection: 'row',
        height: 32,
        justifyContent: 'center',
        marginBottom: 16,
        marginTop: -20,
        paddingHorizontal: dm.moderate(16),
    },
})
