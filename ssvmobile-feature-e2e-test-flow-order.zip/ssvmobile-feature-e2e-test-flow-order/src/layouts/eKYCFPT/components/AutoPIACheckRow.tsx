import React, { useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { StyleSheet, Switch, TouchableOpacity, View } from 'react-native'

import { Text } from '../../../basic-components'
import { StoreContext } from '../../../store'
import { dimensions as dm, fontSizes as fs, IconSvg } from '../../../styles'

interface IAutoPIACheckRowProps {
    checkAutoPIA: boolean
    setCheckAutoPIA: (isAutoPIA: boolean) => void
}

export const AutoPIACheckRow = ({ setCheckAutoPIA = () => null, checkAutoPIA }: IAutoPIACheckRowProps) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()

    const [isCheckAutoPIA, setIsCheckAutoPIA] = useState(checkAutoPIA || false)

    useEffect(() => {
        setCheckAutoPIA(isCheckAutoPIA)
    }, [isCheckAutoPIA])

    return (
        <View style={UI.row}>
            <TouchableOpacity
                activeOpacity={0.9}
                style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    marginTop: dm.vertical(16),
                    flex: 1,
                    justifyContent: 'space-between',
                }}
                onPress={() => setIsCheckAutoPIA((value) => !value)}
            >
                {/* <View style={{ paddingTop: 2 }}>
					<IconSvg.CheckboxIcon
						active={isCheckAutoPIA}
						colorActive={styles.PRIMARY}
						colorunActive={styles.PRIMARY__CONTENT__COLOR}
					/>
				</View> */}
                <Text
                    style={{
                        fontSize: fs.small,
                        color: styles.PRIMARY__CONTENT__COLOR,
                        marginLeft: dm.moderate(8),
                        marginRight: 16,
                    }}
                >
                    {t<string>('auto_pia')}
                </Text>
                <View>
                    <Switch value={isCheckAutoPIA} onChange={() => setIsCheckAutoPIA((value) => !value)} />
                </View>
            </TouchableOpacity>
        </View>
    )
}

const UI = StyleSheet.create({
    row: {
        alignItems: 'center',
        borderRadius: 12,
        flexDirection: 'row',
        marginHorizontal: dm.moderate(16),
    },
})
