import React, { useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { StyleSheet, TouchableOpacity, View } from 'react-native'
import Modal from 'react-native-modal'
import ToastGlobal from 'react-native-toast-message'
import ModalController from '@mts-components/appModal/modalControlller'
import { Container, Content } from 'native-base'

import { CustomFloatInput, Text } from '../../basic-components'
import HeaderComponent from '../../components/header'
import { ButtonCustom } from '../../components/trading-component'
import { StoreContext } from '../../store'
import { dimensions, dimensions as dm, fontSizes, fontSizes as fs, fontWeights as fw, IconSvg } from '../../styles'
import { glb_sv, reqFunct, Screens, sendRequest } from '../../utils'

const ServiceInfo = {
    QUERY_USER_INFORMATION: {
        reqFunct: reqFunct.QUERY_USER_INFORMATION,
        WorkerName: 'FOSqAccount01',
        ServiceName: 'FOSqAccount01_UpdateAccount_online',
        Operation: 'Q',
    },
    UPDATE_INFO_REQUEST: {
        reqFunct: reqFunct.UPDATE_INFO_REQUEST,
        WorkerName: 'FOSxAccount01',
        ServiceName: 'FOSxAccount01_UpdateAccount_online',
        Operation: 'U',
    },
}

const initErrCtrl = [
    {
        error: false,
        message: 'common_plz_input_full_name',
    },
    {
        error: false,
        message: 'common_plz_input_your_home_address',
    },
    {
        error: false,
        message: 'common_plz_input_your_email_address',
    },
    {
        error: false,
        message: 'common_plz_input_your_mobile_number',
    },
    {
        error: false,
        message: 'common_plz_input_your_birthday',
    },
]

const genderList = [
    { value: 'M', name: 'common_male' },
    { value: 'F', name: 'common_female' },
    { value: 'O', name: 'common_other' },
]

function UpdatePhoneEmailInfor({ navigation, route }) {
    const { userInfoData, updateInfoCallback } = route.params

    const { styles, theme, language } = useContext(StoreContext)
    const { t } = useTranslation()

    const [gender, setGender] = useState('') // Single code M,F,O
    const [changeInputName, setChangeInputName] = useState('')
    const [userInfo, setUserInfo] = useState({})
    const [accountName, setAccountName] = useState('')
    const [birthDay, setBirthDay] = useState('')
    const [address, setAddress] = useState()
    const [email, setEmail] = useState('')
    const [phone, setPhone] = useState('')

    const [modalBirthday, setModalBirthday] = useState(false)
    const [visibleGender, setVisibleGender] = useState(false)

    // const [otpMessage, setOtpMessage] = useState('')
    // const [timeOTP, setTimeOTP] = useState(30)
    // const [visibleModalAuthen, setVisibleModalAuthen] = useState(false)

    useEffect(() => {
        getUserInfo()

        return () => {
            // second
        }
    }, [])

    const getUserInfo = () => {
        const inputParams = [String(glb_sv.objShareGlb.userInfo?.c19).toLocaleUpperCase()]
        sendRequest(ServiceInfo.QUERY_USER_INFORMATION, inputParams, handleQueryUserInfoResult)
    }

    const handleQueryUserInfoResult = (reqInfoMap, message) => {
        // console.log('handleQueryUserInfoResult: ', reqInfoMap, message);
        if (Number(message.Result) === 0) {
            // navigation.navigate(Screens.ALERT_MODAL, {
            // icon: <IconSvg.ErrorIcon color={styles.PRIMARY} />,
            // title: t('common_notify'),
            // content: message.Message,
            // typeColor: styles.PRIMARY,
            // showCancel: false,
            //     linkCallback: () => navigation.goBack(),
            // })
            ModalController.showModal({
                icon: <IconSvg.ErrorIcon color={styles.PRIMARY} />,
                title: t('common_notify'),
                content: message.Message,
                typeColor: styles.PRIMARY,
                linkCallback: () => navigation.goBack(),
            })
        } else {
            let jsondata
            if (!message.Data) return
            try {
                jsondata = JSON.parse(message.Data)
            } catch (err) {
                console.log('handleQueryUserInfoResult -> err', err)
                return
            }
            if (Number(message.Packet) <= 0) {
                setUserInfo(jsondata[0])
                setAccountName(jsondata[0]?.c0)
                setBirthDay(jsondata[0]?.c1)
                setAddress(jsondata[0]?.c2)
                setEmail(jsondata[0]?.c3)
                setPhone(jsondata[0]?.c4)
            }
        }
    }

    const confirmBeforeRequest = (callbackFunc) => {
        setChangeInputName('')
        navigation.navigate(Screens.OTP_MODAL_WITHOUT_TYPE_OPTIONS, {
            smsOTP: true,
            otp_Type: Number(glb_sv.objShareGlb.userInfo.c6),
            functCallback: callbackFunc,
        })
    }

    const hideDatePicker = () => {
        setModalBirthday(false)
    }

    const onInfosUpdateConfirm = () => {
        console.log('onInfosUpdateConfirm')

        if (email?.trim() === '') {
            ToastGlobal.show({
                type: 'warning',
                text2: t('common_plz_input_your_email_address'),
            })
        } else if (phone?.trim() === '') {
            ToastGlobal.show({
                type: 'warning',
                text2: t('common_plz_input_your_mobile_number'),
            })
        } else {
            // setTimeOTP(0)
            sendUpdateInfosRequest('')
        }
    }

    const sendUpdateInfosRequest = (otp) => {
        const inputParams = [String(glb_sv.objShareGlb.AcntMain).toLocaleUpperCase(), phone, address, email]

        // console.log('sendUpdateInfosRequest inputParams: ', inputParams)
        sendRequest(ServiceInfo.UPDATE_INFO_REQUEST, inputParams, handleInfosUpdate)
    }

    // -----------------------------------------
    // const otpAuthenCallBack = (otpCode) => {
    //     console.log('otpAuthenCallBack otpCode: ', otpCode);
    //     sendUpdateInfosRequest(otpCode)
    // }

    // -----------------------------------------
    const handleInfosUpdate = (reqInfoMap, message) => {
        // console.log('handleInfosUpdate: ', reqInfoMap, message)
        const msgCode = message.Code
        if (Number(message.Result) === 0) {
            ToastGlobal.show({
                type: 'warning',
                text2: message.Message,
            })
        } else {
            ToastGlobal.show({
                type: 'success',
                text2: message.Message,
            })

            navigation.goBack()
            // updateInfoCallback(true)
        }
    }

    return (
        <Container>
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft={true}
                navigation={navigation}
                title={t('update_info')}
                titleAlgin="flex-start"
            />

            <Content keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false} style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
                {/* <RowData textLeft={t('customer_fullname')} textRight={userData.c0} /> */}

                <View style={{ paddingHorizontal: dm.moderate(16) }}>
                    <CustomFloatInput
                        editable={false}
                        label={t('customer_fullname')}
                        maxLength={50}
                        numberOfLines={1}
                        placeholderTextColor={styles.PLACEHODLER__COLOR}
                        staticLabel
                        value={accountName}
                        onChangeText={(value) => setAccountName(value)}
                    />
                </View>

                {/* <Pressable
                    disabled={true}
                    onPress={() => {
                        if (birthday === '') {
                            setBirthday(moment().subtract(20, 'year').format('YYYYMMDD'))
                        }
                        setModalBirthday(true)
                    }}>
                    <View style={{ paddingHorizontal: dm.moderate(16), paddingTop: dm.moderate(8) }} pointerEvents="none">
                        <CustomFloatInput
                            staticLabel
                            label={t('common_birthday')}
                            value={birthday === '' ? '' : moment(birthday).format('DD/MM/YYYY')}
                            editable={false}
                            placeholderTextColor={styles.PLACEHODLER__COLOR}
                        />
                    </View>
                </Pressable> */}

                {/* <Pressable
                    disabled={true}
                    onPress={() => {
                        setVisibleGender(true)
                        Keyboard.dismiss()
                    }}>
                    <View style={{ paddingHorizontal: dm.moderate(16), paddingTop: dm.moderate(8) }} pointerEvents="none">
                        <CustomFloatInput
                            staticLabel
                            label={t('gender')}
                            value={gender === 'M' ? t('common_male') : gender === 'F' ? t('common_female') : gender === 'O' ? t('common_other') : ''}
                            editable={false}
                            placeholderTextColor={styles.PLACEHODLER__COLOR}
                        />
                    </View>
                </Pressable> */}

                <View style={{ paddingHorizontal: dm.moderate(16), paddingTop: dm.moderate(8) }}>
                    <CustomFloatInput
                        editable={false}
                        label={t('contact_address')}
                        maxLength={100}
                        numberOfLines={1}
                        placeholderTextColor={styles.PLACEHODLER__COLOR}
                        staticLabel
                        value={address}
                        onChangeText={(value) => setAddress(value)}
                    />
                </View>

                <View style={{ paddingHorizontal: dm.moderate(16), paddingTop: dm.moderate(8) }}>
                    <CustomFloatInput
                        autoCapitalize="none"
                        disabled={changeInputName !== 'email'}
                        label={t('email')}
                        maxLength={50}
                        numberOfLines={1}
                        placeholderTextColor={styles.PLACEHODLER__COLOR}
                        readOnly={changeInputName !== 'email'}
                        value={email}
                        onChangeText={(value) => setEmail(value)}
                        onFocus={() => {
                            setPhone(userInfo.c4)
                            setChangeInputName('email')
                        }}
                    />
                </View>

                <View style={{ paddingHorizontal: dm.moderate(16), paddingTop: dm.moderate(8) }}>
                    <CustomFloatInput
                        disabled={changeInputName !== 'phone'}
                        keyboardType="number-pad"
                        label={t('phone')}
                        maxLength={10}
                        numberOfLines={1}
                        placeholderTextColor={styles.PLACEHODLER__COLOR}
                        readOnly={changeInputName !== 'phone'}
                        value={phone}
                        onChangeText={(value) => setPhone(value)}
                        onFocus={() => {
                            setEmail(userInfo.c3)
                            setChangeInputName('phone')
                        }}
                    />
                </View>

                <ButtonCustom
                    text={t('common_update')}
                    type="confirm"
                    onPress={() => {
                        // console.log('userInfoData', userInfoData, is_user_information_update)
                        confirmBeforeRequest(() => onInfosUpdateConfirm())
                    }}
                />
            </Content>

            {/* <DateTimePickerModal
                isVisible={modalBirthday}
                mode="date"
                onCancel={hideDatePicker}
                headerTextIOS=""
                cancelTextIOS={t('common_Cancel')}
                confirmTextIOS={t('common_Ok')}
                isDarkModeEnabled={theme.includes('DARK')}
                date={moment(birthday).toDate()}
                locale={language === 'VI' ? 'vi_VN' : 'en_US'}
                onConfirm={(value) => {
                    hideDatePicker()
                    setBirthday(value)
                }}
            /> */}

            {visibleGender ? (
                <Modal
                    isVisible={visibleGender}
                    style={UI.bottomModal}
                    useNativeDriver={true}
                    onBackButtonPress={() => setVisibleGender(false)}
                    onBackdropPress={() => setVisibleGender(false)}
                >
                    <View
                        style={{
                            backgroundColor: styles.PRIMARY__BG__COLOR,
                            padding: dimensions.moderate(24),
                            justifyContent: 'flex-start',
                            borderTopLeftRadius: 12,
                            borderTopRightRadius: 12,
                        }}
                    >
                        {genderList.map((item) => (
                            <TouchableOpacity
                                key={item.value}
                                style={UI.row}
                                onPress={() => {
                                    setGender(item.value)
                                    setVisibleGender(false)
                                }}
                            >
                                <IconSvg.CheckboxIcon
                                    active={gender === item.value}
                                    colorActive={styles.PRIMARY}
                                    colorunActive={styles.PRIMARY__CONTENT__COLOR}
                                />
                                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal, marginLeft: dimensions.moderate(12) }}>
                                    {t(item.name)}
                                </Text>
                            </TouchableOpacity>
                        ))}
                    </View>
                </Modal>
            ) : null}
        </Container>
    )
}

const UI = StyleSheet.create({
    ErrorBorder: {
        borderColor: '#EB5C55',
        borderWidth: 1,
    },
    ErrorStyle: {
        color: '#EB5C55',
        fontSize: fs.smallest,
        fontStyle: 'italic',
        fontWeight: fw.light,
    },
    GroupInput: {
        marginVertical: dm.halfVerticalIndent,
        paddingHorizontal: dm.halfIndent,
    },
    RowInput: {
        marginLeft: dm.moderate(8),
        marginVertical: dm.vertical(8),
    },
    bottomModal: {
        justifyContent: 'flex-end',
        margin: 0,
    },
    row: {
        borderRadius: 12,
        flexDirection: 'row',
        marginTop: dimensions.vertical(12),
    },
})

export default UpdatePhoneEmailInfor
