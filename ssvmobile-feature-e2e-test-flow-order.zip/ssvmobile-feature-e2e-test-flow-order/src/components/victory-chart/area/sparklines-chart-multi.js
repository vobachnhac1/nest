import React, { Component, memo, useEffect, useRef, useState } from 'react'
import { InteractionManager } from 'react-native'
import { Defs, LinearGradient, Stop } from 'react-native-svg'
import maxBy from 'lodash/maxBy'
import minBy from 'lodash/minBy'
import throttle from 'lodash/throttle'
import moment from 'moment'
import { VictoryArea, VictoryAxis, VictoryChart, VictoryLine } from 'victory-native'

import { eventList, glb_sv } from '../../../utils'

const initData = [
    {
        x: 1601370904,
        y: 1,
        y0: 0,
    },
    {
        x: 1601370964,
        y: 1,
        y0: 0,
    },
]

class SparklinesChartMulti extends Component {
    constructor(props) {
        super(props)
        this.state = {
            colorChart: '',
            refLineData: [],
            chartData: [],
        }
        this.dataIntraday = []
        this.handleUpdate = throttle(this.convert2chartVictory, 5000)
    }

    componentDidMount() {
        this.mounted = true
        this.eventMarket = glb_sv.eventMarket.subscribe((msg) => {
            //

            if (msg.type === eventList.GET_DATA_EP_CHART_DONE && msg.msgKey === this.props.stockCode) {
                const data = glb_sv.StockMarket[this.props.stockCode] ? glb_sv.StockMarket[this.props.stockCode].arrMinutes : []
                if (!data.length) return

                if (this.dataIntraday && this.dataIntraday.length < 300 && this.dataIntraday.length >= data.length) return

                this.dataIntraday = [...data]
                this.lastData = data[data.length - 1]
                if (glb_sv.StockMarket[this.props.stockCode].t260 === 0) return
                this.convert2chartVictory()
                return
            } else if (msg.type === eventList.REQ_AFTER_SUB_INFO) {
                if (msg.value.includes(this.props.stockCode) && !this.colorChart) {
                    this.convert2chartVictory()
                }
                return
            } else if (msg.type === eventList.MKT_INTRADAY && msg.S === this.props.stockCode) {
                if (this.lastData && this.lastData.T === msg.T) {
                    return
                }
                const value = {
                    ...msg,
                    time: moment(glb_sv.timeServer + '-' + msg.T, 'YYYYMMDD-HH:mm:ss').valueOf(),
                }
                this.lastData = { ...value }
                this.dataIntraday.push({
                    ...value,
                })
                InteractionManager.runAfterInteractions(() => {
                    this.handleUpdate()
                })
                return
            } else if (msg.type === eventList.RESET_DATA) {
                this.lastData = null
                this.dataIntraday = []
                this.convert2chartVictory([])
                return
            }
        })
        const data = glb_sv.StockMarket[this.props.stockCode] ? glb_sv.StockMarket[this.props.stockCode].arrMinutes : []
        if (data.length) {
            this.dataIntraday = [...data]
            this.lastData = data[data.length - 1]
            this.convert2chartVictory([...data])
        }
    }

    componentWillUnmount() {
        this.eventMarket.unsubscribe()
        this.mounted = false
    }

    getColorChart = (lastItem) => {
        if (!lastItem) return this.props.styles.REF__COLOR
        const glb_stock_data = glb_sv.StockMarket[this.props.stockCode]
        if (!glb_stock_data) return this.props.styles.REF__COLOR
        const { t31, t260 } = glb_sv.StockMarket[this.props.stockCode]
        this.colorChart = t260 ? glb_sv.getColor(t31, glb_stock_data, this.props.styles) : ''
        return this.colorChart || this.props.styles.REF__COLOR
    }

    convert2chartVictory = () => {
        'worklet'
        const arr = [...this.dataIntraday]
        const victoryDataChart = []
        let chartData = []
        let refLineData = []
        let colorChart = ''

        // set data cho chart
        const minValue =
            minBy(arr, function (o) {
                return o.C
            }) || {}
        const maxValue =
            maxBy(arr, function (o) {
                return o.C
            }) || {}

        let value_y0 = minValue.C - (maxValue.C - minValue.C) / 4
        if (minValue.C === maxValue.C) value_y0 = minValue.C * 0.95
        for (let index = 0; index < arr.length; index++) {
            victoryDataChart.push({
                x: arr[index].time,
                y: arr[index].C,
                y0: value_y0,
            })
        }
        // ----------------

        const { t260 = 0 } = glb_sv.StockMarket[this.props.stockCode] || {}
        // ----------------

        if (victoryDataChart.length <= 1) {
            if (victoryDataChart.length === 1) {
                chartData = [...victoryDataChart, { ...victoryDataChart[0], x: victoryDataChart[0].x + 1000 }]
                refLineData = [
                    { x: victoryDataChart[0].x, y: t260 },
                    { x: victoryDataChart[0].x + 1000, y: t260 },
                ]
                colorChart = this.getColorChart(arr[0])
            } else {
                chartData = [] // initData
                refLineData = []
            }
            if (this.mounted) {
                this.setState({
                    colorChart,
                    refLineData,
                    chartData,
                })
            }
            return
        } else {
            chartData = victoryDataChart
        }
        // set màu cho chart
        const lastItem = arr.pop()
        const firstItem = arr.shift()
        colorChart = this.getColorChart(lastItem)
        // set basic info cho chart

        const firstTime = firstItem.time
        const lastTime = lastItem.time

        refLineData = [
            { x: firstTime, y: t260 },
            { x: lastTime, y: t260 },
        ]
        if (this.mounted) {
            this.setState({
                colorChart,
                refLineData,
                chartData,
            })
        }
    }

    shouldComponentUpdate(nextProps, nextState) {
        if (nextProps.iDItemFav === glb_sv.activeList.c1) {
            return true
        } else {
            if (this.state.chartData.length === 0 && nextState.chartData.length) {
                return true
            }
            return false
        }
    }

    render() {
        // console.log('render SparklinesChartMulti', this.props.stockCode, this.props.iDItemFav)
        const { styles, height, width } = this.props
        const { colorChart, refLineData, chartData } = this.state
        return (
            <VictoryChart height={height || 40} padding={0} width={width || 85}>
                <VictoryAxis
                    style={{
                        axis: { stroke: 'transparent' },
                        ticks: { stroke: 'transparent' },
                        tickLabels: { fill: 'transparent' },
                    }}
                />
                <Defs>
                    <LinearGradient id="gradientStroke" x1="0%" x2="0%" y1="0%" y2="100%">
                        <Stop offset="0%" stopColor={colorChart || styles.REF__COLOR} stopOpacity="0.2" />
                        <Stop offset="100%" stopColor={colorChart || styles.REF__COLOR} stopOpacity="0" />
                    </LinearGradient>
                </Defs>

                <VictoryArea
                    data={chartData || []}
                    style={{
                        data: {
                            fill: 'url(#gradientStroke)',
                            stroke: `${colorChart || styles.REF__COLOR}`,
                            strokeWidth: 1,
                        },
                    }}
                />

                <VictoryLine
                    data={refLineData}
                    style={{
                        data: { stroke: styles.HEADER__CONTENT__COLOR, strokeWidth: 0.5, strokeDasharray: '3,5' },
                    }}
                />
            </VictoryChart>
        )
    }
}

export default memo(SparklinesChartMulti)
