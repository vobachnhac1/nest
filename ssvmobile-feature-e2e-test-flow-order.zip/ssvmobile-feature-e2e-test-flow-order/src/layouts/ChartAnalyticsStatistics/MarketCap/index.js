import React, { memo } from 'react'
import { StyleSheet, View } from 'react-native'

import { dimensions } from '../../../styles'
import WebviewMarketCap from './chart/webview'

const getKeyExchange = (value) => {
    if (value.includes('HNXUpcomIndex')) {
        return 'UPC'
    } else if (value.includes('HNX')) {
        return 'HNX'
    } else {
        return 'HSX'
    }
}

const MarketCap = ({ active, height }) => {
    const exchangeState = getKeyExchange(active)

    return (
        <View style={UI.view}>
            <WebviewMarketCap exchange={exchangeState} height={height} />
        </View>
    )
}

export default memo(MarketCap)

const UI = StyleSheet.create({
    view: {
        height: dimensions.IOS ? dimensions.HIEGHT - 230 : dimensions.HIEGHT - 170,
        width: dimensions.WIDTH,
    },
})
