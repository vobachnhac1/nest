import React, { memo, useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { ActivityIndicator, FlatList, InteractionManager, StyleSheet, TouchableOpacity } from 'react-native'
import Modal from 'react-native-modal'
import { useNavigation } from '@react-navigation/native'
import moment from 'moment'
import { Text, View } from 'native-base'

import { EmptyView, ModalBottomContent, ModalBottomRowSelect, RowTitleGroup, WarningOrInfo } from '../../../components/trading-component'
import ErrorView from '../../../components/trading-component/error-view'
import { allowCompanyRender, useCustomInteraction } from '../../../hoc'
import { StoreContext } from '../../../store'
import { StoreTrading } from '../../../store-trading'
import { dimensions, fontSizes, fontWeights } from '../../../styles'
import { eventList, FormatNumber, glb_sv, reqFunct, Screens, sendRequest } from '../../../utils'

const ServiceInfo = {
    GET_ASSETS_GUAR_INFO: {
        reqFunct: reqFunct.GET_ASSETS_GUAR_INFO,
        WorkerName: 'FOSqMargin',
        ServiceName: 'FOSqLendingMargin_Online_1450_2',
        Operation: 'Q',
        ClientSentTime: '0',
    },
    GET_CUR_MARG_CONT_LIST: {
        reqFunct: reqFunct.GET_CUR_MARG_CONT_LIST,
        WorkerName: 'FOSqMargin',
        ServiceName: 'FOSqMargin_1402_1',
        ClientSentTime: '0',
        Operation: 'Q',
        // InVal: ['OTSRPY', this.actn_curr, this.sub_curr, '6', '%', '0', 'z', '']
    },
}

const Debt = ({ isAllSubRef, isTimeout, setIsTimeout, refreshStockOwn, isLoading, setIsLoading, assetInfo }) => {
    useCustomInteraction()
    const { t } = useTranslation()
    const { userInfo } = useContext(StoreTrading)
    const navigation = useNavigation()

    const [data, setData] = useState({})
    const mounted = useRef(true)
    const { styles, theme } = useContext(StoreContext)
    const [isOpenActionSheet, setIsOpenActionSheet] = useState(false)
    const [selectContract, setSelectContract] = useState({})

    const [listCurMarginContract, setListCurMarginContract] = useState([])
    const [totalObject, setTotalObject] = useState({
        loan_expide_dt: 0,
        due_debt: 0,
        undue_debt: 0,
        interest: 0,
    })

    useEffect(() => {
        mounted.current = true
        getAssetsGuarInfo()
        getListCurrentMarginContractList()

        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.LOGIN_SUCCESS) {
                setIsLoading(true)
                getAssetsGuarInfo()
                getListCurrentMarginContractList()
            }
        })

        return () => {
            mounted.current = false
            commonEvent.unsubscribe()
        }
    }, [userInfo])

    const getAssetsGuarInfo = () => {
        const { actn_curr, sub_curr } = userInfo
        if (!actn_curr || !sub_curr) {
            // [broker] - Nếu không có tài khoản sub thì không gửi request
            return
        }
        setIsLoading(true)
        // ---------

        const InputParams = [actn_curr, isAllSubRef.current && userInfo.sub_list.length > 1 ? '%' : sub_curr]
        sendRequest(ServiceInfo.GET_ASSETS_GUAR_INFO, InputParams, getAssetsGuarInfoResult, true, getAssetsGuarInfoTimeout)
        setData({})
    }

    const getAssetsGuarInfoTimeout = () => {
        // setIsTimeout(true)
    }

    const getAssetsGuarInfoResult = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            return
        } else {
            try {
                const jsondata = message.Data ? JSON.parse(message.Data)[0] : {}
                InteractionManager.runAfterInteractions(() => {
                    setTimeout(() => {
                        setData(jsondata)
                        // console.log('data nợ', jsondata)
                        setIsLoading(false)
                    }, 0)
                })
            } catch (err) {
                console.log('getAssetsGuarInfoResult', err)
            }
        }
    }

    const getListCurrentMarginContractList = () => {
        const { actn_curr, sub_curr } = userInfo
        if (!actn_curr || !sub_curr) {
            // [broker] - Nếu không có tài khoản sub thì không gửi request
            return
        }
        // ---------
        const inputParams = [
            'OTSRPY',
            userInfo.actn_curr,
            isAllSubRef.current && userInfo.sub_list.length > 1 ? '%' : userInfo.sub_curr,
            '6',
            '%',
            '0',
            'z',
            '',
        ]
        sendRequest(ServiceInfo.GET_CUR_MARG_CONT_LIST, inputParams, handleGetListCurrentMarginContractList)
    }

    const handleGetListCurrentMarginContractList = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata
            try {
                jsondata = JSON.parse(message.Data)
            } catch (err) {
                // glb_sv.logMessage(err);
                jsondata = []
            }
            if (Number(message.Packet) <= 0) {
                setListCurMarginContract(jsondata)
                const loan_expide_dt = jsondata.reduce(function (a, b) {
                    return a + 0
                }, 0)
                const due_debt = jsondata.reduce(function (a, b) {
                    return a + 0
                }, 0)
                const undue_debt = jsondata.reduce(function (a, b) {
                    return a + 0
                }, 0)
                const interest = jsondata.reduce(function (a, b) {
                    return a + Number(b.c21)
                }, 0)
                setTotalObject({
                    loan_expide_dt,
                    due_debt,
                    undue_debt,
                    interest,
                })
            }
        }
    }

    const hideModal = () => {
        setIsOpenActionSheet(false)
    }
    const _openActionSheet = (item) => {
        setIsOpenActionSheet(true)
        setSelectContract(item)
    }

    const ViewList = ({ item }) => {
        return (
            <TouchableOpacity onPress={() => _openActionSheet(item)}>
                <View
                    style={{
                        display: 'flex',
                        flexDirection: 'row',
                        paddingVertical: dimensions.moderate(8),
                        borderBottomColor: styles.DIVIDER__COLOR,
                        borderBottomWidth: 1,
                    }}
                >
                    <View style={{ flex: 2 }}>
                        <View>
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.verySmall, textAlign: 'left' }}>
                                {moment(item.c1, 'DDMMYYYY').format('DD/MM/YYYY')}
                            </Text>
                            <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.verySmall, textAlign: 'left' }}>
                                {moment(item.c5, 'DDMMYYYY').format('DD/MM/YYYY')}
                            </Text>
                        </View>
                    </View>
                    <View style={{ justifyContent: 'center', alignItems: 'flex-end', flex: 2.6 }}>
                        <View>
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.verySmall, textAlign: 'right' }}>
                                {FormatNumber(item.c8)}
                            </Text>
                            <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.verySmall, textAlign: 'right' }}>
                                {FormatNumber(item.c9)}
                            </Text>
                        </View>
                    </View>
                    <View style={{ justifyContent: 'center', alignItems: 'flex-end', flex: 3 }}>
                        <View>
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.verySmall, textAlign: 'right' }}>{item.c19}</Text>
                        </View>
                    </View>
                </View>
            </TouchableOpacity>
        )
    }

    return (
        <>
            {isLoading ? (
                isTimeout ? (
                    <ErrorView
                        refresh={() => {
                            getAssetsGuarInfo()
                            getListCurrentMarginContractList()
                            // refreshStockOwn()
                        }}
                    />
                ) : (
                    <View style={{ paddingVertical: dimensions.moderate(50) }}>
                        <ActivityIndicator color="#494949" size={30} />
                    </View>
                )
            ) : (
                <View style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
                    <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                        <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('pia_loan_current')}</Text>
                        <Text
                            style={{
                                color: styles.PRIMARY__CONTENT__COLOR,
                                fontSize: fontSizes.small,
                                fontWeight: fontWeights.bold,
                                flex: 1,
                                textAlign: 'right',
                            }}
                        >
                            {FormatNumber(data.c0)}
                        </Text>
                    </View>

                    <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                        <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('pia_loan_fee')}</Text>
                        <Text
                            style={{
                                color: styles.PRIMARY__CONTENT__COLOR,
                                fontSize: fontSizes.small,
                                fontWeight: fontWeights.bold,
                                flex: 1,
                                textAlign: 'right',
                            }}
                        >
                            {FormatNumber(data.c1)}
                        </Text>
                    </View>

                    <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                        <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('margin_debt')}</Text>
                        <Text
                            style={{
                                color: styles.PRIMARY__CONTENT__COLOR,
                                fontSize: fontSizes.small,
                                fontWeight: fontWeights.bold,
                                flex: 1,
                                textAlign: 'right',
                            }}
                        >
                            {FormatNumber(data.c2)}
                        </Text>
                    </View>

                    <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                        <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('margin_debt_fee')}</Text>
                        <Text
                            style={{
                                color: styles.PRIMARY__CONTENT__COLOR,
                                fontSize: fontSizes.small,
                                fontWeight: fontWeights.bold,
                                flex: 1,
                                textAlign: 'right',
                            }}
                        >
                            {FormatNumber(data.c3)}
                        </Text>
                    </View>

                    <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                        <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('temporary_loan')}</Text>
                        <Text
                            style={{
                                color: styles.PRIMARY__CONTENT__COLOR,
                                fontSize: fontSizes.small,
                                fontWeight: fontWeights.bold,
                                flex: 1,
                                textAlign: 'right',
                            }}
                        >
                            {FormatNumber(data.c4)}
                        </Text>
                    </View>

                    {glb_sv.activeCode === '081' ? null : (
                        <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                            <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('loan_expide_dt')}</Text>
                            <Text
                                style={{
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                    fontSize: fontSizes.small,
                                    fontWeight: fontWeights.bold,
                                    flex: 1,
                                    textAlign: 'right',
                                }}
                            >
                                {FormatNumber(data.c5)}
                            </Text>
                        </View>
                    )}

                    {/* VCS: Thêm trường hiển thị Nợ Phí Lưu ký */}
                    {allowCompanyRender(['888']) ? (
                        <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                            <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('depository_fee_debt')}</Text>
                            <Text
                                style={{
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                    fontSize: fontSizes.small,
                                    fontWeight: fontWeights.bold,
                                    flex: 1,
                                    textAlign: 'right',
                                }}
                            >
                                {FormatNumber(data.c12)}
                            </Text>
                        </View>
                    ) : null}
                    <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                        <View style={{ flexDirection: 'row', flex: 0.5 }}>
                            <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('total_current_loand')}</Text>
                            {/* <Text style={{ marginLeft: dimensions.moderate(5) }}>
                    <Info fill={styles.SECOND__CONTENT__COLOR} />
                </Text> */}
                        </View>
                        <Text
                            style={{
                                color: styles.PRIMARY__CONTENT__COLOR,
                                fontSize: fontSizes.small,
                                fontWeight: fontWeights.bold,
                                flex: 1,
                                textAlign: 'right',
                            }}
                        >
                            {FormatNumber(data.c6)}
                        </Text>
                    </View>

                    <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                        <View style={{ flexDirection: 'row', flex: 0.15 }}>
                            <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('CMR')}</Text>
                            {/* <Text style={{ marginLeft: dimensions.moderate(5) }}>
                    <Info fill={styles.SECOND__CONTENT__COLOR} />
                </Text> */}
                        </View>
                        <Text
                            style={{
                                color: styles.PRIMARY__CONTENT__COLOR,
                                fontSize: fontSizes.small,
                                fontWeight: fontWeights.bold,
                                flex: 1,
                                textAlign: 'right',
                            }}
                        >
                            {allowCompanyRender(['082'])
                                ? isNaN(data.c7)
                                    ? data.c7
                                    : FormatNumber(data.c7, 2, 0) + ' %'
                                : isNaN(data.c8)
                                ? data.c8
                                : FormatNumber(data.c8, 2, 0) + ' %'}
                        </Text>
                    </View>

                    <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                        <View style={{ flexDirection: 'row', flex: 1 }}>
                            <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('margin_EE')}</Text>
                            {/* <Text style={{ marginLeft: dimensions.moderate(5) }}>
                    <Info fill={styles.SECOND__CONTENT__COLOR} />
                </Text> */}
                        </View>

                        <Text
                            style={{
                                color: styles.PRIMARY__CONTENT__COLOR,
                                fontSize: fontSizes.small,
                                fontWeight: fontWeights.bold,
                                flex: 1,
                                textAlign: 'right',
                            }}
                        >
                            {FormatNumber(data.c11)}
                        </Text>
                    </View>

                    <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                        <View style={{ flexDirection: 'row', flex: 1 }}>
                            <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('adding_amount')}</Text>
                            {/* <Text style={{ marginLeft: dimensions.moderate(5) }}>
                    <Info fill={styles.SECOND__CONTENT__COLOR} />
                </Text> */}
                        </View>

                        <Text
                            style={{
                                color: styles.PRIMARY__CONTENT__COLOR,
                                fontSize: fontSizes.small,
                                fontWeight: fontWeights.bold,
                                flex: 1,
                                textAlign: 'right',
                            }}
                        >
                            {FormatNumber(data.c9)}
                        </Text>
                    </View>

                    <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                        <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('remain_margin_amount')}</Text>
                        <Text
                            style={{
                                color: styles.PRIMARY__CONTENT__COLOR,
                                fontSize: fontSizes.small,
                                fontWeight: fontWeights.bold,
                                flex: 1,
                                textAlign: 'right',
                            }}
                        >
                            {isNaN(data.c10) ? data.c10 : FormatNumber(data.c10)}
                        </Text>
                    </View>
                    {/* <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                        <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('total_unsecured_loan')}</Text>
                        <Text
                            style={{
                                color: styles.PRIMARY__CONTENT__COLOR,
                                fontSize: fontSizes.small,
                                fontWeight: fontWeights.bold,
                                flex: 1,
                                textAlign: 'right',
                            }}>
                            {FormatNumber(Number(assetInfo.c12) + Number(assetInfo.c13))}
                        </Text>
                    </View>
                    <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                        <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('total_pledge_loan')}</Text>
                        <Text
                            style={{
                                color: styles.PRIMARY__CONTENT__COLOR,
                                fontSize: fontSizes.small,
                                fontWeight: fontWeights.bold,
                                flex: 1,
                                textAlign: 'right',
                            }}>
                            {FormatNumber(Number(assetInfo.c14) + Number(assetInfo.c15))}
                        </Text>
                    </View> */}
                    <RowTitleGroup hasDivider text={t('list_debt')} type="group" />
                    <WarningOrInfo text={t('warn_press_to_repay_or_extend_margin')} />

                    <View style={{ flexDirection: 'row', paddingHorizontal: dimensions.moderate(8) }}>
                        <View style={{ flex: 3 }}>
                            <Text
                                style={{
                                    fontWeight: fontWeights.bold,
                                    fontSize: fontSizes.verySmall,
                                    textAlign: 'left',
                                    color: styles.HEADER__CONTENT__COLOR,
                                    flex: 1.2,
                                }}
                            >
                                {t('loan_date')}
                            </Text>
                            <Text
                                style={{
                                    fontWeight: fontWeights.bold,
                                    fontSize: fontSizes.verySmall,
                                    textAlign: 'left',
                                    color: styles.HEADER__CONTENT__COLOR,
                                }}
                            >
                                {t('date_due')}
                            </Text>
                        </View>
                        <View style={{ flex: 3 }}>
                            <Text
                                style={{
                                    fontWeight: fontWeights.bold,
                                    fontSize: fontSizes.verySmall,
                                    textAlign: 'right',
                                    color: styles.HEADER__CONTENT__COLOR,
                                }}
                            >
                                {t('loan_amount')}
                            </Text>
                            <Text
                                style={{
                                    fontWeight: fontWeights.bold,
                                    fontSize: fontSizes.verySmall,
                                    textAlign: 'right',
                                    color: styles.HEADER__CONTENT__COLOR,
                                }}
                            >
                                {t('loan_current')}
                            </Text>
                        </View>

                        <View style={{ flex: 4 }}>
                            <Text
                                style={{
                                    fontWeight: fontWeights.bold,
                                    fontSize: fontSizes.verySmall,
                                    textAlign: 'right',
                                    color: styles.HEADER__CONTENT__COLOR,
                                }}
                            >
                                {t('state_handle')}
                            </Text>
                        </View>
                    </View>
                    <FlatList
                        data={listCurMarginContract}
                        keyExtractor={(item, index) => String(index)}
                        ListEmptyComponent={EmptyView}
                        renderItem={ViewList}
                        style={{ marginBottom: dimensions.vertical(32), paddingHorizontal: dimensions.moderate(8) }}
                    />
                </View>
            )}
            {isOpenActionSheet && (
                <Modal
                    hideModalContentWhileAnimating={true}
                    isVisible={isOpenActionSheet}
                    style={UI.bottomModal}
                    useNativeDriver={true}
                    onBackButtonPress={hideModal}
                    onBackdropPress={hideModal}
                >
                    <ModalBottomContent title={t('margin_contract_detail')}>
                        <ModalBottomRowSelect
                            text={t('sb_exten_ctrmargin')}
                            onPress={() => {
                                hideModal()
                                navigation.navigate(Screens.RENEW_MARGIN_CONTRACT, {
                                    data: selectContract,
                                    // onRefresh: onRefresh,
                                })
                            }}
                        />
                        <ModalBottomRowSelect
                            text={t('sb_margin_repay')}
                            onPress={() => {
                                hideModal()
                                navigation.navigate(Screens.DETAIL_MARGIN_REFUND, {
                                    data: selectContract,
                                    // onRefresh: onRefresh,
                                })
                            }}
                        />
                    </ModalBottomContent>
                </Modal>
            )}
        </>
    )
}

const UI = StyleSheet.create({
    bottomModal: {
        justifyContent: 'flex-end',
        margin: 0,
    },
    row: {
        borderBottomWidth: 1,
        flexDirection: 'row',
        marginHorizontal: dimensions.moderate(16),
        paddingVertical: dimensions.vertical(9),
    },
})

export default memo(Debt)
