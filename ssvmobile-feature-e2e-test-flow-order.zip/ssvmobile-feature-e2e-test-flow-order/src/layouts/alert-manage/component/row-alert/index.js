import React, { useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { StyleSheet } from 'react-native'
import AntDesign from 'react-native-vector-icons/AntDesign'
import moment from 'moment'
import { Col, Row, View } from 'native-base'

import { Text } from '../../../../basic-components'
import { StoreContext } from '../../../../store'
import { dimensions as dm, fontSizes as fs, fontWeights as fw } from '../../../../styles'
import { glb_sv } from '../../../../utils'

const AlertRowView = ({
    onPress = () => {},
    alertName, // Nội dung header
    alertNote,
    item,
    iconRight = null, // Right Component
    type = 'buy', // type của header
    onDeleteAlert = () => null,
    onStopAlert = () => null,
    onReopenAlert = () => null,
    ...props
}) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()

    //-------
    const translateKeyStatus = (key) => {
        if (key === '1') return t('running')
        if (key === '2') return t('notice_sent')
        if (key === '3') return t('expired')
        if (key === '4') return t('stop')
        if (key === '9') return t('err')
        return ''
    }
    const getColorStatus = (key) => {
        if (key === '1') return styles.UP__COLOR
        if (key === '2') return styles.UP__COLOR
        if (key === '3') return styles.DOWN__COLOR
        if (key === '4') return styles.REF__COLOR
        if (key === '9') return styles.DOWN__COLOR
        return styles.REF__COLOR
    }

    const getActivePeriod = (timeExpired) => {
        const now = moment(glb_sv.objShareGlb.workDate)
        const end = moment(timeExpired).format('YYYYYYMMDD')
        const days = -now.diff(end, 'days') > 0 ? -now.diff(end, 'days') : 0
        return days
    }

    return (
        <Row style={[UI.AlertRowView, { backgroundColor: styles.INPUT__BG }]} onPress={onPress}>
            <Col size={20}>
                <View style={{ flexDirection: 'row' }}>
                    <Text numberOfLines={1} style={{ fontWeight: fw.bold, fontSize: fs.normal, color: styles.PRIMARY__CONTENT__COLOR }}>
                        {alertName}{' '}
                    </Text>
                    <View style={{ paddingHorizontal: 8, marginLeft: 0, backgroundColor: getColorStatus(item.c11), borderRadius: 8 }}>
                        <Text style={{ color: '#fff' }}>{translateKeyStatus(item.c11)}</Text>
                    </View>
                    <View style={{ paddingHorizontal: 8, marginLeft: 0, borderRadius: 8 }}>
                        <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontStyle: 'italic' }}>
                            {getActivePeriod(item.c10)} {t('days_remaining')}
                        </Text>
                    </View>
                </View>
                <Text style={{ fontSize: fs.small, color: styles.SECOND__CONTENT__COLOR }}>{alertNote}</Text>
            </Col>
            <Col size={4} style={UI.WrapIcon}>
                <View>
                    {item.c11 === '1' ? (
                        <AntDesign AntDesign color={styles.PLACEHODLER__COLOR} name="pausecircle" size={24} style={UI.Icon} onPress={onStopAlert} />
                    ) : null}
                    {item.c11 === '4' ? (
                        <AntDesign AntDesign color={styles.PLACEHODLER__COLOR} name="playcircleo" size={24} style={UI.Icon} onPress={onReopenAlert} />
                    ) : null}
                </View>
                <View>
                    <AntDesign AntDesign color={styles.PLACEHODLER__COLOR} name="delete" size={24} style={UI.Icon} onPress={onDeleteAlert} />
                </View>
            </Col>
        </Row>
    )
}

export default AlertRowView

const UI = StyleSheet.create({
    AlertRowView: {
        borderRadius: 8,
        marginHorizontal: dm.moderate(16),
        marginVertical: dm.moderate(4),
        paddingVertical: dm.moderate(4),
    },
    Icon: { paddingLeft: 12, paddingRight: 4, paddingVertical: 8 },
    WrapIcon: { alignItems: 'flex-end', flexDirection: 'row', justifyContent: 'center', paddingLeft: 8 },
})
