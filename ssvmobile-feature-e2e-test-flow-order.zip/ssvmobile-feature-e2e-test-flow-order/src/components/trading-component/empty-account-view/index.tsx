import React, { memo, useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { GestureResponderEvent, Image, Text, TouchableOpacity, View } from 'react-native'

import GREEN_WARNING_PNG from '../../../assets/images/common/ic_green_warning.png'
import { StoreContext } from '../../../store'
import { dimensions, fontSizes } from '../../../styles'

const EmptyAccountView = ({ refresh }: { refresh: (event: GestureResponderEvent) => void }) => {
    const { t } = useTranslation()
    const { styles } = useContext(StoreContext)

    return (
        <TouchableOpacity style={{ paddingVertical: dimensions.moderate(40), display: 'flex', alignItems: 'center' }} onPress={refresh}>
            <Image source={GREEN_WARNING_PNG} style={{ width: 65, height: 65 }} />
            <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small }}>{t<string>('account_in_advance')}</Text>
        </TouchableOpacity>
    )
}

export default memo(EmptyAccountView)
