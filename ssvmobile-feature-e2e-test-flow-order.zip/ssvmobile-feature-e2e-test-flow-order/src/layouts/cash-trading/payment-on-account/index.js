import React, { useContext, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { InteractionManager, Keyboard, RefreshControl, StyleSheet, View } from 'react-native'
import Modal from 'react-native-modal'
import StepIndicator from 'react-native-step-indicator'
import Svg, { Circle, ClipPath, Defs, G, Path } from 'react-native-svg'
import ToastGlobal from 'react-native-toast-message'
import { Container, Content, Tab, Tabs } from 'native-base'

import HeaderComponent from '../../../components/header'
import ModalLoading from '../../../components/modal-loading'
import { ButtonCustom, ModalContent, RowDataModal } from '../../../components/trading-component'
import { useAlertModal, useAlertModalCommonCode, useModalOtpWhenErr } from '../../../hoc'
import { StoreContext } from '../../../store'
import { StoreTrading } from '../../../store-trading'
import { dimensions as dm } from '../../../styles'
import { FormatNumber, glb_sv, reqFunct, sendRequest, wait } from '../../../utils'
import StepOne from './step-one'
import StepTwo from './step-two'

// Khai báo ServiceInfo (nếu có)
const ServiceInfo = {
    ADD_NEW_TRAN_MONEY_NOTIFY: {
        reqFunct: reqFunct.ADD_NEW_TRAN_MONEY_NOTIFY, // Thêm giao dịch thông báo nộp tiền
        WorkerName: 'FOSxCash',
        ServiceName: 'FOSxCash_0201_1',
        Operation: 'I',
    },
}
const initErrCtrl = [
    {
        error: false,
        message: 'select_bank_from',
    },
    {
        error: false,
        message: 'transfer_bank_account_must_input',
    },
    {
        error: false,
        message: 'receive_bank_account_must_input',
    },
    {
        error: false,
        message: 'warning_heir_bank_input',
    },
    {
        error: false,
        message: 'bank_transaction_amount_must_bigger_zero',
    },
]
// Khai báo component
const PaymentOnAccountLayout = ({ navigation }) => {
    const { styles } = useContext(StoreContext)
    const { userInfo } = useContext(StoreTrading)
    const { t } = useTranslation()
    // All orther state
    const [activeStep, setActiveStep] = useState(0)
    const [isOpenModal, setIsOpenModal] = useState(false)
    const [refreshing, setRefreshing] = React.useState(false)
    const [errCtrl, setErrCtrl] = useState(initErrCtrl)
    // Start define all bussiness state
    const [currentSubCash, setCurrentSubCash] = useState({})
    const [bankTransfer, setBankTransfer] = useState({})
    const [bankTransferAct, setBankTransferAct] = useState('')
    const [actReceive, setActReceive] = useState({})
    const [bankReceive, setBankReceive] = useState({})
    const [amoutTransfer, setAmoutTransfer] = useState('')

    const [loadingConfirm, setLoadingConfirm] = useState(false)

    // End define form bussiness state
    // -------------------------------------------   Dùng useEffect get các dữ liệu cần thiết còn thiếu
    // -------------------------------------------   Viết các hàm để set lại bussiness form state. Nên viết đúng một chuẩn duy nhất để dễ control
    const onRefresh = React.useCallback(() => {
        setRefreshing(true)
        wait(300).then(() => setRefreshing(false))
    }, [])

    const switchStep = {
        goTo: (step) => setActiveStep(step),
        next: () => setActiveStep(activeStep + 1),
        prev: () => setActiveStep(activeStep - 1),
        submit: () => {
            const isAuthenOTP = glb_sv.checkOtp(navigation, () => {
                setTimeout(() => {
                    setIsOpenModal((prev) => true)
                }, 100)
            })
            if (isAuthenOTP) {
                confirmTranferCash()
            }
        },
        onFinish: () => _checkValueBfSend(),
        getCurrent: () => {
            return activeStep
        },
    }

    const hideModal = () => {
        setIsOpenModal(false)
    }
    const _resetInput = () => {
        onRefresh()
        Keyboard.dismiss()
        setBankTransfer({})
        setBankTransferAct('')
        setActReceive({})
        setBankReceive({})
        setAmoutTransfer('')
        switchStep.goTo(0)
    }
    const _onClickBackButton = () => {
        if (activeStep > 0) switchStep.prev()
        if (activeStep === 0) navigation.goBack()
    }

    const _validateValue = (inputIndex) => {
        const newErrCtrl = [...initErrCtrl]

        newErrCtrl[0].message = t(initErrCtrl[0].message)
        newErrCtrl[1].message = t(initErrCtrl[1].message)
        newErrCtrl[2].message = t(initErrCtrl[2].message)
        newErrCtrl[3].message = t(initErrCtrl[3].message)
        newErrCtrl[4].message = t(initErrCtrl[4].message)

        console.log('inputIndex', inputIndex, bankTransfer)

        if (inputIndex === 0) newErrCtrl[0].error = !bankTransfer?.value?.c0
        if (inputIndex === 2) newErrCtrl[2].error = !bankReceive?.value?.c2
        if (inputIndex === 3) newErrCtrl[3].error = !bankReceive?.value?.c0
        if (inputIndex === 4) newErrCtrl[4].error = Number(amoutTransfer) <= 0 || !amoutTransfer
        if (!inputIndex && inputIndex !== 0) {
            newErrCtrl[0].error = !bankTransfer?.value?.c0
            newErrCtrl[2].error = !bankReceive?.value?.c2
            newErrCtrl[3].error = !bankReceive?.value?.c0
            newErrCtrl[4].error = Number(amoutTransfer) <= 0
        }
        setErrCtrl(newErrCtrl)
    }

    const _checkValueBfSend = () => {
        hideModal()
        _validateValue()
        if (errCtrl.filter((item) => item.error === true).length === 0) {
            setIsOpenModal(true)
        }
        return
    }

    // -------------------------------------------   Khai báo các hàm gửi (request) lên server
    const confirmTranferCash = () => {
        setIsOpenModal(false)

        InteractionManager.runAfterInteractions(() => {
            if (!glb_sv.checkOtp(navigation, confirmTranferCash)) return
            const inputParams = [
                userInfo.actn_curr,
                userInfo.sub_curr,
                '2',
                bankReceive?.value?.c2 || '', // Bank recieve account no
                bankReceive?.value?.c0 || '', // Ngân hàng nhận
                bankTransferAct, // Tài khoản chuyển
                bankTransfer?.value?.c0 || '', // Ngân hàng chuyển
                String(amoutTransfer), // Số tiền chuyển
                '', // Ghi chú
            ]
            // svInputPrm.InVal = [this.actn_curr, this.sub_curr, '2', rcvBankacnt, rcvBnk, trnBnkacnt, trnBnk, deposit_amt + '', noteInfo];
            sendRequest(ServiceInfo.ADD_NEW_TRAN_MONEY_NOTIFY, inputParams, handleConfirmTranferCash)
            setLoadingConfirm(true)
        })
    }

    // -------------------------------------------   Khai báo các hàm gửi (request) và nhận (handle respone) dữ liệu từ server
    const handleConfirmTranferCash = (reqInfoMap, message) => {
        setLoadingConfirm(false)
        // -- process after get result --
        if (Number(message.Result) === 0) {
            const { hasAlertCommonCode } = useAlertModalCommonCode(message, {})
            const { hasAlertErrOtp } = useModalOtpWhenErr(message, { continueVerify: !hasAlertCommonCode, callback: () => setIsOpenModal((prev) => true) })
            useAlertModal(message, { continueVerify: !hasAlertErrOtp })
        } else {
            _resetInput()

            ToastGlobal.show({
                type: 'success',
                text2: message.Message, //t('pass_confirm_not_correct'),
            })
        }
    }

    const renderStepIndicator = (params) => {
        if (params.position === 0) {
            return (
                <View>
                    <Svg fill="none" height={30} viewBox="0 0 30 30" width={30} xmlns="http://www.w3.org/2000/svg">
                        <Circle cx={15} cy={15} fill={params.position <= switchStep.getCurrent() ? '#60B44A' : '#D1D5DB'} r={15} />
                        <Path
                            d="M15 21.916l1.469-.339-1.13-1.13-.34 1.47zM14.71 20.949l.243-1.053.002-.008a.493.493 0 01.004-.013l.004-.012a.176.176 0 01.015-.032.27.27 0 01.008-.013l.005-.008a.21.21 0 01.015-.02l.01-.01.004-.005 3.275-3.275c-.914-1.88-2.605-3-4.545-3-1.423 0-2.737.609-3.7 1.714C9.078 16.328 8.531 17.88 8.5 19.6c.574.289 2.93 1.401 5.249 1.401.32 0 .641-.018.96-.051zM15.548 19.951l3.889-3.888 1.414 1.414-3.889 3.888-1.414-1.414zM13.75 13a2.5 2.5 0 100-5 2.5 2.5 0 000 5zM21.5 16.416a1 1 0 00-1.707-.707l1.414 1.414a.994.994 0 00.293-.707z"
                            fill="#fff"
                        />
                    </Svg>
                </View>
            )
        }
        if (params.position === 1) {
            return (
                <View>
                    <Svg fill="none" height={30} viewBox="0 0 30 30" width={30} xmlns="http://www.w3.org/2000/svg">
                        <Circle cx={15} cy={15} fill={params.position <= switchStep.getCurrent() ? '#60B44A' : '#D1D5DB'} opacity={1} r={15} />
                        <Path
                            d="M15 8.5A6.507 6.507 0 008.5 15c0 3.584 2.916 6.5 6.5 6.5s6.5-2.916 6.5-6.5-2.916-6.5-6.5-6.5zm-1.188 9.762l-2.518-2.8.743-.668 1.75 1.944 4.15-4.942.767.642-4.892 5.824z"
                            fill={'#fff'}
                            // opacity={0.1}
                        />
                    </Svg>
                </View>
            )
        }
    }

    return (
        <Container>
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft
                leftButtonLink={_onClickBackButton}
                navigation={navigation}
                title={t('title_add_money')}
                titleAlgin="flex-start"
                transparent
            />
            <Content
                refreshControl={
                    <RefreshControl
                        refreshing={refreshing}
                        onRefresh={onRefresh} // title={t('pull_refresh')}
                        // titleColor={styles.PRIMARY__CONTENT__COLOR}
                        tintColor={styles.PRIMARY__CONTENT__COLOR}
                    />
                }
                style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}
            >
                <View style={UI.stepIndicator}>
                    <StepIndicator
                        currentPosition={activeStep}
                        customStyles={secondIndicatorStyles}
                        labels={[t('choose_account'), t('trading_confirm')]}
                        renderStepIndicator={renderStepIndicator}
                        stepCount={2}
                    />
                </View>
                <Tabs locked page={activeStep} renderTabBar={() => <View />} style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
                    <Tab heading={<View />} style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
                        <StepOne
                            currentSubCash={currentSubCash}
                            navigation={navigation}
                            refreshing={refreshing}
                            setActReceive={setActReceive}
                            setAmoutTransfer={setAmoutTransfer}
                            setBankReceive={setBankReceive}
                            setBankTransfer={setBankTransfer}
                            setBankTransferAct={setBankTransferAct}
                            setCurrentSubCash={setCurrentSubCash}
                            setRefreshing={setRefreshing}
                            switchStep={switchStep}
                            onRefresh={onRefresh}
                        />
                    </Tab>
                    <Tab heading={<View />} style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
                        <StepTwo
                            _validateValue={_validateValue}
                            actReceive={actReceive}
                            amoutTransfer={amoutTransfer}
                            bankReceive={bankReceive}
                            bankTransfer={bankTransfer}
                            bankTransferAct={bankTransferAct}
                            errCtrl={errCtrl}
                            navigation={navigation}
                            refreshing={refreshing}
                            setActReceive={setActReceive}
                            setAmoutTransfer={setAmoutTransfer}
                            setBankReceive={setBankReceive}
                            setBankTransfer={setBankTransfer}
                            setBankTransferAct={setBankTransferAct}
                            setErrCtrl={setErrCtrl}
                            setRefreshing={setRefreshing}
                            switchStep={switchStep}
                        />
                    </Tab>
                </Tabs>
            </Content>
            {/* **************************************** Modal submit ******************************************/}
            {isOpenModal && (
                <Modal isVisible={isOpenModal} useNativeDriver={true} onBackButtonPress={hideModal} onBackdropPress={hideModal}>
                    <ModalContent
                        iconComponent={
                            <Svg fill="none" height={32} viewBox="0 0 33 32" width={33} xmlns="http://www.w3.org/2000/svg">
                                <G clipPath="url(#prefix__clip0)" fill="#2ECC71">
                                    <Path d="M5.754 23.077V0H4.217A4.111 4.111 0 00.11 4.106v20.275a5.343 5.343 0 013.501-1.304h2.143zM24.93 15.934c.201 0 .402.008.6.021V0H7.625v23.077h8.547c.834-4.07 4.444-7.143 8.758-7.143zM13.305 5.511h6.264v1.871h-6.264V5.511zM11.19 9.574h10.496v1.871H11.189V9.574zM17.213 29.381H4.853V27.51h11.534a8.906 8.906 0 01-.396-2.62H3.61a3.56 3.56 0 00-3.555 3.556A3.56 3.56 0 003.611 32H19.54a9.007 9.007 0 01-2.327-2.62z" />
                                    <Path d="M24.93 17.746a7.135 7.135 0 00-7.127 7.127c0 3.93 3.197 7.126 7.127 7.126 3.93 0 7.126-3.197 7.126-7.126a7.135 7.135 0 00-7.126-7.127zm-.001 2.86c.526 0 .915.43.937.938.023.506-.447.937-.937.937-.526 0-.915-.43-.938-.937-.022-.507.448-.938.938-.938zm.94 7.92h-1.875v-4.8h1.875v4.8z" />
                                </G>
                                <Defs>
                                    <ClipPath id="prefix__clip0">
                                        <Path d="M0 0h32v32H0z" fill="#fff" transform="translate(.056)" />
                                    </ClipPath>
                                </Defs>
                            </Svg>
                        }
                        title={t('confirm_send_deposite_inform')}
                        type="confirm"
                    >
                        <RowDataModal dataSub={[userInfo.actn_curr, userInfo.sub_curr]} textLeft={t('acnt_no')} textRight={userInfo.actn_curr} />
                        <RowDataModal textLeft={t('trans_sub_account')} textRight={bankTransfer?.label} />
                        {bankTransferAct.length > 0 && <RowDataModal textLeft={t('trans_numb_account')} textRight={bankTransferAct} />}
                        <RowDataModal textLeft={t('receive_sub_account')} textRight={actReceive?.value?.c2} />
                        <RowDataModal last textLeft={t('transfer_amount')} textRight={FormatNumber(amoutTransfer)} />
                        <ButtonCustom text={t('common_button_confirm')} type="confirm" onPress={switchStep.submit} />
                        <ButtonCustom last text={t('common_Cancel')} type="back" onPress={hideModal} />
                    </ModalContent>
                </Modal>
            )}
            {loadingConfirm && <ModalLoading content={t('common_processing')} visible={loadingConfirm} />}
        </Container>
    )
}

export default PaymentOnAccountLayout

const UI = StyleSheet.create({
    Button: {
        alignItems: 'center',
        borderRadius: 8,
        height: dm.moderate(28),
        justifyContent: 'center',
        width: dm.moderate(28),
    },
    Row_Modal: {
        height: dm.vertical(24),
        marginVertical: dm.vertical(16),
    },
    page: {
        flex: 1,
        flexDirection: 'column',
    },
    stepIndicator: {
        marginBottom: dm.vertical(8),
        marginTop: dm.vertical(0),
    },
})

const secondIndicatorStyles = {
    stepIndicatorSize: 32,
    currentStepIndicatorSize: 32,
    separatorStrokeWidth: 3,
    currentStepStrokeWidth: 4,
    stepStrokeCurrentColor: '#60B44A',
    stepStrokeWidth: 2,
    separatorStrokeFinishedWidth: 4,
    stepStrokeFinishedColor: '#60B44A',
    stepStrokeUnFinishedColor: '#aaaaaa',
    separatorFinishedColor: '#60B44A',
    separatorUnFinishedColor: '#aaaaaa',
    stepIndicatorFinishedColor: '#60B44A',
    stepIndicatorUnFinishedColor: '#ffffff',
    stepIndicatorCurrentColor: '#ffffff',
    stepIndicatorLabelFontSize: 13,
    currentStepIndicatorLabelFontSize: 13,
    stepIndicatorLabelCurrentColor: '#60B44A',
    stepIndicatorLabelFinishedColor: '#ffffff',
    stepIndicatorLabelUnFinishedColor: '#aaaaaa',
    labelColor: '#999999',
    labelSize: 13,
    currentStepLabelColor: '#60B44A',
}
