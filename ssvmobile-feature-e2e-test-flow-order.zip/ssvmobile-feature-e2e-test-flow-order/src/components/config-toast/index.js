import React from 'react'
// Nếu custom gì không rõ có thể mở thư viện ra đọc
import { useTranslation } from 'react-i18next'
import { StyleSheet } from 'react-native'
// import { StoreContext } from '../../store';
import Svg, { ClipPath, Defs, G, Path } from 'react-native-svg'
import { Col, Row, Text, View } from 'native-base'

import { dimensions } from '../../styles'

function WarningToast({ hide, text1, text2, iconLeft, iconRight, size = [4, 16, 4], visibilityTime = 10000, props, ...rest }) {
    const ICLeft = () => {
        return (
            <Svg fill="none" height={20} viewBox="0 0 20 20" width={20} xmlns="http://www.w3.org/2000/svg">
                <G clipPath="url(#prefix__clip0)">
                    <Path
                        d="M10.98 2.207h0l.004.007 8.12 14.415c.4.73-.073 1.67-1.061 1.72H1.878c-.848 0-1.41-.935-.982-1.72l8.12-14.415h0l.004-.007c.408-.741 1.553-.74 1.96 0z"
                        stroke="#E2BD00"
                        strokeWidth={1.5}
                    />
                    <Path
                        d="M8.678 9.402l.504 3.337a.82.82 0 00.818.693c.378 0 .756-.315.819-.693l.504-3.337c.126-.819-.504-1.511-1.323-1.511-.818 0-1.385.692-1.322 1.51zM10 15.635a.756.756 0 100-1.511.756.756 0 000 1.511z"
                        fill="#E2BD00"
                    />
                </G>
                <Defs>
                    <ClipPath id="prefix__clip0">
                        <Path d="M0 0h20v20H0z" fill="#fff" />
                    </ClipPath>
                </Defs>
            </Svg>
        )
    }
    const ICRight = () => {
        return (
            <Svg fill="none" height={20} viewBox="0 0 20 20" width={20} xmlns="http://www.w3.org/2000/svg">
                <Path
                    d="M11.326 10l3.71-3.71a.939.939 0 00-1.325-1.328L10 8.672l-3.71-3.71A.94.94 0 104.96 6.29L8.671 10l-3.71 3.712a.94.94 0 101.328 1.328L10 11.329l3.711 3.71a.94.94 0 101.328-1.327L11.326 10z"
                    fill="#24253D"
                    opacity={0.34}
                />
            </Svg>
        )
    }
    const CenterContent = () => {
        const { t } = useTranslation()
        return (
            <Text style={{ color: '#E2BD00' }}>
                <Text style={{ fontWeight: 'bold', color: '#E2BD00' }}>{t('warning') + ': ' + text1 ? text1 : '' + ' '}</Text>
                {text2}
            </Text>
        )
    }
    // console.log("WarningToast");
    return (
        <View style={{ ...UI.View, backgroundColor: '#F8F3D6', borderWidth: 0.5, borderColor: '#FAD416' }}>
            <Row style={{ width: '100%' }}>
                <Col size={size[0]} style={{ ...UI.Col01 }}>
                    <ICLeft />
                </Col>
                <Col size={size[1]} style={{ ...UI.Col02 }}>
                    <CenterContent />
                </Col>
                <Col size={size[2]} style={{ ...UI.Col03 }} onPress={hide}>
                    <ICRight />
                </Col>
            </Row>
        </View>
    )
}

function SuccessToast({ hide, text1, text2, iconLeft, iconRight, size = [4, 16, 4], props, visibilityTime = 10000, ...rest }) {
    const ICLeft = () => {
        return (
            <Svg fill="none" height={20} viewBox="0 0 20 20" width={20} xmlns="http://www.w3.org/2000/svg">
                <Path d="M10 19.994c5.523 0 10-4.475 10-9.994C20 4.48 15.523.007 10 .007S0 4.48 0 10c0 5.52 4.477 9.994 10 9.994z" fill="#2ECC71" />
                <Path d="M9.198 15.316L4.47 11.632l1.344-1.725 2.904 2.262 4.792-6.915L15.308 6.5l-6.11 8.816z" fill="#fff" />
            </Svg>
        )
    }
    const ICRight = () => {
        return (
            <Svg fill="none" height={20} viewBox="0 0 20 20" width={20} xmlns="http://www.w3.org/2000/svg">
                <Path
                    d="M11.326 10l3.71-3.71a.939.939 0 00-1.325-1.328L10 8.672l-3.71-3.71A.94.94 0 104.96 6.29L8.671 10l-3.71 3.712a.94.94 0 101.328 1.328L10 11.329l3.711 3.71a.94.94 0 101.328-1.327L11.326 10z"
                    fill="#24253D"
                    opacity={0.34}
                />
            </Svg>
        )
    }
    const CenterContent = () => {
        const { t } = useTranslation()
        return (
            <Text style={{ color: '#2ECC71' }}>
                <Text style={{ fontWeight: 'bold', color: '#2ECC71' }}>{t('common_Success') + ': ' + text1 ? text1 : '' + ' '}</Text>
                {text2}
            </Text>
        )
    }
    // console.log("WarningToast");
    return (
        <View style={{ ...UI.View, backgroundColor: '#CCE8F3', borderWidth: 0.5, borderColor: '#2ECC71' }}>
            <Row style={{ width: '100%' }}>
                <Col size={size[0]} style={{ ...UI.Col01 }}>
                    <ICLeft />
                </Col>
                <Col size={size[1]} style={{ ...UI.Col02 }}>
                    <CenterContent />
                </Col>
                <Col size={size[2]} style={{ ...UI.Col03 }} onPress={hide}>
                    <ICRight />
                </Col>
            </Row>
        </View>
    )
}

export const configToast = {
    warning: WarningToast,
    success: SuccessToast,
}

const UI = StyleSheet.create({
    Col01: {
        alignItems: 'center',
        justifyContent: 'center',
    },
    Col02: {
        justifyContent: 'center',
    },
    Col03: {
        alignItems: 'center',
        justifyContent: 'center',
    },
    View: {
        borderRadius: 8,
        marginHorizontal: dimensions.moderate(16),
        marginTop: 32,
        paddingVertical: 8,
    },
})
