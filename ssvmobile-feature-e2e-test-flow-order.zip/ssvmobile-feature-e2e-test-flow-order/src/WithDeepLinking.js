import React, { useEffect } from 'react'
import { Linking } from 'react-native'
import DeepLinking from 'react-native-deep-linking'

const handleUrl = ({ url }) => {
    if (!url) {
        return
    }

    Linking.canOpenURL(url)
        .then((supported) => {
            if (supported) {
                DeepLinking.evaluateUrl(url)
            }
        })
        .catch((error) => alert(error))
}

export const WithDeepLinking = (WrappedComponent) => {
    useEffect(() => {
        DeepLinking.addScheme(`ssvmobile://`)
        DeepLinking.addScheme('https://')
        const linkingEvent = Linking.addEventListener('url', handleUrlListener)

        const handleDeepLinkingInfo = (info = {}) => {
            const { } = info
        }

        DeepLinking.addRoute('/promo/:id', (response) => {
            handleDeepLinkingInfo({})
        })
    }, [])

    const handleUrlListener = (urlInfo) => {
        handleUrl(urlInfo)
    }

    return <WrappedComponent />
}
