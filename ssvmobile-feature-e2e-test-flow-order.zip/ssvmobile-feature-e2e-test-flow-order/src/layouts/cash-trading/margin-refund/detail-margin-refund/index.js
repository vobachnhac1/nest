import React, { useContext, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { InteractionManager, Pressable, View } from 'react-native'
import Modal from 'react-native-modal'
import Svg, { ClipPath, Defs, G, Path } from 'react-native-svg'
import ToastGlobal from 'react-native-toast-message'
import moment from 'moment'
import { Container, Content } from 'native-base'

import { CustomFloatInput } from '../../../../basic-components'
import HeaderComponent from '../../../../components/header'
import ModalLoading from '../../../../components/modal-loading'
import { ButtonCustom, ModalContent, RowData, RowDataModal, RowTitleGroup } from '../../../../components/trading-component'
import { useAlertModal, useAlertModalCommonCode, useModalOtpWhenErr, useUpdateEffect } from '../../../../hoc'
import { StoreContext } from '../../../../store'
import { StoreTrading } from '../../../../store-trading'
import { dimensions as dm } from '../../../../styles'
import { FormatNumber, glb_sv, reqFunct, sendRequest } from '../../../../utils'
import screens from '../../../../utils/constant/screens'

// Khai báo ServiceInfo (nếu có)
const ServiceInfo = {
    SEND_REFUND_MARG: {
        reqFunct: reqFunct.SEND_REFUND_MARG,
        WorkerName: 'FOSxMargin',
        ServiceName: 'FOSxMargin_1402',
        ClientSentTime: '0',
        Operation: 'I',
    },
    GET_REF_INFO_DETAIL: {
        reqFunct: reqFunct.GET_REF_INFO_DETAIL,
        WorkerName: 'FOSqMargin',
        ServiceName: 'FOSqMargin_1402_2',
        ClientSentTime: '0',
        Operation: 'Q',
    },
}
const initErrCtrl = [
    {
        error: false,
        message: 'warning_cash_input',
    },
]
// Khai báo component
export default function DetailAdvanceLendingLayout({ navigation, route }) {
    const { styles } = useContext(StoreContext)
    const { userInfo } = useContext(StoreTrading)

    const { t } = useTranslation()
    const { params = {} } = route
    const { data = {}, onRefresh = () => null, onReFreshContract = () => null } = params
    const [isOpenModal, setIsOpenModal] = useState(false)
    const [loadingConfirm, setLoadingConfirm] = useState(false)
    const [errCtrl, setErrCtrl] = useState(initErrCtrl)

    // Start define all bussiness state
    const [refundAmount, setRefundAmount] = useState('')
    const [contractInfo, setContractInfo] = useState({})
    // End define form bussiness state
    // -------------------------------------------   Dùng useEffect get các dữ liệu cần thiết còn thiếu

    useUpdateEffect(() => {
        _validateValue(0)
    }, [refundAmount])

    // -------------------------------------------   Viết các hàm để set lại bussiness form state. Nên viết đúng một chuẩn duy nhất để dễ control
    const switchStep = {
        submit: () => sendRepayMargin(),
        onFinish: () => _checkValueBfSend(),
    }
    const _validateValue = (inputIndex) => {
        const newErrCtrl = [...initErrCtrl]
        if (inputIndex === 0) newErrCtrl[0].error = Number(refundAmount) <= 0 || !refundAmount
        if (!inputIndex && inputIndex !== 0) {
            newErrCtrl[0].error = Number(refundAmount) <= 0
        }
        setErrCtrl(newErrCtrl)
    }
    const _checkValueBfSend = () => {
        hideModal()
        _validateValue()
        if (errCtrl.filter((item) => item.error === true).length === 0) {
            //----------------
            const isAuthenOTP = glb_sv.checkOtp(navigation, () => {
                setTimeout(() => {
                    setIsOpenModal((prev) => true)
                }, 100)
            })
            if (isAuthenOTP) {
                setIsOpenModal(true)
            }
            //---------------
        }
        return
    }
    const _resetInput = () => {
        navigation.goBack()
        onRefresh()
        setRefundAmount()
    }
    const hideModal = () => {
        setIsOpenModal(false)
    }

    // -------------------------------------------   Khai báo các hàm gửi (request) lên server
    const getRefundInfoDetail = () => {
        const InputParams = ['OTSDTL', data.c0]
        sendRequest(ServiceInfo.GET_REF_INFO_DETAIL, InputParams, handleGetRefundInfoDetail)
    }

    const handleGetRefundInfoDetail = (reqInfoMap, message) => {
        // -- process after get result --
        if (Number(message.Result) === 0) {
            ToastGlobal.show({
                text2: message.Message,
                type: 'warning',
            })
            return
        } else {
            let jsondata
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {
                jsondata = []
            }
            console.log('Contract info', message, jsondata)
            setContractInfo(jsondata)
        }
    }

    const sendRepayMargin = () => {
        hideModal()
        InteractionManager.runAfterInteractions(() => {
            if (!glb_sv.checkOtp(navigation, sendRepayMargin)) return
            const InputParams = ['1', data.c0, String(refundAmount)]
            sendRequest(ServiceInfo.SEND_REFUND_MARG, InputParams, handleSendRepayMargin)
            setLoadingConfirm(true)
        })
    }

    const handleSendRepayMargin = (reqInfoMap, message) => {
        setLoadingConfirm(false)
        // -- process after get result --
        if (Number(message.Result) === 0) {
            const { hasAlertCommonCode } = useAlertModalCommonCode(message, {})
            const { hasAlertErrOtp } = useModalOtpWhenErr(message, { continueVerify: !hasAlertCommonCode, callback: () => setIsOpenModal((prev) => true) })
            useAlertModal(message, { continueVerify: !hasAlertErrOtp })
        } else {
            ToastGlobal.show({
                text2: message.Message,
                type: 'success',
            })
            onReFreshContract()
            _resetInput()
        }
    }

    const repayMaxValue = () => {
        setRefundAmount(Number(data.c9) + Number(data.c15))
    }
    const repayAmountAvailable = () => {
        setRefundAmount(Number(data.c20))
    }

    const refundContract = () => {
        if (refundAmount && Number(refundAmount) > 0) {
            switchStep.onFinish()
        } else {
            ToastGlobal.show({
                text2: t('warning_cash_input'),
                type: 'warning',
            })
        }
    }
    const openHistory = () => {
        navigation.navigate(screens.HISTORY_MARGIN_REFUND, { contractInfo: data })
    }

    // -------------------------------------------   Khai báo các hàm gửi (request) và nhận (handle respone) dữ liệu từ server

    return (
        <Container style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
            <HeaderComponent
                colorRightText={styles.PRIMARY}
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft
                isShowRight
                navigation={navigation}
                rightButtonLink={openHistory}
                rightText={t('history_tab')}
                title={t('margin_contract_detail')}
                titleAlgin="flex-start"
                transparent
            />
            <Content>
                <RowTitleGroup text={t('contact_detail')} />
                <RowData dataSub={[data.c3, data.c4]} textLeft={t('acnt_no')} />
                <RowData textLeft={t('contract_no')} textRight={data.c0} />
                <RowData textLeft={t('loan_date')} textRight={moment(data.c1, 'DDMMYYYY').format('DD/MM/YYYY')} />
                <RowData textLeft={t('date_due')} textRight={moment(data.c5, 'DDMMYYYY').format('DD/MM/YYYY')} />
                <RowData last textLeft={t('loan_term')} textRight={data.c6} />

                {/* ------------------------------------------- */}
                <RowTitleGroup hasDivider text={t('common_Detail')} />
                <RowData textLeft={t('loan_amount')} textRight={FormatNumber(data.c8)} />
                <RowData textLeft={t('amount_paid')} textRight={FormatNumber(data.c10)} />
                <RowData textLeft={t('interest_paid')} textRight={FormatNumber(data.c11)} />
                <Pressable onPress={repayAmountAvailable}>
                    <RowData rightColor={styles.PRIMARY} textLeft={t('money_available')} textRight={FormatNumber(data.c20)} type="highlight" />
                </Pressable>
                <RowData textLeft={t('loan_current')} textRight={FormatNumber(data.c9)} />
                <RowData textLeft={t('interest_contemp')} textRight={FormatNumber(Number(data.c15) + Number(data.c16) + Number(data.c17) + Number(data.c18))} />
                <Pressable onPress={repayMaxValue}>
                    <RowData
                        last
                        rightColor={styles.PRIMARY}
                        textLeft={t('repay_max')}
                        textRight={FormatNumber(Number(data.c9) + Number(data.c15))}
                        type="highlight"
                    />
                </Pressable>

                {/* {isCanCancelContract && <>
                </>} */}

                <RowTitleGroup hasDivider text={t('repay_amount')} />

                <View style={{ paddingHorizontal: dm.moderate(16), paddingTop: 8 }}>
                    <CustomFloatInput
                        animationDuration={100}
                        errCtrl={t(errCtrl[0])}
                        keyboardType="number-pad"
                        label={t('repay_amount')}
                        placeholderTextColor={styles.PLACEHODLER__COLOR}
                        value={FormatNumber(refundAmount) === '0' ? '0' : FormatNumber(refundAmount)}
                        onChangeText={(amount) => setRefundAmount(glb_sv.filterNumber(amount))}
                    />
                </View>

                <ButtonCustom text={t('regit_repay')} onPress={refundContract} />
                <View style={{ height: 40 }} />
            </Content>
            {/* **************************************** Modal confirm ******************************************/}
            {isOpenModal ? (
                <Modal isVisible={isOpenModal} useNativeDriver={true} onBackButtonPress={hideModal} onBackdropPress={hideModal}>
                    <ModalContent
                        iconComponent={
                            <Svg fill="none" height={32} viewBox="0 0 33 32" width={33} xmlns="http://www.w3.org/2000/svg">
                                <G clipPath="url(#prefix__clip0)" fill="#2ECC71">
                                    <Path d="M5.754 23.077V0H4.217A4.111 4.111 0 00.11 4.106v20.275a5.343 5.343 0 013.501-1.304h2.143zM24.93 15.934c.201 0 .402.008.6.021V0H7.625v23.077h8.547c.834-4.07 4.444-7.143 8.758-7.143zM13.305 5.511h6.264v1.871h-6.264V5.511zM11.19 9.574h10.496v1.871H11.189V9.574zM17.213 29.381H4.853V27.51h11.534a8.906 8.906 0 01-.396-2.62H3.61a3.56 3.56 0 00-3.555 3.556A3.56 3.56 0 003.611 32H19.54a9.007 9.007 0 01-2.327-2.62z" />
                                    <Path d="M24.93 17.746a7.135 7.135 0 00-7.127 7.127c0 3.93 3.197 7.126 7.127 7.126 3.93 0 7.126-3.197 7.126-7.126a7.135 7.135 0 00-7.126-7.127zm-.001 2.86c.526 0 .915.43.937.938.023.506-.447.937-.937.937-.526 0-.915-.43-.938-.937-.022-.507.448-.938.938-.938zm.94 7.92h-1.875v-4.8h1.875v4.8z" />
                                </G>
                                <Defs>
                                    <ClipPath id="prefix__clip0">
                                        <Path d="M0 0h32v32H0z" fill="#fff" transform="translate(.056)" />
                                    </ClipPath>
                                </Defs>
                            </Svg>
                        }
                        title={t('trading_confirm')}
                        type="confirm"
                    >
                        <RowDataModal dataSub={[userInfo.actn_curr, userInfo.sub_curr]} textLeft={t('acnt_no')} textRight={userInfo.actn_curr} />
                        <RowDataModal textLeft={t('contract_no')} textRight={data.c0} />
                        <RowDataModal textLeft={t('loan_date')} textRight={moment(data.c1, 'DDMMYYYY').format('DD/MM/YYYY')} />
                        <RowDataModal textLeft={t('loan_amount')} textRight={FormatNumber(data.c8)} />
                        <RowDataModal textLeft={t('loan_current')} textRight={FormatNumber(data.c9)} />
                        <RowDataModal textLeft={t('repay_amount')} textRight={FormatNumber(refundAmount)} />
                        <ButtonCustom text={t('common_button_confirm')} type="confirm" onPress={switchStep.submit} />
                        <ButtonCustom last text={t('common_Cancel')} type="back" onPress={hideModal} />
                    </ModalContent>
                </Modal>
            ) : null}
            {loadingConfirm ? <ModalLoading content={t('common_processing')} visible={loadingConfirm} /> : null}
        </Container>
    )
}
