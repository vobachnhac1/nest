import React, { useContext, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { StyleSheet, TextInput, TouchableOpacity } from 'react-native'
import Svg, { Circle, ClipPath, Defs, G, Path } from 'react-native-svg'
import { Col, Row, View } from 'native-base'

import { CustomFloatInput, Text } from '../../../../basic-components'
import { StoreContext } from '../../../../store'
import { dimensions as dm, fontSizes as fs, fontWeights as fw } from '../../../../styles'
import { FormatNumber, glb_sv } from '../../../../utils'

const listCompare = [
    { label: '>=', value: '>=' },
    { label: '<=', value: '<=' },
]

const AlertRowInput = ({
    alertName, // Nội dung header
    deleteRowConditon,
    iconRight = null, // Right Component
    type = 'buy', // type của header
    indexCondition,
    listCurrentConditionAlert,
    setListCurrentConditionAlert,
    listCondition,
    conditionInfo,
    ...props
}) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()
    const [conditionOperator, setConditionOperator] = useState(listCompare.findIndex((item) => item.value === listCurrentConditionAlert[indexCondition].c4))
    const [conditionValue, setConditionValue] = useState(listCurrentConditionAlert[indexCondition].c5)

    const updateListCurrentConditionOperator = () => {
        const currentData = [...listCurrentConditionAlert]
        const newCompareOperator = (conditionOperator + 1) % listCompare.length
        currentData[indexCondition].c4 = listCompare[newCompareOperator]?.value
        setConditionOperator(newCompareOperator)
        setListCurrentConditionAlert(currentData)
    }
    const onChangeValue = (newValue) => {
        const currentData = [...listCurrentConditionAlert]
        currentData[indexCondition].c5 = newValue
        setConditionValue(newValue)
        setListCurrentConditionAlert(currentData)
    }

    const getUnit = (keyOfCondition, conditionCode) => {
        const condition = listCondition.find((cond) => cond.data.c0 === keyOfCondition && cond.data.c1 === conditionCode)
        return condition?.data.c3 || ''
    }

    return (
        <Row style={[UI.RowWrap, { borderBottomColor: styles.DIVIDER__COLOR }]}>
            <View style={{ flex: 20 }}>
                <Text numberOfLines={1} style={{ fontWeight: fw.bold, fontSize: fs.small, color: styles.PRIMARY__CONTENT__COLOR, fontStyle: 'italic' }}>
                    {alertName} ({getUnit(conditionInfo.c1, conditionInfo.c2)})
                </Text>
                <View style={{ flexDirection: 'row', marginTop: 8 }}>
                    <View style={[UI.LabelInput]}>
                        <Text style={{ fontWeight: fw.bold, fontSize: fs.small, color: styles.SECOND__CONTENT__COLOR, textAlign: 'right' }}>
                            {t('common_compare')}:
                        </Text>
                    </View>
                    <TouchableOpacity onPress={updateListCurrentConditionOperator}>
                        <View style={[UI.ConditionOparator, { backgroundColor: styles.INPUT__BG }]}>
                            <Text style={{ fontWeight: fw.bold, fontSize: fs.normal, color: styles.PRIMARY__CONTENT__COLOR }}>
                                {listCompare[conditionOperator]?.label}
                            </Text>
                        </View>
                    </TouchableOpacity>
                    <View style={[UI.LabelInput]}>
                        <Text style={{ fontWeight: fw.bold, fontSize: fs.small, color: styles.SECOND__CONTENT__COLOR, textAlign: 'right' }}>
                            {t('common_values')}:
                        </Text>
                    </View>
                    <View style={[UI.InputValue, { backgroundColor: styles.INPUT__BG }]}>
                        <TextInput
                            keyboardType="number-pad"
                            placeholder={t('common_values')}
                            placeholderTextColor={styles.SECOND__CONTENT__COLOR}
                            returnKeyType="done"
                            style={{
                                fontSize: fs.small,
                                color: styles.PRIMARY__CONTENT__COLOR,
                                textAlignVertical: 'center',
                                textAlign: 'right',
                            }}
                            value={FormatNumber(conditionValue)}
                            onChangeText={(value) => {
                                onChangeValue(glb_sv.filterNumber(value))
                            }}
                        />
                    </View>
                    <View style={{ justifyContent: 'center', alignItems: 'flex-end', paddingLeft: 8 }}>
                        <TouchableOpacity onPress={deleteRowConditon}>
                            <Svg fill="none" height={20} width={20} xmlns="http://www.w3.org/2000/svg">
                                <Path
                                    d="M10 1.875C5.52 1.875 1.875 5.52 1.875 10S5.52 18.125 10 18.125 18.125 14.48 18.125 10 14.48 1.875 10 1.875zm3.125 8.75h-6.25a.625.625 0 110-1.25h6.25a.625.625 0 110 1.25z"
                                    fill="#EB5C55"
                                />
                            </Svg>
                        </TouchableOpacity>
                    </View>
                </View>
            </View>
        </Row>
    )
}

export default AlertRowInput

const UI = StyleSheet.create({
    ConditionOparator: {
        borderRadius: 4,
        flex: 1,
        marginRight: 8,
        paddingHorizontal: 10,
        paddingVertical: 8,
    },
    InputValue: {
        borderRadius: 4,
        flex: 5,
        paddingHorizontal: 10,
        paddingVertical: 8,
    },
    LabelInput: { borderRadius: 4, marginRight: 8, paddingVertical: 8 },
    RowWrap: {
        borderBottomWidth: 1,
        borderRadius: 8,
        marginHorizontal: dm.moderate(16),
        marginVertical: dm.moderate(4),
        paddingBottom: 8,
        paddingVertical: dm.moderate(4),
    },
})
