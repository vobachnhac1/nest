import React, { useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { View } from 'react-native'
import DeviceInfo from 'react-native-device-info'
import { SafeAreaView } from 'react-native-safe-area-context'
import AntDesign from 'react-native-vector-icons/AntDesign'
import { Button, Input, Item } from 'native-base'
import SyncStorage from 'sync-storage'

import IconBack from '../../assets/images/common/ic_back.svg'
import { FocusAwareStatusBar, Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { dimensions, fontSizes } from '../../styles'
import { STORE_KEY } from '../../utils'

const isTablet = DeviceInfo.isTablet()

const NoteMarket = ({ navigation, route }) => {
    const { t55, U9 } = route.params
    const { styles, theme } = useContext(StoreContext)
    const { t } = useTranslation()
    const [note, setNote] = useState('')

    useEffect(() => {
        const data = SyncStorage.get(STORE_KEY.NOTE_MARKET)
        if (data && data[t55]) {
            setNote(data[t55])
        }
    }, [])

    const saveNote = () => {
        const data = SyncStorage.get(STORE_KEY.NOTE_MARKET)
        if (data) {
            data[t55] = note
            SyncStorage.set(STORE_KEY.NOTE_MARKET, data)
        } else {
            const data = {}
            data[t55] = note
            SyncStorage.set(STORE_KEY.NOTE_MARKET, data)
        }
        navigation.pop()
    }

    return (
        <SafeAreaView style={{ flex: 1, backgroundColor: styles.PRIMARY__BG__COLOR }}>
            <FocusAwareStatusBar backgroundColor={'transparent'} barStyle={theme.includes('DARK') ? 'light-content' : 'dark-content'} translucent={true} />
            <View style={{ flexDirection: 'row', height: isTablet ? 50 : 40, paddingHorizontal: 5, alignItems: 'center' }}>
                <Button style={{ paddingTop: 0, paddingBottom: 0, height: 35 }} transparent onPress={() => navigation.pop()}>
                    <IconBack height={dimensions.moderate(24)} style={{ color: styles.ICON__PRIMARY }} width={dimensions.moderate(24)} />
                </Button>
                <View style={{ flexDirection: 'column', flex: 1, borderRadius: 10, padding: 0, alignItems: 'flex-start' }}>
                    <Text style={{ fontSize: fontSizes.xmedium, color: styles.PRIMARY__CONTENT__COLOR }}>{t('add_note')}</Text>
                </View>
                <Button
                    style={{ paddingVertical: 0, paddingHorizontal: dimensions.moderate(16), height: 35, backgroundColor: styles.PRIMARY, borderRadius: 20 }}
                    onPress={saveNote}
                >
                    <Text style={{ color: '#FFF', fontSize: fontSizes.small }}>{t('save')}</Text>
                </Button>
            </View>
            <Text style={{ fontSize: fontSizes.small, color: styles.SECOND__CONTENT__COLOR, padding: dimensions.halfIndent }}>
                {t55} - {U9}
            </Text>
            <View style={{ flex: 1, borderTopColor: styles.DIVIDER__COLOR, borderTopWidth: 1 }}>
                <Item style={{ borderColor: 'transparent' }}>
                    <Input
                        multiline
                        placeholder={t('note_something')}
                        placeholderTextColor={styles.PLACEHODLER__COLOR}
                        style={{
                            fontSize: fontSizes.small,
                            color: styles.PRIMARY__CONTENT__COLOR,
                        }}
                        value={note}
                        onChangeText={(newNote) => setNote(newNote)}
                    />
                </Item>
            </View>
        </SafeAreaView>
    )
}

export default NoteMarket
