import React, { useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { View } from 'react-native'
import { Row } from 'native-base'

import { StoreContext } from '../../../store'
import { dimensions as dm, fontSizes as fs, fontWeights as fw } from '../../../styles'

interface IRowTableData {
    type?: 'table'
    onPress?: Function
    children?: any
    last?: boolean
}

const RowTableData = ({
    type = 'table', // type của header
    onPress, // onPress
    children,
    last,
    ...props
}: IRowTableData) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()

    return (
        <>
            <Row
                style={{
                    flex: 1,
                    paddingVertical: dm.vertical(6),
                }}
                onPress={onPress}
            >
                {children}
            </Row>
            {!last && <View style={{ borderBottomColor: styles.DIVIDER__COLOR, borderBottomWidth: 1 }} />}
        </>
    )
}

export default RowTableData
