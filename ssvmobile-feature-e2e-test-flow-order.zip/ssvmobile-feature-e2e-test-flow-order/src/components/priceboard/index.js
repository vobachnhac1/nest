/* eslint-disable no-restricted-syntax */
import React, { memo, useCallback, useContext, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import {
    ActivityIndicator,
    Animated,
    BackHandler,
    FlatList,
    InteractionManager,
    Platform,
    ScrollView,
    StatusBar,
    StyleSheet,
    TouchableOpacity,
    View,
} from 'react-native'
import { isTablet } from 'react-native-device-info'
import Orientation from 'react-native-orientation-locker'
import Svg, { Path, Rect } from 'react-native-svg'
import cloneDeep from 'lodash/cloneDeep'
import throttle from 'lodash/throttle'

import { OrderBy, Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { dimensions, fontSizes, fontWeights } from '../../styles'
import { eventList, FormatNumber, glb_sv, Screens, subcribeFunctStream } from '../../utils'
import FormatNumberAC from '../../utils/formatNumber/FormatNumberAC'

const IOS = Platform.OS === 'ios' ? true : false
const isTab = isTablet()

function isVolume(type) {
    if (type === 't391' || type === 't32' || type === 't397' || type === 't398' || type === 't3301' || type === 't32_PO') {
        return true
    } else return false
}

function isVolumeSellBuy(type) {
    if (
        type === 't1321_3' ||
        type === 't1321_2' ||
        type === 't1321_1' ||
        type === 't1331_3' ||
        type === 't1331_2' ||
        type === 't1331_1' ||
        type === 't1321_3_PO' ||
        type === 't1321_2_PO' ||
        type === 't1321_1_PO' ||
        type === 't1331_3_PO' ||
        type === 't1331_2_PO' ||
        type === 't1331_1_PO'
    ) {
        return true
    } else return false
}

function isHightLight(type) {
    if (
        type === 't55' ||
        type === 't31' ||
        type === 't32' ||
        type === 't260' ||
        type === 't332' ||
        type === 't333' ||
        type === 't31_incr' ||
        type === 't31_incr_per' ||
        type === 't391' ||
        type === 't31_PO' ||
        type === 't32_PO' ||
        type === 't31_incr_PO' ||
        type === 't31_incr_per_PO'
    ) {
        return true
    } else return false
}

const listOther = [
    't55',
    't391',
    't398',
    't3301',
    't1321_3',
    't1321_2',
    't1321_1',
    't1331_3',
    't1331_2',
    't1331_1',
    't32',
    't31_incr_per',
    't1321_3_PO',
    't1321_2_PO',
    't1321_1_PO',
    't1331_3_PO',
    't1331_2_PO',
    't1331_1_PO',
    't32_PO',
    't31_incr_per_PO',
]

export default function Priceboard({ navigation, route }) {
    const isFocused = useRef(null)
    const { list } = route.params
    const listStock = list.map((e) => e.t55)

    const { styles, fractionPrice, fractionQty } = useContext(StoreContext)
    const { t } = useTranslation()

    const [data, setData] = useState([])
    const [sort, setSort] = useState('')
    const sortRef = useRef('')

    const listDataSubRef = useRef(list)
    const VIEW_HEIGHT_LIST = useRef(dimensions.HIEGHT)
    const VIEW_HEIGHT_ROW = useRef(60.5)
    const CURRENT_SCROLL = useRef(0)
    const delayTimeout = useRef(null)

    const [HEADER_TABLE, setHeader] = useState(glb_sv.activeList.isOddlot ? glb_sv.LIST_HEADER_PRICEBOARD_ODDLOT : glb_sv.LIST_HEADER_PRICEBOARD)

    const [scrollX, setScrollX] = useState(new Animated.Value(0))

    const throttled = useRef(
        throttle(
            () => {
                if (!isFocused.current) return
                const newList = listStock.map((e) => glb_sv.StockMarket[e] || { t55: e, EP: [] })
                newList.sort(sortColumn)
                setData(newList)
            },
            500,
            { trailing: true },
        ),
    )

    const isOddlot = glb_sv.activeList.isOddlot

    useEffect(() => {
        Orientation.lockToLandscape()
        const eventMarket = glb_sv.eventMarket.subscribe((msg) => {
            if (msg.type === eventList.SUB_STOCK && msg.message !== 'EP' && glb_sv.subListCur.some((e) => e === msg.msgKey) && isFocused.current) {
                throttled.current()
            }
            if (msg.type === eventList.RECONNECT_MARKET) {
                handleSubRow(null, true)
                handleSubRow()
            }
        })

        const focusScreen = navigation.addListener('focus', (e) => {
            isFocused.current = true
            InteractionManager.runAfterInteractions(() => {
                throttled.current()
                handleSubRow(null, true)
                setTimeout(() => {
                    handleSubRow()
                }, 0)
            })
        })
        const blurScreen = navigation.addListener('blur', (e) => {
            isFocused.current = false
        })

        return () => {
            isFocused.current = false
            Orientation.lockToPortrait()
            eventMarket.unsubscribe()
            throttled.current.cancel()
            blurScreen()
            focusScreen()
            subcribeFunctStream('UNSUB', ['MDDS|TO', 'MDDS|PO', 'MDDS|TP'], listStock)
        }
    }, [])

    const changeTypeSort = (changed) => {
        if (sort === '' || sort.split('|')[0] !== changed) {
            sortRef.current = changed + '|down'
            setSort(changed + '|down')
            const listSub = listDataSubRef.current.map((e) => {
                return glb_sv.StockMarket[e.t55] || { t55: e.t55, EP: [] }
            })
            listDataSubRef.current = listSub
            const newList = cloneDeep(listDataSubRef.current)
            newList.sort(sortColumn)
            setData(newList)
        }
        if (sort === changed + '|down') {
            sortRef.current = changed + '|up'
            setSort(changed + '|up')
            const listSub = listDataSubRef.current.map((e) => {
                return glb_sv.StockMarket[e.t55] || { t55: e.t55, EP: [] }
            })
            listDataSubRef.current = listSub
            const newList = cloneDeep(listDataSubRef.current)
            newList.sort(sortColumn)
            setData(newList)
        }
        if (sort === changed + '|up') {
            sortRef.current = ''
            setSort('')
            const listSub = listDataSubRef.current.map((e) => {
                return glb_sv.StockMarket[e.t55] || { t55: e.t55, EP: [] }
            })
            listDataSubRef.current = listSub
            const newList = cloneDeep(listDataSubRef.current)
            setData(newList)
        }
    }

    function sortColumn(a, b) {
        const [key, direction] = sortRef.current.split('|')
        if (direction === 'up') {
            if (a[key] > b[key]) return 1
            if (a[key] < b[key]) return -1
            return 0
        }
        if (direction === 'down') {
            if (a[key] < b[key]) return 1
            if (a[key] > b[key]) return -1
            return 0
        }
    }

    const handleSubRow = (y, all) => {
        if (all) {
            const newList = listStock.slice()
            if (newList.length) {
                if (glb_sv.activeList.isOddlot) {
                    subcribeFunctStream('SUB', ['MDDS|SI', 'MDDS|TO', 'MDDS|PO'], newList)
                } else {
                    subcribeFunctStream('SUB', ['MDDS|SI', 'MDDS|TP'], newList)
                }
            }
            return
        }
        CURRENT_SCROLL.current = y || CURRENT_SCROLL.current

        if (delayTimeout.current) clearTimeout(delayTimeout.current)
        delayTimeout.current = setTimeout(() => {
            const NoHeadArr = Math.round(CURRENT_SCROLL.current / VIEW_HEIGHT_ROW.current)
            const NoTailArr = Math.ceil(VIEW_HEIGHT_LIST.current / VIEW_HEIGHT_ROW.current)

            const newList = listStock.slice(NoHeadArr, NoHeadArr + NoTailArr)

            if (newList.length) {
                glb_sv.subListCur = newList

                const listSub = listDataSubRef.current.map((e) => {
                    return glb_sv.StockMarket[e.t55] || { t55: e.t55, EP: [] }
                })
                listDataSubRef.current = listSub
                throttled.current()
            }
        }, 200)
    }

    useEffect(() => {
        const backHandler = BackHandler.addEventListener('hardwareBackPress', goBack)

        return () => backHandler.remove()
    }, [])

    const goBack = useCallback(() => {
        isFocused.current = false
        throttled.current.cancel()
        Orientation.lockToPortrait()
        setData([])
        InteractionManager.runAfterInteractions(() => navigation.goBack())
        return true
    }, [])

    const showOrderPriceboard = useCallback(() => {
        isFocused.current = false
        throttled.current.cancel()
        InteractionManager.runAfterInteractions(() => {
            navigation.navigate(Screens.SORT_PRICEBOARD, { setHeader, isOddlot })
        })
    }, [])

    const stickyX = scrollX.interpolate({
        inputRange: [-1, 0, 1],
        outputRange: [0, 0, 1],
    })

    const HEADER_PB = useMemo(
        () => StyleSheet.flatten([{ flexDirection: 'row', flex: 1, backgroundColor: styles.PRIMARY__BG__COLOR, paddingLeft: dimensions.moderate(66, 0.25) }]),
        [],
    )

    const renderHeader = useMemo(() => {
        return (
            <View style={HEADER_PB}>
                {HEADER_TABLE.filter((e) => e.isShow === true).map((e, index) =>
                    e.type === 't55' ? (
                        <Animated.View
                            key={e.type + 'header'}
                            style={{
                                transform: [{ translateX: stickyX }],
                                zIndex: 99,
                                position: 'absolute',
                            }}
                        >
                            <ItemHeader changeTypeSort={changeTypeSort} index={index} name={t(e.name)} sort={sort} styles={styles} type={e.type} />
                        </Animated.View>
                    ) : (
                        <ItemHeader
                            changeTypeSort={changeTypeSort}
                            index={index}
                            key={e.type + 'header'}
                            name={t(e.name)}
                            sort={sort}
                            styles={styles}
                            type={e.type}
                        />
                    ),
                )}
            </View>
        )
    }, [HEADER_TABLE, sort])

    const RenderItem = ({ item, index }) => {
        return (
            <View style={UI.row_pb}>
                {HEADER_TABLE.filter((e) => e.isShow === true).map((e, i) =>
                    e.type === 't55' ? (
                        <Animated.View
                            key={e.type + 'cell' + item.t55}
                            style={{
                                ...StyleView,
                                transform: [{ translateX: stickyX }],
                                zIndex: 99,
                                position: 'absolute',
                            }}
                        >
                            <ItemCell
                                color={glb_sv.getColor(isOddlot ? item.t31_PO : item.t31, item, styles, isOddlot ? 't31_PO' : 't31')}
                                type={e.type}
                                value={item[e.type]}
                                valueOrgin={item[e.type]}
                            />
                        </Animated.View>
                    ) : (
                        <View key={e.type + 'cell' + item.t55} style={StyleView}>
                            {['t31_incr_per', 't31_incr_per_PO'].includes(e.type) && (
                                <ItemCell
                                    color={glb_sv.getColor(isOddlot ? item.t31_PO : item.t31, item, styles, e.type)}
                                    type={e.type}
                                    value={FormatNumber(item[e.type], 2, 1) + (item[e.type] ? '%' : '')}
                                    valueOrgin={item[e.type]}
                                />
                            )}
                            {e.type !== 't55' &&
                                e.type !== 't31_incr_per' &&
                                e.type !== 't391' &&
                                e.type !== 't397' &&
                                e.type !== 't398' &&
                                e.type !== 't3301' &&
                                e.type !== 't1321_3' &&
                                e.type !== 't1321_2' &&
                                e.type !== 't1321_1' &&
                                e.type !== 't1331_3' &&
                                e.type !== 't1331_2' &&
                                e.type !== 't1331_1' &&
                                e.type !== 't32' &&
                                e.type !== 't1321_3_PO' &&
                                e.type !== 't1321_2_PO' &&
                                e.type !== 't1321_1_PO' &&
                                e.type !== 't1331_3_PO' &&
                                e.type !== 't1331_2_PO' &&
                                e.type !== 't1331_1_PO' &&
                                e.type !== 't32_PO' &&
                                e.type !== 't31_incr_per_PO' && (
                                    <ItemCell
                                        color={glb_sv.getColor(item[e.type], item, styles, e.type)}
                                        type={e.type}
                                        value={
                                            item[e.type] === 777777710000
                                                ? 'ATO'
                                                : item[e.type] === 777777720000
                                                ? 'ATC'
                                                : fractionPrice
                                                ? FormatNumber(item[e.type] / 1000, 2, 1)
                                                : FormatNumber(item[e.type], 0, 1)
                                        }
                                        valueOrgin={item[e.type]}
                                    />
                                )}
                            {isVolumeSellBuy(e.type) && (
                                <ItemCell
                                    color={glb_sv.getColor(item[e.type], item, styles, e.type)}
                                    type={e.type}
                                    value={fractionQty ? FormatNumberAC(item[e.type], 0, 1) : FormatNumber(item[e.type], 0, 1)}
                                    valueOrgin={item[e.type]}
                                />
                            )}
                            {isVolume(e.type) && (
                                <ItemCell
                                    color={glb_sv.getColor(item[e.type], item, styles, e.type)}
                                    type={e.type}
                                    value={fractionQty ? FormatNumberAC(item[e.type], 0, 1) : FormatNumber(item[e.type], 0, 1, 'short')}
                                    valueOrgin={item[e.type]}
                                />
                            )}
                        </View>
                    ),
                )}
            </View>
        )
    }

    const renderLoading = useMemo(() => {
        return <ActivityIndicator color={styles.PRIMARY} size="large" />
    }, [])

    const StyleView = useMemo(() => StyleSheet.flatten([{ borderBottomColor: styles.DIVIDER__PB__COLOR, borderBottomWidth: 0.6 }]), [styles])

    const StyleContainer = useMemo(
        () => StyleSheet.flatten([{ backgroundColor: styles.PRIMARY__BG__COLOR, flex: 1, justifyContent: 'center', padding: dimensions.moderate(16) }]),
        [styles],
    )

    const StyleScrollView = useMemo(() => StyleSheet.flatten([{ backgroundColor: styles.PRIMARY__BG__COLOR, height: dimensions.WIDTH }]), [styles])

    return (
        <View style={StyleContainer}>
            <StatusBar hidden={true} />
            {data.length ? (
                <Animated.ScrollView
                    horizontal
                    style={StyleScrollView}
                    onLayout={(event) => {
                        const { height } = event.nativeEvent.layout
                        VIEW_HEIGHT_LIST.current = height
                    }}
                    onScroll={Animated.event([{ nativeEvent: { contentOffset: { x: scrollX } } }], { useNativeDriver: true })}
                >
                    <FlatList
                        data={data}
                        extraData={data}
                        keyExtractor={(item, index) => item?.t55 || index.toString()}
                        ListHeaderComponent={renderHeader}
                        renderItem={RenderItem}
                        scrollEventThrottle={100}
                        showsVerticalScrollIndicator={false}
                        stickyHeaderIndices={[0]}
                        onScroll={(e) => handleSubRow(e.nativeEvent.contentOffset.y)}
                    />
                </Animated.ScrollView>
            ) : (
                renderLoading
            )}
            <ButtonGoBack goBack={goBack} styles={styles} />
            <ButtonOrderPriceboard showOrderPriceboard={showOrderPriceboard} styles={styles} />
        </View>
    )
}

const ItemHeader = memo(({ name, type, sort, changeTypeSort, index, styles }) => {
    const ViewHeader = useMemo(
        () =>
            StyleSheet.flatten([
                UI.item,
                index === 0
                    ? { justifyContent: 'flex-start', alignItems: 'flex-start' }
                    : { justifyContent: 'flex-end', alignItems: 'flex-end', paddingRight: 0 },
                type === 't31_incr' || type === 't32' || type === 't31_incr_PO' || type === 't32_PO' ? { width: dimensions.moderate(50, 0.25) } : null,
                type === 't31_incr_per' || type === 't31_incr_per_PO' ? { width: dimensions.moderate(60, 0.25) } : null,
                type === 't391' || type === 't3301' ? { width: dimensions.moderate(82, 0.25) } : null,
                isHightLight(type) ? { backgroundColor: styles.HIGHTLIGHT_PB } : null,
            ]),
        [styles, index, type],
    )

    return (
        <View style={ViewHeader}>
            <OrderBy
                algin="right"
                changeTypeSort={changeTypeSort}
                isPriceboard={true}
                key={type}
                sortType={type}
                status={sort === type + '|up' ? 'asc' : sort === type + '|down' ? 'desc' : ''}
                title={name}
            />
        </View>
    )
})

const ItemCell = memo(({ value, color, valueOrgin, type }) => {
    const { styles } = useContext(StoreContext)
    const valueRef = useRef(valueOrgin)
    const animate = useRef(new Animated.Value(0))
    const bgColor = useRef('rgba(224,82,99,1)')

    useLayoutEffect(() => {
        if (type === 't55') return
        if (!valueOrgin) return
        if (valueRef.current === valueOrgin) {
            return
        }
        if (valueRef.current > valueOrgin) bgColor.current = 'rgba(224,82,99,1)'
        else if (valueRef.current < valueOrgin) bgColor.current = 'rgba(90,210,244,1)'
        valueRef.current = valueOrgin

        animate.current.resetAnimation()
        Animated.sequence([
            Animated.timing(animate.current, { toValue: 1, duration: 10, delay: 0, useNativeDriver: false }),
            Animated.timing(animate.current, { toValue: 0, duration: 10, delay: 400, useNativeDriver: false }),
        ]).start()

        return () => {
            animate.current.stopAnimation()
        }
    }, [valueOrgin, color])

    const boxInterpolation = animate.current.interpolate({
        inputRange: [0, 1],
        outputRange: [isHightLight(type) ? styles.HIGHTLIGHT_PB : styles.PRIMARY__BG__COLOR, bgColor.current],
    })
    const textInterpolation = animate.current.interpolate({
        inputRange: [0, 1],
        outputRange: [color, 'rgb(255,255,255)'],
    })

    const bgAnimation = {
        backgroundColor: boxInterpolation,
    }
    const animatedText = {
        color: textInterpolation,
    }

    const ViewHeader = useMemo(
        () => StyleSheet.flatten([UI.item, { justifyContent: 'flex-start', alignItems: 'flex-start', backgroundColor: styles.HIGHTLIGHT_PB }]),
        [styles],
    )

    const StyleTextT55 = useMemo(
        () =>
            StyleSheet.flatten([
                { fontSize: value.length > 8 ? 8 : fontSizes.tiny, fontWeight: fontWeights.medium, color },
                isTab && IOS ? {} : { lineHeight: fontSizes.normal },
            ]),
        [value, color],
    )

    if (type === 't55') {
        return (
            <View style={ViewHeader}>
                <Text numberOfLines={1} style={StyleTextT55}>
                    {value}
                </Text>
            </View>
        )
    } else
        return (
            <Animated.View
                style={[
                    { ...UI.item, ...bgAnimation },
                    type === 't31_incr' || type === 't32' || type === 't31_incr_PO' || type === 't32_PO' ? { width: dimensions.moderate(50, 0.25) } : null,
                    type === 't31_incr_per' || type === 't31_incr_per_PO' ? { width: dimensions.moderate(60, 0.25) } : null,
                    type === 't391' || type === 't3301' ? { width: dimensions.moderate(82, 0.25) } : null,
                ]}
            >
                <Animated.Text numberOfLines={1} style={{ fontSize: fontSizes.tiny, fontWeight: fontWeights.medium, color, ...animatedText }}>
                    {value}
                </Animated.Text>
            </Animated.View>
        )
})

const ButtonGoBackMemo = ({ goBack, styles }) => {
    return (
        <TouchableOpacity style={[UI.iconRotate, { backgroundColor: styles.PRIMARY__CONTENT__COLOR }]} onPress={goBack}>
            <Svg height={19} viewBox="0 0 18 19" width={18} xmlns="http://www.w3.org/2000/svg">
                <Rect
                    fill={styles.PRIMARY__CONTENT__COLOR}
                    height={14.556}
                    rx={0.55}
                    stroke={styles.PRIMARY__BG__COLOR}
                    transform="rotate(-35 2.009 5.983)"
                    width={7.556}
                    x={2.009}
                    y={5.983}
                />
                <Path
                    d="M3.752 5.253l3.164-2.215.268.384a.283.283 0 01-.069.393l-2.7 1.891a.283.283 0 01-.394-.07l-.269-.383z"
                    fill={styles.PRIMARY__BG__COLOR}
                    stroke={styles.PRIMARY__CONTENT__COLOR}
                    strokeWidth={0.027}
                />
                <Path
                    d="M6.317 17.26l.122-.085a.25.25 0 00-.01-.418l-.142-.088-.115-.071-.497-.307a.25.25 0 00-.381.21c-1.594-.345-2.849-1.673-3.146-3.358a.25.25 0 00.21-.385l-.505-.787a.25.25 0 00-.427.01l-.063.112-.086.149-.3.522a.25.25 0 00.216.375h.13c.314 2.136 1.915 3.84 3.967 4.205v.148a.25.25 0 00.392.207l.566-.392.069-.047zM12.185 3.421l-.122.085a.25.25 0 00.01.418l.142.088.115.07.497.308a.25.25 0 00.381-.21c1.594.344 2.849 1.673 3.147 3.358a.25.25 0 00-.21.384l.504.787a.25.25 0 00.427-.01l.064-.111.085-.15.3-.522a.25.25 0 00-.215-.374h-.131c-.314-2.136-1.915-3.84-3.967-4.205v-.149a.25.25 0 00-.391-.206l-.567.392-.069.047z"
                    fill={styles.PRIMARY__BG__COLOR}
                    stroke={styles.PRIMARY__CONTENT__COLOR}
                    strokeWidth={0.133}
                />
            </Svg>
        </TouchableOpacity>
    )
}
const ButtonGoBack = memo(ButtonGoBackMemo)

const ButtonOrderPriceboardMemo = ({ showOrderPriceboard, styles }) => {
    return (
        <TouchableOpacity style={[UI.iconRotate, { right: 100, backgroundColor: styles.ICON__FOURTH }]} onPress={showOrderPriceboard}>
            <Svg height={16} viewBox="0 0 16 16" width={16}>
                <Path
                    d="M15.333 12.667h-1.775A2.329 2.329 0 0011.333 11a2.33 2.33 0 00-2.224 1.667H.667a.667.667 0 000 1.333h8.442a2.329 2.329 0 002.224 1.667A2.33 2.33 0 0013.558 14h1.775a.667.667 0 100-1.333zm-4 1.666a1.001 1.001 0 010-2 1.001 1.001 0 010 2zM15.333 2h-1.775A2.33 2.33 0 0011.333.333 2.33 2.33 0 009.11 2H.667a.667.667 0 000 1.333h8.442A2.33 2.33 0 0011.333 5a2.33 2.33 0 002.225-1.667h1.775a.666.666 0 100-1.333zm-4 1.667a1.001 1.001 0 010-2 1.001 1.001 0 010 2zM15.333 7.333H6.891a2.33 2.33 0 00-2.224-1.666 2.33 2.33 0 00-2.225 1.666H.667a.667.667 0 000 1.334h1.775a2.33 2.33 0 002.225 1.666A2.33 2.33 0 006.89 8.667h8.442a.666.666 0 100-1.334zM4.667 9a1.001 1.001 0 010-2 1.001 1.001 0 010 2z"
                    fill={styles.PRIMARY__BG__COLOR}
                />
            </Svg>
        </TouchableOpacity>
    )
}
const ButtonOrderPriceboard = memo(ButtonOrderPriceboardMemo)

const UI = StyleSheet.create({
    container: { backgroundColor: '#fff', flex: 1, padding: 16, paddingTop: 30 },
    head: { backgroundColor: '#f1f8ff', height: 40 },
    iconRotate: {
        borderRadius: 18,
        bottom: 30,
        opacity: 0.7,
        padding: 10,
        position: 'absolute',
        right: 50,
        zIndex: 9,
    },
    item: {
        alignItems: 'flex-end',
        height: 28,
        justifyContent: 'center',
        padding: 6,
        paddingHorizontal: 5,
        width: dimensions.moderate(66, 0.25),
    },
    row: { height: 28 },
    row_pb: {
        flexDirection: 'row',
        flex: 1,
        paddingLeft: dimensions.moderate(66, 0.25),
    },
    text: { textAlign: 'center' },
    title: { backgroundColor: '#f6f8fa', flex: 1 },
    viewItem: {
        flexDirection: 'row',
        flex: 1,
    },
    view_t55_empty: {
        height: 28,
        width: dimensions.moderate(66, 0.25),
    },
    wrapper: { flexDirection: 'row' },
})
