import React, { useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { Linking, Text } from 'react-native'
import { Container, Content } from 'native-base'

import HeaderComponent from '../../../../components/header'
import { RowData } from '../../../../components/trading-component'
import { StoreContext } from '../../../../store'
import { fontSizes as fs, fontWeights as fw } from '../../../../styles'
import { FormatNumber } from '../../../../utils'

// Khai báo component
export default function DetailAnnouncementOrder({ navigation, route }) {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()
    const { params = {} } = route
    const { data = {} } = params
    // Start define all bussiness state
    // End define form bussiness state
    // -------------------------------------------   Dùng useEffect get các dữ liệu cần thiết còn thiếu
    // -------------------------------------------   Viết các hàm để set lại bussiness form state. Nên viết đúng một chuẩn duy nhất để dễ control

    // -------------------------------------------   Khai báo các hàm gửi (request) lên server
    // -------------------------------------------   Khai báo các hàm gửi (request) và nhận (handle respone) dữ liệu từ server

    return (
        <Container style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft
                navigation={navigation}
                title={t('order_detail')}
                titleAlgin="flex-start"
                transparent
            />
            <Content>
                <RowData textLeft={t('time')} textRight={data.c0} />
                <RowData textLeft={t('symbol_short')} textRight={data.c2} />
                <RowData textLeft={t('qty')} textRight={FormatNumber(data.c4)} />
                <RowData textLeft={t('price')} textRight={FormatNumber(data.c5)} />
                <RowData
                    rightColor={data.c3 === '2' ? styles.DOWN__COLOR : styles.UP__COLOR}
                    textLeft={t('sell_buy_tp')}
                    textRight={data.c3 === '1' ? t('buy_order') : t('sell_order')}
                />
                <RowData
                    textLeft={t('phone')}
                    // textRight={ data.c6}
                    // rightColor={styles.PRIMARY}
                    rightComponent={
                        <Text
                            style={{
                                fontSize: fs.normal,
                                color: styles.PRIMARY,
                                fontWeight: fw.semiBold,
                                fontStyle: 'italic',
                                textDecorationLine: 'underline',
                            }}
                            onPress={() => {
                                Linking.openURL(`tel:${data.c6}`)
                            }}
                        >
                            {data.c6}
                        </Text>
                    }
                />
            </Content>
        </Container>
    )
}
