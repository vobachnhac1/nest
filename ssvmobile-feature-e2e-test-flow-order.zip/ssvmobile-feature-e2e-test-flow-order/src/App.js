import React, { Component } from 'react'
import { I18nextProvider } from 'react-i18next'
import { AppState, LogBox, Text, TextInput } from 'react-native'
import DeviceInfo from 'react-native-device-info'
import { GestureHandlerRootView } from 'react-native-gesture-handler'
import changeNavigationBarColor from 'react-native-navigation-bar-color'
import Orientation from 'react-native-orientation-locker'
import { Portal } from 'react-native-paper'
import RNRestart from 'react-native-restart'
import { enableFreeze, enableScreens } from 'react-native-screens'
// import { SafeAreaProvider } from 'react-native-safe-area-context';
import Toast from 'react-native-toast-message' // Toast thông báo, warning thông thường
import AppModal from '@mts-components/appModal'
import moment from 'moment'
import { Root } from 'native-base'
import SyncStorage from 'sync-storage'

import CONFIG, { ENV } from './assets/config'
import HotUpdate from './components/code-push'
import { configToast } from './components/config-toast'
import NotifyOnesignal from './components/notify-onesignal'
import SecureScreen from './components/secure-screen'
import { PortalConsumer, PortalProvider } from './components/toaster'
import BackgroundService from './layouts/background-service'
import AppNavigation from './navigation/AppNavigation'
import StoreContext from './store'
import StoreTrading from './store-trading'
import i18n from './translate/i18n'
import { eventList, glb_sv, InfoStatistic, socket_sv, STORE_KEY } from './utils'
import Analytics from './utils/TrackingData/Analytics'

enableScreens()
// enableFreeze(true)
TextInput.defaultProps = TextInput.defaultProps || {}
TextInput.defaultProps.allowFontScaling = false
Text.defaultProps = Text.defaultProps || {}
Text.defaultProps.allowFontScaling = false

class App extends Component {
    constructor(props) {
        super(props)
        const activeCd = CONFIG.active_code

        if (activeCd && CONFIG[activeCd]) {
            glb_sv.activeCode = activeCd
            glb_sv.configInfo = CONFIG[activeCd]

            //-- time expire sau khi hệ thống bị rớt mạng (nếu trong time này thì hệ thống tự relogin)
            glb_sv.discexpire = CONFIG[activeCd].discexpire || 30
            glb_sv.latencyTime = CONFIG[activeCd].latencyTime || 100
            socket_sv.server_node_list = CONFIG[activeCd].server_node_list
        }

        this.timezone = new Date().getTimezoneOffset()

        // Get device infos
        DeviceInfo.getDeviceName()
            .then((res) => {
                glb_sv.deviceName = res || 'empty'
            })
            .catch((err) => null)

        DeviceInfo.getBuildId()
            .then((res) => {
                glb_sv.buildId = res || 'empty'
            })
            .catch((err) => null)

        DeviceInfo.getApiLevel().then((res) => {
            glb_sv.apiLevel = res || 'empty'
        })

        glb_sv.deviceBuildNumber = DeviceInfo.getBuildNumber()
        glb_sv.deviceID = DeviceInfo.getDeviceId()
        glb_sv.readableVersion = DeviceInfo.getReadableVersion()
        glb_sv.systemName = DeviceInfo.getSystemName()
        glb_sv.systemVersion = DeviceInfo.getSystemVersion()
        glb_sv.uniqueId = DeviceInfo.getUniqueId()
        // END Get device infos
    }

    componentDidMount() {
        this.initAppConfig()
        // Lắng nghe thay đổi về trạng thái network và authen
        this.eventConnect = glb_sv.eventConnect.subscribe((msg) => {
            // Xử lý trường hợp đổi server (node server)
            if (msg.type === socket_sv.connect_event.SWITCH_NODE_SERVER) {
                // Logic: disconnect toàn bộ các socket cũ, handleAppStateChange sẽ nhận được lỗi (event) disconnect và tự động connect lại
                console.log('SWITCH_NODE_SERVER')
                this.handleAppStateChange('change_node_server')
            }
            if (msg.type === eventList.DONE_CONFIG_NODE) {
                this.setConfigNodeServer()
                // Thực hiện thiết lập kết nối socket -----------------------------
                this.handleAppStateChange('active')
                // Lắng nghe các trạng thái của app -------------------------------
                AppState.addEventListener('change', this.handleAppStateChange)
            }
        })

        glb_sv.StatisticMarket.HSX = new InfoStatistic()
        glb_sv.StatisticMarket.HNX = new InfoStatistic()
        glb_sv.StatisticMarket.UPC = new InfoStatistic()
    }

    initAppConfig = async () => {
        Orientation.lockToPortrait()
        // Đổi màu tabar --------------------------------------------------
        // this.changeColorNavBar();
        // Khởi động store ------------------------------------------------
        await SyncStorage.init()
        console.log('AsyncStorage is ready!')
        // Set server config ----------------------------------------------
        const currentServer = SyncStorage.get(STORE_KEY.SERVER)
        if (typeof currentServer === 'number') {
            this.setConfigNodeServer()
            // Thực hiện thiết lập kết nối socket -----------------------------
            this.handleAppStateChange('active')
            // Lắng nghe các trạng thái của app -------------------------------
            AppState.addEventListener('change', this.handleAppStateChange)
        }
        glb_sv.commonEvent.next({ type: eventList.STORE_IS_READY })
        glb_sv.isStoreReady = true
    }

    componentWillUnmount() {
        this.eventConnect.unsubscribe()
        AppState.removeEventListener('change', this.handleAppStateChange)
    }

    changeColorNavBar = async () => {
        try {
            await changeNavigationBarColor('#000000', true)
        } catch (e) { }
    }

    setConfigNodeServer = () => {
        const activeCd = glb_sv.activeCode
        const node_server = SyncStorage.get(STORE_KEY.SERVER) || 0
        socket_sv.server_node_list = CONFIG[activeCd].server_node_list
        socket_sv.current_server_node = node_server
        socket_sv.url_stream = CONFIG[activeCd].server_node_list[node_server].stream_server.ip_address
        socket_sv.url_trading = CONFIG[activeCd].server_node_list[node_server].trading_server.ip_address
    }

    handleAppStateChange = (nextAppState, socket_nm) => {
        console.log('####################  handleAppStateChange: ', nextAppState)
        // --- Xử lý socket khi app active
        if (this.throttAppStateChange) clearTimeout(this.throttAppStateChange)
        this.throttAppStateChange = setTimeout(this.executeCode, 500, nextAppState, socket_nm)
        // --- Xử lý timeout connect sau khi login
        const endDay = moment()
            .endOf('day')
            .add(this.timezone + 420, 'minutes')
        const now = moment().add(this.timezone + 420, 'minutes')
        const timeEndDay = Math.round(endDay - now)
        if (nextAppState === 'inactive' || nextAppState === 'background') {
            if (this.timeoutConnectFlag) return
            let time = 30 * 60000
            if (glb_sv.timeoutConnect === 'timeout_1m') {
                time = 5 * 60000
            } else if (glb_sv.timeoutConnect === 'timeout_1h') {
                time = 60 * 60000
            } else if (glb_sv.timeoutConnect === 'timeout_2h') {
                time = 2 * 60 * 60000
            } else if (glb_sv.timeoutConnect === 'timeout_4h') {
                time = 4 * 60 * 60000
            } else if (glb_sv.timeoutConnect === 'timeout_8h') {
                time = 8 * 60 * 60000
            } else if (glb_sv.timeoutConnect === 'timeout_outday') {
                time = timeEndDay
            }

            if (glb_sv.authFlag) {
                if (timeEndDay < time) {
                    time = timeEndDay
                }
            } else time = timeEndDay

            this.timeoutConnectFlag = true
            this.runBackgroundTime = time
            this.runBackgroundTimer = moment().add(this.timezone + 420, 'minutes')
        } else {
            if (nextAppState === 'active') {
                this.timeoutConnectFlag = false
                if (moment().add(this.timezone + 420, 'minutes') - this.runBackgroundTimer > this.runBackgroundTime) {
                    this.restartApp()
                    return
                }
                glb_sv.commonEvent.next({ type: eventList.APPSTATE })
            }
        }
        // this.appState = nextAppState;
    }

    restartApp = async () => {
        // await SyncStorage.set(STORE_KEY.AutoLoginMode, true)
        RNRestart.Restart()
    }

    executeCode = (nextAppState, socket_nm = '') => {
        // Nếu app không active hoặc không phải xử lý net work thì bỏ qua
        if (!['active', 'change_node_server'].includes(nextAppState)) {
            return
        }
        //---------------------------------------------
        const AutoLoginMode = SyncStorage.get(STORE_KEY.AutoLoginMode) || false
        // let AutoLoginMode = false

        // Lần đầu tiên vào app
        if (glb_sv.LastConnectStatus === '' || glb_sv.LastConnectStatus === 'pre_auto_authen') {
            if (AutoLoginMode) {
                // Khởi tạo kết nối để auto Login
                socket_sv.establishSocketConnect('pre_auto_authen', { socket_nm: socket_nm, type: nextAppState })
            } else {
                // Khởi tạo kết nối thông thường
                socket_sv.establishSocketConnect('non_authen', { socket_nm: socket_nm, type: nextAppState })
            }
        } else {
            // Nếu không phải mở app lần đầu. Và app đang active thì kiểm tra
            // Trước đó đã đăng nhập thành công
            if (glb_sv.LastConnectStatus === 'authen_success' || glb_sv.LastConnectStatus === 'pre_relogin') {
                // Khởi tạo kết nối để đăng nhập lại
                socket_sv.establishSocketConnect('pre_relogin', { socket_nm: socket_nm, type: nextAppState })
            } else {
                // Trước đó chưa đăng nhập
                socket_sv.establishSocketConnect('non_authen', { socket_nm: socket_nm, type: nextAppState })
            }
        }
    }

    render() {
        return (
            <GestureHandlerRootView style={{ flex: 1 }}>
                <I18nextProvider i18n={i18n}>
                    <PortalProvider>
                        <StoreContext>
                            <StoreTrading>
                                <Portal.Host>
                                    <Root>
                                        <AppModal />
                                        <PortalConsumer gateName="toaster" />
                                        {/* <SafeAreaProvider> */}
                                        <AppNavigation />
                                        {/* </SafeAreaProvider> */}
                                        <BackgroundService />
                                        <NotifyOnesignal />
                                        <Toast config={configToast} ref={(ref) => Toast.setRef(ref)} />
                                        <SecureScreen />
                                        {ENV === 'CONFIG_TEST' ? <HotUpdate /> : null}
                                    </Root>
                                </Portal.Host>
                            </StoreTrading>
                        </StoreContext>
                    </PortalProvider>
                </I18nextProvider>
            </GestureHandlerRootView>
        )
    }
}

export default App
