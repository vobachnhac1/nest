import React, { useCallback, useContext, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import {
    ActivityIndicator,
    Animated,
    InteractionManager,
    Pressable,
    RefreshControl,
    ScrollView,
    StyleSheet,
    TouchableOpacity,
    Vibration,
    View,
} from 'react-native'
import { TouchableHighlight } from 'react-native-gesture-handler'
import { getBottomSpace, getStatusBarHeight } from 'react-native-iphone-x-helper'
import DateTimePickerModal from 'react-native-modal-datetime-picker'
import ToastGlobal from 'react-native-toast-message'
import ModalController from '@mts-components/appModal/modalControlller'
import throttle from 'lodash/throttle'
import moment from 'moment'
import { Button, DefaultTabBar, Row, Tab, TabHeading, Tabs, Toast } from 'native-base'
import SyncStorage from 'sync-storage'

import IconBack from '../../assets/images/common/ic_back.svg'
import { BlinkView, FocusAwareStatusBar, Text } from '../../basic-components'
// import RNBeep from 'react-native-a-beep';
import KeyboardCustom from '../../basic-components/custom-keyboard'
import Account from '../../components/account'
import NotAuthView from '../../components/notAuth-view'
import { StockInfo } from '../../components/place-order'
import { preventCompanyRender } from '../../hoc'
import { StoreContext } from '../../store'
import { StoreTrading } from '../../store-trading'
import { dimensions, fontSizes, fontWeights, IconSvg } from '../../styles'
import { eventList, FormatNumber, glb_sv, reqFunct, Screens, sendRequest, STORE_KEY, subcribeFunctStream } from '../../utils'
import ModalMarginBuyableInfo from '../place-order/modal-margin-buyable-info'
import ModalNormalBuyableInfo from '../place-order/modal-normal-buyable-info'
import SearchStock from '../place-order/search-stock'
import StockOwner from '../place-order/stock-owner'
import AdvOrderList from './GTCOrderList'
import ModalCheckDoubleOrder from './modal-check-double-order'
import ModalOrderConfirm from './modal-order-confirm'
import ModalSeasontp from './modal-seasontp'

const ServiceInfo = {
    ORDER_ADVANCE: {
        reqFunct: reqFunct.ORDER_ADVANCE,
        WorkerName: 'FOSxOrder',
        ServiceName: 'FOSxOrder_0509_1',
        Operation: 'I',
    },
    GET_SELL_ABLE_STOCK: {
        reqFunct: reqFunct.GET_SELL_ABLE_STOCK + 'GTCOrder',
        WorkerName: 'FOSqSellAble',
        ServiceName: 'FOSqSellAble',
        Operation: 'Q',
    },
    GET_BUY_ABLE: {
        reqFunct: reqFunct.GET_BUY_ABLE,
        WorkerName: 'FOSqBuyPower',
        ServiceName: 'FOSqBuyPower',
        Operation: 'Q',
    },
    GET_DAY_TRADING: {
        reqFunct: reqFunct.GET_DAY_TRADING,
        WorkerName: 'FOSqOrder01',
        ServiceName: 'FOSqOrder01_Common_0509_1',
        Operation: 'Q',
    },
    ORDER_GTC: {
        reqFunct: reqFunct.ORDER_GTC,
        WorkerName: 'FOSxOrder',
        ServiceName: 'FOSxOrder_0509_1',
        Operation: 'I',
    },
    GET_SELL_STOCK_LIST: {
        reqFunct: reqFunct.GET_SELL_STOCK_LIST + 'GTCOrder',
        WorkerName: 'FOSqAsset',
        ServiceName: 'FOSqAsset_1801_1',
        Operation: 'Q',
    },
}

const sessons = [
    {
        key: '1',
        name: 'ATO_session',
    },
    {
        key: '2',
        name: 'continuity_session_morning',
    },
    {
        key: '3',
        name: 'continuity_session_afternoon',
    },
    {
        key: '4',
        name: 'ATC_session',
    },
    {
        key: '5',
        name: 'priceboard_Close',
    },
]

function getSeasonTp(value) {
    const obj = sessons.find((e) => e.key === value)
    if (obj) return obj.name
    return ''
}

function GTCOrder({ navigation, route, setRefresh, refreshing }) {
    const { stockCodeAdv, plcOrdRefAdv, priceOrderAdv, priceRefAdv, qtyRefAdv } = route.params

    const stockCode = useRef(stockCodeAdv || '')
    const { styles, fractionPriceOrder, theme, language } = useContext(StoreContext)
    const { userInfo } = useContext(StoreTrading)

    const { t } = useTranslation()

    const [stock, setStock] = useState(
        glb_sv.StockMarket[stockCode.current] ? { ...glb_sv.StockMarket[stockCode.current] } : { TP: [], EP: [], t55: stockCode.current, PO: [] },
    )

    const throttled = useRef(
        throttle(() => {
            const newValue = glb_sv.StockMarket[stockCode.current]
            setStock(newValue ? { ...newValue } : { t55: stockCode.current, TP: [], EP: [], PO: [] })
        }, 100),
    )

    const timeOutFunct_plcOrd = useRef({
        getBuyAble: null,
        getSellAbleStock: null,
    })

    const plcOrdRef = useRef({
        sellbuy_tp: 'buy',
        orderTp: '01',
        buyPw: 0,
        sellPw: 0,
        maxtrad_qty: 0,
        maxtrad_qty_buy: 0,
        maxtrad_qty_sell: 0,
        stkOwn: 0,
        temp_fee: 0,
        exchange: '',
        orderTps: [],
        seasonTp: '',
        seasonTps: [],
        leverage_ratio: 0,
    })

    const stepPrice = useRef(10)
    const [stepQty, setStepQty] = useState(100)

    const [plcOrd, setPlcOrd] = useState({
        sellbuy_tp: 'buy',
        orderTp: '01',
        buyPw: 0,
        sellPw: 0,
        maxtrad_qty: 0,
        maxtrad_qty_buy: 0,
        maxtrad_qty_sell: 0,
        stkOwn: 0,
        temp_fee: 0,
        exchange: '',
        orderTps: [],
        seasonTp: '',
        seasonTps: [],
        leverage_ratio: 0,
    })

    const [price, setPrice] = useState(0)
    const priceRef = useRef(0)
    const [qty, setQty] = useState(0)
    const qtyRef = useRef(0)
    const timeoutChangePrice = useRef(null)

    const shakePrice = useRef(new Animated.Value(0))
    const shakeQty = useRef(new Animated.Value(0))

    const placeOrderFlag = useRef(false)
    const confirmOrderFlag = useRef(false)

    const [buyAbleInfo, setBuyAbleInfo] = useState({ keyUserInfo: userInfo, keyBuyAbleObj: null }) // Lưu thông tin sức mua theo tài khoản
    const [modalOrderCfm, setModalOrderCfm] = useState(false)
    const [modalCheckDoubleOrder, setModalCheckDoubleOrder] = useState(false)

    const [isNormalBuyableShow, setIsNormalBuyableShow] = useState(false)
    const [isMarginBuyableShow, setIsMarginBuyableShow] = useState(false)

    const timeoutChangeAccount = useRef(null)

    const scrollviewRef = useRef(null)

    const [modalKeyboard, setModalKeyboard] = useState(false)
    const [priceOrder, setPriceOrder] = useState('') // dùng để set giá ATC, ATO
    const priceOrderRef = useRef('')
    const [inputModal, setInputModal] = useState('')

    const [from_dt, setFromDt] = useState(glb_sv.objShareGlb.workDate ? moment(glb_sv.objShareGlb.workDate, 'YYYYMMDD').toDate() : moment().toDate())
    const [to_dt, setToDt] = useState(glb_sv.objShareGlb.workDate ? moment(glb_sv.objShareGlb.workDate, 'YYYYMMDD').toDate() : moment().toDate())

    const [isDatePickerFrom, setisDatePickerFrom] = useState(false)
    const [isDatePickerTo, setisDatePickerTo] = useState(false)
    const [visibleModalSessiontp, setVisibleModalSessiontp] = useState(false)
    const [loadingSendOrder, setLoadingSendOrder] = useState(false)
    const [passTrading, setPassTrading] = useState('')

    const nextDayAdvOrder = useRef(null)

    const [sellStkList, setSellStkList] = useState([])
    const [statusSellStkList, setStatusSellStkList] = useState('loading')
    const sellStkListRef = useRef([])
    const [isOddlot, setOddLot] = useState(false)
    const isOddlotRef = useRef(false)

    useEffect(() => {
        glb_sv.notifyOpened = null

        InteractionManager.runAfterInteractions(() => {
            if (stockCodeAdv) {
                plcOrdRef.current = { ...plcOrdRefAdv }
                setPlcOrd({ ...plcOrdRefAdv })

                if (priceOrderAdv) {
                    const t332 = glb_sv.StockMarket[stockCodeAdv]?.t332 || 0
                    handleChangePrice(t332)
                } else {
                    setPriceText(priceRefAdv ? priceRefAdv / 1000 + '' : '')
                    handleChangePrice(priceRefAdv)
                }
                setPriceOrder(priceOrderAdv)
                priceOrderRef.current = priceOrderAdv

                handleChangeQty(qtyRefAdv)

                glb_sv.StockMarket[stockCode.current]
                    ? changeOrdTP(stockCode.current, glb_sv.StockMarket[stockCode.current].U10)
                    : changeOrdTP(stockCode.current, '00')

                if (priceOrderAdv) {
                    const sessionId = plcOrdRef.current.seasonTps.find((e) => e.value === priceOrderAdv)
                    if (sessionId) {
                        handleChangeSessontp(sessionId.key, true)
                    }
                    const orderTp = plcOrdRef.current.orderTps.find((e) => e.name === priceOrderAdv)
                    if (orderTp) {
                        plcOrdRef.current.orderTp = orderTp.key
                        setPlcOrd({ ...plcOrdRef.current })
                    }
                }

                setTimeout(() => {
                    placeOrder()
                }, 500)
            }
            getDayTrading()
            getSellAbleList()
        })

        return () => {
            if (stockCode.current) subcribeFunctStream('UNSUB', ['MDDS|SI', 'MDDS|TP', 'MDDS|TO', 'MDDS|PO'], [stockCode.current])
        }
    }, [])

    useEffect(() => {
        if (timeoutChangeAccount.current) clearTimeout(timeoutChangeAccount.current)
        timeoutChangeAccount.current = setTimeout(() => {
            getBuyAble(stockCode.current)
            getSellAbleStock(stockCode.current)
        }, 0)
        const eventMarket = glb_sv.eventMarket.subscribe((msg) => {
            if (msg.type === eventList.SUB_STOCK && msg.message !== 'EP' && msg.msgKey === stockCode.current) {
                throttled.current()
            } else if (msg.type === eventList.REQ_AFTER_SUB_INFO && msg.value.includes(stockCode.current)) {
                if (glb_sv.StockMarket[stockCode.current]) {
                    throttled.current(glb_sv.StockMarket[stockCode.current])
                } else
                    setStock({
                        t55: stockCode.current,
                        TP: [],
                        PO: [],
                    })

                if (!plcOrdRef.current.orderTps.length) {
                    glb_sv.StockMarket[stockCode.current]
                        ? changeOrdTP(stockCode.current, glb_sv.StockMarket[stockCode.current].U10)
                        : changeOrdTP(stockCode.current, '00')
                }

                if (!priceRef.current) {
                    if (stockCode.current && glb_sv.configInfo.application_style.is_default_order_price) {
                        const newValue = glb_sv.StockMarket[stockCode.current] || { t55: stockCode.current, TP: [], EP: [], PO: [] }
                        const priceInit = newValue.t31 || newValue.U31 || newValue.t260
                        if (priceInit) {
                            if (plcOrdRef.current.orderTp !== '01' || (plcOrdRef.current.orderTp === '01' && priceRef.current && qtyRef.current)) {
                                changePrice()
                            } else handleChangePrice(priceInit)
                        } else changePrice()
                    } else {
                        changePrice()
                    }
                }
            } else if ((msg.type === eventList.RECONNECT_MARKET || msg.type === eventList.REQ_RE_GET_MKT_INF) && stockCode.current) {
                const U10 = glb_sv.StockMarket[stockCode.current] ? glb_sv.StockMarket[stockCode.current].U10 : ''
                if (isOddlotRef.current) {
                    subcribeFunctStream('SUB', ['MDDS|SI', U10 === '01' ? 'MDDS|TO' : 'MDDS|PO'], [stockCode.current])
                } else {
                    subcribeFunctStream('SUB', ['MDDS|SI', 'MDDS|TP'], [stockCode.current])
                }
            }
        })

        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.NOTIFY_SERVER) {
                const message = msg.data
                if (
                    message.MsgTp === 'ORD_NEW' ||
                    message.MsgTp === 'ORD_REJ' ||
                    message.MsgTp === 'ORD_MTH' ||
                    message.MsgTp === 'ORD_CNL' ||
                    message.MsgTp === 'ORD_MOD' ||
                    message.MsgTp === 'ORD_ADV' ||
                    message.MsgTp === 'ORD_REJ8' ||
                    message.MsgTp === 'MSS_ORD_OK' ||
                    message.MsgTp === 'MSS_ORD_ERR'
                ) {
                    setTimeout(() => {
                        getBuyAble(stockCode.current)
                        getSellAbleStock(stockCode.current)
                    }, 100)
                }
            }
        })

        return () => {
            eventMarket.unsubscribe()
            commonEvent.unsubscribe()
            if (timeoutChangeAccount.current) clearTimeout(timeoutChangeAccount.current)
            if (timeOutFunct_plcOrd.current.getBuyAble) clearTimeout(timeOutFunct_plcOrd.current.getBuyAble)
            if (timeOutFunct_plcOrd.current.getSellAbleStock) clearTimeout(timeOutFunct_plcOrd.current.getSellAbleStock)
            throttled.current.cancel()
        }
    }, [userInfo])

    const startShake = useCallback((type) => {
        Animated.sequence([
            Animated.timing(type, { toValue: 10, duration: 50, useNativeDriver: true }),
            Animated.timing(type, { toValue: -10, duration: 50, useNativeDriver: true }),
            Animated.timing(type, { toValue: 10, duration: 50, useNativeDriver: true }),
            Animated.timing(type, { toValue: 0, duration: 50, useNativeDriver: true }),
        ]).start()
    }, [])

    useLayoutEffect(() => {
        if (stock.U10 === '01') {
            if (price < 10000) {
                if (stepPrice.current !== 10) stepPrice.current = 10
            }
            if (price >= 10000 && price < 50000) {
                if (stepPrice.current !== 50) stepPrice.current = 50
            }
            if (price >= 50000) {
                if (stepPrice.current !== 100) stepPrice.current = 100
            }
        } else if (stock.U10) {
            if (stepPrice.current !== 100) stepPrice.current = 100
        }
    }, [price, stock.U10])

    const decrPrice = () => {
        if (priceRef.current === 10000) stepPrice.current = 10
        if (priceRef.current === 50000) stepPrice.current = 50
        const newPrice = priceRef.current - stepPrice.current
        priceRef.current = newPrice
        setPrice(newPrice)
        if (timeoutChangePrice.current) clearTimeout(timeoutChangePrice.current)
        timeoutChangePrice.current = setTimeout(() => {
            changePrice()
        }, 100)
    }

    const incrPrice = () => {
        if (priceRef.current === 10000) stepPrice.current = 50
        if (priceRef.current === 50000) stepPrice.current = 100
        const newPrice = priceRef.current + stepPrice.current
        priceRef.current = newPrice
        setPrice(newPrice)
        if (timeoutChangePrice.current) clearTimeout(timeoutChangePrice.current)
        timeoutChangePrice.current = setTimeout(() => {
            changePrice()
        }, 100)
    }

    const handleChangePrice = useCallback((newPrice, type) => {
        if (newPrice === 777777710000) {
            const stockRef = glb_sv.StockMarket[stockCode.current] || { t332: 0 }
            handleChangePrice(stockRef.U29 || stockRef.t332, true)
            setPriceOrder('ATO')
            plcOrdRef.current.orderTps = [
                {
                    key: '03',
                    name: 'ATO',
                },
            ]
            plcOrdRef.current.orderTp = '03'
            plcOrdRef.current.seasonTp = '1'
            setPlcOrd({ ...plcOrdRef.current })
            return
        } else if (newPrice === 777777720000) {
            const stockRef = glb_sv.StockMarket[stockCode.current] || { t332: 0 }
            handleChangePrice(stockRef.U29 || stockRef.t332, true)
            setPriceOrder('ATC')
            plcOrdRef.current.orderTps = [
                {
                    key: '04',
                    name: 'ATC',
                },
            ]
            plcOrdRef.current.seasonTp = '4'
            plcOrdRef.current.orderTp = '04'
            setPlcOrd({ ...plcOrdRef.current })
            return
        }
        setPriceOrder('')
        priceOrderRef.current = ''
        plcOrdRef.current.orderTp = '01'
        setPlcOrd({ ...plcOrdRef.current })
        const newPrc = Number(String(newPrice).replace(/\D/g, ''))
        if (newPrc === priceRef.current) return

        priceRef.current = newPrc
        setPrice(priceRef.current)
        if (timeoutChangePrice.current) clearTimeout(timeoutChangePrice.current)
        timeoutChangePrice.current = setTimeout(() => {
            changePrice()
        }, 100)
    }, [])

    const decrQty = () => {
        let newQty = qtyRef.current - stepQty
        if (newQty < 0) newQty = 0
        if (qtyRef.current === newQty) return
        qtyRef.current = newQty
        setQty(newQty)
    }

    const incrQty = () => {
        const newQty = qtyRef.current + stepQty
        qtyRef.current = newQty
        setQty(newQty)
    }

    const handleChangeQty = useCallback((newQty, type) => {
        const qty = Number(String(newQty).replace(/\D/g, ''))
        // if (Math.floor(1109615822 / price) < qty) qty = Math.floor(1109615822 / price)
        if (qty === qtyRef.current) return
        qtyRef.current = qty
        setQty(qty)
    }, [])

    const changeStock = (stk, type) => {
        if (stk === stockCode.current) {
        } else {
            if (stockCode.current) {
                subcribeFunctStream('UNSUB', ['MDDS|SI', 'MDDS|TP', 'MDDS|TO', 'MDDS|PO'], [stockCode.current])
            }
            stockCode.current = stk
            const U10 = glb_sv.StockMarket[stockCode.current] ? glb_sv.StockMarket[stockCode.current].U10 : ''
            if (isOddlotRef.current) {
                subcribeFunctStream('SUB', ['MDDS|SI', U10 === '01' ? 'MDDS|TO' : 'MDDS|PO'], [stockCode.current])
            } else {
                subcribeFunctStream('SUB', ['MDDS|SI', 'MDDS|TP'], [stockCode.current])
            }

            getBuyAble(stockCode.current)
            getSellAbleStock(stockCode.current)

            glb_sv.StockMarket[stockCode.current]
                ? changeOrdTP(stockCode.current, glb_sv.StockMarket[stockCode.current].U10)
                : changeOrdTP(stockCode.current, '00')

            if (stockCode.current && glb_sv.configInfo.application_style.is_default_order_price) {
                const newValue = glb_sv.StockMarket[stockCode.current] || { t55: stockCode.current, TP: [], EP: [], PO: [] }
                const priceInit = newValue.t31 || newValue.U31 || newValue.t260
                if (priceInit) handleChangePrice(priceInit)
                else handleChangePrice(0)
            } else handleChangePrice(0)

            handleChangeQty(0)
            plcOrdRef.current.orderTp = '01'
            setPlcOrd({ ...plcOrdRef.current })

            throttled.current()
        }
        if (scrollviewRef.current) scrollviewRef.current.scrollTo({ y: 0, animated: true })
    }

    const getBuyAble = (t55) => {
        if (!userInfo.actn_curr) {
            ToastGlobal.show({
                type: 'warning',
                text2: t('warning_account_is_empty'),
            })
            return
        }

        const acntNo = userInfo.actn_curr
        const subNo = userInfo.sub_curr
        const InputParams = [acntNo, subNo, t55, '0000']
        sendRequest(ServiceInfo.GET_BUY_ABLE, InputParams, buyAble_ResultProc, true, getBuyAbleTimeout, '', 0, 'equal_service')
        plcOrdRef.current.buyPw = 0
        plcOrdRef.current.maxtrad_qty_buy = 0
        setPlcOrd({ ...plcOrdRef.current })
    }

    const getBuyAbleTimeout = () => {}

    const buyAble_ResultProc = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            setBuyAbleInfo({ keyUserInfo: null, keyBuyAbleObj: null })
            return
        } else {
            let jsonBuyAble = []
            try {
                if (!message.Data) return

                jsonBuyAble = JSON.parse(message.Data)[0]
                plcOrdRef.current.buyPw = Number(jsonBuyAble.c0) + Number(jsonBuyAble.c6) || 0
                plcOrdRef.current.temp_fee = jsonBuyAble.c7 || 0
                plcOrdRef.current.leverage_ratio = jsonBuyAble.c15 * 100
                setPlcOrd({ ...plcOrdRef.current })
                changePrice()
                setBuyAbleInfo({ keyUserInfo: userInfo, keyBuyAbleObj: jsonBuyAble })
            } catch (err) {
                console.log('buyAble_ResultProc', err)
                setBuyAbleInfo({ keyUserInfo: null, keyBuyAbleObj: null })
            }
        }
    }

    const showBuyableModal = () => {
        // console.log('buyAbleInfo keyUserInfo: ', buyAbleInfo.keyUserInfo)
        // console.log('buyAbleInfo keyBuyAbleObj: ', buyAbleInfo.keyBuyAbleObj)
        // console.log('userInfo', userInfo);
        // console.log('acntNoInfo', glb_sv.objShareGlb['acntNoInfo']);
        const dataSub = glb_sv.objShareGlb.acntNoInfo.find((e) => e.AcntNo + e.SubNo === userInfo.actn_curr + userInfo.sub_curr)
        if (dataSub) {
            if (dataSub.MarginYN) {
                setIsMarginBuyableShow(true)
            } else {
                setIsNormalBuyableShow(true)
            }
        }
    }

    const getSellAbleStock = (stkCd) => {
        if (!stkCd) return

        if (!userInfo.actn_curr) {
            ToastGlobal.show({
                type: 'warning',
                text2: t('warning_account_is_empty'),
            })
            return
        }

        const acntNo = userInfo.actn_curr
        const subNo = userInfo.sub_curr
        const InputParams = ['02', 'today', acntNo, subNo, stkCd]
        sendRequest(ServiceInfo.GET_SELL_ABLE_STOCK, InputParams, sellAble_ResultProc, true, getSellAbleStockTimeout, '', 0, 'equal_service')

        plcOrdRef.current.sellPw = 0
        plcOrdRef.current.stkOwn = 0
        plcOrdRef.current.maxtrad_qty_sell = 0
        setPlcOrd({ ...plcOrdRef.current })
    }

    const getSellAbleStockTimeout = () => {}

    const sellAble_ResultProc = (reqInfoMap, message) => {
        // if (timeOutFunct_plcOrd.current.getSellAbleStock) clearTimeout(timeOutFunct_plcOrd.current.getSellAbleStock)
        if (Number(message.Result) === 0) {
            console.log('sellAble_ResultProc', message)
            return
        } else {
            let jsonsellAb
            try {
                if (message.Data === '') return
                jsonsellAb = JSON.parse(message.Data)
                plcOrdRef.current.sellPw = jsonsellAb[0].c3
                plcOrdRef.current.stkOwn = jsonsellAb[0].c2
                plcOrdRef.current.maxtrad_qty_sell = jsonsellAb[0].c3
                setPlcOrd({ ...plcOrdRef.current })
            } catch (err) {
                console.log('sellAble_ResultProc', err)
            }
        }
    }

    const getSellAbleList = () => {
        console.log('getSellAbleList')
        if (!userInfo.actn_curr) {
            ToastGlobal.show({
                type: 'warning',
                text2: t('warning_account_is_empty'),
            })
            return
        }

        const acntNo = userInfo.actn_curr
        const subNo = userInfo.sub_curr
        const InputParams = ['02', acntNo, subNo]
        sendRequest(ServiceInfo.GET_SELL_STOCK_LIST, InputParams, getSellAbleList_ResultProc, true, getSellAbleListTimeout, '', 0, 'equal_service')
        sellStkListRef.current = []
    }

    const getSellAbleListTimeout = () => {
        setStatusSellStkList('error')
    }

    const getSellAbleList_ResultProc = (reqInfoMap, message) => {
        // console.log("getSellAbleList_ResultProc -> message", message)
        if (Number(message.Result) === 0) {
            setStatusSellStkList('error')
            return
        } else {
            let jsonSellAble
            try {
                jsonSellAble = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {
                console.log('getSellAbleList_ResultProc', err)
                return
            }

            setStatusSellStkList('done')

            sellStkListRef.current = filterSoldStock(sellStkListRef.current.concat(jsonSellAble))
            if (Number(message.Packet) <= 0) {
                setSellStkList([...sellStkListRef.current])
                if (stockCode.current) {
                    const dataSellAble = sellStkListRef.current.find((e) => e.c2 === stockCode.current)
                    if (dataSellAble) {
                        plcOrdRef.current.maxtrad_qty_sell = dataSellAble.c4
                        setPlcOrd({ ...plcOrdRef.current })
                    } else {
                        plcOrdRef.current.maxtrad_qty_sell = 0
                        setPlcOrd({ ...plcOrdRef.current })
                    }
                }
            }
        }
    }

    const changePrice = () => {
        const stockInfo = glb_sv.StockMarket[stockCode.current]
        let priceCheck = priceRef.current || (stockInfo ? stockInfo.U30 || stockInfo.t333 : 0)
        const buyPw = plcOrdRef.current.buyPw
        if (plcOrdRef.current.orderTp !== '01') {
            priceCheck = stockInfo ? stockInfo.U29 || stockInfo.t332 : 0
        }
        if (!priceCheck || !buyPw) {
            plcOrdRef.current.maxtrad_qty_buy = 0
            setPlcOrd({ ...plcOrdRef.current })
        } else {
            const QtyVal = calc_max_buyqty(priceCheck, buyPw, plcOrdRef.current.temp_fee || 0)
            plcOrdRef.current.maxtrad_qty_buy = Math.floor(QtyVal)
            setPlcOrd({ ...plcOrdRef.current })
        }
    }

    const calc_max_buyqty = (price, buypw, fee_rto) => {
        return buypw / (price + (fee_rto / 100) * price)
    }

    const handleChangeSessontp = (sessionId, notSetPrice) => {
        if (!notSetPrice) {
            handleChangePrice(0)
            plcOrdRef.current.orderTp = '01'
            setPlcOrd({ ...plcOrdRef.current })
        }

        plcOrdRef.current.seasonTp = sessionId
        setVisibleModalSessiontp(false)
        if (!stockCode.current) {
            plcOrdRef.current.seasonTp = '01'
            plcOrdRef.current.seasonTps = []
            plcOrdRef.current.orderTp = ''
            plcOrdRef.current.orderTps = []
            setPlcOrd({ ...plcOrdRef.current })
            return
        }
        let sanGd = stock.U10,
            hoseOrdTp,
            hnxOrdTp,
            upcOrdTp
        if (sanGd === '01') {
            if (sessionId === '1') {
                hoseOrdTp = [
                    {
                        key: '03',
                        name: 'ATO',
                    },
                ]
            } else if (sessionId === '2' || sessionId === '3') {
                hoseOrdTp = [
                    {
                        key: '02',
                        name: 'MP',
                    },
                ]
            } else if (sessionId === '4') {
                hoseOrdTp = [
                    {
                        key: '04',
                        name: 'ATC',
                    },
                ]
            }
            plcOrdRef.current.orderTp = ''
            plcOrdRef.current.orderTps = hoseOrdTp
            setPlcOrd({ ...plcOrdRef.current })
        }
        // ---------- San HNX --------------------
        if (sanGd === '03') {
            if (sessionId === '2' || sessionId === '3') {
                hnxOrdTp = [
                    {
                        key: '06',
                        name: 'MOK',
                    },
                    {
                        key: '07',
                        name: 'MAK',
                    },
                    {
                        key: '08',
                        name: 'MTL',
                    },
                ]
            } else if (sessionId === '4') {
                hnxOrdTp = [
                    {
                        key: '04',
                        name: 'ATC',
                    },
                ]
            } else if (sessionId === '5') {
                hnxOrdTp = [
                    {
                        key: '15',
                        name: 'PLO',
                    },
                ]
            }
            if (sessionId === '5') {
                plcOrdRef.current.orderTp = '15'
            } else {
                plcOrdRef.current.orderTp = '01'
            }
            plcOrdRef.current.orderTps = hnxOrdTp
            setPlcOrd({ ...plcOrdRef.current })
        }
        // ---------- San UPC --------------------
        if (sanGd === '05') {
            upcOrdTp = []
            plcOrdRef.current.orderTp = '01'
            plcOrdRef.current.orderTps = upcOrdTp
            setPlcOrd({ ...plcOrdRef.current })
        }
    }

    const changeOrdTP = (stkCdOt, U10) => {
        if (!stkCdOt) {
            plcOrdRef.current.orderTps = []
            plcOrdRef.current.orderTp = ''
            plcOrdRef.current.seasonTp = ''
            plcOrdRef.current.seasonTps = []
            setPlcOrd({ ...plcOrdRef.current })
            return
        }
        let sanGd = U10 || stock.U10 || glb_sv.StockMarket[stkCdOt]?.U10,
            hnxOrdTp = [],
            upcOrdTp = [],
            hsxOrdTp = []

        if (sanGd === '03') {
            hnxOrdTp = [
                {
                    key: '06',
                    name: 'MOK',
                },
                {
                    key: '07',
                    name: 'MAK',
                },
                {
                    key: '08',
                    name: 'MTL',
                },
            ]
            const hnxSeasondTp = [
                {
                    key: '2',
                    name: 'continuity_session_morning',
                },
                {
                    key: '3',
                    name: 'continuity_session_afternoon',
                },
                {
                    key: '4',
                    name: 'ATC_session',
                    value: 'ATC',
                },
                {
                    key: '5',
                    name: 'priceboard_Close',
                    value: 'PLO',
                },
            ]
            plcOrdRef.current.orderTps = hnxOrdTp
            plcOrdRef.current.orderTp = '01'
            plcOrdRef.current.seasonTp = '2'
            plcOrdRef.current.seasonTps = hnxSeasondTp
            setPlcOrd({ ...plcOrdRef.current })
        } else if (sanGd === '05') {
            upcOrdTp = []
            const upcSeasonTp = [
                {
                    key: '2',
                    name: 'continuity_session_morning',
                },
                {
                    key: '3',
                    name: 'continuity_session_afternoon',
                },
            ]
            plcOrdRef.current.orderTps = upcOrdTp
            plcOrdRef.current.orderTp = '01'
            plcOrdRef.current.seasonTp = '2'
            plcOrdRef.current.seasonTps = upcSeasonTp
            setPlcOrd({ ...plcOrdRef.current })
        } else if (sanGd === '01') {
            hsxOrdTp = [
                {
                    key: '03',
                    name: 'ATO',
                },
            ]
            const hoseSeasondTp = [
                {
                    key: '1',
                    name: 'ATO_session',
                    value: 'ATO',
                },
                {
                    key: '2',
                    name: 'continuity_session_morning',
                    value: 'MP',
                },
                {
                    key: '3',
                    name: 'continuity_session_afternoon',
                    value: 'MP',
                },
                {
                    key: '4',
                    name: 'ATC_session',
                    value: 'ATC',
                },
            ]
            plcOrdRef.current.orderTps = hsxOrdTp
            plcOrdRef.current.orderTp = '01'
            plcOrdRef.current.seasonTp = '1'
            plcOrdRef.current.seasonTps = hoseSeasondTp
            setPlcOrd({ ...plcOrdRef.current })
        } else {
            plcOrdRef.current.orderTps = []
            plcOrdRef.current.orderTp = '01'
            plcOrdRef.current.seasonTp = ''
            plcOrdRef.current.seasonTps = []
            setPlcOrd({ ...plcOrdRef.current })
        }
    }

    // send order
    const placeOrder = () => {
        if (placeOrderFlag.current) return
        hideModalKeyboard()
        if (!stockCode.current) {
            glb_sv.commonEvent.next({ type: eventList.FOCUS_SEARCH_PLACE_ORDER })
            return
        }
        if (plcOrdRef.current.orderTp === '01' && !price) {
            startShake(shakePrice.current)
            Vibration.vibrate()
            setModalKeyboard(true)
            setPriceText('')
            setInputModal('price')
            return
        }
        if (plcOrdRef.current.orderTp === '') {
            startShake(shakePrice.current)
            Vibration.vibrate()
            setModalKeyboard(true)
            setInputModal('price')
            scrollviewRef.current?.scrollTo({ y: 200, animated: true })
            return
        }
        if (!qtyRef.current) {
            startShake(shakeQty.current)
            Vibration.vibrate()
            setModalKeyboard(true)
            setInputModal('qty')
            return
        }

        if (!glb_sv.isConnectApp) {
            Toast.show({
                text: t('Can_not_connected_to_server_plz_check_your_network'),
                type: 'warning',
            })
            return
        }

        if (!userInfo.actn_curr) {
            ToastGlobal.show({
                type: 'warning',
                text2: t('warning_account_is_empty'),
            })
            return
        }

        if (plcOrdRef.current.orderTp === '01') {
            plcOrdRef.current.tradAmount = price * qty
            plcOrdRef.current.fee_buy = Math.ceil(((plcOrdRef.current.temp_fee || 0) * plcOrdRef.current.tradAmount) / 100)
            plcOrdRef.current.temp_pay = plcOrdRef.current.fee_buy + plcOrdRef.current.tradAmount
            setPlcOrd({ ...plcOrdRef.current })
        } else {
            plcOrdRef.current.tradAmount = stock.t332 * qty
            setPlcOrd({ ...plcOrdRef.current })
        }

        if (!glb_sv.checkOtp(navigation, placeOrder)) {
            return
        }
        placeOrderFlag.current = true

        if (
            glb_sv.lastAdvOrdInfo.acntNo &&
            glb_sv.lastAdvOrdInfo.acntNo === userInfo.actn_curr + '.' + userInfo.sub_curr &&
            glb_sv.lastAdvOrdInfo.sb_tp === plcOrd.sellbuy_tp &&
            glb_sv.lastAdvOrdInfo.stkCode === stock.t55 &&
            glb_sv.lastAdvOrdInfo.orderTp === plcOrd.orderTp &&
            glb_sv.lastAdvOrdInfo.price === price &&
            glb_sv.lastAdvOrdInfo.qty === qty
        ) {
            // -- open modal confirm send lệnh
            setModalCheckDoubleOrder(true)
        } else {
            setModalOrderCfm(true)
            confirmOrderFlag.current = false
        }
    }

    const hanldeCheckDoubOrder = (cfm) => {
        setModalCheckDoubleOrder(false)
        if (!cfm) {
            placeOrderFlag.current = false
            return
        }
        InteractionManager.runAfterInteractions(() => {
            setTimeout(() => {
                setModalOrderCfm(true)
                confirmOrderFlag.current = false
            }, 0)
        })
    }

    const onNormalBuyableModalConfirm = () => {
        setIsNormalBuyableShow(false)
    }

    const onMarginBuyableModalConfirm = () => {
        setIsMarginBuyableShow(false)
    }

    const onHideModalCheckDoub = () => {
        if (placeOrderFlag.current) {
            setModalOrderCfm(true)
            confirmOrderFlag.current = false
        }
    }

    const confirmOrder = (cfmTp) => {
        if (!userInfo.actn_curr) {
            ToastGlobal.show({
                type: 'warning',
                text2: t('warning_account_is_empty'),
            })
            return
        }

        if (confirmOrderFlag.current) return
        confirmOrderFlag.current = true

        if (cfmTp === 'N') {
            placeOrderFlag.current = false
            setModalOrderCfm(false)
            setPassTrading('')
            return
        }
        setModalOrderCfm(false)
        sendGtcOrder()
    }

    const sendGtcOrder = () => {
        const acntNo = userInfo.actn_curr
        const subNo = userInfo.sub_curr

        const sellbuy_tp = plcOrd.sellbuy_tp === 'buy' ? '1' : '2'
        const orderTp = plcOrd.orderTp
        const stkCd = stock.t55

        const effect_dt = moment(from_dt).format('YYYYMMDD')
        const exp_dt = moment(to_dt).format('YYYYMMDD')
        const seasonTp = plcOrd.seasonTp

        const priceOrderCfm = orderTp === '01' ? price : '0'

        const InputParams = [acntNo, subNo, '', stkCd, sellbuy_tp, qty + '', priceOrderCfm + '', '0000', effect_dt, exp_dt, orderTp, seasonTp, '', 'G']
        setLoadingSendOrder(true)
        sendRequest(ServiceInfo.ORDER_GTC, InputParams, handleGtcOrder, true, sendGtcOrderTimeout)
    }

    const sendGtcOrderTimeout = () => {
        placeOrderFlag.current = false
        confirmOrderFlag.current = false
        setLoadingSendOrder(false)
        Toast.show({
            text: t('request_hanlde_not_success_try_again'),
            type: 'warning',
            position: 'bottom',
        })
    }

    const handleGtcOrder = (reqInfoMap, message) => {
        placeOrderFlag.current = false
        confirmOrderFlag.current = false
        setLoadingSendOrder(false)
        if (Number(message.Result) === 0) {
            if (message.Code == 'XXXXX5' || message.Code === '080063') {
                // navigation.navigate(Screens.ALERT_MODAL, {
                // icon: <IconSvg.ErrorIcon color={styles.WARN__COLOR} />,
                // title: t('common_notify'),
                // content: t('request_hanlde_not_success_try_again'),
                // typeColor: styles.WARN__COLOR,
                // })
                ModalController.showModal({
                    icon: <IconSvg.ErrorIcon color={styles.WARN__COLOR} />,
                    title: t('common_notify'),
                    content: t('request_hanlde_not_success_try_again'),
                    typeColor: styles.WARN__COLOR,
                })
            } else if (glb_sv.otpCases.includes(message.Code)) {
                glb_sv.objShareGlb.sessionInfo.Otp = ''

                let data
                try {
                    data = JSON.parse(message.Data)[0]
                } catch (error) {
                    return
                }

                const otp_Type = Number(data.c1)
                const expTimeOtp = Number(data.c2)
                let reqOtpMessage = 'OTP'
                if (Number(data.c1) === 2) {
                    //-- dạng thẻ ma trận
                    reqOtpMessage = 'OTP ' + data.c3
                }
                navigation.navigate(Screens.OTP_MODAL, {
                    time: expTimeOtp,
                    type: reqOtpMessage,
                    hasOTP: false,
                    otp_Type,
                    msg: message.Message,
                    functCallback: sendGtcOrder,
                })
            } else {
                // navigation.navigate(Screens.ALERT_MODAL, {
                // icon: <IconSvg.ErrorIcon color={styles.WARN__COLOR} />,
                // title: t('common_notify'),
                // content: message.Message,
                // typeColor: styles.WARN__COLOR,
                // })
                ModalController.showModal({
                    icon: <IconSvg.ErrorIcon color={styles.WARN__COLOR} />,
                    title: t('common_notify'),
                    content: message.Message,
                    typeColor: styles.WARN__COLOR,
                })
            }
        } else {
            glb_sv.lastAdvOrdInfo.acntNo = userInfo.actn_curr + '.' + userInfo.sub_curr
            glb_sv.lastAdvOrdInfo.sb_tp = plcOrd.sellbuy_tp
            glb_sv.lastAdvOrdInfo.stkCode = stock.t55
            glb_sv.lastAdvOrdInfo.orderTp = plcOrd.orderTp
            glb_sv.lastAdvOrdInfo.price = price
            glb_sv.lastAdvOrdInfo.qty = qty

            handleChangeQty(0)
            handleChangePrice(0)

            glb_sv.commonEvent.next({ type: eventList.REFRESH_ADVORDER_LIST })

            // navigation.navigate(Screens.ALERT_MODAL, {
            // icon: <IconSvg.ErrorIcon color={styles.PRIMARY} />,
            // title: t('common_notify'),
            // content: message.Message,
            // typeColor: styles.PRIMARY,
            // })
            ModalController.showModal({
                icon: <IconSvg.ErrorIcon color={styles.PRIMARY} />,
                title: t('common_notify'),
                content: message.Message,
                typeColor: styles.PRIMARY,
            })
        }
    }

    const _handleClear = () => {
        // IOS ? RNBeep.PlaySysSound(1104) : null;
        if (inputModal === 'price') {
            handleChangePrice(0)
            plcOrdRef.current.orderTp = '01'
            setPlcOrd({ ...plcOrdRef.current })
        } else {
            handleChangeQty(0)
        }
    }

    const _handleDelete = () => {
        // IOS ? RNBeep.PlaySysSound(1104) : null;
        if (inputModal === 'price') {
            if (priceOrder) {
                handleChangePrice(0)
                plcOrdRef.current.orderTp = '01'
                setPlcOrd({ ...plcOrdRef.current })
            } else {
                if (fractionPriceOrder) {
                    setPriceText((value) => value.slice(0, value.length - 1))
                    return
                }
                handleChangePrice(String(price).slice(0, String(price).length - 1))
            }
        } else handleChangeQty(String(qty).slice(0, String(qty).length - 1))
    }

    const [priceText, setPriceText] = useState('')

    const _handleKeyPress = (key) => {
        // IOS ? RNBeep.PlaySysSound(1104) : null;
        if (inputModal === 'price') {
            if (fractionPriceOrder) {
                if (key === '.' && priceText.includes('.')) return
                setPriceText((value) => value + key)
                handleChangePrice(Number(((priceText + key) * 1000).toFixed(0)))
                return
            }
            handleChangePrice(priceOrder ? key : String(price) + key)
            plcOrdRef.current.orderTp = '01'
            setPlcOrd({ ...plcOrdRef.current })
        } else handleChangeQty(qty + key)
    }

    const setPriceOrderTp = (item) => {
        handleChangePrice(stock.t332)
        setPriceOrder(item.name)
        priceOrderRef.current = item.name
        setInputModal('qty')
        plcOrdRef.current.orderTp = item.key
        setPlcOrd({ ...plcOrdRef.current })
        // IOS ? RNBeep.PlaySysSound(1104) : null;
        scrollviewRef.current?.scrollTo({ y: 300, animated: true })
    }

    const hideModalKeyboard = () => {
        if (modalKeyboard) {
            setModalKeyboard(false)
        } else glb_sv.commonEvent.next({ type: eventList.HIDE_SEARCH_STOCK })
    }

    const changeSearchStock = () => {
        navigation.navigate(Screens.SEARCH_STOCK, { actionType: 'PLACE_ORDER', changeStock })
    }

    const hideDatePicker = () => {
        setisDatePickerFrom(false)
        setisDatePickerTo(false)
    }

    const onRefresh = () => {
        if (refreshing) return
        setRefresh(true)
        getBuyAble(stockCode.current) // Lấy sức mua
        getSellAbleList()
        setTimeout(() => {
            setRefresh(false)
        }, 300)
    }

    const getDayTrading = () => {
        const InputParams = ['']
        sendRequest(ServiceInfo.GET_DAY_TRADING, InputParams, getDayTradingResult, true, getDayTradingTimeout, '', 0, 'equal_service')
        nextDayAdvOrder.current = null
    }

    const getDayTradingTimeout = () => {}

    const getDayTradingResult = (reqInfoMap, message) => {
        console.log('getDayTradingResult -> message', message)
        if (Number(message.Result) === 0) {
            return
        } else {
            let json
            try {
                json = JSON.parse(message.Data)
                const workDt = json[0].c0
                if (!workDt || workDt.length !== 8) return

                nextDayAdvOrder.current = moment(workDt, 'YYYYMMDD').toDate()

                setFromDt(nextDayAdvOrder.current)
                setToDt(nextDayAdvOrder.current)

                // if (stockCode.current) {
                //     const U10 = glb_sv.StockMarket[stockCode.current] ? glb_sv.StockMarket[stockCode.current].U10 : ''
                //     if (U10 === '01') {
                //         handleChangeSessontp(json[0].c1, true)
                //     } else if (U10 === '03') {
                //         handleChangeSessontp(json[0].c2, true)
                //     } else if (U10 === '05') {
                //         handleChangeSessontp(json[0].c3, true)
                //     }
                // }
            } catch (err) {
                console.log('getSellAbleList_ResultProc', err)
                return
            }
        }
    }

    const StyleContainer = { flex: 1, backgroundColor: styles.PRIMARY__BG__COLOR }

    const StyleButtonBuy = {
        backgroundColor: styles.UP__COLOR,
        height: dimensions.vertical(40, 0.5),
        marginVertical: dimensions.indent,
        flex: 1,
        borderRadius: 5,
    }

    const StyleButtonSell = {
        backgroundColor: styles.DOWN__COLOR,
        height: dimensions.vertical(40, 0.5),
        marginVertical: dimensions.indent,
        flex: 1,
        borderRadius: 5,
    }

    const StyleBuySellText = { fontSize: fontSizes.medium, color: 'white', fontWeight: fontWeights.bold }

    const refreshStockOwn = useCallback(() => {
        console.log('refreshStockOwn')
        setSellStkList([])
        setStatusSellStkList('loading')
        getSellAbleStock()
    }, [userInfo])

    const filterSoldStock = (list = []) => {
        if (!preventCompanyRender(['081'])) {
            // Remove các mã đã bán hết
            return list.filter((x) => x.c4 !== 0)
        } else {
            return list
        }
    }

    const changeTypeLot = useCallback((value) => {
        if (isOddlotRef.current === value) return
        setOddLot(value)
        isOddlotRef.current = value
        const U10 = glb_sv.StockMarket[stockCode.current] ? glb_sv.StockMarket[stockCode.current].U10 : ''
        if (isOddlotRef.current) {
            subcribeFunctStream('UNSUB', ['MDDS|TP'], [stockCode.current])
            subcribeFunctStream('SUB', [U10 === '01' ? 'MDDS|TO' : 'MDDS|PO'], [stockCode.current])
        } else {
            subcribeFunctStream('UNSUB', [U10 === '01' ? 'MDDS|TO' : 'MDDS|PO'], [stockCode.current])
            subcribeFunctStream('SUB', ['MDDS|TP'], [stockCode.current])
        }
    }, [])

    return (
        <View style={StyleContainer}>
            <ScrollView
                keyboardShouldPersistTaps="handled"
                ref={scrollviewRef}
                refreshControl={<RefreshControl refreshing={refreshing} tintColor={styles.PRIMARY__CONTENT__COLOR} onRefresh={onRefresh} />}
                style={{ marginBottom: modalKeyboard ? 0 : getBottomSpace() }}
                onScrollBeginDrag={hideModalKeyboard}
            >
                <View onResponderStart={hideModalKeyboard} onStartShouldSetResponder={(e) => true}>
                    <SearchStock changeStock={changeStock} stock={stock} />

                    {stock.t55 ? (
                        <StockInfo
                            changeSearchStock={changeSearchStock}
                            changeTypeLot={changeTypeLot}
                            handleChangePrice={handleChangePrice}
                            isOddlot={isOddlot}
                            navigation={navigation}
                            stock={stock}
                        />
                    ) : null}

                    <View style={{ backgroundColor: styles.PRIMARY__BG__COLOR, paddingHorizontal: dimensions.moderate(12), flex: 1 }}>
                        <View style={UI.row_account}>
                            <Account navigation={navigation} noPadding />
                        </View>

                        <View style={{ height: 1, backgroundColor: styles.FIFTH__BORDER__COLOR }} />

                        <View style={[UI.margin_top_row, UI.justify_content_between]}>
                            <TouchableOpacity onPress={showBuyableModal}>
                                <View style={UI.flex_direction_row}>
                                    <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.verySmall }}>{t('buy_available')}</Text>
                                    <IconSvg.InfoIcon color={styles.PRIMARY__CONTENT__COLOR} />
                                </View>
                            </TouchableOpacity>

                            <Text style={{ color: styles.PRIMARY, fontSize: fontSizes.small, fontWeight: fontWeights.bold }}>{FormatNumber(plcOrd.buyPw)}</Text>
                        </View>

                        <View style={[UI.margin_top_row, UI.justify_content_between]}>
                            <View style={UI.flex_direction_row}>
                                <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.verySmall }}>{t('leverage_ratio')}</Text>
                            </View>

                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small, fontWeight: fontWeights.bold }}>
                                {FormatNumber(plcOrd.leverage_ratio)}%
                            </Text>
                        </View>

                        <View style={[UI.margin_top_row, UI.justify_content_between]}>
                            <View style={UI.flex_direction_row}>
                                <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.verySmall }}>{t('buy_max_and_sell_qtty')}</Text>
                            </View>
                            <View style={UI.flex_direction_row}>
                                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small, fontWeight: fontWeights.bold }}>
                                    {FormatNumber(Math.floor(plcOrd.maxtrad_qty_buy))} |
                                </Text>
                                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small, fontWeight: fontWeights.bold }}>
                                    {' '}
                                    {FormatNumber(Math.floor(plcOrd.maxtrad_qty_sell))}
                                </Text>
                            </View>
                        </View>

                        <Animated.View
                            style={{
                                transform: [{ translateX: shakePrice.current }],
                            }}
                        >
                            <Row
                                style={[
                                    UI.margin_top_row,
                                    { backgroundColor: styles.BUTTON__THIRD, paddingHorizontal: dimensions.moderate(12), borderRadius: 8 },
                                ]}
                            >
                                <View style={UI.left_row}>
                                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal, fontWeight: fontWeights.light }}>
                                        {t('price')}
                                    </Text>
                                    <Text
                                        style={{
                                            color: styles.PRIMARY__CONTENT__COLOR,
                                            fontSize: fontSizes.normal,
                                            fontWeight: fontWeights.light,
                                            lineHeight: fontSizes.normal + 5,
                                        }}
                                    >
                                        {' '}
                                        ({fractionPriceOrder ? 'x1000' : 'x1'})
                                    </Text>
                                </View>
                                <Pressable
                                    style={UI.order_row}
                                    onPress={() => {
                                        glb_sv.commonEvent.next({ type: eventList.HIDE_SEARCH_STOCK })
                                        setInputModal('price')
                                        setModalKeyboard(true)
                                        setPriceText(price / 1000 + '' === '0' ? '' : price / 1000 + '')
                                        scrollviewRef.current?.scrollTo({ y: 200, animated: true })
                                    }}
                                >
                                    <TouchableOpacity
                                        style={{
                                            width: dimensions.moderate(31),
                                            height: dimensions.vertical(28),
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                        }}
                                        onPress={decrPrice}
                                    >
                                        <IconSvg.MinusIcon color={styles.ICON__SECONDARY} />
                                    </TouchableOpacity>
                                    <Text
                                        numberOfLines={1}
                                        style={{
                                            padding: 0,
                                            flex: 1,
                                            fontSize: fontSizes.normal,
                                            color: styles.PRIMARY__CONTENT__COLOR,
                                            alignSelf: 'center',
                                            textAlign: 'center',
                                        }}
                                    >
                                        {priceOrder ||
                                            (fractionPriceOrder
                                                ? modalKeyboard && inputModal === 'price'
                                                    ? priceText
                                                    : FormatNumber(price / 1000, 2, 1)
                                                : FormatNumber(price, 0, 1))}
                                        {modalKeyboard && inputModal === 'price' ? (
                                            <BlinkView style={[UI.blinkText, { color: styles.PRIMARY }]}>|</BlinkView>
                                        ) : null}
                                    </Text>
                                    <TouchableOpacity
                                        style={{
                                            width: dimensions.moderate(31),
                                            height: dimensions.vertical(28),
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                        }}
                                        onPress={incrPrice}
                                    >
                                        <IconSvg.PlusIcon color={styles.ICON__SECONDARY} />
                                    </TouchableOpacity>
                                </Pressable>
                            </Row>
                        </Animated.View>

                        <Animated.View style={{ transform: [{ translateX: shakeQty.current }], marginTop: dimensions.vertical(16) }}>
                            <Row
                                style={[
                                    UI.margin_top_row,
                                    { backgroundColor: styles.BUTTON__THIRD, borderRadius: 8, paddingHorizontal: dimensions.moderate(12) },
                                ]}
                            >
                                <View style={UI.left_row}>
                                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal, fontWeight: fontWeights.light }}>
                                        {t('qty')}
                                    </Text>
                                    <Text
                                        style={{
                                            color: styles.PRIMARY__CONTENT__COLOR,
                                            fontSize: fontSizes.normal,
                                            fontWeight: fontWeights.light,
                                            lineHeight: fontSizes.normal + 5,
                                        }}
                                    >
                                        {' '}
                                        (x1)
                                    </Text>
                                </View>
                                <Pressable
                                    style={UI.order_row}
                                    onPress={() => {
                                        glb_sv.commonEvent.next({ type: eventList.HIDE_SEARCH_STOCK })
                                        setInputModal('qty')
                                        setModalKeyboard(true)
                                        scrollviewRef.current?.scrollTo({ y: 300, animated: true })
                                    }}
                                >
                                    <TouchableOpacity
                                        style={{
                                            width: dimensions.moderate(31),
                                            height: dimensions.vertical(28),
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                        }}
                                        onPress={decrQty}
                                    >
                                        <IconSvg.MinusIcon color={styles.ICON__SECONDARY} />
                                    </TouchableOpacity>
                                    <Text
                                        numberOfLines={1}
                                        style={{
                                            padding: 0,
                                            flex: 1,
                                            fontSize: fontSizes.normal,
                                            color: styles.PRIMARY__CONTENT__COLOR,
                                            alignSelf: 'center',
                                            textAlign: 'center',
                                        }}
                                    >
                                        {FormatNumber(qty, 0, 1)}
                                        {modalKeyboard && inputModal === 'qty' ? (
                                            <BlinkView style={[UI.blinkText, { color: styles.PRIMARY }]}>|</BlinkView>
                                        ) : null}
                                    </Text>
                                    <TouchableOpacity
                                        style={{
                                            width: dimensions.moderate(31),
                                            height: dimensions.vertical(28),
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                        }}
                                        onPress={incrQty}
                                    >
                                        <IconSvg.PlusIcon color={styles.ICON__SECONDARY} />
                                    </TouchableOpacity>
                                </Pressable>
                            </Row>
                        </Animated.View>

                        <View style={{ height: 1, backgroundColor: styles.DIVIDER__COLOR, marginVertical: dimensions.vertical(10) }} />

                        <Row style={{ marginTop: dimensions.vertical(8), justifyContent: 'space-between' }}>
                            <TouchableOpacity
                                style={{
                                    justifyContent: 'flex-start',
                                    borderRadius: 8,
                                    backgroundColor: styles.BUTTON__THIRD,
                                    padding: dimensions.moderate(8),
                                    flexDirection: 'row',
                                    alignItems: 'center',
                                }}
                                onPress={() => setisDatePickerFrom(true)}
                            >
                                <View style={{ marginRight: dimensions.moderate(20) }}>
                                    <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.normal }}>
                                        {t('common_from_date')}
                                        {'  '}
                                    </Text>
                                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal }}>
                                        {moment(from_dt).format('DD/MM/YYYY')}
                                    </Text>
                                </View>
                                <IconSvg.DateIcon color={styles.PRIMARY__CONTENT__COLOR} />
                            </TouchableOpacity>
                            <View style={{ width: dimensions.moderate(16) }} />
                            <TouchableOpacity
                                style={{
                                    justifyContent: 'flex-start',
                                    borderRadius: 8,
                                    backgroundColor: styles.BUTTON__THIRD,
                                    padding: dimensions.moderate(8),
                                    flexDirection: 'row',
                                    alignItems: 'center',
                                }}
                                onPress={() => setisDatePickerTo(true)}
                            >
                                <View style={{ marginRight: dimensions.moderate(20) }}>
                                    <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.normal }}>
                                        {t('common_to_date')}
                                        {'  '}
                                    </Text>
                                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal }}>
                                        {moment(to_dt).format('DD/MM/YYYY')}
                                    </Text>
                                </View>
                                <IconSvg.DateIcon color={styles.PRIMARY__CONTENT__COLOR} />
                            </TouchableOpacity>
                        </Row>

                        <Row style={{ marginTop: dimensions.vertical(22), justifyContent: 'space-between' }}>
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small, fontWeight: fontWeights.semiBold }}>
                                {t('estimate_amount')}
                            </Text>
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.medium, fontWeight: fontWeights.semiBold }}>
                                {FormatNumber(Math.ceil(((plcOrd.temp_fee || 0) * price * qty) / 100) + price * qty)}
                            </Text>
                        </Row>

                        <View style={[UI.margin_top_row, UI.justify_content_between]}>
                            <Text style={{ color: styles.WARN__COLOR, fontSize: fontSizes.verySmall }}>{t('order_gtc_description')}</Text>
                        </View>

                        {loadingSendOrder ? (
                            <Row style={UI.justify_content_between}>
                                <Button
                                    block
                                    style={{
                                        backgroundColor: styles.SECOND__BG__COLOR,
                                        height: dimensions.vertical(40, 0.5),
                                        marginVertical: dimensions.indent,
                                        flex: 1,
                                    }}
                                >
                                    <ActivityIndicator color={styles.PRIMARY__CONTENT__COLOR} />
                                    <Text style={{ fontSize: fontSizes.xmedium, color: styles.PRIMARY__CONTENT__COLOR }}>{t('common_processing')}...</Text>
                                </Button>
                            </Row>
                        ) : (
                            <Row style={UI.justify_content_between}>
                                <Button
                                    block
                                    style={StyleButtonBuy}
                                    onPress={() => {
                                        plcOrdRef.current.sellbuy_tp = 'buy'
                                        if (!stockCode.current) changeSearchStock()
                                        else placeOrder()
                                    }}
                                >
                                    <Text style={StyleBuySellText}>{t('buy_upcase')}</Text>
                                </Button>
                                <View style={UI.width8} />
                                <Button
                                    block
                                    style={StyleButtonSell}
                                    onPress={() => {
                                        plcOrdRef.current.sellbuy_tp = 'sell'
                                        if (!stockCode.current) changeSearchStock()
                                        else placeOrder()
                                    }}
                                >
                                    <Text style={StyleBuySellText}>{t('sell_upcase')}</Text>
                                </Button>
                            </Row>
                        )}

                        <StockOwner
                            changeStock={changeStock}
                            refreshStockOwn={refreshStockOwn}
                            sellStkList={sellStkList}
                            statusSellStkList={statusSellStkList}
                        />
                        <View style={UI.bottomSpace} />
                    </View>
                </View>
            </ScrollView>

            {modalKeyboard ? (
                <KeyboardCustom
                    hideKeyboard={hideModalKeyboard}
                    inputModal={inputModal}
                    keyboardType={fractionPriceOrder ? 'decimal-pad' : 'number-pad'}
                    orderTps={[]}
                    placeOrder={placeOrder}
                    qty={qty}
                    setPriceOrderTp={setPriceOrderTp}
                    setQtyKeyboard={handleChangeQty}
                    styles={styles}
                    t={t}
                    onClear={_handleClear}
                    onDelete={_handleDelete}
                    onKeyPress={_handleKeyPress}
                />
            ) : null}

            {modalOrderCfm ? (
                <ModalOrderConfirm
                    confirmOrder={confirmOrder}
                    from_dt={moment(from_dt).format('DD/MM/YYYY')}
                    isGTCOrder={true}
                    modalOrderCfm={modalOrderCfm}
                    nameSessionTp=""
                    orderTp={plcOrd.orderTp}
                    passTrading={passTrading}
                    price={price}
                    qty={qty}
                    sellbuy_tp={plcOrd.sellbuy_tp}
                    setPassTrading={setPassTrading}
                    stockCode={stockCode.current}
                    to_dt={moment(to_dt).format('DD/MM/YYYY')}
                />
            ) : null}

            {modalCheckDoubleOrder ? (
                <ModalCheckDoubleOrder
                    hanldeCheckDoubOrder={hanldeCheckDoubOrder}
                    modalCheckDoubleOrder={modalCheckDoubleOrder}
                    onHideModalCheckDoub={onHideModalCheckDoub}
                />
            ) : null}

            {isDatePickerFrom ? (
                <DateTimePickerModal
                    cancelTextIOS={t('common_Cancel')}
                    confirmTextIOS={t('common_Ok')}
                    date={moment(from_dt).toDate()}
                    headerTextIOS=""
                    isDarkModeEnabled={theme.includes('DARK')}
                    isVisible={isDatePickerFrom}
                    locale={language === 'VI' ? 'vi_VN' : 'en_US'}
                    mode="date"
                    onCancel={hideDatePicker}
                    onConfirm={(value) => {
                        setisDatePickerFrom(false)
                        setFromDt(value)
                    }}
                />
            ) : null}

            {isDatePickerTo ? (
                <DateTimePickerModal
                    cancelTextIOS={t('common_Cancel')}
                    confirmTextIOS={t('common_Ok')}
                    date={moment(to_dt).toDate()}
                    headerTextIOS=""
                    isDarkModeEnabled={theme.includes('DARK')}
                    isVisible={isDatePickerTo}
                    locale={language === 'VI' ? 'vi_VN' : 'en_US'}
                    mode="date"
                    onCancel={hideDatePicker}
                    onConfirm={(value) => {
                        setisDatePickerTo(false)
                        setToDt(value)
                    }}
                />
            ) : null}

            {visibleModalSessiontp ? (
                <ModalSeasontp
                    handleChangeSessontp={handleChangeSessontp}
                    list={plcOrd.seasonTps}
                    seasonTp={plcOrd.seasonTp}
                    setVisible={setVisibleModalSessiontp}
                    visible={visibleModalSessiontp}
                />
            ) : null}

            {isNormalBuyableShow ? (
                <ModalNormalBuyableInfo buyAbleInfo={buyAbleInfo} isVisible={isNormalBuyableShow} onConfirm={onNormalBuyableModalConfirm} />
            ) : null}

            {isMarginBuyableShow ? (
                <ModalMarginBuyableInfo buyAbleInfo={buyAbleInfo} isVisible={isMarginBuyableShow} onConfirm={onMarginBuyableModalConfirm} />
            ) : null}
        </View>
    )
}

const getInitPage = () => {
    if (glb_sv.notifyOpened) {
        if (glb_sv.notifyOpened.direct.includes('ORD')) {
            glb_sv.notifyOpened = null
            return 1
        }
        if (glb_sv.notifyOpened.direct.includes('CASH') || glb_sv.notifyOpened.direct.includes('STK')) {
            glb_sv.notifyOpened = null
            return 2
        }
    }
    return 0
}

function GTCOrderWithTab({ navigation, route, isTab }) {
    const { theme, styles, authFlag, connected, applicationSettings } = useContext(StoreContext)
    const { t } = useTranslation()

    const [tab, setTab] = useState(0)
    const [, updateState] = useState()
    const forceUpdate = useCallback(() => updateState({}), [])
    const [refreshing, setRefresh] = useState(false)

    useEffect(() => {
        glb_sv.focusPlaceOrder = true
        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.EKYC_SUCCESS) {
                forceUpdate()
            }
            if (msg.type === eventList.ORDER) {
                setTab(0)
            }
            if (msg.type === eventList.CHANGE_SCREEN && glb_sv.notifyOpened) {
                if (glb_sv.notifyOpened.direct.includes('ORD')) {
                    setTab(1)
                }
                // if (glb_sv.notifyOpened.direct.includes('CASH') || glb_sv.notifyOpened.direct.includes('STK')) {
                //     if (CONFIG.application_style.default_style === '1.0') {
                //         setTab(2)
                //     }
                // }
            }
        })

        InteractionManager.runAfterInteractions(() => {
            if (glb_sv.notifyOpened) {
                setTab(getInitPage())
            }
        })

        return () => {
            glb_sv.focusPlaceOrder = false
            commonEvent.unsubscribe()
        }
    }, [])

    useEffect(() => {
        if (!authFlag && !SyncStorage.get(STORE_KEY.AutoLoginMode)) {
            InteractionManager.runAfterInteractions(() => {
                navigation.navigate(Screens.SIGN_IN)
            })
        }
    }, [authFlag])
    const StyleUnderline = {
        backgroundColor: applicationSettings.application_style.tab_style === '2.0' ? 'transparent' : styles.PRIMARY,
        borderRadius: 2,
        height: 2,
    }

    const StyleBgPrimary = { backgroundColor: styles.PRIMARY__BG__COLOR }
    const StyleBgPrimaryActive =
        applicationSettings.application_style.tab_style === '2.0'
            ? { backgroundColor: styles.ACTIVE__TAB__HIGHLIGHT__BG, borderTopRightRadius: 6, borderTopLeftRadius: 6, marginLeft: 2 }
            : { backgroundColor: styles.PRIMARY__BG__COLOR }

    const StyleTextPrimary = { color: applicationSettings.application_style.tab_style === '2.0' ? '#fff' : styles.PRIMARY }
    const StyleTextSecond = { color: styles.SECOND__CONTENT__COLOR }
    const StyleContainer = { flex: 1, backgroundColor: styles.PRIMARY__BG__COLOR }

    if (!authFlag || glb_sv.objShareGlb.userInfo.c9 === 'N') {
        return <NotAuthView isBottom={isTab} navigation={navigation} />
    }

    return (
        <View style={StyleContainer}>
            <FocusAwareStatusBar backgroundColor={'transparent'} barStyle={theme.includes('DARK') ? 'light-content' : 'dark-content'} translucent={true} />
            <View style={{ flex: 1, paddingBottom: 8, marginTop: connected ? getStatusBarHeight(true) : 0 }}>
                <Tabs
                    page={tab}
                    renderTabBar={(props) => (
                        <DefaultTabBar
                            {...props}
                            backgroundColor={styles.PRIMARY__BG__COLOR}
                            tabContainerStyle={{
                                elevation: 0,
                                borderBottomColor: styles.DIVIDER__COLOR,
                                borderBottomWidth: 1,
                                height: 34,
                                backgroundColor: 'transparent',
                            }}
                            underlineStyle={StyleUnderline}
                        />
                    )}
                    onChangeTab={(value) => {
                        setTab(value.i)
                        if (value.i === 1) {
                            glb_sv.commonEvent.next({ type: eventList.REFRESH_ORDER_LIST })
                        } else {
                            glb_sv.commonEvent.next({ type: eventList.REFRESH_ORDER_LIST, notGetList: true })
                        }
                    }}
                >
                    <Tab
                        activeTabStyle={StyleBgPrimaryActive}
                        activeTextStyle={StyleTextPrimary}
                        heading={
                            <TabHeading style={{ backgroundColor: styles.PRIMARY__BG__COLOR, justifyContent: 'flex-start' }}>
                                <Button
                                    style={{
                                        paddingTop: dimensions.vertical(8),
                                        paddingBottom: dimensions.vertical(8),
                                        paddingHorizontal: dimensions.moderate(8),
                                        height: dimensions.vertical(35),
                                        flex: 0,
                                    }}
                                    transparent
                                    onPress={() => navigation.pop()}
                                >
                                    <IconBack style={{ color: styles.ICON__PRIMARY }} />
                                </Button>
                                <View
                                    style={[
                                        {
                                            flex: 1,
                                            height: '100%',
                                            justifyContent: 'center',
                                        },
                                        tab === 0 ? StyleBgPrimaryActive : {},
                                    ]}
                                >
                                    <Text
                                        style={[
                                            {
                                                fontSize: fontSizes.normal,
                                                textAlign: 'center',
                                            },
                                            tab === 0 ? StyleTextPrimary : StyleTextSecond,
                                        ]}
                                    >
                                        {t('gtc_order')}
                                    </Text>
                                </View>
                            </TabHeading>
                        }
                        tabStyle={StyleBgPrimary}
                        textStyle={StyleTextSecond}
                    >
                        <GTCOrder isTab={isTab} navigation={navigation} refreshing={refreshing} route={route} setRefresh={setRefresh} setTab={setTab} />
                    </Tab>
                    <Tab
                        activeTabStyle={StyleBgPrimaryActive}
                        activeTextStyle={StyleTextPrimary}
                        heading={t('order_history')}
                        tabStyle={StyleBgPrimary}
                        textStyle={StyleTextSecond}
                    >
                        <View style={{ paddingHorizontal: dimensions.moderate(12), backgroundColor: styles.PRIMARY__BG__COLOR, flex: 1 }}>
                            <AdvOrderList isGTCOrder={true} navigation={navigation} refreshing={refreshing} setRefresh={setRefresh} />
                        </View>
                    </Tab>
                </Tabs>
            </View>
        </View>
    )
}

const UI = StyleSheet.create({
    blinkText: {
        fontSize: fontSizes.normal,
        fontWeight: fontWeights.semiBold,
    },
    bottomSpace: { height: 32 },
    button_back: { height: dimensions.vertical(35), paddingBottom: 0, paddingTop: 0 },
    buying_row: {
        justifyContent: 'space-between',
        paddingHorizontal: dimensions.halfIndent,
    },
    caption: {
        //flex: 1,
    },
    estimate_row: {
        justifyContent: 'space-between',
        marginBottom: 5,
        paddingHorizontal: dimensions.halfIndent,
    },
    flex1: {
        flex: 1,
    },
    flex_direction_row: { flexDirection: 'row' },
    justify_content_between: { justifyContent: 'space-between' },
    left_row: {
        flex: 4,
        flexDirection: 'row',
        paddingVertical: 5,
    },
    margin_top_row: {
        flexDirection: 'row',
        paddingVertical: dimensions.vertical(8),
    },
    name_act: {
        flexDirection: 'row',
        paddingTop: 8,
        paddingVertical: 5,
    },
    order_row: {
        flex: 5,
        flexDirection: 'row',
    },
    price_under_slider: {
        justifyContent: 'space-between',
        marginBottom: dimensions.indent,
        marginTop: -5,
    },
    row_account: {
        paddingBottom: dimensions.vertical(8),
    },
    search: {
        alignItems: 'center',
        borderRadius: 20,
        flexDirection: 'row',
        marginHorizontal: dimensions.moderate(16),
        marginTop: 14,
    },
    selectStock: {
        flex: 1,
        fontSize: fontSizes.normal,
    },
    thumb: {
        height: 30,
        shadowColor: 'black',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.5,
        shadowRadius: 1,
        width: 30,
    },
    titleContainer: {
        alignItems: 'center',
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
    value: {
        flex: 1,
        marginLeft: 10,
        textAlign: 'right',
    },
    viewInput: {
        borderRadius: 8,
        borderWidth: 0.6,
        flexDirection: 'row',
        paddingHorizontal: dimensions.moderate(16),
        paddingVertical: dimensions.vertical(8),
    },
    viewTitle: {
        alignItems: 'flex-start',
        flexDirection: 'column',
        flex: 1,
        justifyContent: 'center',
        paddingHorizontal: dimensions.halfIndent,
    },
    view_header: { flexDirection: 'row', height: dimensions.vertical(35), marginTop: getStatusBarHeight() + 3, paddingHorizontal: dimensions.moderate(16) },
    width8: {
        width: dimensions.moderate(8),
    },
})

export default GTCOrderWithTab
