import e2e_testing_id from './e2e_test_id'

const fs = require('fs')

describe('Login', () => {
    beforeAll(async () => {
        await device.launchApp()
        await waitFor(element(by.text('Service')))
            .toBeVisible()
            .withTimeout(10000)
    })

    it('Should tap on a Service', async () => {
        await element(by.text('Service')).tap()
    })

    it('Should tap on a Login', async () => {
        await element(by.id(e2e_testing_id.settings_screen.login_icon)).tap()
    })
    it('Input username', async () => {
        const userName = element(by.id(e2e_testing_id.login_screen.input_user_id))
        await expect(userName).toBeVisible()
        await userName.clearText()
        await userName.typeText('081C002022')
        await expect(userName).toHaveText('081C002022')
    })

    it('Input password', async () => {
        const password = element(by.id(e2e_testing_id.login_screen.input_password))
        await expect(password).toBeVisible()
        await password.clearText()

        await password.typeText('12345678')
        await expect(password).toHaveText('12345678')
    })

    it('Should tap on a Login Button', async () => {
        const snapshottedImagePath = 'e2e/image_taking/result_login.png'
        const imagePath = await device.takeScreenshot('login_func')
        fs.writeFileSync(snapshottedImagePath, fs.readFileSync(imagePath), 'base64', (err) => {
            if (!err) console.log(`Image saved!`)
        })
        await element(by.id(e2e_testing_id.login_screen.login_button)).tap()
    })
})
