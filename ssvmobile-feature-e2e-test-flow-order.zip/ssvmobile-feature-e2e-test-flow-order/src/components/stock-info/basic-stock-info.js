import React, { memo, useContext } from 'react'
import { Col } from 'native-base'

import { Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { fontSizes, fontWeights } from '../../styles'

const BasicStockInfo = ({ name, figure, right, figure1, figure2, figure1Color, figure2Color, type, center, figureColor }) => {
    const { styles } = useContext(StoreContext)
    return (
        <Col style={{ flexDirection: 'column', alignItems: right && 'flex-end', paddingLeft: center ? 26 : 0 }}>
            <Text
                numberOfLines={1}
                style={{
                    fontSize: fontSizes.smallest,
                    color: styles.SECOND__CONTENT__COLOR,
                    fontWeight: fontWeights.medium,
                }}
            >
                {name}
            </Text>
            <Text
                style={{
                    fontSize: fontSizes.tiny,
                    color: figureColor || styles.PRIMARY__CONTENT__COLOR,
                    fontWeight: fontWeights.medium,
                }}
            >
                {figure ? (
                    figure
                ) : (
                    <>
                        <Text style={{ fontSize: fontSizes.tiny, color: figure1Color || styles.PRIMARY__CONTENT__COLOR, fontWeight: fontWeights.medium }}>
                            {figure1}
                        </Text>
                        {type ? type : '/'}
                        <Text style={{ fontSize: fontSizes.tiny, color: figure2Color || styles.PRIMARY__CONTENT__COLOR, fontWeight: fontWeights.medium }}>
                            {figure2}
                        </Text>
                    </>
                )}
            </Text>
        </Col>
    )
}

export default memo(BasicStockInfo)
