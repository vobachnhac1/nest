import React, { memo } from 'react'
import { View } from 'react-native'

const Divider = ({ styles }) => <View style={{ backgroundColor: styles.DIVIDER__VIEW__COLOR, height: 10 }} />
export default memo(Divider)
