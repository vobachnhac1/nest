import { useRef, useState } from 'react'
import ToastGlobal from 'react-native-toast-message'

import { glb_sv, reqFunct, sendRequest } from '../../../../utils'

const ServiceInfo: { [key: string]: ISserviceInfo } = {
    CHECK_ADVERTISING_NOTIFY_MODAL: {
        reqFunct: reqFunct.CHECK_ADVERTISING_NOTIFY_MODAL,
        WorkerName: 'FOSqCommon',
        ServiceName: 'FOSqCommon_0820_04_Online',
        Operation: 'Q',
    },
}
export const useCheckModalAdvertising = () => {
    // Gọi service check thông báo hoặc quảng cáo, khuyến mãi, thông tin, ...
    // @return State open popup, ...
    const [isCheckingDataPopup, setIsCheckingDataPopup] = useState(false)
    const [dataPopup, setDataPopup] = useState<IServiceResponeData>({})
    // const [arrayDataPopup, setArrayDataPopup] = useState([]);
    const callbackFunc = useRef<null | Function>(null)
    const arrayDataPopupRef = useRef<IServiceResponeData[]>([])

    const _excuteCallbackOnSuccess = (isVisible: boolean) => {
        if (typeof callbackFunc.current === 'function') {
            callbackFunc.current(isVisible)
        }
    }
    /**
     * @type {string} : 1. Trước đăng nhập, 2. Sau đăng nhập, 3. Khi mở web/apps
     */
    const checkPopup = ({ type = '3' }: { type: '1' | '2' | '3' }, callbackOnSuccess: (isVisible: boolean) => void): void => {
        callbackFunc.current = callbackOnSuccess
        // ----- Reset data and start new loading
        setDataPopup({})
        // -----------

        const InputParams = [type]
        sendRequest(ServiceInfo.CHECK_ADVERTISING_NOTIFY_MODAL, InputParams, handleResult, true, onTimeout)
    }

    const handleResult = (reqInfoMap, message) => {
        setIsCheckingDataPopup(false)
        if (Number(message.Result) === 0) {
            ToastGlobal.show({
                type: 'warning',
                text2: message.Message,
            })
            return
        } else {
            let jsondata
            try {
                jsondata = message.Data ? JSON.parse(glb_sv.replaceStrToHTML(message.Data)) : []
            } catch (err) {
                console.log('handleResult useCheckModalAdvertising', err)
                return
            }
            // console.log('jsondata', jsondata)
            setDataPopup(jsondata[0] || {})
            arrayDataPopupRef.current = jsondata || []
            _excuteCallbackOnSuccess(true)
        }
    }

    const onTimeout = () => {
        setIsCheckingDataPopup(false)
        setDataPopup({})
    }

    const nextEvent = (callbackOnFinished: () => void) => {
        const nextArray = arrayDataPopupRef.current.filter((i) => i?.c0 !== dataPopup?.c0)
        arrayDataPopupRef.current = nextArray || []
        // console.log("nextArray >>>>>>>>>", arrayDataPopupRef.current, nextArray, dataPopup);
        if (nextArray.length > 0) {
            // if (nextArray[0])
            setDataPopup(nextArray[0])
        } else {
            if (typeof callbackOnFinished === 'function') {
                callbackOnFinished()
            }
        }
    }

    return {
        isCheckingDataPopup,
        dataPopup,
        checkPopup,
        nextEvent,
    }
}
