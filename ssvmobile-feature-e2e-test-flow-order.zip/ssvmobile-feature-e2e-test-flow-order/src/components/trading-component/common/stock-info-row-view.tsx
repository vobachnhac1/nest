import React, { useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { Col, Row } from 'native-base'

import { Text } from '../../../basic-components'
import { StoreContext } from '../../../store'
import { dimensions as dm, fontSizes as fs, fontWeights as fw } from '../../../styles'

interface IStockInfoRowView {
    onPress?: Function
    stockSymbol?: string
    stockName?: string
    qtyNote?: string
    qty?: string
    iconRight?: any
    type?: 'buy' | 'sell' | 'confirm' | 'cancel' | 'back'
}

const StockInfoRowView = ({
    onPress = () => {},
    stockSymbol, // Nội dung header
    stockName,
    qtyNote,
    qty,
    iconRight = null, // Right Component
    type = 'buy', // type của header
    ...props
}: IStockInfoRowView) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()

    const getColor = (type) => {
        if (type === 'buy' || type === 'confirm') return styles.PRIMARY
        if (type === 'sell' || type === 'cancel') return styles.SELL__BG
        if (type === 'back') return 'transparent'
    }

    return (
        <Row
            style={{
                backgroundColor: styles.INPUT__BG,
                borderRadius: 8,
                paddingVertical: dm.moderate(4),
                marginVertical: dm.moderate(4),
                marginHorizontal: dm.moderate(16),
            }}
            onPress={onPress}
        >
            <Col size={20}>
                <Text numberOfLines={1} style={{ fontWeight: fw.bold, fontSize: fs.normal, color: styles.PRIMARY__CONTENT__COLOR }}>
                    {stockSymbol}
                    <Text style={{ fontWeight: fw.normal, color: styles.SECOND__CONTENT__COLOR }}>{` - ${stockName}`}</Text>
                </Text>
                <Text style={{ fontSize: fs.small, color: styles.SECOND__CONTENT__COLOR }}>
                    {qtyNote}
                    <Text style={{ fontWeight: fw.bold, fontSize: fs.small, color: getColor(type) }}>{qty}</Text>
                </Text>
            </Col>
            <Col size={4} style={{ justifyContent: 'center', alignItems: 'flex-end' }}>
                {iconRight}
            </Col>
        </Row>
    )
}

export default StockInfoRowView
