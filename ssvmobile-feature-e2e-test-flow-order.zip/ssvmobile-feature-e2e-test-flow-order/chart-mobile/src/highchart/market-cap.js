import React, { useEffect, useRef, useState } from 'react'
import Highcharts from 'highcharts'
import Treemap from 'highcharts/modules/treemap'
import HighchartsReact from 'highcharts-react-official'

Treemap(Highcharts)

const HighChartMarketCap = () => {
    const [dataChart, setDataChart] = useState([])
    const chartRef = useRef(null)

    useEffect(() => {
        const eventMarket = window.eventMarket.subscribe((msg) => {
            if (msg.type === 'highchart-marketcap') {
                convertedAndUpdateData()
            }
        })
        convertedAndUpdateData()
        return () => {
            eventMarket?.unsubscribe()
        }
    }, [])

    const convertedAndUpdateData = () => {
        const data = window.DataMarketCap || []
        setDataChart([...data])
    }

    const options = {
        chart: {
            animation: false,
            type: 'treemap',
            margin: 0,
            marginTop: 0,
        },

        series: [
            {
                type: 'treemap',
                layoutAlgorithm: 'stripes',
                alternateStartingDirection: true,
                levels: [
                    {
                        level: 1,
                        layoutAlgorithm: 'squarified',
                        alternateStartingDirection: true,
                        dataLabels: {
                            enabled: true,
                            padding: 0,
                            x: 0,
                            y: 0,
                            className: 'label_treemap_item',
                            style: {
                                color: '#25253e',
                                textOutline: false,
                                textOverflow: 'ellipsis',
                                // overflow: 'hidden',
                                whiteSpace: 'normal',
                                // fontSize: 'var(--xnormal)',
                            },
                        },
                    },
                ],
                data: dataChart,
            },
        ],
        title: {
            text: '',
        },
        tooltip: {
            formatter: function () {
                return this.point.options.tooltip
            },
        },
        credits: { enabled: false },
    }

    return (
        <div id="highcharts-marketcap" style={{ height: 'calc(100vh)', width: 'calc(100vw)' }}>
            {/* <span style={{ color: 'red'}}> none </span>
            {loading ? <span style={{ color: 'red'}}> Loading </span> : null} */}
            <HighchartsReact
                callback={(chart) => {
                    const elm = document.getElementById('highcharts-marketcap')
                    chart.update({
                        chart: {
                            height: elm?.offsetHeight,
                        },
                    })
                }}
                highcharts={Highcharts}
                options={options}
                ref={chartRef}
            />
        </div>
    )
}

export default HighChartMarketCap
