import React, { memo, useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { ActivityIndicator, FlatList, InteractionManager, RefreshControl, ScrollView, StyleSheet, TouchableOpacity } from 'react-native'
import Modal from 'react-native-modal'
import { useNavigation } from '@react-navigation/native'
import moment from 'moment'
import { Text, View } from 'native-base'

import { EmptyView, ModalBottomContent, ModalBottomRowSelect, RowTitleGroup, WarningOrInfo } from '../../components/trading-component'
import ErrorView from '../../components/trading-component/error-view'
import { allowCompanyRender } from '../../hoc'
import { StoreContext } from '../../store'
import { StoreTrading } from '../../store-trading'
import { dimensions, fontSizes, fontWeights } from '../../styles'
import { eventList, FormatNumber, glb_sv, reqFunct, Screens, sendRequest } from '../../utils'

const ServiceInfo = {
    GET_ASSETS_GUAR_INFO: {
        reqFunct: reqFunct.GET_ASSETS_GUAR_INFO,
        WorkerName: 'FOSqMargin',
        ServiceName: 'FOSqLendingMargin_Online_1450_1',
        Operation: 'Q',
        ClientSentTime: '0',
    },
    GET_ASSETS_GUAR_INFO_V2: {
        reqFunct: reqFunct.GET_ASSETS_GUAR_INFO,
        WorkerName: 'FOSqMargin',
        ServiceName: 'FOSqLendingMargin_Online_1450_2',
        Operation: 'Q',
        ClientSentTime: '0',
    },
    GET_CUR_MARG_CONT_LIST: {
        reqFunct: reqFunct.GET_CUR_MARG_CONT_LIST,
        WorkerName: 'FOSqMargin',
        ServiceName: 'FOSqMargin_1402_1',
        ClientSentTime: '0',
        Operation: 'Q',
        // InVal: ['OTSRPY', this.actn_curr, this.sub_curr, '6', '%', '0', 'z', '']
    },
}

const Debt = ({ isActive }) => {
    const { t } = useTranslation()
    const { userInfo } = useContext(StoreTrading)
    const navigation = useNavigation()

    const [data, setData] = useState({})
    const mounted = useRef(true)
    const { styles } = useContext(StoreContext)
    const [isOpenActionSheet, setIsOpenActionSheet] = useState(false)
    const [selectContract, setSelectContract] = useState({})

    const [listCurMarginContract, setListCurMarginContract] = useState([])
    const [totalObject, setTotalObject] = useState({
        loan_expide_dt: 0,
        due_debt: 0,
        undue_debt: 0,
        interest: 0,
    })

    const [refreshing, setRefresh] = useState(false)
    const timeoutRefresh = useRef(null)
    const [isTimeout, setIsTimemout] = useState(false)

    useEffect(() => {
        mounted.current = true
        if (isActive) {
            onRefresh()
        }

        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.LOGIN_SUCCESS) {
                if (isActive) {
                    onRefresh()
                }
            }
        })

        return () => {
            mounted.current = false
            commonEvent.unsubscribe()
        }
    }, [userInfo, isActive])

    const getAssetsGuarInfo = () => {
        setRefresh(true)
        const { actn_curr, sub_curr } = userInfo
        const InputParams = [actn_curr, sub_curr]
        setData({})
        setIsTimemout(false)
        sendRequest(ServiceInfo.GET_ASSETS_GUAR_INFO, InputParams, getAssetsGuarInfoResult, true, getAssetsGuarInfoTimeout)
    }

    const getAssetsGuarInfoTimeout = () => {
        setIsTimemout(true)
        setRefresh(false)
    }

    const getAssetsGuarInfoResult = (reqInfoMap, message) => {
        setRefresh(false)
        if (Number(message.Result) === 0) {
            return
        } else {
            try {
                const jsondata = message.Data ? JSON.parse(message.Data)[0] : {}
                console.log('getAssetsGuarInfoResult -> jsondata', jsondata)
                InteractionManager.runAfterInteractions(() => {
                    setData(jsondata)
                })
            } catch (err) {
                console.log('getAssetsGuarInfoResult', err)
            }
        }
    }

    const getListCurrentMarginContractList = () => {
        const inputParams = ['OTSRPY', userInfo.actn_curr, userInfo.sub_curr, '6', '%', '0', 'z', '']
        sendRequest(ServiceInfo.GET_CUR_MARG_CONT_LIST, inputParams, handleGetListCurrentMarginContractList)
    }

    const handleGetListCurrentMarginContractList = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata
            try {
                jsondata = JSON.parse(message.Data)
            } catch (err) {
                // glb_sv.logMessage(err);
                jsondata = []
            }
            if (Number(message.Packet) <= 0) {
                setListCurMarginContract(jsondata)
                // const loan_expide_dt = jsondata.reduce(function (a, b) {
                //     return a + 0
                // }, 0)
                // const due_debt = jsondata.reduce(function (a, b) {
                //     return a + 0
                // }, 0)
                // const undue_debt = jsondata.reduce(function (a, b) {
                //     return a + 0
                // }, 0)
                // const interest = jsondata.reduce(function (a, b) {
                //     return a + Number(b.c21)
                // }, 0)
                // setTotalObject({
                //     loan_expide_dt,
                //     due_debt,
                //     undue_debt,
                //     interest,
                // })
            }
        }
    }

    const hideModal = () => {
        setIsOpenActionSheet(false)
    }
    const _openActionSheet = (item) => {
        setIsOpenActionSheet(true)
        setSelectContract(item)
    }

    const onRefresh = () => {
        if (refreshing) return
        if (!mounted.current) return
        setRefresh(true)
        if (timeoutRefresh.current) clearTimeout(timeoutRefresh.current)
        timeoutRefresh.current = setTimeout(() => {
            getAssetsGuarInfo()
            getListCurrentMarginContractList()
        }, 500)
    }

    const ViewList = ({ item }) => {
        return (
            <TouchableOpacity onPress={() => _openActionSheet(item)}>
                <View
                    style={{
                        display: 'flex',
                        flexDirection: 'row',
                        paddingVertical: dimensions.moderate(8),
                        borderBottomColor: styles.DIVIDER__COLOR,
                        borderBottomWidth: 1,
                    }}
                >
                    <View style={{ flex: 2 }}>
                        <View>
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.verySmall, textAlign: 'left' }}>
                                {moment(item.c1, 'DDMMYYYY').format('DD/MM/YYYY')}
                            </Text>
                            <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.verySmall, textAlign: 'left' }}>
                                {moment(item.c5, 'DDMMYYYY').format('DD/MM/YYYY')}
                            </Text>
                        </View>
                    </View>
                    <View style={{ justifyContent: 'center', alignItems: 'flex-end', flex: 2.6 }}>
                        <View>
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.verySmall, textAlign: 'right' }}>
                                {FormatNumber(item.c8)}
                            </Text>
                            <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.verySmall, textAlign: 'right' }}>
                                {FormatNumber(item.c9)}
                            </Text>
                        </View>
                    </View>
                    <View style={{ justifyContent: 'center', alignItems: 'flex-end', flex: 3 }}>
                        <View>
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.verySmall, textAlign: 'right' }}>{item.c19}</Text>
                        </View>
                    </View>
                </View>
            </TouchableOpacity>
        )
    }

    return (
        <View style={{ backgroundColor: styles.PRIMARY__BG__COLOR, height: '100%' }}>
            {isTimeout ? (
                <ErrorView
                    refresh={() => {
                        getAssetsGuarInfo()
                        getListCurrentMarginContractList()
                    }}
                />
            ) : (
                <ScrollView
                    refreshControl={
                        <RefreshControl
                            refreshing={refreshing}
                            onRefresh={onRefresh}
                            // title={t('pull_refresh')}
                            // titleColor={styles.PRIMARY__CONTENT__COLOR}
                            tintColor={styles.PRIMARY__CONTENT__COLOR}
                        />
                    }
                    showsVerticalScrollIndicator={false}
                    style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}
                >
                    <>
                        <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                            <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('pia_loan_current')}</Text>
                            <Text
                                style={{
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                    fontSize: fontSizes.small,
                                    fontWeight: fontWeights.bold,
                                    flex: 1,
                                    textAlign: 'right',
                                }}
                            >
                                {FormatNumber(data.c47)}
                            </Text>
                        </View>

                        <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                            <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('pia_loan_fee')}</Text>
                            <Text
                                style={{
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                    fontSize: fontSizes.small,
                                    fontWeight: fontWeights.bold,
                                    flex: 1,
                                    textAlign: 'right',
                                }}
                            >
                                {FormatNumber(data.c48)}
                            </Text>
                        </View>

                        <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                            <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('margin_debt')}</Text>
                            <Text
                                style={{
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                    fontSize: fontSizes.small,
                                    fontWeight: fontWeights.bold,
                                    flex: 1,
                                    textAlign: 'right',
                                }}
                            >
                                {FormatNumber(data.c32)}
                            </Text>
                        </View>

                        <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                            <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('margin_debt_fee')}</Text>
                            <Text
                                style={{
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                    fontSize: fontSizes.small,
                                    fontWeight: fontWeights.bold,
                                    flex: 1,
                                    textAlign: 'right',
                                }}
                            >
                                {FormatNumber(Number(data.c33) + Number(data.c34) + Number(data.c35))}
                            </Text>
                        </View>

                        <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                            <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('temporary_loan')}</Text>
                            <Text
                                style={{
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                    fontSize: fontSizes.small,
                                    fontWeight: fontWeights.bold,
                                    flex: 1,
                                    textAlign: 'right',
                                }}
                            >
                                {FormatNumber(data.c69)}
                            </Text>
                        </View>

                        <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                            <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('loan_expide_dt')}</Text>
                            <Text
                                style={{
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                    fontSize: fontSizes.small,
                                    fontWeight: fontWeights.bold,
                                    flex: 1,
                                    textAlign: 'right',
                                }}
                            >
                                {FormatNumber(data.c68)}
                            </Text>
                        </View>

                        <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                            <View style={{ flexDirection: 'row', flex: 0.5 }}>
                                <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('total_current_loand')}</Text>
                            </View>
                            <Text
                                style={{
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                    fontSize: fontSizes.small,
                                    fontWeight: fontWeights.bold,
                                    flex: 1,
                                    textAlign: 'right',
                                }}
                            >
                                {FormatNumber(data.c31)}
                            </Text>
                        </View>

                        <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                            <View style={{ flexDirection: 'row', flex: 0.15 }}>
                                <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('CMR')}</Text>
                            </View>
                            <Text
                                style={{
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                    fontSize: fontSizes.small,
                                    fontWeight: fontWeights.bold,
                                    flex: 1,
                                    textAlign: 'right',
                                }}
                            >
                                {FormatNumber(data.c2, 2, 0)} %
                            </Text>
                        </View>

                        <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                            <View style={{ flexDirection: 'row', flex: 1 }}>
                                <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('adding_amount')}</Text>
                            </View>

                            <Text
                                style={{
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                    fontSize: fontSizes.small,
                                    fontWeight: fontWeights.bold,
                                    flex: 1,
                                    textAlign: 'right',
                                }}
                            >
                                {FormatNumber(data.c49)}
                            </Text>
                        </View>

                        <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                            <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('remain_margin_amount')}</Text>
                            <Text
                                style={{
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                    fontSize: fontSizes.small,
                                    fontWeight: fontWeights.bold,
                                    flex: 1,
                                    textAlign: 'right',
                                }}
                            >
                                {FormatNumber(data.c56)}
                            </Text>
                        </View>
                    </>

                    <RowTitleGroup hasDivider text={t('list_debt')} type="group" />
                    <WarningOrInfo text={t('warn_press_to_repay_or_extend_margin')} />

                    <View style={{ flexDirection: 'row', paddingHorizontal: dimensions.moderate(8) }}>
                        <View style={{ flex: 3 }}>
                            <Text
                                style={{
                                    fontWeight: fontWeights.bold,
                                    fontSize: fontSizes.verySmall,
                                    textAlign: 'left',
                                    color: styles.HEADER__CONTENT__COLOR,
                                    flex: 1.2,
                                }}
                            >
                                {t('loan_date')}
                            </Text>
                            <Text
                                style={{
                                    fontWeight: fontWeights.bold,
                                    fontSize: fontSizes.verySmall,
                                    textAlign: 'left',
                                    color: styles.HEADER__CONTENT__COLOR,
                                }}
                            >
                                {t('date_due')}
                            </Text>
                        </View>
                        <View style={{ flex: 3 }}>
                            <Text
                                style={{
                                    fontWeight: fontWeights.bold,
                                    fontSize: fontSizes.verySmall,
                                    textAlign: 'right',
                                    color: styles.HEADER__CONTENT__COLOR,
                                }}
                            >
                                {t('loan_amount')}
                            </Text>
                            <Text
                                style={{
                                    fontWeight: fontWeights.bold,
                                    fontSize: fontSizes.verySmall,
                                    textAlign: 'right',
                                    color: styles.HEADER__CONTENT__COLOR,
                                }}
                            >
                                {t('loan_current')}
                            </Text>
                        </View>

                        <View style={{ flex: 4 }}>
                            <Text
                                style={{
                                    fontWeight: fontWeights.bold,
                                    fontSize: fontSizes.verySmall,
                                    textAlign: 'right',
                                    color: styles.HEADER__CONTENT__COLOR,
                                }}
                            >
                                {t('state_handle')}
                            </Text>
                        </View>
                    </View>
                    <FlatList
                        data={listCurMarginContract}
                        keyExtractor={(item, index) => String(index)}
                        ListEmptyComponent={EmptyView}
                        renderItem={ViewList}
                        scrollEnabled={false}
                        style={{ marginBottom: dimensions.vertical(32), paddingHorizontal: dimensions.moderate(8) }}
                    />
                </ScrollView>
            )}
            {isOpenActionSheet ? (
                <Modal
                    hideModalContentWhileAnimating={true}
                    isVisible={isOpenActionSheet}
                    style={UI.bottomModal}
                    useNativeDriver={true}
                    onBackButtonPress={hideModal}
                    onBackdropPress={hideModal}
                >
                    <ModalBottomContent title={t('margin_contract_detail')}>
                        <ModalBottomRowSelect
                            text={t('sb_exten_ctrmargin')}
                            onPress={() => {
                                hideModal()
                                navigation.navigate(Screens.RENEW_MARGIN_CONTRACT, {
                                    data: selectContract,
                                })
                            }}
                        />
                        <ModalBottomRowSelect
                            text={t('sb_margin_repay')}
                            onPress={() => {
                                hideModal()
                                navigation.navigate(Screens.DETAIL_MARGIN_REFUND, {
                                    data: selectContract,
                                })
                            }}
                        />
                    </ModalBottomContent>
                </Modal>
            ) : null}
        </View>
    )
}

const UI = StyleSheet.create({
    bottomModal: {
        justifyContent: 'flex-end',
        margin: 0,
    },
    row: {
        borderBottomWidth: 1,
        flexDirection: 'row',
        marginHorizontal: dimensions.moderate(16),
        paddingVertical: dimensions.vertical(9),
    },
})

export default memo(Debt)
