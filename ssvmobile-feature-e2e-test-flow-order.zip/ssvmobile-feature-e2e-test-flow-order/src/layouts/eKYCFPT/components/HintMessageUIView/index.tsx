import { default as React, useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { ActivityIndicator, Image, Pressable, StyleSheet, TouchableOpacity, View } from 'react-native'
import Animated, {
    Easing,
    Extrapolate,
    interpolate,
    useAnimatedStyle,
    useSharedValue,
    withDelay,
    withRepeat,
    withSpring,
    withTiming,
} from 'react-native-reanimated'

import { Text } from '../../../../basic-components'
import { StoreContext } from '../../../../store'
import { dimensions as dm, fontSizes } from '../../../../styles'

export const HintMessageUIView = ({ progress = 0, zIndex, messageHint }: { progress: 0 | 1 | 2 | 3 | 4 | number; zIndex: number; messageHint: string }) => {
    const { styles, theme, language } = useContext(StoreContext)
    const { t } = useTranslation()
    const [widthHint, setWidthHint] = useState(dm.WIDTH * 0.8)
    const [heightHint, setHeightHint] = useState(60)

    return (
        <View style={[UI.hint, { zIndex, borderColor: styles.SUCCESS__COLOR, backgroundColor: styles.PRIMARY__BG__COLOR }]}>
            <Pulse height={heightHint} repeat width={widthHint} />
            <TouchableOpacity
                disabled
                style={[
                    UI.capture,
                    {
                        backgroundColor: styles.PRIMARY,
                        borderColor: styles.PRIMARY,
                    },
                ]}
                onLayout={(event) => {
                    const { x, y, width, height } = event.nativeEvent.layout
                    setWidthHint(width + 32)
                    setHeightHint(height + 16)
                }}
            >
                {messageHint === 'ok_keep_it_a_bit' ? <ActivityIndicator color={styles.PRIMARY__CONTENT__COLOR} /> : null}
                {/* @ts-expect-error */}
                <Text
                    style={{
                        fontSize: fontSizes.medium,
                        color: styles.ICON__PRIMARY,
                        fontWeight: '600',
                        marginLeft: 8,
                    }}
                >
                    {t<string>(messageHint)}
                </Text>
            </TouchableOpacity>
        </View>
    )
}

const Pulse = ({ delay = 0, repeat, width, height }) => {
    const { styles, theme, language } = useContext(StoreContext)
    const animation = useSharedValue(0)
    useEffect(() => {
        animation.value = withDelay(
            delay,
            withRepeat(
                withTiming(1, {
                    duration: 700,
                    easing: Easing.linear,
                }),
                repeat ? -1 : 1,
                false,
            ),
        )
    }, [])
    const animatedStyles = useAnimatedStyle(() => {
        const opacity = interpolate(animation.value, [0.8, 1], [0.6, 0.3], Extrapolate.CLAMP)
        return {
            opacity: opacity,
            transform: [{ scale: animation.value }],
        }
    })
    return (
        <Animated.View
            style={[UI.pulseShape, { borderColor: styles.PRIMARY, backgroundColor: styles.SUCCESS__COLOR, overflow: 'visible', width, height }, animatedStyles]}
        />
    )
}

const UI = StyleSheet.create({
    capture: {
        alignSelf: 'center',
        borderRadius: 8,
        borderWidth: 1,
        flex: 0,
        flexDirection: 'row',
        paddingHorizontal: 20,
        paddingVertical: 8,
    },
    circle_style: {
        alignSelf: 'center',
        borderRadius: 50,
        height: 14,
        marginHorizontal: 3,
        width: 14,
    },
    container: {
        backgroundColor: '#ecf0f1',
        flex: 1,
        justifyContent: 'center',
        padding: 8,
    },
    hint: {
        // position: 'absolute',
        // flex: 1,
        // backgroundColor: 'red',
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        overflow: 'visible',
        paddingTop: 16,
        // width: '100%',
    },
    innerCircle: {
        backgroundColor: 'white',
        borderRadius: 40,
        height: 80,
        position: 'absolute',
        width: 80,
        zIndex: 100,
    },
    pulseShape: {
        borderRadius: 16,
        borderWidth: 4,
        overflow: 'visible',
        position: 'absolute',
        top: 8,
    },
    row: {
        alignItems: 'center',
        flexDirection: 'row',
        height: 32,
        justifyContent: 'center',
        marginBottom: 16,
        marginTop: -20,
        paddingHorizontal: dm.moderate(16),
    },
})
