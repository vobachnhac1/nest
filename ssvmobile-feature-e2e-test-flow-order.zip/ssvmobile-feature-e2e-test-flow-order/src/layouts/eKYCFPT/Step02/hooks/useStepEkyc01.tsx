import React, { useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Image, InteractionManager, Platform } from 'react-native'
import { RNCamera, TakePictureOptions, TakePictureResponse } from 'react-native-camera'
import ModalController from '@mts-components/appModal/modalControlller'
import Analytics, { EkycAnalyticEvents } from '@mts-utils/TrackingData/Analytics'
import { useNavigation } from '@react-navigation/native'
import moment from 'moment'

import { useLoading } from '../../../../hoc'
import { StoreContext } from '../../../../store'
import { IconSvg } from '../../../../styles'
import { eventList, glb_sv, reqFunct, Screens, sendRequest } from '../../../../utils'
import ekycService, { IFrontData } from '../../ekycService'
import { apiFPT, createFormData, fetchTimeout } from '../../middleProcess'

const ServiceInfo: IServiceInfo = {
    CHECK_ID_CARD_EXITS: {
        reqFunct: reqFunct.CHECK_ID_CARD_EXITS,
        WorkerName: 'FOSqAccount',
        ServiceName: 'FOSqAccount_Common_3',
        Operation: 'Q',
    },
}

export const useStepEkyc01 = ({ onProcessUploaded, isClearDataAndStartFromBegin, activeStep, switchStep, isHasPrevStep, subActiveStep }) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()
    const navigation = useNavigation()

    const cameraRef = useRef<RNCamera>(null)
    const [forceUpdate, setForceUpdate] = useState({})

    const [fileInfo, setFileInfo] = useState<TakePictureResponse | { uri: string }>({ uri: '' })
    const [loading, setLoading] = useLoading(false)
    const [uploaded, setUploaded] = useState<boolean | null>(null)
    const [urlSuccess, setUrlSuccess] = useState('')
    const [isAllowNextStep, setIsAllowNextStep] = useState(false) // if user has data image one server auto passed next step button
    const [idImage, setIdImage] = useState('')

    const [listMessage, setListMessage] = useState<string[]>([])
    const [isVisible, setIsVisible] = useState(!isHasPrevStep)

    // modal when capture image failed
    const [alertModal, setAlertModal] = useState(false)

    useEffect(() => {
        const commonEvent = glb_sv.commonEvent.subscribe((msg: any) => {
            if (msg.type === eventList.RESET_FPT_EKYC_DATA) {
                setFileInfo({ uri: '' })
                setLoading(false)
                setUploaded(null)
                setUrlSuccess('')
                setListMessage([])
                setIsVisible(true)
            }
        })
        return () => {
            commonEvent.unsubscribe()
        }
    }, [])

    useEffect(() => {
        if (ekycService.imageData.front_id) {
            setUrlSuccess(`data:image/jpeg;base64,${ekycService.imageData.front_id}`)
            setIsAllowNextStep(true)
            setIsVisible(false)
        }
    }, [])

    useEffect(() => {
        if (listMessage.length !== 0) {
            InteractionManager.runAfterInteractions(() => {
                setTimeout(() => {
                    setAlertModal(true)
                }, 300)
            })
        }
    }, [listMessage])

    useEffect(() => {
        if (isClearDataAndStartFromBegin) {
            onRemoveImages()
        }
    }, [isClearDataAndStartFromBegin])

    const onRemoveImages = () => {
        setFileInfo({ uri: '' })
        setUploaded(null)
        setUrlSuccess('')
        setLoading(false)
        setIsAllowNextStep(false)
        setIdImage('')
        setListMessage([])
        Analytics.logEvent(EkycAnalyticEvents.ekyc_step_two_take_front_again)
        glb_sv.sendEKYCLogNewTracking({
            sEKYCLog: EkycAnalyticEvents.ekyc_step_two_take_front_again,
            reason: 'Chụp lại CMND mặt trước',
            eKYCType: '4',
            ekycStep: '2',
        })
    }

    const renderFileUri = () => {
        if (fileInfo.uri || urlSuccess) {
            return (
                <Image
                    source={{ uri: fileInfo.uri || urlSuccess }}
                    style={{ height: '100%', width: '100%', borderRadius: 5, backgroundColor: styles.PRIMARY__BORDER__COLOR }}
                />
            )
        }
    }

    const takePicture = async () => {
        if (cameraRef.current) {
            const iosOptions: TakePictureOptions = { quality: 0.7, base64: false, width: 2000, orientation: 'portrait' }
            const androidOptions: TakePictureOptions = { quality: 0.9, base64: false, orientation: 'portrait' }
            const data = await cameraRef.current.takePictureAsync(Platform.OS === 'ios' ? iosOptions : androidOptions)
            const { width, height, uri, exif, pictureOrientation, deviceOrientation } = data
            setFileInfo(data)
            setUrlSuccess(uri)
        }
    }

    const onUploadData = async () => {
        if (isAllowNextStep === true) {
            switchStep.next()
            return
        }
        if (!urlSuccess) return
        try {
            const urlEnd = Platform.OS === 'ios' ? urlSuccess.replace('file://', '') : urlSuccess
            const fileData = await fetch(urlEnd)
            const {
                _bodyBlob: { _data: data },
            } = fileData
            const sec = glb_sv.activeCode
            const step = '1'
            const userId = glb_sv.objShareGlb.sessionInfo.userID
            const type = 'IMAGE'
            const timeout = 30000
            const mdmTp = Platform.OS === 'android' ? '03' : '04'
            const mwLoginID = Platform.OS === 'android' ? 'Android' : 'IOS'
            const body = createFormData(fileInfo, null, {
                sec,
                fileName: data.name,
                fileType: data.type,
                userId,
                size: data.size,
                step,
                type,
                timeout,
                Mdmtp: mdmTp,
                MWLoginID: mwLoginID,
            })
            setLoading(true)
            //Gửi request
            fetchTimeout(`${apiFPT}/upload/`, timeout, fetchingCallback, {
                method: 'POST',
                headers: { 'Content-Type': 'multipart/form-data' },
                body,
            })
                .then((response) => response.json())
                .then(async (data) => {
                    const dataLog = { ...data }
                    dataLog.cropped_idcard_base64 = ''
                    dataLog.face_base64 = ''
                    setLoading(false)
                    Analytics.logEvent(EkycAnalyticEvents.ekyc_step_two_take_front_upload)
                    glb_sv.sendEKYCLogNewTracking({
                        sEKYCLog: EkycAnalyticEvents.ekyc_step_two_take_front_upload,
                        eKYCType: '3',
                        reason: 'Chụp ảnh mặt trước CMND và upload đến bước tiếp theo',
                        ekycStep: '2',
                    })

                    if (data.success === true) {
                        if (data.errorCode !== 0) {
                            setUploaded(false)
                            setListMessage(data.errorMessage)
                        } else {
                            const isCheckSuccess: boolean = await checkDataFrontIDCard(dataLog)
                            if (isCheckSuccess) {
                                onProcessUploaded(data)
                            }
                        }
                    } else {
                        setUploaded(null)
                        setListMessage([data.error?.['message']])
                    }
                })
                .catch((error) => {
                    setLoading(false)
                    setUploaded(null)
                    if (error.name === 'AbortError') {
                        // Processing timeout
                        setListMessage(['request_hanlde_not_success_try_again'])
                    } else {
                        // network error or json parsing error
                        setListMessage(['Can_not_connected_to_server_plz_check_your_network'])
                    }
                })
        } catch (error) {
            setUploaded(null)
            setListMessage(['file_is_error_please_take_again'])
        }
        return
    }

    const fetchingCallback = () => {
        setLoading(false)
        setUploaded(null)

        // ToastGlobal.show({
        //     text2: t('common_server_no_response'),
        //     type: 'warning'
        // })

        return
    }

    const checkValidateDate = (dateString) => {
        // Check if the dateString is in the correct format (DD/MM/YYYY)
        const dateRegex = /^\d{2}\/\d{2}\/\d{4}$/
        if (!dateRegex.test(dateString) || !moment(dateString, 'DD/MM/YYYY', true).isValid()) {
            return false
        }

        // Split the dateString into day, month, and year components
        const [day, month, year] = dateString.split('/')

        // Check the ranges of month and year
        if (year < 1950 || year > 2100 || month == 0 || month > 12) return false

        const monthLength = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]

        // Adjust for leap years
        if (year % 400 == 0 || (year % 100 != 0 && year % 4 == 0)) monthLength[1] = 29

        // Check the range of the day
        return day > 0 && day <= monthLength[month - 1]
    }

    const checkDataFrontIDCard = async (data: IFrontData): Promise<boolean> => {
        // 1. Check trùng CMND
        // 2. Check Trùng ngày sinh + tên
        // 3. Check trùng ngày hết hạn đối với CCCD
        // 4. Check 18 tuổi
        // Chỉ return true 1 lần khi user pass hết toàn bộ
        // -----------

        if (data?.dob && checkValidateDate(data?.dob)) {
            const diffYears = moment().diff(moment(data.dob, 'DD/MM/YYYY'), 'years')
            if (!isNaN(diffYears)) {
                if (diffYears < 18) {
                    ModalController.showModal({
                        icon: <IconSvg.ErrorIcon color={styles.INFO__COLOR} />,
                        title: t('common_notify').toLocaleUpperCase(),
                        colorTitle: styles.EKYC__COLOR,
                        content: t('ekyc_user_not_18_please_contact'),
                        titleOK: t('continue').toLocaleUpperCase(),
                        typeColor: styles.INFO__COLOR,
                        showCancel: false,
                    })
                    return false
                }
            }
        } else {
            // ngay_sinh_mo_nhoe
            ModalController.showModal({
                icon: <IconSvg.ErrorIcon color={styles.INFO__COLOR} />,
                title: t('common_notify').toLocaleUpperCase(),
                colorTitle: styles.EKYC__COLOR,
                content: t('ngay_sinh_mo_nhoe'),
                titleOK: t('continue').toLocaleUpperCase(),
                typeColor: styles.INFO__COLOR,
            })
            return false
        }

        // Nếu ngày cấp bằng true và sau ngày hiện tại
        if (checkValidateDate(data?.doe) || data?.doe === 'N/A') {
            if (moment().isAfter(moment(data.doe, 'DD/MM/YYYY'))) {
                // Ngày hết hạn CCCD
                // có ngày hết hạn chứng mình nhân dân
                InteractionManager.runAfterInteractions(() => {
                    ModalController.showModal({
                        icon: <IconSvg.ErrorIcon color={styles.INFO__COLOR} />,
                        title: t('common_notify').toLocaleUpperCase(),
                        colorTitle: styles.EKYC__COLOR,
                        content: t('notify_info_ekyc_issue_loc_expired'),
                        titleOK: t('continue').toLocaleUpperCase(),
                        typeColor: styles.INFO__COLOR,
                        linkCallback: () => {
                            // @ts-expect-error
                            navigation.replace(Screens.SIGN_IN)
                        },
                        showCancel: false,
                    })
                })
                return false
            }
            const isCheckIDSuccess = await checkIdCardExits(data)
            return isCheckIDSuccess
        } else {
            // ngay_cap_mo_nhoe
            ModalController.showModal({
                icon: <IconSvg.ErrorIcon color={styles.INFO__COLOR} />,
                title: t('common_notify').toLocaleUpperCase(),
                colorTitle: styles.EKYC__COLOR,
                content: t('ngay_cap_mo_nhoe'),
                titleOK: t('continue').toLocaleUpperCase(),
                typeColor: styles.INFO__COLOR,
                showCancel: false,
            })
            return false
        }
    }

    const checkIdCardExits = async (data: any): Promise<boolean> => {
        const inval = ['CHK_ID_NO', data.id]
        const { reqInfoMap, message } = await new Promise<{ message: IServiceRespone; reqInfoMap: any }>((resolve, reject) => {
            sendRequest(ServiceInfo.CHECK_ID_CARD_EXITS, inval, (reqInfoMap: any, message: IServiceRespone) => resolve({ reqInfoMap, message }))
        })
        if (Number(message.Result) === 0) {
            return false
        } else {
            let jsondata: IServiceResponeData[] = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {
                return false
            }
            const idCardlExistedInfo = jsondata[0] || {}
            if (idCardlExistedInfo.c0 === 'Y') {
                ModalController.showModal({
                    icon: <IconSvg.ErrorIcon color={styles.EKYC__COLOR} />,
                    title: t('common_notify').toLocaleUpperCase(),
                    colorTitle: styles.EKYC__COLOR,
                    content: message.Message,
                    typeColor: styles.EKYC__COLOR,
                    titleOK: t('common_alert_agree').toLocaleUpperCase(),
                    linkCallback: () => {
                        // @ts-expect-error
                        navigation.replace(Screens.SIGN_IN)
                    },
                })
                return false
            }
            return true
        }
    }

    return {
        styles,
        t,
        isVisible,
        onUploadData,
        onRemoveImages,
        urlSuccess,
        uploaded,
        takePicture,
        renderFileUri,
        listMessage,
        cameraRef,
        setIsVisible,
        setAlertModal,
        alertModal,
        loading,
        forceUpdate,
        setLoading,
        switchStep,
    }
}
