import React from 'react'
import { ImageBackground, StyleSheet, TouchableOpacity } from 'react-native'
import Swiper from 'react-native-swiper'

import { Text } from '../../basic-components'
import { dimensions, fontSizes, fontWeights } from '../../styles'

export default ({ list, onChange, styles }) => {
    return (
        <Swiper
            activeDotStyle={{
                top: 25,
            }}
            autoplay
            dotColor={styles.PRIMARY__BG__COLOR}
            dotStyle={{
                top: 25,
            }}
            style={styless.wrapper}
        >
            {list.map((e) => (
                <TouchableOpacity
                    key={e.c0}
                    style={{ flex: 1 }}
                    onPress={() => onChange({ title: e.c4, link: e.c3, idNews: e.c0, isHTML: e.c15 === 'HTML', c5: e.c15 === 'HTML' ? 'TEXT' : '' })}
                >
                    <ImageBackground resizeMode="cover" source={{ uri: e.c7 }} style={styless.slide}>
                        <Text numberOfLines={2} style={styless.text}>
                            {e.c4}
                        </Text>
                    </ImageBackground>
                </TouchableOpacity>
            ))}
        </Swiper>
    )
}

const styless = StyleSheet.create({
    slide: {
        alignItems: 'center',
        height: 200,
        justifyContent: 'flex-end',
    },
    text: {
        bottom: 10,
        color: '#fff',
        fontSize: fontSizes.small,
        fontWeight: fontWeights.medium,
        padding: dimensions.halfIndent,
        textShadowColor: 'rgba(0, 0, 0, 0.85)',
        textShadowOffset: { width: -1, height: 1 },
        textShadowRadius: 5,
    },
    wrapper: {
        height: 200,
    },
})
