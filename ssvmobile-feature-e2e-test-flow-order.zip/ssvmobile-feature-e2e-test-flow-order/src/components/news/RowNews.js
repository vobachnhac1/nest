import React from 'react'
import { Image, Linking, StyleSheet, TouchableOpacity, View } from 'react-native'

import { Text } from '../../basic-components'
import { fontSizes } from '../../styles'

export default ({ title, subtitle, uri, link, styles, onChange }) => {
    return (
        <TouchableOpacity style={[styless.HeaderTop_view, { borderBottomColor: styles.DIVIDER__COLOR }]} onPress={() => onChange({ title, link })}>
            <View style={{ flex: 2, justifyContent: 'space-between' }}>
                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small }}>{title}</Text>
                <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.verySmall }}>{subtitle}</Text>
            </View>
            {uri ? <Image resizeMode="stretch" source={{ uri }} style={styless.image} /> : null}
        </TouchableOpacity>
    )
}

const styless = StyleSheet.create({
    HeaderTop_view: {
        borderBottomWidth: 1,
        flexDirection: 'row',
        paddingVertical: 10,
    },
    image: {
        height: 100,
        width: 100,
    },
})
