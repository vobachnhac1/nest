import React, { memo, useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { ActivityIndicator, StyleSheet, View } from 'react-native'
import moment from 'moment'

import { Text } from '../../../basic-components'
import { useCustomInteraction } from '../../../hoc'
import { StoreContext } from '../../../store'
import { StoreTrading } from '../../../store-trading'
import { dimensions } from '../../../styles'
import { eventList, glb_sv, sendRequest, subcribeFunctStream } from '../../../utils'
import WebviewMarketLiquity from './webview'

const getKeyExchange = (value) => {
    if (value.includes('HNXUpcomIndex')) {
        return 'HNXUpcomIndex'
    } else if (value.includes('HNX')) {
        return 'HNXIndex'
    } else {
        return 'HSXIndex'
    }
}
const getKeyExchangeAVG5Days = (value) => {
    if (value.includes('HNXUpcomIndex')) {
        return 'UPC_BRD_01'
    } else if (value.includes('HNX')) {
        return 'LIS_BRD_01'
    } else {
        return 'HSXIndex'
    }
}
const getKeyView = (value) => {
    if (value.includes('HNXUpcomIndex')) {
        return 'UPCOM'
    } else if (value.includes('HNX')) {
        return 'HNX'
    } else {
        return 'HOSE'
    }
}
const ListDataLiquity = {
    HSXIndex: [],
    HNXIndex: [],
    HNXUpcomIndex: [],
}

const hasGetHistLiquity = {
    HSXIndex: false,
    HNXIndex: false,
    HNXUpcomIndex: false,
}

const ServiceInfo = {
    GetHistAverage5Day: {
        WorkerName: 'FOSqMkt03',
        ServiceName: 'FOSqMkt03_HistTrading',
        Operation: 'Q',
    },
}

const MarketLiquity = ({ active }) => {
    useCustomInteraction()
    const { t } = useTranslation()
    const exchangeState = getKeyExchange(active)
    const exchangeStateAVG5Day = getKeyExchangeAVG5Days(active)
    const { filterOption } = useContext(StoreTrading)
    const { theme, styles } = React.useContext(StoreContext)
    const [loading, setLoading] = useState(false)
    const [exchangeCode, setExchangeCode] = useState(exchangeState)
    const [updateSeq, setUpdateSeq] = useState(0)
    //---------
    const [liquityData, setLiquityData] = useState([])
    const [liquityData5day, setLiquidityData5Day] = useState([])
    // console.log(test);
    //---------
    const lastSeqChart = useRef(9999999999) // Bắt đầu là seq lớn nhất
    const dataAVG5days = useRef([])

    //---------
    useEffect(() => {
        GetHistAverage5Day()
    }, [active])
    useEffect(() => {
        //-----
        subcribeFunctStream('GET_HIST', ['INTRADAY_1m'], ['HSXIndex'], [0], [500], 'INDEX')
        subcribeFunctStream('GET_HIST', ['INTRADAY_1m'], ['HNXIndex'], [0], [500], 'INDEX')
        subcribeFunctStream('GET_HIST', ['INTRADAY_1m'], ['HNXUpcomIndex'], [0], [500], 'INDEX')
        subcribeFunctStream('SUB', ['INTRADAY_1m'], ['HSXIndex', 'HNXIndex', 'HNXUpcomIndex'])
        // //----
        const eventMarket = glb_sv.eventMarket.subscribe((msg) => {
            if (msg.type === eventList.GET_DATA_I_MINUTES_DONE) {
                if (msg.msgKey === 'HSXIndex') {
                    const data = glb_sv.IndexMarket.HSXIndex?.arrMinutes
                    ListDataLiquity.HSXIndex = [...data]
                    setUpdateSeq((prev) => prev + 1)
                }
                if (msg.msgKey === 'HNXIndex') {
                    const data = glb_sv.IndexMarket.HNXIndex?.arrMinutes
                    ListDataLiquity.HNXIndex = [...data]
                    setUpdateSeq((prev) => prev + 1)
                }
                if (msg.msgKey === 'HNXUpcomIndex') {
                    const data = glb_sv.IndexMarket.HNXUpcomIndex?.arrMinutes
                    ListDataLiquity.HNXUpcomIndex = [...data]
                    setUpdateSeq((prev) => prev + 1)
                }
            }
            if (msg.type === eventList.MKT_INTRADAY) {
                // console.log(msg)
                const T = glb_sv.timeServer + '-' + msg?.T
                const time = moment(T, 'YYYYMMDD-HH:mm:ss:SSSSSS').valueOf()
                const converted = {
                    T,
                    time,
                    ...msg,
                }
                // ----
                if (msg.S === 'HSXIndex') {
                    const data = [...ListDataLiquity.HSXIndex]
                    ListDataLiquity.HSXIndex = [...data, converted]
                    setUpdateSeq((prev) => prev + 1)
                }
                if (msg.S === 'HNXIndex') {
                    const data = [...ListDataLiquity.HNXIndex]
                    ListDataLiquity.HNXIndex = [...data, converted]
                    setUpdateSeq((prev) => prev + 1)
                }
                if (msg.S === 'HNXUpcomIndex') {
                    const data = [...ListDataLiquity.HNXUpcomIndex]
                    ListDataLiquity.HNXUpcomIndex = [...data, converted]
                    setUpdateSeq((prev) => prev + 1)
                }
            }
        })
        return () => {
            eventMarket.unsubscribe()
            // subcribeFunctStream('UNSUB', ['INTRADAY_1m'], glb_sv.listIndex)
        }
    }, [])

    useEffect(() => {
        setLiquityData([...ListDataLiquity[exchangeState]])
    }, [active, updateSeq])

    const GetHistAverage5Day = () => {
        setLoading(true)
        const InputParams = ['AVG', '7', exchangeStateAVG5Day]
        sendRequest(ServiceInfo.GetHistAverage5Day, InputParams, handleGetHistAverage5Day) //true, handleGetMarketTopTimeout
    }
    const handleGetHistAverage5Day = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {}
            dataAVG5days.current = dataAVG5days.current.concat(jsondata)
            if (Number(message.Packet) <= 0) {
                setLiquidityData5Day(dataAVG5days.current)
                dataAVG5days.current = []
                setTimeout(() => {
                    setLoading(false)
                }, 300)
            }
        }
    }
    return (
        <View style={UI.view}>
            {loading ? (
                <View style={{ alignItems: 'center', justifyContent: 'center' }}>
                    <ActivityIndicator color={styles.PRIMARY} size={24} />
                </View>
            ) : null}
            <WebviewMarketLiquity
                colorsTheme={JSON.stringify(styles)}
                dataChart={JSON.stringify(liquityData)}
                dataChartAvg5day={JSON.stringify(liquityData5day)}
                exchangeTitle={getKeyView(active)}
                t={t}
            />
        </View>
    )
}

export default memo(MarketLiquity)

const UI = StyleSheet.create({
    view: {
        height: dimensions.IOS ? dimensions.HIEGHT - 230 : dimensions.HIEGHT - 170,
        width: dimensions.WIDTH,
    },
})
