import React, { useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { StyleSheet, View } from 'react-native'
import Modal from 'react-native-modal'
import Svg, { Path } from 'react-native-svg'
import ToastGlobal from 'react-native-toast-message'
import { useNavigation } from '@react-navigation/native'

import { Text } from '../../../../basic-components'
import ModalLoading from '../../../../components/modal-loading'
import { ButtonCustom, ModalContent, RowDataModal, RowTitleGroup } from '../../../../components/trading-component'
import { useLoading } from '../../../../hoc'
import { StoreContext } from '../../../../store'
import { StoreTrading } from '../../../../store-trading'
import { dimensions, fontSizes, IconSvg } from '../../../../styles'
import { glb_sv, reqFunct, sendRequest } from '../../../../utils'
import { OtherUtilsCashAdvance } from '../components/OtherUtilsCashAdvance'
import { OtherUtilsEmailReport } from '../components/OtherUtilsEmailReport'
import { OtherUtilsOTP } from '../components/OtherUtilsOTP'
import { OtherUtilsSMS } from '../components/OtherUtilsSMS'

const ServiceInfo = {
    QUERY_ACCOUNT_SERVICE: {
        reqFunct: reqFunct.QUERY_ACCOUNT_SERVICE,
        WorkerName: 'FOSqAccount01',
        ServiceName: 'FOSqAccount01_Update0102_online_1',
        ClientSentTime: '0',
        Operation: 'Q',
    },
    UPDATE_USER_NOTIFY_SERVICE_INFO: {
        reqFunct: reqFunct.UPDATE_USER_NOTIFY_SERVICE_INFO,
        WorkerName: 'FOSxAccount01',
        ServiceName: 'FOSxAccount01_Update0102_online_1',
        Operation: 'U',
    },
}

const UpdateOtherService = ({ userData, onRefresh, refreshing }) => {
    const { t } = useTranslation()
    const { styles } = useContext(StoreContext)

    const [isUpdateCommonInfo, setIsUpdateCommonInfo] = useState(false)
    const [loadingConfirm, setLoadingConfirm] = useLoading(false)
    const [newMarginValue, setNewMarginValue] = useState('')
    const navigation = useNavigation()
    const { userInfo } = useContext(StoreTrading)
    const [isAutoPia, setIsAutoPia] = useState(false) // Ứng trước tự động
    const [currentOTPType, setCurrentOTPType] = useState('')
    // const [isOtpStatic, setIsOtpStatic] = useState(false) // Gửi tin nhắn OTP tĩnh
    // const [isOtpMatrix, setIsOtpMatrix] = useState(false) // Gửi tiun nhắn OTP Matrix
    // const [isOtpSMS, setIsOtpSMS] = useState(false) // Gửi tin nhắn OTP SMS
    const [isSMSFree, setIsSMSFree] = useState(false) // Gửi tin nhắn miễn phí
    const [isSMSAlert, setIsSMSAlert] = useState(false) // Gửi tin nhắn thông báo
    const [isSMSCharge, setIsSMSCharge] = useState(false) // Gửi tin nhắn trả phí
    const [isEmail, setIsEmail] = useState(false) // Gửi email
    const [isMonthlyReport, setIsMonthlyReport] = useState(false) // Gửi báo cáo tháng

    const [disableUpdateOtherService, setDisableUpdateOtherService] = useLoading(false)

    const optionsOTP = useRef([
        {
            label: t('static_OTP'),
            value: '4',
        },
        {
            label: t('matrix_code'),
            value: '2',
        },
        {
            label: t('SMS'),
            value: '1',
        },
    ])

    // ------
    useEffect(() => {
        queryServicesInfo()
    }, [userInfo.actn_curr])

    useEffect(() => {
        if (refreshing) {
            queryServicesInfo()
        }
    }, [refreshing])

    const queryServicesInfo = () => {
        const { actn_curr, sub_curr } = userInfo
        if (!actn_curr || !sub_curr) return
        const InputParams = [actn_curr]
        sendRequest(ServiceInfo.QUERY_ACCOUNT_SERVICE, InputParams, handleQueryServiceResult, true, handleQueryServiceTimeout)
        setDisableUpdateOtherService(true)
    }

    const handleQueryServiceResult = (reqInfoMap, message) => {
        console.log('handleQueryServiceResult', reqInfoMap, message)
        if (Number(message.Result) === 0) {
            // ToastGlobal.show({
            //     type: 'warning',
            //     text2: message['Message'],
            // })
            return
        } else {
            let jsondata
            try {
                jsondata = JSON.parse(message.Data)[0]
            } catch (error) {
                console.log('error', error)
                jsondata = {}
            }
            if (Number(message.Packet) <= 0) {
                setIsAutoPia(jsondata.c0 === 'Y')
                setCurrentOTPType(jsondata.c1)
                // if (jsondata['c1'] === '1') {
                //     setIsOtpStatic(false)
                //     setIsOtpMatrix(false)
                //     setIsOtpSMS(true)
                // } else if (jsondata['c1'] === '2') {
                //     setIsOtpStatic(false)
                //     setIsOtpMatrix(true)
                //     setIsOtpSMS(false)
                // } else if (jsondata['c1'] === '4') {
                //     setIsOtpStatic(true)
                //     setIsOtpMatrix(false)
                //     setIsOtpSMS(false)
                // }
                setIsSMSFree(jsondata.c2 === 'Y')
                setIsSMSAlert(jsondata.c3 === 'Y')
                setIsSMSCharge(jsondata.c4 === 'Y')
                setIsMonthlyReport(jsondata.c5 === 'Y')
                setDisableUpdateOtherService(false)
            }
            // Lưu lại data và append lên form
        }
    }

    const handleQueryServiceTimeout = (e) => {
        ToastGlobal.show({
            type: 'warning',
            text2: t('common_cant_connect_server'),
        })
    }

    const hideModal = () => {
        setIsUpdateCommonInfo(false)
    }

    const confirmUpadateInfo = () => {
        setIsUpdateCommonInfo(false)
        updateUserNotifyInfo()
    }

    // const getOTPType = () => {
    //         if (isOtpStatic) return '4'
    //         if (isOtpMatrix) return '2'
    //         if (isOtpSMS) return '1'
    //         return currentOTPType
    // }

    const updateUserNotifyInfo = () => {
        // -------
        const InputParams = [
            userInfo.actn_curr,
            isAutoPia ? 'Y' : 'N',
            currentOTPType,
            isSMSFree ? 'Y' : 'N',
            isSMSAlert ? 'Y' : 'N',
            isSMSCharge ? 'Y' : 'N',
            isEmail ? 'Y' : 'N',
            isMonthlyReport ? 'Y' : 'N',
        ]
        sendRequest(
            ServiceInfo.UPDATE_USER_NOTIFY_SERVICE_INFO,
            InputParams,
            updateUserNotifyInfoResult,
            true,
            updateUserNotifyInfoTimeout,
            '',
            null,
            'equal_service',
        )
        setLoadingConfirm(true)
    }

    const updateUserNotifyInfoTimeout = () => {
        setLoadingConfirm(false)
    }

    const updateUserNotifyInfoResult = (reqInfoMap, message) => {
        setLoadingConfirm(false)
        if (Number(message.Result) === 0) {
            ToastGlobal.show({
                type: 'warning',
                text2: message.Message,
            })
            return
        } else {
            let jsondata = {}
            try {
                jsondata = message.Data ? JSON.parse(message.Data)[0] : {}
            } catch (err) {}
            ToastGlobal.show({
                type: 'success',
                text2: message.Message,
            })
            onRefresh()
        }
    }

    return (
        <View style={{ paddingBottom: dimensions.moderate(8) }}>
            <RowTitleGroup hasDivider text={t('change_settings_service_and_utils')} />
            <OtherUtilsEmailReport isMonthlyReport={isMonthlyReport} setIsMonthlyReport={setIsMonthlyReport} />
            <OtherUtilsCashAdvance isAutoPia={isAutoPia} setIsAutoPia={setIsAutoPia} />
            {/* <OtherUtilsOTP
                isOtpStatic={isOtpStatic}
                setIsOtpStatic={setIsOtpStatic}
                isOtpMatrix={isOtpMatrix}
                setIsOtpMatrix={setIsOtpMatrix}
                isOtpSMS={isOtpSMS}
                setIsOtpSMS={setIsOtpSMS}
            /> */}
            <OtherUtilsSMS
                isSMSAlert={isSMSAlert}
                isSMSCharge={isSMSCharge}
                isSMSFree={isSMSFree}
                setIsSMSAlert={setIsSMSAlert}
                setIsSMSCharge={setIsSMSCharge}
                setIsSMSFree={setIsSMSFree}
            />

            <ButtonCustom disabled={disableUpdateOtherService} text={t('update_info')} onPress={() => setIsUpdateCommonInfo(true)} />

            {isUpdateCommonInfo ? (
                <Modal isVisible={isUpdateCommonInfo} useNativeDriver={true} onBackButtonPress={hideModal} onBackdropPress={hideModal}>
                    <ModalContent
                        iconComponent={
                            <Svg fill="none" height="32" viewBox="0 0 33 32" width="33" xmlns="http://www.w3.org/2000/svg">
                                <Path
                                    d="M7.53452 6.48793L20.2914 3.00584L19.6158 1.64032C19.1738 0.752727 18.0958 0.386191 17.2082 0.82819L5.78809 6.48793H7.53452Z"
                                    fill="#2ECC71"
                                />
                                <Path
                                    d="M24.2509 3.10547C24.0928 3.10547 23.9346 3.12703 23.7765 3.17015L20.7796 3.98946L11.627 6.48693H22.0157H26.5435L25.9829 4.43146C25.7673 3.63012 25.0414 3.10547 24.2509 3.10547Z"
                                    fill="#2ECC71"
                                />
                                <Path
                                    d="M28.4164 7.74609H28.0068H27.4498H26.8928H22.6417H7.02082H4.97253H3.24766H2.92784H1.85698C1.28921 7.74609 0.782525 8.00842 0.451924 8.42167C0.300998 8.61212 0.186006 8.83133 0.121323 9.07209C0.081795 9.22302 0.0566406 9.38113 0.0566406 9.54284V9.75845V11.8067V29.5622C0.0566406 30.554 0.861582 31.3589 1.85338 31.3589H28.4128C29.4047 31.3589 30.2096 30.554 30.2096 29.5622V24.5492H19.5477C17.8624 24.5492 16.4932 23.1801 16.4932 21.4948V19.849V19.292V18.735V17.4988C16.4932 16.6723 16.8238 15.9213 17.3593 15.3715C17.8336 14.8828 18.4697 14.5522 19.1812 14.4695C19.2998 14.4552 19.4219 14.4479 19.5441 14.4479H28.7147H29.2717H29.8287H30.2096V9.54284C30.2132 8.55103 29.4082 7.74609 28.4164 7.74609Z"
                                    fill="#2ECC71"
                                />
                                <Path
                                    d="M31.47 16.1641C31.2903 15.9988 31.0783 15.873 30.8411 15.7903C30.6578 15.7293 30.4638 15.6934 30.259 15.6934H30.2123H30.1763H29.6193H27.6106H19.5468C18.5549 15.6934 17.75 16.4983 17.75 17.4901V18.3848V18.9418V19.4988V21.4896C17.75 22.4814 18.5549 23.2864 19.5468 23.2864H30.2123H30.259C30.4638 23.2864 30.6578 23.2504 30.8411 23.1893C31.0783 23.1103 31.2903 22.9809 31.47 22.8156C31.8293 22.4886 32.0557 22.0143 32.0557 21.4897V17.4901C32.0557 16.9654 31.8293 16.491 31.47 16.1641ZM23.2984 19.8474C23.2984 20.3433 22.8959 20.7458 22.4 20.7458H21.8035C21.3076 20.7458 20.9051 20.3433 20.9051 19.8474V19.2509C20.9051 18.9634 21.0381 18.7082 21.2501 18.5465C21.4046 18.4279 21.5951 18.3525 21.8035 18.3525H21.9544H22.4C22.8959 18.3525 23.2984 18.7549 23.2984 19.2509V19.8474Z"
                                    fill="#2ECC71"
                                />
                            </Svg>
                        }
                        title={t('update_info')}
                        type="confirm"
                    >
                        <View style={UI.RowModalTitle}>
                            <View style={{ flex: 12, justifyContent: 'center' }}>
                                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal }}>{t('recivce_report_via_email')}</Text>
                            </View>
                        </View>
                        <RowDataModal
                            rightComponent={
                                <IconSvg.CheckboxIcon active={isMonthlyReport} colorActive={styles.PRIMARY} colorunActive={styles.PRIMARY__CONTENT__COLOR} />
                            }
                            textLeft={t('monthly_report')}
                        />
                        <View style={UI.RowModalTitle}>
                            <View style={{ flex: 12, justifyContent: 'center' }}>
                                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal }}>{t('sb_cash_advance')}</Text>
                            </View>
                        </View>
                        <RowDataModal
                            rightComponent={
                                <IconSvg.CheckboxIcon active={isAutoPia} colorActive={styles.PRIMARY} colorunActive={styles.PRIMARY__CONTENT__COLOR} />
                            }
                            textLeft={t('automatic')}
                        />
                        <View style={UI.RowModalTitle}>
                            <View style={{ flex: 12, justifyContent: 'center' }}>
                                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal }}>{t('head_sms')}</Text>
                            </View>
                        </View>
                        <RowDataModal
                            rightComponent={
                                <IconSvg.CheckboxIcon active={isSMSFree} colorActive={styles.PRIMARY} colorunActive={styles.PRIMARY__CONTENT__COLOR} />
                            }
                            textLeft={t('free_sms')}
                        />
                        <RowDataModal
                            rightComponent={
                                <IconSvg.CheckboxIcon active={isSMSAlert} colorActive={styles.PRIMARY} colorunActive={styles.PRIMARY__CONTENT__COLOR} />
                            }
                            textLeft={t('notify_sms')}
                        />
                        <RowDataModal
                            rightComponent={
                                <IconSvg.CheckboxIcon active={isSMSCharge} colorActive={styles.PRIMARY} colorunActive={styles.PRIMARY__CONTENT__COLOR} />
                            }
                            textLeft={t('advance_sms')}
                        />

                        <ButtonCustom text={t('common_button_confirm')} type="confirm" onPress={confirmUpadateInfo} />
                        <ButtonCustom last text={'common_Cancel'} type="back" onPress={hideModal} />
                    </ModalContent>
                </Modal>
            ) : null}
            {loadingConfirm ? <ModalLoading content={t('common_processing')} visible={loadingConfirm} /> : null}
        </View>
    )
}

const UI = StyleSheet.create({
    RowInput: {
        marginVertical: dimensions.vertical(8),
    },
    RowModalTitle: {
        borderBottomColor: '#444c575d',
        flexDirection: 'row',
        marginHorizontal: dimensions.moderate(16),
        paddingVertical: dimensions.vertical(8), // styles.DIVIDER__MODAL__COLOR,
    },
    row: {
        alignItems: 'center',
        borderRadius: 12,
        flexDirection: 'row',
        marginHorizontal: dimensions.moderate(16),
        marginTop: dimensions.vertical(12),
    },
    viewInput: {
        borderRadius: 8,
        borderWidth: 0.6,
        paddingHorizontal: dimensions.moderate(16),
        paddingVertical: dimensions.vertical(8),
    },
})

export default UpdateOtherService
