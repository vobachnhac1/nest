import React, { memo, useMemo } from 'react'
import { StyleSheet, TouchableWithoutFeedback, View } from 'react-native'

import { Text } from '../../../basic-components'
import { dimensions, fontSizes, fontWeights } from '../../../styles'

const OptionsTop = ({ title, active, onChange, styles, isLast, value }) => {
    const ViewWrapUI = useMemo(
        () =>
            StyleSheet.flatten([
                UI.view,
                active ? { backgroundColor: styles.PRIMARY } : { backgroundColor: styles.BUTTON__SECONDARY },
                isLast ? { marginRight: 0 } : null,
            ]),
        [styles, active],
    )
    const TextWrapUI = useMemo(
        () => StyleSheet.flatten([UI.title, active ? { color: '#FFF', fontWeight: fontWeights.semiBold } : { color: styles.PRIMARY__CONTENT__COLOR }]),
        [styles, active],
    )

    return (
        <TouchableWithoutFeedback onPress={() => onChange(value)}>
            <View style={ViewWrapUI}>
                <Text style={TextWrapUI}>{title}</Text>
            </View>
        </TouchableWithoutFeedback>
    )
}
export default memo(OptionsTop)

const UI = StyleSheet.create({
    title: {
        fontSize: fontSizes.smallest,
        fontWeight: fontWeights.medium,
        lineHeight: dimensions.moderate(20, 0.3),
        textAlign: 'center',
    },
    view: {
        borderRadius: 8,
        marginRight: dimensions.vertical(6, 0.3),
        paddingHorizontal: dimensions.moderate(22, 0.3),
        paddingVertical: dimensions.vertical(2, 0.3),
    },
})
