import React, { memo, useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { FlatList, InteractionManager, StyleSheet, TouchableOpacity, TouchableWithoutFeedback, View } from 'react-native'
import Svg, { Path } from 'react-native-svg'
import isEqual from 'lodash/isEqual'
import { Button, Row } from 'native-base'
import SyncStorage from 'sync-storage'

import { Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { dimensions, fontSizes, fontWeights } from '../../styles'
import { eventList, glb_sv, STORE_KEY } from '../../utils'

const BottomModal = ({ navigation }) => {
    const { styles } = useContext(StoreContext)
    const [listActive, setListActive] = useState(glb_sv.listActiveIndex)
    const [isEffect, setEffect] = useState(false)

    const [listIndex, setListIndex] = useState([...glb_sv.listIndex])

    const { t } = useTranslation()

    useEffect(() => {
        const eventMarket = glb_sv.eventMarket.subscribe((msg) => {
            if (msg.type === eventList.GET_LIST_INDEX) {
                const newList = [...listActive]
                setListActive(newList)
                setListIndex([...glb_sv.listIndex])
            }
        })
        return () => {
            eventMarket.unsubscribe()
        }
    }, [])

    const handleAction = () => {
        if (isEffect) {
            if (!isEqual(glb_sv.listActiveIndex, listActive)) {
                SyncStorage.set(STORE_KEY.LIST_ACTIVE_INDEX, listActive)
                glb_sv.listActiveIndex = listActive
                glb_sv.eventMarket.next({ type: eventList.CHANGE_LIST_INDEX_CHART })
            }
            InteractionManager.runAfterInteractions(() => {
                navigation.pop()
            })
        } else navigation.pop()
    }

    const hanldeAddIndex = (item) => {
        if (listActive.some((e) => e === item)) {
            hanldeRemoveIndex(item)
            return
        }
        const newList = [...listActive]
        if (newList.length === 3) newList.shift()
        newList.push(item)
        setListActive(newList)
        setEffect(true)
    }

    const hanldeRemoveIndex = (item) => {
        const newList = listActive.filter((e) => e !== item)
        setListActive(newList)
        if (newList.length) setEffect(true)
        else setEffect(false)
    }

    const getNameIndex = (index) => {
        if (glb_sv.IndexMarket[index]) {
            return glb_sv.IndexMarket[index].indexName
        } else index
    }

    return (
        <TouchableWithoutFeedback onPress={() => navigation.pop()}>
            <View
                style={{
                    flex: 1,
                    backgroundColor: 'transparent',
                    alignItems: 'center',
                    justifyContent: 'flex-end',
                }}
            >
                <TouchableWithoutFeedback onPress={null}>
                    <View
                        style={{
                            backgroundColor: styles.PRIMARY__BG__COLOR,
                            paddingBottom: dimensions.vertical(34),
                            paddingTop: dimensions.vertical(24),
                            borderRadius: 10,
                            height: dimensions.HIEGHT * 0.7,
                            width: dimensions.WIDTH,
                            zIndex: 999,
                        }}
                    >
                        <Row style={{ justifyContent: 'center', flex: 0, marginBottom: dimensions.vertical(24) }}>
                            <Text
                                style={{
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                    fontSize: fontSizes.medium,
                                    fontWeight: fontWeights.semiBold,
                                    lineHeight: dimensions.moderate(22),
                                }}
                            >
                                {t('indicator_options')}
                            </Text>
                        </Row>
                        <FlatList
                            data={listIndex}
                            keyExtractor={(item) => item}
                            numColumns={3}
                            renderItem={({ item }) => (
                                <TouchableOpacity
                                    style={[
                                        UI.view,
                                        {
                                            backgroundColor: listActive.includes(item) ? styles.UP__COLOR + '1a' : styles.PRIMARY__BG__COLOR,
                                            borderColor: listActive.includes(item) ? styles.UP__COLOR : styles.FOURTH__BORDER__COLOR,
                                        },
                                    ]}
                                    onPress={() => hanldeAddIndex(item)}
                                >
                                    <Text numberOfLines={1} style={{ ...UI.text, color: styles.PRIMARY__CONTENT__COLOR }}>
                                        {getNameIndex(item)}
                                    </Text>
                                    {listActive.includes(item) && (
                                        <TouchableOpacity style={UI.close}>
                                            <Svg
                                                fill="none"
                                                height={dimensions.moderate(16.25)}
                                                viewBox="0 0 20 20"
                                                width={dimensions.moderate(16.25)}
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <Path
                                                    d="M10 1.875C5.52 1.875 1.875 5.52 1.875 10S5.52 18.125 10 18.125 18.125 14.48 18.125 10 14.48 1.875 10 1.875zm2.942 10.183a.624.624 0 11-.884.884L10 10.884l-2.058 2.058a.625.625 0 01-.884-.884L9.116 10 7.058 7.942a.625.625 0 01.884-.884L10 9.116l2.058-2.058a.625.625 0 01.884.884L10.884 10l2.058 2.058z"
                                                    fill="#fff"
                                                />
                                                <Path
                                                    d="M12.942 12.058a.624.624 0 11-.884.884L10 10.884l-2.058 2.058a.625.625 0 01-.884-.884L9.116 10 7.058 7.942a.625.625 0 01.884-.884L10 9.116l2.058-2.058a.625.625 0 01.884.884L10.884 10l2.058 2.058z"
                                                    fill="#fff"
                                                />
                                                <Path
                                                    d="M10 1.875C5.52 1.875 1.875 5.52 1.875 10S5.52 18.125 10 18.125 18.125 14.48 18.125 10 14.48 1.875 10 1.875zm2.942 10.183a.624.624 0 11-.884.884L10 10.884l-2.058 2.058a.625.625 0 01-.884-.884L9.116 10 7.058 7.942a.625.625 0 01.884-.884L10 9.116l2.058-2.058a.625.625 0 01.884.884L10.884 10l2.058 2.058z"
                                                    fill={styles.DOWN__COLOR}
                                                />
                                            </Svg>
                                        </TouchableOpacity>
                                    )}
                                </TouchableOpacity>
                            )}
                            showsHorizontalScrollIndicator={false}
                            style={{ marginHorizontal: dimensions.moderate(12), flexGrow: 0 }}
                        />
                        <Row style={{ justifyContent: 'center', flex: 0, marginBottom: dimensions.vertical(26), marginTop: dimensions.vertical(24) }}>
                            <Text
                                style={{
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                    fontSize: fontSizes.medium,
                                    lineHeight: dimensions.moderate(22),
                                    opacity: 0.64,
                                }}
                            >
                                {t('note_indicator_options')}
                            </Text>
                        </Row>
                        <Button style={{ ...UI.button, backgroundColor: isEffect ? styles.PRIMARY : styles.PRIMARY + '4d' }} onPress={handleAction}>
                            <Text style={{ color: '#FFF', fontSize: fontSizes.small }}>{t('common_Ok')}</Text>
                        </Button>
                    </View>
                </TouchableWithoutFeedback>
                <View style={{ ...StyleSheet.absoluteFill, backgroundColor: styles.PRIMARY__CONTENT__COLOR, opacity: 0.2 }} />
            </View>
        </TouchableWithoutFeedback>
    )
}

const UI = StyleSheet.create({
    button: {
        alignSelf: 'center',
        elevation: 0,
        justifyContent: 'center',
        paddingHorizontal: 105,
    },
    circle: {
        borderRadius: 4,
        height: 8,
        marginTop: 3,
        width: 8,
    },
    close: {
        borderRadius: dimensions.moderate(16.25) / 2,
        height: dimensions.moderate(16.25),
        position: 'absolute',
        right: -5,
        top: -5,
        width: dimensions.moderate(16.25),
    },
    text: {
        fontSize: fontSizes.verySmall,
        fontWeight: fontWeights.medium,
        lineHeight: dimensions.moderate(22),
    },
    view: {
        alignItems: 'center',
        borderRadius: 4,
        borderWidth: 0.75,
        justifyContent: 'center',
        marginHorizontal: dimensions.moderate(4),
        marginVertical: dimensions.vertical(4),
        paddingHorizontal: dimensions.moderate(10),
        paddingVertical: dimensions.vertical(10),
        width: (dimensions.WIDTH - dimensions.moderate(12) * 2) / 3 - dimensions.moderate(4) * 2,
    },
})

export default memo(BottomModal)
