import React, { useContext, useEffect, useState } from 'react'
import { ActivityIndicator, Platform, StyleSheet, View } from 'react-native'
import { ProgressBar } from 'react-native-paper'
import Share from 'react-native-share'
import WebView from 'react-native-webview'
import { Container } from 'native-base'

import HeaderComponent from '../../components/header'
import { StoreContext } from '../../store'
import { glb_sv, reqFunct, saveStatisticTrackingNews, sendRequest } from '../../utils'

const ServiceInfo = {
    GET_DETAILS_NEWS: {
        reqFunct: reqFunct.GET_DETAILS_NEWS,
        WorkerName: 'FOSqNews',
        ServiceName: 'FOSqNews_NewsInfo',
        ClientSentTime: '0',
        Operation: 'Q',
    },
}

export default function NewsDetail({ navigation, route }) {
    const { link, title, c5, c6, idNews, isHTML } = route.params

    const { styles } = useContext(StoreContext)
    const [visible, setVisible] = useState(true)
    const [progress, setProgress] = useState(0)

    const [html, setHtml] = useState('')

    useEffect(() => {
        const timeout = setTimeout(() => {
            setVisible(false)
        }, 3000)

        if (isHTML && idNews) {
            const InputParams = ['10', idNews]
            sendRequest(ServiceInfo.GET_DETAILS_NEWS, InputParams, getNewsResultProc, true, getNewsResultProcTimeout, null, 3000)
            setHtml(' ')
        }

        if (idNews) {
            saveStatisticTrackingNews(idNews)
        }
        return () => clearTimeout(timeout)
    }, [])

    const getNewsResultProcTimeout = () => {}

    const getNewsResultProc = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            return
        } else {
            try {
                if (message.Data) {
                    const jsondata = JSON.parse(glb_sv.filterStrBfParse(message.Data))
                    setHtml(jsondata[0] ? jsondata[0].c1 : ' ')
                    console.log('getNewsResultProc -> jsondata', jsondata)
                }
            } catch (err) {
                console.error('getNewsResultProc error', err)
                return
            }
        }
    }

    const openShare = () => {
        const options = {
            title,
            url: link,
        }
        Share.open(options)
            .then((res) => {
                console.log(res)
            })
            .catch((err) => {
                err && console.log(err)
            })
    }

    return (
        <Container
            style={{
                backgroundColor: styles.PRIMARY__BG__COLOR,
            }}
        >
            <View style={[UI.container, { backgroundColor: styles.PRIMARY__BG__COLOR }]}>
                <HeaderComponent
                    colorTitle={styles.PRIMARY__CONTENT__COLOR}
                    isShowLeft={true}
                    isShowRight={true}
                    maxTitleLine={1}
                    navigation={navigation}
                    rightButtonIcon={'sharealt'}
                    rightButtonLink={openShare}
                    title={title}
                    titleAlgin="flex-start"
                    transparent
                />
                <ProgressBar color={styles.PRIMARY} progress={progress} style={{ height: 2 }} />

                <WebView
                    originWhitelist={['*']}
                    source={c5 === 'TEXT' ? { html: html || c6 } : { uri: getLink(link) }}
                    onError={() => setVisible(false)}
                    onLoad={() => setVisible(false)}
                    onLoadProgress={({ nativeEvent }) => {
                        setProgress(nativeEvent.progress)
                    }}
                    onLoadStart={() => setVisible(true)}
                    textZoom={100}
                    // fix thanh scroll trên webview hiện sai vị trí
                    showsVerticalScrollIndicator={false}
                />
                {visible ? <ActivityIndicatorElement styles={styles} /> : null}
            </View>
        </Container>
    )
}

const getLink = (link) => {
    if (Platform.OS === 'android' && String(link).endsWith('.pdf')) {
        return 'https://drive.google.com/viewerng/viewer?embedded=true&url=' + link
    }

    return link
}

const ActivityIndicatorElement = ({ styles }) => {
    return (
        <View style={UI.activityIndicatorStyle}>
            <ActivityIndicator color={styles.PRIMARY} size="large" />
        </View>
    )
}

const UI = StyleSheet.create({
    activityIndicatorStyle: {
        bottom: 0,
        flex: 1,
        justifyContent: 'center',
        left: 0,
        marginBottom: 'auto',
        marginLeft: 'auto',
        marginRight: 'auto',
        marginTop: 'auto',
        position: 'absolute',
        right: 0,
        top: 0,
    },
    container: {
        flex: 1,
    },
})
