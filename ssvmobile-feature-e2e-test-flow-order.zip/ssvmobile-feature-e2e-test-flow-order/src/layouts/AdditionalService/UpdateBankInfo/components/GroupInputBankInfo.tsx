import React, { useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Pressable, StyleSheet, TextInput, TouchableOpacity, TouchableWithoutFeedback, View } from 'react-native'
import ToastGlobal from 'react-native-toast-message'
import AntDesign from 'react-native-vector-icons/AntDesign'

import ArrowRight from '../../../../assets/images/common/ic_arrow_right.svg'
import { CustomFloatInput, Text } from '../../../../basic-components'
import ModalSelection from '../../../../components/list-selections'
import { StoreContext } from '../../../../store'
import { dimensions as dm, fontSizes as fs } from '../../../../styles'
import { sendRequest } from '../../../../utils'

const ServiceInfo: { [key: string]: ISserviceInfo } = {
    getListBank: {
        WorkerName: 'FOSqAccount',
        ServiceName: 'FOSqAccount_Common',
        Operation: 'Q',
    },
    getListSubBank: {
        WorkerName: 'FOSqAccount',
        ServiceName: 'FOSqAccount_Common',
        Operation: 'Q',
    },
}

interface IGroupInputBankInfo {
    size?: 'ssv' | 'small'
    fullName: string
    onChangeFullName: (name: string) => void
    bankInfoObj: any
    callback: (item: any) => void
}

const GroupInputBankInfo = ({ size = 'ssv', fullName, onChangeFullName = () => null, bankInfoObj, callback = (item) => {} }: IGroupInputBankInfo) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()
    const isSmall = size === 'small'
    // Start define all bussiness state
    const [isOpenModalSelection, setIsOpenModalSelection] = useState(false)
    const [infoSelection, setInfoSelection] = useState({
        type: '',
        callback: () => {},
    })
    const [bankInfo, setBankInfo] = useState({})
    const [bankSubInfo, setBankSubInfo] = useState(
        bankInfoObj?.bankAccLink?.c0
            ? {
                  label: bankInfoObj?.bankAccLink?.c1,
                  value: bankInfoObj?.bankAccLink,
              }
            : {},
    )
    const [bankAccNum, setBankAccNum] = useState(bankInfoObj.bankAccNum || '')

    // -------
    const [listBank, setListBank] = useState([])
    const [listSubBank, setListSubBank] = useState([])
    const [listCurrentSelectBank, setListCurrentSelectBank] = useState([])

    // -------------------------------------------   Dùng useEffect get các dữ liệu cần thiết còn thiếu
    useEffect(() => {
        if (listBank.length === 0) getListBank()
    }, [])
    useEffect(() => {
        // @ts-expect-error
        if (bankInfo?.value?.c0) getListSubBank()
    }, [bankInfo])

    // -------------------------------------------   Khai báo các hàm gửi (request) lên server
    const getListBank = () => {
        const inputParams = ['25', '%']
        sendRequest(ServiceInfo.getListBank, inputParams, handleGetListBank)
    }

    const getListSubBank = () => {
        // @ts-expect-error
        const inputParams = ['18', bankInfo?.value?.c0, '%']
        sendRequest(ServiceInfo.getListSubBank, inputParams, handleGetListSubBank)
    }

    // -------------------------------------------   Khai báo các hàm gửi (request) và nhận (handle respone) dữ liệu từ server
    const handleGetListBank = (reqInfoMap, message: IServiceRespone) => {
        // -- process after get result --
        let ListBankTemp = []
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata
            try {
                jsondata = JSON.parse(message.Data)
            } catch (err) {
                // glb_sv.logMessage(err);
                jsondata = []
            }
            ListBankTemp = ListBankTemp.concat(jsondata)
            if (Number(message.Packet) <= 0) {
                const bankTransferList = ListBankTemp.map((item: IServiceResponeData) => {
                    const label = item.c3 + ' - ' + item.c1
                    const value = item
                    const currentSelectBankCode = bankInfoObj?.bankAccLink?.c0?.split('.')?.[0]
                    if (currentSelectBankCode === item.c0) {
                        setBankInfo({ label, value })
                    }
                    return { label, value }
                })
                // @ts-expect-error
                setListBank(bankTransferList)
            }
        }
    }
    const handleGetListSubBank = (reqInfoMap, message: IServiceRespone) => {
        // -- process after get result --
        let ListSubBankTemp = []
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata
            try {
                jsondata = JSON.parse(message.Data)
            } catch (err) {
                // glb_sv.logMessage(err);
                jsondata = []
            }
            ListSubBankTemp = ListSubBankTemp.concat(jsondata)
            if (Number(message.Packet) <= 0) {
                const bankTransferList = ListSubBankTemp.map((item: IServiceResponeData) => {
                    const label = item.c1
                    const value = item
                    return { label, value }
                })
                // @ts-expect-error
                setListSubBank(bankTransferList)
                if (bankTransferList.length === 1) {
                    setBankSubInfo((prev) => bankTransferList[0] || {})
                }
            }
        }
    }

    const selectBank = (value) => {
        setBankInfo(value)
        setBankSubInfo({})
        if (JSON.stringify(value) === '{}') {
            setListSubBank([])
        }
    }

    const selectSubBank = (value) => {
        setBankSubInfo(value)
    }

    useEffect(() => {
        callback({
            bankInfoObj: bankSubInfo.value || { isEmpty: true },
            bankAccNum: bankAccNum,
            selectedBank: bankInfo,
        })
    }, [bankAccNum, bankSubInfo, bankInfo])

    return (
        <>
            <View style={[UI.GroupInput, isSmall ? { marginVertical: 0 } : {}, { borderColor: styles.PRIMARY__BORDER__COLOR }]}>
                <View style={[UI.RowInput, isSmall ? UI.RowInputSmall : {}]}>
                    {isSmall ? (
                        <>
                            <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fs.small, flex: 1 }}>{t<string>('common_full_name')}</Text>
                            <View style={[UI.SmallInputWrap]}>
                                <TextInput
                                    placeholder={t('common_full_name')}
                                    placeholderTextColor={styles.PLACEHODLER__COLOR}
                                    style={{
                                        fontSize: fs.small,
                                        color: styles.PRIMARY__CONTENT__COLOR,
                                        textAlignVertical: 'center',
                                    }}
                                    value={fullName?.toUpperCase()}
                                    onChangeText={(value) => onChangeFullName(value?.toUpperCase())}
                                    // editable={false}
                                    returnKeyType="next"
                                />
                            </View>
                        </>
                    ) : (
                        <CustomFloatInput
                            // staticLabel
                            animationDuration={100}
                            autoCapitalize="characters"
                            editable={false}
                            label={t('common_full_name')}
                            placeholderTextColor={styles.PLACEHODLER__COLOR}
                            value={fullName?.toUpperCase()}
                            onChangeText={(value) => onChangeFullName(value?.toUpperCase())}
                        />
                    )}
                </View>
                <Pressable
                    onPress={() => {
                        // @ts-expect-error
                        setInfoSelection({ type: 'PICK_BANK_EKYC', callback: selectBank })
                        setListCurrentSelectBank(listBank)
                        setIsOpenModalSelection(true)
                    }}
                >
                    <View style={[UI.RowInput, isSmall ? { marginTop: 0 } : {}]}>
                        <CustomFloatInput
                            animationDuration={100}
                            ellipsizeMode="end"
                            isSelectInput
                            label={t('bank_cd')}
                            numberOfLines={1}
                            rightComponent={
                                bankInfo?.label ? (
                                    <View style={UI.BlankSpace} />
                                ) : (
                                    <TouchableOpacity
                                        style={{ paddingVertical: 8 }}
                                        onPress={() => {
                                            setInfoSelection({ type: 'PICK_BANK_EKYC', callback: selectBank })
                                            setListCurrentSelectBank(listBank)
                                            setIsOpenModalSelection(true)
                                        }}
                                    >
                                        <ArrowRight style={{ color: styles.PRIMARY__CONTENT__COLOR, marginVertical: dm.vertical(22), marginRight: 10 }} />
                                    </TouchableOpacity>
                                )
                            }
                            value={bankInfo?.label}
                        />
                        <View style={UI.ButtonDelete}>
                            {bankInfo?.label ? (
                                <TouchableWithoutFeedback>
                                    <TouchableOpacity
                                        style={{ paddingHorizontal: 8, paddingVertical: 8 }}
                                        onPress={() => {
                                            selectBank({})
                                            setBankAccNum('')
                                        }}
                                    >
                                        <AntDesign color={styles.ICON__PRIMARY} name="closecircleo" size={20} style={{ marginHorizontal: dm.moderate(5) }} />
                                    </TouchableOpacity>
                                </TouchableWithoutFeedback>
                            ) : null}
                        </View>
                    </View>
                </Pressable>
                <Pressable
                    onPress={() => {
                        if (!bankInfo?.value?.c0) {
                            ToastGlobal.show({
                                text2: t('warning_bank'),
                                type: 'warning',
                            })
                            return
                        }
                        setInfoSelection({ type: 'PICK_SUB_BANK_EKYC', callback: selectSubBank })
                        setListCurrentSelectBank(listSubBank)
                        setIsOpenModalSelection(true)
                    }}
                >
                    <View pointerEvents="none" style={[UI.RowInput, isSmall ? { marginTop: 0 } : {}]}>
                        <CustomFloatInput
                            animationDuration={100}
                            editable={false}
                            ellipsizeMode="end"
                            label={t('common_branch')}
                            numberOfLines={1}
                            rightComponent={<ArrowRight style={{ color: styles.PRIMARY__CONTENT__COLOR, marginVertical: dm.vertical(22), marginRight: 10 }} />}
                            value={bankSubInfo?.label}
                        />
                    </View>
                </Pressable>
                <View style={[UI.RowInput, isSmall ? UI.RowInputSmall : {}]}>
                    {isSmall ? (
                        <>
                            <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fs.small, flex: 4 }}>{t('enter_acc_number_full')}</Text>
                            <View style={[UI.SmallInputWrap, { backgroundColor: styles.INPUT__BG }]}>
                                <TextInput
                                    placeholder={t('enter_acc_number_full')}
                                    placeholderTextColor={styles.PLACEHODLER__COLOR}
                                    returnKeyType="next"
                                    style={{
                                        fontSize: fs.small,
                                        color: styles.PRIMARY__CONTENT__COLOR,
                                        textAlignVertical: 'center',
                                    }}
                                    value={bankAccNum}
                                    onChangeText={(acc) => setBankAccNum(acc)}
                                />
                            </View>
                        </>
                    ) : (
                        <>
                            <CustomFloatInput
                                animationDuration={100}
                                label={t('input_bank_acc_number')}
                                placeholderTextColor={styles.PLACEHODLER__COLOR}
                                value={bankAccNum}
                                onChangeText={(acc) => setBankAccNum(acc)}
                            />
                        </>
                    )}
                </View>
            </View>
            {/* <ButtonCustom text={t('common_confirm')} onPress={onConfirm} type="confirm" /> */}
            <ModalSelection
                actionType={infoSelection.type}
                getSelectValue={infoSelection.callback}
                isOpen={isOpenModalSelection}
                listSelectionsProps={listCurrentSelectBank}
                setIsOpen={setIsOpenModalSelection}
            />
        </>
    )
}

export { GroupInputBankInfo }

const UI = StyleSheet.create({
    BlankSpace: {
        height: 10,
        width: dm.moderate(40),
    },
    ButtonDelete: {
        alignItems: 'center',
        height: '100%',
        justifyContent: 'center',
        position: 'absolute',
        right: 0,
    },
    GroupInput: {
        marginVertical: dm.halfVerticalIndent,
        paddingHorizontal: dm.halfIndent,
    },
    RowInput: {
        marginLeft: dm.moderate(8),
        marginVertical: dm.vertical(8),
    },
    RowInputSmall: { alignItems: 'center', display: 'flex', flexDirection: 'row', marginVertical: 0 },
    SmallInputWrap: {
        borderRadius: 4,
        flex: 4,
        paddingHorizontal: 10,
        paddingVertical: 8,
    },
})
