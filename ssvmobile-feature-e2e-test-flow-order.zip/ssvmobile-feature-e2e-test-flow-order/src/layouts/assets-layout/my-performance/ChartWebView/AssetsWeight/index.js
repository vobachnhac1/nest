import React, { useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { ActivityIndicator, StyleSheet, TouchableOpacity, View } from 'react-native'
import { ScrollView } from 'react-native-gesture-handler'
import Modal from 'react-native-modal'
import DateTimePickerModal from 'react-native-modal-datetime-picker'
import MonthSelectorCalendar from 'react-native-month-selector'
import Entypo from 'react-native-vector-icons/Entypo'
import moment from 'moment'

import { Text } from '../../../../../basic-components'
import { ModalBottomContent, RowTitleGroup } from '../../../../../components/trading-component'
import { useLoading } from '../../../../../hoc'
import { StoreContext } from '../../../../../store'
import { dimensions, fontSizes, fontWeights, IconSvg } from '../../../../../styles'
import { FormatNumber, glb_sv, reqFunct, sendRequest } from '../../../../../utils'
import ChartWebview from './webview'

const ServiceInfo = {
    GET_HISTORY_ASSETS: {
        reqFunct: reqFunct.GET_HISTORY_ASSETS,
        WorkerName: 'FOSqAsset',
        ServiceName: 'FOSqAsset_Online_1',
        Operation: 'Q',
    },
}

const fakeData = [
    { c0: '202102', c1: '547205463800', c2: '59043903147', c3: '0', c4: '59043903147' },
    { c0: '202103', c1: '247205463800', c2: '159043903147', c3: '259043903147', c4: '25943903147' },
    { c0: '202104', c1: '547205463800', c2: '59043903147', c3: '59043903147', c4: '259043903147' },
    { c0: '202105', c1: '147205463800', c2: '159043903147', c3: '0', c4: '259043903147' },
    { c0: '202106', c1: '647205463800', c2: '159043903147', c3: '159043903147', c4: '259043903147' },
    { c0: '202107', c1: '147205463800', c2: '159043903147', c3: '0', c4: '259043903147' },
]

export const AssetsWeight = ({ userInfo }) => {
    const { theme, styles, language } = useContext(StoreContext)
    const [loading, setLoading] = useLoading(false)
    const { t } = useTranslation()
    const [dataChart, setDataChart] = useState([])
    const [from, setFrom] = useState(moment(glb_sv.objShareGlb.workDate, 'YYYYMMDD').startOf('month').toDate())
    const [to, setTo] = useState(moment(glb_sv.objShareGlb.workDate, 'YYYYMMDD').toDate())

    const [isModalFrom, setIsModalFrom] = useState(false)
    const [isModalTo, setIsModalTo] = useState(false)

    useEffect(() => {
        getHistoryAssetsFull(moment(from).format('YYYYMMDD'), moment(to).format('YYYYMMDD'))
    }, [userInfo, from, to])

    // ------ service
    const getHistoryAssetsFull = (from, to) => {
        setLoading(true)
        const inputParams = ['05', glb_sv.objShareGlb.AcntMain, '%', from, to]
        sendRequest(ServiceInfo.GET_HISTORY_ASSETS, inputParams, getHistoryAssetsFullResult, true, getHistoryAssetsFullTimeout)
    }

    const getHistoryAssetsFullTimeout = () => {
        console.log('getHistoryAssetsFullTimeout')
    }

    const getHistoryAssetsFullResult = (reqInfoMap, message) => {
        // setDataChart(fakeData)
        setLoading(false)
        console.log('getHistoryAssetsFullResult -> message', message)
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {}
            setDataChart(jsondata)
        }
    }

    const onFinish = () => {
        setIsModalFrom(false)
        setIsModalTo(false)
    }

    const getMinWidthTable = (type) => {
        if (dataChart.length === 0) {
            return dimensions.WIDTH - dimensions.moderate(16) * 2
        } else if (dataChart.length <= 2) {
            if (type === 'first') return (dimensions.WIDTH - dimensions.moderate(16) * 2) / 4
            return (dimensions.WIDTH - dimensions.moderate(16) * 2 - (dimensions.WIDTH - dimensions.moderate(16) * 2) / 4) / dataChart.length
        } else {
            if (type === 'first') return (dimensions.WIDTH - dimensions.moderate(16) * 2) / 4
            return dimensions.WIDTH / 3.1
        }
    }

    const TableDataAssetsWeight = () => {
        return (
            <ScrollView horizontal nestedScrollEnabled>
                <View style={{ paddingHorizontal: dimensions.moderate(16), marginTop: 8, marginBottom: 8, flex: 1 }}>
                    <View style={[UI.Row, { borderColor: styles.DIVIDER__COLOR }]}>
                        <View style={[UI.Cell, { width: getMinWidthTable('first') }]}>
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small, fontWeight: fontWeights.bold }}>{t('time')}</Text>
                        </View>
                        {dataChart.map((colData) => (
                            <View style={[UI.Cell, { width: getMinWidthTable() }]}>
                                <Text numberOfLines={1} style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small, textAlign: 'right' }}>
                                    {moment(colData.c0, 'YYYYMMDD').format('DD/MM/YYYY')}
                                </Text>
                            </View>
                        ))}
                    </View>
                    <View style={[UI.Row, { borderColor: styles.DIVIDER__COLOR }]}>
                        <View style={[UI.Cell, { width: getMinWidthTable('first') }]}>
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small, fontWeight: fontWeights.bold }}>
                                {t('net_assets')}
                            </Text>
                        </View>
                        {dataChart.map((colData) => (
                            <View style={[UI.Cell, { width: getMinWidthTable() }]}>
                                <Text numberOfLines={1} style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small, textAlign: 'right' }}>
                                    {FormatNumber(colData.c4)}
                                </Text>
                            </View>
                        ))}
                    </View>
                    <View style={[UI.Row, { borderColor: styles.DIVIDER__COLOR }]}>
                        <View style={[UI.Cell, { width: getMinWidthTable('first') }]}>
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small, fontWeight: fontWeights.bold }}>{t('stock')}</Text>
                        </View>
                        {dataChart.map((colData) => (
                            <View style={[UI.Cell, { width: getMinWidthTable() }]}>
                                <Text numberOfLines={1} style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small, textAlign: 'right' }}>
                                    {FormatNumber(colData.c1)}
                                </Text>
                            </View>
                        ))}
                    </View>
                    <View style={[UI.Row, { borderColor: styles.DIVIDER__COLOR }]}>
                        <View style={[UI.Cell, { width: getMinWidthTable('first') }]}>
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small, fontWeight: fontWeights.bold }}>
                                {t('title_cash')}
                            </Text>
                        </View>
                        {dataChart.map((colData) => (
                            <View style={[UI.Cell, { width: getMinWidthTable() }]}>
                                <Text numberOfLines={1} style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small, textAlign: 'right' }}>
                                    {FormatNumber(colData.c2)}
                                </Text>
                            </View>
                        ))}
                    </View>
                    <View style={[UI.Row, { borderColor: styles.DIVIDER__COLOR }]}>
                        <View style={[UI.Cell, { width: getMinWidthTable('first') }]}>
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small, fontWeight: fontWeights.bold }}>{t('debt')}</Text>
                        </View>
                        {dataChart.map((colData) => (
                            <View style={[UI.Cell, { width: getMinWidthTable() }]}>
                                <Text numberOfLines={1} style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small, textAlign: 'right' }}>
                                    {FormatNumber(colData.c3)}
                                </Text>
                            </View>
                        ))}
                    </View>
                </View>
            </ScrollView>
        )
    }

    return (
        <>
            <RowTitleGroup text={t('assets_weight')} />
            <View
                style={{ flexDirection: 'row', marginTop: dimensions.vertical(8), justifyContent: 'space-between', marginHorizontal: dimensions.moderate(16) }}
            >
                <TouchableOpacity
                    style={{
                        flex: 1,
                        justifyContent: 'flex-start',
                        borderRadius: 8,
                        backgroundColor: styles.BUTTON__THIRD,
                        padding: dimensions.moderate(6),
                        flexDirection: 'row',
                        alignItems: 'center',
                    }}
                    onPress={() => setIsModalFrom(!isModalFrom)}
                >
                    <View style={{ marginRight: dimensions.moderate(20), flex: 1 }}>
                        <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.verySmall }}>{t('common_from_date')}</Text>
                        <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.verySmall }}>{moment(from).format('DD/MM/YYYY')}</Text>
                    </View>
                    <IconSvg.DateIcon color={styles.PRIMARY__CONTENT__COLOR} />
                </TouchableOpacity>
                <View style={{ width: dimensions.moderate(16) }} />
                <TouchableOpacity
                    style={{
                        flex: 1,
                        justifyContent: 'flex-start',
                        borderRadius: 8,
                        backgroundColor: styles.BUTTON__THIRD,
                        padding: dimensions.moderate(6),
                        flexDirection: 'row',
                        alignItems: 'center',
                    }}
                    onPress={() => setIsModalTo(!isModalTo)}
                >
                    <View style={{ marginRight: dimensions.moderate(20), flex: 1 }}>
                        <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.verySmall }}>{t('common_to_date')}</Text>
                        <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.verySmall }}>{moment(to).format('DD/MM/YYYY')}</Text>
                    </View>
                    <IconSvg.DateIcon color={styles.PRIMARY__CONTENT__COLOR} />
                </TouchableOpacity>
            </View>
            {/* <TableDataAssetsWeight /> */}
            <View style={{ height: 250 }}>
                {loading ? (
                    <View style={{ alignItems: 'center', justifyContent: 'center' }}>
                        <ActivityIndicator color={styles.PRIMARY} />
                    </View>
                ) : null}
                <ChartWebview dataChart={JSON.stringify(dataChart)} styles={styles} t={t} theme={theme} />
            </View>
            {/* {isModalFrom ? (
                <Modal
                    isVisible={isModalFrom}
                    style={UI.bottomModal}
                    useNativeDriver={true}
                    hideModalContentWhileAnimating={true}
                    onBackButtonPress={() => onFinish()}
                    onBackdropPress={() => onFinish()}>
                    <ModalBottomContent title={t('common_from_month')}>
                        <MonthSelectorCalendar
                            selectedDate={moment(from)}
                            onMonthTapped={(date) => {
                                setFrom(date)
                                onFinish()
                            }}
                            maxDate={moment().add(12, 'months')}
                            currentDate={moment(glb_sv.objShareGlb.workDate, 'YYYYMMDD')}
                            monthDisabledStyle={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.medium }}
                            containerStyle={[{ backgroundColor: styles.HEADER__BG__COLOR, marginTop: -8 }]}
                            yearTextStyle={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.medium, fontWeight: fontWeights.bold }}
                            monthTextStyle={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.medium }}
                            currentMonthTextStyle={{ color: styles.PRIMARY, fontSize: fontSizes.medium, fontWeight: fontWeights.bold }}
                            selectedBackgroundColor={styles.HEADER__BG__COLOR}
                            selectedMonthTextStyle={{ color: styles.PRIMARY, fontSize: fontSizes.medium, fontWeight: fontWeights.bold }}
                            nextIcon={<Entypo name="chevron-right" color={styles.SECOND__CONTENT__COLOR} size={28} />}
                            prevIcon={<Entypo name="chevron-left" color={styles.SECOND__CONTENT__COLOR} size={28} />}
                            seperatorColor={styles.DIVIDER__COLOR}
                        />
                    </ModalBottomContent>
                </Modal>
            ) : null} */}
            {/* {isModalTo ? (
                <Modal
                    isVisible={isModalTo}
                    style={UI.bottomModal}
                    useNativeDriver={true}
                    hideModalContentWhileAnimating={true}
                    onBackButtonPress={() => onFinish()}
                    onBackdropPress={() => onFinish()}>
                    <ModalBottomContent title={t('common_to_month')}>
                        <MonthSelectorCalendar
                            selectedDate={moment(to)}
                            onMonthTapped={(date) => {
                                setTo(date)
                                onFinish()
                            }}
                            maxDate={moment().add(12, 'months')}
                            currentDate={moment(glb_sv.objShareGlb.workDate, 'YYYYMMDD')}
                            monthDisabledStyle={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.medium }}
                            containerStyle={[{ backgroundColor: styles.HEADER__BG__COLOR, marginTop: -8 }]}
                            yearTextStyle={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.medium, fontWeight: fontWeights.bold }}
                            monthTextStyle={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.medium }}
                            currentMonthTextStyle={{ color: styles.PRIMARY, fontSize: fontSizes.medium, fontWeight: fontWeights.bold }}
                            selectedBackgroundColor={styles.HEADER__BG__COLOR}
                            selectedMonthTextStyle={{ color: styles.PRIMARY, fontSize: fontSizes.medium, fontWeight: fontWeights.bold }}
                            nextIcon={<Entypo name="chevron-right" color={styles.SECOND__CONTENT__COLOR} size={28} />}
                            prevIcon={<Entypo name="chevron-left" color={styles.SECOND__CONTENT__COLOR} size={28} />}
                            seperatorColor={styles.DIVIDER__COLOR}
                        />
                    </ModalBottomContent>
                </Modal>
            ) : null} */}

            {isModalFrom ? (
                <DateTimePickerModal
                    cancelTextIOS={t('common_Cancel')}
                    confirmTextIOS={t('common_Ok')}
                    date={from}
                    headerTextIOS=""
                    isDarkModeEnabled={theme.includes('DARK')}
                    isVisible={isModalFrom}
                    locale={language === 'VI' ? 'vi_VN' : 'en_US'}
                    mode="date"
                    onCancel={onFinish}
                    onConfirm={(value) => {
                        onFinish()
                        setFrom(value)
                    }}
                />
            ) : null}

            {isModalTo ? (
                <DateTimePickerModal
                    cancelTextIOS={t('common_Cancel')}
                    confirmTextIOS={t('common_Ok')}
                    date={to}
                    headerTextIOS=""
                    isDarkModeEnabled={theme.includes('DARK')}
                    isVisible={isModalTo}
                    locale={language === 'VI' ? 'vi_VN' : 'en_US'}
                    mode="date"
                    onCancel={onFinish}
                    onConfirm={(value) => {
                        onFinish()
                        setTo(value)
                    }}
                />
            ) : null}
        </>
    )
}

const UI = StyleSheet.create({
    Cell: {
        flex: 1,
        paddingRight: 8,
        paddingVertical: dimensions.vertical(4),
    },
    Row: {
        borderBottomWidth: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
    bottomModal: {
        justifyContent: 'flex-end',
        margin: 0,
    },
})
