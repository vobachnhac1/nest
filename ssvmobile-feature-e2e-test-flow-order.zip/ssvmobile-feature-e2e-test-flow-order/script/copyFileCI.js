//copyfile.js
const fs = require('fs')

// destination will be created or overwritten by default.
fs.copyFile(
    '/Users/ssv01/Desktop/SSVMobile/android/app/altisss_key_store.keystore',
    '/Users/ssv01/builds/jheRGh-s/0/coretrading/ssvmobile/android/app/altisss_key_store.keystore',
    (err) => {
        if (err) throw err
        console.log('File was copied to destination')
    },
)

try {
    fs.cp(
        '/Users/ssv01/Desktop/SSVMobile/ios/FinalSDK.xcframework',
        '/Users/ssv01/builds/jheRGh-s/0/coretrading/ssvmobile/ios/FinalSDK.xcframework',
        { recursive: true },
        () => {
            console.log('success!')
        },
    )
} catch {
    console.log('error')
}
