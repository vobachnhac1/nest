import React, { memo, useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { InteractionManager, Pressable, Text, View } from 'react-native'
import ModalController from '@mts-components/appModal/modalControlller'
import moment from 'moment'
import { VictoryAxis, VictoryBar, VictoryChart } from 'victory-native'

import { StoreContext } from '../../../store'
import { dimensions, fontSizes, IconSvg } from '../../../styles'
import { reqFunct, Screens, sendRequest } from '../../../utils'

const ServiceInfo = {
    GET_HISTORY_CASH_FLOW: {
        reqFunct: reqFunct.GET_HISTORY_CASH_FLOW,
        WorkerName: 'FOSqMkt03',
        ServiceName: 'FOSqMkt03_HistTrading',
        ClientSentTime: '0',
        Operation: 'Q',
    },
}

const CashFlowHistory = ({ code, navigation, showName }) => {
    const { t } = useTranslation()
    const { styles } = useContext(StoreContext)
    const [data, setData] = useState([])

    const [min, setMin] = useState(0)
    const [max, setMax] = useState(0)
    const [offsetY, setY] = useState(0)

    const firstRequest = useRef(true)

    useEffect(() => {
        let timeOut
        if (firstRequest.current) {
            InteractionManager.runAfterInteractions(() => {
                timeOut = setTimeout(() => {
                    setData([])
                    getHistoryCashFlow()
                }, 1200)
            })
        } else {
            setData([])
            getHistoryCashFlow()
        }
        return () => {
            clearTimeout(timeOut)
        }
    }, [code])

    const getHistoryCashFlow = () => {
        const InputParams = ['NET_FLOW', '5', code]
        sendRequest(ServiceInfo.GET_HISTORY_CASH_FLOW, InputParams, getHistoryCashFlowResult, true, getHistoryCashFlowTimeout)
    }

    const getHistoryCashFlowTimeout = () => { }

    const getHistoryCashFlowResult = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
        } else {
            let jsondata = []
            try {
                if (message.Data) {
                    jsondata = JSON.parse(message.Data)
                }
            } catch (err) {
                console.warn('getHistoryCashFlowResult error', err)
                return
            }
            if (jsondata.length) {
                const array = jsondata.map((item) => ({
                    x: moment(item.c1, 'YYYYMMDD').format('DD/MM'),
                    y: Number((Number(item.c4) - Number(item.c5)).toFixed(2)),
                }))
                array.push({
                    x: moment('20220101', 'YYYYMMDD').format('DD/MM'),
                    y: 0.1,
                })
                setData(array)

                const minV = array.reduce(function (prev, curr) {
                    return prev.y < curr.y ? prev : curr
                }).y
                const maxV = array.reduce(function (prev, curr) {
                    return prev.y > curr.y ? prev : curr
                }).y
                setMax(maxV)
                setMin(minV < 0 ? minV : 0)
                if (maxV && minV) {
                    const offset = Math.abs(minV / ((maxV * 1.1 - minV * 1.1) / 320))

                    if (minV >= 0) {
                        setY(10)
                    } else if (minV) {
                        setY(offset > 250 ? 250 : offset < 36 ? 50 : offset + 15)
                    }
                }
            }
        }
    }

    const openInfo = () => {
        // navigation.navigate(Screens.ALERT_MODAL, {
        // title: t('large_scale_orders_in_last_5day'),
        // content: t('large_scale_orders_in_last_5day_info'),
        // typeColor: styles.INFO__COLOR,
        // })
        //

        ModalController.showModal({
            title: t('large_scale_orders_in_last_5day'),
            content: t('large_scale_orders_in_last_5day_info'),
            typeColor: styles.INFO__COLOR,
        })
    }

    return (
        <View>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: showName ? dimensions.moderate(12) : 0 }}>
                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <Text style={{ color: !showName ? styles.PRIMARY__CONTENT__COLOR : styles.PRIMARY, fontSize: fontSizes.medium, fontWeight: '600' }}>
                        {t('large_scale_orders_in_last_5day')}{' '}
                        {!showName ? '' : code === 'HSXIndex' ? 'HSX' : code === 'HNXIndex' ? 'HNX' : code === 'HNXUpcomIndex' ? 'UPC' : ''}
                    </Text>
                    <Pressable hitSlop={12} onPress={openInfo}>
                        <IconSvg.InfoIcon color={styles.PRIMARY__CONTENT__COLOR} />
                    </Pressable>
                </View>
            </View>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: showName ? dimensions.moderate(12) : 0 }}>
                <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small, marginTop: 5 }}>{t('billion_vnd__unit')}</Text>
            </View>

            <VictoryChart
                height={340}
                padding={{
                    right: 20,
                    top: 30,
                    bottom: 65,
                    left: 80,
                }}
            >
                <VictoryAxis
                    offsetY={offsetY}
                    orientation="bottom"
                    style={{
                        tickLabels: { fontSize: 10, padding: 0, fontWeight: '500', fill: styles.PRIMARY__CONTENT__COLOR },
                        axis: { stroke: 'transparent' },
                    }}
                    tickFormat={(tick) => {
                        if (tick === '01/01') return ''
                        return tick
                    }}
                />
                <VictoryAxis
                    dependentAxis
                    domain={[min * 1.1, max * 1.1]}
                    offsetX={20}
                    style={{
                        tickLabels: { fontSize: 10, padding: 5, fontWeight: '500', fill: styles.PRIMARY__CONTENT__COLOR },
                        axis: { stroke: 'transparent' },
                        grid: { stroke: styles.BORDER__MODAL, strokeDasharray: '5' },
                    }}
                    tickCount={9}
                />
                <VictoryBar
                    alignment="middle"
                    barRatio={0.7}
                    cornerRadius={2}
                    data={data}
                    labels={({ datum }) => {
                        if (datum.x === '01/01') return ''
                        return datum.y
                    }}
                    style={{
                        data: {
                            fill: ({ datum }) => {
                                if (datum.x === '01/01') return 'transparent'
                                return datum.y < 0 ? styles.DOWN__COLOR : styles.UP__COLOR
                            },
                        },
                        labels: {
                            fill: styles.PRIMARY__CONTENT__COLOR,
                        },
                    }}
                />
            </VictoryChart>
        </View>
    )
}

export default memo(CashFlowHistory)
