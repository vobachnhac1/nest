import React, { createRef, PureComponent } from 'react'
import { Platform, StyleSheet } from 'react-native'
import WebView from 'react-native-webview'

const source = Platform.select({
    ios: require('../../basic-components/custom-chart/index.html'),
    android: { uri: 'file:///android_asset/index.html' },
})

export default class Chart extends PureComponent {
    constructor(props) {
        super(props)
        this.chart = createRef()
        this.state = {
            webviewKey: new Date().getTime(),
        }
    }

    reload = () => {
        this.setState({
            webviewKey: this.state.webviewKey + 1,
        })
    }

    render() {
        return (
            <WebView
                allowUniversalAccessFromFileURLs={true}
                androidHardwareAccelerationDisabled
                androidLayerType="hardware"
                domStorageEnabled={true}
                injectedJavaScriptBeforeContentLoaded={`
                    new Date().toLocaleString();
                    true;
                `}
                javaScriptEnabled
                key={this.state.webviewKey}
                originWhitelist={['*']}
                ref={this.chart}
                scrollEnabled={false}
                source={source}
                style={styles.webView}
                onContentProcessDidTerminate={this.reload}
            />
        )
    }
}

const styles = StyleSheet.create({
    webView: {
        backgroundColor: 'transparent',
        flex: 1,
    },
})
