import React, { useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { FlatList, Image, RefreshControl, StyleSheet, Text, View } from 'react-native'
import RNFS from 'react-native-fs'
import RenderHTML from 'react-native-render-html'
import Share from 'react-native-share'
import ToastGlobal from 'react-native-toast-message'
import ModalController from '@mts-components/appModal/modalControlller'
import { ButtonCustom, EmptyView, RowTitleGroup } from '@mts-components/trading-component'
import { COLORS } from '@mts-styles/colors'
import { eventList, glb_sv, reqFunct, Screens, sendRequest } from '@mts-utils/index'
import isEmpty from 'lodash/isEmpty'
import moment from 'moment'
import { Container } from 'native-base'

import CONFIG, { activeCode } from '../../../assets/config'
import CONTRACT_EMPTY from '../../../assets/images/common/contract_empty.png'
import HeaderComponent from '../../../components/header'
import ModalLoading from '../../../components/modal-loading'
import HeaderList from '../../../components/trading-component/header-list'
import { StoreContext } from '../../../store'
import { StoreTrading } from '../../../store-trading'
import { dimensions as dm, fontSizes, IconSvg } from '../../../styles'
import { EContractItem } from './components/EcontractItem'
import { IEcontractItem } from './EContractViewDetail'

const INPUT_DATE_FORMAT = 'YYYYMMDD'
const ServiceInfo: { [key: string]: ISserviceInfo } = {
    GET_LIST_ECONTRACT: {
        reqFunct: reqFunct.GET_LIST_ECONTRACT,
        WorkerName: 'FOSqCommon',
        ServiceName: 'FOSqCommon_QueryEContract',
        Operation: 'Q',
    },
    SIGN_E_CONTRACT_FOR_HARD_COPY: {
        reqFunct: reqFunct.SIGN_E_CONTRACT_FOR_HARD_COPY,
        WorkerName: 'FOSxAccount01',
        ServiceName: 'FOSxAccount01_RegMargin_Online_Cus',
        Operation: 'E',
        ClientSentTime: '0',
    },
}

export const EContractManagement = ({ navigation }) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()
    const [listEcontract, setListEContract] = useState([])
    const [refreshing, setRefreshing] = useState(false)
    const colSpan = [2, 1, 1.5]
    const fileDomain = CONFIG[activeCode].econtract_download_url
    const [isDownloading, setIsDownloading] = useState<boolean>(false)
    const [isDisable, setDisable] = useState<boolean>(false)
    const { userInfo } = useContext(StoreTrading)
    const [loadingWaitingContract, setLoadingWaitingContract] = useState(false)

    const getListEcontract = () => {
        setRefreshing(true)
        const fromDate = moment().subtract(10, 'years').format(INPUT_DATE_FORMAT)
        const toDate = moment().format(INPUT_DATE_FORMAT)
        const InputParams = [fromDate, toDate]
        setListEContract([])
        sendRequest(ServiceInfo.GET_LIST_ECONTRACT, InputParams, (_, message) => {
            setRefreshing(false)
            if (Number(message.Result === 0)) {
                return
            } else {
                let jsonData
                if (!message.Data) return
                try {
                    jsonData = JSON.parse(message.Data)
                    setListEContract(jsonData)
                    const listAdditional = jsonData.filter((e) => e.c2 === '3')
                    const result = listAdditional.some((e) => e.c4 === 'Y' || (e.c4 !== 'Y' && e.c15 !== 'Y'))
                    setDisable(result)
                } catch (err) {
                    console.log('getListEContractResutl -> err', err)
                    return
                }
            }
        })
    }

    const handlePullToRefresh = () => {
        getListEcontract()
    }

    useEffect(() => {
        getListEcontract()
    }, [])

    useEffect(() => {
        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.NOTIFY_ECONTRACT_CUS) {
                handlePullToRefresh()
            }
        })
        return () => {
            commonEvent.unsubscribe()
        }
    }, [navigation])

    const onPressSignEContract = (item: IEcontractItem) => {
        navigation.navigate(Screens.ECONTRACT_VIEW_DETAIL, { item })
    }

    const onPressViewEcontract = (item: IEcontractItem) => {
        const fileUrl = `${fileDomain}/${item?.c13}`
        if (item?.c13) {
            navigation.navigate(Screens.ECONTRACT_FILE_VIEW, {
                uri: `http://docs.google.com/gview?embedded=true&url=${encodeURIComponent(fileUrl)}`,
                contractName: item?.c3,
            })
        } else {
            navigation.navigate(Screens.ECONTRACT_VIEW_DETAIL, { item })
        }
    }

    const onPressDownloadFile = (item) => {
        const { c12, c13, c3: eContractName } = item
        const fileName = !isEmpty(c12) ? c12 : moment().format('DDMMYYYYHHmmss')
        const filePath = `${RNFS.DocumentDirectoryPath}/${fileName}.pdf`
        setIsDownloading(true)
        RNFS.downloadFile({
            fromUrl: `${fileDomain}/${c13}`,
            toFile: filePath,
        })
            .promise.then((e) => {
                if (e.statusCode === 200) {
                    ToastGlobal.show({
                        type: 'success',
                        text2: t('econtract_download_file_success'),
                    })
                    Share.open({
                        url: `file://${filePath}`,
                        message: eContractName,
                        title: eContractName,
                    })
                        .then((res) => console.log(res))
                        .catch((err) => {
                            err && console.log(err)
                        })
                }
            })
            .finally(() => {
                setIsDownloading(false)
            })
    }

    const SignAccountEcontract = () => {
        if (glb_sv.objShareGlb.userInfo.c25 === 'Y') {
            return <ButtonCustom disabled={isDisable} text={t('sign_account_e_contract')} type={'confirm'} onPress={signAccountEcontract} />
        }
        return <></>
    }

    const signAccountEcontract = () => {
        navigation.navigate(Screens.OTP_MODAL, {
            hasOTP: false,
            functCallback: sendContact,
        })
    }

    const sendContact = () => {
        setLoadingWaitingContract(true)
        const inputParams = [userInfo.actn_curr]
        sendRequest(ServiceInfo.SIGN_E_CONTRACT_FOR_HARD_COPY, inputParams, handleSendContactResult, true, handleSendContactTimeout)
    }

    const SignHardCopyContractSuccessContent = () => {
        const escapeHtml = (text) => {
            return text
                .replace(/&amp;/g, '&')
                .replace(/&lt;/g, '<')
                .replace(/&gt;/g, '>')
                .replace(/&quot/g, '"')
                .replace(/&#039;/g, "'")
        }
        const tagsStyles = {
            strong: {
                color: styles.PRIMARY,
            },
        }

        return (
            <RenderHTML
                baseStyle={{
                    fontSize: fontSizes.normal,
                    color: styles.PRIMARY__CONTENT__COLOR,
                    overflow: 'visible',
                    textAlign: 'justify',
                    marginLeft: 8,
                    marginRight: 8,
                    marginBottom: 16,
                }}
                source={{
                    html: escapeHtml(t('ekyc_have_econtract_open_account_not_sign')),
                }}
                tagsStyles={tagsStyles}
            />
        )
    }

    const handleSendContactResult = (reqInfoMap, message) => {
        setLoadingWaitingContract(false)
        if (Number(message.Result) === 0) {
            if (message.Code === '010620') {
                ModalController.showModal({
                    icon: <IconSvg.ErrorIcon color={styles.PRIMARY} />,
                    title: t('common_notify'),
                    typeColor: styles.PRIMARY,
                    middleComponent: <SignHardCopyContractSuccessContent />,
                })
                return
            }
            ModalController.showModal({
                icon: <IconSvg.ErrorIcon color={styles.PRIMARY} />,
                title: t('common_notify'),
                typeColor: styles.PRIMARY,
                content: message.Message,
            })
            return
        } else {
            if (Number(message.Packet) <= 0) {
                ModalController.showModal({
                    icon: <IconSvg.ErrorIcon color={styles.PRIMARY} />,
                    title: t('common_notify'),
                    typeColor: styles.PRIMARY,
                    middleComponent: <SignHardCopyContractSuccessContent />,
                    linkCallback: () => {
                        setDisable(true)
                        getListEcontract()
                    },
                })
            }
            return
        }
    }

    const handleSendContactTimeout = (e) => {
        setLoadingWaitingContract(false)
    }

    return (
        <Container style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
            <HeaderComponent isShowLeft={true} navigation={navigation} title={t('econtract_list_title')} titleAlgin="flex-start" />
            <RowTitleGroup noPaddingHorizontal text={t<string>('econtract_folder')} />
            <View style={[UI.view, { backgroundColor: styles.PRIMARY__BG__COLOR }]}>
                <HeaderList colSpan={colSpan} noPadding typeHeader="ECONTRACT_LIST" />
                <FlatList
                    data={listEcontract}
                    keyExtractor={(item, index) => String(index)}
                    ListEmptyComponent={() => (
                        <View style={UI.View}>
                            <Image source={CONTRACT_EMPTY} style={UI.Image} />
                            <View style={UI.textEmptyView}>
                                <Text style={UI.textEmptyStyle(styles)}>{t<string>('contract_list_empty_message_1')}</Text>
                                <Text style={UI.textEmptyWarningStyle(styles)}>{t<string>('contract_list_empty_message_2')}</Text>
                            </View>
                        </View>
                    )}
                    ListFooterComponent={<SignAccountEcontract />}
                    refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handlePullToRefresh} />}
                    renderItem={({ item }) => (
                        <EContractItem
                            colSpan={colSpan}
                            isDownloadFile={isDownloading}
                            item={item}
                            onPressDownload={() => onPressDownloadFile(item)}
                            onPressSign={() => onPressSignEContract(item)}
                            onPressView={() => onPressViewEcontract(item)}
                        />
                    )}
                />
            </View>
            {loadingWaitingContract ? (
                <ModalLoading
                    content={t('ekyc_prepare_econtract')}
                    maxVisibleLoading={60000}
                    setLoading={(loadingState) => {
                        setLoadingWaitingContract(loadingState)
                    }}
                    showTimeoutMessage={false}
                    visible={loadingWaitingContract}
                />
            ) : null}
        </Container>
    )
}

export default EContractManagement

const UI = StyleSheet.create({
    Image: {
        alignItems: 'center',
        height: 214,
        justifyContent: 'center',
        marginVertical: dm.vertical(18),
        resizeMode: 'contain',
    },
    View: {
        alignItems: 'center',
        justifyContent: 'center',
    },
    accountView: { alignContent: 'center', flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
    container: { justifyContent: 'space-between', paddingHorizontal: 80, paddingVertical: 16, width: '100%' },
    passwordView: { alignContent: 'center', flexDirection: 'row', justifyContent: 'space-between' },
    textEmptyStyle: (styles) => ({ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal, textAlign: 'center' }),
    textEmptyView: {
        alignItems: 'center',
        justifyContent: 'center',
        paddingVertical: dm.vertical(32),
        width: '100%',
    },
    textEmptyWarningStyle: (styles) => ({
        color: COLORS.YELLOW_F1F510,
        fontSize: fontSizes.verySmall,
        textAlign: 'center',
        fontStyle: 'italic',
        marginTop: dm.vertical(16),
    }),
    view: { flex: 1, paddingHorizontal: 10, paddingVertical: 5 },
})
