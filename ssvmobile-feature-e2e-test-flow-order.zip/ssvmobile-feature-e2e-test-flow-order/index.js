/**
 * @format
 */


import { AppRegistry } from 'react-native'

import { name as appName } from './app.json'
import App from './src/App'
import Analytics from './src/utils/TrackingData/Analytics'
if (__DEV__) {
    import('./ReactotronConfig').then(() => console.log('Reactotron Configured'))
}
Analytics.init()

AppRegistry.registerComponent(appName, () => App)
