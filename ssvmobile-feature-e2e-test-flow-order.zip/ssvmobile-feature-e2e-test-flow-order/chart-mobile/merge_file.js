const fs = require('fs')

function Appen_file(appen_file) {
    const rootDir = process.cwd()
    const destFile = `${rootDir}/${appen_file}`
    const datacss = fs.readFileSync(destFile, 'utf-8')
    return datacss
}

const replaceFile = () => {
    let result = ``
    const rootDir = process.cwd()
    const filesJS = fs.readdirSync('build/static/js')
    const fileCss = fs.readdirSync('build/static/css')
    const listFileCss = fileCss.filter((item) => item.endsWith('chunk.css'))
    const listFileScript = filesJS.filter((item) => item.endsWith('chunk.js'))
    const desFile = `${rootDir}/build/index.html`
    const dataHtml = fs.readFileSync(desFile, 'utf-8')
    const script = Appen_file(`build/static/js/${listFileScript[0]}`)
    const script2 = Appen_file(`build/static/js/${listFileScript[1]}`)

    result = dataHtml.replace(
        `<link href="/static/css/${listFileCss[0]}" rel="stylesheet">`,
        `<style>
        ${Appen_file(`build/static/css/${listFileCss[0]}`)}
    </style>`,
    )
    result = result.replace(`<script src="/static/js/${listFileScript[0]}"></script>`, `*index-script*`)

    result = result.replace(
        `*index-script*`,
        `<script>
            ${script}
        </script>`,
    )
    result = result.replace(
        `<script src="/static/js/${listFileScript[1]}"></script>`,
        `<script>
            ${script2}  
        </script>`,
    )
    fs.writeFileSync(desFile, result, 'utf-8')
}

const replaceFileHtml = (destination) => {
    try {
        const sourceFile = `build/index.html`
        const desFile = `${destination}`
        const data = fs.readFileSync(sourceFile, 'utf-8')
        fs.writeFileSync(desFile, data, 'utf-8')
    } catch (e) {
        process.exit(1)
    }
}

const build_run = () => {
    replaceFile()
    replaceFileHtml('../src/basic-components/custom-chart/index.html')
    replaceFileHtml('../android/app/src/main/assets/index.html')
}

build_run()
