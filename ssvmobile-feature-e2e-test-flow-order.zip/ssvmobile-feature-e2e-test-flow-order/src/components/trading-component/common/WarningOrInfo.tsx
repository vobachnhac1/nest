import React, { useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { StyleSheet, View, ViewProps } from 'react-native'
import { Col, Right, Row } from 'native-base'

import { Text } from '../../../basic-components'
import { StoreContext } from '../../../store'
import { dimensions as dm, fontSizes as fs, fontWeights as fw } from '../../../styles'

// TODO: Thêm tính năng: success, error, info
// TODO: Thêm icon
// Ai làm cũng được

interface IWarningOrInfo {
    text: string
    icon: any
    rowStyle: ViewProps['style']
}

const WarningOrInfo = ({ text, icon, rowStyle = {}, ...props }) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()
    return (
        <View style={[UI.Row, rowStyle]}>
            <Text
                style={{
                    fontWeight: fw.bold,
                    fontStyle: 'italic',
                    fontSize: fs.verySmall,
                    color: styles.WARN__COLOR,
                }}
            >
                {t<string>(text)}
            </Text>
        </View>
    )
}

export default WarningOrInfo

const UI = StyleSheet.create({
    Row: { marginBottom: dm.vertical(8), marginHorizontal: dm.moderate(8) },
})
