'use strict'

import React from 'react'
import { StyleSheet } from 'react-native'

import { dimensions, fontSizes } from '../../styles'

const hairlineWidth = StyleSheet.hairlineWidth

export const BG_COLOR = '#d2d5dc'

export default StyleSheet.create({
    main: {
        alignSelf: 'flex-end',
        flex: 1,
    },
    row: {
        flexDirection: 'row',
    },
    wrapper: {
        backgroundColor: '#f4f4f4',
        bottom: 0,
        elevation: 12,
        flexDirection: 'row',
        position: 'absolute',
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 0,
        },
        shadowOpacity: 0.37,
        shadowRadius: 7.49,
    },
})

export const keyStyle = StyleSheet.create({
    bd: {
        alignItems: 'center',
        borderColor: '#a5a5a5',
        borderRightWidth: hairlineWidth,
        borderTopWidth: hairlineWidth,
        flex: 1,
        justifyContent: 'center',
    },
    bgLessL: {
        backgroundColor: '#fff',
    },
    bg_d2d5dc: {
        backgroundColor: BG_COLOR,
    },
    border: {
        borderColor: '#FFF',
    },
    dot: {
        fontSize: 30,
        height: 30,
        lineHeight: 25,
    },
    mainText: {
        color: '#000',
        fontSize: fontSizes.big,
    },
    otherText: {
        color: '#333',
        fontSize: 10,
    },
    wrapper: {
        backgroundColor: '#fff',
        elevation: 6,
        flex: 1,
        height: dimensions.vertical(66, 0.5),
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 0,
        },
        shadowOpacity: 0.27,

        shadowRadius: 4.65,
    },
})
