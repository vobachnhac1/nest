import React, { useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Linking, Platform, View } from 'react-native'
import Modal from 'react-native-modal'
import Svg, { Defs, G, LinearGradient, Path, Stop } from 'react-native-svg'
import SyncStorage from 'sync-storage'

import CONFIG, { APP_VERSION } from '../../../assets/config'
import { Text } from '../../../basic-components'
import { ButtonCustom, ModalByView, ModalContent } from '../../../components/trading-component'
import useSafeModalState, { GLOBAL_MODAL_KEY } from '../../../hoc/useSafeModalState/index'
import { StoreContext } from '../../../store'
import { StoreTrading } from '../../../store-trading'
import { dimensions, dimensions as dm, fontSizes as fs, IconSvg } from '../../../styles'
import { eventList, glb_sv, reqFunct, STORE_KEY } from '../../../utils'
import sendRequest from '../../../utils/sendRequest'

const ServiceInfo: { [key: string]: ISserviceInfo } = {
    CHECK_VERSION_APP: {
        reqFunct: reqFunct.CHECK_VERSION_APP,
        WorkerName: 'FOSxCommon',
        ServiceName: 'FOSxCommon_Token_Mgt',
        ClientSentTime: '0',
        Operation: 'Q',
    },
}

const ModalNotifyNewVersion = () => {
    const { styles, language } = useContext(StoreContext)
    const { userInfo } = useContext(StoreTrading)
    const { t } = useTranslation()
    // All orther state
    const [isOpenModal, setIsOpenModal] = useSafeModalState(GLOBAL_MODAL_KEY.ModalNotifyNewVersion)
    const [updateUrl, setUpdateUrl] = useState('')
    const [isUnstable, setIsUnstable] = useState(false)

    useEffect(() => {
        setTimeout(() => {
            console.log('checkVersion() >>>>>>>>>>>>>')
            checkVersion()
        }, 3000)
    }, [])

    const checkVersion = async () => {
        const message: IServiceRespone = await new Promise((resolve) => {
            const InputParams = ['CHECK', '']
            sendRequest(ServiceInfo.CHECK_VERSION_APP, InputParams, (reqInfoMap, message) => resolve(message))
        })
        const { Message, Data, Result } = message
        // console.log('message', message);
        if (Number(Result) === 0) {
            return
        } else {
            try {
                const res = JSON.parse(message.Data.replace(/\\n/g, '').replace(/\n/g, ''))[0]
                const mts_stable_version = res.c1
                const mts_latest_version = res.c2
                const { link_playStore, link_appStore } = CONFIG[glb_sv.activeCode]
                const URL_UPDATE = Platform.select({ ios: link_appStore, android: link_playStore })
                setUpdateUrl(URL_UPDATE)
                // if (!mts_latest_version || !mts_stable_version || !URL_UPDATE) return;

                // const compareStable = versionCompare(CONFIG[glb_sv.activeCode].build_version, stable_version);
                // const compareLatest = versionCompare(CONFIG[glb_sv.activeCode].build_version, latest_version);
                const compareStable = versionCompare(APP_VERSION, mts_stable_version)
                const compareLatest = versionCompare(APP_VERSION, mts_latest_version)
                console.log('>>>>>>>> ', { compareStable, compareLatest, URL_UPDATE })

                if (compareStable === -1) {
                    // Có version mới nhất và version hiện tại thì không ổn định
                    console.log('>>> Version mới nhất [Unstable version] ')
                    setIsOpenModal(true)
                    setIsUnstable(true)
                } else if (compareLatest === -1) {
                    // Có version mới nhất => Hiển thị modal link tới AppStore, Google Play
                    console.log('>>> Version mới nhất ')
                    setIsOpenModal(true)
                } else {
                    console.log('>>> Check Version ok ')
                    // Open modal
                }
            } catch (err) {
                console.log(err)
                return
            }
        }
    }
    const hideModal = () => {
        setIsOpenModal(false)
    }

    const OpenURLButton = async (url) => {
        try {
            const supported = await Linking.canOpenURL(url)
            if (supported) {
                await Linking.openURL(url)
            }
        } catch (err) {
            console.log('OpenURLButton -> err', err)
        }
    }
    if (!isOpenModal) return null

    return (
        <ModalByView isVisible={isOpenModal} useNativeDriver={true} onBackButtonPress={hideModal} onBackdropPress={hideModal}>
            <ModalContent
                iconComponent={<IconSvg.InfoIcon color={isUnstable ? styles.ERROR__COLOR : styles.WARN__COLOR} height={40} opacity={1} width={40} />}
                title={t('title_new_updates')}
                type="confirm"
            >
                {/* <View style={{ justifyContent: 'center', alignItems: 'center', flexDirection: 'row' }}>
					<IconListNewFeature />
				</View> */}
                <View style={{ marginHorizontal: dimensions.moderate(16) }}>
                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fs.normal, textAlign: 'center' }}>
                        {t<string>('notify_release_new_version')}
                    </Text>
                </View>
                {isUnstable ? (
                    <View style={{ marginHorizontal: dimensions.moderate(16), marginTop: 8 }}>
                        <Text style={{ color: styles.ERROR__COLOR, fontSize: fs.smallest, textAlign: 'center' }}>
                            {t<string>('notify_release_new_version_unstable')}
                        </Text>
                    </View>
                ) : null}
                <ButtonCustom
                    text={t('common_Ok')}
                    type="confirm"
                    onPress={() => {
                        hideModal()
                        OpenURLButton(updateUrl)
                    }}
                />
                <ButtonCustom
                    last
                    text={t('common_Cancel')}
                    type="back"
                    onPress={() => {
                        hideModal()
                    }}
                />
                <View style={{ height: 8 }} />
            </ModalContent>
        </ModalByView>
    )
}

export default ModalNotifyNewVersion

const IconListNewFeature = () => {
    return (
        <Svg height={64} viewBox="0 0 40 40" width={64}>
            <Path d="M1.5 35.5V8.55h37v20.189L28.843 35.5z" fill="#fff" />
            <Path d="M38 9.05v19.429L28.685 35H2V9.05h36m1-1H1V36h28l10-7V8.05z" fill="#788b9c" />
            <Path d="M1.5 8.5v-2c0-1.103.897-2 2-2h33c1.103 0 2 .897 2 2v2h-37z" fill="#c8d1db" />
            <Path d="M36.5 5c.827 0 1.5.673 1.5 1.5V8H2V6.5C2 5.673 2.673 5 3.5 5h33m0-1h-33A2.5 2.5 0 001 6.5V9h38V6.5A2.5 2.5 0 0036.5 4z" fill="#66798f" />
            <Path d="M7 16.5h3m3 0h20m-26 4h3m3 0h20m-26 4h3m-3 4h3" fill="none" stroke="#788b9c" strokeMiterlimit={10} />
            <Path d="M21.318 28H13v1h8.807zm3.425-4H13v1h11.568z" fill="#788b9c" />
            <Path d="M22.91 35H28v1h-4.708zM38 30.425l1-1.647v-2.88l-1-.558z" fill="#d6e3ed" />
            <Path
                d="M29.045 37.318l-2.828.401-.493-2.814-2.525-1.339L24.454 31l-1.255-2.566 2.525-1.339.493-2.814 2.828.401 2.053-1.987 2.053 1.987 2.828-.401.494 2.814 2.523 1.339L37.741 31l1.255 2.566-2.523 1.339-.494 2.814-2.828-.401-2.053 1.987z"
                fill="#ffeea3"
            />
            <Path
                d="M31.098 23.391l1.53 1.48.351.34.484-.068 2.107-.298.368 2.096.084.482.432.229 1.88.997-.935 1.912-.214.439.215.439.935 1.912-1.88.997-.432.229-.084.482-.368 2.096-2.107-.298-.484-.068-.351.34-1.53 1.48-1.53-1.48-.351-.34-.484.068-2.107.298-.368-2.096-.084-.481-.432-.229-1.88-.997.935-1.912.213-.44-.215-.439-.935-1.912 1.88-.997.432-.229.084-.481.368-2.096 2.107.298.484.068.351-.34 1.531-1.481m0-1.391l-2.225 2.152-3.065-.434-.535 3.049-2.735 1.451L23.898 31l-1.359 2.781 2.735 1.451.535 3.049 3.065-.434L31.098 40l2.225-2.152 3.065.434.535-3.049 2.735-1.451L38.298 31l1.359-2.781-2.735-1.451-.535-3.049-3.065.434L31.098 22z"
                fill="#ba9b48"
            />
        </Svg>
    )
}

const versionCompare = (v1: string, v2: string, options?: { lexicographical?: any; zeroExtend?: any }) => {
    let lexicographical = options && options.lexicographical,
        zeroExtend = options && options.zeroExtend,
        v1parts: string[] | number[] = v1.split('.'),
        v2parts: string[] | number[] = v2.split('.')

    function isValidPart(x) {
        return (lexicographical ? /^\d+[A-Za-z]*$/ : /^\d+$/).test(x)
    }

    if (!v1parts.every(isValidPart) || !v2parts.every(isValidPart)) {
        return NaN
    }

    if (zeroExtend) {
        while (v1parts.length < v2parts.length) v1parts.push('0')
        while (v2parts.length < v1parts.length) v2parts.push('0')
    }

    if (!lexicographical) {
        v1parts = v1parts.map(Number)
        v2parts = v2parts.map(Number)
    }

    for (let i = 0; i < v1parts.length; ++i) {
        if (v2parts.length == i) {
            return 1
        }

        if (v1parts[i] == v2parts[i]) {
            continue
        } else if (v1parts[i] > v2parts[i]) {
            return 1
        } else {
            return -1
        }
    }

    if (v1parts.length != v2parts.length) {
        return -1
    }

    return 0
}
