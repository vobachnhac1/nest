import React, { useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { StyleSheet, TextInput, View } from 'react-native'

import { Text } from '../../../../basic-components'
import { StoreContext } from '../../../../store'
import { dimensions as dm, fontSizes as fs } from '../../../../styles'
import { FormatNumber, glb_sv } from '../../../../utils'

export const MarginInputCurrentNewValue = ({ onChangeMarginValue = () => null, marginValue = '' }) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()

    return (
        <>
            <View style={[UI.row, { alignItems: 'center' }, { display: 'flex' }]}>
                <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fs.small, flex: 4 }}>{t('new_limit_margin')}</Text>
                <View
                    style={{
                        flex: 5,
                        backgroundColor: styles.INPUT__BG,
                        paddingHorizontal: 10,
                        paddingVertical: 8,
                        borderRadius: 4,
                        flexDirection: 'row',
                    }}
                >
                    <TextInput
                        keyboardType="numeric"
                        placeholder={t('new_limit_margin')}
                        placeholderTextColor={styles.PLACEHODLER__COLOR}
                        returnKeyType="next"
                        style={{
                            marginStart: dm.moderate(4),
                            fontSize: fs.small,
                            color: styles.PRIMARY__CONTENT__COLOR,
                            textAlignVertical: 'center',
                            flex: 1,
                        }}
                        textAlign="right"
                        value={FormatNumber(marginValue, 0)}
                        onChangeText={(value) => {
                            onChangeMarginValue(glb_sv.filterNumber(value))
                        }}
                    />
                </View>
            </View>
        </>
    )
}

const UI = StyleSheet.create({
    BlankSpace: {
        height: 10,
        width: dm.moderate(40),
    },
    ButtonDelete: {
        alignItems: 'center',
        height: '100%',
        justifyContent: 'center',
        position: 'absolute',
        right: 0,
    },
    GroupInput: {
        marginVertical: dm.halfVerticalIndent,
        paddingHorizontal: dm.halfIndent,
    },
    RowInput: {
        marginLeft: dm.moderate(8),
        marginVertical: dm.vertical(8),
    },
    modal: {
        justifyContent: 'flex-end',
        margin: 0,
    },
    row: {
        alignItems: 'center',
        borderRadius: 12,
        flexDirection: 'row',
        marginHorizontal: dm.moderate(16),
        marginTop: dm.vertical(12),
    },
})
