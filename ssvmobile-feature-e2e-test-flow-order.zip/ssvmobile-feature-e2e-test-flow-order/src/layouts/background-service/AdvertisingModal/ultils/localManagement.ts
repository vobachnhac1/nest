import SyncStorage from 'sync-storage'

import { STORE_KEY } from '../../../../utils'

// export const saveDataPopupToLocal =  async (data) => {
//     SyncStorage.set(STORE_KEY.POPUP_ADVERTISING_NOTIFY, data)
// }
// export const getDataPopupToLocal =  async () => {
//     SyncStorage.get(STORE_KEY.POPUP_ADVERTISING_NOTIFY)
// }
export const setDataPopupToLocalDontAskAgain = async (
    popupData: any,
    id: string,
    isDontAsk: boolean,
    timeExpriedNumber?: number,
    timeExpriedType?: 'days' | 'forever' | 'hours' | 'minutes',
) => {
    const prevData = await getDataPopupToLocalDontAskAgain()
    const newData = prevData || {}
    newData[id] = {
        isDontAsk: isDontAsk,
        timeExpried: _getTimeExpried(timeExpriedNumber || 1, timeExpriedType || 'days'), // Thời gian hết hạn là một ngày
        dataPopup: popupData,
    }
    SyncStorage.set(STORE_KEY.POPUP_ADVERTISING_NOTIFY, newData)
}
export const getDataPopupToLocalDontAskAgain = async () => {
    // SyncStorage.remove('POPUP_ADVERTISING_NOTIFY')
    return (await SyncStorage.get(STORE_KEY.POPUP_ADVERTISING_NOTIFY)) || {}
}

const _getTimeExpried = (period: number, type: 'days' | 'forever' | 'hours' | 'minutes') => {
    const currentTime = new Date()
    if (type === 'days') {
        currentTime.setHours(0)
        currentTime.setMinutes(0)
        return currentTime.setDate(currentTime.getDate() + period) // Thời gian hết hạn là một ngày
    }
    if (type === 'forever') {
        return currentTime.setDate(currentTime.getDate() + 1000) // 3 năm
    }
    if (type === 'hours') {
        return currentTime.setHours(currentTime.getHours() + period)
    }
}

export const __DEV__deleteLocalPopup = async () => {
    console.log('__DEV__deleteLocalPopup')
    return await SyncStorage.remove(STORE_KEY.POPUP_ADVERTISING_NOTIFY)
}
