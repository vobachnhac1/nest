import React from 'react'
import { Image, ScrollView, StyleSheet, View } from 'react-native'
import { RNCamera } from 'react-native-camera'
import Modal from 'react-native-modal'

// import Spinner from 'react-native-loading-spinner-overlay'
import ImageCamera from '../../../assets/images/common/camera.png'
import EKYC_NOTE_03 from '../../../assets/images/common/ekyc_card_corner.png'
import EKYC_NOTE_02 from '../../../assets/images/common/ekyc_card_glare.png'
import EKYC_NOTE_01 from '../../../assets/images/common/ekyc_id_card.png'
import ICON_APPROVE from '../../../assets/images/common/ic_approve.png'
import ICON_REJECT from '../../../assets/images/common/ic_reject.png'
import StickIcon from '../../../assets/images/common/tick.svg'
import { Text } from '../../../basic-components'
import { ButtonCustom, ModalContent } from '../../../components/trading-component'
import { dimensions as dm, fontSizes as fs, fontWeights as fw, IconSvg } from '../../../styles'
import { HIEGHT, WIDTH } from '../../../styles/helper/dimensions'
import EkycButton from '../components/EkycButton'

const listNoted = [
    { type: 'warning', title: 'ekyc_id_card_note_01' },
    { type: 'warning', title: 'ekyc_id_card_note_02' },
    { type: 'warning', title: 'ekyc_id_card_note_03' },
]

const FRAME_DETECTION = {
    center: {
        y: HIEGHT / 4 - 250 / 2,
        x: WIDTH / 2 - 200 / 2,
    },
    cameraHeight: Math.round(((WIDTH - 65) / 3) * 2.2),
}

export const StepEkyc01 = ({
    styles,
    t,
    isVisible,
    onRemoveImages,
    urlSuccess,
    takePicture,
    renderFileUri,
    listMessage,
    cameraRef,
    setIsVisible,
    setAlertModal,
    alertModal,
    forceUpdate,
    loading,
    setLoading,
    switchStep,
    onUploadData,
}) => {
    return (
        <>
            <ScrollView contentContainerStyle={{ backgroundColor: styles.PRIMARY__BG__COLOR }} showsVerticalScrollIndicator={false}>
                <View>
                    <View>
                        <Text style={[UI.subTitle, { color: styles.PRIMARY }]}>{t('front_id_card').toUpperCase()}</Text>
                    </View>
                    <View
                        style={{
                            backgroundColor: styles.SERVICE__BACKGROUND__WRAP,
                            paddingHorizontal: 8,
                            paddingVertical: 8,
                            borderRadius: 4,
                        }}
                    >
                        <Text style={{ textAlign: 'center', fontSize: fs.verySmall, color: 'orange' }}>{t<string>('note_front_id_card')}</Text>
                    </View>
                </View>
                <View style={UI.borderCamera}>
                    <View style={UI.cameraArea}>
                        {urlSuccess ? (
                            renderFileUri()
                        ) : (
                            <RNCamera
                                androidCameraPermissionOptions={{
                                    title: t('title_permission_camera'),
                                    message: t('msg_permission_camera'),
                                    buttonPositive: t('common_alert_agree'),
                                    buttonNegative: t('common_Cancel'),
                                }}
                                captureAudio={false}
                                defaultVideoQuality={RNCamera.Constants.VideoQuality['1080p']}
                                ref={cameraRef}
                                style={UI.camera}
                                type={RNCamera.Constants.Type.back}
                                updateTrickProps={forceUpdate}
                            />
                        )}
                    </View>
                </View>
                <View style={[UI.row, { marginTop: dm.moderate(20) }]}>
                    <View style={UI.col}>
                        <View style={[UI.noteImageWrap, { borderColor: styles.EKYC__BORDER__NOTE, backgroundColor: styles.EKYC__BACKGROUND__NOTE }]}>
                            <Image source={EKYC_NOTE_01} style={UI.image} />
                            <Image source={ICON_APPROVE} style={UI.iconFloat} />
                        </View>
                        <Text style={{ color: styles.SECOND__CONTENT__COLOR, alignItems: 'center', textAlign: 'center' }}>{t<string>('note_valid_image')}</Text>
                    </View>
                    <View style={UI.col}>
                        <View style={[UI.noteImageWrap, { borderColor: styles.EKYC__BORDER__NOTE, backgroundColor: styles.EKYC__BACKGROUND__NOTE }]}>
                            <Image source={EKYC_NOTE_02} style={UI.image} />
                            <Image source={ICON_REJECT} style={UI.iconFloat} />
                        </View>
                        <Text style={{ color: styles.SECOND__CONTENT__COLOR, alignItems: 'center', textAlign: 'center' }}>
                            {t<string>('note_not_blur_glare')}
                        </Text>
                    </View>
                    <View style={UI.col}>
                        <View style={[UI.noteImageWrap, { borderColor: styles.EKYC__BORDER__NOTE, backgroundColor: styles.EKYC__BACKGROUND__NOTE }]}>
                            <Image source={EKYC_NOTE_03} style={UI.image} />
                            <Image source={ICON_REJECT} style={UI.iconFloat} />
                        </View>
                        <Text style={{ color: styles.SECOND__CONTENT__COLOR, alignItems: 'center', textAlign: 'center' }}>
                            {t<string>('note_not_cut_corner')}
                        </Text>
                    </View>
                </View>
                {listMessage?.length > 0 ? (
                    <View style={{ marginTop: 5 }}>
                        {listMessage.map((item) => (
                            <Text key={item} style={{ color: 'orange' }}>
                                - {t<string>(item)}
                            </Text>
                        ))}
                    </View>
                ) : null}
                <View
                    style={{
                        justifyContent: 'center',
                        flexDirection: 'column',
                        alignContent: 'center',
                        alignItems: 'center',
                    }}
                >
                    {!urlSuccess ? (
                        <>
                            <ButtonCustom text="" onPress={takePicture}>
                                <View style={UI.capture}>
                                    <Image source={ImageCamera} style={{ width: 28, height: 28 }} />
                                    <Text
                                        style={{
                                            color: '#f5f5f5',
                                            fontWeight: fw.bold,
                                            fontSize: fs.normal,
                                            marginLeft: 8,
                                        }}
                                    >
                                        {t<string>('front_id_card').toUpperCase()}
                                    </Text>
                                </View>
                            </ButtonCustom>
                        </>
                    ) : (
                        <View>
                            <ButtonCustom color={styles.INPUT__BG} text={t('take_again')} type="back" onPress={onRemoveImages} />
                        </View>
                    )}
                </View>
            </ScrollView>
            <View style={{ flexDirection: 'row', marginBottom: 16 }}>
                <EkycButton
                    customStyle={{ flex: 1, marginEnd: 16 }}
                    text={t('common_button_previous')}
                    onPress={() => switchStep.prev({ step: 1, subStep: 0 })}
                />
                <EkycButton customStyle={{ flex: 1 }} disabled={!urlSuccess} isLoading={loading} text={t('common_button_next')} onPress={onUploadData} />
            </View>
            {/* //#region Modal confirm các điều kiện chụp ảnh */}
            <Modal
                hideModalContentWhileAnimating
                isVisible={isVisible}
                style={{ marginLeft: 5, marginRight: 5 }}
                useNativeDriver={true}
                onBackButtonPress={() => {
                    setIsVisible(false)
                }}
                onBackdropPress={() => {
                    return
                }}
            >
                <ModalContent title={t('ekyc_id_card_note_title').toLocaleUpperCase()}>
                    <View style={{ paddingHorizontal: dm.moderate(16), alignItems: 'center', justifyContent: 'center', marginBottom: 16 }}>
                        <Text style={{ fontSize: fs.normal, color: styles.PRIMARY__CONTENT__COLOR, textAlign: 'center' }}>
                            {t<string>('ekyc_id_card_note_intro')}
                        </Text>
                    </View>
                    <View
                        style={{
                            paddingHorizontal: dm.moderate(16),
                            alignItems: 'center',
                            flexDirection: 'column',
                            justifyContent: 'center',
                        }}
                    >
                        {listNoted.map((item, index) => (
                            <View
                                key={item.type + index}
                                style={{ alignItems: 'center', flexDirection: 'row', justifyContent: 'center', paddingVertical: dm.moderate(4) }}
                            >
                                <View style={item.type === 'error' ? UI.buttonError : UI.buttonWarning}>
                                    <StickIcon style={{ color: styles.WHITE__COLOR, width: dm.moderate(14), height: dm.moderate(14), alignSelf: 'center' }} />
                                </View>
                                <Text
                                    style={{
                                        flex: 1,
                                        marginLeft: dm.moderate(6),
                                        fontSize: fs.normal,
                                        color: styles.PRIMARY__CONTENT__COLOR,
                                        textAlign: 'justify',
                                    }}
                                >
                                    {t<string>(item.title)}
                                </Text>
                            </View>
                        ))}
                    </View>
                    <ButtonCustom
                        text={t('common_alert_agree')}
                        type="confirm"
                        onPress={() => {
                            setIsVisible(false)
                        }}
                    />
                </ModalContent>
            </Modal>
            {/* //#endregion */}
            <Modal
                hideModalContentWhileAnimating
                isVisible={alertModal}
                style={{ marginLeft: 5, marginRight: 5 }}
                useNativeDriver={true}
                onBackButtonPress={() => {
                    setAlertModal(false)
                }}
            >
                <ModalContent iconComponent={<IconSvg.ErrorIcon color={styles.EKYC__COLOR} />} title={t('notify_info')}>
                    <View
                        style={{
                            paddingHorizontal: dm.moderate(16),
                            alignItems: 'center',
                            flexDirection: 'column',
                            justifyContent: 'center',
                        }}
                    >
                        {listMessage.map((item, index) => (
                            <View
                                key={'err_' + index}
                                style={{ alignItems: 'center', flexDirection: 'row', justifyContent: 'center', paddingVertical: dm.moderate(4) }}
                            >
                                <Text style={{ flex: 1, marginLeft: dm.moderate(6), fontSize: fs.normal, color: styles.PRIMARY__CONTENT__COLOR }}>
                                    {t<string>(item)}
                                </Text>
                            </View>
                        ))}
                    </View>
                    <ButtonCustom
                        text={t('common_alert_agree')}
                        type="confirm"
                        onPress={() => {
                            setAlertModal(false)
                        }}
                    />
                </ModalContent>
            </Modal>
        </>
    )
}

const UI = StyleSheet.create({
    borderCamera: {
        borderColor: 'green',
        borderRadius: 5,
        borderWidth: 2,
        height: 'auto',
        marginTop: 10,
        padding: 10,
    },
    buttonError: {
        backgroundColor: 'red',
        borderRadius: 50,
        flex: 0,
        height: dm.moderate(24),
        justifyContent: 'center',
        marginLeft: 6,
        marginRight: 2,
        marginVertical: dm.vertical(4),
        width: dm.moderate(24),
    },
    buttonWarning: {
        backgroundColor: 'orange',
        borderRadius: 50,
        flex: 0,
        height: dm.moderate(24),
        justifyContent: 'center',
        marginLeft: 6,
        marginRight: 2,
        marginVertical: dm.vertical(4),
        width: dm.moderate(24),
    },
    camera: {
        // working
        justifyContent: 'flex-end',
        alignItems: 'center',
        flexGrow: 1,
    },
    cameraArea: {
        // working
        height: FRAME_DETECTION.cameraHeight,
        // width: WIDTH - 65,
        borderRadius: 5,
        overflow: 'hidden',
    },
    capture: {
        alignItems: 'center',
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
        // marginBottom: -4
    },
    col: {
        marginHorizontal: dm.moderate(8),
        width: '30%',
    },
    container: {
        alignContent: 'space-between',
        flex: 1,
        height: HIEGHT - 200,
        justifyContent: 'space-between',
        marginLeft: 20,
        marginRight: 20,
    },
    iconFloat: {
        height: 25,
        position: 'absolute',
        right: -15,
        top: -15,
        width: 25,
    },
    image: {
        alignContent: 'flex-start',
        alignItems: 'center',
        aspectRatio: 4 / 3,
        borderRadius: 0,
        height: 'auto',
        justifyContent: 'flex-start',
        resizeMode: 'contain',
        width: '100%',
    },
    noteImageWrap: {
        borderRadius: 10,
        borderWidth: 2,
        marginBottom: dm.moderate(8),
        padding: '8%',
        position: 'relative',
    },
    row: {
        alignContent: 'space-between',
        alignItems: 'flex-start',
        flexDirection: 'row',
        justifyContent: 'space-evenly',
        marginLeft: dm.moderate(4),
        marginRight: dm.moderate(8),
        marginTop: dm.vertical(12),
    },
    subTitle: { fontSize: fs.xmedium, fontWeight: fw.bold, marginBottom: 16, textAlign: 'center' },
})
