import React, { memo, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Image, RefreshControl, ScrollView, StyleSheet, TouchableOpacity } from 'react-native'
import QRCode from 'react-native-qrcode-svg'
import ToastGlobal from 'react-native-toast-message'
import Clipboard from '@react-native-clipboard/clipboard'
import cloneDeep from 'lodash/cloneDeep'
import { Container, Content, Row, View } from 'native-base'

import IconBack from '../../assets/images/common/ic_arrow_right.svg'
import IconCopy from '../../assets/images/common/ic_copy.svg'
import LogoSSVIcon from '../../assets/images/logo/081_splash_logo_light.png'
import LogoBIDV from '../../assets/images/logo/logo_bidv.png'
import LogoSSV from '../../assets/images/logo/Shinhan-Bank-logo.png'
import { Text } from '../../basic-components'
import Account from '../../components/account'
import HeaderComponent from '../../components/header'
import { RowTitleGroup } from '../../components/trading-component'
import EmptyData from '../../components/trading-component/error-view'
import { StoreContext } from '../../store'
import { StoreTrading } from '../../store-trading'
import { dimensions, fontSizes, fontWeights, IconSvg } from '../../styles'
import { glb_sv, reqFunct, Screens, sendRequest, wait } from '../../utils'

const ServiceInfo = {
    GET_QR_CODE_CASH_DEPOSIT: {
        reqFunct: reqFunct.GET_QR_CODE_CASH_DEPOSIT,
        WorkerName: 'FOSqBank',
        ServiceName: 'FOSqBank_Common_1',
        ClientSentTime: '0',
        Operation: 'Q',
    },
}

export default function CashDeposit({ navigation }) {
    const { styles, theme } = useContext(StoreContext)
    const { t } = useTranslation()
    const { userInfo } = useContext(StoreTrading)
    const [qrCodeData, setQrCodeData] = useState([])
    const [bankSelectedIndex, setbBankSelectedIndex] = useState(-1)
    const scrollviewRef = useRef(null)
    const refreshing = useRef(false)

    useEffect(() => {
        getCashQRCode()
    }, [userInfo])

    const getCashQRCode = () => {
        const inputParams = ['02', userInfo.actn_curr, userInfo.sub_curr]
        sendRequest(ServiceInfo.GET_QR_CODE_CASH_DEPOSIT, inputParams, handleGetCashQRCode)
    }

    const handleGetCashQRCode = (reqInfoMap, message) => {
        console.log('handleGetCashQRCode', reqInfoMap, message)
        refreshing.current = false
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata = []
            try {
                jsondata = JSON.parse(message.Data)
                const tempList = cloneDeep(jsondata)
                tempList.map((item, index, array) => {
                    if (item.c5 !== '') {
                        setbBankSelectedIndex(index)
                        array.length = 0
                    }
                })
                // c0. Mã ngân hàng
                // c1. Tên ngân hàng full name
                // c2. Tên ngần hàng short name
                // c3. Số tài khoản
                // c4. Ghi chú
                // c5. Mã QR code
            } catch (err) {
                return
            }
            if (Number(message.Packet) <= 0) {
                setQrCodeData(jsondata)
            }
        }
    }

    const onRefresh = () => {
        refreshing.current = true
        wait(300).then(() => {
            getCashQRCode()
        })
    }

    const onChangeBank = (index) => {
        setbBankSelectedIndex(index) // 0: Shinhan; 1: BIDV
    }

    const onClickCopy = (text) => {
        if (!text) return
        Clipboard.setString(String(text))
        ToastGlobal.show({
            text2: t('copied'),
            type: 'success',
            position: 'bottom',
        })
    }

    const _onClickBackButton = () => {
        navigation.goBack()
    }

    const onGenQRCodeError = () => {
        console.log('onGenQRCodeError')
    }

    return (
        <Container>
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft
                leftButtonLink={_onClickBackButton}
                navigation={navigation}
                title={t('cash_deposit_title')}
                titleAlgin="flex-start"
                transparent
            />
            <Content
                refreshControl={<RefreshControl refreshing={refreshing.current} tintColor={styles.PRIMARY__CONTENT__COLOR} onRefresh={onRefresh} />}
                style={{ ...UI.container, backgroundColor: styles.PRIMARY__BG__COLOR }}
            >
                <ScrollView ref={scrollviewRef}>
                    <View style={{ flexDirection: 'row', paddingHorizontal: dimensions.moderate(8), marginTop: dimensions.moderate(4) }}>
                        <Account navigation={navigation} noPadding />
                    </View>

                    <RowTitleGroup hasDivider />
                    <View style={{ flexDirection: 'row', justifyContent: 'space-evenly' }}>
                        <TouchableOpacity activeOpacity={0.7} onPress={() => onChangeBank(0)}>
                            <View style={{ ...UI.logoBox, borderColor: bankSelectedIndex === 0 ? styles.PRIMARY : styles.BORDER__MODAL }}>
                                <Image source={LogoSSV} style={UI.logo} />
                            </View>
                        </TouchableOpacity>
                        <TouchableOpacity activeOpacity={0.7} onPress={() => onChangeBank(1)}>
                            <View style={{ ...UI.logoBox, borderColor: bankSelectedIndex === 1 ? styles.PRIMARY : styles.BORDER__MODAL }}>
                                <Image source={LogoBIDV} style={UI.logo} />
                            </View>
                        </TouchableOpacity>
                    </View>

                    <View style={UI.wrap}>
                        <Text style={{ ...UI.title, color: styles.PRIMARY__CONTENT__COLOR }}>{t('beneficiary_bank')}</Text>
                        <TouchableOpacity onPress={() => onClickCopy(qrCodeData[bankSelectedIndex]?.c1)}>
                            <View style={UI.wrapContent}>
                                <Text
                                    style={{
                                        ...UI.content,
                                        color: styles.PRIMARY__CONTENT__COLOR,
                                        borderBottomColor: styles.PRIMARY__CONTENT__COLOR,
                                        flex: 1,
                                        paddingBottom: 4,
                                    }}
                                >
                                    {qrCodeData[bankSelectedIndex]?.c1}
                                </Text>
                                <IconCopy fill={styles.ICON__PRIMARY} style={UI.icon} />
                            </View>
                        </TouchableOpacity>
                    </View>

                    <View style={UI.wrap}>
                        <Text style={{ ...UI.title, color: styles.PRIMARY__CONTENT__COLOR }}>{t('beneficiary')}</Text>
                        <TouchableOpacity onPress={() => onClickCopy(qrCodeData[bankSelectedIndex]?.c3)}>
                            <View style={UI.wrapContent}>
                                <Text
                                    style={{
                                        ...UI.content,
                                        color: styles.PRIMARY__CONTENT__COLOR,
                                        borderBottomColor: styles.PRIMARY__CONTENT__COLOR,
                                        flex: 1,
                                        paddingBottom: 4,
                                    }}
                                >
                                    {qrCodeData[bankSelectedIndex]?.c3}
                                </Text>
                                <IconCopy fill={styles.ICON__PRIMARY} style={UI.icon} />
                            </View>
                        </TouchableOpacity>
                    </View>

                    <View style={UI.wrap}>
                        <Text style={{ ...UI.title, color: styles.PRIMARY__CONTENT__COLOR }}>{t('content')}</Text>
                        <TouchableOpacity onPress={() => onClickCopy(qrCodeData[bankSelectedIndex]?.c4)}>
                            <View style={UI.wrapContent}>
                                <Text
                                    style={{
                                        ...UI.content,
                                        color: styles.PRIMARY__CONTENT__COLOR,
                                        borderBottomColor: styles.PRIMARY__CONTENT__COLOR,
                                        flex: 1,
                                        paddingBottom: 4,
                                    }}
                                >
                                    {qrCodeData[bankSelectedIndex]?.c4}
                                </Text>
                                <IconCopy fill={styles.ICON__PRIMARY} style={UI.icon} />
                            </View>
                        </TouchableOpacity>
                    </View>

                    <View style={{ ...UI.qrcode, backgroundColor: styles.PRIMARY }}>
                        <View style={{ ...UI.qrcodeInner, backgroundColor: '#FFF' }}>
                            <View style={{ ...UI.qrTitle }}>
                                <Text style={{ color: styles.EKYC__COLOR, fontWeight: fontWeights.bold, fontSize: fontSizes.big }}>SSV </Text>
                                <Text style={{ color: styles.QR__COLOR, fontWeight: fontWeights.bold, fontSize: fontSizes.big }}>QR</Text>
                            </View>
                            <View style={{ borderColor: '#111', borderWidth: 1, padding: dimensions.moderate(8), alignItems: 'center' }}>
                                {qrCodeData[bankSelectedIndex]?.c5 ? (
                                    <QRCode
                                        ecl="L"
                                        logo={LogoSSVIcon}
                                        logoBackgroundColor="#FFF"
                                        logoSize={25}
                                        size={150}
                                        value={qrCodeData[bankSelectedIndex]?.c5}
                                        onError={(error) => {
                                            console.log(error)
                                        }}
                                    />
                                ) : (
                                    <EmptyData refresh={onRefresh} title={t('common_NoDataFound')} />
                                )}
                            </View>
                            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: dimensions.moderate(5) }}>
                                <Text style={{ color: styles.PRIMARY, fontSize: fontSizes.small, fontWeight: fontWeights.bold }}>NAPAS 247 </Text>
                                <Text style={{ color: '#111' }}>| </Text>
                                <Text style={{ color: styles.PRIMARY, fontSize: fontSizes.medium, fontWeight: fontWeights.bold }}>
                                    {qrCodeData[bankSelectedIndex]?.c2 || '---'}
                                </Text>
                            </View>
                        </View>
                    </View>

                    <View
                        style={[
                            UI.wrap,
                            {
                                borderWidth: 3,
                                borderColor: styles.THIRD__BORDER__COLOR,
                                borderRadius: 8,
                                paddingTop: dimensions.moderate(8),
                                paddingBottom: dimensions.moderate(8),
                            },
                        ]}
                    >
                        <TouchableOpacity onPress={() => navigation.navigate(Screens.DEPOSIT_GUIDE)}>
                            <View style={{ alignItems: 'center', flexDirection: 'row' }}>
                                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, flex: 1, fontWeight: 'bold', fontSize: 16 }}>{t('deposit_normal')}</Text>
                                <Text style={{ color: styles.BUTTON__PRIMARY, fontWeight: 'bold', fontSize: 16 }}>{t('deposit_select')}</Text>
                                <IconBack style={{ color: styles.ICON__PRIMARY }} />
                            </View>
                        </TouchableOpacity>
                    </View>
                    <View style={{ height: 64 }} />
                </ScrollView>
            </Content>
        </Container>
    )
}

const UI = StyleSheet.create({
    container: {
        paddingHorizontal: dimensions.halfIndent,
    },
    content: {
        borderBottomWidth: 1,
        fontSize: 15,
        fontWeight: 'bold',
        paddingTop: dimensions.moderate(4),
    },
    icon: {
        alignSelf: 'center',
        height: 20,
        marginLeft: dimensions.moderate(8),
        marginTop: dimensions.moderate(8),
        width: 20,
    },
    logo: {
        height: 50,
        resizeMode: 'contain',
        width: dimensions.WIDTH * 0.2,
    },
    logoBox: {
        alignItems: 'center',
        backgroundColor: 'white',
        borderRadius: 15,
        borderWidth: 3,
        flexDirection: 'row',
        height: 60,
        justifyContent: 'center',
        width: dimensions.WIDTH * 0.25,
    },
    qrFooter: {
        alignSelf: 'center',
        fontSize: 15,
        fontWeight: 'bold',
        paddingTop: dimensions.moderate(8),
    },
    qrTitle: {
        alignSelf: 'center',
        flexDirection: 'row',
        paddingVertical: dimensions.moderate(5),
    },
    qrcode: {
        alignSelf: 'center',
        borderRadius: 18,
        marginVertical: dimensions.moderate(12),
        padding: dimensions.moderate(12),
    },
    qrcodeInner: {
        alignSelf: 'center',
        borderRadius: 15,
        paddingHorizontal: dimensions.moderate(16),
        width: '100%',
    },
    title: {
        fontSize: 15,
        paddingLeft: dimensions.moderate(24),
    },
    wrap: {
        paddingHorizontal: dimensions.halfIndent,
        paddingTop: dimensions.moderate(16),
    },
    wrapContent: {
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
    wrapLogo: {
        justifyContent: 'space-around',
    },
})
