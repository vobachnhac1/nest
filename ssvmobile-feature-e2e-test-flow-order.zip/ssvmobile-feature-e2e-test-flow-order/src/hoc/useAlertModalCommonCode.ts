import React, { useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { useNavigation } from '@react-navigation/native'

import { StoreContext } from '../store'
import { alertType, eventList, glb_sv, Screens } from '../utils'

/**
 * Hàm có tác dụng: gọi otp khi có error
 *
 */

interface IUseAlertModalCommonCodeOptions {
    icon?: React.ReactNode
    title?: string
    content?: string
    typeColor?: string
    callback?: (...arg: any[]) => void
    continueVerify?: boolean
}

const useAlertModalCommonCode = (message: IServiceRespone, { icon, title, content, typeColor, callback, continueVerify }: IUseAlertModalCommonCodeOptions) => {
    if (!continueVerify) return { hasAlertCommonCode: false }
    //-------
    if (message.Code == 'XXXXX5' || message.Code === '080063' || message.Code === '010012') {
        glb_sv.commonEvent.next({
            type: eventList.SHOW_ALERT,
            alerType: alertType.COMMON_ERR_CODE,
            icon,
            title,
            content,
            typeColor,
            callback,
        })
        return { hasAlertCommonCode: true }
    }
    return { hasAlertCommonCode: false }
}

export default useAlertModalCommonCode
