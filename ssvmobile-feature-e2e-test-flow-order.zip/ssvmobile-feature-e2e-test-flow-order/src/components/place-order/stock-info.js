import React, { memo, useContext, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Pressable, StyleSheet, TouchableOpacity, View } from 'react-native'
import { Row } from 'native-base'

import { SwitchSelector, Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { dimensions, fontSizes, fontWeights, IconSvg } from '../../styles'
import { FormatNumber, FormatNumberAC, glb_sv } from '../../utils'
import { IntraPrice } from '../stock-info'
import { RowBuySell } from '../stock-info/list-buy-sell'

const maxCallback = (max, cur) => Math.max(max, cur.t1321, cur.t1331)

const StockInfo = ({ stock, handleChangePrice, isAlwaysExpand = true, isEditOrder, isOddlot, changeTypeLot = () => null }) => {
    const { styles, fractionPrice, fractionQty, fractionPriceOrder } = useContext(StoreContext)
    const { t } = useTranslation()
    const bid_ask_ratio = useRef({ bid: 0, ask: 0 })
    const widthRef = useRef((dimensions.WIDTH - dimensions.moderate(16) * 2) / 2)

    const [showStockInfo, setShowStockInfo] = useState(isAlwaysExpand)

    const [, forceUpdate] = useState({})

    const options = useRef([
        { label: t('even_lot'), value: false },
        { label: t('odd_lot'), value: true },
    ])

    useEffect(() => {
        if (isOddlot) {
            const t1321 = (stock.t1321_1_PO || 0) + (stock.t1321_2_PO || 0) + (stock.t1321_3_PO || 0)
            const t1331 = (stock.t1331_1_PO || 0) + (stock.t1331_2_PO || 0) + (stock.t1331_3_PO || 0)
            if (t1321 + t1331 === 0) {
                widthRef.current = (dimensions.WIDTH - dimensions.moderate(16) * 2) / 2
                bid_ask_ratio.current = {
                    bid: 0,
                    ask: 0,
                }
                forceUpdate({})
                return
            }
            bid_ask_ratio.current = {
                bid: Math.round((t1321 / (t1321 + t1331)) * 10000) / 100,
                ask: Math.round((t1331 / (t1321 + t1331)) * 10000) / 100,
            }
            if (widthRef.current !== (dimensions.WIDTH - dimensions.moderate(16) * 2) * (t1321 / (t1321 + t1331))) {
                widthRef.current = (dimensions.WIDTH - dimensions.moderate(16) * 2) * (t1321 / (t1321 + t1331))
            }
        } else {
            const t1321 = (stock.t1321_1 || 0) + (stock.t1321_2 || 0) + (stock.t1321_3 || 0)
            const t1331 = (stock.t1331_1 || 0) + (stock.t1331_2 || 0) + (stock.t1331_3 || 0)
            if (t1321 + t1331 === 0) {
                widthRef.current = (dimensions.WIDTH - dimensions.moderate(16) * 2) / 2
                bid_ask_ratio.current = {
                    bid: 0,
                    ask: 0,
                }
                forceUpdate({})
                return
            }
            bid_ask_ratio.current = {
                bid: Math.round((t1321 / (t1321 + t1331)) * 10000) / 100,
                ask: Math.round((t1331 / (t1321 + t1331)) * 10000) / 100,
            }
            if (widthRef.current !== (dimensions.WIDTH - dimensions.moderate(16) * 2) * (t1321 / (t1321 + t1331))) {
                widthRef.current = (dimensions.WIDTH - dimensions.moderate(16) * 2) * (t1321 / (t1321 + t1331))
            }
        }
        forceUpdate({})
    }, [stock, isOddlot])

    return (
        <View
            style={{
                backgroundColor: styles.PRIMARY__BG__COLOR,
                shadowColor: styles.BUTTON__SECONDARY,
                shadowOffset: {
                    width: 6,
                    height: 6,
                },
                shadowOpacity: 0.67,
                shadowRadius: 7.49,
                elevation: 18,
            }}
        >
            <View style={{ paddingHorizontal: dimensions.moderate(16), flexDirection: 'row', alignItems: 'center' }}>
                <Row style={{ alignItems: 'center' }} onPress={() => handleChangePrice((isOddlot ? stock.t31_PO : stock.t31) || stock.t260, 'buy')}>
                    <IntraPrice
                        change={
                            fractionPriceOrder
                                ? FormatNumber((isOddlot ? stock.t31_incr_PO : stock.t31_incr) / 1000, 2)
                                : FormatNumber(isOddlot ? stock.t31_incr_PO : stock.t31_incr)
                        }
                        indexValueChang={isOddlot ? stock.t31_incr_per_PO : stock.t31_incr_per}
                        isPlaceOrder={true}
                        price={
                            fractionPriceOrder
                                ? FormatNumber(((isOddlot ? stock.t31_PO : stock.t31) || stock.t260) / 1000, 2)
                                : FormatNumber((isOddlot ? stock.t31_PO : stock.t31) || stock.t260)
                        }
                        ratio={FormatNumber(isOddlot ? stock.t31_incr_per_PO : stock.t31_incr_per, 2)}
                        status={glb_sv.getColor((isOddlot ? stock.t31_PO : stock.t31) || stock.t260, stock, styles)}
                    />
                </Row>

                <View>
                    <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.smallest }}>{t('volume')}</Text>
                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.smallest }}>
                        {isOddlot
                            ? stock.t391_PO
                                ? fractionQty
                                    ? FormatNumberAC(stock.t391_PO, 0, 1)
                                    : FormatNumber(stock.t391_PO, 0, 0, 'short')
                                : '---'
                            : stock.t391
                            ? fractionQty
                                ? FormatNumberAC(stock.t391, 0, 1)
                                : FormatNumber(stock.t391, 0, 0, 'short')
                            : '---'}
                    </Text>
                </View>
                <TouchableOpacity style={{ marginLeft: 5 }} onPress={() => handleChangePrice(stock.U29 || stock.t332, 'buy')}>
                    <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.smallest }}>{t('ceiling')}</Text>
                    <Text style={{ color: styles.CEIL__COLOR, fontSize: fontSizes.smallest }}>
                        {stock.t332 ? (fractionPriceOrder ? FormatNumber((stock.U29 || stock.t332) / 1000, 2) : FormatNumber(stock.U29 || stock.t332)) : '---'}
                    </Text>
                </TouchableOpacity>
                <TouchableOpacity style={{ marginLeft: 5 }} onPress={() => handleChangePrice(stock.U31 || stock.t260, 'buy')}>
                    <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.smallest }}>{t('reference')}</Text>
                    <Text style={{ color: styles.REF__COLOR, fontSize: fontSizes.smallest }}>
                        {stock.t260 ? (fractionPriceOrder ? FormatNumber((stock.U31 || stock.t260) / 1000, 2) : FormatNumber(stock.U31 || stock.t260)) : '---'}
                    </Text>
                </TouchableOpacity>
                <TouchableOpacity style={{ marginLeft: 5 }} onPress={() => handleChangePrice(stock.U30 || stock.t333, 'buy')}>
                    <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.smallest }}>{t('floor')}</Text>
                    <Text style={{ color: styles.FLOOR__COLOR, fontSize: fontSizes.smallest }}>
                        {stock.t333 ? (fractionPriceOrder ? FormatNumber((stock.U30 || stock.t333) / 1000, 2) : FormatNumber(stock.U30 || stock.t333)) : '---'}
                    </Text>
                </TouchableOpacity>
            </View>
            {glb_sv.configInfo.application_style.is_oddlot_info_order ? (
                <SwitchSelector
                    borderColor={styles.DIVIDER__COLOR}
                    borderRadius={4}
                    buttonColor={styles.DIVIDER__COLOR}
                    hasPadding
                    initial={0}
                    options={options.current}
                    backgroundColor={styles.PRIMARY__BG__COLOR}
                    // textContainerStyle={{ borderRadius: 4 }}
                    // selectedTextContainerStyle={{ borderRadius: 4 }}
                    selectedColor={styles.PRIMARY}
                    selectedTextStyle={{ fontWeight: fontWeights.bold }}
                    style={{ paddingHorizontal: dimensions.moderate(16), marginBottom: 8 }}
                    textColor={styles.PRIMARY__CONTENT__COLOR}
                    onPress={(value) => changeTypeLot(value)}
                />
            ) : null}

            {isEditOrder ? null : (
                <View style={{ display: showStockInfo ? 'flex' : 'none' }}>
                    <View style={{ paddingHorizontal: dimensions.moderate(16) }}>
                        {(isOddlot ? stock.PO : stock.TP).slice(0, 3).map((item, i) => (
                            <RowBuySell
                                color_t132={glb_sv.getColor(item.t132, stock, styles)}
                                color_t133={glb_sv.getColor(item.t133, stock, styles)}
                                handleChangePrice={handleChangePrice}
                                index={i + 1}
                                key={`BuySell__Row__${i}`}
                                t132={item.t132}
                                t1321={item.t1321}
                                t133={item.t133}
                                t1331={item.t1331}
                                total={(isOddlot ? stock.PO : stock.TP).reduce(maxCallback, -Infinity)}
                            />
                        ))}
                    </View>

                    <Row style={{ justifyContent: 'space-between', paddingHorizontal: dimensions.moderate(16), alignItems: 'center' }}>
                        <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.verySmall }}>{t('priceboard_bid_short')}</Text>
                        <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.verySmall }}>{t('priceboard_over_sell_quantity')}</Text>
                    </Row>
                    <Row
                        style={{
                            height: 14,
                            backgroundColor: styles.DOWN__COLOR,
                            marginHorizontal: dimensions.moderate(16),
                            borderRadius: 4,
                            alignItems: 'center',
                        }}
                    >
                        <View
                            style={{
                                width: widthRef.current,
                                height: 14,
                                zIndex: 10,
                                backgroundColor: styles.UP__COLOR,
                                borderTopLeftRadius: 4,
                                borderBottomLeftRadius: 4,
                            }}
                        />
                        <Text
                            style={{
                                color: 'white',
                                fontSize: 11,
                                fontWeight: fontWeights.semiBold,
                                position: 'absolute',
                                left: dimensions.halfIndent,
                                zIndex: 10,
                            }}
                        >
                            {bid_ask_ratio.current.bid ? bid_ask_ratio.current.bid + '%' : ''}
                        </Text>
                        <Text
                            style={{
                                color: 'white',
                                fontSize: 11,
                                fontWeight: fontWeights.semiBold,
                                position: 'absolute',
                                right: dimensions.halfIndent,
                                zIndex: 10,
                            }}
                        >
                            {bid_ask_ratio.current.ask ? bid_ask_ratio.current.ask + '%' : ''}
                        </Text>
                    </Row>
                </View>
            )}

            {!isEditOrder && (
                <View
                    style={{
                        height: 3,
                        backgroundColor: styles.BUTTON__SECONDARY,
                        top: 10,
                    }}
                />
            )}

            {isAlwaysExpand && isEditOrder ? (
                <View style={{ paddingBottom: 12 }} />
            ) : (
                <Row style={{ justifyContent: 'center' }}>
                    <TouchableOpacity activeOpacity={1} onPress={() => setShowStockInfo((value) => !value)}>
                        <IconSvg.CaretUpIcon color1={styles.BUTTON__SECONDARY} color2={styles.PRIMARY__CONTENT__COLOR} show={showStockInfo} size={24} />
                    </TouchableOpacity>
                </Row>
            )}
        </View>
    )
}

export default memo(StockInfo)
