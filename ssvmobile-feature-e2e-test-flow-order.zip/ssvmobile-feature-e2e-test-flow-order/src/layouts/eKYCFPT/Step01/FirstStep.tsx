/**
 * STEP 1: ĐĂNG KÝ THÔNG TIN/ REGISTER INFOMATION
 * Bao gồm nhập số điện thoại, email và thông tin người giới thiệu
 */

import React from 'react'
import { Dimensions, ScrollView, StyleSheet, View } from 'react-native'
import { TouchableOpacity } from 'react-native-gesture-handler'

import { CustomFloatInput, Text } from '../../../basic-components'
import { dimensions, dimensions as dm, fontSizes as fs, fontWeights as fw } from '../../../styles'
import EkycButton from '../components/EkycButton'
import { FATCAInfomation } from '../components/FATCAInfomation'
import { MarginCheckRow } from '../components/MarginCheckRow'
import { configUIEkyc } from '../config'
import ekycService from '../ekycService'

const { height } = Dimensions.get('window')
export const FirstStep = ({
    styles,
    t,
    customerPhone,
    hintCommonEmail,
    customerEmail,
    setHintCommonEmail,
    setCustomerEmail,
    onChangeFATCA,
    checkAndSaveDataBeforeStep02,
    onChangeCheckMargin,
    checkMargin,
    isHasPrevStep,
}) => {
    return (
        <>
            <ScrollView>
                <View>
                    <Text style={[UI.subTitle, { color: styles.PRIMARY }]}>{t('ekyc_title_1_register_info').toUpperCase()}</Text>
                </View>
                <View>
                    <View style={UI.RowInput}>
                        <CustomFloatInput
                            editable={false}
                            keyboardType="numeric"
                            label={t('phone')}
                            placeholderTextColor={styles.PLACEHODLER__COLOR}
                            staticLabel
                            value={customerPhone}
                        />
                    </View>
                    <View style={UI.RowInput}>
                        <CustomFloatInput
                            autoCapitalize="none"
                            keyboardType="email-address"
                            label={t('email')}
                            placeholderTextColor={styles.PLACEHODLER__COLOR}
                            staticLabel
                            value={customerEmail}
                            onBlur={() => {
                                setTimeout(() => {
                                    setHintCommonEmail(false)
                                }, 100)
                            }}
                            onChangeText={(email) => setCustomerEmail(email?.trim())}
                            onFocus={() => {
                                setHintCommonEmail(true)
                            }}
                        />
                        {hintCommonEmail ? (
                            <View style={{ flex: 1, justifyContent: 'flex-end', flexDirection: 'row', paddingTop: 8 }}>
                                <TouchableOpacity onPress={() => setCustomerEmail(`${customerEmail}@gmail.com`)}>
                                    <View
                                        style={{ paddingHorizontal: 8, paddingVertical: 4, borderRadius: 4, marginLeft: 8, backgroundColor: styles.INPUT__BG }}
                                    >
                                        <Text style={{ color: styles.PRIMARY__CONTENT__COLOR }}>@gmail.com</Text>
                                    </View>
                                </TouchableOpacity>
                                <TouchableOpacity onPress={() => setCustomerEmail(`${customerEmail}@icloud.com`)}>
                                    <View
                                        style={{ paddingHorizontal: 8, paddingVertical: 4, borderRadius: 4, marginLeft: 8, backgroundColor: styles.INPUT__BG }}
                                    >
                                        <Text style={{ color: styles.PRIMARY__CONTENT__COLOR }}>@icloud.com</Text>
                                    </View>
                                </TouchableOpacity>
                                <TouchableOpacity onPress={() => setCustomerEmail(`${customerEmail}@yahoo.com`)}>
                                    <View
                                        style={{ paddingHorizontal: 8, paddingVertical: 4, borderRadius: 4, marginLeft: 8, backgroundColor: styles.INPUT__BG }}
                                    >
                                        <Text style={{ color: styles.PRIMARY__CONTENT__COLOR }}>@yahoo.com</Text>
                                    </View>
                                </TouchableOpacity>
                            </View>
                        ) : null}
                    </View>
                    {configUIEkyc.margin_check ? <MarginCheckRow checkMargin={checkMargin} setCheckMargin={onChangeCheckMargin} /> : null}
                    {configUIEkyc.is_FATCA ? (
                        <FATCAInfomation checkFATCA={ekycService.additionalData.checkFATCA ? '0' : '2'} setCheckFATCA={onChangeFATCA} />
                    ) : null}
                </View>
            </ScrollView>
            <EkycButton customStyle={{ marginBottom: 24 }} text={t('common_button_next')} onPress={checkAndSaveDataBeforeStep02} />
        </>
    )
}

const UI = StyleSheet.create({
    RowInput: {
        marginBottom: dm.vertical(16),
        marginHorizontal: dimensions.moderate(16),
    },
    buttonError: {
        backgroundColor: 'red',
        borderRadius: 50,
        flex: 0,
        height: dm.moderate(24),
        justifyContent: 'center',
        marginLeft: 6,
        marginRight: 2,
        marginVertical: dm.vertical(4),
        width: dm.moderate(24),
    },
    circle_style: {
        alignSelf: 'center',
        borderRadius: 10 / 2,
        height: 10,
        width: 10,
    },
    container: {
        alignContent: 'flex-start',
        flex: 1,
        justifyContent: 'flex-start',
    },
    image: {
        alignContent: 'flex-start',
        alignItems: 'center',
        height: 80,
        justifyContent: 'flex-start',
        marginVertical: 10,
    },
    modal: {
        justifyContent: 'flex-end',
        margin: 0,
    },
    row: {
        alignItems: 'center',
        borderRadius: 12,
        flexDirection: 'row',
        marginHorizontal: dm.moderate(16),
        marginTop: dm.vertical(12),
    },
    rowNote: {
        alignItems: 'center',
        borderRadius: 12,
        flexDirection: 'row',
        marginHorizontal: dm.moderate(8),
        marginTop: dm.vertical(12),
    },
    subTitle: { fontSize: fs.xmedium, fontWeight: fw.bold, marginBottom: 16, textAlign: 'center' },
    textArea: {
        color: 'white', //styles.PRIMARY__CONTENT__COLOR,
        fontSize: fs.small,
        fontWeight: fw.medium,
        textAlign: 'center',
    },
})
