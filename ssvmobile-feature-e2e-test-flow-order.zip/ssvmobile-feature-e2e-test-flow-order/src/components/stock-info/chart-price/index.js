import React from 'react'
import { useTranslation } from 'react-i18next'
import { View } from 'react-native'
import { WebView } from 'react-native-webview'

import { Text } from '../../../basic-components'
import { StoreContext } from '../../../store'
import { dimensions } from '../../../styles'
import { glb_sv } from '../../../utils'
import Chart from '../../f2-chart'

const PieChartPrice = ({ stock }) => {
    if (!stock.t260 || !stock.EP.length) return <View />
    const { styles } = React.useContext(StoreContext)
    const { t } = useTranslation()
    const totalQty = stock.EP.reduce((acc, curr) => {
        return acc + curr.volume
    }, 0)
    const arr = stock.EP.reduce((acc, curr) => {
        if (!acc.length) {
            acc.push({
                qty: curr.volume,
                price: curr.indexValue,
                const: 'const',
                ratio: curr.volume / totalQty,
            })
        } else {
            const dupPrice = acc.find((e) => e.price === curr.indexValue)
            if (dupPrice) {
                dupPrice.qty += curr.volume
                dupPrice.ratio = curr.volume / totalQty
            } else {
                acc.push({
                    qty: curr.volume,
                    price: curr.indexValue,
                    const: 'const',
                    ratio: curr.volume / totalQty,
                })
            }
        }
        return acc
    }, [])

    arr.forEach((element) => {
        element.ratio = Math.round((element.qty / totalQty) * 100) / 100
        element.price += ''
    })
    const data = arr.filter((e) => e.ratio > 0.01)

    const otherArr = arr.filter((e) => e.ratio <= 0.01)
    const otherObj = {
        price: 'Other',
        qty: otherArr.reduce((acc, curr) => {
            return acc + curr.qty
        }, 0),
        ratio: otherArr.reduce((acc, curr) => {
            return acc + curr.ratio
        }, 0),
        const: 'const',
    }
    data.push(otherObj)

    const colorMap = data.reduce((acc, curr) => {
        acc[curr.price] = glb_sv.getColor(curr.price * 1, stock, styles) || styles.PRIMARY
        return acc
    }, {})

    return (
        <View>
            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, marginTop: dimensions.halfIndent, marginLeft: dimensions.halfIndent }}>
                {t('chart_rate_match_today')}
            </Text>
            <View style={{ height: 350, backgroundColor: styles.PRIMARY__BG__COLOR }}>
                <Chart data={data} initScript={labelPie(data, colorMap)} webView={WebView} />
            </View>
            <View style={{ height: 20 }} />
        </View>
    )
}

export default PieChartPrice

const labelPie = (data, colorMap) => `
(function(){
  setTimeout(() => {
window.chart = new F2.Chart({
  id: 'chart',
  pixelRatio: window.devicePixelRatio
});

const DATA = ${JSON.stringify(data)}

chart.source(DATA);
chart.coord('polar', {
  transposed: true,
  innerRadius: 0.4,
  radius: 0.75
});

chart.axis(false);
chart.legend({
  position: 'bottom',
  align: 'center'
});
chart.tooltip(false);
chart.guide().html({
  position: ['50%', '50%'],
  html: '<div style="width: 100px;height: 20px;text-align: center;line-height: 20px;" id="textContent"></div>'
});
chart.pieLabel({
  activeShape: true,
  sidePadding: 35,
  label2OffsetY: 2,
  label1OffsetY: -2,
  label1: function label1(data) {
    return {
      text: data.price === 'Other' ? data.price : formatNumber(data.price*1),
      fill: '#808080'
    };
  },
  label2: function label2(data) {
    return {
      fill: '#808080',
      text: data.ratio*100 + '%',
      fontWeight: 500,
      fontSize: 10
    };
  }
});
chart.interval().position('const*ratio').color('price', ['#1890FF', '#13C2C2', '#2FC25B', '#FACC14', '#F04864', '#8543E0', '#3436C7', '#223273']).adjust('stack');
chart.render();

const frontPlot = chart.get('frontPlot');
const coord = chart.get('coord'); // 获取坐标系对象
frontPlot.addShape('sector', {
  attrs: {
    x: coord.center.x,
    y: coord.center.y,
    r: coord.circleRadius * coord.innerRadius * 1.2, // 全半径
    r0: coord.circleRadius * coord.innerRadius,
    fill: '#808080',
    opacity: 0.15
  }
});
chart.get('canvas').draw();
},1000);
true
})();
`
