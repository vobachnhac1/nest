import React, { useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { StyleSheet } from 'react-native'
import AntDesign from 'react-native-vector-icons/AntDesign'
import moment from 'moment'
import { Col, Row, View } from 'native-base'

import { Text } from '../../../../basic-components'
import { StoreContext } from '../../../../store'
import { dimensions as dm, fontSizes as fs, fontWeights as fw } from '../../../../styles'
import { glb_sv } from '../../../../utils'

export const RowBankInfo = ({
    onPress = () => {},
    bankName, // Nội dung header
    bankAccountNumber,
    iconRight = null, // Right Component
    onDeleteBankInfo = () => null,
    onEditBankInfo = () => null,
    item,
    setModalData,
    ...props
}) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()

    return (
        // @ts-expect-error
        <Row style={[UI.BankInfoRowView, { backgroundColor: styles.INPUT__BG }]} onPress={onPress}>
            <Col size={20}>
                <View style={{ flexDirection: 'row' }}>
                    <Text numberOfLines={1} style={{ fontWeight: fw.bold, fontSize: fs.normal, color: styles.PRIMARY__CONTENT__COLOR }}>
                        {bankName}{' '}
                    </Text>
                </View>
                <Text style={{ fontSize: fs.small, color: styles.SECOND__CONTENT__COLOR }}>{bankAccountNumber}</Text>
            </Col>
            <Col size={4} style={UI.WrapIcon}>
                {/* <View>
                    <AntDesign onPress={() => onEditBankInfo(item)} AntDesign name="edit" color={styles.ICON__PRIMARY} size={24} style={UI.Icon} />
                </View> */}
                <View>
                    <AntDesign AntDesign color={styles.ERROR__COLOR} name="delete" size={24} style={UI.Icon} onPress={() => onDeleteBankInfo(item)} />
                </View>
            </Col>
        </Row>
    )
}

const UI = StyleSheet.create({
    BankInfoRowView: {
        borderRadius: 8,
        flex: 1,
        marginHorizontal: dm.moderate(16),
        marginVertical: dm.moderate(4),
        paddingVertical: dm.moderate(4),
        // justifyContent: 'flex-start'
    },
    Icon: { paddingLeft: 12, paddingRight: 4, paddingVertical: 8 },
    WrapIcon: { alignItems: 'flex-end', flexDirection: 'row', justifyContent: 'center', paddingLeft: 8 },
})
