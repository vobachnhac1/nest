import React, { memo, useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { StyleSheet, TouchableOpacity, View } from 'react-native'
import Modal from 'react-native-modal'

import { Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { dimensions, fontSizes, fontWeights, IconSvg } from '../../styles'

function ModalChangeSeasontp({ visible, setVisible, list, handleChangeSessontp, seasonTp }) {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()

    return (
        <Modal
            isVisible={visible}
            style={UI.modal}
            useNativeDriver={true}
            onBackButtonPress={() => setVisible(false)}
            onBackdropPress={() => setVisible(false)}
        >
            <View
                style={{
                    backgroundColor: styles.PRIMARY__BG__COLOR,
                    padding: dimensions.moderate(24),
                    justifyContent: 'flex-start',
                    borderTopLeftRadius: 12,
                    borderTopRightRadius: 12,
                }}
            >
                <Text
                    style={{
                        marginBottom: dimensions.vertical(24),
                        fontSize: fontSizes.xmedium,
                        color: styles.PRIMARY__CONTENT__COLOR,
                        fontWeight: fontWeights.semiBold,
                    }}
                >
                    {t('choose_sesson_tp')}
                </Text>

                {list.map((item) => (
                    <TouchableOpacity
                        key={item.key}
                        style={UI.row}
                        onPress={() => {
                            handleChangeSessontp(item.key)
                        }}
                    >
                        <IconSvg.CheckboxIcon active={seasonTp === item.key} colorActive={styles.PRIMARY} colorunActive={styles.PRIMARY__CONTENT__COLOR} />
                        <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.medium, marginLeft: dimensions.moderate(12) }}>
                            {t(item.name)}
                        </Text>
                    </TouchableOpacity>
                ))}
            </View>
        </Modal>
    )
}

export default memo(ModalChangeSeasontp, areEqual)

function areEqual(prev, next) {
    if (prev.visible === next.visible) return true
    return false
}

const UI = StyleSheet.create({
    modal: {
        justifyContent: 'flex-end',
        margin: 0,
    },
    row: {
        alignItems: 'center',
        flexDirection: 'row',
        marginBottom: dimensions.vertical(12),
        padding: dimensions.moderate(7),
    },
})
