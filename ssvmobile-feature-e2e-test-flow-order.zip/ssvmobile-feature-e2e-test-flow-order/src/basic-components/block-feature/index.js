import React, { memo, useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { Image, Platform, StyleSheet, TouchableOpacity, View } from 'react-native'
import { useNavigation } from '@react-navigation/native'

import { StoreContext } from '../../store'
import { StoreTrading } from '../../store-trading'
import { dimensions, fontSizes } from '../../styles'
import { glb_sv, Screens } from '../../utils'
import { openAccountPopupNotification } from '../open_account_notification'
import Text from '../Text'

const IOS = Platform.OS === 'ios' ? true : false

const BlockFeature = (props) => {
    const { item = {} } = props
    const { styles, imageTheme, theme, applicationSettings } = useContext(StoreContext)
    const { userInfo } = useContext(StoreTrading)
    const { t } = useTranslation()
    const navigation = useNavigation()
    const { popupDontFinishEKYC, popupWaitingSSVSignContract, econtractWillSendLater } = openAccountPopupNotification()

    //-------------------------------
    const onSelectFeature = () => {
        // if (glb_sv.objShareGlb.userInfo.c9 === 'N' && item.needHaveAccount !== false) {
        //     popupDontFinishEKYC()
        //     return
        // } else if (glb_sv.objShareGlb.userInfo.c26 === 'N' && item.needHaveAccount !== false) {
        //     popupWaitingSSVSignContract()
        //     return
        // } else if (glb_sv.objShareGlb.userInfo.c27 === 'N' && item.needHaveAccount !== false) {
        //     econtractWillSendLater()
        //     return
        // } else if (item.screen) {
        //     navigation.navigate(item.screen, {})
        // } else if (item.link) {
        //     navigation.navigate(Screens.NEWS_DETAIL, { title: t(item.title), link: item.link })
        // }
        if (glb_sv.objShareGlb.userInfo.c9 === 'N' && item.needHaveAccount !== false) {
            popupDontFinishEKYC()
            return
        } else if (item.screen) {
            navigation.navigate(item.screen, {})
        } else if (item.link) {
            navigation.navigate(Screens.NEWS_DETAIL, { title: t(item.title), link: item.link })
        }
    }

    const getIconByTheme = (imageSrc, theme) => {
        if (typeof imageSrc === 'object') {
            return imageSrc[theme]
        } else {
            return imageSrc
        }
    }

    const getCircleWrapperColor = (imageSrc, theme) => {
        if (typeof imageSrc === 'object' && typeof imageSrc.WRAP_COLOR === 'object') {
            return imageSrc.WRAP_COLOR[theme]
        } else {
            return styles.PRIMARY__BG__COLOR
        }
    }
    const checkIsObjectImage = (object) => {
        if (object?.DARK) return true
        return false
    }

    const renderIcon = () => {
        if (typeof imageTheme[item.icon] !== 'number' && typeof imageTheme[item.icon] !== 'function') {
            const isObjectImage = checkIsObjectImage(imageTheme[item.icon])
            if (isObjectImage) {
                return (
                    <View style={{ backgroundColor: getCircleWrapperColor(imageTheme[item.icon], theme), padding: 10, borderRadius: 100 }}>
                        <Image
                            source={getIconByTheme(imageTheme[item.icon], theme)}
                            style={{
                                width: 24,
                                height: 24,
                                // tintColor: styles.PRIMARY__CONTENT__COLOR,
                                resizeMode: 'contain',
                            }}
                        />
                    </View>
                )
            }
            return imageTheme[item.icon]
        } else {
            return (
                <View style={{ backgroundColor: getCircleWrapperColor(imageTheme[item.icon], theme), padding: 10, borderRadius: 100 }}>
                    <Image
                        source={getIconByTheme(imageTheme[item.icon], theme)}
                        style={{
                            width: 24,
                            height: 24,
                            // tintColor: styles.PRIMARY__CONTENT__COLOR,
                            resizeMode: 'contain',
                        }}
                    />
                </View>
            )
        }
    }

    const isDisableIcon = () => {
        if (item.needHaveAccount === false) {
            return false
        }
        return glb_sv.objShareGlb.userInfo.c26 === 'Y' || glb_sv.objShareGlb.userInfo.c27 === 'Y'
    }

    if (item?.accList) {
        const accList = item?.accList?.map((item) => String(item).toLocaleLowerCase()) || []
        // console.log("accList", item, accList, userInfo.actn_curr, accList.includes(userInfo.actn_curr?.toLocaleLowerCase()));
        return accList.includes(userInfo.actn_curr?.toLocaleLowerCase()) ? (
            <TouchableOpacity style={UI.BlockFeature} onPress={onSelectFeature}>
                <View style={{ textAlign: 'center', alignItems: 'center' }}>
                    <View>{renderIcon()}</View>
                    <Text
                        style={{
                            color: styles.PRIMARY__CONTENT__COLOR,
                            textAlign: 'center',
                            paddingTop: 8,
                            fontSize: applicationSettings.application_style.grid_column === 3 ? fontSizes.small : fontSizes.verySmall,
                        }}
                    >
                        {t(item.title)}
                    </Text>
                </View>
            </TouchableOpacity>
        ) : null
    } else {
        return (
            <TouchableOpacity disabled={isDisableIcon()} style={UI.BlockFeature} onPress={onSelectFeature}>
                <View style={{ textAlign: 'center', alignItems: 'center', opacity: isDisableIcon() ? 0.5 : 1 }}>
                    <View>{renderIcon()}</View>
                    <Text
                        style={{
                            color: styles.PRIMARY__CONTENT__COLOR,
                            textAlign: 'center',
                            paddingTop: 8,
                            fontSize: applicationSettings.application_style.grid_column === 3 ? fontSizes.small : fontSizes.verySmall,
                        }}
                    >
                        {t(item.title)}
                    </Text>
                </View>
            </TouchableOpacity>
        )
    }
}
const UI = StyleSheet.create({
    BlockFeature: {
        alignItems: 'center',
        flex: 1,
        flexDirection: 'column',
        height: 120,
        paddingHorizontal: dimensions.moderate(8),
        paddingVertical: dimensions.vertical(8),
    },
})

export default memo(BlockFeature)
