import React, { memo, useContext } from 'react'
import { StyleSheet } from 'react-native'
import Orientation from 'react-native-orientation-locker'
import Svg, { Path, Rect } from 'react-native-svg'
import { Button, Row, View } from 'native-base'

import { Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { dimensions, fontSizes, fontWeights } from '../../styles'
import { glb_sv, Screens } from '../../utils'

const listSelect = [
    {
        name: '1D',
        value: '1D',
    },
    {
        name: '1W',
        value: '1W',
    },
    {
        name: '1M',
        value: '1M',
    },
    {
        name: '3M',
        value: '3M',
    },
    {
        name: '6M',
        value: '6M',
    },
    {
        name: '1Y',
        value: '1Y',
    },
    {
        name: '5Y',
        value: '5Y',
    },
    {
        name: 'Max',
        value: 'MAX',
    },
]

const TimeSelect = ({ time = '1D', typeChart = 'LINE', changeTypeChart, changeTime, navigation, indexCode }) => {
    const { styles } = useContext(StoreContext)

    function setActiveButton(value) {
        if (time !== value) changeTime(value)
    }

    const changeChart = () => {
        if (time === '1D') return
        if (typeChart === 'LINE') changeTypeChart('CANDLE')
        else if (typeChart === 'CANDLE') changeTypeChart('LINE')
    }

    const changeTradingview = () => {
        Orientation.lockToLandscapeRight()
        const key = indexCode
        navigation.navigate(Screens.TRADING_VIEW, {
            screen: Screens.DRAW_STACK,
            params: { key, type: glb_sv.IndexMarket[key] ? 'INDEX' : 'STOCK' },
        })
    }

    return (
        <Row style={UI.GroupButton__Time}>
            {listSelect.map((btn, index) => (
                <Button
                    key={`timeSelect__${btn.value}`}
                    style={{ ...UI.Button, backgroundColor: btn.value === time ? styles.PRIMARY : styles.BUTTON__SECONDARY }}
                    transparent
                    onPress={() => setActiveButton(btn.value)}
                >
                    <Text style={{ ...UI.Text, color: btn.value === time ? '#FFF' : styles.PRIMARY__CONTENT__COLOR }}>{btn.name}</Text>
                </Button>
            ))}
            <View style={{ width: 2, backgroundColor: styles.PRIMARY__BG__COLOR }} />
            {typeChart === 'LINE' && (
                <Button disabled={time === '1D'} style={{ ...UI.Button, backgroundColor: styles.BUTTON__SECONDARY }} transparent onPress={changeChart}>
                    <View style={{ opacity: time === '1D' ? 0.25 : 1 }}>
                        <Svg
                            fill="none"
                            height={dimensions.moderate(14)}
                            viewBox="0 0 14 14"
                            width={dimensions.moderate(14)}
                            xmlns="http://www.w3.org/2000/svg"
                        >
                            <Path
                                d="M13.845 2.207a.53.53 0 00-.75-.002L9.07 6.215 7.905 5.052a.53.53 0 00-.75 0l-4.72 4.72a.53.53 0 10.75.75L7.53 6.176 8.693 7.34a.53.53 0 00.75 0l4.4-4.383a.53.53 0 00.002-.75z"
                                fill={'#B900A3'}
                            />
                            <Path
                                d="M13.452 12.303H1.061V1.167a.53.53 0 10-1.061 0v11.666c0 .293.237.53.53.53h12.922a.53.53 0 100-1.06zM13.47 2.033H9.492a.53.53 0 100 1.06h3.447v3.448a.53.53 0 101.061 0V2.562a.53.53 0 00-.53-.53z"
                                fill={'#B900A3'}
                            />
                        </Svg>
                    </View>
                </Button>
            )}

            {typeChart === 'CANDLE' && (
                <Button
                    style={{ ...UI.Button, backgroundColor: styles.BUTTON__SECONDARY, paddingRight: 7, paddingBottom: 8 }}
                    transparent
                    onPress={changeChart}
                >
                    <Svg
                        fill={'#B900A3'}
                        height={dimensions.moderate(22)}
                        viewBox="0 0 22 22"
                        width={dimensions.moderate(22)}
                        xmlns="http://www.w3.org/2000/Svg"
                    >
                        <Path d="M17 11v6h3v-6h-3zm-.5-1h4a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-.5.5h-4a.5.5 0 0 1-.5-.5v-7a.5.5 0 0 1 .5-.5z" />
                        <Path d="M18 7h1v3.5h-1zm0 10.5h1V21h-1z" />
                        <Path d="M9 8v12h3V8H9zm-.5-1h4a.5.5 0 0 1 .5.5v13a.5.5 0 0 1-.5.5h-4a.5.5 0 0 1-.5-.5v-13a.5.5 0 0 1 .5-.5z" />
                        <Path d="M10 4h1v3.5h-1zm0 16.5h1V24h-1z" />
                    </Svg>
                </Button>
            )}

            {/* <Button
                transparent
                onPress={changeTradingview}
                style={{ ...UI.Button, backgroundColor: styles.BUTTON__SECONDARY, paddingRight: 2, paddingBottom: 8 }}>
                <Svg
                    width={dimensions.moderate(19)}
                    height={dimensions.moderate(19)}
                    viewBox="0 0 18 19"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                >
                    <Rect
                        x={2.009}
                        y={5.983}
                        width={7.556}
                        height={14.556}
                        rx={0.55}
                        transform="rotate(-35 2.009 5.983)"
                        stroke="#196EEE"
                    />
                    <Path
                        d="M3.734 5.25l3.185-2.23.276.394a.296.296 0 01-.072.412l-2.7 1.891a.296.296 0 01-.413-.073l-.276-.394zM6.313 16.992a.028.028 0 00-.001-.046l-.216-.134v-.002h-.004l-.534-.33a.028.028 0 00-.042.023v.263a3.99 3.99 0 01-.156-.025c-1.774-.331-3.165-1.807-3.449-3.666a4.614 4.614 0 01-.02-.156l.257.002a.028.028 0 00.023-.043l-.505-.787a.028.028 0 00-.047.001l-.45.783a.027.027 0 00.025.041l.325.002.02.155c.29 2.072 1.842 3.718 3.819 4.057.051.009.103.017.155.024l-.001.34c0 .021.025.035.043.022l.595-.411.163-.113z"
                        fill="#196EEE"
                    />
                    <Path
                        fillRule="evenodd"
                        clipRule="evenodd"
                        d="M6.401 17.12l-.122.085-.069.047-.566.392a.183.183 0 01-.288-.152l.001-.205c-2.066-.341-3.684-2.06-3.975-4.214l-.19-.001a.183.183 0 01-.157-.274l.3-.523.086-.15.063-.11a.183.183 0 01.313-.008l.505.787a.183.183 0 01-.155.282h-.078c.28 1.776 1.606 3.18 3.291 3.506v-.08c.001-.143.158-.23.28-.155l.497.308.115.07.142.088c.112.07.116.232.007.307zm-.09-.174c.018.01.018.034.002.046l-.163.113-.595.41a.028.028 0 01-.043-.022l.001-.34a4.67 4.67 0 01-.155-.023c-1.977-.34-3.53-1.985-3.82-4.057a5.029 5.029 0 01-.019-.155l-.325-.002a.027.027 0 01-.024-.04l.45-.784a.028.028 0 01.046 0l.505.786a.028.028 0 01-.023.043l-.258-.002c.006.053.013.104.021.156.284 1.859 1.675 3.335 3.449 3.666.051.01.103.018.155.025l.001-.263c0-.022.024-.035.042-.024l.534.33h.004v.003l.216.134z"
                        fill="#196EEE"
                    />
                    <Path
                        d="M12.19 3.689a.028.028 0 000 .046l.216.133v.003h.004l.534.33a.028.028 0 00.042-.023l.001-.264c.052.008.104.016.156.026 1.773.33 3.164 1.807 3.448 3.666.008.051.015.103.02.155h-.256a.028.028 0 00-.024.042l.505.786a.028.028 0 00.047 0l.45-.784a.028.028 0 00-.024-.04l-.326-.002a4.967 4.967 0 00-.02-.156c-.289-2.071-1.841-3.717-3.819-4.056a4.447 4.447 0 00-.155-.024l.001-.34a.028.028 0 00-.043-.022l-.595.411-.163.113z"
                        fill="#196EEE"
                    />
                    <Path
                        fillRule="evenodd"
                        clipRule="evenodd"
                        d="M12.1 3.56l.123-.084.069-.047.567-.392a.183.183 0 01.287.151l-.001.205c2.067.342 3.684 2.06 3.976 4.215h.188c.14.001.228.153.158.275l-.3.523-.085.149-.064.11a.183.183 0 01-.313.008l-.505-.787a.183.183 0 01.155-.281h.078c-.28-1.776-1.606-3.18-3.291-3.507v.08c-.001.144-.158.23-.28.155l-.497-.307-.115-.071-.141-.088a.183.183 0 01-.008-.306zm.09.175a.028.028 0 010-.046l.162-.113.595-.411a.028.028 0 01.043.022l-.001.34c.052.007.104.015.155.024 1.978.339 3.53 1.985 3.82 4.056l.019.156.326.001c.02 0 .034.023.023.042l-.449.782a.028.028 0 01-.047.001l-.505-.786a.028.028 0 01.024-.043l.257.001a4.42 4.42 0 00-.021-.155c-.284-1.86-1.675-3.335-3.448-3.666a4.064 4.064 0 00-.156-.026l-.001.264a.028.028 0 01-.042.023l-.534-.33h-.004v-.003l-.216-.133z"
                        fill="#196EEE"
                    />
                </Svg>
            </Button> */}
        </Row>
    )
}

export default memo(TimeSelect)

const UI = StyleSheet.create({
    Button: {
        borderRadius: dimensions.moderate(30) / 2,
        height: dimensions.moderate(30),
        justifyContent: 'center',
        marginRight: dimensions.moderate(5, 1),
        width: dimensions.moderate(30),
    },
    GroupButton__Time: {
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 8,
    },
    Text: {
        // paddingLeft: 0,
        // paddingRight: 0,
        // padding: dimensions.moderate(7),
        fontSize: fontSizes.verySmall,
        fontWeight: fontWeights.medium,
        textAlign: 'center',
    },
})
