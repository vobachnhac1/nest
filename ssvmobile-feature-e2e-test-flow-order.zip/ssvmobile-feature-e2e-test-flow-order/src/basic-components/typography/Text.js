import React from 'react'
import { Dimensions } from 'react-native'

import Text from '../Text'
/**
 * @param {} color	-	mặc định black
 * @param {} fontSize	-	mặc định 14
 * @param {} fontWeight	-	mặc định normal
 * @param {} textAlign	-	mặc định left
 * @param {} lineHeight	-	mặc định 25
 *
 */
const { height, width } = Dimensions.get('window') // device height and width
//Chiều rộng và cao cho design chuẩn.
const guidelineBaseWidth = 360
const guidelineBaseHeight = 592

const scale = (size) => (width / guidelineBaseWidth) * size
const verticalScale = (size) => (height / guidelineBaseHeight) * size
const moderateScale = (size, factor = 0.5) => size + (scale(size) - size) * factor

const TextElement = (props) => {
    return (
        <Text
            {...props}
            style={{
                ...props.style,
                color: props.color || 'black',
                fontSize: props.fontSize ? moderateScale(props.fontSize) : moderateScale(14),
                fontWeight: props.fontWeight || 'normal',
                textAlign: props.textAlign || 'left',
                lineHeight: props.lineHeight ? verticalScale(props.lineHeight) : verticalScale(25),
            }}
        >
            {props.children}
        </Text>
    )
}
export default TextElement
