import React, { useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { RefreshControl, StyleSheet, TextInput, View } from 'react-native'
import { STORE_KEY } from '@mts-utils/index'
import { Container, Content, Textarea } from 'native-base'
import SyncStorage from 'sync-storage'

import { Text } from '../../../basic-components'
import Account from '../../../components/account'
import HeaderComponent from '../../../components/header'
import ModalLoading from '../../../components/modal-loading'
import { ButtonCustom } from '../../../components/trading-component'
import { StoreContext } from '../../../store'
import { dimensions as dm, fontSizes as fs, fontWeights as fw } from '../../../styles'
import { glb_sv, Screens, sendRequest, wait } from '../../../utils'

const LocalStorageDevTool = ({ navigation, route }) => {
    const { t } = useTranslation()
    const { styles, theme, language, authFlag } = useContext(StoreContext)
    const [refreshing, setRefreshing] = useState(false)
    const [loading, setLoading] = useState(false)

    // -----------------
    const [keyLocal, setKeyLocal] = useState(STORE_KEY.POPUP_ADVERTISING_NOTIFY)
    const [response, setResponse] = useState('')
    const [colorResponse, setColorResponse] = useState('')

    useEffect(() => {}, [])

    const getLocalData = async () => {
        setLoading(true)
        const data = (await SyncStorage.get(STORE_KEY.POPUP_ADVERTISING_NOTIFY)) || {}
        setResponse(JSON.stringify(data))
        setLoading(false)
    }
    const onDeleteLocal = async () => {
        const data = (await SyncStorage.remove(STORE_KEY.POPUP_ADVERTISING_NOTIFY)) || {}
        getLocalData()
    }

    // ----------------------------------------
    const onRefresh = () => {
        setRefreshing(true)
        wait(300).then(() => setRefreshing(false))
    }

    return (
        // @ts-expect-error
        <Container style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                navigation={navigation}
                title={t('Request Tools')}
                titleAlgin="flex-start"
                transparent
                isShowLeft
                // leftButtonLink={() => goBackAndRefresh()}
            />
            <Content
                refreshControl={<RefreshControl refreshing={refreshing} tintColor={styles.PRIMARY__CONTENT__COLOR} onRefresh={onRefresh} />}
                style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}
            >
                {/* --------------- */}
                <View style={[UI.RowWrap, { borderBottomColor: styles.DIVIDER__COLOR, flexDirection: 'row' }]}>
                    <View style={[UI.LabelInput]}>
                        <Text style={{ fontWeight: fw.bold, fontSize: fs.small, color: styles.SECOND__CONTENT__COLOR, textAlign: 'right' }}>
                            {t<string>('keyLocal')}:
                        </Text>
                    </View>
                    <View style={[UI.InputValue, { backgroundColor: styles.INPUT__BG }]}>
                        <TextInput
                            placeholder={t('worker Name')}
                            placeholderTextColor={styles.SECOND__CONTENT__COLOR}
                            returnKeyType="done"
                            style={{
                                fontSize: fs.small,
                                color: styles.PRIMARY__CONTENT__COLOR,
                                textAlignVertical: 'center',
                                textAlign: 'right',
                            }}
                            value={keyLocal}
                            onChangeText={(value) => {
                                setKeyLocal(value)
                            }}
                        />
                    </View>
                </View>

                <ButtonCustom text={t('Request')} type="confirm" onPress={getLocalData} />
                <ButtonCustom text={t('Delete')} type="sell" onPress={onDeleteLocal} />
                <View style={{ paddingHorizontal: dm.moderate(16), marginTop: dm.moderate(16) }}>
                    <Textarea
                        disabled
                        rowSpan={10}
                        style={{
                            borderRadius: 8,
                            borderWidth: 0,
                            backgroundColor: styles.INPUT__BG,
                            color: colorResponse ? colorResponse : styles.PRIMARY__CONTENT__COLOR,
                        }}
                        value={response}
                        onChangeText={() => null}
                    />
                </View>
            </Content>
            {loading && <ModalLoading content={t('processing')} visible={loading} />}
        </Container>
    )
}

export default LocalStorageDevTool

const UI = StyleSheet.create({
    ButtonAdd: {
        alignItems: 'center',
        alignSelf: 'flex-end',
        borderRadius: 16,
        justifyContent: 'center',
        marginHorizontal: dm.moderate(16),
        marginVertical: 16,
        paddingHorizontal: 16,
        paddingVertical: 8,
        width: dm.WIDTH * 0.4,
    },
    ConditionOparator: {
        borderRadius: 4,
        flex: 1,
        marginRight: 8,
        paddingHorizontal: 10,
        paddingVertical: 8,
    },
    InputValue: {
        borderRadius: 4,
        flex: 5,
        paddingHorizontal: 10,
        paddingVertical: 8,
    },
    LabelInput: { borderRadius: 4, marginRight: 8, paddingVertical: 8 },
    RowCheckBox: {
        borderRadius: 12,
        flexDirection: 'row',
        marginHorizontal: dm.moderate(16),
        marginTop: dm.vertical(12),
    },
    RowCheckBoxTouch: { alignItems: 'center', flexDirection: 'row', marginTop: dm.vertical(16) },
    RowFilter: {
        marginHorizontal: dm.moderate(8),
        marginVertical: dm.vertical(8),
    },
    RowWrap: {
        borderBottomWidth: 1,
        borderRadius: 8,
        marginHorizontal: dm.moderate(16),
        marginVertical: dm.moderate(4),
        paddingBottom: 8,
        paddingVertical: dm.moderate(4),
    },
    bottomModal: {
        justifyContent: 'flex-end',
        margin: 0,
    },
    marginRight8: { marginRight: 8 },
    view_price_t31: { alignItems: 'center', flexDirection: 'row', marginHorizontal: dm.moderate(4), marginTop: 4 },
})
