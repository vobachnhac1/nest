import React, { memo, useContext, useMemo, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { StyleSheet, View } from 'react-native'
import { DefaultTabBar, Tab, Tabs } from 'native-base'

import Account from '../../../components/account'
import { StoreContext } from '../../../store'
import { StoreTrading } from '../../../store-trading'
import { dimensions } from '../../../styles'
import { glb_sv } from '../../../utils'
import WebviewPieChartAssetOwn from './webview'

const PieChartAssetStockOwn = ({ data }) => {
    const { t } = useTranslation()

    if (data.length) {
        return (
            <View style={UI.view}>
                <WebviewPieChartAssetOwn dataChart={JSON.stringify(data)} t={t} />
            </View>
        )
    }
    return null
}

export default PieChartAssetStockOwn

const UI = StyleSheet.create({
    view: {
        height: 400,
        width: dimensions.WIDTH,
    },
})
