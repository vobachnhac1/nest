import React, { useContext, useEffect } from 'react'
import { useTranslation } from 'react-i18next'
import { Keyboard, StyleSheet, View } from 'react-native'
import { TouchableOpacity } from 'react-native-gesture-handler'
import Svg, { Circle, Path } from 'react-native-svg'

import { CustomFloatInput } from '../../../basic-components'
import AccountReceived from '../../../components/account/account-received'
import { ButtonCustom, RowTitleGroup, StockInfoRowView } from '../../../components/trading-component'
import { StoreContext } from '../../../store'
import { dimensions as dm } from '../../../styles'
import { eventList, glb_sv, reqFunct, sendRequest } from '../../../utils'
import FormatNumber from '../../../utils/formatNumber/FormatNumber'
// Khai báo ServiceInfo (nếu có)
const ServiceInfo = {
    getListBankTran: {
        reqFunct: reqFunct.GET_LIST_BANK_TRANS, //Lấy DS ngân hàng chuyển
        WorkerName: 'FOSqAccount',
        ServiceName: 'FOSqAccount_Common',
        ClientSentTime: '0',
        Operation: 'Q',
        // TestInput: ["07", "%"]
    },
    getListActReceive: {
        reqFunct: reqFunct.GET_LIST_ACT_RECEIVE, // Lấy DS số tài khoản hưởng (CTCK)
        WorkerName: 'FOSqCash',
        ServiceName: 'FOSqCash_Common',
        ClientSentTime: '0',
        Operation: 'Q',
        // TestInput: ["02", "00"]
    },
}
// Khai báo component
const StepTwo = ({
    dataSubCurrTransfer,
    navigation,
    switchStep,
    amountMove,
    setAmountMove,
    sub_curr2,
    setSub_curr2,
    errCtrl,
    setErrCtrl,
    resetReceived,
    setStkList,
    stkList,
}) => {
    const { t } = useTranslation()
    const { styles } = useContext(StoreContext)
    // const [isOpenModalSelection, setIsOpenModalSelection] = useState(false);

    //  const [resetReceived,setResetReceived] = useState('')
    // const [infoSelection, setInfoSelection] = useState({
    //   type: '',
    //   callback: () => {},
    // });

    // -------------------------------------------   Dùng useEffect get các dữ liệu cần thiết còn thiếu
    useEffect(() => {
        if (glb_sv.ListBankTrans.length === 0) {
            getListBankTran()
        }
        if (glb_sv.ListBankReceive.length === 0) {
            getListActReceive()
        }

        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.LOGIN_SUCCESS) {
                // reCall service FOSq
                getListBankTran()
                getListActReceive()
            }
        })

        return () => {
            commonEvent.unsubscribe()
        }
    }, [])
    // -------------------------------------------   Viết các hàm để set lại bussiness form state. Nên viết đúng một chuẩn duy nhất để dễ control

    // -------------------------------------------   Khai báo các hàm gửi (request) lên server
    const getListBankTran = () => {
        const inputParams = ['07', '%']
        sendRequest(ServiceInfo.getListBankTran, inputParams, handleGetListBankTran)
    }
    const getListActReceive = () => {
        const inputParams = ['02', '00']
        sendRequest(ServiceInfo.getListActReceive, inputParams, handleGetListActReceive)
    }
    // -------------------------------------------   Khai báo các hàm nhận (handle respone) dữ liệu từ server

    const handleGetListBankTran = (reqInfoMap, message) => {
        // s
        // -- process after get result --
        let ListBankTranTemp = []
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata
            try {
                jsondata = JSON.parse(message.Data)
            } catch (err) {
                // glb_sv.logMessage(err);
                jsondata = []
            }
            ListBankTranTemp = ListBankTranTemp.concat(jsondata)
            if (Number(message.Packet) <= 0) {
                const bankTransferList = ListBankTranTemp.map((item) => {
                    const label = item.c1
                    const value = item
                    return { label, value }
                })
                glb_sv.ListBankTrans = bankTransferList
            }
        }
    }
    // ----------------------------------------------------

    const handleGetListActReceive = (reqInfoMap, message) => {
        // -- process after get result --
        let ListBankReceiveTemp = []
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata
            try {
                jsondata = JSON.parse(message.Data)
            } catch (err) {
                jsondata = []
            }
            ListBankReceiveTemp = ListBankReceiveTemp.concat(jsondata)
            if (Number(message.Packet) <= 0) {
                const bankSecList = ListBankReceiveTemp.map((item) => {
                    const label = item.c2 + ' - ' + item.c1
                    const value = item
                    return { label, value }
                })
                glb_sv.ListBankReceive = bankSecList
            }
        }
    }

    return (
        <View style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
            <RowTitleGroup text={t('receive_sub_account')} />
            <AccountReceived // Component tài khoản nhận chưa nằm ngang
                setSub_curr2={setSub_curr2}
                sub_curr2={sub_curr2}
            />
            <StockInfoRowView
                qtyNote={t('stock_available') + ' '}
                stockName={stkList[dataSubCurrTransfer.codeCk]}
                stockSymbol={dataSubCurrTransfer.codeCk}
                key={String(Math.random())}
                // type="buy"
                onPress={() => {
                    // switchStep.next();
                    setAmountMove(dataSubCurrTransfer.stockAmount)
                }}
                qty={FormatNumber(dataSubCurrTransfer.stockAmount)}
                // iconRight={<IconSelect />}
            />
            <View style={UI.RowInput}>
                <CustomFloatInput
                    animationDuration={100}
                    errCtrl={t(errCtrl[0])}
                    keyboardType="number-pad"
                    label={t('transfer_quantity')}
                    onChangeText={(amout) => {
                        setAmountMove(glb_sv.filterNumber(amout))
                        // Keyboard.dismiss();
                    }}
                    // editable={false}
                    placeholderTextColor={styles.PLACEHODLER__COLOR}
                    value={FormatNumber(amountMove) === '0' ? '' : FormatNumber(amountMove)}
                />
            </View>
            <ButtonCustom
                text={t('common_button_confirm')}
                type="confirm"
                onPress={() => {
                    Keyboard.dismiss
                    switchStep.onFinish()
                }}
            />
            <ButtonCustom
                last
                text={t('common_back')}
                type="back"
                onPress={() => {
                    switchStep.prev()
                    setAmountMove(0)
                }}
            />
        </View>
    )
}
const UI = StyleSheet.create({
    GroupInput: {
        marginVertical: dm.halfVerticalIndent,
        paddingHorizontal: dm.halfIndent,
    },
    RowInput: {
        marginHorizontal: dm.moderate(16),
        marginVertical: dm.moderate(4),
        paddingVertical: dm.moderate(4),
    },
})
export default StepTwo
