import React, { memo, useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { GestureResponderEvent, Text, TouchableOpacity } from 'react-native'

import LoadingError from '../../../assets/images/common/loading_err.svg'
import { StoreContext } from '../../../store'
import { dimensions, fontSizes } from '../../../styles'

interface IErrorView {
    refresh?: (event: GestureResponderEvent) => void
    title?: string
}

const ErrorView = ({ refresh, title }: IErrorView) => {
    const { t } = useTranslation()
    const { styles } = useContext(StoreContext)

    return (
        <TouchableOpacity style={{ paddingVertical: dimensions.moderate(40), display: 'flex', alignItems: 'center', paddingHorizontal: 50 }} onPress={refresh}>
            <LoadingError fill={styles.REF__COLOR} height={65} width={65} onPress={refresh} />
            <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small, textAlign: 'center' }}>
                {title || t<string>('error_loading_data_please_try_again_later')}
            </Text>
        </TouchableOpacity>
    )
}

export default memo(ErrorView)
