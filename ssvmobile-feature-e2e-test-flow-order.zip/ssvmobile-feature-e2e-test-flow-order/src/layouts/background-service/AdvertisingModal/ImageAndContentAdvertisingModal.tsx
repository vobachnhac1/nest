import React, { memo, useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { ActivityIndicator, ImageBackground, Linking, StyleSheet, TouchableOpacity, View } from 'react-native'
import { ScrollView } from 'react-native-gesture-handler'
import Modal from 'react-native-modal'
import RenderHTML from 'react-native-render-html'
import ToastGlobal from 'react-native-toast-message'
import Icon from 'react-native-vector-icons/MaterialIcons'

import { Text } from '../../../basic-components'
import { ModalByView } from '../../../components/trading-component/common/ModalByView'
import { useEffectAwaitConnectionTrading } from '../../../hoc/useEffectAwaitConnectionTrading'
import useSafeModalState, { GLOBAL_MODAL_KEY } from '../../../hoc/useSafeModalState'
import { StoreContext } from '../../../store'
import { StoreTrading } from '../../../store-trading'
import { dimensions, fontSizes, fontWeights, IconSvg } from '../../../styles'
import { reqFunct } from '../../../utils'
import { useCheckModalAdvertising } from './hooks/useCheckModalAdvertising'
import { __DEV__deleteLocalPopup, getDataPopupToLocalDontAskAgain, setDataPopupToLocalDontAskAgain } from './ultils/localManagement'
// ---------------------------
const ImageAndContentAdvertisingModal = ({ visible, content, callbackOnClose, callbackOnClick }) => {
    const [isVisible, setIsVisible] = useSafeModalState(GLOBAL_MODAL_KEY.AdvertisingModal)

    const { styles, authFlag } = useContext(StoreContext)

    const { t } = useTranslation()
    const [checkBoxDontAskAgain, setCheckBoxDontAskAgain] = useState(false)
    const [currentPopupInLocal, setCurrentPopupInLocal] = useState({})

    const { isCheckingDataPopup, dataPopup, checkPopup, nextEvent } = useCheckModalAdvertising()
    // --------------
    useEffectAwaitConnectionTrading(() => {
        // __DEV__deleteLocalPopup()
        if (authFlag) {
            checkPopup({ type: '2' }, setIsVisible)
        } else {
            checkPopup({ type: '3' }, setIsVisible)
        }
    }, [authFlag])

    const onClose = () => {
        //Tần số hiện popup notify cho khách hàng: 1. Một lần trong ngày,2. Nhiều lần trong ngày,3. Một lần duy nhất
        if (dataPopup.c2 === '3') {
            // Một lần duy nhất
            // @ts-expect-error
            setDataPopupToLocalDontAskAgain(dataPopup, dataPopup.c0, true, 1, 'forever')
        }
        if (dataPopup.c2 === '1') {
            // Một lần trong ngày
            // @ts-expect-error
            setDataPopupToLocalDontAskAgain(dataPopup, dataPopup.c0, true, 1, 'days')
        }
        nextEvent(() => setIsVisible(false))
    }
    useEffect(() => {
        checkIsDontAskAgain()
        // Kiểm tra nếu không có dataPopup phải set lại state của modal về false
        if (!dataPopup.c4 || !dataPopup.c5) {
            setIsVisible(false)
        }
    }, [dataPopup])

    const backgroundImageLink = dataPopup.c5

    const checkIsValidateData = () => {
        if (!dataPopup.c4) return false
        if (!dataPopup.c5) return false
        return true
    }
    const onCheckDontAskAgain = (isDontAsk) => {
        setCheckBoxDontAskAgain(isDontAsk)
        // console.log('dataPopup onCheckDontAskAgain', dataPopup, isDontAsk)
        // @ts-expect-error
        setDataPopupToLocalDontAskAgain(dataPopup, dataPopup.c0, isDontAsk, 1, 'forever')
    }

    const checkIsDontAskAgain = async () => {
        const localData = await getDataPopupToLocalDontAskAgain()
        // @ts-expect-error
        const currentPopupData = localData[dataPopup.c0]
        setCurrentPopupInLocal(currentPopupData || {})
        setCheckBoxDontAskAgain(currentPopupData?.isDontAsk)
        if (currentPopupData?.isDontAsk) {
            // Thời quá thời gian dontAsk
            if (currentPopupData?.timeExpried > new Date().getTime()) {
                // Nếu quá hạn thì next event kế tiếp, nếu hết thì tắt popup
                nextEvent(() => {
                    setIsVisible(false)
                })
            } else {
                // ------
                onCheckDontAskAgain(false) // Set checkbox false
                setIsVisible(true) // Hiển thị
            }
        }
        return true
    }

    const OpenURLButton = async (url) => {
        try {
            const supported = await Linking.canOpenURL(url)
            if (supported) {
                await Linking.openURL(url)
            }
        } catch (err) {
            console.log('OpenURLButton -> err', err)
        }
    }

    const hideModal = () => {
        setIsVisible(false)
    }

    //---------------
    return (
        <>
            {isVisible ? (
                <ModalByView
                    hideModalContentWhileAnimating={true}
                    isVisible={!isCheckingDataPopup && checkIsValidateData() && isVisible}
                    style={UI.modal}
                    useNativeDriver={true}
                    onBackButtonPress={hideModal}
                    onBackdropPress={hideModal}
                >
                    <View style={[UI.View, { backgroundColor: styles.HEADER__BG__COLOR, shadowColor: styles.PRIMARY__CONTENT__COLOR }]}>
                        <View style={UI.haftTop}>
                            <TouchableOpacity style={{ flex: 1 }} onPress={() => OpenURLButton(dataPopup.c6)}>
                                <ImageBackground resizeMode="cover" source={{ uri: backgroundImageLink }} style={UI.imageBackground} />
                            </TouchableOpacity>
                        </View>
                        {/* <View style={[UI.circleClose, { borderColor: styles.ICON__PRIMARY, backgroundColor: styles.HEADER__BG__COLOR }]}>
                    <TouchableOpacity onPress={onClose}>
                        <Icon name="close" size={16} color={styles.ICON__PRIMARY} />
                    </TouchableOpacity>
                </View> */}
                        <View style={UI.haftBottom}>
                            <View style={UI.contentModal}>
                                <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
                                    <RenderHTML
                                        baseStyle={{
                                            fontSize: fontSizes.normal,
                                            fontWeight: fontWeights.bold,
                                            color: styles.PRIMARY__CONTENT__COLOR,
                                            // @ts-expect-error
                                            overflow: 'scroll',
                                        }}
                                        source={{
                                            html: escapeHtml(dataPopup.c4 || ''),
                                        }}
                                    />
                                </ScrollView>
                            </View>
                            <View style={[UI.bottomModal, { backgroundColor: styles.PRIMARY__BG__COLOR }]}>
                                {/* Tần số hiện popup notify cho khách hàng: 1. Một lần trong ngày,2. Nhiều lần trong ngày,3. Một lần duy nhất */}
                                {dataPopup.c2 === '1' || dataPopup.c2 === '2' ? (
                                    <TouchableOpacity onPress={() => onCheckDontAskAgain(!checkBoxDontAskAgain)}>
                                        <View
                                            style={{
                                                flexDirection: 'row',
                                                justifyContent: 'center',
                                                alignItems: 'center',
                                                paddingVertical: dimensions.vertical(16),
                                            }}
                                        >
                                            <View>
                                                <IconSvg.CheckboxIcon
                                                    active={checkBoxDontAskAgain}
                                                    colorActive={styles.PRIMARY}
                                                    colorunActive={styles.PRIMARY__CONTENT__COLOR}
                                                />
                                            </View>
                                            <View>
                                                <Text
                                                    style={{
                                                        fontSize: fontSizes.small,
                                                        color: styles.PRIMARY__CONTENT__COLOR,
                                                        marginLeft: dimensions.moderate(8),
                                                        marginRight: 16,
                                                    }}
                                                >
                                                    {t<string>('dont_show_again')}
                                                </Text>
                                            </View>
                                        </View>
                                    </TouchableOpacity>
                                ) : null}
                                <View style={{ flexDirection: 'row', justifyContent: 'flex-end', alignItems: 'center', flex: 1 }}>
                                    <TouchableOpacity onPress={onClose}>
                                        <Text
                                            style={{
                                                color: styles.PRIMARY,
                                                fontSize: fontSizes.normal,
                                                fontWeight: fontWeights.bold,
                                                textDecorationLine: 'underline',
                                                paddingLeft: 16,
                                                paddingVertical: dimensions.vertical(16),
                                            }}
                                        >
                                            {t<string>('common_Close')}
                                        </Text>
                                    </TouchableOpacity>
                                </View>
                            </View>
                        </View>
                    </View>
                </ModalByView>
            ) : null}
        </>
    )
}

export default memo(ImageAndContentAdvertisingModal)

const UI = StyleSheet.create({
    Text: {
        fontSize: fontSizes.medium,
        paddingLeft: dimensions.moderate(8),
    },
    View: {
        aspectRatio: 0.75,
        borderColor: 'rgba(0, 0, 0, 0.1)',
        borderRadius: 8,
        elevation: 20,
        flexDirection: 'column',
        justifyContent: 'flex-start',
        position: 'relative',
        shadowOffset: { width: 6, height: 6 },
        shadowOpacity: 0.3,
        shadowRadius: 5,
    },
    bottomModal: {
        paddingHorizontal: dimensions.moderate(16),
        // paddingVertical: dimensions.vertical(16),
        borderBottomLeftRadius: 8,
        borderBottomRightRadius: 8,
        alignItems: 'flex-end',
        justifyContent: 'space-between',
        flexDirection: 'row',
        // minHeight: dimensions.vertical(44),
    },
    circleClose: {
        borderRadius: 40,
        borderWidth: 1,
        padding: 2,
        position: 'absolute',
        right: -8,
        top: -8,
    },
    contentModal: {
        flex: 1,
        justifyContent: 'flex-start',
        overflow: 'scroll',
        paddingHorizontal: dimensions.moderate(16),
        paddingVertical: dimensions.vertical(16),
    },
    haftBottom: {
        flex: 1,
        height: '50%',
        justifyContent: 'space-between',
    },
    haftTop: {
        flex: 1,
        height: '50%',
    },
    imageBackground: {
        borderTopLeftRadius: 8,
        borderTopRightRadius: 8,
        flex: 1,
        justifyContent: 'center',
        overflow: 'hidden',
    },
    modal: {
        margin: dimensions.moderate(32),
    },
})

const escapeHtml = (text) => {
    return text
        .replace(/&amp;/g, '&')
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&quot/g, '"')
        .replace(/&#039;/g, "'")
}
