import 'antd/dist/antd.css'
import 'moment/locale/vi'

import React, { PureComponent } from 'react'
import { DatePicker } from 'antd'
import Highcharts from 'highcharts'
import HighchartsStock from 'highcharts/highstock'
import moment from 'moment'

import FormatNumber from '../../formatNumber/FormatNumber'

const PROFIT_LOSS_DOWN = '#FF6973'
const PROFIT_LOSS_UP = '#4CB593'

export default class MyPerformanceChart extends PureComponent {
    constructor(props) {
        super(props)
        this.state = {
            tab: '1',
            fromdt: moment(window.workDate, 'YYYYMMDD').subtract(12, 'months'),
            todt: moment(window.workDate, 'YYYYMMDD'),
            dataTableAssetsFull: window.dataAssetWeightFull || [],
        }
        document.body.classList.add(window.theme)
    }

    componentDidMount() {
        this.chart_statistic = Highcharts.chart('chart_statistic', {
            chart: {
                type: 'column',
            },
            title: {
                text: '',
            },
            xAxis: {
                crosshair: true,
                labels: {
                    formatter: function () {
                        return moment(this.value).format('MM/YYYY')
                    },
                },
                type: 'datetime',
            },
            yAxis: {
                // visible: false,
                title: {
                    text: '',
                },
            },
            legend: {
                enabled: false,
                itemStyle: {
                    color: window.PRIMARY__CONTENT__COLOR,
                },
            },
            credits: {
                enabled: false,
            },
            // tooltip: {
            //     headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
            //     pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            //         '<td style="padding:0"><b>{point.y:.1f} mm</b></td></tr>',
            //     footerFormat: '</table>',
            //     shared: true,
            //     useHTML: true
            // },
            plotOptions: {
                column: {
                    dataLabels: {
                        enabled: true,
                        formatter: function () {
                            return FormatNumber(this.y, 2) + '%'
                        },
                    },
                },
            },
            series: [
                {
                    name: window.profit_or_loss_ratio,
                    data: [],
                },
            ],
        })

        this.eventMarket = window.eventMarket.subscribe((msg) => {
            if (msg.type === 'highchart-render' && msg.value === 'dataStatictis') {
                requestAnimationFrame(() => {
                    this.chart_statistic.series[0].setData(
                        window.dataStatictis.map((e) => {
                            return {
                                x: moment(e.c0, 'YYYYMM').valueOf(),
                                y: Number(e.c2),
                                color: Number(e.c2) < 0 ? PROFIT_LOSS_DOWN : PROFIT_LOSS_UP,
                            }
                        }),
                    )
                    this.chart_statistic.reflow()
                })
            }
        })
        requestAnimationFrame(() => {
            // Chart Thống kê lời lỗ
            this.chart_statistic.series[0].setData(
                window.dataStatictis.map((e) => {
                    return {
                        x: moment(e.c0, 'YYYYMM').valueOf(),
                        y: Number(e.c2),
                        color: Number(e.c2) < 0 ? PROFIT_LOSS_DOWN : PROFIT_LOSS_UP,
                    }
                }),
            )
            this.chart_statistic.reflow()
        })
    }

    componentWillUnmount() {
        this.eventMarket.unsubscribe()
    }

    render() {
        const disabledFromDate = moment(window.workDate, 'YYYYMMDD')
        const disabledDate = (current) => {
            const tooEff = disabledFromDate.diff(current, 'days') < 0
            return tooEff
        }
        return (
            <div className="flex flex-direction-column h-100" style={{ color: window.PRIMARY__CONTENT__COLOR, backgroundColor: window.PRIMARY__BG__COLOR }}>
                <div className="flex flex-direction-column">
                    <div id="chart_statistic" style={{ height: 250 }} />
                </div>
            </div>
        )
    }
}
