import React, { useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Linking, NativeModules, Pressable, Switch, TouchableOpacity, View } from 'react-native'
import FingerprintScanner from 'react-native-fingerprint-scanner'
import * as Keychain from 'react-native-keychain'
import RNRestart from 'react-native-restart'
import ModalController from '@mts-components/appModal/modalControlller'
import { dbRef, useSaveCurrentStep } from '@mts-layouts/eKYCFPT/hooks/useSaveCurrentStep'
import { navigate2Ekyc } from '@mts-utils/navigate2Ekyc'
import moment from 'moment'
import { Body, Container, Content, Left, ListItem, Right } from 'native-base'
import SyncStorage from 'sync-storage'

import Fingerprint from '../../assets/images/common/fingerprint.svg'
import IconBack from '../../assets/images/common/ic_arrow_right.svg'
import { Text } from '../../basic-components'
import AvatarImage from '../../basic-components/avatar'
import HeaderComponent from '../../components/header'
import { allowCompanyRender } from '../../hoc'
import ModalAuthenOtp from '../../layouts/login/modal-authen-otp'
import { StoreContext } from '../../store'
import { StoreTrading } from '../../store-trading'
import { fontSizes, fontWeights, IconSvg } from '../../styles'
import { IOS } from '../../styles/helper/dimensions'
import { eventList, glb_sv, reqFunct, Screens, sendRequest, STORE_KEY } from '../../utils'
import { ButtonCustom, RowData, RowTitleGroup } from '../trading-component'
import ModalEditAvatar from './ModalEditAvatar'

const ServiceInfo = {
    GET_USER_INFO_IVS: {
        reqFunct: reqFunct.GET_USER_INFO_IVS,
        WorkerName: 'FOSqAccount01',
        ServiceName: 'FOSqAccount01_Online_1',
        Operation: 'Q',
        ClientSentTime: '0',
    },
    LOGOUT: {
        reqFunct: reqFunct.LOGOUT,
        WorkerName: 'FOSxID02',
        ServiceName: 'FOSxID02_AfterLogin',
        Operation: 'I',
        ClientSentTime: '0',
    },
    EKYC_INFO: {
        reqFunct: reqFunct.EKYC_INFO,
        WorkerName: 'FOSqID01',
        ServiceName: 'FOSqID01_EKYCInfo',
        ClientSentTime: '0',
        Operation: 'Q',
    },
    QUERY_USER_INFORMATION: {
        reqFunct: reqFunct.QUERY_USER_INFORMATION,
        WorkerName: 'FOSqID02',
        ServiceName: 'FOSqID02_UserInformation',
        ClientSentTime: '0',
        Operation: 'Q',
    },
}

function UserInfo({ navigation }) {
    const { styles, language, authFlag } = useContext(StoreContext)
    const { userInfo } = useContext(StoreTrading)

    const { t } = useTranslation()

    const [data, setData] = useState({})
    const [userData, setUserData] = useState({})

    const [showEkyc, setShowEkyc] = useState(true)

    const [biometric, setBiometric] = useState(true)
    const [isAuthenBiometric, setIsAuthenBiometric] = useState(false)
    const [isOpenEditAvatar, setIsOpenEditAvatar] = useState(false)
    const [avatarUrl, setAvatarUrl] = useState('')

    const [timeOTP, setTimeOTP] = useState(0)
    const [visibleModalAuthen, setVisibleModalAuthen] = useState(false)
    const [typeSendOTP, setTypeSendOTP] = useState('')
    const [typeModalAuthen, setTypeModalAuthen] = useState('')

    useEffect(() => {
        if (allowCompanyRender(['061', '888'])) {
            getUserInfoIVS()
        } else {
            getUserInfo()
        }
        detectFingerprintAvailable()
        if (!glb_sv.dataEkycInfo) checkEkyc()
        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.EKYC_SUCCESS) {
                setShowEkyc(false)
            } else if (eventList.UPDATE_AVATAR_URL === msg.type) {
                setAvatarUrl(msg.urlAvatar)
            }
        })
        return () => {
            commonEvent.unsubscribe()
        }
    }, [])

    useEffect(() => {
        const userID = glb_sv.objShareGlb.userInfo.c1
        const requestOptions = {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ account_no: userID }),
        }

        if (authFlag && allowCompanyRender[('888', '081')]) {
            const avatarDomain = glb_sv.configInfo.avatar_restful_domain
            fetch(`${avatarDomain}/file/nameavatar`, requestOptions)
                .then((res) => res.json())
                .then((data) => {
                    if (data.success) {
                        glb_sv.imageAvatarUrl = `${avatarDomain}/assets/upload_avatar/${data.data?.file_nm}`
                        setAvatarUrl(glb_sv.imageAvatarUrl)
                    }
                })
        }
    }, [authFlag, glb_sv.imageAvatarUrl, userInfo.actn_curr])

    const getUserInfo = () => {
        const InputParams = ['info']
        sendRequest(ServiceInfo.QUERY_USER_INFORMATION, InputParams, handleGetUserInfo)
    }

    const handleGetUserInfo = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata
            if (!message.Data) return
            try {
                // jsondata = JSON.parse(message['Data'])
                jsondata = JSON.parse(glb_sv.filterStrBfParse(message.Data))
                glb_sv.objUserInfo = jsondata[0] || {}
                setUserData(jsondata[0] || {})
            } catch (err) {
                console.log('handleGetAccoutInfo -> err', err)
                return
            }
        }
    }

    const getUserInfoIVS = () => {
        const InputParams = ['01', glb_sv.objShareGlb.AcntMain || '']
        sendRequest(ServiceInfo.GET_USER_INFO_IVS, InputParams, handleGetUserInfoIVS)
    }

    const handleGetUserInfoIVS = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            return
        } else {
            if (!message.Data) return
            try {
                // const jsondata = JSON.parse(message['Data'])
                const jsondata = JSON.parse(glb_sv.filterStrBfParse(message.Data))
                setUserData(jsondata[0] || {})
            } catch (err) {
                console.log('handleGetAccoutInfo -> err', err)
                return
            }
        }
    }

    const OpenURLButton = async (url) => {
        try {
            const supported = await Linking.canOpenURL(url)
            if (supported) {
                await Linking.openURL(url)
            }
        } catch (err) {
            console.log('OpenURLButton -> err', err)
        }
    }

    const handleLogout = () => {
        // navigation.navigate(Screens.ALERT_MODAL, {
        // icon: <IconSvg.ErrorIcon color={styles.ERROR__COLOR} />,
        // title: t('logout'),
        // content: t('confirm_logout_session'),
        // typeColor: styles.ERROR__COLOR,
        // showCancel: true,
        // linkCallback: () => {
        //     const InputParams = ['logout', glb_sv.credentials.username, glb_sv.notifyOnesignal.userId || '']
        //     sendRequest(ServiceInfo.LOGOUT, InputParams, handleLogoutResult)
        //     setTimeout(() => {
        //         handleLogoutCont()
        //     }, 100)
        // },
        // })

        ModalController.showModal({
            icon: <IconSvg.ErrorIcon color={styles.ERROR__COLOR} />,
            title: t('logout'),
            content: t('confirm_logout_session'),
            typeColor: styles.ERROR__COLOR,
            showCancel: true,
            linkCallback: () => {
                const InputParams = ['logout', glb_sv.credentials.username, glb_sv.notifyOnesignal.userId || '']
                sendRequest(ServiceInfo.LOGOUT, InputParams, handleLogoutResult)
                setTimeout(() => {
                    handleLogoutCont()
                }, 100)
            },
        })
    }

    const handleLogoutResult = async (reqInfoMap, message) => { }

    const handleLogoutCont = async () => {
        try {
            await SyncStorage.remove(STORE_KEY.USER_INFO_TRADING)
            await SyncStorage.set(STORE_KEY.APP_LOGIN_ID, false)
            await SyncStorage.remove(STORE_KEY.AUTHEN_BIOMETRIC)
            await SyncStorage.set(STORE_KEY.AutoLoginMode, false)
            await Keychain.resetGenericPassword()
            await Keychain.setGenericPassword(glb_sv.credentials.username, ' ')
            RNRestart.Restart()
        } catch (err) {
            console.log('handleLogoutCont -> err', err)
        }
    }

    const checkEkyc = () => {
        const inval = ['info']
        sendRequest(ServiceInfo.EKYC_INFO, inval, checkEkycResult, true, checkEkycTimeout, '', 5000)
    }

    const checkEkycTimeout = ({ type }) => { }

    const checkEkycResult = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
        } else {
            let datajson
            try {
                datajson = message.Data ? JSON.parse(message.Data.replace(/\\n/g, '').replace(/\n/g, ''))[0] : {}
            } catch (err) {
                console.log('checkEkycResult', err)
                return
            }
            glb_sv.dataEkycInfo = datajson
        }
    }

    const { getData, deleteData } = useSaveCurrentStep()

    const openTradingAct = () => {
        getData({
            callback: () => {
                ModalController.showModal({
                    icon: null,
                    title: null,
                    content: t('reopen_ekyc_title'),
                    typeColor: styles.PRIMARY,
                    titleOK: t('reopen_ekyc_next_btn'),
                    titleCancel: t('reopen_ekyc_next_cancel'),
                    showCancel: true,
                    isBackdropClose: false,
                    cancelCallBack: () => {
                        deleteData({
                            callback: () => navigate2Ekyc({ IOS, NativeModules, styles }),
                        })
                    },
                    linkCallback: () => {
                        navigate2Ekyc({ IOS, NativeModules, styles, isHasPrevStep: true })
                    },
                })
            },
            callbackNoHaveData: () => {
                navigate2Ekyc({ IOS, NativeModules, styles })
            },
        })
    }

    const detectFingerprintAvailable = () => {
        FingerprintScanner.isSensorAvailable()
            .then((type) => {
                setBiometric(type)
                const IsAuthenBiometricStore = SyncStorage.get(STORE_KEY.AUTHEN_BIOMETRIC)

                if (IsAuthenBiometricStore) {
                    setIsAuthenBiometric(true)
                }
            })
            .catch((error) => {
                console.log('detectFingerprintAvailable -> error', error)
            })
    }

    const handleChangeBiometric = (value) => {
        if (value) {
            FingerprintScanner.release()
            glb_sv.commonEvent.next({ type: eventList.AUTHEN_BIOMETRIC, isShow: true })
            FingerprintScanner.authenticate({ description: t('fingerprint_setting'), cancelButton: t('common_Cancel'), fallbackEnabled: false })
                .then((res) => {
                    setIsAuthenBiometric(true)
                    SyncStorage.set(STORE_KEY.AUTHEN_BIOMETRIC, true)
                    glb_sv.commonEvent.next({ type: eventList.AUTHEN_BIOMETRIC, isShow: false })
                })
                .catch((err) => {
                    console.log('err', err)
                    Linking.openSettings()
                    glb_sv.commonEvent.next({ type: eventList.AUTHEN_BIOMETRIC, isShow: false })
                })
        } else {
            setIsAuthenBiometric(false)
            SyncStorage.set(STORE_KEY.AUTHEN_BIOMETRIC, false)
        }
    }

    const updateInfoCallback = (isRefeshUserInfo) => {
        if (isRefeshUserInfo) {
            if (allowCompanyRender(['061', '888'])) {
                getUserInfoIVS()
            } else {
                getUserInfo()
            }
        }
    }

    const resetOrderPass = () => {
        setTimeOTP('get_new_otp')
        setTypeModalAuthen('change_phonecode')
        setVisibleModalAuthen(true)
    }

    const eContract = () => {
        navigation.navigate(Screens.ECONTRACT_MANAGEMENT)
    }

    return (
        <Container>
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft={true}
                navigation={navigation}
                title={t('account_security')}
                titleAlgin="flex-start"
            />
            <Content style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
                <TouchableOpacity
                    onPress={() => {
                        if (allowCompanyRender(['888', '081']) && authFlag) {
                            setIsOpenEditAvatar(true)
                        }
                    }}
                >
                    <AvatarImage avatar={avatarUrl} isBigger />
                </TouchableOpacity>
                <RowTitleGroup
                    hasDivider
                    rightComponent={
                        glb_sv.configInfo.application_style.is_information_change ? (
                            <Pressable
                                style={{
                                    marginRight: 0,
                                    marginTop: 10,
                                    paddingTop: 5,
                                    paddingBottom: 5,
                                    borderRadius: 10,
                                    borderWidth: 1.5,
                                    borderColor: styles.PRIMARY,
                                }}
                                onPress={() =>
                                    navigation.navigate(Screens.UPDATE_USER_INFO, {
                                        userInfoData: userData,
                                        updateInfoCallback: (value) => updateInfoCallback(value),
                                    })
                                }
                            >
                                <Text
                                    style={{
                                        paddingHorizontal: 10,
                                        fontSize: fontSizes.normal,
                                        color: styles.PRIMARY,
                                        fontWeight: fontWeights.bold,
                                        fontStyle: 'italic',
                                    }}
                                >
                                    {t('common_Modify')}
                                </Text>
                            </Pressable>
                        ) : null
                    }
                    text={t('user_info')}
                />

                {allowCompanyRender(['888', '061']) ? (
                    <>
                        <RowData textLeft={t('customer_fullname')} textRight={userData.c0} />
                        <RowData
                            textLeft={t('common_birthday')}
                            textRight={userData.c8 && userData.c8.trim() ? moment(userData.c8, 'YYYYMMDD').format('DD/MM/YYYY') : ''}
                        />
                        <RowData textLeft={t('id_card_number')} textRight={userData.c9} />
                        <RowData
                            textLeft={t('common_register_date')}
                            textRight={userData.c10 && userData.c10.trim() ? moment(userData.c10, 'YYYYMMDD').format('DD/MM/YYYY') : ''}
                        />
                        <RowData textLeft={t('contact_address')} textRight={userData.c11} />
                        <RowData textLeft={t('email')} textRight={userData.c12} />
                        <RowData textLeft={t('phone')} textRight={userData.c13} />
                        <RowData textLeft={t('branch_open_account')} textRight={userData.c3} />
                        <RowData textLeft={t('branch_manage')} textRight={userData.c4} />
                        <RowData textLeft={t('broker_staff')} textRight={userData.c5} />
                        <RowData
                            rightComponent={
                                <Text
                                    style={{
                                        fontSize: fontSizes.normal,
                                        color: styles.PRIMARY,
                                        fontWeight: fontWeights.semiBold,
                                        fontStyle: 'italic',
                                        textDecorationLine: 'underline',
                                    }}
                                    onPress={() => {
                                        if (userData.c14 && userData.c14.trim()) OpenURLButton(`mailto:${userData.c14}`)
                                    }}
                                >
                                    {userData.c14}
                                </Text>
                            }
                            textLeft={t('broker_email')}
                        />
                        <RowData
                            last
                            rightComponent={
                                <Text
                                    style={{
                                        fontSize: fontSizes.normal,
                                        color: styles.PRIMARY,
                                        fontWeight: fontWeights.semiBold,
                                        fontStyle: 'italic',
                                        textDecorationLine: 'underline',
                                    }}
                                    onPress={() => {
                                        if (userData.c15 && userData.c15.trim()) OpenURLButton(`tel:${userData.c15}`)
                                    }}
                                >
                                    {userData.c15}
                                </Text>
                            }
                            textLeft={t('broker_phone')}
                        />
                    </>
                ) : (
                    <>
                        <RowData textLeft={t('customer_fullname')} textRight={userData.c0} />
                        <RowData textLeft={t('contact_address')} textRight={userData.c22} />
                        <RowData textLeft={t('email')} textRight={userData.c32} />
                        <RowData textLeft={t('phone')} textRight={userData.c35} />
                        <RowData textLeft={t('broker_name')} textRight={userData.c39} />
                        <RowData
                            rightComponent={
                                <Text
                                    style={{
                                        fontSize: fontSizes.normal,
                                        color: styles.PRIMARY,
                                        fontWeight: fontWeights.semiBold,
                                        fontStyle: 'italic',
                                        textDecorationLine: 'underline',
                                    }}
                                    onPress={() => {
                                        OpenURLButton(`mailto:${userData.c40}`)
                                    }}
                                >
                                    {userData.c40}
                                </Text>
                            }
                            textLeft={t('broker_email')}
                        />
                        <RowData
                            last
                            rightComponent={
                                <Text
                                    style={{
                                        fontSize: fontSizes.normal,
                                        color: styles.PRIMARY,
                                        fontWeight: fontWeights.semiBold,
                                        fontStyle: 'italic',
                                        textDecorationLine: 'underline',
                                    }}
                                    onPress={() => {
                                        OpenURLButton(`tel:${userData.c41}`)
                                    }}
                                >
                                    {userData.c41}
                                </Text>
                            }
                            textLeft={t('broker_phone')}
                        />
                    </>
                )}

                {showEkyc && glb_sv.objShareGlb.userInfo.c9 === 'N' ? (
                    <>
                        <View style={{ borderBottomColor: styles.DIVIDER__COLOR, borderBottomWidth: 1 }} />
                        <ListItem activeOpacity={0.6} icon noBorder underlayColor="transparent" onPress={openTradingAct}>
                            <Body>
                                <Text style={{ fontSize: fontSizes.medium, color: styles.PRIMARY }}>{t('open_trading_account')}</Text>
                            </Body>
                            <Right>
                                <IconBack style={{ color: styles.PRIMARY__CONTENT__COLOR }} />
                            </Right>
                        </ListItem>
                    </>
                ) : null}
                <RowTitleGroup hasDivider style={{ marginTop: 2 }} text={t('account__security')} />
                {biometric ? (
                    <ListItem activeOpacity={0.6} icon noBorder underlayColor="transparent">
                        <Left>
                            <Fingerprint fill={styles.PRIMARY__CONTENT__COLOR} height={56} />
                        </Left>
                        <Body>
                            <Text style={{ fontSize: fontSizes.medium, color: styles.PRIMARY }}>{t('authen_biometric')}</Text>
                        </Body>
                        <Right>
                            <Switch value={isAuthenBiometric} onValueChange={handleChangeBiometric} />
                        </Right>
                    </ListItem>
                ) : null}
                {biometric ? (
                    <Text style={{ fontSize: fontSizes.small, color: styles.SECOND__CONTENT__COLOR, paddingHorizontal: 8 }}>
                        {t('note_content_authen_biometric')}
                    </Text>
                ) : null}
                {glb_sv.configInfo.application_style.is_history_login_screen_on ? (
                    <ListItem icon noBorder underlayColor="transparent" onPress={() => navigation.navigate(Screens.HISTORY_LOGIN)}>
                        <Body>
                            <Text style={{ fontSize: fontSizes.medium, color: styles.PRIMARY }}>{t('history_login')}</Text>
                        </Body>
                        <Right>
                            <IconBack style={{ color: styles.PRIMARY__CONTENT__COLOR }} />
                        </Right>
                    </ListItem>
                ) : null}
                {glb_sv.configInfo.application_style.is_update_phone_email ? (
                    <ListItem
                        icon
                        noBorder
                        underlayColor="transparent"
                        onPress={() =>
                            navigation.navigate(Screens.CHANGE_ACC_INFORMATION, {
                                userInfoData: userData,
                                updateInfoCallback: (value) => updateInfoCallback(value),
                            })
                        }
                    >
                        <Body>
                            <Text style={{ fontSize: fontSizes.medium, color: styles.PRIMARY }}>{t('change_acc_info')}</Text>
                        </Body>
                        <Right>
                            <IconBack style={{ color: styles.PRIMARY__CONTENT__COLOR }} />
                        </Right>
                    </ListItem>
                ) : null}
                {glb_sv.configInfo.application_style.is_change_otp_type_screen_on ? (
                    <ListItem
                        icon
                        noBorder
                        underlayColor="transparent"
                        onPress={() => navigation.navigate(Screens.CHANGE_OTP_TYPE, { fromScreen: Screens.SETTINGS })}
                    >
                        <Body>
                            <Text style={{ fontSize: fontSizes.medium, color: styles.PRIMARY }}>{t('change_otp_type')}</Text>
                        </Body>
                        <Right>
                            <IconBack style={{ color: styles.PRIMARY__CONTENT__COLOR }} />
                        </Right>
                    </ListItem>
                ) : null}
                {glb_sv.configInfo.application_style.is_oauth2 ? (
                    <ListItem icon noBorder underlayColor="transparent" onPress={() => navigation.navigate(Screens.OAUTHEN_MANAGEMENT, {})}>
                        <Body>
                            <Text style={{ fontSize: fontSizes.medium, color: styles.PRIMARY }}>{t('OAuthen')}</Text>
                        </Body>
                        <Right>
                            <IconBack style={{ color: styles.PRIMARY__CONTENT__COLOR }} />
                        </Right>
                    </ListItem>
                ) : null}
                <ListItem icon noBorder underlayColor="transparent" onPress={() => navigation.navigate(Screens.CHANGE_PASSWORD, { type: 'change_login' })}>
                    <Body>
                        <Text style={{ fontSize: fontSizes.medium, color: styles.PRIMARY }}>{t('common_change_login_pass')}</Text>
                    </Body>
                    <Right>
                        <IconBack style={{ color: styles.PRIMARY__CONTENT__COLOR }} />
                    </Right>
                </ListItem>

                <ListItem icon noBorder underlayColor="transparent" onPress={() => navigation.navigate(Screens.CHANGE_PASSWORD, { type: 'change_order' })}>
                    <Body>
                        <Text style={{ fontSize: fontSizes.medium, color: styles.PRIMARY }}>{t('common_change_order_pass')}</Text>
                    </Body>
                    <Right>
                        <IconBack style={{ color: styles.PRIMARY__CONTENT__COLOR }} />
                    </Right>
                </ListItem>

                <ListItem icon noBorder underlayColor="transparent" onPress={resetOrderPass}>
                    <Body>
                        <Text style={{ fontSize: fontSizes.medium, color: styles.PRIMARY }}>{t('menu_forget_phone_code')}</Text>
                    </Body>
                    <Right>
                        <IconBack style={{ color: styles.PRIMARY__CONTENT__COLOR }} />
                    </Right>
                </ListItem>

                {allowCompanyRender(['888', '081']) ? (
                    <ListItem icon noBorder underlayColor="transparent" onPress={eContract}>
                        <Body>
                            <Text style={{ fontSize: fontSizes.medium, color: styles.PRIMARY }}>{t('econtract_account_management')}</Text>
                        </Body>
                        <Right>
                            <IconBack style={{ color: styles.PRIMARY__CONTENT__COLOR }} />
                        </Right>
                    </ListItem>
                ) : null}
                {/* <ListItem underlayColor="transparent" noBorder icon onPress={() => navigation.navigate(Screens.UPDATE_BANK_INFO, { userData })}>
                    <Body>
                        <Text style={{ fontSize: fontSizes.medium, color: styles.PRIMARY }}>{t('bank_account_management')}</Text>
                    </Body>
                    <Right>
                        <IconBack style={{ color: styles.PRIMARY__CONTENT__COLOR }} />
                    </Right>
                </ListItem> */}

                {glb_sv.configInfo.application_style.is_update_account_info_screen_on ? (
                    <>
                        <ListItem icon noBorder underlayColor="transparent" onPress={() => navigation.navigate(Screens.UPDATE_ACCOUNT_INFOR, { userData })}>
                            <Body>
                                <Text style={{ fontSize: fontSizes.medium, color: styles.PRIMARY }}>{t('update_acc_info')}</Text>
                            </Body>
                            <Right>
                                <IconBack style={{ color: styles.PRIMARY__CONTENT__COLOR }} />
                            </Right>
                        </ListItem>
                    </>
                ) : null}

                <View style={{ backgroundColor: styles.DIVIDER__VIEW__COLOR, paddingTop: 6 }} />
                <ButtonCustom text={t('logout')} type="cancel" onPress={handleLogout} />
                <View style={{ paddingBottom: 16 }} />
                {/* --------- Modal View/Edit Avatar ------- */}
                <ModalEditAvatar isOpenModal={isOpenEditAvatar} setIsOpenModal={setIsOpenEditAvatar} />
            </Content>

            {visibleModalAuthen ? (
                <ModalAuthenOtp
                    callbackAfterChangePassword={() => null}
                    callBackChangePhonecode={() => null}
                    callBackLogin={() => null}
                    new_pass=""
                    setVisible={setVisibleModalAuthen}
                    time={timeOTP}
                    type={typeModalAuthen}
                    typeSendOTP={typeSendOTP}
                    visible={visibleModalAuthen}
                />
            ) : null}
        </Container>
    )
}

export default UserInfo
