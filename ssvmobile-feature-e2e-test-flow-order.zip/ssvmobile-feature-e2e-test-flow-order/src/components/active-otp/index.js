import React, { useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { ActivityIndicator, Image, InteractionManager, StyleSheet, TouchableOpacity, View } from 'react-native'
import FingerprintScanner from 'react-native-fingerprint-scanner'
import Modal from 'react-native-modal'
import OneSignal from 'react-native-onesignal'
import ToastGlobal from 'react-native-toast-message'
import Ionicons from 'react-native-vector-icons/Ionicons'
import ModalController from '@mts-components/appModal/modalControlller'
import getUniqueIdDevice from '@mts-utils/getUniqueIdDevice'
import Clipboard from '@react-native-clipboard/clipboard'
import moment from 'moment'
import { Button, Container } from 'native-base'
import { default as SyncStorage, default as syncStorage } from 'sync-storage'

import ICON_OTP_SECURITY from '../../assets/images/common/ic_otp_security.png'
import { Text, TextInput } from '../../basic-components'
import HeaderComponent from '../../components/header'
import { useLoading } from '../../hoc'
import ModalAuthen from '../../layouts/login/modal-authen'
import { StoreContext } from '../../store'
import { dimensions, fontSizes, fontWeights, IconSvg } from '../../styles'
import { dataCryption, eventList, glb_sv, reqFunct, Screens, sendRequest, STORE_KEY } from '../../utils'
import { ButtonCustom } from '../trading-component'
import ErrorView from '../trading-component/error-view'

const ServiceInfo = {
    REGISTER_ACTIVE_OTP: {
        reqFunct: reqFunct.REGISTER_ACTIVE_OTP,
        WorkerName: 'FOSxID01',
        ServiceName: 'FOSxID01_OTPManagement',
        ClientSentTime: '0',
        Operation: 'I',
    },
    GET_NEW_OTP: {
        reqFunct: reqFunct.GET_NEW_OTP,
        WorkerName: 'FOSxID01',
        ServiceName: 'FOSxID01_OTPManagement',
        ClientSentTime: '0',
        Operation: 'I',
    },
    DEACTIVE_OTP: {
        reqFunct: reqFunct.DEACTIVE_OTP,
        WorkerName: 'FOSxID01',
        ServiceName: 'FOSxID01_OTPManagement',
        ClientSentTime: '0',
        Operation: 'I',
    },
    GET_LATEST_OTP: {
        reqFunct: reqFunct.GET_LATEST_OTP,
        WorkerName: 'FOSxID01',
        ServiceName: 'FOSxID01_OTPManagement',
        ClientSentTime: '0',
        Operation: 'I',
    },
}

function ActiveOTPScreen({ navigation }) {
    const TAG = 'ActiveOTPScreen'

    const { styles, language } = useContext(StoreContext)
    const { t } = useTranslation()
    const flagSendRegister = useRef(false)

    const [visible, setVisible] = useState(false)

    const timeoutTimingOTP = useRef(null)

    const [error, setError] = useState('')

    const [loadingRegister, setLoadingRegister] = useState(false)
    const [loading, setLoading] = useState(false)

    const [code, setCode] = useState('')
    const [timeOTP, setTimeOTP] = useState(0)
    const timeOTPRef = useRef(0)

    const dataTimeOTP = useRef({
        numberOTP: 0,
        timeGetOTP: moment(),
    })
    const otpRef = useRef(null)

    const [isGetOtp, setGetOtp] = useState(false)
    const [newOTP, setNewOTP] = useState('')

    const authenFlag = useRef(false)

    const [modalAuthen, setModalAuthen] = useState(false)
    const [biometric, setBiometric] = useState('')
    const [isAuthenBiometric, setIsAuthenBiometric] = useState(false)

    const [checkNote, setCheckNote] = useState(false)

    const timeoutGetiOTP = useRef(null)

    const [showErrorView, setShowErrorView] = useState(false)
    const [textError, setTextError] = useState('')
    const iOTPGuildContact = useRef({})
    const [isLoadingGetOTP, setIsLoadingGetOTP] = useLoading(false)

    const isTouchNotify = useRef(false)

    useEffect(() => {
        if (glb_sv.notifyOpened) {
            glb_sv.notifyOpened = null
            isTouchNotify.current = true
            setGetOtp(true)
            handleCheckiOTP()
            return
        }
        glb_sv.notifyOpened = null
        handleCheckUserIdOnesignal()

        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.LOGIN_SUCCESS) {
                handleCheckUserIdOnesignal()
            }
        })

        return () => {
            if (timeoutTimingOTP.current) clearTimeout(timeoutTimingOTP.current)
            FingerprintScanner.release()
            if (timeoutGetiOTP.current) clearTimeout(timeoutGetiOTP.current)
            commonEvent.unsubscribe()
        }
    }, [])

    const handleCheckUserIdOnesignal = () => {
        if (glb_sv.notifyOnesignal.userId) {
            handleCheckiOTP()
        } else {
            OneSignal.getDeviceState()
                .then((res) => {
                    if (glb_sv.notifyOnesignal.userId) {
                        glb_sv.notifyOnesignal = res
                        syncStorage.set(STORE_KEY.DEVICE_ID_ONESIGNAL, res.userId)
                        handleCheckiOTP()
                    } else {
                        ToastGlobal.show({
                            text2: t('notify_note_get_userid_onesignal'),
                            type: 'warning',
                        })
                    }
                })
                .catch((err) => {
                    ToastGlobal.show({
                        text2: t('notify_note_get_userid_onesignal'),
                        type: 'warning',
                    })
                })
        }
    }

    const handleCheckiOTP = () => {
        flagSendRegister.current = true
        const InputParams = ['check_device', glb_sv.notifyOnesignal.userId || '', getUniqueIdDevice()]
        sendRequest(ServiceInfo.REGISTER_ACTIVE_OTP, InputParams, handleCheckiOTPResult, true, handleCheckiOTPTimeout, '', 5000, 'equal_service')
    }

    const handleCheckiOTPTimeout = ({ type }) => {
        flagSendRegister.current = false
        if (isTouchNotify.current) {
            isTouchNotify.current = false
            return
        }
        setShowErrorView(true)
        if (type === 'error_network') {
            setTextError(t('network_disconnected_please_check_network_try_again'))
        } else {
            setTextError('')
        }
    }

    const handleCheckiOTPResult = (reqInfoMap, message) => {
        flagSendRegister.current = false
        setShowErrorView(false)
        let data = {}
        try {
            data = JSON.parse(message.Data.replace(/\\n/g, '').replace(/\n/g, ''))[0]
        } catch (err) {}
        iOTPGuildContact.current = data
        if (Number(message.Result) === 0) {
        } else {
            setGetOtp(true)
            getLatestOTP()
            // FingerprintScanner.release()
            // FingerprintScanner
            //     .isSensorAvailable()
            //     .then(type => {
            //         setBiometric(type)
            //         handleShowBiometric()
            //     })
            //     .catch(error => {
            //     });
        }
    }

    const getLatestOTP = () => {
        const InputParams = ['get_iotp', getUniqueIdDevice()]
        sendRequest(ServiceInfo.GET_LATEST_OTP, InputParams, handleLatestOTPResult, true, handleLatestOTPTimeout, '', 0, 'equal_service')
    }

    const handleLatestOTPTimeout = () => {}

    const handleLatestOTPResult = (reqInfoMap, message) => {
        console.log('handleLatestOTPResult -> message', message)
        if (Number(message.Result) === 0) {
            // nếu lần đầu bị lỗi thì bỏ qua
            if (isTouchNotify.current) {
                isTouchNotify.current = false
            } else {
                ToastGlobal.show({
                    text2: message.Message,
                    type: 'warning',
                })
            }
        } else {
            let datajson
            try {
                datajson = message.Data ? JSON.parse(message.Data)[0] : {}
            } catch (err) {
                console.log('handleRegisterResult', err)
                return
            }
            if (Number(datajson.c0) > 0) {
                setTimeOTP(datajson.c0)
                timeOTPRef.current = datajson.c0
                dataTimeOTP.current = {
                    numberOTP: datajson.c0,
                    timeGetOTP: moment(),
                }
                timingOTP()
                setNewOTP(dataCryption.decryptString(datajson.c1))
            }
        }
    }

    const deactiveIOTP = () => {
        ModalController.showModal({
            icon: <IconSvg.ErrorIcon color={styles.WARN__COLOR} />,
            title: t('common_notify'),
            content: t('notify_deactive_iotp'),
            typeColor: styles.WARN__COLOR,
            showCancel: true,
            linkCallback: () => {
                if (flagSendRegister.current) return
                flagSendRegister.current = true
                const InputParams = ['deactive_device', glb_sv.notifyOnesignal.userId || '', getUniqueIdDevice()]
                sendRequest(ServiceInfo.DEACTIVE_OTP, InputParams, handleDeactiveIOTPResult, true)
            },
        })
        // navigation.navigate(Screens.ALERT_MODAL, {
        // icon: <IconSvg.ErrorIcon color={styles.WARN__COLOR} />,
        // title: t('common_notify'),
        // content: t('notify_deactive_iotp'),
        // typeColor: styles.WARN__COLOR,
        // showCancel: true,
        // linkCallback: () => {
        //     if (flagSendRegister.current) return
        //     flagSendRegister.current = true
        //     const InputParams = ['deactive_device', glb_sv.notifyOnesignal.userId || '', getUniqueIdDevice()]
        //     sendRequest(ServiceInfo.DEACTIVE_OTP, InputParams, handleDeactiveIOTPResult, true)
        // },
        // })
    }

    const handleDeactiveIOTPResult = (reqInfoMap, message) => {
        flagSendRegister.current = false
        if (Number(message.Result) === 0) {
            ToastGlobal.show({
                text2: message.Message,
                type: 'warning',
            })
        } else {
            glb_sv.objShareGlb.userInfo.c20 = 'N'
            // navigation.navigate(Screens.ALERT_MODAL, {
            // icon: <IconSvg.ErrorIcon color={styles.INFO__COLOR} />,
            // title: t('common_notify'),
            // content: message.Message,
            // typeColor: styles.INFO__COLOR,
            //     linkCallback: () => navigation.pop(),
            // })
            ModalController.showModal({
                icon: <IconSvg.ErrorIcon color={styles.INFO__COLOR} />,
                title: t('common_notify'),
                content: message.Message,
                typeColor: styles.INFO__COLOR,
                linkCallback: () => navigation.pop(),
            })
        }
    }

    const handleRegister = () => {
        setError('')
        if (!glb_sv.notifyOnesignal.userId) {
            OneSignal.getDeviceState()
                .then((res) => {
                    if (glb_sv.notifyOnesignal.userId) {
                        glb_sv.notifyOnesignal = res
                        syncStorage.set(STORE_KEY.DEVICE_ID_ONESIGNAL, res.userId)
                        if (flagSendRegister.current) return
                        flagSendRegister.current = true
                        const InputParams = ['active_device', '', glb_sv.notifyOnesignal.userId || '', getUniqueIdDevice()]
                        sendRequest(ServiceInfo.REGISTER_ACTIVE_OTP, InputParams, handleRegisterResult, true, handleRegisterTimeout)
                    } else {
                        ToastGlobal.show({
                            text2: t('notify_note_get_userid_onesignal'),
                            type: 'warning',
                        })
                    }
                })
                .catch((err) => {
                    ToastGlobal.show({
                        text2: t('notify_note_get_userid_onesignal'),
                        type: 'warning',
                    })
                })
            return
        }
        if (flagSendRegister.current) return
        flagSendRegister.current = true
        const InputParams = ['active_device', '', glb_sv.notifyOnesignal.userId || '', getUniqueIdDevice()]
        sendRequest(ServiceInfo.REGISTER_ACTIVE_OTP, InputParams, handleRegisterResult, true, handleRegisterTimeout)
    }

    const sendAuthenOTP = (value) => {
        if (flagSendRegister.current) return
        if (!value || !code) return
        flagSendRegister.current = true
        const codeEncryt = dataCryption.encryptString(value || code)
        const InputParams = ['active_device', codeEncryt, glb_sv.notifyOnesignal.userId || '', getUniqueIdDevice()]
        sendRequest(ServiceInfo.REGISTER_ACTIVE_OTP, InputParams, handleRegisterResult, true, handleRegisterTimeout)
    }

    const handleRegisterTimeout = () => {
        flagSendRegister.current = false
        ToastGlobal.show({
            text2: t('request_hanlde_not_success_try_again'),
            type: 'warning',
        })
    }

    const handleRegisterResult = (reqInfoMap, message) => {
        flagSendRegister.current = false
        if (Number(message.Result) === 0) {
            if (message.Code === '010021') {
                setVisible(true)
                let datajson
                try {
                    datajson = message.Data ? JSON.parse(message.Data)[0] : {}
                } catch (err) {
                    console.log('handleRegisterResult', err)
                    return
                }
                setTimeOTP(datajson.c1)
                timeOTPRef.current = datajson.c1
                dataTimeOTP.current = {
                    numberOTP: datajson.c1,
                    timeGetOTP: moment(),
                }
                timingOTP()
                InteractionManager.runAfterInteractions(() => {
                    otpRef.current && otpRef.current.focus()
                })
            } else {
                setError(message.Message)
            }
        } else {
            SyncStorage.remove(STORE_KEY.TIMEOUT_AUTHEN)
            SyncStorage.remove(STORE_KEY.NUMBER_ERRORS)

            SyncStorage.set(STORE_KEY.FLAG_iOTP, true)
            setGetOtp(true)
            hideModal()
            if (timeoutTimingOTP.current) clearTimeout(timeoutTimingOTP.current)
            timeOTPRef.current = 0
            setTimeOTP(0)
            authenFlag.current = true
            glb_sv.objShareGlb.userInfo.c6 = '5'
            if (glb_sv.configInfo.application_style.show_get_iotp) {
                glb_sv.objShareGlb.userInfo.c20 = 'Y'
                glb_sv.objShareGlb.userInfo.c13 = 'Y'
            } else {
                glb_sv.objShareGlb.userInfo.c13 = 'N'
            }

            InteractionManager.runAfterInteractions(() => {
                // navigation.navigate(Screens.ALERT_MODAL, {
                // icon: <IconSvg.ErrorIcon color={styles.INFO__COLOR} />,
                // title: t('common_notify'),
                // content: message.Message,
                // typeColor: styles.INFO__COLOR,
                //     // linkCallback: () => handleGetNewOTP()
                // })
                ModalController.showModal({
                    icon: <IconSvg.ErrorIcon color={styles.INFO__COLOR} />,
                    title: t('common_notify'),
                    content: message.Message,
                    typeColor: styles.INFO__COLOR,
                    // linkCallback: () => handleGetNewOTP()
                })
            })
        }
    }

    const hideModal = () => {
        setVisible(false)
        setCode('')
        setError('')
        if (timeoutTimingOTP.current) clearTimeout(timeoutTimingOTP.current)
    }

    const timingOTP = () => {
        if (timeOTPRef.current > 0) {
            if (timeoutTimingOTP.current) clearTimeout(timeoutTimingOTP.current)
            timeoutTimingOTP.current = setTimeout(() => {
                const remainTimeOTP = Math.max(0, dataTimeOTP.current.numberOTP - Math.round((moment() - dataTimeOTP.current.timeGetOTP) / 1000))
                timeOTPRef.current = remainTimeOTP
                setTimeOTP(remainTimeOTP)
                timingOTP()
            }, 1000)
        } else setNewOTP('')
    }

    const handleGetNewOTP = (isNotCallRequestAgain) => {
        setIsLoadingGetOTP(true)
        // if (!authenFlag.current) {
        //     setModalAuthen(true);
        //     if (isAuthenBiometric) handleShowBiometric();
        //     return;
        // }
        if (flagSendRegister.current) return
        flagSendRegister.current = true

        const handleGetNewOTPResult = (reqInfoMap, message) => {
            setIsLoadingGetOTP(false)
            flagSendRegister.current = false
            if (Number(message.Result) === 0) {
                if (message.Code === '010012' && !isNotCallRequestAgain) {
                    if (timeoutGetiOTP.current) clearTimeout(timeoutGetiOTP.current)
                    timeoutGetiOTP.current = setTimeout(() => {
                        handleGetNewOTP(true)
                    }, 500)
                } else {
                    ToastGlobal.show({
                        text2: message.Message,
                        type: 'warning',
                    })
                }
            } else {
                let datajson
                try {
                    datajson = message.Data ? JSON.parse(message.Data)[0] : {}
                } catch (err) {
                    console.log('handleRegisterResult', err)
                    return
                }
                setTimeOTP(datajson.c0)
                timeOTPRef.current = datajson.c0
                dataTimeOTP.current = {
                    numberOTP: datajson.c0,
                    timeGetOTP: moment(),
                }
                timingOTP()

                setNewOTP(dataCryption.decryptString(datajson.c1))
            }
        }

        const InputParams = ['new_otp', getUniqueIdDevice()]
        setTimeout(() => {
            sendRequest(ServiceInfo.GET_NEW_OTP, InputParams, handleGetNewOTPResult, true, handleGetNewOTPResultTimeout)
        }, 500)
    }

    const handleGetNewOTPResultTimeout = () => {
        flagSendRegister.current = false
        ToastGlobal.show({
            text2: t('request_hanlde_not_success_try_again'),
            type: 'warning',
        })
    }

    const detectFingerprintAvailable = () => {
        FingerprintScanner.isSensorAvailable()
            .then((type) => {
                setBiometric(type)
                const IsAuthenBiometricStore = SyncStorage.get(STORE_KEY.AUTHEN_BIOMETRIC)
                if (IsAuthenBiometricStore) {
                    setIsAuthenBiometric(true)
                }
            })
            .catch((error) => {
                console.log('detectFingerprintAvailable -> error', error)
            })
    }

    const handleShowBiometric = (value) => {
        FingerprintScanner.release()
        glb_sv.commonEvent.next({ type: eventList.AUTHEN_BIOMETRIC, isShow: true })
        FingerprintScanner.authenticate({ description: t('fingerprint_setting'), cancelButton: t('common_Cancel'), fallbackEnabled: false })
            .then((res) => {
                glb_sv.commonEvent.next({ type: eventList.AUTHEN_BIOMETRIC, isShow: false })
                authenFlag.current = true
                handleGetNewOTP()
                setModalAuthen(false)
                SyncStorage.set(STORE_KEY.AUTHEN_BIOMETRIC, true)
                setIsAuthenBiometric(true)
            })
            .catch((err) => {
                console.log('err', err)
                glb_sv.commonEvent.next({ type: eventList.AUTHEN_BIOMETRIC, isShow: false })
            })
    }

    const hideAuthen = () => {
        setModalAuthen(false)
    }

    const authenSuccess = () => {
        setModalAuthen(false)
        authenFlag.current = true
        handleGetNewOTP()
    }

    const copyOtp = () => {
        if (timeOTP) {
            Clipboard.setString(newOTP)
            ToastGlobal.show({
                text2: t('copy_otp_success'),
                type: 'success',
            })
            return
        }
    }

    return (
        <Container>
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft={true}
                navigation={navigation}
                rightComponent={
                    isGetOtp ? (
                        <View>
                            <TouchableOpacity style={{ padding: dimensions.moderate(4) }} onPress={deactiveIOTP}>
                                {/* <Image source={GREEN_CANCEL_PNG} style={{ width: 30, height: 30 }} /> */}
                                <Text style={{ color: styles.DOWN__COLOR }}>{t('abort_iotp')}</Text>
                            </TouchableOpacity>
                        </View>
                    ) : null
                }
                title={''}
            />
            {!showErrorView ? (
                <View style={{ backgroundColor: styles.PRIMARY__BG__COLOR, padding: dimensions.moderate(16), alignItems: 'center', flex: 1 }}>
                    <Image source={ICON_OTP_SECURITY} style={{ width: 200, height: 200, marginBottom: 50 }} />

                    {isGetOtp ? (
                        <>
                            <TouchableOpacity style={{ flexDirection: 'row' }} onPress={copyOtp}>
                                <View
                                    style={{
                                        backgroundColor: styles.INPUT__BG__LOGIN,
                                        borderRadius: 20,
                                        width: 230,
                                        height: 40,
                                        justifyContent: 'center',
                                        flexDirection: 'row',
                                        alignItems: 'center',
                                    }}
                                >
                                    <Text
                                        style={{
                                            letterSpacing: 16,
                                            fontSize: fontSizes.medium,
                                            fontWeight: fontWeights.semiBold,
                                            color: styles.PRIMARY,
                                            textAlign: 'center',
                                            flex: 1,
                                        }}
                                    >
                                        {newOTP}
                                    </Text>
                                    {timeOTP ? (
                                        <Ionicons
                                            color={styles.PRIMARY__CONTENT__COLOR}
                                            name="copy"
                                            size={18}
                                            style={{
                                                position: 'absolute',
                                                right: 8,
                                            }}
                                        />
                                    ) : null}
                                </View>
                            </TouchableOpacity>

                            <Text
                                style={{
                                    fontSize: fontSizes.verySmall,
                                    color: styles.SECOND__CONTENT__COLOR,
                                    opacity: timeOTP ? 1 : 0,
                                    marginTop: dimensions.vertical(16),
                                }}
                            >
                                {t('otp_timeout_after')}{' '}
                                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR }}>
                                    {timeOTP} {t('second')}
                                </Text>
                            </Text>
                        </>
                    ) : (
                        <>
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal }}>
                                {t('use_feature_you_register_device_main')}.
                            </Text>
                        </>
                    )}

                    <View style={{ flex: 0.8 }} />

                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small, fontStyle: 'italic' }}>
                        {t('message_note_for_iotp')}
                        <Text
                            style={{ color: styles.PRIMARY, fontWeight: fontWeights.medium, textDecorationLine: 'underline' }}
                            onPress={() =>
                                navigation.navigate(Screens.NEWS_DETAIL, {
                                    title: t('user_manual_iotp'),
                                    link: iOTPGuildContact.current.c1,
                                    c5: iOTPGuildContact.current.c0,
                                    c6: iOTPGuildContact.current.c1,
                                })
                            }
                        >
                            {t('user_manual_iotp')}
                        </Text>
                    </Text>

                    {!isGetOtp ? (
                        <TouchableOpacity
                            activeOpacity={0.9}
                            style={{ flexDirection: 'row', alignItems: 'center', marginTop: dimensions.vertical(32), width: '100%' }}
                            onPress={() => setCheckNote((value) => !value)}
                        >
                            <IconSvg.CheckboxIcon active={checkNote} colorActive={styles.PRIMARY} colorunActive={styles.PRIMARY__CONTENT__COLOR} />
                            <Text style={{ fontSize: fontSizes.small, color: styles.PRIMARY__CONTENT__COLOR, marginLeft: dimensions.moderate(8) }}>
                                {t('user_argee_to')}
                                <Text
                                    style={{
                                        fontSize: fontSizes.small,
                                        color: styles.PRIMARY,
                                        fontWeight: fontWeights.medium,
                                        textDecorationLine: 'underline',
                                    }}
                                    onPress={() =>
                                        navigation.navigate(Screens.NEWS_DETAIL, {
                                            title: t('term_condition_iotp'),
                                            link: iOTPGuildContact.current.c3,
                                            c5: iOTPGuildContact.current.c2,
                                            c6: iOTPGuildContact.current.c3,
                                        })
                                    }
                                >
                                    {t('term_condition_iotp')}
                                </Text>
                            </Text>
                        </TouchableOpacity>
                    ) : null}

                    {isGetOtp ? (
                        <View style={{ alignItems: 'center', width: '100%' }}>
                            <ButtonCustom
                                isLoading={isLoadingGetOTP}
                                noPadding
                                style={{ backgroundColor: styles.PRIMARY, borderRadius: 8, marginTop: 40 }}
                                text={t('get_new_otp')}
                                onPress={handleGetNewOTP}
                            >
                                {/* <Text style={{ color: '#FFF', fontSize: fontSizes.normal, fontWeight: fontWeights.medium }}></Text> */}
                            </ButtonCustom>
                            {/* <TouchableOpacity style = {{marginTop: dimensions.moderate(8)}} onPress={deactiveIOTP}>
                        <Text style={{ color: '#F00', fontSize: fontSizes.normal, fontWeight: fontWeights.medium }}>{t('abort_iotp')}</Text>
                    </TouchableOpacity> */}
                            {glb_sv.configInfo.application_style.is_change_otp_type_screen_on ? (
                                <TouchableOpacity
                                    style={{ marginTop: dimensions.moderate(8) }}
                                    onPress={() =>
                                        navigation.navigate(Screens.CHANGE_OTP_TYPE, {
                                            functCallback: () => {
                                                console.log(TAG, 'CHANGE_OTP_TYPE functCallback')
                                                if (glb_sv.notifyOnesignal.userId) {
                                                    setGetOtp(false)
                                                    handleCheckiOTP()
                                                }
                                            },
                                        })
                                    }
                                >
                                    <Text style={{ color: styles.PRIMARY, fontSize: fontSizes.normal, fontWeight: fontWeights.bold }}>
                                        {t('change_otp_type')}
                                    </Text>
                                </TouchableOpacity>
                            ) : null}
                        </View>
                    ) : (
                        <View style={{ alignItems: 'center', width: '100%' }}>
                            <Button
                                block
                                disabled={!checkNote}
                                style={{ backgroundColor: checkNote ? styles.PRIMARY : styles.PRIMARY + '4d', borderRadius: 8, marginTop: 10 }}
                                transparent
                                onPress={handleRegister}
                            >
                                {loadingRegister ? <ActivityIndicator color="#FFF" /> : null}
                                <Text style={{ color: '#FFF', fontSize: fontSizes.normal, fontWeight: fontWeights.medium }}>
                                    {loadingRegister ? '...' : t('register')}
                                </Text>
                            </Button>

                            {glb_sv.configInfo.application_style.is_change_otp_type_screen_on ? (
                                <TouchableOpacity
                                    style={{ marginTop: dimensions.moderate(16) }}
                                    onPress={() =>
                                        navigation.navigate(Screens.CHANGE_OTP_TYPE, {
                                            functCallback: () => {
                                                console.log(TAG, 'CHANGE_OTP_TYPE functCallback')
                                                if (glb_sv.notifyOnesignal.userId) {
                                                    setGetOtp(false)
                                                    handleCheckiOTP()
                                                }
                                            },
                                        })
                                    }
                                >
                                    <Text style={{ color: styles.PRIMARY, fontSize: fontSizes.normal, fontWeight: fontWeights.bold }}>
                                        {t('change_otp_type')}
                                    </Text>
                                </TouchableOpacity>
                            ) : null}
                        </View>
                    )}
                    <View style={{ height: 50 }} />
                </View>
            ) : (
                <View style={{ backgroundColor: styles.PRIMARY__BG__COLOR, padding: dimensions.moderate(16), alignItems: 'center', flex: 1 }}>
                    <ErrorView refresh={handleCheckiOTP} title={textError} />
                </View>
            )}

            {visible ? (
                <Modal
                    isVisible={visible}
                    useNativeDriver={true}
                    avoidKeyboard
                    // onBackdropPress={hideModal} // Modal otp thì không cho đóng modal khi click outside
                    onBackButtonPress={hideModal}
                >
                    <View
                        style={{
                            backgroundColor: styles.PRIMARY__BG__COLOR,
                            paddingHorizontal: dimensions.moderate(16),
                            paddingTop: dimensions.vertical(16),
                            paddingBottom: dimensions.vertical(12),
                            justifyContent: 'center',
                            alignItems: 'center',
                            borderRadius: 12,
                            borderColor: 'rgba(0, 0, 0, 0.1)',
                        }}
                    >
                        <IconSvg.CodeIcon />
                        <Text
                            style={{
                                fontSize: fontSizes.xmedium,
                                color: styles.PRIMARY__CONTENT__COLOR,
                                marginTop: dimensions.vertical(16),
                                marginBottom: dimensions.vertical(16),
                                textAlign: 'center',
                            }}
                        >
                            {t('authen_register_device_main_otp')}
                        </Text>

                        <View style={[UI.row, { backgroundColor: styles.INPUT__BG__LOGIN, paddingVertical: dimensions.vertical(12) }]}>
                            <TextInput
                                editable={timeOTP > 0}
                                keyboardType="number-pad"
                                maxLength={6}
                                placeholder={t('otp_text_placeholder')}
                                placeholderTextColor={styles.SECOND__CONTENT__COLOR}
                                ref={otpRef}
                                secureTextEntry
                                style={{ ...UI.codeInput, color: styles.PRIMARY__CONTENT__COLOR, padding: 0 }}
                                textContentType="oneTimeCode"
                                value={code}
                                onChangeText={(value) => {
                                    setCode(value)
                                    setError('')
                                    if (value.length === 6) {
                                        sendAuthenOTP(value)
                                    }
                                }}
                            />
                            <View style={{ position: 'absolute', top: dimensions.vertical(16), right: dimensions.halfIndent }}>
                                <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.normal, padding: 0 }}>{timeOTP}s</Text>
                            </View>
                        </View>

                        <Text style={{ fontSize: fontSizes.verySmall, color: styles.ERROR__COLOR }}>{error}</Text>

                        <Text
                            style={{ fontSize: fontSizes.small, color: styles.PRIMARY, textAlign: 'center', paddingVertical: 12, opacity: timeOTP ? 0 : 1 }}
                            onPress={handleRegister}
                        >
                            {t('resend_authen_account')}
                        </Text>

                        <Button
                            block
                            disabled={!code}
                            style={{ backgroundColor: !code ? styles.PRIMARY + '4d' : styles.PRIMARY }}
                            transparent
                            onPress={sendAuthenOTP}
                        >
                            {loading ? (
                                <View style={{ flexDirection: 'row' }}>
                                    <ActivityIndicator color={'#FFF'} />
                                    <Text style={{ color: '#FFF', fontSize: fontSizes.medium, fontWeight: fontWeights.medium }}>...</Text>
                                </View>
                            ) : (
                                <Text
                                    style={{
                                        color: !code ? styles.SECOND__CONTENT__COLOR : '#FFF',
                                        fontSize: fontSizes.medium,
                                        fontWeight: fontWeights.medium,
                                    }}
                                >
                                    {t('authen')}
                                </Text>
                            )}
                        </Button>

                        <Button block transparent onPress={hideModal}>
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.medium, opacity: 0.34 }}>{t('common_Cancel')}</Text>
                        </Button>
                    </View>
                </Modal>
            ) : null}

            {modalAuthen ? (
                <ModalAuthen
                    authenSuccess={authenSuccess}
                    biometric={biometric}
                    handleShowBiometric={handleShowBiometric}
                    hideAuthen={hideAuthen}
                    isAuthenBiometric={isAuthenBiometric}
                    visible={modalAuthen}
                />
            ) : null}
        </Container>
    )
}

const UI = StyleSheet.create({
    codeInput: {
        flex: 1,
        fontSize: fontSizes.normal,
        fontWeight: fontWeights.semiBold,
    },
    row: {
        borderRadius: 200,
        flexDirection: 'row',
        marginTop: 10,
        paddingHorizontal: dimensions.halfIndent,
    },
    tab: {
        fontSize: fontSizes.small,
        fontWeight: fontWeights.medium,
        marginLeft: 0,
        marginRight: 0,
    },
})

export default ActiveOTPScreen
