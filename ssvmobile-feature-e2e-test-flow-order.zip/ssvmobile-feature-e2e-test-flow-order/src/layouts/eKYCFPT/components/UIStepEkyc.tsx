import React, { useContext, useMemo } from 'react'
import { useTranslation } from 'react-i18next'
import { StyleSheet, View } from 'react-native'
import StepIndicator from 'react-native-step-indicator'
import Svg, { Circle, G, Path } from 'react-native-svg'

import BACK from '../../../assets/images/common/ekyc_back.svg'
import FACE from '../../../assets/images/common/ekyc_face.svg'
import FRONT from '../../../assets/images/common/ekyc_front.svg'
import SERVICES from '../../../assets/images/common/ekyc_services.svg'
import STEP_01 from '../../../assets/images/common/ekyc_step_01.svg'
import STEP_02 from '../../../assets/images/common/ekyc_step_02.svg'
import STEP_03 from '../../../assets/images/common/ekyc_step_03.svg'
import STEP_04 from '../../../assets/images/common/ekyc_step_04.svg'
import USER from '../../../assets/images/common/ekyc_user.svg'
import IconBack from '../../../assets/images/common/ic_back.svg'
import { StoreContext } from '../../../store'
import { dimensions as dm } from '../../../styles'
import ekycService from '../ekycService'

export const UIStepEkyc = ({ switchStep, activeStep }) => {
    const { styles, theme, language } = useContext(StoreContext)
    const { t } = useTranslation()
    console.log('activeStep', activeStep)

    const renderStepIndicator = (params) => {
        // console.log('renderStepIndicator, params', params, activeStep);
        if (params.position === 0) {
            return (
                <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                    <STEP_01 fill={params.position <= activeStep + 1 ? '#8cd2f5' : '#D1D5DB'} height={32} width={32} />
                </View>
            )
        }
        if (params.position === 1) {
            return (
                <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                    <STEP_02 fill={params.position <= activeStep + 1 ? '#8cd2f5' : '#D1D5DB'} height={32} width={32} />
                </View>
            )
        }
        if (params.position === 2) {
            return (
                <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                    <STEP_03 fill={params.position <= activeStep + 1 ? '#8cd2f5' : '#D1D5DB'} height={30} width={30} />
                </View>
            )
        }
        if (params.position === 3) {
            return (
                <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                    <STEP_04 fill={params.position <= activeStep + 1 ? '#8cd2f5' : '#D1D5DB'} height={30} width={30} />
                </View>
            )
        }
        if (params.position === 4) {
            return (
                <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                    <USER fill={params.position <= activeStep + 1 ? '#8cd2f5' : '#D1D5DB'} height={32} width={32} />
                </View>
            )
        }
        if (params.position === 5) {
            return (
                <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                    <IconBack fill={params.position <= activeStep ? '#8cd2f5' : '#D1D5DB'} height={32} width={32} />
                </View>
            )
        }
    }

    const onPressStep = (step) => {
        console.log('activeStep >>> SAVE_DATA >>> check', { activeStep, step })
        // if ([3, 4].includes(activeStep) && [3, 4].includes(e)) {
        //     ekycService.ekycEvent.next({ type: 'SAVE_DATA', step: e + 1 })
        //     switchStep.goTo(e + 1)
        //     return
        // }
        return
    }

    const secondIndicatorStyles = useMemo(() => {
        return {
            stepIndicatorSize: 48,
            currentStepIndicatorSize: 48,
            separatorStrokeWidth: 2,
            currentStepStrokeWidth: 0,
            stepStrokeCurrentColor: '#8cd2f5',
            stepStrokeWidth: 0,
            separatorStrokeFinishedWidth: 2,
            stepStrokeFinishedColor: '#8cd2f5',
            stepStrokeUnFinishedColor: '#aaaaaa',
            separatorFinishedColor: '#8cd2f5',
            separatorUnFinishedColor: '#aaaaaa',
            stepIndicatorFinishedColor: styles.PRIMARY__BG__COLOR,
            stepIndicatorUnFinishedColor: styles.PRIMARY__BG__COLOR,
            stepIndicatorCurrentColor: styles.PRIMARY__BG__COLOR,
            stepIndicatorLabelFontSize: 13,
            currentStepIndicatorLabelFontSize: 13,
            stepIndicatorLabelCurrentColor: '#8cd2f5',
            stepIndicatorLabelFinishedColor: '#ffffff',
            stepIndicatorLabelUnFinishedColor: '#aaaaaa',
            labelColor: '#999999',
            labelSize: 13,
            currentStepLabelColor: '#8cd2f5',
        }
    }, [styles])

    return (
        <View style={UI.stepIndicator}>
            <StepIndicator
                currentPosition={activeStep + 1}
                customStyles={secondIndicatorStyles}
                renderStepIndicator={renderStepIndicator}
                stepCount={4}
                onPress={onPressStep}
                renderLabel={() => <View />}
                // renderStepIndicator={() => <IconBack fill={activeStep >= 0 ? styles.PRIMAY : styles} width={32} height={32} />}
                labels={[t(''), t(''), t(''), t(''), t(''), t('')]}
            />
        </View>
    )
}
const UI = StyleSheet.create({
    Button: {
        alignItems: 'center',
        borderRadius: 8,
        height: dm.moderate(20),
        justifyContent: 'center',
        width: dm.moderate(20),
    },
    Row_Modal: {
        height: dm.vertical(24),
        marginVertical: dm.vertical(16),
    },
    container: {
        backgroundColor: '#ffffff',
        flex: 1,
    },
    page: {
        flex: 1,
        flexDirection: 'column',
    },
    stepIndicator: {
        marginBottom: 0,
        marginTop: dm.vertical(0),
        // marginVertical: 50,
    },
})
