import React, { useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import ToastGlobal from 'react-native-toast-message'
import ModalController from '@mts-components/appModal/modalControlller'
import Analytics, { EkycAnalyticEvents } from '@mts-utils/TrackingData/Analytics'
import { useNavigation } from '@react-navigation/native'
import isEmpty from 'lodash/isEmpty'

import { StoreContext } from '../../../store'
import { IconSvg } from '../../../styles'
import { glb_sv, reqFunct, Screens } from '../../../utils'
import sendRequest from '../../../utils/sendRequest'
import { configUIEkyc } from '../config'
import ekycService from '../ekycService'
import { EKYC_TRACKING_STEP, useSaveCurrentStep } from '../hooks/useSaveCurrentStep'
import { getApiFpt } from '../middleProcess'

const ServiceInfo: IServiceInfo = {
    CHECK_EMAIL_EXITS: {
        reqFunct: reqFunct.CHECK_EMAIL_EXITS,
        WorkerName: 'FOSqAccount',
        ServiceName: 'FOSqAccount_Common_3',
        Operation: 'Q',
    },
    UPDATE_EMAIL_FOR_USER: {
        reqFunct: reqFunct.UPDATE_EMAIL_FOR_USER,
        WorkerName: 'FOSxID02',
        ServiceName: 'FOSxID02_UserInformation',
        Operation: 'U',
    },
    GET_INSTITUATION: {
        reqFunct: reqFunct.GET_INSTITUATION,
        WorkerName: 'FOSqAccount',
        ServiceName: 'FOSqAccount_Common_1',
        Operation: 'Q',
    },
    GET_USER_INFORMATION_EKYC: {
        reqFunct: reqFunct.GET_USER_INFORMATION_EKYC,
        WorkerName: 'FOSqID02',
        ServiceName: 'FOSqID02_UserInformation',
        ClientSentTime: '0',
        Operation: 'Q',
    },
}

export const useFirstStep = ({ switchStep }) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()
    const navigation = useNavigation()
    const [hintCommonEmail, setHintCommonEmail] = useState(false)
    const [checkMargin, setCheckMargin] = useState(ekycService?.additionalData?.checkMargin)
    // -----
    const [customerPhone, setCustomerPhone] = useState('')
    const [customerEmail, setCustomerEmail] = useState('')
    const { saveData } = useSaveCurrentStep()
    // -------
    const onChangeCheckMargin = (isCheck: boolean) => {
        ekycService.additionalData.checkMargin = isCheck
        setCheckMargin(isCheck)
    }

    const getUserInfoForGetPhoneNumber = () => {
        // Mục đích lấy số điện thoại
        const InputParams = ['info']
        sendRequest(
            ServiceInfo.GET_USER_INFORMATION_EKYC,
            InputParams,
            (_, message) => {
                if (Number(message.Result) === 0) {
                    // navigation.navigate(Screens.ALERT_MODAL, {
                    // icon: null,
                    // title: t('common_notify').toLocaleUpperCase(),
                    // colorTitle: styles.EKYC__COLOR,
                    // content: t('ekyc_alert_phone_require'),
                    // titleOK: t('common_alert_agree').toLocaleUpperCase(),
                    // typeColor: styles.EKYC__COLOR,
                    //     // @ts-expect-error
                    //     linkCallback: () => navigation.replace(Screens.HOME, {}),
                    //     showCancel: false,
                    // })
                    ModalController.showModal({
                        icon: null,
                        title: t('common_notify').toLocaleUpperCase(),
                        colorTitle: styles.EKYC__COLOR,
                        content: t('ekyc_alert_phone_require'),
                        titleOK: t('common_alert_agree').toLocaleUpperCase(),
                        typeColor: styles.EKYC__COLOR,
                        // @ts-expect-error
                        linkCallback: () => navigation.replace(Screens.HOME, {}),
                        showCancel: false,
                    })
                } else {
                    let jsondata
                    if (!message.Data) return
                    try {
                        jsondata = JSON.parse(glb_sv.filterStrBfParse(message.Data))
                        const userData = jsondata[0] || {}
                        // -------
                        if (userData.c35) {
                            setCustomerPhone(userData.c35)
                            if (userData.c32) {
                                setCustomerEmail(userData?.c32?.trim())
                            }
                        } else {
                            // navigation.navigate(Screens.ALERT_MODAL, {
                            //     icon: null,
                            //     title: t('common_notify').toLocaleUpperCase(),
                            //     colorTitle: styles.EKYC__COLOR,
                            //     content: t('ekyc_alert_phone_require'),
                            //     titleOK: t('common_alert_agree').toLocaleUpperCase(),
                            //     typeColor: styles.EKYC__COLOR,
                            //     // @ts-expect-error
                            //     linkCallback: () => navigation.replace(Screens.HOME, {}),
                            //     showCancel: false,
                            // })
                            ModalController.showModal({
                                icon: null,
                                title: t('common_notify').toLocaleUpperCase(),
                                colorTitle: styles.EKYC__COLOR,
                                content: t('ekyc_alert_phone_require'),
                                titleOK: t('common_alert_agree').toLocaleUpperCase(),
                                typeColor: styles.EKYC__COLOR,
                                // @ts-expect-error
                                linkCallback: () => navigation.replace(Screens.HOME, {}),
                                showCancel: false,
                            })
                        }
                    } catch (err) {
                        console.log('handleGetAccoutInfo -> err', err)
                        return
                    }
                }
            },
            true,
            (timeoutInfo: any) => {
                console.log('timeout getUserInfoForGetPhoneNumber', timeoutInfo)
            },
        )
    }
    // -----
    useEffect(() => {
        getApiFpt()
        getUserInfoForGetPhoneNumber()
    }, [])

    //---- Logic là khi check ok thì save luôn
    const checkAndSaveDataBeforeStep02 = async () => {
        // Bước 1 cần check:
        // - Số điện thoại
        // - Email
        // - Broker/ Remissier (nếu có)
        // - Referal (nếu có)

        if (customerPhone.trim() === '') {
            ToastGlobal.show({
                type: 'warning',
                text2: t('common_plz_input_your_mobile_number'),
            })
            return
        }
        // ------
        if (customerEmail.trim() === '') {
            ToastGlobal.show({
                type: 'warning',
                text2: t('common_plz_input_your_email_address'),
            })
            return
        }
        // ------
        if (!validateEmail(customerEmail)) {
            ToastGlobal.show({
                type: 'warning',
                text2: t('common_plz_input_your_email_address_validate'),
            })
            return
        }
        // ------
        // ---- Save data before next step
        ekycService.userData.phone = customerPhone
        ekycService.userData.email = customerEmail
        // ---------- Service Check -------
        // Check hết các thông tin trên, check email xong thì mới next bước kế tiếp
        checkEmailExits()
        // ----------------------------------
    }

    const validateEmail = (email) => {
        return email.match(
            /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
        )
    }

    const checkEmailExits = () => {
        const inval = ['CHK_EMAIL', customerEmail]
        sendRequest(ServiceInfo.CHECK_EMAIL_EXITS, inval, handleCheckEmailExits)
    }

    const handleCheckEmailExits = (reqInfoMap, message: IServiceRespone) => {
        if (Number(message.Result) === 0) {
        } else {
            let jsondata: IServiceResponeData[] = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {
                return
            }
            const emailExitedInfo = jsondata[0] || {}
            if (emailExitedInfo.c0 === 'Y') {
                // navigation.navigate(Screens.ALERT_MODAL, {
                // icon: <IconSvg.ErrorIcon color={styles.EKYC__COLOR} />,
                // title: t('common_notify').toLocaleUpperCase(),
                // colorTitle: styles.EKYC__COLOR,
                // content: message.Message,
                // typeColor: styles.EKYC__COLOR,
                // titleOK: t('common_alert_agree').toLocaleUpperCase(),
                // })
                ModalController.showModal({
                    icon: <IconSvg.ErrorIcon color={styles.EKYC__COLOR} />,
                    title: t('common_notify').toLocaleUpperCase(),
                    colorTitle: styles.EKYC__COLOR,
                    content: message.Message,
                    typeColor: styles.EKYC__COLOR,
                    titleOK: t('common_alert_agree').toLocaleUpperCase(),
                })
            } else {
                updateEmailForUser()
            }
        }
    }

    const updateEmailForUser = async () => {
        const inval = ['email_ekyc', customerEmail]
        sendRequest(ServiceInfo.UPDATE_EMAIL_FOR_USER, inval, (_, message) => {
            if (Number(message.Result) === 0) {
                // navigation.navigate(Screens.ALERT_MODAL, {
                // icon: <IconSvg.ErrorIcon color={styles.EKYC__COLOR} />,
                // title: t('common_notify').toLocaleUpperCase(),
                // colorTitle: styles.EKYC__COLOR,
                // content: message.Message, // t('ekyc_email_already_exits'),
                // typeColor: styles.EKYC__COLOR,
                // titleOK: t('common_alert_agree').toLocaleUpperCase(),
                // })
                ModalController.showModal({
                    icon: <IconSvg.ErrorIcon color={styles.EKYC__COLOR} />,
                    title: t('common_notify').toLocaleUpperCase(),
                    colorTitle: styles.EKYC__COLOR,
                    content: message.Message, // t('ekyc_email_already_exits'),
                    typeColor: styles.EKYC__COLOR,
                    titleOK: t('common_alert_agree').toLocaleUpperCase(),
                })
            } else {
                // Update lại email khách hàng
                ekycService.userData.email = customerEmail
                saveData(ekycService, EKYC_TRACKING_STEP.FIRST_STEP_DONE)

                // Update email ok thì next step
                switchStep.next()
                Analytics.logEvent(EkycAnalyticEvents.ekyc_step_one_register_information)
                glb_sv.sendEKYCLogNewTracking({
                    sEKYCLog: EkycAnalyticEvents.ekyc_step_one_register_information,
                    eKYCType: '3',
                    reason: 'Xác nhận đăng ký thông tin EKYC',
                    ekycStep: '1',
                })
                let jsondata: IServiceResponeData[] = []
                try {
                    jsondata = message.Data ? JSON.parse(message.Data) : []
                } catch (err) {
                    return
                }
            }
        })
    }

    const onChangeFATCA = (fatca: '0' | '1' | '2') => {
        // --- save FATCA: Yếu tố Hoa kỳ Y/N
        ekycService.additionalData.checkFATCADetail = fatca
        ekycService.additionalData.checkFATCA = fatca === '0' || fatca === '1'
    }

    return {
        styles,
        t,
        customerPhone,
        hintCommonEmail,
        customerEmail,
        setHintCommonEmail,
        setCustomerEmail,
        onChangeFATCA,
        checkAndSaveDataBeforeStep02,
        onChangeCheckMargin,
        checkMargin,
    }
}
