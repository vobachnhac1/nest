import React, { useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { InteractionManager, RefreshControl, StyleSheet, View } from 'react-native'
import Modal from 'react-native-modal'
import StepIndicator from 'react-native-step-indicator'
import Svg, { Circle, Path } from 'react-native-svg'
import ToastGlobal from 'react-native-toast-message'
import ModalController from '@mts-components/appModal/modalControlller'
import moment from 'moment'
import { Button, Container, Content, Tab, Tabs, Text } from 'native-base'

import HeaderComponent from '../../../components/header'
import { ButtonCustom, ModalContent, RowDataModal } from '../../../components/trading-component'
import { StoreContext } from '../../../store'
import { StoreTrading } from '../../../store-trading'
import { dimensions as dm, fontSizes as fs, fontWeights, IconSvg } from '../../../styles'
import { glb_sv, reqFunct, Screens, wait } from '../../../utils'
import sendRequest from '../../../utils/sendRequest'
import StepOne from './step-one'
import StepTwo from './step-two'

// Khai báo ServiceInfo (nếu có)
const ServiceInfo = {
    CONFIRM_RENEW_MARGIN_CONTRACT: {
        reqFunct: reqFunct.CONFIRM_RENEW_MARGIN_CONTRACT,
        WorkerName: 'FOSxMargin',
        ServiceName: 'FOSxMargin_1404_1',
        Operation: 'I',
    },
}

const initErrCtrl = [
    {
        error: false,
        message: 'input_renew_value',
    },
]
// Khai báo component
const RenewMarginContract = ({ navigation }) => {
    const { styles } = useContext(StoreContext)
    const { userInfo, setUserInfo } = useContext(StoreTrading)
    const { t } = useTranslation()
    // All orther state
    const [activeStep, setActiveStep] = useState(0)
    const [isOpenModal, setIsOpenModal] = useState(false)
    const [refreshing, setRefreshing] = React.useState(false)

    // Start define all bussiness state
    const [listContractRenew, setListContractRenew] = useState([])
    const [contractSelect, setContractSelect] = useState({})

    const [dateRenew, setDateRenew] = useState(null)
    const [errCtrl, setErrCtrl] = useState(initErrCtrl)

    const flag = true
    useEffect(() => {
        const dataSub = glb_sv.objShareGlb.acntNoInfo.find((e) => e.AcntNo + e.SubNo === userInfo.actn_curr + userInfo.sub_curr)
        if (dataSub) {
            if (!dataSub.MarginYN) {
                if (userInfo.sub_list.includes('01')) {
                    setUserInfo({
                        ...userInfo,
                        sub_curr: '01',
                    })
                    glb_sv.userInfo.sub_curr = '01'
                    glb_sv.userInfoAccount = {
                        ...userInfo,
                        sub_curr: '01',
                    }
                }
            }
        }
    }, [flag])

    const onRefresh = React.useCallback(() => {
        setRefreshing(true)
        wait(300).then(() => setRefreshing(false))
    }, [])

    const switchStep = {
        goTo: (step) => setActiveStep(step),
        next: () => setActiveStep(activeStep + 1),
        prev: () => {
            setDateRenew(null)
            setActiveStep(activeStep - 1)
        },
        submit: () => confirmRenewContractMargin(),
        onFinish: () => _checkValueBfSend(),
        getCurrent: () => {
            return activeStep
        },
    }

    const _validateValue = (inputIndex) => {
        const newErrCtrl = [...initErrCtrl]

        if (inputIndex === 0) newErrCtrl[0].error = Number(dateRenew) <= 0 || !dateRenew
        if (!inputIndex && inputIndex !== 0) {
            newErrCtrl[0].error = Number(dateRenew) <= 0
        }
        setErrCtrl(newErrCtrl)
    }

    const hideModal = () => {
        setIsOpenModal(false)
    }
    // const _resetInput = () => {
    //     setDateRenew(null)
    // }
    const _onClickBackButton = () => {
        if (activeStep > 0) switchStep.prev()
        if (activeStep === 0) navigation.goBack()
    }

    const _checkValueBfSend = () => {
        hideModal()
        _validateValue()
        if (errCtrl.filter((item) => item.error === true).length === 0) {
            //----------------
            const isAuthenOTP = glb_sv.checkOtp(navigation, () => {
                setTimeout(() => {
                    setIsOpenModal((prev) => true)
                }, 100)
            })
            if (isAuthenOTP) {
                setIsOpenModal(true)
            }
            //---------------
        }
        return
    }

    // -------------------------------------------   Khai báo các hàm gửi (request) lên server
    const confirmRenewContractMargin = () => {
        setIsOpenModal(false)
        InteractionManager.runAfterInteractions(() => {
            if (!glb_sv.checkOtp(navigation, confirmRenewContractMargin)) return
            const inputParams = [contractSelect.c0, contractSelect.c1, String(dateRenew)]

            ServiceInfo.CONFIRM_RENEW_MARGIN_CONTRACT.AcntNo = userInfo.actn_curr
            ServiceInfo.CONFIRM_RENEW_MARGIN_CONTRACT.SubNo = userInfo.sub_curr
            sendRequest(ServiceInfo.CONFIRM_RENEW_MARGIN_CONTRACT, inputParams, handleConfirmRenewContractMargin)
        })
    }

    // -------------------------------------------   Khai báo các hàm gửi (request) và nhận (handle respone) dữ liệu từ server
    const handleConfirmRenewContractMargin = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            if (message.Code == 'XXXXX5' || message.Code === '080063' || message.Code === '010012') {
                // navigation.navigate(Screens.ALERT_MODAL, {
                // icon: <IconSvg.ErrorIcon color={styles.WARN__COLOR} />,
                // title: t('common_notify'),
                // content: t('request_hanlde_not_success_try_again'),
                // typeColor: styles.WARN__COLOR,
                // })
                ModalController.showModal({
                    icon: <IconSvg.ErrorIcon color={styles.WARN__COLOR} />,
                    title: t('common_notify'),
                    content: t('request_hanlde_not_success_try_again'),
                    typeColor: styles.WARN__COLOR,
                })
            } else if (glb_sv.otpCases.includes(message.Code)) {
                glb_sv.objShareGlb.sessionInfo.Otp = ''

                let data
                try {
                    data = JSON.parse(message.Data)[0]
                } catch (error) {
                    return
                }

                const otp_Type = Number(data.c1)
                const expTimeOtp = Number(data.c2)
                let reqOtpMessage = 'OTP'
                if (Number(data.c1) === 2) {
                    //-- dạng thẻ ma trận
                    reqOtpMessage = 'OTP ' + data.c3
                }
                navigation.navigate(Screens.OTP_MODAL, {
                    time: expTimeOtp,
                    type: reqOtpMessage,
                    hasOTP: false,
                    otp_Type,
                    msg: message.Message,
                    // functCallback: showModalAction
                })
            } else {
                // navigation.navigate(Screens.ALERT_MODAL, {
                // icon: <IconSvg.ErrorIcon color={styles.WARN__COLOR} />,
                // title: t('common_notify'),
                // content: message.Message,
                // typeColor: styles.WARN__COLOR,
                // })
                ModalController.showModal({
                    icon: <IconSvg.ErrorIcon color={styles.WARN__COLOR} />,
                    title: t('common_notify'),
                    content: message.Message,
                    typeColor: styles.WARN__COLOR,
                })
            }
        } else {
            ToastGlobal.show({
                type: 'success',
                text2: message.Message, //t('pass_confirm_not_correct'),
            })
            switchStep.goTo(0)
        }
    }
    const renderStepIndicator = (params) => {
        if (params.position === 0) {
            return (
                <View>
                    <Svg fill="none" height={30} viewBox="0 0 30 30" width={30} xmlns="http://www.w3.org/2000/svg">
                        <Circle cx={15} cy={15} fill={params.position <= switchStep.getCurrent() ? '#60B44A' : '#D1D5DB'} r={15} />
                        <Path
                            d="M15 21.916l1.469-.339-1.13-1.13-.34 1.47zM14.71 20.949l.243-1.053.002-.008a.493.493 0 01.004-.013l.004-.012a.176.176 0 01.015-.032.27.27 0 01.008-.013l.005-.008a.21.21 0 01.015-.02l.01-.01.004-.005 3.275-3.275c-.914-1.88-2.605-3-4.545-3-1.423 0-2.737.609-3.7 1.714C9.078 16.328 8.531 17.88 8.5 19.6c.574.289 2.93 1.401 5.249 1.401.32 0 .641-.018.96-.051zM15.548 19.951l3.889-3.888 1.414 1.414-3.889 3.888-1.414-1.414zM13.75 13a2.5 2.5 0 100-5 2.5 2.5 0 000 5zM21.5 16.416a1 1 0 00-1.707-.707l1.414 1.414a.994.994 0 00.293-.707z"
                            fill="#fff"
                        />
                    </Svg>
                </View>
            )
        }
        if (params.position === 1) {
            return (
                <View>
                    <Svg fill="none" height={30} viewBox="0 0 30 30" width={30} xmlns="http://www.w3.org/2000/svg">
                        <Circle cx={15} cy={15} fill={params.position <= switchStep.getCurrent() ? '#60B44A' : '#D1D5DB'} opacity={1} r={15} />
                        <Path
                            d="M15 8.5A6.507 6.507 0 008.5 15c0 3.584 2.916 6.5 6.5 6.5s6.5-2.916 6.5-6.5-2.916-6.5-6.5-6.5zm-1.188 9.762l-2.518-2.8.743-.668 1.75 1.944 4.15-4.942.767.642-4.892 5.824z"
                            fill={'#fff'}
                            // opacity={0.1}
                        />
                    </Svg>
                </View>
            )
        }
    }

    return (
        <Container>
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft
                leftButtonLink={_onClickBackButton}
                navigation={navigation}
                title={t('margin_postpone_contract')}
                titleAlgin="flex-start"
                transparent
            />
            {userInfo.sub_list.length > 1 ? (
                <Content
                    refreshControl={
                        <RefreshControl
                            refreshing={refreshing}
                            onRefresh={onRefresh} // title={t('pull_refresh')}
                            // titleColor={styles.PRIMARY__CONTENT__COLOR}
                            tintColor={styles.PRIMARY__CONTENT__COLOR}
                        />
                    }
                    style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}
                >
                    <View style={UI.stepIndicator}>
                        <StepIndicator
                            customStyles={secondIndicatorStyles}
                            labels={[t('select_contract_renew'), t('trading_confirm')]}
                            stepCount={2}
                            currentPosition={activeStep}
                            // onPress={switchStep.goTo}
                            renderStepIndicator={renderStepIndicator}
                        />
                    </View>
                    <Tabs locked page={activeStep} renderTabBar={() => <View />} style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
                        <Tab heading={<View />} style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
                            <StepOne
                                listContractRenew={listContractRenew}
                                navigation={navigation}
                                refreshing={refreshing}
                                setContractSelect={setContractSelect}
                                setListContractRenew={setListContractRenew}
                                switchStep={switchStep}
                            />
                        </Tab>
                        <Tab heading={<View />} style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
                            <StepTwo
                                _validateValue={_validateValue}
                                contractSelect={contractSelect}
                                dateRenew={dateRenew}
                                errCtrl={errCtrl}
                                setDateRenew={setDateRenew}
                                setErrCtrl={setErrCtrl}
                                switchStep={switchStep}
                            />
                        </Tab>
                    </Tabs>
                </Content>
            ) : (
                <Content style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
                    <View
                        style={{
                            flex: 1,
                            flexDirection: 'column',
                            alignItems: 'center',
                            justifyContent: 'center',
                            height: dm.HIEGHT - 56,
                            textAlign: 'center',
                        }}
                    >
                        <View
                            style={{
                                marginBottom: dm.moderate(100),
                            }}
                        >
                            <View style={{ textAlign: 'center', justifyContent: 'center', alignItems: 'center' }}>
                                <Svg fill="none" height="84" viewBox="0 0 43 64" width="63" xmlns="http://www.w3.org/2000/svg">
                                    <Path
                                        d="M36.9 17.1998V33.7998H32.2V17.1998C32.2 10.8998 27.4 5.7998 21.5 5.7998C15.6 5.7998 10.8 10.8998 10.8 17.2998V33.7998H6.10001V17.1998C6.10001 8.1998 13 0.799805 21.5 0.799805C30 0.799805 36.9 8.1998 36.9 17.1998Z"
                                        fill="#C7C7C7"
                                    />
                                    <Path d="M6.10001 21.5L10.8 21.7V33.8H6.10001V21.5Z" fill="#A6A6A6" />
                                    <Path d="M36.9 22.7996V33.7996H32.2V22.5996L36.9 22.7996Z" fill="#A6A6A6" />
                                    <Path d="M42.9 24.3999H0.100006V63.2999H42.9V24.3999Z" fill="#FFC727" />
                                    <Path d="M42.9 24.3999H21.5V63.2999H42.9V24.3999Z" fill="black" opacity="0.1" />
                                    <Path
                                        d="M23.3 45.1997L25.1 53.6997H17.5L19.3 45.1997C18.2 44.4997 17.5 43.2997 17.5 41.9997C17.5 39.8997 19.2 38.1997 21.3 38.1997C23.4 38.1997 25.1 39.8997 25.1 41.9997C25.1 43.3997 24.4 44.4997 23.3 45.1997Z"
                                        fill="#263238"
                                    />
                                </Svg>
                            </View>
                            <Text
                                style={{
                                    textAlign: 'center',
                                    marginTop: 20,
                                    fontSize: fs.medium,
                                    fontWeight: fontWeights.medium,
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                }}
                            >
                                {t('service_is_not_available')}
                            </Text>
                            <Text style={{ textAlign: 'center', color: styles.SECOND__CONTENT__COLOR, fontSize: fs.verySmall }}>
                                {t('service_is_not_available_note')}
                            </Text>
                            <Button
                                style={{
                                    alignSelf: 'center',
                                    marginTop: dm.moderate(10),
                                    backgroundColor: styles.PRIMARY,
                                    borderRadius: 8,
                                    paddingHorizontal: 10,
                                }}
                                onPress={() => navigation.goBack()}
                            >
                                <Text>{t('common_back')}</Text>
                            </Button>
                        </View>
                    </View>
                </Content>
            )}

            {/* **************************************** Modal submit ******************************************/}
            {isOpenModal ? (
                <Modal isVisible={isOpenModal} useNativeDriver={true} onBackButtonPress={hideModal} onBackdropPress={hideModal}>
                    <ModalContent
                        iconComponent={
                            <Svg fill="none" height={32} viewBox="0 0 33 32" width={33} xmlns="http://www.w3.org/2000/svg">
                                <Path d="M4.60667 0.125L0.185547 4.54612H4.60667V0.125Z" fill="#2ECC71" />
                                <Path
                                    d="M32.0524 6.73597L30.7266 5.41016L28.4714 7.66541C28.1902 7.65647 27.9062 7.75797 27.6921 7.97209L26.5059 9.15834L28.3042 10.9567L29.4905 9.77041C29.6897 9.57128 29.7993 9.30653 29.7993 9.02497C29.7993 9.01347 29.798 9.00216 29.7976 8.99072L32.0524 6.73597Z"
                                    fill="#2ECC71"
                                />
                                <Path d="M14.1348 21.5254L25.1749 10.4853L26.973 12.2834L15.9329 23.3235L14.1348 21.5254Z" fill="#2ECC71" />
                                <Path d="M12.9429 22.9844L11.8164 25.6474L14.4795 24.521L12.9429 22.9844Z" fill="#2ECC71" />
                                <Path
                                    d="M9.9738 28.4621L8.37836 26.867L6.95511 28.2903H3.04811V26.4153H6.17848L8.37836 24.2153L9.79023 25.6272L11.552 21.4621L14.3313 18.6829H4.15786V16.8079H16.2063L18.3147 14.6995H4.15786V12.8245H20.1897L24.3016 8.71262V0H6.48073V6.42019H0.0605469V32H24.3015V17.6126L16.0021 25.9122L9.9738 28.4621ZM6.96242 8.84106H17.3998V10.7161H6.96242V8.84106Z"
                                    fill="#2ECC71"
                                />
                            </Svg>
                        }
                        title={t('confirm_send_renew_inform')}
                        type="confirm"
                    >
                        <RowDataModal textLeft={t('contract_num')} textRight={contractSelect.c0} />
                        <RowDataModal textLeft={t('date_loan')} textRight={moment(contractSelect.c3, 'DDMMYYYY').format('DD/MM/YYYY')} />
                        <RowDataModal textLeft={t('date_due')} textRight={moment(contractSelect.c4, 'DDMMYYYY').format('DD/MM/YYYY')} />
                        <RowDataModal textLeft={t('date_renew')} textRight={dateRenew} />

                        <ButtonCustom text={t('common_button_confirm')} type="confirm" onPress={() => switchStep.submit()} />
                        <ButtonCustom last text={'common_Cancel'} type="back" onPress={hideModal} />
                    </ModalContent>
                </Modal>
            ) : null}
        </Container>
    )
}

export default RenewMarginContract

const UI = StyleSheet.create({
    Button: {
        alignItems: 'center',
        borderRadius: 8,
        height: dm.moderate(28),
        justifyContent: 'center',
        width: dm.moderate(28),
    },
    Row_Modal: {
        height: dm.vertical(12),
        marginVertical: dm.vertical(16),
    },
    container: {
        backgroundColor: '#ffffff',
        flex: 1,
    },
    page: {
        flex: 1,
        flexDirection: 'column',
    },
    stepIndicator: {
        marginBottom: dm.vertical(8),
        marginTop: dm.vertical(24),
        // marginVertical: 50,
    },
})

const secondIndicatorStyles = {
    stepIndicatorSize: 32,
    currentStepIndicatorSize: 32,
    separatorStrokeWidth: 3,
    currentStepStrokeWidth: 4,
    stepStrokeCurrentColor: '#60B44A',
    stepStrokeWidth: 2,
    separatorStrokeFinishedWidth: 4,
    stepStrokeFinishedColor: '#60B44A',
    stepStrokeUnFinishedColor: '#aaaaaa',
    separatorFinishedColor: '#60B44A',
    separatorUnFinishedColor: '#aaaaaa',
    stepIndicatorFinishedColor: '#60B44A',
    stepIndicatorUnFinishedColor: '#ffffff',
    stepIndicatorCurrentColor: '#ffffff',
    stepIndicatorLabelFontSize: 13,
    currentStepIndicatorLabelFontSize: 13,
    stepIndicatorLabelCurrentColor: '#60B44A',
    stepIndicatorLabelFinishedColor: '#ffffff',
    stepIndicatorLabelUnFinishedColor: '#aaaaaa',
    labelColor: '#999999',
    labelSize: 13,
    currentStepLabelColor: '#60B44A',
}
