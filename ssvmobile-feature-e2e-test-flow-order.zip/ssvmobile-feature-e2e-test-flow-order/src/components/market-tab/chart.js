import React, { memo } from 'react'
import moment from 'moment'

import { glb_sv } from '../../utils'
import LightChart from '../light-chart'

function SimpleChart({ data, color, activeIndex, theme }) {
    const DATA_LINE = []
    const DATA_VOLUME = []
    const DATA_REF = []
    if (glb_sv.timeServer) {
        DATA_REF.push({ value: activeIndex.ref, time: dateToChartTimeMinute(moment(glb_sv.timeServer + '-09:00:00', 'YYYYMMDD-HH:mm:ss').toDate()) })
        DATA_REF.push({ value: activeIndex.ref, time: dateToChartTimeMinute(moment(glb_sv.timeServer + '-15:00:00', 'YYYYMMDD-HH:mm:ss').toDate()) })
    }
    const cvData = glb_sv.chartConvert2Minutes(data)
    for (let index = 0; index < cvData.length; index++) {
        const timeStamp = dateToChartTimeMinute(new Date(cvData[index].time))
        DATA_LINE.push({ value: cvData[index].indexValue, time: timeStamp })
        DATA_VOLUME.push({
            value: cvData[index].volume,
            time: timeStamp,
            color: 'rgba(0, 150, 136, 0.5)',
        })
    }

    return <LightChart DATA_LINE={DATA_LINE} DATA_VOLUME={DATA_VOLUME} initScript={intraChart(DATA_LINE, DATA_VOLUME, DATA_REF, color, theme)} theme={theme} />
}
export default memo(SimpleChart, areEqual)

function areEqual(prevProps, nextProps) {
    /* Trả về true nếu nextProps bằng prevProps, ngược lại trả về false */
    if (prevProps.color === nextProps.color && prevProps.theme === nextProps.theme && prevProps.data.length === nextProps.data.length) return true
    else return false
}

const intraChart = (DATA_LINE, DATA_VOLUME, DATA_REF, color, theme) => `
    window.chartIntra = true;
    const chartElement = document.createElement('div');
    const chart = LightweightCharts.createChart(chartElement, {
        width: screen.width,
        height: 250,
        priceScale: {
            borderVisible: false,
        },
        rightPriceScale: {
            scaleMargins: {
                top: 0.3,
                bottom: 0.25,
            },
            borderVisible: false,
        },
        timeScale: {
            timeVisible: true,
            secondsVisible: true,
            borderVisible: false,
        },
        layout: ${
            theme.includes('DARK')
                ? JSON.stringify({
                      backgroundColor: 'transparent',
                      textColor: '#d1d4dc',
                  })
                : JSON.stringify({
                      backgroundColor: 'transparent',
                  })
        },
    grid: ${
        theme.includes('DARK')
            ? JSON.stringify({
                  vertLines: {
                      color: 'rgba(42, 46, 57, 0.6)',
                  },
                  horzLines: {
                      color: 'rgba(42, 46, 57, 0.6)',
                  },
              })
            : JSON.stringify({
                  vertLines: {
                      color: '#d5d1c699',
                  },
                  horzLines: {
                      color: '#d5d1c699',
                  },
              })
    },
        handleScroll: false,
        handleScale: false
    });
    
    document.body.appendChild(chartElement);
    
    const areaSeries = chart.addAreaSeries({
        topColor: 'rgba(33, 150, 243, 0.56)',
        bottomColor: 'rgba(33, 150, 243, 0.04)',
        lineColor: 'rgba(33, 150, 243, 1)',
        lineWidth: 1,
    });
  
    const volumeSeries = chart.addHistogramSeries({
        color: '#26a69a',
        lineWidth: 1,
        priceFormat: {
            type: 'volume',
        },
        overlay: true,
        scaleMargins: {
            top: 0.2,
            bottom: 0.02,
        },
    });

    const refSeries = chart.addLineSeries({
        color: '#FFC107',
        lineWidth: 1,
        crosshairMarkerVisible: false
    });
    window.chart = chart
    window.areaSeries = areaSeries
    window.volumeSeries = volumeSeries
    window.refSeries = refSeries
    window.areaSeries.setData(${JSON.stringify(DATA_LINE)});
    window.volumeSeries.setData(${JSON.stringify(DATA_VOLUME)});
    window.refSeries.setData(${JSON.stringify(DATA_REF)});
  
    window.chart.applyOptions({
        localization: {
            priceFormatter: function(price) { return formatNumber(price) },
        },
    });
    chart.timeScale().fitContent();
    true;
`

function dateToChartTimeMinute(date) {
    return Date.UTC(date.getFullYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes(), date.getSeconds(), 0) / 1000
}
