/**
 * Script optimize and automation build
 * @param
 * 1. yarn prebuild uat 3.99.10 1 ssv704 "Fix lỗi và thêm mới nhiều tính năng"
 * 2. yarn prebuild prod 3.99.10 1 ssv704 "Fix lỗi và thêm mới nhiều tính năng"
 *
 * yarn prebuild 081 t [version app] [build number] [jira release] "[Nội dung note]"
 */

const { exec, spawn } = require('child_process')
const fs = require('fs')
const { _changeConfig, _changeVersionPackageJson, _changeAndroidConfig, _changeIOSConfig } = require('./config/helpers')

// ------------ Get params
const [dirnm, loca, typeApp = 'prod', appVersion, buildNumber, releaseTag = '', releaseMessage = ''] = process.argv
/**
 * @function _checkIsInputValid kiểm tra xem các input có hợp lệ không
 */
const _autoTagVersion = (typeApp, targetVersion, buildNumber, releaseTag, releaseMessage) => {
    const versionString = `${typeApp}/v${targetVersion}/b${buildNumber}-${releaseTag}`
    const versionMessage = `${releaseMessage}`
    console.log(`git tag -a ${versionString} -m "${versionMessage}"`)
    exec(`git tag -a ${versionString} -m "${versionMessage}"`)
    console.log('git push origin --tags')
    exec(`git push origin --tags`)
}
/**
 *  ------------- Change
 */
_changeConfig(typeApp, appVersion, buildNumber, releaseTag)
_changeVersionPackageJson(appVersion)
_changeAndroidConfig(appVersion)
_changeIOSConfig(appVersion)
// _autoTagVersion(typeApp, appVersion, buildNumber, releaseTag, releaseMessage)
/**
 *
 * --------------
 *
 *
 */
