import React, { useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Image, Linking, Platform, StyleSheet, View } from 'react-native'
import { TouchableOpacity } from 'react-native-gesture-handler'
import { Body, Col, Container, Content, Left, List, ListItem, Right } from 'native-base'

import IconRight from '../../assets/images/common/ic_right.svg'
import IconStar from '../../assets/images/common/star.svg'
import { Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { dimensions, fontSizes } from '../../styles'
// import CONFIG from '../../assets/config';
import { UIcommon, UIcomponent } from '../../styles/appUI'
import { glb_sv, reqFunct, sendRequest } from '../../utils'
import IMAGE from '../../utils/constant/image'
import HeaderComponent from '../header'

const ServiceInfo = {
    GET_VERSION_SERVER: {
        reqFunct: reqFunct.GET_VERSION_SERVER,
        WorkerName: 'FOSxID01',
        ServiceName: 'FOSxID01_Token_Mgt',
        Operation: 'Q',
        ClientSentTime: '0',
    },
    API_UPLOAD: {
        reqFunct: reqFunct.API_UPLOAD,
        WorkerName: 'FOSxCommon',
        ServiceName: 'FOSxCommon_Token_Mgt',
        ClientSentTime: '0',
        Operation: 'Q',
    },
}

export default function AboutCompany({ navigation }) {
    const { imageTheme, styles, language } = useContext(StoreContext)
    const { t } = useTranslation()
    const [companyData, setCompanyData] = useState({})
    const [riskUrl, setRiskUrl] = useState(glb_sv.configInfo.riskdisclosure_link)
    const IOS = Platform.OS === 'ios' ? true : false

    useEffect(() => {
        getVersionServer()
    }, [])

    // const OpenURLButton = async (url) => {
    //     console.log("OpenURLButton -> url:", url)
    //     let viewerUrl = url
    //     if (String(url).endsWith('.pdf')) {
    //         viewerUrl = 'http://docs.google.com/gview?embedded=true&url=' + url
    //     }

    //     try {
    //         const supported = await Linking.canOpenURL(viewerUrl);
    //         if (supported) {
    //             await Linking.openURL(viewerUrl);
    //         }
    //     } catch (err) {
    //         console.log("OpenURLButton -> err", err)
    //     }
    // }

    const OpenURLButton = async (url) => {
        if (Platform.OS === 'android' && String(url).endsWith('.pdf')) {
            url = 'https://drive.google.com/viewerng/viewer?embedded=true&url=' + url
        }

        try {
            const supported = await Linking.canOpenURL(url)
            if (supported) {
                await Linking.openURL(url)
            }
        } catch (err) {
            console.log('OpenURLButton -> err', err)
        }
    }

    const getVersionServer = () => {
        const InputParams = ['CHECK', '']
        sendRequest(ServiceInfo.GET_VERSION_SERVER, InputParams, handleGetVersionServer)
    }

    const handleGetVersionServer = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            return
        } else {
            try {
                const res = JSON.parse(message.Data.replace(/\\n/g, '').replace(/\n/g, ''))[0]
                setCompanyData(res)
                if (!glb_sv.configInfo.riskdisclosure_link) {
                    getEventLogin()
                }
            } catch (err) {
                console.log(err)
                return
            }
        }
    }

    const getEventLogin = () => {
        const inval = ['CHECK', glb_sv.notifyOnesignal.userId || '']
        sendRequest(ServiceInfo.API_UPLOAD, inval, getEventLoginResult, true, getEventLoginTimeout)
    }

    const getEventLoginTimeout = ({ type }) => null

    const getEventLoginResult = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
        } else {
            let datajson
            try {
                datajson = message.Data ? JSON.parse(message.Data)[0] : {}
            } catch (err) {
                console.log('checkEkycResult', err)
                return
            }
            if (datajson) {
                const event1 = datajson.c11?.split('|')
                const event2 = datajson.c12?.split('|')
                const event3 = datajson.c13?.split('|')
                const event4 = datajson.c14?.split('|')

                glb_sv.configInfo.riskdisclosure_link = event4.length ? event4[2] : ''
                setRiskUrl(glb_sv.configInfo.riskdisclosure_link)
            }
        }
    }

    return (
        <Container
            style={{
                backgroundColor: styles.PRIMARY__BG__COLOR,
            }}
        >
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft
                navigation={navigation}
                title={t('about') + ' ' + glb_sv.configInfo.shortName}
                titleAlgin="flex-start"
            />
            <Content>
                <TouchableOpacity style={UI.About__Logo} onPress={() => OpenURLButton(companyData.c10)}>
                    <Image resizeMode="contain" source={imageTheme.LOGO} style={[UI.About__Logo__Img]} />
                    <Text style={{ fontSize: fontSizes.smallest, color: styles.PRIMARY__CONTENT__COLOR }}>
                        {glb_sv.configInfo.shortName} {glb_sv.configInfo.build_version} - {glb_sv.buildNumber}
                    </Text>
                </TouchableOpacity>
                <List>
                    <ListItem activeOpacity={0.6} noBorder underlayColor="transparent" onPress={() => OpenURLButton(companyData.c10)}>
                        <Body style={{ ...UIcommon.flex3 }}>
                            <Text style={{ textAlign: 'center', fontWeight: '600', fontSize: fontSizes.medium, color: styles.PRIMARY__CONTENT__COLOR }}>
                                {companyData.c6}
                            </Text>
                        </Body>
                    </ListItem>
                    <View style={{ borderBottomColor: styles.DIVIDER__COLOR, borderBottomWidth: 1 }} />
                    <ListItem activeOpacity={0.6} noBorder underlayColor="transparent" onPress={() => OpenURLButton('tel:' + companyData.c7)}>
                        <Left style={{ flex: 1 }}>
                            <Text style={{ fontSize: fontSizes.small, color: styles.PRIMARY__CONTENT__COLOR }}>{t('hotline')}</Text>
                        </Left>
                        <Right style={{ flex: 3 }}>
                            <Text style={{ fontSize: fontSizes.normal, color: styles.PRIMARY__CONTENT__COLOR }}>{companyData.c7}</Text>
                        </Right>
                    </ListItem>
                    <View style={{ borderBottomColor: styles.DIVIDER__COLOR, borderBottomWidth: 1 }} />
                    <ListItem activeOpacity={0.6} noBorder underlayColor="transparent" onPress={() => OpenURLButton('mailto:' + companyData.c8)}>
                        <Left style={{ flex: 1 }}>
                            <Text style={{ fontSize: fontSizes.small, color: styles.PRIMARY__CONTENT__COLOR }}>{t('comp_email')}</Text>
                        </Left>
                        <Right style={{ flex: 3 }}>
                            <Text style={{ fontSize: fontSizes.normal, color: styles.PRIMARY__CONTENT__COLOR }}>{companyData.c8}</Text>
                        </Right>
                    </ListItem>
                    <View style={{ borderBottomColor: styles.DIVIDER__COLOR, borderBottomWidth: 1 }} />
                    <ListItem activeOpacity={0.6} noBorder underlayColor="transparent" onPress={() => OpenURLButton(glb_sv.configInfo.branch_location || '')}>
                        <Left style={{ flex: 1 }}>
                            <Text style={{ fontSize: fontSizes.small, color: styles.PRIMARY__CONTENT__COLOR }}>{t('comp_address')}</Text>
                        </Left>
                        <Right style={{ flex: 3 }}>
                            <Text style={{ fontSize: fontSizes.normal, color: styles.PRIMARY__CONTENT__COLOR }}>{companyData.c9}</Text>
                        </Right>
                    </ListItem>

                    {/* <ListItem itemDivider style={{
                        backgroundColor: styles.PRIMARY__BG__COLOR
                    }}>
                    </ListItem> */}
                    <View style={{ borderBottomColor: styles.DIVIDER__COLOR, borderBottomWidth: 1 }} />

                    <ListItem activeOpacity={0.6} noBorder underlayColor="transparent" onPress={() => OpenURLButton(riskUrl)}>
                        <Col size={12}>
                            <Text style={{ fontSize: fontSizes.normal, color: styles.PRIMARY__CONTENT__COLOR }}>{t('risk_disclosure_statement')}</Text>
                        </Col>
                        <Col size={12}>
                            <View style={{ flex: 1, flexDirection: 'row', alignSelf: 'flex-end' }}>
                                <Text style={{ textAlign: 'right', color: styles.PRIMARY }}>{t('detail')}</Text>
                                <Right>
                                    <IconRight />
                                </Right>
                            </View>
                        </Col>
                    </ListItem>

                    <View style={{ borderBottomColor: styles.DIVIDER__COLOR, borderBottomWidth: 1 }} />

                    <ListItem activeOpacity={0.6} noBorder underlayColor="transparent" onPress={() => OpenURLButton(glb_sv.configInfo.term_service)}>
                        <Col size={12}>
                            <Text style={{ fontSize: fontSizes.normal, color: styles.PRIMARY__CONTENT__COLOR }}>{t('term_service')}</Text>
                        </Col>
                        <Col size={12}>
                            <View style={{ flex: 1, flexDirection: 'row', alignSelf: 'flex-end' }}>
                                <Text style={{ textAlign: 'right', color: styles.PRIMARY }}>{t('detail')}</Text>
                                <Right>
                                    <IconRight />
                                </Right>
                            </View>
                        </Col>
                    </ListItem>

                    {/* <View style={{ borderBottomColor: styles.DIVIDER__COLOR, borderBottomWidth: 1 }} />

                    <ListItem
                        activeOpacity={0.6}
                        underlayColor="transparent"
                        onPress={() => OpenURLButton('http://altisss.vn/')}
                        noBorder>
                        <Left>
                            <Text style={{ fontSize: fontSizes.normal, color: styles.PRIMARY__CONTENT__COLOR }}>{t('data_disclaimer')}</Text>
                        </Left>
                    </ListItem>

                    <View style={{ borderBottomColor: styles.DIVIDER__COLOR, borderBottomWidth: 1 }} /> */}

                    <ListItem
                        activeOpacity={0.6}
                        noBorder
                        underlayColor="transparent"
                        onPress={() => OpenURLButton(IOS ? glb_sv.configInfo.link_appStore : glb_sv.configInfo.link_playStore)}
                    >
                        <View
                            style={{
                                width: '100%',
                                justifyContent: 'center',
                                backgroundColor: styles.PRIMARY,
                                borderRadius: dimensions.moderate(8),
                                paddingVertical: 12,
                            }}
                        >
                            <Body style={{ flexDirection: 'row', justifyContent: 'center' }}>
                                <IconStar />
                                <Text style={{ fontSize: fontSizes.normal, color: 'white', paddingLeft: 5 }}>{t('rate_us').toUpperCase()}</Text>
                            </Body>
                        </View>
                    </ListItem>

                    {/* <ListItem style={{ borderBottomWidth: 0 }}>
                        <Left>
                            <Text>{t('follow_us')}</Text>
                        </Left>
                    </ListItem> */}
                </List>
                <View style={{ ...UIcomponent.About__Copyright, marginTop: dimensions.vertical(20) }}>
                    <Text
                        style={{ fontSize: fontSizes.small, color: styles.PRIMARY__CONTENT__COLOR, textAlign: 'center' }}
                        onPress={() => OpenURLButton(companyData.c10)}
                    >
                        {language === 'VI' ? glb_sv.configInfo.copyright : language === 'EN' ? glb_sv.configInfo.copyright_e : glb_sv.configInfo.copyright_cn}
                        <Text
                            style={{
                                ...UIcomponent.About__PowerBy,
                                color: styles.BLUE__COLOR,
                            }}
                            onPress={() => OpenURLButton('http://altisss.com/')}
                        >
                            {' '}
                            Power by Altisss.vn
                        </Text>
                    </Text>
                </View>
            </Content>
        </Container>
    )
}

const UI = StyleSheet.create({
    About__Logo: {
        alignItems: 'center',
        height: dimensions.moderate(100),
        justifyContent: 'center',
        marginBottom: dimensions.vertical(7),
        marginTop: dimensions.vertical(13),
    },
    About__Logo__Img: {
        flex: 1,
        height: dimensions.bigIconSize * 8,
        width: dimensions.bigIconSize * 8,
    },
})
