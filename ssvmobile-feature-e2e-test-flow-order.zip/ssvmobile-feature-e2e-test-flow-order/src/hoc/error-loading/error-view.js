import React, { memo, useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { View } from 'react-native'
import AntDesign from 'react-native-vector-icons/AntDesign'

import { Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { fontSizes } from '../../styles'

const ErrorView = ({ getData, title }) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()

    return (
        <View style={{ flex: 1, justifyContent: 'center' }}>
            <AntDesign color={styles.WARN__COLOR} name="warning" size={40} style={{ textAlign: 'center' }} onPress={getData} />
            <Text style={{ fontSize: fontSizes.medium, color: styles.SECOND__CONTENT__COLOR, textAlign: 'center' }} onPress={getData}>
                {title || t('error_loading_data_please_try_again_later')}
            </Text>
        </View>
    )
}

export default memo(ErrorView)
