import React, { memo, useContext, useMemo, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { StyleSheet, View } from 'react-native'
import { DefaultTabBar, Tab, Tabs } from 'native-base'

import Account from '../../components/account'
import { StoreContext } from '../../store'
import { StoreTrading } from '../../store-trading'
import { dimensions } from '../../styles'
import { glb_sv } from '../../utils'
import Debt from './debt'
import AssetsMarginInfo from './margin'
import OverviewInfo from './overview'

function AssetsInfo({ navigation }) {
    const { styles, applicationSettings } = useContext(StoreContext)
    const { userInfo, setUserInfo } = useContext(StoreTrading)
    const { t } = useTranslation()
    const [page, setPage] = useState(0)

    const onTabSwipeListener = (i) => {
        setPage(i)
        if (i === 1) {
            const dataSub = glb_sv.objShareGlb.acntNoInfo.find((e) => e.AcntNo + e.SubNo === userInfo.actn_curr + userInfo.sub_curr)
            if (dataSub) {
                if (!dataSub.MarginYN) {
                    if (userInfo.sub_list.includes('01')) {
                        setUserInfo({
                            ...userInfo,
                            sub_curr: '01',
                        })
                        glb_sv.userInfo.sub_curr = '01'
                        glb_sv.userInfoAccount = {
                            ...userInfo,
                            sub_curr: '01',
                        }
                    }
                }
            } else {
                if (userInfo.sub_list.includes('01')) {
                    setUserInfo({
                        ...userInfo,
                        sub_curr: '01',
                    })
                    glb_sv.userInfo.sub_curr = '01'
                    glb_sv.userInfoAccount = {
                        ...userInfo,
                        sub_curr: '01',
                    }
                }
            }
        }
    }

    const isMarginAccExist = (userInfo) => {
        const subList = glb_sv.objShareGlb.acntNoInfo.filter((e) => e.AcntNo === userInfo.actn_curr)
        const marginSubAcc = subList.find((e) => e.MarginYN === true)
        return marginSubAcc ? true : false
    }

    const StyleUnderline = {
        backgroundColor: applicationSettings.application_style.tab_style === '2.0' ? 'transparent' : styles.PRIMARY,
        borderRadius: 2,
        height: 2,
    }

    const StyleTabBar = { backgroundColor: styles.PRIMARY__BG__COLOR, borderColor: styles.DIVIDER__COLOR, height: 30 }

    const StyleBgPrimary = { backgroundColor: styles.PRIMARY__BG__COLOR }
    const StyleBgPrimaryActive =
        applicationSettings.application_style.tab_style === '2.0'
            ? { backgroundColor: styles.ACTIVE__TAB__HIGHLIGHT__BG, borderTopRightRadius: 6, borderTopLeftRadius: 6, marginLeft: 2 }
            : { backgroundColor: styles.PRIMARY__BG__COLOR }
    const StyleTextPrimary = { color: applicationSettings.application_style.tab_style === '2.0' ? '#fff' : styles.PRIMARY }

    const StyleTextSecond = { color: styles.SECOND__CONTENT__COLOR }

    return (
        <View style={{ backgroundColor: styles.PRIMARY__BG__COLOR, flex: 1 }}>
            <View style={{ flexDirection: 'row', paddingHorizontal: dimensions.moderate(8), marginTop: dimensions.moderate(4) }}>
                <Account navigation={navigation} noPadding />
            </View>

            <Tabs
                renderTabBar={(props) => (
                    <DefaultTabBar
                        {...props}
                        backgroundColor={styles.PRIMARY__BG__COLOR}
                        style={StyleTabBar}
                        tabContainerStyle={{
                            elevation: 0,
                            borderBottomColor: styles.DIVIDER__COLOR,
                            borderBottomWidth: 1,
                            height: 30,
                        }}
                        underlineStyle={StyleUnderline}
                    />
                )}
                onChangeTab={({ i }) => onTabSwipeListener(i)}
            >
                <Tab
                    activeTabStyle={StyleBgPrimaryActive}
                    activeTextStyle={StyleTextPrimary}
                    heading={t('overview')}
                    tabStyle={StyleBgPrimary}
                    textStyle={StyleTextSecond}
                >
                    <OverviewInfo isActive={page === 0} navigation={navigation} />
                </Tab>
                {!isMarginAccExist(userInfo) ? null : (
                    <Tab
                        activeTabStyle={StyleBgPrimaryActive}
                        activeTextStyle={StyleTextPrimary}
                        heading={t('margin_account_info_short')}
                        tabStyle={StyleBgPrimary}
                        textStyle={StyleTextSecond}
                    >
                        <AssetsMarginInfo isActive={page === 1} navigation={navigation} />
                    </Tab>
                )}
                <Tab
                    activeTabStyle={StyleBgPrimaryActive}
                    activeTextStyle={StyleTextPrimary}
                    heading={t('total_debt')}
                    tabStyle={StyleBgPrimary}
                    textStyle={StyleTextSecond}
                >
                    <Debt isActive={!isMarginAccExist(userInfo) ? page === 1 : page === 2} />
                </Tab>
            </Tabs>
        </View>
    )
}

export default memo(AssetsInfo)
