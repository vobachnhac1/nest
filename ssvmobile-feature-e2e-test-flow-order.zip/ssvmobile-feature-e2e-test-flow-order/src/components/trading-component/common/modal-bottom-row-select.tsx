import React, { useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { GestureResponderEvent, Pressable, View } from 'react-native'

import ICTick from '../../../assets/images/common/ic_tick.svg'
import { Text } from '../../../basic-components'
import { StoreContext } from '../../../store'
import { dimensions as dm, fontSizes as fs } from '../../../styles'

interface IModalBottomRowSelect {
    text: string
    checked?: boolean
    type?: 'select'
    onPress: (event: GestureResponderEvent) => void
    last?: boolean
    [key: string]: any
}

const ModalBottomRowSelect = ({
    text,
    checked,
    type = 'select', // type
    onPress, // onPress
    last,
    ...props
}: IModalBottomRowSelect) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()

    return (
        <Pressable onPress={onPress}>
            <View
                style={{
                    marginVertical: dm.vertical(12),
                    marginHorizontal: dm.moderate(24),
                    flexDirection: 'row',
                }}
            >
                <View style={{ justifyContent: 'center', flex: 5 }}>
                    <Text
                        style={{
                            fontSize: fs.medium,
                            color: styles.PRIMARY__CONTENT__COLOR,
                        }}
                    >
                        {text}
                    </Text>
                </View>
                <View style={{ justifyContent: 'center', alignItems: 'flex-end', flex: 1 }}>
                    {checked && <ICTick fill={styles.PRIMARY} height={16} width={20} />}
                </View>
            </View>
        </Pressable>
    )
}

export default ModalBottomRowSelect
