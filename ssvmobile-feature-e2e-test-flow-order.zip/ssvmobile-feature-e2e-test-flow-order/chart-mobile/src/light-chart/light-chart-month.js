import React, { PureComponent } from 'react'
import dayjs from 'dayjs'
import { createChart } from 'lightweight-charts'
import cloneDeep from 'lodash/cloneDeep'

export default class Chart extends PureComponent {
    constructor(props) {
        super(props)
        this.data = window.dataLightChart

        this.timeChart = window.timeChart
        this.typeChart = window.typeChart
        this.flagdataSMA5 = window.flagdataSMA5
        this.flagdataSMA10 = window.flagdataSMA10
        this.flagdataSMA20 = window.flagdataSMA20
        this.flagdataSMA30 = window.flagdataSMA30
    }

    componentDidMount() {
        this.parseDataHistory(this.data)
        const chartElement = document.getElementById('lightchart')
        this.chart = createChart(chartElement, {
            width: window.screen.width - 4,
            height: 250,
            priceScale: {
                borderVisible: false,
            },
            rightPriceScale: {
                scaleMargins: {
                    top: 0.03,
                    bottom: 0.3,
                },
                borderVisible: false,
            },
            timeScale: {
                timeVisible: true,
                secondsVisible: true,
                borderVisible: false,
            },
            layout: window.theme.includes('DARK')
                ? {
                      backgroundColor: 'transparent',
                      textColor: '#93969C',
                      fontSize: 8,
                  }
                : {
                      backgroundColor: 'transparent',
                      fontSize: 8,
                  },
            grid: window.theme.includes('DARK')
                ? {
                      vertLines: {
                          color: 'rgba(42, 46, 57, 0.6)',
                      },
                      horzLines: {
                          color: 'rgba(42, 46, 57, 0.6)',
                      },
                  }
                : {
                      vertLines: {
                          color: 'rgba(42, 46, 57, 0.05)',
                      },
                      horzLines: {
                          color: 'rgba(42, 46, 57, 0.05)',
                      },
                  },
        })
        this.areaSeries = this.chart.addAreaSeries({
            topColor: 'rgba(33, 150, 243, 0.4)',
            bottomColor: 'rgba(33, 150, 243, 0)',
            lineColor: 'rgba(33, 150, 243, 1)',
            lineWidth: 1,
        })

        this.candleSeries = this.chart.addCandlestickSeries()
        this.lineMA5 = this.chart.addLineSeries({
            color: '#FFA43B',
            lineWidth: 1,
            lastValueVisible: false,
            priceLineVisible: false,
        })

        this.lineMA10 = this.chart.addLineSeries({
            color: '#00CFED',
            lineWidth: 1,
            lastValueVisible: false,
            priceLineVisible: false,
        })
        this.lineMA20 = this.chart.addLineSeries({
            color: '#FF725B',
            lineWidth: 1,
            lastValueVisible: false,
            priceLineVisible: false,
        })
        this.lineMA30 = this.chart.addLineSeries({
            color: '#196EEE',
            lineWidth: 1,
            lastValueVisible: false,
            priceLineVisible: false,
        })
        this.volumeSeries = this.chart.addHistogramSeries({
            color: '#26a69a',
            lineWidth: 1,
            priceFormat: {
                type: 'volume',
            },
            overlay: true,
            scaleMargins: {
                top: 0.8,
                bottom: 0.05,
            },
        })

        if (this.typeChart === 'CANDLE') this.candleSeries.setData(cloneDeep(this.DATA_CANDLE))
        else this.areaSeries.setData(cloneDeep(this.DATA_LINE))
        this.lineMA5.setData(this.DATA_SMA5)
        this.lineMA10.setData(this.DATA_SMA10)
        this.lineMA20.setData(this.DATA_SMA20)
        this.lineMA30.setData(this.DATA_SMA30)
        this.volumeSeries.setData(cloneDeep(this.DATA_VOLUME))

        this.chart.applyOptions({
            localization: {
                locale: window.locale,
                priceFormatter: function (price) {
                    return formatNumber(price)
                },
            },
        })
        this.changeTimeChart()

        this.eventMarket = window.eventMarket.subscribe((msg) => {
            if (msg.type === 'lightchart-change-ma') {
                this.flagdataSMA5 = msg.flagdataSMA5
                this.flagdataSMA10 = msg.flagdataSMA10
                this.flagdataSMA20 = msg.flagdataSMA20
                this.flagdataSMA30 = msg.flagdataSMA30

                this.DATA_SMA5 = this.flagdataSMA5 ? SMA(this.DATA_LINE, 5) : []
                this.DATA_SMA10 = this.flagdataSMA10 ? SMA(this.DATA_LINE, 10) : []
                this.DATA_SMA20 = this.flagdataSMA20 ? SMA(this.DATA_LINE, 20) : []
                this.DATA_SMA30 = this.flagdataSMA30 ? SMA(this.DATA_LINE, 30) : []

                this.lineMA5.setData(this.DATA_SMA5)
                this.lineMA10.setData(this.DATA_SMA10)
                this.lineMA20.setData(this.DATA_SMA20)
                this.lineMA30.setData(this.DATA_SMA30)
            }
            if (msg.type === 'lightchart-history-change-type') {
                this.typeChart = msg.typeChart
                this.changeTypeChart()
            }
            if (msg.type === 'lightchart-history-change-time') {
                this.timeChart = msg.timeChart
                this.changeTimeChart()
            }
        })
    }

    componentWillUnmount() {
        if (this.eventMarket) this.eventMarket.unsubscribe()
        this.unmount = true
    }

    parseDataHistory = (data) => {
        const dataStockDaily = chartConvertMonths(data)
        const dataStock_line = []
        const dataStock_volume = []

        for (let index = 0; index < dataStockDaily.length; index++) {
            dataStock_line.push({ value: dataStockDaily[index].close, time: dataStockDaily[index].time })
            dataStock_volume.push({
                value: dataStockDaily[index].volume,
                time: dataStockDaily[index].time,
                color: dataStockDaily[index].close > dataStockDaily[index].open ? 'rgba(0, 150, 136, 0.5)' : 'rgba(255,82,82, 0.5)',
            })
        }

        if (dataStock_line.length) {
            const dataSMA5 = this.flagdataSMA5 ? SMA(dataStock_line, 5) : []
            const dataSMA10 = this.flagdataSMA10 ? SMA(dataStock_line, 10) : []
            const dataSMA20 = this.flagdataSMA20 ? SMA(dataStock_line, 20) : []
            const dataSMA30 = this.flagdataSMA30 ? SMA(dataStock_line, 30) : []

            this.DATA_CANDLE = dataStockDaily
            this.DATA_LINE = dataStock_line
            this.DATA_SMA5 = dataSMA5
            this.DATA_SMA10 = dataSMA10
            this.DATA_SMA20 = dataSMA20
            this.DATA_SMA30 = dataSMA30
            this.DATA_VOLUME = dataStock_volume
        } else {
            this.DATA_CANDLE = dataStockDaily
            this.DATA_LINE = dataStock_line
            this.DATA_VOLUME = dataStock_volume
            this.DATA_SMA5 = []
            this.DATA_SMA10 = []
            this.DATA_SMA20 = []
            this.DATA_SMA30 = []
        }
    }

    changeTypeChart = () => {
        if (this.typeChart === 'CANDLE') {
            this.candleSeries.setData(cloneDeep(this.DATA_CANDLE))
            this.areaSeries.setData([])
        } else {
            this.candleSeries.setData(cloneDeep([]))
            this.areaSeries.setData(cloneDeep(this.DATA_LINE))
        }
    }

    changeTimeChart = () => {
        if (this.timeChart === '5Y') {
            const from = dayjs().subtract(5, 'year').toDate()
            const to = new Date()
            this.chart.timeScale().setVisibleRange({
                from: dateToChartTimeMinute(from),
                to: dateToChartTimeMinute(to),
            })
        } else this.chart.timeScale().fitContent()
    }

    render() {
        return <div id="lightchart" />
    }
}

function formatNumber(n) {
    let newValue = n,
        unit = ''
    if (Number(n) > 10 ** 6) {
        unit = 'M'
        newValue = n / 10 ** 6
    }
    if (Number(n) > 10 ** 9) {
        unit = 'B'
        newValue = n / 10 ** 9
    }
    if (Number(n) > 10 ** 12) {
        unit = 'T'
        newValue = n / 10 ** 12
    }
    if (unit) return Math.round(newValue * 100) / 100 + unit
    return String(Math.round(n * 100) / 100).replace(/\B(?=(\d{3})+(?!\d))/g, ',')
}

function chartConvertMonths(data) {
    const arr = []
    for (let index = 0; index < data.length; index++) {
        const curItem = data[index]
        const prevItem = arr[arr.length - 1]
        const obj = cloneDeep(curItem)
        if (!arr.length) {
            arr.push(obj)
        } else {
            if (prevItem) {
                const momentCur = dayjs(curItem.time, 'YYYY-MM-DD')
                const momentPrev = dayjs(prevItem.time, 'YYYY-MM-DD')
                if (momentCur.month() === momentPrev.month() && momentCur.year() === momentPrev.year()) {
                    prevItem.volume = Math.abs(Number(prevItem.volume)) + Math.abs(Number(curItem.volume))
                    if (Number(prevItem.high) < Number(curItem.high)) prevItem.high = Number(curItem.high)
                    if (Number(prevItem.low) > Number(curItem.low)) prevItem.low = Number(curItem.low)
                    prevItem.close = Number(curItem.close)
                    continue
                } else {
                    arr.push(obj)
                }
            }
        }
    }
    const lastPointArr = arr[arr.length - 1]
    const lastPointOrgin = data[data.length - 1]
    if (lastPointArr && lastPointOrgin && lastPointArr.time !== lastPointOrgin.time) {
        arr.push(lastPointOrgin)
    }
    return arr
}

function SMA(data, period) {
    const result = []
    if (data.length < period) return result
    for (let index = period; index < data.length; index++) {
        let sum = 0,
            periodDivide = 0
        for (let temp = index; temp > index - period; temp--) {
            if (data[temp].value) {
                periodDivide += 1
                sum += data[temp].value
            }
        }
        if (periodDivide) {
            const ma = {
                value: Math.round((sum / periodDivide) * 100) / 100,
                time: data[index].time,
            }
            result.push(ma)
        }
    }
    return result
}

function dateToChartTimeMinute(date) {
    return Date.UTC(date.getFullYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes(), date.getSeconds(), 0) / 1000
}
