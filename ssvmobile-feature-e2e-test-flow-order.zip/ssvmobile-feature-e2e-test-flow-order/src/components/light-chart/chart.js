import React, { memo, PureComponent } from 'react'
import { ActivityIndicator, Pressable, StyleSheet, View } from 'react-native'
import Orientation from 'react-native-orientation-locker'
import Svg, { Path, Rect } from 'react-native-svg'
import moment from 'moment'
import { Button } from 'native-base'

import { Text } from '../../basic-components'
import { dimensions, fontSizes } from '../../styles'
import { glb_sv, reqFunct, Screens, sendRequest } from '../../utils'
import LightChartCandle from '../light-chart/chartCandle'
import LightChartHistory from '../light-chart/chartExtend'
import LightChartRT from './light-chart'
import LightChartMonthHistory from './light-chart-history-month'
import TimeSelect from './time-select'

const ServiceInfo = {
    GET_DATA_CHART_INDEX: {
        reqFunct: reqFunct.GET_DATA_CHART_INDEX,
        WorkerName: 'FOSqMkt01',
        ServiceName: 'FOSqMkt01_ChartService',
        ClientSentTime: '0',
        Operation: 'Q',
    },
}
class Chart extends PureComponent {
    constructor(props) {
        super(props)

        this.state = {
            dataStock: [],
            dataStockDaily: [],
            loadingChart: false,
            dataStock5D: [],
            dataStockDaily_line: [],
            dataStockDaily_volume: [],
            dataStock5D_line: [],
            dataStock5D_volume: [],
            dataStock_line: [],
            dataStock_volume: [],
            flagdataSMA5: false,
            flagdataSMA10: false,
            flagdataSMA20: false,
            flagdataSMA30: false,
            timeChart: '1D',
            typeChart: 'LINE',
            typeTime: '1s',
            dataRef: [],
            dataSMA5: [],
            dataSMA10: [],
            dataSMA20: [],
            dataSMA30: [],
        }
        this.getDataMarketFlag = false

        this.languageChart = 'vi-VN'
        this.indexCode = props.code
        this.timeChart = '1D'
        this.typeChart = 'LINE'
        this.loadMoreFromDailyDay = moment().format('YYYYMMDD')
    }

    componentDidMount() {
        this.HISTORY_CHART = glb_sv.HISTORY_CHART[this.indexCode] || []
    }

    convertSMA = (data) => {
        const dataSMA5 = this.state.flagdataSMA5 ? glb_sv.SMA(data, 5) : []
        const dataSMA10 = this.state.flagdataSMA10 ? glb_sv.SMA(data, 10) : []
        const dataSMA20 = this.state.flagdataSMA20 ? glb_sv.SMA(data, 20) : []
        const dataSMA30 = this.state.flagdataSMA30 ? glb_sv.SMA(data, 30) : []
        this.setState({ dataSMA5, dataSMA10, dataSMA20, dataSMA30 })
    }

    changeMA5 = () => {
        const data = this.state.timeChart === '1D' ? this.state.dataStock_line : this.state.dataStockDaily_line
        if (this.state.flagdataSMA5) {
            this.setState({ flagdataSMA5: false, dataSMA5: [] })
        } else {
            const dataSMA5 = glb_sv.SMA(data, 5)
            this.setState({ flagdataSMA5: true, dataSMA5 })
        }
    }

    changeMA10 = () => {
        const data = this.state.timeChart === '1D' ? this.state.dataStock_line : this.state.dataStockDaily_line
        if (this.state.flagdataSMA10) {
            this.setState({ flagdataSMA10: false, dataSMA10: [] })
        } else {
            const dataSMA10 = glb_sv.SMA(data, 10)
            this.setState({ flagdataSMA10: true, dataSMA10 })
        }
    }

    changeMA20 = () => {
        const data = this.state.timeChart === '1D' ? this.state.dataStock_line : this.state.dataStockDaily_line
        if (this.state.flagdataSMA20) {
            this.setState({ flagdataSMA20: false, dataSMA20: [] })
        } else {
            const dataSMA20 = glb_sv.SMA(data, 20)
            this.setState({ flagdataSMA20: true, dataSMA20 })
        }
    }

    changeMA30 = () => {
        const data = this.state.timeChart === '1D' ? this.state.dataStock_line : this.state.dataStockDaily_line
        if (this.state.flagdataSMA30) {
            this.setState({ flagdataSMA30: false, dataSMA30: [] })
        } else {
            const dataSMA30 = glb_sv.SMA(data, 30)
            this.setState({ flagdataSMA30: true, dataSMA30 })
        }
    }

    changeTimeChart = (timeChart) => {
        if (this.doneDataHistory && (timeChart === '5Y' || timeChart === 'MAX')) {
            this.setState({ timeChart })
            return
        }
        this.timeChart = timeChart
        this.flagMoreDataDaily = false
        this.setState({ timeChart, loadingChart: true, dataSMA5: [], dataSMA10: [], dataSMA20: [], dataSMA30: [] })
        if (this.timeoutchangeTimeChart) clearTimeout(this.timeoutchangeTimeChart)
        this.timeoutchangeTimeChart = setTimeout(() => {
            if (timeChart === '1D') {
                this.setState({ typeChart: 'LINE', loadingChart: false })
            } else {
                this.loadMoreFromDailyDay = glb_sv.timeServer
                if (this.HISTORY_CHART && this.HISTORY_CHART.length === 0) {
                    if (timeChart === '1W') {
                        const from = moment(glb_sv.timeServer, 'YYYYMMDD')
                            .subtract(7 * 2, 'days')
                            .format('YYYYMMDD')
                        this.getDataHistMarket(from, glb_sv.timeServer)
                    }
                    if (timeChart === '1M') {
                        const from = moment(glb_sv.timeServer, 'YYYYMMDD')
                            .subtract(30 * 2, 'days')
                            .format('YYYYMMDD')
                        this.getDataHistMarket(from, glb_sv.timeServer)
                    }
                    if (timeChart === '3M') {
                        const from = moment(glb_sv.timeServer, 'YYYYMMDD')
                            .subtract(90 * 2, 'days')
                            .format('YYYYMMDD')
                        this.getDataHistMarket(from, glb_sv.timeServer)
                    }
                    if (timeChart === '6M') {
                        const from = moment(glb_sv.timeServer, 'YYYYMMDD')
                            .subtract(180 * 2, 'days')
                            .format('YYYYMMDD')
                        this.getDataHistMarket(from, glb_sv.timeServer)
                    }
                    if (timeChart === '1Y') {
                        const from = moment(glb_sv.timeServer, 'YYYYMMDD')
                            .subtract(365 * 2, 'days')
                            .format('YYYYMMDD')
                        this.getDataHistMarket(from, glb_sv.timeServer)
                    }

                    if (timeChart === '5Y' || timeChart === 'MAX') {
                        if (this.doneDataHistory) this.setState({ loadingChart: false })
                        else this.getDataHistMarket('20000101', glb_sv.timeServer)
                    }
                } else {
                    const now = moment(glb_sv.timeServer, 'YYYYMMDD')
                    const lastDay = moment(this.HISTORY_CHART[0].time)
                    const dayMiss = now.diff(lastDay, 'days')
                    if (dayMiss > 0) {
                        if (timeChart === '1W') {
                            if (dayMiss >= 7) {
                                const dataStockDaily = this.HISTORY_CHART.slice(-5)
                                this.addLastestPoint2Data(dataStockDaily)

                                const dataStockDaily_line = []
                                const dataStockDaily_volume = []
                                for (let index = 0; index < dataStockDaily.length; index++) {
                                    dataStockDaily_line.push({ value: dataStockDaily[index].close, time: dataStockDaily[index].time })
                                    dataStockDaily_volume.push({
                                        value: dataStockDaily[index].volume,
                                        time: dataStockDaily[index].time,
                                        color: dataStockDaily[index].close > dataStockDaily[index].open ? 'rgba(0, 150, 136, 0.5)' : 'rgba(255,82,82, 0.5)',
                                    })
                                }

                                this.convertSMA(dataStockDaily_line)
                                this.setState({ dataStockDaily, dataStockDaily_line, dataStockDaily_volume }, () => this.setState({ loadingChart: false }))
                            } else {
                                const from = moment(glb_sv.timeServer, 'YYYYMMDD').subtract(7, 'days').format('YYYYMMDD')
                                this.getDataMissMarket(from, lastDay.format('YYYYMMDD'))
                            }
                        }
                        if (timeChart === '1M') {
                            if (dayMiss >= 30) {
                                const dataStockDaily = this.HISTORY_CHART.slice(-22)
                                this.addLastestPoint2Data(dataStockDaily)
                                const dataStockDaily_line = []
                                const dataStockDaily_volume = []
                                for (let index = 0; index < dataStockDaily.length; index++) {
                                    dataStockDaily_line.push({ value: dataStockDaily[index].close, time: dataStockDaily[index].time })
                                    dataStockDaily_volume.push({
                                        value: dataStockDaily[index].volume,
                                        time: dataStockDaily[index].time,
                                        color: dataStockDaily[index].close > dataStockDaily[index].open ? 'rgba(0, 150, 136, 0.5)' : 'rgba(255,82,82, 0.5)',
                                    })
                                }
                                this.convertSMA(dataStockDaily_line)
                                this.setState({ dataStockDaily, dataStockDaily_line, dataStockDaily_volume }, () => this.setState({ loadingChart: false }))
                            } else {
                                const from = moment(glb_sv.timeServer, 'YYYYMMDD').subtract(30, 'days').format('YYYYMMDD')
                                this.getDataMissMarket(from, lastDay.format('YYYYMMDD'))
                            }
                        }
                        if (timeChart === '3M') {
                            if (dayMiss >= 90) {
                                const dataStockDaily = this.HISTORY_CHART.slice(-22 * 3)
                                const dataStockDaily_line = []
                                const dataStockDaily_volume = []
                                for (let index = 0; index < dataStockDaily.length; index++) {
                                    dataStockDaily_line.push({ value: dataStockDaily[index].close, time: dataStockDaily[index].time })
                                    dataStockDaily_volume.push({
                                        value: dataStockDaily[index].volume,
                                        time: dataStockDaily[index].time,
                                        color: dataStockDaily[index].close > dataStockDaily[index].open ? 'rgba(0, 150, 136, 0.5)' : 'rgba(255,82,82, 0.5)',
                                    })
                                }
                                this.convertSMA(dataStockDaily_line)
                                this.setState({ dataStockDaily, dataStockDaily_line, dataStockDaily_volume }, () => this.setState({ loadingChart: false }))
                            } else {
                                const from = moment(glb_sv.timeServer, 'YYYYMMDD').subtract(90, 'days').format('YYYYMMDD')
                                this.getDataMissMarket(from, lastDay.format('YYYYMMDD'))
                            }
                        }
                        if (timeChart === '6M') {
                            if (dayMiss >= 30 * 6) {
                                const dataStockDaily = this.HISTORY_CHART.slice(-22 * 6)
                                this.addLastestPoint2Data(dataStockDaily)
                                const dataStockDaily_line = []
                                const dataStockDaily_volume = []
                                for (let index = 0; index < dataStockDaily.length; index++) {
                                    dataStockDaily_line.push({ value: dataStockDaily[index].close, time: dataStockDaily[index].time })
                                    dataStockDaily_volume.push({
                                        value: dataStockDaily[index].volume,
                                        time: dataStockDaily[index].time,
                                        color: dataStockDaily[index].close > dataStockDaily[index].open ? 'rgba(0, 150, 136, 0.5)' : 'rgba(255,82,82, 0.5)',
                                    })
                                }
                                this.convertSMA(dataStockDaily_line)
                                this.setState({ dataStockDaily, dataStockDaily_line, dataStockDaily_volume }, () => this.setState({ loadingChart: false }))
                            } else {
                                const from = moment(glb_sv.timeServer, 'YYYYMMDD').subtract(180, 'days').format('YYYYMMDD')
                                this.getDataMissMarket(from, lastDay.format('YYYYMMDD'))
                            }
                        }
                        if (timeChart === '1Y') {
                            if (dayMiss >= 365) {
                                const dataStockDaily = this.HISTORY_CHART.slice(-22 * 12)
                                this.addLastestPoint2Data(dataStockDaily)
                                const dataStockDaily_line = []
                                const dataStockDaily_volume = []
                                for (let index = 0; index < dataStockDaily.length; index++) {
                                    dataStockDaily_line.push({ value: dataStockDaily[index].close, time: dataStockDaily[index].time })
                                    dataStockDaily_volume.push({
                                        value: dataStockDaily[index].volume,
                                        time: dataStockDaily[index].time,
                                        color: dataStockDaily[index].close > dataStockDaily[index].open ? 'rgba(0, 150, 136, 0.5)' : 'rgba(255,82,82, 0.5)',
                                    })
                                }
                                this.convertSMA(dataStockDaily_line)
                                this.setState({ dataStockDaily, dataStockDaily_line, dataStockDaily_volume }, () => this.setState({ loadingChart: false }))
                            } else {
                                const from = moment(glb_sv.timeServer, 'YYYYMMDD').subtract(365, 'days').format('YYYYMMDD')
                                this.getDataMissMarket(from, lastDay.format('YYYYMMDD'))
                            }
                        }
                        if (timeChart === '5Y' || timeChart === 'MAX') {
                            if (this.doneDataHistory) this.setState({ loadingChart: false })
                            else this.getDataHistMarket('20000101', glb_sv.timeServer)
                        }
                    }
                }
            }
        }, 500)
    }

    getDataMissMarket = (from, to) => {
        this.ChartDataTmp = []
        const stkCd = this.indexCode
        const InVal = ['CandleStick', this.props.type === 'INDEX' ? this.props.type : 'STOCK_CODE', 'DAILY', stkCd, from, to]
        sendRequest(ServiceInfo.GET_DATA_CHART_INDEX, InVal, this.getDataMissMarketResultProc, true, this.getDataMissMarketTimeout)
    }

    getDataMissMarketTimeout = () => null

    getDataMissMarketResultProc = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata
            try {
                jsondata = JSON.parse(message.Data)
            } catch (err) {
                jsondata = []
                this.setState({ loadingChart: false, dataStockDaily: [], dataStockDaily_line: [], dataStockDaily_volume: [] })
                return
            }
            this.ChartDataTmp = this.ChartDataTmp.concat(jsondata)
            if (Number(message.Packet) <= 0) {
                if (this.ChartDataTmp.length === 0) {
                    this.setState({ loadingChart: false })
                } else {
                    const data = []
                    for (let index = 0; index < this.ChartDataTmp.length; index++) {
                        const time = moment(this.ChartDataTmp[index].c0, 'YYYYMMDD').format('YYYY-MM-DD')
                        data.push({
                            time,
                            high: Number(this.ChartDataTmp[index].c5),
                            close: Number(this.ChartDataTmp[index].c7),
                            low: Number(this.ChartDataTmp[index].c4),
                            open: Number(this.ChartDataTmp[index].c6),
                            volume: Math.abs(Number(this.ChartDataTmp[index].c8)),
                        })
                    }

                    data.forEach((temp) => {
                        if (!this.HISTORY_CHART.some((e) => e.time === temp.time)) {
                            this.HISTORY_CHART.push(temp)
                        }
                    })

                    this.HISTORY_CHART.sort(function (a, b) {
                        if (a.time > b.time) return 1
                        if (a.time < b.time) return -1
                        return 0
                    })
                    glb_sv.HISTORY_CHART[this.indexCode] = [...this.HISTORY_CHART]

                    const time = this.getDays() * -1
                    const newData = this.HISTORY_CHART.slice()
                    const dataStockDaily = newData.slice(time)
                    this.addLastestPoint2Data(dataStockDaily)
                    const dataStockDaily_line = []
                    const dataStockDaily_volume = []
                    for (let index = 0; index < dataStockDaily.length; index++) {
                        dataStockDaily_line.push({ value: dataStockDaily[index].close, time: dataStockDaily[index].time })
                        dataStockDaily_volume.push({
                            value: dataStockDaily[index].volume,
                            time: dataStockDaily[index].time,
                            color: dataStockDaily[index].close > dataStockDaily[index].open ? 'rgba(0, 150, 136, 0.5)' : 'rgba(255,82,82, 0.5)',
                        })
                    }

                    this.convertSMA(dataStockDaily_line)
                    this.setState({ loadingChart: false, dataStockDaily, dataStockDaily_line, dataStockDaily_volume })
                }
            }
        }
    }

    getDays() {
        if (this.timeChart === '1W') return 5
        if (this.timeChart === '1M') return 22
        if (this.timeChart === '3M') return 22 * 3
        if (this.timeChart === '6M') return 22 * 6
        if (this.timeChart === '1Y') return 22 * 12
    }

    changeTypeChart = (typeChart) => {
        this.setState({ typeChart })
        if (this.timeoutchangeTimeChart) clearTimeout(this.timeoutchangeTimeChart)
        this.timeoutchangeTimeChart = setTimeout(() => {
            this.changeTimeChart(this.state.timeChart)
        }, 500)
    }

    getDataHistMarket = (from, to) => {
        this.ChartDataTmp = []
        const stkCd = this.indexCode
        const InVal = ['CandleStick', this.props.type === 'INDEX' ? this.props.type : 'STOCK_CODE', 'DAILY', stkCd, from, to]
        sendRequest(ServiceInfo.GET_DATA_CHART_INDEX, InVal, this.getDataHistMarketResultProc, true, this.getDataHistMarketTimeout)
    }

    getDataHistMarketTimeout = () => null

    getDataHistMarketResultProc = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            this.setState({ loadingChart: false })
            return
        } else {
            let jsondata
            try {
                jsondata = JSON.parse(message.Data)
            } catch (err) {
                jsondata = []
                this.setState({ loadingChart: false, dataStockDaily: [], dataStockDaily_line: [], dataStockDaily_volume: [] })
                return
            }
            this.ChartDataTmp = this.ChartDataTmp.concat(jsondata)
            if (Number(message.Packet) <= 0) {
                if (this.ChartDataTmp.length === 0) {
                    this.setState({ loadingChart: false })
                } else {
                    const dataStockDaily = []
                    const dataStockDaily_line = []
                    const dataStockDaily_volume = []
                    const data = this.ChartDataTmp.slice()
                    for (let index = 0; index < data.length; index++) {
                        const time = moment(data[index].c0, 'YYYYMMDD').format('YYYY-MM-DD')
                        dataStockDaily.push({
                            time,
                            high: Number(data[index].c5),
                            close: Number(data[index].c7),
                            low: Number(data[index].c4),
                            open: Number(data[index].c6),
                            volume: Math.abs(Number(data[index].c8)),
                        })

                        dataStockDaily_line.push({ value: Number(data[index].c7), time })
                        dataStockDaily_volume.push({
                            time,
                            value: Number(data[index].c8),
                            color: Number(data[index].c7) > Number(data[index].c6) ? 'rgba(0, 150, 136, 0.5)' : 'rgba(255,82,82, 0.5)',
                        })
                    }
                    this.addLastestPoint2DataService(dataStockDaily, dataStockDaily_line, dataStockDaily_volume)
                    this.HISTORY_CHART = dataStockDaily
                    glb_sv.HISTORY_CHART[this.indexCode] = dataStockDaily

                    const time = this.getDays() * -1
                    const dataStockDailyIntoTime = dataStockDaily.slice(time)
                    const dataStockDaily_lineIntoTime = dataStockDaily_line.slice(time)
                    const dataStockDaily_volumeIntoTime = dataStockDaily_volume.slice(time)
                    this.convertSMA(dataStockDaily_line.slice(time))
                    this.setState({
                        loadingChart: false,
                        dataStockDaily: dataStockDailyIntoTime,
                        dataStockDaily_line: dataStockDaily_lineIntoTime,
                        dataStockDaily_volume: dataStockDaily_volumeIntoTime,
                    })
                    if (this.timeChart === '5Y' || this.timeChart === 'MAX') this.doneDataHistory = true
                }
            }
        }
    }

    timeOutFunct = (reqInfo) => {}

    loadMoreDaily = ({ from, to, type }) => {
        if (type) return
        if (this.timeChart === '1D' || this.timeChart === 'MAX' || this.timeChart === '5Y') return
        const stringFrom = moment(new Date(from.year, from.month - 1, from.day)).format('YYYYMMDD')
        if (this.flagMoreDataDaily) return
        if (this.loadMoreFromDailyDay >= stringFrom) {
            this.loadMoreFromDailyDay = stringFrom
            this.getMoreDataDaily()
        }
    }

    getDaysMore() {
        if (this.timeChart === '1W') return 5 * 3
        if (this.timeChart === '1M') return 22 * 3
        if (this.timeChart === '3M') return 22 * 3 * 3
        if (this.timeChart === '6M') return 22 * 6 * 3
        return 22 * 12 * 3
    }

    getDataIntoMonth = () => {
        const { timeChart } = this.state
        if (timeChart === '5Y' || timeChart === 'MAX') return true
        return false
    }

    getMoreDataDaily() {
        if (this.timeouLoadMore) clearTimeout(this.timeouLoadMore)
        this.timeouLoadMore = setTimeout(() => {
            const { dataStockDaily } = this.state
            const lastTime = moment(this.loadMoreFromDailyDay, 'YYYY-MM-DD').format('YYYYMMDD')
            const timeArray = moment(dataStockDaily[0].time, 'YYYY-MM-DD').format('YYYYMMDD')
            if (timeArray === this.loadMoreFromDailyDay) {
                const qty = this.getDaysMore()
                const newData = this.HISTORY_CHART.slice((dataStockDaily.length + qty) * -1)
                if (dataStockDaily.length + qty > newData.length) {
                    const from = moment(lastTime, 'YYYYMMDD').subtract(qty, 'days').format('YYYYMMDD')
                    this.flagMoreDataDaily = true
                    this.getDataMoreMarket(from, lastTime)
                } else {
                    this.flagMoreDataDaily = false
                    const dataStockDaily = this.HISTORY_CHART.slice()
                    this.addLastestPoint2Data(dataStockDaily)
                    const dataStockDaily_line = []
                    const dataStockDaily_volume = []
                    for (let index = 0; index < dataStockDaily.length; index++) {
                        dataStockDaily_line.push({ value: dataStockDaily[index].close, time: dataStockDaily[index].time })
                        dataStockDaily_volume.push({
                            value: dataStockDaily[index].volume,
                            time: dataStockDaily[index].time,
                            color: dataStockDaily[index].close > dataStockDaily[index].open ? 'rgba(0, 150, 136, 0.5)' : 'rgba(255,82,82, 0.5)',
                        })
                    }
                    this.convertSMA(dataStockDaily_line)
                    this.setState({
                        loadingChart: false,
                        dataStockDaily,
                        dataStockDaily_line,
                        dataStockDaily_volume,
                    })
                }
            }
        }, 100)
    }

    getDataMoreMarket = (from, to) => {
        this.ChartDataTmp = []
        const stkCd = this.indexCode
        const InVal = ['CandleStick', this.props.type === 'INDEX' ? this.props.type : 'STOCK_CODE', 'DAILY', stkCd, from, to]
        sendRequest(ServiceInfo.GET_DATA_CHART_INDEX, InVal, this.getDataMoreResultProc, true, this.getDataMoreMarketTimeout)
    }

    getDataMoreMarketTimeout = () => (this.flagMoreDataDaily = false)

    getDataMoreResultProc = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            this.flagMoreDataDaily = false
            return
        } else {
            if (Number(message.Result) === 0) {
                this.flagMoreDataDaily = false
                return
            } else {
                let jsondata
                try {
                    jsondata = JSON.parse(message.Data)
                } catch (err) {
                    jsondata = []
                    this.flagMoreDataDaily = false
                    return
                }
                this.ChartDataTmp = this.ChartDataTmp.concat(jsondata)
                if (Number(message.Packet) <= 0) {
                    this.flagMoreDataDaily = false
                    if (this.ChartDataTmp.length === 0) {
                        this.setState({ loadingChart: false })
                        this.flagMoreDataDaily = true
                    } else if (this.ChartDataTmp.length === 1) {
                        this.flagMoreDataDaily = true
                    } else {
                        const data = []
                        for (let index = 0; index < this.ChartDataTmp.length; index++) {
                            const time = moment(this.ChartDataTmp[index].c0, 'YYYYMMDD').format('YYYY-MM-DD')
                            data.push({
                                time,
                                high: Number(this.ChartDataTmp[index].c5),
                                close: Number(this.ChartDataTmp[index].c7),
                                low: Number(this.ChartDataTmp[index].c4),
                                open: Number(this.ChartDataTmp[index].c6),
                                volume: Math.abs(Number(this.ChartDataTmp[index].c8)),
                            })
                        }
                        data.forEach((temp) => {
                            if (!this.HISTORY_CHART.some((e) => e.time === temp.time)) {
                                this.HISTORY_CHART.push(temp)
                            }
                        })

                        this.HISTORY_CHART.sort(function (a, b) {
                            if (a.time > b.time) return 1
                            if (a.time < b.time) return -1
                            return 0
                        })
                        glb_sv.HISTORY_CHART[this.indexCode] = [...this.HISTORY_CHART]

                        const dataStockDaily = this.HISTORY_CHART.slice()
                        this.addLastestPoint2Data(dataStockDaily)
                        const dataStockDaily_line = []
                        const dataStockDaily_volume = []
                        for (let index = 0; index < dataStockDaily.length; index++) {
                            dataStockDaily_line.push({ value: dataStockDaily[index].close, time: dataStockDaily[index].time })
                            dataStockDaily_volume.push({
                                value: dataStockDaily[index].volume,
                                time: dataStockDaily[index].time,
                                color: dataStockDaily[index].close > dataStockDaily[index].open ? 'rgba(0, 150, 136, 0.5)' : 'rgba(255,82,82, 0.5)',
                            })
                        }
                        this.convertSMA(dataStockDaily_line)
                        this.setState({ loadingChart: false, dataStockDaily, dataStockDaily_line, dataStockDaily_volume })
                    }
                }
            }
        }
    }

    changeTradingview = () => {
        Orientation.lockToLandscapeRight()
        const key = this.indexCode
        this.props.navigation.navigate(Screens.TRADING_VIEW, {
            screen: Screens.DRAW_STACK,
            params: { key, type: glb_sv.IndexMarket[key] ? 'INDEX' : 'STOCK' },
        })
    }

    addLastestPoint2Data = (dataStockDaily) => {
        if (this.props.type === 'STOCK') {
            const stockInfo = glb_sv.StockMarket[this.props.code]
            if (!stockInfo) return
            const close = stockInfo.t31 || stockInfo.t260
            if (!close) return
            const high = stockInfo.t266
            const low = stockInfo.t2661
            const open = stockInfo.t137 || stockInfo.t260
            const volume = stockInfo.t391

            const now = moment().format('YYYY-MM-DD')
            const lastPoint = dataStockDaily[dataStockDaily.length - 1]
            // {
            //     close: 0,
            //     high: 0,
            //     low: 0,
            //     open: 0,
            //     time: moment().format('YYYY-MM-DD'),
            //     volume: 0
            // };
            // nếu điểm cuối có time = hiện tại thì chỉ cập nhật lại giá trị
            // ngược lại push thêm điểm mới
            if (lastPoint && lastPoint.time === now) {
                lastPoint.close = close
                lastPoint.high = high
                lastPoint.low = low
                lastPoint.open = open
                lastPoint.volume = volume
            } else {
                dataStockDaily.push({
                    close,
                    high,
                    low,
                    open,
                    time: now,
                    volume,
                })
            }
        } else if (this.props.type === 'INDEX') {
            const indexInfo = glb_sv.IndexMarket[this.props.code]
            if (!indexInfo) return
            const close = indexInfo.indexValue
            if (!close) return
            const high = indexInfo.indexHighest
            const low = indexInfo.indexLowest
            const open = indexInfo.indexOpen || indexInfo.indexValue
            const volume = indexInfo.indexTotalQty

            const now = moment().format('YYYY-MM-DD')
            const lastPoint = dataStockDaily[dataStockDaily.length - 1]
            // {
            //     close: 0,
            //     high: 0,
            //     low: 0,
            //     open: 0,
            //     time: moment().format('YYYY-MM-DD'),
            //     volume: 0
            // };
            // nếu điểm cuối có time = hiện tại thì chỉ cập nhật lại giá trị
            // ngược lại push thêm điểm mới
            if (lastPoint && lastPoint.time === now) {
                lastPoint.close = close
                lastPoint.high = high
                lastPoint.low = low
                lastPoint.open = open
                lastPoint.volume = volume
            } else {
                dataStockDaily.push({
                    close,
                    high,
                    low,
                    open,
                    time: now,
                    volume,
                })
            }
        }
    }

    addLastestPoint2DataService = (dataStockDaily, dataStockDaily_line, dataStockDaily_volume) => {
        if (this.props.type === 'STOCK') {
            const stockInfo = glb_sv.StockMarket[this.props.code]
            if (!stockInfo) return
            const close = stockInfo.t31 || stockInfo.t260
            if (!close) return
            const high = stockInfo.t266
            const low = stockInfo.t2661
            const open = stockInfo.t137 || stockInfo.t260
            const volume = stockInfo.t391

            const now = moment().format('YYYY-MM-DD')
            const lastPoint = dataStockDaily[dataStockDaily.length - 1]
            if (lastPoint && lastPoint.time < now) {
                dataStockDaily.push({
                    close,
                    high,
                    low,
                    open,
                    time: now,
                    volume,
                })

                dataStockDaily_line.push({
                    value: close,
                    time: now,
                })

                dataStockDaily_volume.push({
                    value: volume,
                    time: now,
                    color: close > open ? 'rgba(0, 150, 136, 0.5)' : 'rgba(255,82,82, 0.5)',
                })
            }
        } else if (this.props.type === 'INDEX') {
            const indexInfo = glb_sv.IndexMarket[this.props.code]
            if (!indexInfo) return
            const close = indexInfo.indexValue
            if (!close) return
            const high = indexInfo.indexHighest
            const low = indexInfo.indexLowest
            const open = indexInfo.indexOpen || indexInfo.indexValue
            const volume = indexInfo.indexTotalQty

            const now = moment().format('YYYY-MM-DD')
            const lastPoint = dataStockDaily[dataStockDaily.length - 1]
            if (lastPoint && lastPoint.time < now) {
                dataStockDaily.push({
                    close,
                    high,
                    low,
                    open,
                    time: now,
                    volume,
                })

                dataStockDaily_line.push({
                    value: close,
                    time: now,
                })

                dataStockDaily_volume.push({
                    value: volume,
                    time: now,
                    color: close > open ? 'rgba(0, 150, 136, 0.5)' : 'rgba(255,82,82, 0.5)',
                })
            }
        }
    }

    render() {
        const { timeChart, typeChart, flagdataSMA5, flagdataSMA10, flagdataSMA20, flagdataSMA30 } = this.state
        const { styles, theme } = this.props
        return (
            <>
                <View style={UI.row_checkbox}>
                    <Pressable style={{ flexDirection: 'row' }} onPress={this.changeMA5}>
                        <CheckBoxMA colorActive={styles.LINE_MA5} colorunActive={styles.PRIMARY__CONTENT__COLOR} flag={flagdataSMA5} />
                        <Text style={{ ...UI.textMA, color: flagdataSMA5 ? styles.LINE_MA5 : styles.PRIMARY__CONTENT__COLOR }}> MA5</Text>
                    </Pressable>

                    <Pressable style={{ flexDirection: 'row', justifyContent: 'center' }} onPress={this.changeMA10}>
                        <CheckBoxMA colorActive={styles.LINE_MA10} colorunActive={styles.PRIMARY__CONTENT__COLOR} flag={flagdataSMA10} />
                        <Text style={{ ...UI.textMA, color: flagdataSMA10 ? styles.LINE_MA10 : styles.PRIMARY__CONTENT__COLOR }}> MA10</Text>
                    </Pressable>

                    <Pressable style={{ flexDirection: 'row', justifyContent: 'center' }} onPress={this.changeMA20}>
                        <CheckBoxMA colorActive={styles.LINE_MA20} colorunActive={styles.PRIMARY__CONTENT__COLOR} flag={flagdataSMA20} />
                        <Text style={{ ...UI.textMA, color: flagdataSMA20 ? styles.LINE_MA20 : styles.PRIMARY__CONTENT__COLOR }}> MA20</Text>
                    </Pressable>

                    <Pressable style={{ flexDirection: 'row', justifyContent: 'flex-end' }} onPress={this.changeMA30}>
                        <CheckBoxMA colorActive={styles.LINE_MA30} colorunActive={styles.PRIMARY__CONTENT__COLOR} flag={flagdataSMA30} />
                        <Text style={{ ...UI.textMA, color: flagdataSMA30 ? styles.LINE_MA30 : styles.PRIMARY__CONTENT__COLOR }}> MA30</Text>
                    </Pressable>
                </View>

                {this.state.timeChart === '1D' && !this.state.loadingChart ? (
                    <View style={UI.height_250}>
                        <ButtonChangeTradingview changeTradingview={this.changeTradingview} styles={styles} />

                        <LightChartRT
                            code={this.indexCode}
                            flagdataSMA10={flagdataSMA10}
                            flagdataSMA20={flagdataSMA20}
                            flagdataSMA30={flagdataSMA30}
                            flagdataSMA5={flagdataSMA5}
                            theme={theme}
                            type={this.props.type}
                        />
                    </View>
                ) : null}

                {this.state.timeChart !== '1D' && this.state.timeChart !== '5Y' && this.state.timeChart !== 'MAX' && !this.state.loadingChart ? (
                    <>
                        <View style={UI.height_250}>
                            <ButtonChangeTradingview changeTradingview={this.changeTradingview} styles={styles} />

                            {/* chart line weight  =>>> */}
                            {this.state.typeChart === 'LINE' ? (
                                <LightChartHistory
                                    DATA_LINE={this.state.dataStockDaily_line}
                                    DATA_SMA10={this.state.dataSMA10}
                                    DATA_SMA20={this.state.dataSMA20}
                                    DATA_SMA30={this.state.dataSMA30}
                                    DATA_SMA5={this.state.dataSMA5}
                                    DATA_VOLUME={this.state.dataStockDaily_volume}
                                    initScript={lineChart(
                                        this.state.dataStockDaily_line,
                                        this.state.dataStockDaily_volume,
                                        this.languageChart,
                                        this.state.dataSMA5,
                                        this.state.dataSMA10,
                                        this.state.dataSMA20,
                                        this.state.dataSMA30,
                                        styles.LINE_MA5,
                                        styles.LINE_MA10,
                                        styles.LINE_MA20,
                                        styles.LINE_MA30,
                                        theme,
                                    )}
                                    typeTime={this.state.timeChart}
                                    onLoadMore={this.loadMoreDaily}
                                />
                            ) : null}

                            {/* chart candle */}
                            {this.state.typeChart === 'CANDLE' ? (
                                <LightChartCandle
                                    DATA_LINE={this.state.dataStockDaily}
                                    DATA_SMA10={this.state.dataSMA10}
                                    DATA_SMA20={this.state.dataSMA20}
                                    DATA_SMA30={this.state.dataSMA30}
                                    DATA_SMA5={this.state.dataSMA5}
                                    DATA_VOLUME={this.state.dataStockDaily_volume}
                                    initScript={candleChart(
                                        this.state.dataStockDaily,
                                        this.state.dataStockDaily_volume,
                                        this.languageChart,
                                        this.state.dataSMA5,
                                        this.state.dataSMA10,
                                        this.state.dataSMA20,
                                        this.state.dataSMA30,
                                        styles.LINE_MA5,
                                        styles.LINE_MA10,
                                        styles.LINE_MA20,
                                        styles.LINE_MA30,
                                        theme,
                                    )}
                                    LINE_MA5={styles.LINE_MA5}
                                    typeTime={this.state.timeChart}
                                    onLoadMore={this.loadMoreDaily}
                                />
                            ) : null}
                        </View>
                    </>
                ) : null}
                {(this.state.timeChart === '5Y' || this.state.timeChart === 'MAX') && !this.state.loadingChart ? (
                    <>
                        <View style={UI.height_250}>
                            <ButtonChangeTradingview changeTradingview={this.changeTradingview} styles={styles} />

                            <LightChartMonthHistory
                                flagdataSMA10={flagdataSMA10}
                                flagdataSMA20={flagdataSMA20}
                                flagdataSMA30={flagdataSMA30}
                                flagdataSMA5={flagdataSMA5}
                                indexCode={this.indexCode}
                                theme={theme}
                                timeChart={timeChart}
                                typeChart={typeChart}
                            />
                        </View>
                    </>
                ) : null}
                {this.state.loadingChart ? (
                    <View style={{ height: 250, justifyContent: 'center' }}>
                        <ActivityIndicator />
                    </View>
                ) : null}
                <TimeSelect
                    changeTime={this.changeTimeChart}
                    changeTypeChart={this.changeTypeChart}
                    indexCode={this.indexCode}
                    navigation={this.props.navigation}
                    time={timeChart}
                    typeChart={typeChart}
                />
            </>
        )
    }
}

const UI = StyleSheet.create({
    Button: {
        borderRadius: dimensions.moderate(45) / 2,
        height: dimensions.moderate(45),
        justifyContent: 'center',
        left: 10,
        position: 'absolute',
        top: 10,
        width: dimensions.moderate(45),
        zIndex: 999,
    },
    height_250: {
        height: 250,
    },
    row_checkbox: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginBottom: dimensions.vertical(11.5),
        paddingHorizontal: dimensions.moderate(12),
    },
    textMA: {
        fontSize: fontSizes.verySmall,
        lineHeight: dimensions.moderate(20),
    },
})

const CheckBoxMA = memo(({ flag, colorActive, colorunActive }) => {
    return (
        <Svg fill="none" height={dimensions.moderate(21)} viewBox="0 0 21 21" width={dimensions.moderate(21)} xmlns="http://www.w3.org/2000/svg">
            {!flag ? (
                <Path
                    d="M16.125 2.5H4.875C3.839 2.5 3 3.34 3 4.375v11.25c0 1.035.84 1.875 1.875 1.875h11.25c1.035 0 1.875-.84 1.875-1.875V4.375c0-1.036-.84-1.875-1.875-1.875z"
                    stroke={colorunActive}
                    strokeLinejoin="round"
                    strokeWidth={dimensions.moderate(1.25)}
                />
            ) : (
                <Path
                    d="M16.125 1.875H4.875a2.503 2.503 0 00-2.5 2.5v11.25a2.503 2.503 0 002.5 2.5h11.25a2.503 2.503 0 002.5-2.5V4.375a2.503 2.503 0 00-2.5-2.5zm-1.396 5.402l-5.25 6.25a.625.625 0 01-.47.223H9a.626.626 0 01-.464-.207l-2.25-2.5a.625.625 0 11.929-.836l1.769 1.966 4.788-5.7a.625.625 0 01.957.804z"
                    fill={colorActive}
                />
            )}
        </Svg>
    )
})

const lineChart = (DATA_LINE, DATA_VOLUME, locale, DATA_SMA5, DATA_SMA10, DATA_SMA20, DATA_SMA30, LINE_MA5, LINE_MA10, LINE_MA20, LINE_MA30, theme) => `
    const chartElement = document.createElement('div');
    const chart = LightweightCharts.createChart(chartElement, {
        width: screen.width - 4,
        height: 250,
        priceScale: {
            borderVisible: false,
        },
        rightPriceScale: {
            scaleMargins: {
                top: 0.1,
                bottom: 0.25,
            },
            borderVisible: false,
        },
        timeScale: {
            timeVisible: true,
            secondsVisible: false,
            borderVisible: false,
        },
        layout: ${
            theme.includes('DARK')
                ? JSON.stringify({
                      backgroundColor: 'transparent',
                      fontSize: 8,
                      textColor: '#d1d4dc',
                  })
                : JSON.stringify({
                      fontSize: 8,
                      backgroundColor: 'transparent',
                  })
        },
    grid: ${
        theme.includes('DARK')
            ? JSON.stringify({
                  vertLines: {
                      color: 'rgba(42, 46, 57, 0.6)',
                  },
                  horzLines: {
                      color: 'rgba(42, 46, 57, 0.6)',
                  },
              })
            : JSON.stringify({
                  vertLines: {
                      color: '#d5d1c699',
                  },
                  horzLines: {
                      color: '#d5d1c699',
                  },
              })
    }
    });
    window.chart = chart
    window.chartIntra = false

    document.body.appendChild(chartElement);

    const areaSeries = chart.addAreaSeries({
      topColor: 'rgba(33, 150, 243, 0.56)',
      bottomColor: 'rgba(33, 150, 243, 0.04)',
      lineColor: 'rgba(33, 150, 243, 1)',
      lineWidth: 1,
      priceFormat: {
		precision: 0,
      }
    });
    window.areaSeries = areaSeries;

    const lineMA5 = chart.addLineSeries({
      color: '${LINE_MA5}',
      lineWidth: 1,
      lastValueVisible: false,
      priceLineVisible: false
    });
    window.lineMA5 = lineMA5;
    const lineMA10 = chart.addLineSeries({
      color: '${LINE_MA10}',
      lineWidth: 1,
      lastValueVisible: false,
      priceLineVisible: false
    });
    window.lineMA10 = lineMA10;
    const lineMA20 = chart.addLineSeries({
      color: '${LINE_MA20}',
      lineWidth: 1,
      lastValueVisible: false,
      priceLineVisible: false
    });
    window.lineMA20 = lineMA20;
    const lineMA30 = chart.addLineSeries({
      color: '${LINE_MA30}',
      lineWidth: 1,
      lastValueVisible: false,
      priceLineVisible: false
    });
    window.lineMA30 = lineMA30;
    const volumeSeries = chart.addHistogramSeries({
        color: '#26a69a',
        lineWidth: 2,
        priceFormat: {
            type: 'volume',
        },
        overlay: true,
        scaleMargins: {
            top: 0.8,
            bottom: 0.05,
        },
    });
    window.volumeSeries = volumeSeries;
    window.areaSeries.setData(${JSON.stringify(DATA_LINE)});
    window.lineMA5.setData(${JSON.stringify(DATA_SMA5)});
    window.lineMA10.setData(${JSON.stringify(DATA_SMA10)});
    window.lineMA20.setData(${JSON.stringify(DATA_SMA20)});
    window.lineMA30.setData(${JSON.stringify(DATA_SMA30)});
    window.volumeSeries.setData(${JSON.stringify(DATA_VOLUME)});
    window.chart.applyOptions({
      localization: {
        locale: '${locale}',
        priceFormatter: function(price) { return formatNumber(price) },
      },
    });
    chart.timeScale().subscribeVisibleTimeRangeChange(function(e) {
        window.ReactNativeWebView && window.ReactNativeWebView.postMessage(JSON.stringify(e));
    });
    chart.timeScale().fitContent();

  true;
`

const candleChart = (DATA_LINE, DATA_VOLUME, locale, DATA_SMA5, DATA_SMA10, DATA_SMA20, DATA_SMA30, LINE_MA5, LINE_MA10, LINE_MA20, LINE_MA30, theme) => `
    const chartElement = document.createElement('div');
    const chart = LightweightCharts.createChart(chartElement, {
        width: screen.width - 4,
        height: 250,
        priceScale: {
            borderVisible: false,
        },
        rightPriceScale: {
            scaleMargins: {
                top: 0.1,
                bottom: 0.25,
            },
            borderVisible: false,
        },
        timeScale: {
            timeVisible: true,
            secondsVisible: true,
            borderVisible: false,
        },
        layout: ${
            theme.includes('DARK')
                ? JSON.stringify({
                      backgroundColor: 'transparent',
                      fontSize: 8,
                      textColor: '#d1d4dc',
                  })
                : JSON.stringify({
                      backgroundColor: 'transparent',
                      fontSize: 8,
                  })
        },
    grid: ${
        theme.includes('DARK')
            ? JSON.stringify({
                  vertLines: {
                      color: 'rgba(42, 46, 57, 0.6)',
                  },
                  horzLines: {
                      color: 'rgba(42, 46, 57, 0.6)',
                  },
              })
            : JSON.stringify({
                  vertLines: {
                      color: '#d5d1c699',
                  },
                  horzLines: {
                      color: '#d5d1c699',
                  },
              })
    },
    });
    window.chart = chart;
    window.chartIntra = false
    document.body.appendChild(chartElement);

    const areaSeries = chart.addCandlestickSeries();
    window.areaSeries = areaSeries;
    const lineMA5 = chart.addLineSeries({
      color: '${LINE_MA5}',
      lineWidth: 1,
      lastValueVisible: false,
      priceLineVisible: false
    });
    window.lineMA5 = lineMA5;
    const lineMA10 = chart.addLineSeries({
      color: '${LINE_MA10}',
      lineWidth: 1,
      lastValueVisible: false,
      priceLineVisible: false
    });
    window.lineMA10 = lineMA10;
    const lineMA20 = chart.addLineSeries({
      color: '${LINE_MA20}',
      lineWidth: 1,
      lastValueVisible: false,
      priceLineVisible: false
    });
    window.lineMA20 = lineMA20;
    const lineMA30 = chart.addLineSeries({
      color: '${LINE_MA30}',
      lineWidth: 1,
      lastValueVisible: false,
      priceLineVisible: false
    });
    window.lineMA30 = lineMA30;
    const volumeSeries = chart.addHistogramSeries({
        color: '#26a69a',
        lineWidth: 2,
        priceFormat: {
            type: 'volume',
        },
        overlay: true,
        scaleMargins: {
            top: 0.8,
            bottom: 0.05,
        },
    });
    window.volumeSeries = volumeSeries;
    window.areaSeries.setData(${JSON.stringify(DATA_LINE)});
    window.lineMA5.setData(${JSON.stringify(DATA_SMA5)});
    window.lineMA10.setData(${JSON.stringify(DATA_SMA10)});
    window.lineMA20.setData(${JSON.stringify(DATA_SMA20)});
    window.lineMA30.setData(${JSON.stringify(DATA_SMA30)});
    window.volumeSeries.setData(${JSON.stringify(DATA_VOLUME)});
    
  const toolTipMargin = 10;
  const priceScaleWidth = 50;
  const toolTip = document.createElement('div');
  toolTip.className = 'three-line-legend';
  chartElement.appendChild(toolTip);
  toolTip.style.display = 'block';
  toolTip.style.left = 3 + 'px';
  toolTip.style.top = 3 + 'px';

  chart.applyOptions({ 
    localization: {
      locale: '${locale}',
      priceFormatter: function(price) { return formatNumber(price) },
    },
  });

  chart.subscribeCrosshairMove(function(param) {
    if ( param === undefined || param.time === undefined || param.point.x < 0 || param.point.x > screen.width || param.point.y < 0 || param.point.y > screen.height ) {
    } else {
        dateStr = param.time.day + ' - ' + param.time.month +' - '+ param.time.year ;
        const ohlc = param.seriesPrices.get(areaSeries);
        const volume = param.seriesPrices.get(volumeSeries);
        toolTip.innerHTML =	'<div style="font-size: 14px; margin: 4px 0px; color: #20262E; width: 305px"> O: ' + ohlc.open.toLocaleString() + '  H: ' + ohlc.high.toLocaleString() + ' L: ' + ohlc.low.toLocaleString() + ' C: ' + ohlc.close.toLocaleString() + '</div><div>V: '+ volume.toLocaleString() +'</div> <div>' + dateStr + '</div>';
    }
  });
    
  chart.timeScale().subscribeVisibleTimeRangeChange(function(e) {
    window.ReactNativeWebView && window.ReactNativeWebView.postMessage(JSON.stringify(e));
  });
    chart.timeScale().fitContent();
    true;
`

const ButtonChangeTradingview = memo(({ changeTradingview, styles }) => {
    return (
        <Button style={{ ...UI.Button, backgroundColor: styles.BUTTON__SECONDARY, paddingRight: 2, paddingBottom: 8 }} transparent onPress={changeTradingview}>
            <Svg fill="none" height={dimensions.moderate(24)} viewBox="0 0 18 19" width={dimensions.moderate(24)} xmlns="http://www.w3.org/2000/svg">
                <Rect height={14.556} rx={0.55} stroke="#196EEE" transform="rotate(-35 2.009 5.983)" width={7.556} x={2.009} y={5.983} />
                <Path
                    d="M3.734 5.25l3.185-2.23.276.394a.296.296 0 01-.072.412l-2.7 1.891a.296.296 0 01-.413-.073l-.276-.394zM6.313 16.992a.028.028 0 00-.001-.046l-.216-.134v-.002h-.004l-.534-.33a.028.028 0 00-.042.023v.263a3.99 3.99 0 01-.156-.025c-1.774-.331-3.165-1.807-3.449-3.666a4.614 4.614 0 01-.02-.156l.257.002a.028.028 0 00.023-.043l-.505-.787a.028.028 0 00-.047.001l-.45.783a.027.027 0 00.025.041l.325.002.02.155c.29 2.072 1.842 3.718 3.819 4.057.051.009.103.017.155.024l-.001.34c0 .021.025.035.043.022l.595-.411.163-.113z"
                    fill="#196EEE"
                />
                <Path
                    clipRule="evenodd"
                    d="M6.401 17.12l-.122.085-.069.047-.566.392a.183.183 0 01-.288-.152l.001-.205c-2.066-.341-3.684-2.06-3.975-4.214l-.19-.001a.183.183 0 01-.157-.274l.3-.523.086-.15.063-.11a.183.183 0 01.313-.008l.505.787a.183.183 0 01-.155.282h-.078c.28 1.776 1.606 3.18 3.291 3.506v-.08c.001-.143.158-.23.28-.155l.497.308.115.07.142.088c.112.07.116.232.007.307zm-.09-.174c.018.01.018.034.002.046l-.163.113-.595.41a.028.028 0 01-.043-.022l.001-.34a4.67 4.67 0 01-.155-.023c-1.977-.34-3.53-1.985-3.82-4.057a5.029 5.029 0 01-.019-.155l-.325-.002a.027.027 0 01-.024-.04l.45-.784a.028.028 0 01.046 0l.505.786a.028.028 0 01-.023.043l-.258-.002c.006.053.013.104.021.156.284 1.859 1.675 3.335 3.449 3.666.051.01.103.018.155.025l.001-.263c0-.022.024-.035.042-.024l.534.33h.004v.003l.216.134z"
                    fill="#196EEE"
                    fillRule="evenodd"
                />
                <Path
                    d="M12.19 3.689a.028.028 0 000 .046l.216.133v.003h.004l.534.33a.028.028 0 00.042-.023l.001-.264c.052.008.104.016.156.026 1.773.33 3.164 1.807 3.448 3.666.008.051.015.103.02.155h-.256a.028.028 0 00-.024.042l.505.786a.028.028 0 00.047 0l.45-.784a.028.028 0 00-.024-.04l-.326-.002a4.967 4.967 0 00-.02-.156c-.289-2.071-1.841-3.717-3.819-4.056a4.447 4.447 0 00-.155-.024l.001-.34a.028.028 0 00-.043-.022l-.595.411-.163.113z"
                    fill="#196EEE"
                />
                <Path
                    clipRule="evenodd"
                    d="M12.1 3.56l.123-.084.069-.047.567-.392a.183.183 0 01.287.151l-.001.205c2.067.342 3.684 2.06 3.976 4.215h.188c.14.001.228.153.158.275l-.3.523-.085.149-.064.11a.183.183 0 01-.313.008l-.505-.787a.183.183 0 01.155-.281h.078c-.28-1.776-1.606-3.18-3.291-3.507v.08c-.001.144-.158.23-.28.155l-.497-.307-.115-.071-.141-.088a.183.183 0 01-.008-.306zm.09.175a.028.028 0 010-.046l.162-.113.595-.411a.028.028 0 01.043.022l-.001.34c.052.007.104.015.155.024 1.978.339 3.53 1.985 3.82 4.056l.019.156.326.001c.02 0 .034.023.023.042l-.449.782a.028.028 0 01-.047.001l-.505-.786a.028.028 0 01.024-.043l.257.001a4.42 4.42 0 00-.021-.155c-.284-1.86-1.675-3.335-3.448-3.666a4.064 4.064 0 00-.156-.026l-.001.264a.028.028 0 01-.042.023l-.534-.33h-.004v-.003l-.216-.133z"
                    fill="#196EEE"
                    fillRule="evenodd"
                />
            </Svg>
        </Button>
    )
})

export default memo(Chart)
