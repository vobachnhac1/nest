import * as React from 'react'
import { StatusBar } from 'react-native'

function FocusAwareStatusBar(props) {
    return <StatusBar {...props} />
}

export default React.memo(FocusAwareStatusBar)
