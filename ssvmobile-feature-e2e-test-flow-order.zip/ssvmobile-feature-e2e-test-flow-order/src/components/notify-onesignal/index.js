import React, { Component } from 'react'
import { Platform } from 'react-native'
import OneSignal from 'react-native-onesignal'
import PushNotificationIOS from '@react-native-community/push-notification-ios'
import syncStorage from 'sync-storage'

import CONFIG from '../../assets/config'
import { eventList, glb_sv, STORE_KEY } from '../../utils'

const appId = CONFIG[CONFIG.active_code].appIdOnesignal || ''

export default class NotifyOnesignal extends Component {
    constructor(properties) {
        super(properties)
    }

    async componentDidMount() {
        /* ONESIGNAL SETUP */
        OneSignal.setAppId(appId)
        // OneSignal.setLogLevel(6, 0);
        OneSignal.setRequiresUserPrivacyConsent(false)
        // OneSignal.promptForPushNotificationsWithUserResponse();

        /* ONESIGNAL HANDLERS */
        OneSignal.setNotificationWillShowInForegroundHandler((notifReceivedEvent) => {
            console.log('NotifyOnesignal ShowInForegroundHandler notifReceivedEvent: ', notifReceivedEvent)
            this.onNotificationReceived(notifReceivedEvent)
        })

        OneSignal.setNotificationOpenedHandler((notification) => {
            console.log('NotifyOnesignal OpenedHandler notification: ', notification)
            this.onNotificationOpened(notification)
        })

        OneSignal.addSubscriptionObserver((event) => {
            console.log('NotifyOnesignal addSubscriptionObserver event: ', event)
            if (event.to.userId) {
                glb_sv.notifyOnesignal = event.to
                syncStorage.set(STORE_KEY.DEVICE_ID_ONESIGNAL, event.to.userId)
            }
            OneSignal.getDeviceState().then((res) => {
                if (res.userId) {
                    glb_sv.notifyOnesignal = res
                    syncStorage.set(STORE_KEY.DEVICE_ID_ONESIGNAL, res.userId)
                }
            })
        })

        setTimeout(() => {
            OneSignal.getDeviceState().then((res) => {
                if (res.userId) {
                    glb_sv.notifyOnesignal = res
                    syncStorage.set(STORE_KEY.DEVICE_ID_ONESIGNAL, res.userId)
                }
            })
        }, 2000)

        if (Platform.OS === 'ios') {
            PushNotificationIOS.checkPermissions((res) => {
                if (!res.notificationCenter) {
                    PushNotificationIOS.requestPermissions().catch((err) => null)
                }
            })
        }
    }

    componentWillUnmount() {
        OneSignal.clearHandlers()
    }

    /**
     When a notification is received this will fire
     */
    onNotificationReceived = (payload) => {
        if (!payload.notification || !payload.notification.additionalData) return
        glb_sv.commonEvent.next({ type: eventList.NOTIFY_ONESIGNAL, data: payload.notification.additionalData })
    }

    /**
     When a notification is opened this will fire
     The openResult will contain information about the notification opened
     */
    onNotificationOpened = (openResult) => {
        const data = openResult.notification.additionalData
        if (data && data.direct && data.direct.trim()) {
            glb_sv.notifyOpened = openResult.notification.additionalData
            console.log('NotifyOnesignal -> onNotificationOpened -> glb_sv.notifyOpened', glb_sv.notifyOpened)
            if (glb_sv.notifyOpened) {
                glb_sv.commonEvent.next({
                    type: eventList.CHANGE_SCREEN,
                    data: glb_sv.notifyOpened,
                })
            }
        }
    }

    render() {
        return null
    }
}
