import React, { useContext, useEffect, useState } from 'react'
import { View } from 'native-base'

import NotAuthView from '../../components/notAuth-view'
import { StoreContext } from '../../store'
import { glb_sv, reqFunct, Screens, socket_sv } from '../../utils'

/**
 *
 * @param {String} arrPrevent     Array các secCode không sử dụng màn hình
 * @returns {Component}           Return Right Component went active Company have permission to access this Page|Tab|Scree|Component
 * else return a Prevention Screen with notify or Warning.
 */
const arrCompany = ['888', '102', '061', '020', '004', '023', '075', '082']

const PreventCompany =
    (arrPrevent = []) =>
    (Component) => {
        const CheckCompany = (props) => {
            const AllowCompany = arrCompany.filter((c) => !arrPrevent.includes(c))
            const activeCode = glb_sv.activeCode
            if (AllowCompany.includes(activeCode)) {
                return <Component {...props} />
            } else {
                console.error('Sai activeCode, công ty này không được sử dụng màn hình này')
                return <NotAuthView wrongActiveCode />
            }
            // return (
            //     <View></View>
            // )
        }
        return CheckCompany
    }

export default PreventCompany
