import React, { useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { NativeModules, Platform } from 'react-native'
import RenderHTML from 'react-native-render-html'
import ModalController from '@mts-components/appModal/modalControlller'
import { useSaveCurrentStep } from '@mts-layouts/eKYCFPT/hooks/useSaveCurrentStep'
import { fontSizes, IconSvg } from '@mts-styles/index'
import { Screens } from '@mts-utils/index'
import { navigate2Ekyc } from '@mts-utils/navigate2Ekyc'
import { useNavigation } from '@react-navigation/native'

import { StoreContext } from '../../store'

const IOS = Platform.OS === 'ios' ? true : false

export const openAccountPopupNotification = () => {
    const { t } = useTranslation()
    const { styles } = useContext(StoreContext)
    const { getData, deleteData } = useSaveCurrentStep()
    const navigation = useNavigation()

    const popupDontFinishEKYC = () => {
        ModalController.showModal({
            icon: <IconSvg.ErrorIcon color={styles.INFO__COLOR} />,
            title: t('common_notify'),
            content: t('ekyc_notify_open_account'),
            typeColor: styles.PRIMARY,
            titleOK: t('common_alert_agree').toLocaleUpperCase(),
            showCancel: false,
            linkCallback: () => {
                getData({
                    callback: () => {
                        ModalController.showModal({
                            icon: null,
                            title: null,
                            content: t('reopen_ekyc_title'),
                            typeColor: styles.PRIMARY,
                            titleOK: t('reopen_ekyc_next_btn'),
                            titleCancel: t('reopen_ekyc_next_cancel'),
                            showCancel: true,
                            cancelCallBack: () => {
                                deleteData({
                                    callback: () => navigate2Ekyc({ IOS, NativeModules, styles }),
                                })
                            },
                            linkCallback: () => {
                                navigate2Ekyc({ IOS, NativeModules, styles, isHasPrevStep: true })
                            },
                        })
                    },
                    callbackNoHaveData: () => {
                        navigate2Ekyc({ IOS, NativeModules, styles })
                    },
                })
            },
        })
    }

    const popupWaitingSSVSignContract = (linkCallback?: void) => {
        ModalController.showModal({
            icon: <IconSvg.ErrorIcon color={styles.INFO__COLOR} />,
            title: t('common_notify'),
            content: t('notify_ekyc_wating_ssv_sign'),
            typeColor: styles.PRIMARY,
            titleOK: t('common_alert_agree').toLocaleUpperCase(),
            showCancel: false,
            linkCallback: linkCallback,
        })
    }

    const econtractWillSendLater = () => {
        ModalController.showModal({
            icon: <IconSvg.ErrorIcon color={styles.INFO__COLOR} />,
            title: t('common_notify'),
            colorTitle: styles.EKYC__COLOR,
            middleComponent: <HTMLNoteContent title={'notify_ekyc_econtract_will_send_later_2'} />,
            titleOK: t('common_alert_agree').toLocaleUpperCase(),
            typeColor: styles.EKYC__COLOR,
            linkCallback: () => navigation.navigate(Screens.ECONTRACT_MANAGEMENT),
            // showCancel: true,
        })
    }

    const HTMLNoteContent = ({ title, textAlign }: { title: string; textAlign: string }) => {
        const escapeHtml = () => {
            return t(title)
                .replace(/&amp;/g, '&')
                .replace(/&lt;/g, '<')
                .replace(/&gt;/g, '>')
                .replace(/&quot/g, '"')
                .replace(/&#039;/g, "'")
        }

        const tagsStyles = {
            strong: {
                color: styles.EKYC__COLOR,
            },
        }

        return (
            <RenderHTML
                baseStyle={{
                    fontSize: fontSizes.normal,
                    color: styles.EKYC__SILVER,
                    overflow: 'visible',
                    textAlign: textAlign || 'center',
                    marginLeft: 8,
                    marginRight: 8,
                    marginBottom: 16,
                }}
                source={{
                    html: escapeHtml(),
                }}
                tagsStyles={tagsStyles}
            />
        )
    }

    return { popupDontFinishEKYC, popupWaitingSSVSignContract, econtractWillSendLater }
}
