import { StyleSheet, TextStyle } from 'react-native'

type StyleProps = {
    radius: number
    progressValueColor?: string
    progressValueFontSize?: number
    progressValueStyle?: TextStyle
    activeStrokeColor?: string
    titleStyle?: TextStyle
    titleColor?: string
    titleFontSize?: number
    showProgressValue?: boolean
    subtitleColor?: string
    subtitleFontSize?: number
    subtitleStyle: TextStyle
    rotation: number
}

const styles = (props: StyleProps) => {
    return StyleSheet.create({
        container: {
            alignItems: 'center',
            height: props.radius * 2,
            justifyContent: 'center',
            width: props.radius * 2,
        },
        fromProps: {
            color: props.progressValueColor || props.progressValueStyle?.color || props.activeStrokeColor,
            fontSize: props.progressValueFontSize || props.progressValueStyle?.fontSize || props.radius / 2,
        },
        input: {
            fontWeight: 'bold',
            textAlign: 'center',
        },
        rotatingContainer: {
            transform: [{ rotate: `${props.rotation}deg` }],
        },
        subtitle: {
            color: props.subtitleColor || props.subtitleStyle?.color || props.activeStrokeColor,
            fontSize: props.subtitleFontSize || props.subtitleStyle?.fontSize || props.radius / 5,
        },
        title: {
            color: props.titleColor || props.titleStyle?.color || props.activeStrokeColor,
            fontSize: props.titleFontSize || props.titleStyle?.fontSize || props.radius / 4,
            marginTop: props.showProgressValue ? props.radius * 0.05 : 0,
            textAlign: 'center',
            width: '70%',
        },
        valueContainer: {
            alignItems: 'center',
            flex: 1,
            justifyContent: 'center',
        },
    })
}

export default styles
