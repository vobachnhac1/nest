import React, { memo, useContext, useMemo } from 'react'
import { useTranslation } from 'react-i18next'
import { StyleSheet, Text, View } from 'react-native'
import { Row } from 'native-base'

import { OrderBy } from '../../../basic-components'
import { StoreContext } from '../../../store'
import { dimensions } from '../../../styles'

const listTimeHis = ['1W', '1M', '3M', '6M', '1Y', '2Y', '3Y']

const HeaderTop = ({ activeOtp, typeTop, changeTypeSort, sort }) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()

    const HeaderTopWrapUI = useMemo(
        () => StyleSheet.flatten([{ borderBottomColor: styles.DIVIDER__COLOR, flex: 0, borderBottomWidth: 1, height: 30 }]),
        [styles],
    )

    return (
        <Row style={HeaderTopWrapUI}>
            <View style={UI.Flex1}>
                <OrderBy
                    changeTypeSort={changeTypeSort}
                    notShowActive={true}
                    sortType="col1"
                    status={sort === 'col1|up' ? 'asc' : sort === 'col1|down' ? 'desc' : ''}
                    title={t('short_symbol')}
                />
            </View>
            <View style={UI.Flex1}>
                <OrderBy
                    changeTypeSort={changeTypeSort}
                    itemAlign="flex-end"
                    notShowActive={true}
                    sortType="col2"
                    status={sort === 'col2|up' ? 'asc' : sort === 'col2|down' ? 'desc' : ''}
                    title={'%'}
                />
            </View>
            <View style={UI.Flex1}>
                <OrderBy
                    changeTypeSort={changeTypeSort}
                    itemAlign="flex-end"
                    notShowActive={true}
                    sortType="col3"
                    status={sort === 'col3|up' ? 'asc' : sort === 'col3|down' ? 'desc' : ''}
                    title={
                        typeTop === 'FRG_VAL_UP' ? t('priceboard_total_buy_value_trading') : listTimeHis.includes(activeOtp) ? t('common_bottom') : t('open')
                    }
                />
            </View>
            <View style={UI.Flex1}>
                <OrderBy
                    changeTypeSort={changeTypeSort}
                    itemAlign="flex-end"
                    notShowActive={true}
                    sortType="col4"
                    status={sort === 'col4|up' ? 'asc' : sort === 'col4|down' ? 'desc' : ''}
                    title={
                        typeTop === 'FRG_VAL_UP' ? t('priceboard_total_sell_value_trading') : listTimeHis.includes(activeOtp) ? t('common_top') : t('current')
                    }
                />
            </View>
            <View style={UI.Flex1}>
                <OrderBy
                    changeTypeSort={changeTypeSort}
                    itemAlign="flex-end"
                    notShowActive={true}
                    sortType="col5"
                    status={sort === 'col5|up' ? 'asc' : sort === 'col5|down' ? 'desc' : ''}
                    title={typeTop === 'FRG_VAL_UP' ? t('trade_value_net') : typeTop === 'TOP_VAL_UP' ? t('common_values') : t('volume')}
                />
            </View>
        </Row>
    )
}

export default memo(HeaderTop)

const UI = StyleSheet.create({
    Flex1: { flex: 1 },
})
