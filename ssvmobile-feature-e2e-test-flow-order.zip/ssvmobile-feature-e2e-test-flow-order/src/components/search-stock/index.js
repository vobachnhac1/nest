import React, { useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { FlatList, InteractionManager, Keyboard, KeyboardAvoidingView, Platform, Pressable, StyleSheet, TextInput, TouchableOpacity, View } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import AntDesign from 'react-native-vector-icons/AntDesign'
import { CommonActions } from '@react-navigation/native'
import { Body, ListItem, Right, Toast } from 'native-base'
import SyncStorage from 'sync-storage'

import { FocusAwareStatusBar, Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { dimensions, fontSizes, fontWeights } from '../../styles'
import { IOS } from '../../styles/helper/dimensions'
import { eventList, glb_sv, reqFunct, saveStatisticTrackingStock, Screens, sendRequest, STORE_KEY } from '../../utils'
import { AddStockToListFav, RemoveStockInListFav } from '../portfolio/favorite-func/favorite.action'

const ServiceInfo = {
    AddStockToFavList: {
        reqFunct: reqFunct.ADD_STOCK_TO_FAV_LIST,
        WorkerName: 'FOSxID01',
        ServiceName: 'FOSxID01_FavoritesMgt',
        ClientSentTime: '0',
        Operation: 'I',
    },
    removeStockFromFavList: {
        reqFunct: reqFunct.REMOVE_STOCK_IN_FAV_LIST,
        WorkerName: 'FOSxID01',
        ServiceName: 'FOSxID01_FavoritesMgt',
        ClientSentTime: '0',
        Operation: 'D',
    },
}

export default function SearchStock({ navigation, route }) {
    const { actionType, changeStock, STOCK_INFO_CODE } = route.params

    const { styles, recentStkList, setRecentStkList, theme } = useContext(StoreContext)

    const { t } = useTranslation()
    const [seach, setSearch] = useState('')
    const [listStock, setListStock] = useState([])
    const timeOutSearch = useRef(null)
    const selectStockRef = useRef('')

    const [recentList, setRecentList] = useState([])

    const searchRef = useRef('')
    const searchInputRef = useRef(null)

    useEffect(() => {
        getListRencent()
        InteractionManager.runAfterInteractions(() => searchInputRef.current?.focus())

        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.CHANGE_LIST_STOCK) {
                getListRencent()
                changeListStock()
            }
            if (msg.type === eventList.REQ_GET_MKT_INF_FIRST) {
                getListRencent()
            }
        })
        const eventMarket = glb_sv.eventMarket.subscribe((msg) => {
            if (msg.type === eventList.REQ_RE_GET_MKT_INF) {
                getListRencent()
            }
        })

        return () => {
            commonEvent.unsubscribe()
            eventMarket.unsubscribe()
        }
    }, [])

    const changeListStock = () => {
        if (!searchRef.current) return

        const stkExact = glb_sv.mrk_stklist.filter((e) => e.t55 === searchRef.current)
        const newList = stkExact.concat(
            glb_sv.mrk_stklist
                .filter((e) => e.t55.includes(searchRef.current))
                .filter((e) => e.t55 !== searchRef.current)
                .slice(0, 30)
                .sort(function (a, b) {
                    if (a.t55 > b.t55) return -1
                    if (a.t55 < b.t55) return 1
                    return 0
                }),
        )

        const newList1 = []
        newList.forEach((element) => {
            const obj = glb_sv.mrk_stklist.find((e) => e.t55 === element.t55)
            if (obj) {
                const cloneObj = { ...obj }
                if (glb_sv.activeList.type === 'watchlist' && glb_sv.activeList.ListStock.some((temp) => temp === cloneObj.t55)) {
                    cloneObj.isFav = true
                }
                newList1.push(cloneObj)
            }
        })
        setListStock(newList1)
    }

    const getListRencent = () => {
        const newList = []
        recentStkList.forEach((element) => {
            const obj = glb_sv.mrk_stklist.find((e) => e.t55 === element)
            if (obj) {
                const cloneObj = { ...obj }
                if (glb_sv.activeList.type === 'watchlist' && glb_sv.activeList.ListStock.some((temp) => temp === cloneObj.t55)) {
                    cloneObj.isFav = true
                }
                newList.push(cloneObj)
            }
        })
        setRecentList(newList)
    }

    const getListStock = (value) => {
        const name = value ? value.toUpperCase() : ''
        searchRef.current = name
        setSearch(name)
        if (name === '') {
            if (timeOutSearch.current) clearTimeout(timeOutSearch.current)
            setListStock([])
            return
        }
        if (timeOutSearch.current) clearTimeout(timeOutSearch.current)
        timeOutSearch.current = setTimeout(() => {
            const stkExact = glb_sv.mrk_stklist.filter((e) => e.t55 === name)
            const newList = stkExact.concat(
                glb_sv.mrk_stklist
                    .filter((e) => e.t55.includes(name) || e.U9.toUpperCase().includes(name))
                    .filter((e) => e.t55 !== name)
                    .slice(0, 30)
                    .sort(function (a, b) {
                        if (a.t55 > b.t55) return -1
                        if (a.t55 < b.t55) return 1
                        return 0
                    }),
            )
            const newList1 = []
            newList.forEach((element) => {
                const obj = glb_sv.mrk_stklist.find((e) => e.t55 === element.t55)
                if (obj) {
                    const cloneObj = { ...obj }
                    if (glb_sv.activeList.type === 'watchlist' && glb_sv.activeList.ListStock.some((temp) => temp === cloneObj.t55)) {
                        cloneObj.isFav = true
                    }
                    newList1.push(cloneObj)
                }
            })
            setListStock(newList1)
        }, 300)
    }

    const StockItem = ({ item }) => {
        return (
            <ListItem
                activeOpacity={0.6}
                style={{ borderBottomColor: styles.PRIMARY__BG__COLOR }}
                underlayColor="transparent"
                onPress={() => handleStock(item)}
            >
                <Body style={UI.body_stock}>
                    <Text
                        style={{
                            color: styles.PRIMARY__CONTENT__COLOR,
                            fontSize: fontSizes.small,
                            fontWeight: fontWeights.medium,
                        }}
                    >
                        {item.t55}{' '}
                        <Text
                            style={{
                                color: styles.SECOND__CONTENT__COLOR,
                                fontSize: fontSizes.smallest,
                            }}
                        >
                            {getExchange(item.U10)}
                        </Text>
                    </Text>
                    <Text
                        style={{
                            color: styles.SECOND__CONTENT__COLOR,
                            fontSize: fontSizes.smallest,
                        }}
                    >
                        {item.U9}
                    </Text>
                </Body>
                <Right style={UI.right_stock}>
                    {actionType === 'FAV_ACTION' ? (
                        <TouchableOpacity
                            style={{
                                alignItems: 'center',
                                height: 32,
                                borderRadius: 32,
                                borderWidth: 1,
                                borderColor: styles.PRIMARY,
                                backgroundColor: item.isFav ? styles.PRIMARY : styles.PRIMARY__BG__COLOR,
                                width: dimensions.moderate(87),
                                justifyContent: 'center',
                            }}
                            onPress={() => onPressAddStockToList(item.t55, true)}
                        >
                            <Text style={{ fontSize: fontSizes.verySmall, fontWeight: fontWeights.medium, color: item.isFav ? '#FFF' : styles.PRIMARY }}>
                                {item.isFav ? t('added') : t('add')}
                            </Text>
                        </TouchableOpacity>
                    ) : null}
                </Right>
            </ListItem>
        )
    }

    const handleStock = (item) => {
        const newList = recentStkList.filter((e) => e !== item.t55)
        if (newList.length >= 5) {
            newList.pop()
        }
        newList.unshift(item.t55)
        SyncStorage.set(STORE_KEY.RECENT_STOCK_LIST, newList)
        setRecentStkList(newList)

        const newList1 = []
        newList.forEach((element) => {
            const obj = glb_sv.mrk_stklist.find((e) => e.t55 === element)
            if (obj) {
                const cloneObj = { ...obj }
                if (glb_sv.activeList.type === 'watchlist' && glb_sv.activeList.ListStock.some((temp) => temp === cloneObj.t55)) {
                    cloneObj.isFav = true
                }
                newList1.push(cloneObj)
            }
        })
        setRecentList(newList1)

        if (actionType === 'PLACE_ORDER') {
            changeStock(item.t55)
            navigation.pop()
            return
        }
        if (actionType === 'FAV_ACTION') {
            onPressAddStockToList(item.t55)
            return
        }

        if (actionType === 'STOCK_INFO') {
            if (STOCK_INFO_CODE !== item.t55) {
                navigation.dispatch((state) => {
                    const routes = state.routes.filter((r) => r.name !== Screens.STOCK_INFO && r.name !== Screens.SEARCH_STOCK)
                    routes.push({ name: Screens.STOCK_INFO, params: { stockCode: item.t55 } })
                    return CommonActions.reset({
                        ...state,
                        routes,
                        index: routes.length - 1,
                    })
                })
            } else {
                navigation.pop()
            }

            return
        }

        navigation.navigate(Screens.STOCK_INFO, { stockCode: item.t55 })
    }

    const getExchange = (type) => {
        if (type === '01') return 'HOSE'
        if (type === '03') return 'HNX'
        if (type === '05') return 'UPCOM'
    }

    const resetData = () => {
        searchInputRef.current?.focus()
        setSearch('')
        // searchInputRef.current?.clear();
        setListStock([])
    }

    const ListEmpty = () => {
        return (
            <View style={{ justifyContent: 'center', flex: 1, margin: 10 }}>
                <Text style={{ textAlign: 'center', color: styles.PRIMARY__CONTENT__COLOR }}>{t('no_match_result')}</Text>
            </View>
        )
    }

    const onPressAddStockToList = (stk, isRemove) => {
        selectStockRef.current = stk
        handleStockFav(glb_sv.activeList, stk, isRemove)

        navigation.pop()

        Keyboard.dismiss()
        return
    }

    const onChangeStatus = () => {
        getListRencent()

        if (!searchRef.current) return
        const stkExact = glb_sv.mrk_stklist.filter((e) => e.t55 === searchRef.current)
        const newList = stkExact.concat(
            glb_sv.mrk_stklist
                .filter((e) => e.t55.includes(searchRef.current))
                .filter((e) => e.t55 !== searchRef.current)
                .slice(0, 30)
                .sort(function (a, b) {
                    if (a.t55 > b.t55) return -1
                    if (a.t55 < b.t55) return 1
                    return 0
                }),
        )
        const newList1 = []
        newList.forEach((element) => {
            const obj = glb_sv.mrk_stklist.find((e) => e.t55 === element.t55)
            if (obj) {
                const cloneObj = { ...obj }
                glb_sv.allListFav
                    .filter((e) => e.type !== 'suggest' && e.type !== 'own')
                    .forEach((item) => {
                        if (item.ListStock.some((temp) => temp === cloneObj.t55)) {
                            cloneObj.isFav = true
                        }
                    })
                newList1.push(cloneObj)
            }
        })
        setListStock(newList1)
    }

    const handleStockFav = (item, stk, isRemove) => {
        const value = !checkExistInWatchList(item.ListStock, stk)
        if (item.ListStock.length >= 30 && value) {
            Toast.show({
                text: t('notify_fav_limit'),
                type: 'warning',
                position: 'bottom',
            })
            return
        }

        if (glb_sv.authFlag) {
            if (value) {
                const InputParams = ['FAV_ITEM_ADD', item.c1, stk]
                sendRequest(ServiceInfo.AddStockToFavList, InputParams, handleAddStockToFavList, true, handleStockFavTimeout)

                saveStatisticTrackingStock(stk)
            } else if (value === false) {
                if (actionType === 'FAV_ACTION' && !isRemove) {
                    return
                }
                const InputParams = ['FAV_ITEM_REMOVE', item.c1, stk]
                sendRequest(ServiceInfo.removeStockFromFavList, InputParams, handleRmStkFrFavList, true, handleStockFavTimeout)
            }
        } else {
            if (value) {
                AddStockToListFav(item.c1, stk)
            }
            if (value === false) {
                if (actionType === 'FAV_ACTION' && !isRemove) {
                    return
                }
                RemoveStockInListFav(item.c1, stk)
            }

            onChangeStatus()
        }
    }

    const handleStockFavTimeout = () => {
        Toast.show({
            text: t('request_hanlde_not_success_try_again'),
            type: 'warning',
            position: 'bottom',
        })
    }

    const handleAddStockToFavList = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            if (message.Code === '010012') {
                Toast.show({
                    text: t('request_hanlde_not_success_try_again'),
                    type: 'warning',
                    position: 'bottom',
                })
            } else {
                Toast.show({
                    text: message.Message,
                    type: 'warning',
                    position: 'bottom',
                })
            }
            return
        } else {
            try {
                const current = glb_sv.allListFav.find((x) => x.c1 === reqInfoMap.inputParam[1])
                current.ListStock.push(selectStockRef.current)
                if (glb_sv.activeList.c1 === current.c1) {
                    glb_sv.activeList = { ...current }
                    glb_sv.commonEvent.next({ type: eventList.CHANGE_LIST_STOCK, value: selectStockRef.current, isSub: true })
                } else {
                    onChangeStatus()
                }
            } catch (err) {
                console.log('error', err)
            }
        }
    }

    const handleRmStkFrFavList = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            if (message.Code === '010012') {
                Toast.show({
                    text: t('request_hanlde_not_success_try_again'),
                    type: 'warning',
                    position: 'bottom',
                })
            } else {
                Toast.show({
                    text: message.Message,
                    type: 'warning',
                    position: 'bottom',
                })
            }
            return
        } else {
            try {
                const current = glb_sv.allListFav.find((x) => x.c1 === reqInfoMap.inputParam[1])
                current.ListStock = current.ListStock.filter((e) => e !== selectStockRef.current)
                if (glb_sv.activeList.c1 === current.c1) {
                    glb_sv.activeList = { ...current }
                    glb_sv.commonEvent.next({ type: eventList.CHANGE_LIST_STOCK, value: selectStockRef.current, isSub: false })
                } else {
                    onChangeStatus()
                }
            } catch (err) {
                console.log('error', err)
            }
        }
    }

    const checkExistInWatchList = (ListStock, stock) => {
        if (ListStock.some((e) => e === stock)) return true
        return false
    }

    return (
        <View
            style={{
                flex: 1,
                backgroundColor: styles.PRIMARY__BG__COLOR,
            }}
        >
            <FocusAwareStatusBar backgroundColor={'transparent'} barStyle={theme.includes('DARK') ? 'light-content' : 'dark-content'} translucent={true} />
            <SafeAreaView edges={['right', 'top', 'left']} style={{ flex: 1 }}>
                <View
                    style={{
                        flexDirection: 'row',
                        paddingHorizontal: 16,
                        marginTop: 8,
                    }}
                >
                    <View
                        style={{
                            backgroundColor: styles.HEADER__BG__COLOR,
                            flexDirection: 'row',
                            flex: 1,
                            borderRadius: 40,
                            paddingHorizontal: 8,
                            paddingVertical: 2,
                        }}
                    >
                        <AntDesign color={styles.PLACEHODLER__COLOR} name="search1" size={20} style={{ paddingVertical: 7, paddingLeft: 5 }} />
                        <TextInput
                            autoCapitalize="characters"
                            autoFocus
                            keyboardType={Platform.OS === 'ios' ? null : 'visible-password'}
                            placeholder={t('choose_symbol_trading')}
                            placeholderTextColor={styles.PLACEHODLER__COLOR}
                            ref={searchInputRef}
                            secureTextEntry={Platform.OS === 'ios' ? false : true}
                            style={{
                                color: styles.PRIMARY__CONTENT__COLOR,
                                fontSize: fontSizes.small,
                                padding: 0,
                                paddingHorizontal: 5,
                                flex: 1,
                            }}
                            value={seach}
                            onChangeText={(search) => getListStock(search)}
                        />
                        {seach ? (
                            <AntDesign
                                color={styles.PLACEHODLER__COLOR}
                                name="closecircle"
                                size={20}
                                style={{ paddingVertical: 7, paddingHorizontal: 5 }}
                                onPress={resetData}
                            />
                        ) : null}
                    </View>
                    <Pressable
                        hitSlop={10}
                        style={{ paddingVertical: 0, paddingHorizontal: 10, alignItems: 'center', justifyContent: 'center' }}
                        onPress={() => navigation.pop()}
                    >
                        <Text
                            style={{
                                color: styles.PRIMARY__CONTENT__COLOR,
                                fontSize: fontSizes.small,
                                lineHeight: dimensions.moderate(17),
                                fontWeight: fontWeights.medium,
                            }}
                        >
                            {t('common_accomplished')}
                        </Text>
                    </Pressable>
                </View>
                <KeyboardAvoidingView behavior={IOS ? 'padding' : 'height'} style={{ flex: 1, paddingBottom: IOS ? 0 : 10 }}>
                    {listStock.length === 0 && seach.length === 0 ? (
                        recentList.length ? (
                            <View style={{ marginTop: 16 }}>
                                <Text
                                    style={{
                                        color: styles.HEADER__CONTENT__COLOR,
                                        paddingHorizontal: 16,
                                    }}
                                >
                                    {t('search_recent')}
                                </Text>
                                {recentList.map((item) => (
                                    <StockItem item={item} key={item.t55} />
                                ))}
                            </View>
                        ) : null
                    ) : (
                        <FlatList
                            data={listStock}
                            keyboardShouldPersistTaps="always"
                            keyExtractor={(item, index) => item?.t55 || index.toString()}
                            ListEmptyComponent={ListEmpty}
                            renderItem={StockItem}
                            style={{ marginBottom: 10 }}
                        />
                    )}
                </KeyboardAvoidingView>
            </SafeAreaView>
        </View>
    )
}

const UI = StyleSheet.create({
    body_stock: {
        flexDirection: 'column',
        flex: 2,
        justifyContent: 'flex-start',
    },
    right_stock: {
        alignItems: 'flex-end',
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'center',
        paddingRight: 0,
    },
})
