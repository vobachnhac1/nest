/**
 * ------------------------ Cấu hình ứng dụng (tĩnh - không lưu local thay đổi)
 * 1. Các cấu hình về UI, bặt tắt một tính năng nào đó
 * 2. Cấu hình các input mặc định, hoặc constant (Size Avatar cho từng công ty, ...)
 *
 */
import { Company } from './config'

export interface IApplicationConfig {
    is_show_promotion_popup: boolean
    is_show_event_banner: boolean
}

const ApplicationConfig: { [key: string]: IApplicationConfig } = {
    '081': {
        is_show_promotion_popup: true,
        is_show_event_banner: true,
    },
}

export default ApplicationConfig
