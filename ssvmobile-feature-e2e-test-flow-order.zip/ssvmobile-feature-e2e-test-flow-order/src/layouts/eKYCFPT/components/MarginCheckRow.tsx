import React, { useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { StyleSheet, Switch, TouchableOpacity, View } from 'react-native'

import { Text } from '../../../basic-components'
import { CustomSwitch } from '../../../components/trading-component'
import { StoreContext } from '../../../store'
import { dimensions as dm, fontSizes as fs, IconSvg } from '../../../styles'

interface IMarginCheckRowProps {
    checkMargin: boolean
    setCheckMargin: (isAutoPIA: boolean) => void
}

export const MarginCheckRow = ({ setCheckMargin = () => null, checkMargin }: IMarginCheckRowProps) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()

    const [isCheckMargin, setIsCheckMargin] = useState(checkMargin || false)

    useEffect(() => {
        setCheckMargin(isCheckMargin)
    }, [isCheckMargin])

    return (
        <View style={UI.row}>
            <TouchableOpacity style={{}} onPress={() => setIsCheckMargin((value) => !value)}>
                <IconSvg.CheckboxIcon active={checkMargin} colorActive={styles.PRIMARY} colorunActive={styles.PRIMARY__CONTENT__COLOR} size={24} />
            </TouchableOpacity>
            <TouchableOpacity
                activeOpacity={0.9}
                style={{
                    flex: 1,
                    flexDirection: 'row',
                    alignItems: 'flex-start',
                    justifyContent: 'space-between',
                }}
                onPress={() => setIsCheckMargin((value) => !value)}
            >
                <View style={{ flex: 5 }}>
                    <Text
                        style={{
                            fontSize: 16,
                            color: styles.PRIMARY__CONTENT__COLOR,
                            marginLeft: dm.moderate(8),
                            marginRight: 8,
                        }}
                    >
                        {t<string>('active_act_trade_margin')}
                    </Text>
                    <Text
                        style={{
                            fontSize: fs.small,
                            fontStyle: 'italic',
                            color: styles.WARN__COLOR,
                            marginLeft: dm.moderate(8),
                            paddingTop: 4,
                            marginRight: 16,
                        }}
                    >
                        {t<string>('margin_register_service_note')}
                    </Text>
                </View>
            </TouchableOpacity>
        </View>
    )
}

const UI = StyleSheet.create({
    row: {
        flexDirection: 'row',
        marginHorizontal: dm.moderate(16),
        marginTop: 16,
    },
})
