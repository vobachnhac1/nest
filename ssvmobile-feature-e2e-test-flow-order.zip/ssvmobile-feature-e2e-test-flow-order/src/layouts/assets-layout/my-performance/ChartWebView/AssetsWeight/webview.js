import React, { Component, createRef } from 'react'
import { Platform, StyleSheet } from 'react-native'
import WebView from 'react-native-webview'

import { glb_sv } from '../../../../../utils'

const source = Platform.select({
    ios: require('../../../../../basic-components/custom-chart/index.html'),
    android: { uri: 'file:///android_asset/index.html' },
})

// export default memo(WebviewChart)
export default class WebviewChart extends Component {
    constructor(props) {
        super(props)
        this.chartRef = createRef()

        this.state = {
            webviewKey: new Date().getTime(),
        }
    }

    componentWillReceiveProps(nextProps) {
        this.chartRef &&
            this.chartRef.current.injectJavaScript(`
            window.dataAssetWeightFull = ${nextProps.dataChart};
            if (window.eventMarket) {
                window.eventMarket.next({ type: 'highchart-render', value: 'dataAssetWeightFull' })
            }
            true;
        `)
    }

    shouldComponentUpdate(nextProps, nextState) {
        if (nextState.webviewKey !== this.state.webviewKey) {
            return true
        }
        if (nextProps.theme !== this.props.theme) {
            this.chartRef.current?.reload()
            return true
        }
        return false
    }
    reload = () => {
        this.setState({
            webviewKey: this.state.webviewKey + 1,
        })
    }

    render() {
        return (
            <WebView
                allowUniversalAccessFromFileURLs={true}
                domStorageEnabled={true}
                injectedJavaScriptBeforeContentLoaded={`
                    window.chartName = 'my_performance_assets_weight';
                    window.asset_weight = '${this.props.t('asset_weight')}';
                    window.assets_weight = '${this.props.t('assets_weight')}';
                    window.statictis = '${this.props.t('statictis')}';
                    window.profit_or_loss_ratio = '${this.props.t('profit_or_loss_ratio')}';
                    window.ratio_index = '${this.props.t('ratio_index')}';
                    window.absolute_efficiency = '${this.props.t('absolute_efficiency')}';
                    window.compare_vnindex = '${this.props.t('compare_vnindex')}';
                    window.title_assets = '${this.props.t('stock_title')}';
                    window.title_cash = '${this.props.t('title_cash')}';
                    window.title_debt = '${this.props.t('common_debt')}';

                    window.workDate = '${glb_sv.objShareGlb.workDate}';
                    window.theme = '${this.props.theme}'
                    window.PRIMARY__CONTENT__COLOR = '${this.props.styles.PRIMARY__CONTENT__COLOR}';
                    window.PRIMARY = '${this.props.styles.PRIMARY}';
                    window.REF__COLOR = '${this.props.styles.REF__COLOR}';
                    window.PRIMARY__BG__COLOR = '${this.props.styles.PRIMARY__BG__COLOR}';
                    window.DIVIDER__COLOR = '${this.props.styles.DIVIDER__COLOR}';
                    window.ICON__PRIMARY = '${this.props.styles.ICON__PRIMARY}';
                    window.dataAssetWeightFull = [];
                `}
                javaScriptEnabled
                source={source}
                // source={{
                //     uri: 'http://192.168.1.31:3000' || 'http://localhost:3000/',
                // }}
                originWhitelist={['*']}
                ref={this.chartRef}
                scrollEnabled={false}
                style={UI.webView}
                androidLayerType="hardware"
                // androidHardwareAccelerationDisabled
                // onMessage={this.onMessage}
                onContentProcessDidTerminate={this.reload}
            />
        )
    }
}

const UI = StyleSheet.create({
    webView: {
        backgroundColor: 'transparent',
        flex: 1,
    },
})
