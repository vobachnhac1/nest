import { StyleSheet } from 'react-native'

type StyleProp = {
    radius: number
    rotation: number
}

const styles = (props: StyleProp) =>
    StyleSheet.create({
        container: {
            alignItems: 'center',
            height: props.radius * 2,
            justifyContent: 'center',
            width: props.radius * 2,
        },
        rotatingContainer: {
            transform: [{ rotate: `${props.rotation}deg` }],
        },
        valueContainer: {
            alignItems: 'center',
            flex: 1,
            justifyContent: 'center',
        },
    })

export default styles
