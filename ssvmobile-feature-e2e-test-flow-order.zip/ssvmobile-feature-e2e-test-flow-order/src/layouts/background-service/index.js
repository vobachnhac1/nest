import React, { memo, useContext, useEffect, useRef } from 'react'
import { useTranslation } from 'react-i18next'
import { InteractionManager, Platform } from 'react-native'
import FingerprintScanner from 'react-native-fingerprint-scanner'
import * as Keychain from 'react-native-keychain'
import OneSignal from 'react-native-onesignal'
import getUniqueIdDevice from '@mts-utils/getUniqueIdDevice'
import uniq from 'lodash/uniq'
import moment from 'moment'
import SyncStorage from 'sync-storage'

import { application_config } from '../../assets/config'
import { allowCompanyRender } from '../../hoc'
import ModalAlertProvider from '../../navigation/ModalAlertProvider'
import { StoreContext } from '../../store'
import { StoreTrading } from '../../store-trading'
import { eventList, glb_sv, InfoIndex, reqFunct, sendRequest, socket_sv, STORE_KEY, subcribeFunct } from '../../utils'
import FullImageAdvertisingModal from './AdvertisingModal/FullImageAdvertisingModal'
import ImageAndContentAdvertisingModal from './AdvertisingModal/ImageAndContentAdvertisingModal'
import ModalAuthenOtpPhone from './modal-authen-otp-phone'
import ModalNewReleaseNotes from './ModalNewReleaseNotes'
import ModalNotifyNewVersion from './ModalNotifyNewVersion'
import ModalVerifyOrderAfterLogin from './ModalVerifyOrderAfterLogin'

const ServiceInfo = {
    LOGIN_FUNCTION: {
        reqFunct: reqFunct.LOGIN_FUNCTION,
        WorkerName: 'FOSxID02',
        ServiceName: 'FOSxID02_Login',
        ClientSentTime: '0',
        Operation: 'Q',
    },
    getFav: {
        reqFunct: reqFunct.GET_FAV_INFO,
        WorkerName: 'FOSqID01',
        ServiceName: 'FOSqID01_FavoritesMgt',
        Operation: 'Q',
        ClientSentTime: '0',
    },
    getDetailList: {
        reqFunct: reqFunct.GET_DETAIL_FAV_LIST,
        WorkerName: 'FOSqID01',
        ServiceName: 'FOSqID01_FavoritesMgt',
        Operation: 'Q',
        ClientSentTime: '0',
    },
    GET_INDEX_LIST: {
        reqFunct: reqFunct.GET_INDEX_LIST,
        WorkerName: 'FOSqMkt02',
        ServiceName: 'FOSqMkt02_IndexMgt',
        ClientSentTime: '0',
        Operation: 'Q',
    },
    EKYC_INFO: {
        reqFunct: reqFunct.EKYC_INFO,
        WorkerName: 'FOSqID01',
        ServiceName: 'FOSqID01_EKYCInfo',
        ClientSentTime: '0',
        Operation: 'Q',
    },
    GET_LIST_OWN: {
        reqFunct: reqFunct.GET_LIST_OWN,
        WorkerName: 'FOSqStock',
        ServiceName: 'FOSqStock_01_online',
        Operation: 'Q',
        ClientSentTime: '0',
    },
    CONFIG_NOTIFY: {
        reqFunct: reqFunct.CONFIG_NOTIFY,
        WorkerName: 'FOSxID01',
        ServiceName: 'FOSxID01_Token_Mgt',
        Operation: 'I',
        ClientSentTime: '0',
    },
    QUERY_USER_INFORMATION: {
        reqFunct: reqFunct.QUERY_USER_INFORMATION,
        WorkerName: 'FOSqID02',
        ServiceName: 'FOSqID02_UserInformation',
        ClientSentTime: '0',
        Operation: 'Q',
    },
    GET_LIST_STOCK_INTO_INDEX: {
        reqFunct: reqFunct.GET_LIST_STOCK_INTO_INDEX,
        WorkerName: 'FOSqMkt02',
        ServiceName: 'FOSqMkt02_IndexMgt',
        ClientSentTime: '0',
        Operation: 'Q',
    },
}

function BackgroundServiceMemo() {
    const TAG = 'BackgroundServiceMemo'
    const { t } = useTranslation()
    const { setAuth, setConnected } = useContext(StoreContext)
    const { setUserInfo } = useContext(StoreTrading)

    const reLoginCallTimeout = useRef(null)
    const autoLoginCallTimeout = useRef(null)

    const numberReLogin = useRef(0)

    const flagListIndex = useRef(false)

    const reLoginFlag = useRef(false)

    const isSensorAvailable = useRef(false)
    const flagAuthenBiometric = useRef(false)

    const tempFav = useRef([])
    const tempFavList = useRef({})

    useEffect(() => {
        setTimeout(() => {
            glb_sv.commonEvent.next({
                type: eventList.OPEN_NEW_RELEASE_NOTES_INFO_MODAL,
                onConfirmViewReleaseNotes: () => {
                    // setTimeout(() => {
                    //     // glb_sv.commonEvent.next({ type: eventList.OPEN_NEW_RELEASE_NOTES_INFO_MODAL })
                    // }, 1000);
                },
            })
        }, 1000)
        // Lắng nghe thay đổi về trạng thái network và authen
        const eventConnect = glb_sv.eventConnect.subscribe((msg) => {
            if (msg.type === socket_sv.connect_event.REQ_RELOGIN) {
                reLogin()
                return
            }
            if (msg.type === socket_sv.connect_event.REQ_AUTO_LOGIN) {
                setTimeout(() => {
                    InteractionManager.runAfterInteractions(() => {
                        const IsAuthenBiometricStore = SyncStorage.get(STORE_KEY.AUTHEN_BIOMETRIC)
                        if (IsAuthenBiometricStore) {
                            setTimeout(() => {
                                showAuthenBiometricAutoLogin()
                            }, 0)
                        }
                    })
                }, 1000)
                return
            }
        })
        // Lắng nghe common Event
        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.MESSAGE_SYSTEM) {
                const message = msg.data
                if (message.Code === 'XXXXX5' || message.Code === 'XXXX12' || message.Code === '080063') {
                    getKeychain()
                }
            } else if (msg.type === eventList.REQ_GET_MKT_INF_FIRST) {
                subcribeFunct(subExchangeTimeTimeout, 10000, 'SUB', ['EXCHANGE_TIME'], [''])
                subcribeFunct(subBITimeTimeout, 10000, 'SUB', ['MDDS|BI'], ['HSXIndex', 'LIS_BRD_01', 'UPC_BRD_01'])
            } else if (msg.type === eventList.RECONNECT_MARKET) {
                subcribeFunct(subExchangeTimeTimeout, 10000, 'SUB', ['EXCHANGE_TIME'], [''])
                subcribeFunct(subBITimeTimeout, 10000, 'SUB', ['MDDS|BI'], ['HSXIndex', 'LIS_BRD_01', 'UPC_BRD_01'])
            } else if (msg.type === eventList.RES_COMMON_MSG) {
                if (msg.Code === '080063' || msg.Code == 'XXXXX5' || msg.Code === '010012') {
                    if (glb_sv.objShareGlb.sessionInfo?.sessionId) {
                        let data
                        try {
                            data = msg.Data ? JSON.parse(msg.Data)[0] : {}
                        } catch (err) {}
                        if (data.c0 === glb_sv.objShareGlb.sessionInfo?.sessionId) return
                    }
                    if (reLoginCallTimeout.current) clearTimeout(reLoginCallTimeout.current)
                    if (socket_sv.anotherLoginFlag) return
                    reLoginCallTimeout.current = setTimeout(() => {
                        reLogin()
                    }, 800)
                }
            } else if (msg.type === eventList.CONNECT_TRADING) {
                if (!flagListIndex.current) {
                    getListIndex()
                    if (glb_sv.configInfo.application_style.default_style === '2.0') {
                        glb_sv.allListFav = glb_sv.allListFav.filter((e) => e.type !== 'fixed')
                        getListStock('HNX30')
                        setTimeout(() => {
                            getListStock('VN30')
                        }, 0)
                    }
                }
                sendPermissionPushNotify()
            } else if (msg.type === eventList.GET_FAV) {
                glb_sv.allListFav = glb_sv.allListFav.filter((e) => e.type === 'fixed')
                getStockListOwn()
                setTimeout(() => {
                    getFavInfo()
                }, 0)
            }
        })

        FingerprintScanner.isSensorAvailable()
            .then((type) => {
                isSensorAvailable.current = true
            })
            .catch((error) => null)

        return () => {
            commonEvent.unsubscribe()
            eventConnect.unsubscribe()
            FingerprintScanner.release()
        }
    }, [t])

    const subExchangeTimeTimeout = () => {
        subcribeFunct(subExchangeTimeTimeout, 10000, 'SUB', ['EXCHANGE_TIME'], [''])
    }

    const subBITimeTimeout = () => {
        subcribeFunct(subBITimeTimeout, 10000, 'SUB', ['MDDS|BI'], ['HSXIndex', 'LIS_BRD_01', 'UPC_BRD_01'])
    }

    const getKeychain = async () => {
        try {
            const credentials = await Keychain.getGenericPassword()
            console.log(TAG, 'getKeychain credentials: ', credentials)
            if (credentials) {
                Autologin(credentials.username, credentials.password)
            }
        } catch (err) {
            console.log(TAG, 'getKeychain err: ', err)
        }
    }

    const showAuthenBiometricAutoLogin = () => {
        // getKeychain();
        // return;
        if (flagAuthenBiometric.current) return
        if (isSensorAvailable.current) {
            flagAuthenBiometric.current = true
            FingerprintScanner.release()
            glb_sv.commonEvent.next({ type: eventList.AUTHEN_BIOMETRIC, isShow: true })
            FingerprintScanner.authenticate({ description: t('fingerprint_setting'), cancelButton: t('common_Cancel'), fallbackEnabled: false })
                .then((res) => {
                    /*
                      Xác thực TouchID/FaceID thành công thì gọi hàm autoLogin
                    */
                    flagAuthenBiometric.current = false
                    getKeychain()
                    glb_sv.commonEvent.next({ type: eventList.AUTHEN_BIOMETRIC, isShow: false })
                })
                .catch((err) => {
                    flagAuthenBiometric.current = false
                    console.log(TAG, 'showAuthenBiometricAutoLogin err: ', err)
                    glb_sv.commonEvent.next({ type: eventList.AUTHEN_BIOMETRIC, isShow: false })
                })
        }
    }

    const showAuthenBiometric = () => {
        if (flagAuthenBiometric.current) return
        if (isSensorAvailable.current) {
            flagAuthenBiometric.current = true
            FingerprintScanner.release()
            FingerprintScanner.authenticate({ description: t('fingerprint_setting'), cancelButton: t('common_Cancel'), fallbackEnabled: false })
                .then((res) => {
                    /*
                      Xác thực TouchID/FaceID thành công thì gọi hàm reLogin
                    */
                    flagAuthenBiometric.current = false
                    reLogin()
                })
                .catch((err) => {
                    flagAuthenBiometric.current = false
                    setAuth(false)
                    glb_sv.authFlag = false
                    glb_sv.commonEvent.next({ type: eventList.RESET_SCREENS })
                    console.log('err', err)
                })
        } else {
            flagAuthenBiometric.current = false
            setAuth(false)
            glb_sv.authFlag = false
            glb_sv.commonEvent.next({ type: eventList.RESET_SCREENS })
        }
    }

    const Autologin = (username, password) => {
        if (!username || !password) return
        const deviceInfos = glb_sv.getDeviceInfos()
        const OTP = 'NONE'
        const InputParams = ['login', username, password, glb_sv.notifyOnesignal.userId || '', getUniqueIdDevice(), 'Y', deviceInfos]
        sendRequest(ServiceInfo.LOGIN_FUNCTION, InputParams, handleAutoLogin, true, handleTimeout, OTP, 5000)
    }

    const reLogin = () => {
        if (glb_sv.isWaitSendResultLogin) return
        if (!glb_sv.isConnectApp) {
            if (reLoginCallTimeout.current) clearTimeout(reLoginCallTimeout.current)
            reLoginCallTimeout.current = setTimeout(() => {
                reLogin()
            }, 100)
            return
        }
        const username = glb_sv.credentials.username
        const password = glb_sv.credentials.password
        if (!username || !password) return
        const deviceInfos = glb_sv.getDeviceInfos()
        const InputParams = ['login', username, password, glb_sv.notifyOnesignal.userId || '', getUniqueIdDevice(), 'Y', deviceInfos]
        const OTP = glb_sv.objShareGlb.sessionInfo.Otp || 'NONE'
        sendRequest(ServiceInfo.LOGIN_FUNCTION, InputParams, handleReloginResult, true, handleTimeoutRelogin, OTP)
        glb_sv.isWaitSendResultLogin = true
    }

    const handleReloginResult = (reqInfoMap, message) => {
        numberReLogin.current = 0
        glb_sv.isWaitSendResultLogin = false
        if (Number(message.Result) === 0) {
            console.warn('Relogin lỗi  >>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<', message)
            SyncStorage.set(STORE_KEY.AutoLoginMode, false)
            if (reLoginCallTimeout.current) clearTimeout(reLoginCallTimeout.current)
            if (message.Code === '080001') {
                socket_sv.anotherLoginFlag = true
                glb_sv.commonEvent.next({ type: eventList.MESSAGE_SYSTEM, data: { Code: '080001' } })
            }
            // if (message.Code === '010012') {
            //     glb_sv.commonEvent.next({ type: eventList.MESSAGE_SYSTEM, data: { Code: '010012' } })
            // }
        } else {
            setConnected(true)
            glb_sv.isConnectApp = true

            let dataArr = {}
            try {
                const strdata = message.Data
                dataArr = JSON.parse(strdata)[0]
            } catch (error) {
                return
            }
            glb_sv.objShareGlb.userInfo = dataArr

            glb_sv.objShareGlb.otpType = Number(dataArr.c6)
            if (glb_sv.objShareGlb.sessionInfo) {
                glb_sv.objShareGlb.sessionInfo.sessionId = dataArr.c0
            }

            const data = SyncStorage.get(STORE_KEY.USER_INFO)
            if (data && data.email === reqInfoMap.inputParam[1]) {
                glb_sv.userInfo = { ...data }
            }

            setTimeout(() => {
                glb_sv.sendAuthReqSocketStream({
                    LoginID: dataArr.c1,
                    MdmTp: Platform.OS === 'android' ? '03' : '04',
                    Token: dataArr.c0,
                })
            }, 2000)

            // storeAccountInfo(dataArr);

            reLoginFlag.current = true
            getStockListOwn()

            socket_sv.establishSocketConnect('authen_success', {})
            glb_sv.commonEvent.next({ type: eventList.LOGIN_SUCCESS })
        }
    }

    const handleTimeoutRelogin = () => {
        glb_sv.isWaitSendResultLogin = false
        if (reLoginCallTimeout.current) clearTimeout(reLoginCallTimeout.current)
        reLoginCallTimeout.current = setTimeout(() => {
            numberReLogin.current += 1
            if (numberReLogin.current > 2) return
            else reLogin()
        }, 100)
    }

    const handleAutoLogin = (reqInfoMap, message) => {
        // console.log("handleAutoLogin -> message", message)
        numberReLogin.current = 0
        if (Number(message.Result) === 0) {
            // Nếu AutoLogin lỗi thì không để cờ pre_auto_authen nữa
            if (glb_sv.LastConnectStatus === 'pre_auto_authen') glb_sv.LastConnectStatus = 'non_authen'
            SyncStorage.set(STORE_KEY.AutoLoginMode, false)
            return
        } else {
            let dataArr = {}
            try {
                const strdata = message.Data
                dataArr = JSON.parse(strdata)[0]
            } catch (error) {
                return
            }
            glb_sv.isAutoLogin = true
            if (glb_sv.configInfo.application_style.show_get_iotp && dataArr.c20 === 'Y') {
                dataArr.c13 = 'Y'
            }
            glb_sv.objShareGlb.userInfo = dataArr

            glb_sv.objShareGlb.otpType = Number(dataArr.c6)

            glb_sv.objShareGlb.sessionInfo = {
                sessionId: dataArr.c0,
                userID: dataArr.c1,
                passID: reqInfoMap.inputParam[2],
                remOrdPass: false,
                orderPass: null,
                Otp: '',
            }

            const data = SyncStorage.get(STORE_KEY.USER_INFO)
            if (data && data.email === reqInfoMap.inputParam[1]) {
                glb_sv.userInfo = { ...data }
            }

            setTimeout(() => {
                glb_sv.sendAuthReqSocketStream({
                    LoginID: dataArr.c1,
                    MdmTp: Platform.OS === 'android' ? '03' : '04',
                    Token: dataArr.c0,
                })
            }, 2000)

            glb_sv.credentials.username = reqInfoMap.inputParam[1]
            glb_sv.credentials.password = reqInfoMap.inputParam[2]
            storeAccountInfo(dataArr)
            getUserInfo()

            glb_sv.allListFav = glb_sv.allListFav.filter((e) => e.type === 'fixed')
            getStockListOwn()
            setTimeout(() => {
                getFavInfo()
            }, 0)

            checkEkyc()

            socket_sv.establishSocketConnect('authen_success', {})
            glb_sv.commonEvent.next({ type: eventList.LOGIN_SUCCESS })

            if (allowCompanyRender(['888', '081'])) {
                setTimeout(() => {
                    glb_sv.commonEvent.next({ type: eventList.SHOW_MODAL_CONFIRM_ORDER })
                }, 500)
            }
        }
    }

    const handleTimeout = (reqInfoMap) => {
        if (autoLoginCallTimeout.current) clearTimeout(autoLoginCallTimeout.current)
        autoLoginCallTimeout.current = setTimeout(() => {
            numberReLogin.current += 1
            if (numberReLogin.current > 2) return
            else getKeychain()
        }, 100)
    }

    const storeAccountInfo = (userInfo) => {
        const accountInfo = userInfo.c12
        if (!accountInfo) {
            setAuth(true)
            glb_sv.authFlag = true
            glb_sv.objShareGlb.workDate = userInfo.c16 || moment().format('YYYYMMDD') // -- Ngày làm việc
            return
        }
        const array_acnt = accountInfo.split('|').filter((e) => e !== '')
        const js_acntInfo = []
        const js_acntList = []
        // const js_acntListAll = []
        let acntMain = '',
            acntMainName = ''
        for (let i = 0; i < array_acnt.length; i++) {
            const acntInfo = array_acnt[i]
            const arr_info = acntInfo.split(',')
            // if (i === 0) {
            //     const ls_acntObjsAll = {
            //         id: arr_info[0] + '.%',
            //         name: arr_info[0] + '.% - ' + arr_info[2],
            //     }
            //     js_acntListAll.push(ls_acntObjsAll)
            // }
            if (arr_info[4] === 'Y') {
                acntMain = arr_info[0]
                acntMainName = arr_info[2]
            }
            const js_acnt = {
                AcntNo: arr_info[0],
                SubNo: arr_info[1],
                AcntNm: arr_info[2],
                IsOwnAcnt: arr_info[4],
                MarginYN: arr_info[3] === '2',
                ActType: arr_info[3],
                // Broker: arr_info[20],
                // BrokerBranch: arr_info[21],
                // BrokerAgent: arr_info[22],
                // TradingFee: arr_info[23],
            }
            const js_acntObj = {
                id: arr_info[0] + '.' + arr_info[1],
                name: arr_info[0] + '.' + arr_info[1] + ' - ' + arr_info[2],
            }
            js_acntInfo.push(js_acnt)
            js_acntList.push(js_acntObj)
            // js_acntListAll.push(js_acntObj)
        }

        glb_sv.objShareGlb.acntNoInfo = js_acntInfo
        glb_sv.objShareGlb.acntNoList = js_acntList
        // glb_sv.objShareGlb['acntNoListAll'] = js_acntListAll
        // --------------------
        glb_sv.objShareGlb.AcntMain = acntMain // -- chủ tài khoản lưu ký
        glb_sv.objShareGlb.AcntMainNm = acntMainName // -- Tên chủ tài khoản
        glb_sv.objShareGlb.workDate = userInfo.c16 || moment().format('YYYYMMDD') // -- Ngày làm việc
        // glb_sv.objShareGlb['brokerId'] = userInfo['c24'] // -- ID nhân viên môi giới
        // glb_sv.objShareGlb['brokerNm'] = userInfo['c25'] // -- Tên nhân viên môi giới
        // glb_sv.objShareGlb['brokerEmail'] = userInfo['c26'] // -- Email nhân viên môi giới
        // glb_sv.objShareGlb['brokerMobile'] = userInfo['c27'] // -- Mobile nhân viên môi giới
        // glb_sv.objShareGlb['secCode'] = userInfo['c9'] // -- Tên nhân viên môi giới
        // glb_sv.objShareGlb['prdYN'] = userInfo['c31'] // -- User trình chiếu bảng điện hay không
        // glb_sv.objShareGlb['verify'] = Number(userInfo['c37']) || 0 // -- verify > 0 => Phải xác thực chứng chỉ số
        // glb_sv.objShareGlb['serialnum'] = userInfo['c38'] // -- serialNumber

        const sub_list = []
        const actn_list = []
        js_acntInfo.forEach((e) => {
            if (e.AcntNo === acntMain) sub_list.push(e.SubNo)
            if (!actn_list.find((temp) => temp.AcntNo === e.AcntNo))
                actn_list.push({
                    AcntNo: e.AcntNo,
                    actn_name: e.AcntNm,
                    key: e.AcntNo,
                    label: e.AcntNo + ' (' + e.AcntNm + ')',
                })
        })
        const userInfoLocal = SyncStorage.get(STORE_KEY.USER_INFO_TRADING)
        let sub_curr = sub_list[0]
        if (userInfoLocal && userInfoLocal.actn_curr === acntMain && sub_list.includes(userInfoLocal.sub_curr)) {
            sub_curr = userInfoLocal.sub_curr
        }
        setUserInfo({
            actn_curr: acntMain,
            sub_curr,
            actn_name: acntMainName,
            sub_list,
            actn_list,
        })
        glb_sv.userInfoAccount = {
            actn_curr: acntMain,
            sub_curr,
            actn_name: acntMainName,
            sub_list,
            actn_list,
        }
        glb_sv.userInfo.actn_curr = acntMain
        glb_sv.userInfo.sub_curr = sub_curr
        setAuth(true)
        glb_sv.authFlag = true
    }

    const getFavInfo = () => {
        const InputParams = ['3', '', '0']
        sendRequest(ServiceInfo.getFav, InputParams, getFavInfoProc)
        tempFav.current = []
    }

    const getFavInfoProc = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsonArr = []
            const strdata = message.Data
            try {
                jsonArr = strdata ? JSON.parse(strdata) : []
                tempFav.current = tempFav.current.concat(jsonArr)
            } catch (error) {
                console.log(error)
                return
            }
            if (Number(message.Packet) <= 0) {
                const newallListFav = []
                for (let i = 0; i < tempFav.current.length; i++) {
                    const element = tempFav.current[i]
                    newallListFav.push({
                        ...element,
                        type: 'watchlist',
                        ListStock: [],
                        isOddlot: element.c6 === '1',
                    })
                    glb_sv.allListFav = glb_sv.allListFav.filter((e) => e.c2 !== element.c2)
                }
                if (glb_sv.allListFav.length) {
                    const listOwn = glb_sv.allListFav.filter((item) => item.type === 'own')
                    const listFixed = glb_sv.allListFav.filter((item) => item.type === 'fixed')
                    glb_sv.allListFav = listOwn.concat(newallListFav).concat(listFixed)
                } else {
                    glb_sv.allListFav = newallListFav
                }

                if ((!glb_sv.activeList.c1 || glb_sv.activeList.type === 'fixed') && newallListFav.length) {
                    glb_sv.activeList = newallListFav[0]
                    if (glb_sv.configInfo.application_style.default_style !== '2.0') {
                        glb_sv.commonEvent.next({ type: eventList.CHANGE_LIST_ACTIVE })
                    }
                }

                tempFav.current.forEach((e) => getDetailFavList(e))
                glb_sv.commonEvent.next({ type: eventList.CHANGE_LIST_FAV })
            }
        }
    }

    const getDetailFavList = (element) => {
        const groupId = element.c1
        const InputParams = ['4', String(groupId)]
        sendRequest(ServiceInfo.getDetailList, InputParams, handleGetDetailFavList)
    }

    const handleGetDetailFavList = (reqInfoMap, message) => {
        const idFav = reqInfoMap.inputParam[1]
        if (Number(message.Result) === 0) {
            return
        } else {
            reqInfoMap.procStat = 1
            let dataArr = []
            try {
                dataArr = message.Data ? JSON.parse(message.Data) : []
                if (!tempFavList.current[idFav]) {
                    tempFavList.current[idFav] = []
                }
                tempFavList.current[idFav] = tempFavList.current[idFav].concat(dataArr.map((e) => e.c3))
            } catch (error) {
                return
            }
            const obj = glb_sv.allListFav.find((x) => x.c1 === reqInfoMap.inputParam[1])
            if (obj) {
                obj.ListStock = tempFavList.current[idFav]

                const dataSort = SyncStorage.get(STORE_KEY.SORT_FAV) || {}
                const sortList = dataSort[reqInfoMap.inputParam[1]] || []
                const newSortListFilterStockRemove = filterArray(sortList, obj.ListStock)
                obj.ListStock = uniq(newSortListFilterStockRemove.concat(obj.ListStock))
            }
            if (glb_sv.allListFav.length) {
                const obj = glb_sv.activeList
                if (obj.c1 === reqInfoMap.inputParam[1]) {
                    obj.ListStock = tempFavList.current[idFav]
                    const dataSort = SyncStorage.get(STORE_KEY.SORT_FAV) || {}
                    const sortList = dataSort[reqInfoMap.inputParam[1]] || []
                    const newSortListFilterStockRemove = filterArray(sortList, obj.ListStock)
                    obj.ListStock = uniq(newSortListFilterStockRemove.concat(obj.ListStock))

                    glb_sv.activeList = { ...obj }
                    if (glb_sv.configInfo.application_style.default_style === '2.0') {
                        glb_sv.commonEvent.next({ type: eventList.SUB_LIST_ACTIVE_FAV })
                    } else glb_sv.commonEvent.next({ type: eventList.CHANGE_LIST_ACTIVE })
                }
            }
        }
    }

    const getListIndex = () => {
        const InputParams = ['idx_list', '%']
        sendRequest(ServiceInfo.GET_INDEX_LIST, InputParams, hanldeGetListIndex, false)
    }

    const hanldeGetListIndex = (reqInfoMap, message) => {
        // -- process after get result --
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {
                console.log('hanldeGetListIndex -> err', err)
                jsondata = []
            }
            flagListIndex.current = true
            jsondata.forEach((item) => {
                if (glb_sv.IndexMarket[item.c1]) {
                    glb_sv.IndexMarket[item.c1].indexName = item.c3
                } else {
                    glb_sv.IndexMarket[item.c1] = new InfoIndex()
                    glb_sv.IndexMarket[item.c1].indexName = item.c3
                }
            })

            glb_sv.jsonIndexInfo = jsondata
            glb_sv.listIndex = []
            const listIndex = jsondata.map((e) => e.c1)

            if (listIndex.includes('HNXUpcomIndex')) glb_sv.listIndex.unshift('HNXUpcomIndex')
            if (listIndex.includes('HNX30')) glb_sv.listIndex.unshift('HNX30')
            if (listIndex.includes('HNXIndex')) glb_sv.listIndex.unshift('HNXIndex')
            if (listIndex.includes('VN30')) glb_sv.listIndex.unshift('VN30')
            if (listIndex.includes('HSXIndex')) glb_sv.listIndex.unshift('HSXIndex')
            glb_sv.listIndex = glb_sv.listIndex.concat(
                listIndex.filter((e) => e !== 'HSXIndex' && e !== 'VN30' && e !== 'HNXIndex' && e !== 'HNX30' && e !== 'HNXUpcomIndex'),
            )

            glb_sv.eventMarket.next({ type: eventList.GET_LIST_INDEX })
            glb_sv.eventMarket.next({ type: eventList.SUB_INDEX })
        }
    }

    const checkEkyc = () => {
        const inval = ['info']
        sendRequest(ServiceInfo.EKYC_INFO, inval, checkEkycResult, true, checkEkycTimeout, '', 5000)
    }

    const checkEkycTimeout = ({ type }) => {}

    const checkEkycResult = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
        } else {
            let datajson
            try {
                datajson = message.Data ? JSON.parse(message.Data.replace(/\\n/g, '').replace(/\n/g, ''))[0] : {}
                console.log('FOSqID01_EKYCInfo Result: ', datajson)
            } catch (err) {
                console.log('checkEkycResult', err)
                return
            }
            glb_sv.dataEkycInfo = datajson
        }
    }

    const getStockListOwn = () => {
        if (!glb_sv.objShareGlb.AcntMain) return
        const InputParams = [glb_sv.objShareGlb.AcntMain]
        sendRequest(ServiceInfo.GET_LIST_OWN, InputParams, getStockListOwnResult, true, getStockListOwnTimeout, '', 0, 'equal_input')
    }

    const getStockListOwnTimeout = () => null

    const getStockListOwnResult = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {
                return
            }
            const newWatchlist = {
                c1: 'watchlist_owner',
                c2: 'own_stock_list',
                type: 'own',
                ListStock: jsondata.map((e) => e.c0),
                // StockSymbolList: jsondata.map(e => glb_sv.StockMarket[e.c0] || { t55: e.c0 })
            }
            const dataSort = SyncStorage.get(STORE_KEY.SORT_FAV) || {}
            const sortList = dataSort[reqInfoMap.inputParam[1]] || []
            const newSortListFilterStockRemove = filterArray(sortList, newWatchlist.ListStock)
            newWatchlist.ListStock = uniq(newSortListFilterStockRemove.concat(newWatchlist.ListStock))

            if (jsondata.length) {
                glb_sv.listStockOwn = newWatchlist
                const listOwn = [newWatchlist]
                const watchList = glb_sv.allListFav.filter((item) => item.type === 'watchlist')
                const listFixed = glb_sv.allListFav.filter((item) => item.type === 'fixed')
                glb_sv.allListFav = listOwn.concat(watchList).concat(listFixed)
            }
            if (reLoginFlag.current) {
            } else {
                if (jsondata.length) {
                    glb_sv.activeList = newWatchlist
                    if (glb_sv.configInfo.application_style.default_style === '2.0') {
                        glb_sv.commonEvent.next({ type: eventList.CHANGE_LIST_FAV })
                    } else glb_sv.commonEvent.next({ type: eventList.CHANGE_LIST_ACTIVE })
                }
            }
        }
    }

    const sendPermissionPushNotify = () => {
        if (glb_sv.notifyOnesignal.userId) {
            OneSignal.getDeviceState()
                .then((res) => {
                    if (!SyncStorage.get(STORE_KEY.APP_LOGIN_ID)) sendRegisterNotify(res.hasNotificationPermission)
                })
                .catch((err) => null)
        } else {
            setTimeout(() => {
                OneSignal.getDeviceState()
                    .then((res) => {
                        if (!SyncStorage.get(STORE_KEY.APP_LOGIN_ID)) sendRegisterNotify(res.hasNotificationPermission)
                    })
                    .catch((err) => null)
            }, 2000)
        }
    }

    const sendRegisterNotify = (type) => {
        const InputParams = [type ? 'noti_on' : 'noti_off', getUniqueIdDevice(), glb_sv.notifyOnesignal.userId || '']
        sendRequest(ServiceInfo.CONFIG_NOTIFY, InputParams, sendRegisterNotifyResult, false)
    }

    const sendRegisterNotifyResult = (reqInfoMap, message) => {}

    const getUserInfo = () => {
        const InputParams = ['info']
        sendRequest(ServiceInfo.QUERY_USER_INFORMATION, InputParams, handleGetUserInfo)
    }

    const handleGetUserInfo = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata
            if (!message.Data) return
            try {
                jsondata = JSON.parse(message.Data)
                glb_sv.objUserInfo = jsondata[0]
            } catch (err) {
                return
            }
        }
    }

    const getListStock = (indexCode) => {
        const InputParams = ['stk_list', indexCode]
        sendRequest(ServiceInfo.GET_LIST_STOCK_INTO_INDEX, InputParams, handleGetListStock)
    }

    const handleGetListStock = (reqInfoMap, message) => {
        // console.log("handleGetListStock -> message", message)
        const indexCode = reqInfoMap.inputParam[1]
        // -- process after get result --
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {
                jsondata = []
            }

            if (Number(message.Packet) <= 0) {
                const newList = jsondata.map((temp) => temp.c0)
                newList.sort(function sortAsc(a, b) {
                    if (a > b) return 1
                    if (a < b) return -1
                    return 0
                })
                // glb_sv.IndexMarket[indexCode].STOCK_INFO = newList;

                // glb_sv.allListFav.unshift({
                //     c1: indexCode + '_FIXED1',
                //     c2: indexCode,
                //     type: 'fixed',
                //     ListStock: newList
                // })
                // glb_sv.allListFav.unshift({
                //     c1: indexCode + '_FIXED2',
                //     c2: indexCode,
                //     type: 'fixed',
                //     ListStock: newList
                // })
                if (indexCode === 'VN30') {
                    glb_sv.allListFav.unshift({
                        c1: indexCode + '_FIXED',
                        c2: indexCode,
                        type: 'fixed',
                        ListStock: newList,
                    })
                    const listFixed = glb_sv.allListFav.filter((e) => e.type === 'fixed')
                    const listOther = glb_sv.allListFav.filter((e) => e.type !== 'fixed')
                    if (listOther.length) {
                        glb_sv.allListFav = listFixed.concat(listOther)
                        glb_sv.activeList = glb_sv.allListFav[0]
                    } else {
                        glb_sv.activeList = {
                            c1: indexCode + '_FIXED',
                            c2: indexCode,
                            type: 'fixed',
                            ListStock: newList,
                        }
                    }
                    glb_sv.commonEvent.next({ type: eventList.CHANGE_LIST_FAV })
                } else {
                    glb_sv.allListFav.push({
                        c1: indexCode + '_FIXED',
                        c2: indexCode,
                        type: 'fixed',
                        ListStock: newList,
                    })
                    if (glb_sv.allListFav.length > 2) {
                        glb_sv.commonEvent.next({ type: eventList.CHANGE_LIST_FAV })
                    }
                }
            }
        }
    }

    return (
        <>
            <ModalNewReleaseNotes />
            <ModalAlertProvider />
            <ModalAuthenOtpPhone />
            {allowCompanyRender(['888', '081']) ? <ModalVerifyOrderAfterLogin /> : null}
            {/* <FullImageAdvertisingModal /> */}
            {application_config.is_show_promotion_popup ? <ImageAndContentAdvertisingModal /> : null}
            {allowCompanyRender(['888', '081', '102']) ? <ModalNotifyNewVersion /> : null}
        </>
    )
}

// hàm dùng để lọc những ở mảng arr1 không có ở mảng arr2
const filterArray = (arr1, arr2) => {
    const filtered = arr1.filter((el) => {
        return arr2.indexOf(el) >= 0
    })
    return filtered
}

const BackgroundService = memo(BackgroundServiceMemo)
export default BackgroundService
