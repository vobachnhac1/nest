import React, { memo, useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { InteractionManager, RefreshControl, ScrollView, TouchableOpacity, View } from 'react-native'
import Modal from 'react-native-modal'
import Svg, { Path, Rect } from 'react-native-svg'
import { Button } from 'native-base'

import { Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { dimensions, fontSizes, fontWeights } from '../../styles'
import { eventList, glb_sv, reqFunct, sendRequest } from '../../utils'

const ServiceInfo = {
    GET_FAV_INFO: {
        reqFunct: reqFunct.GET_FAV_INFO,
        WorkerName: 'FOSqID01',
        ServiceName: 'FOSqID01_FavoritesMgt',
        Operation: 'Q',
        ClientSentTime: '0',
    },
}

export default ({ isModalVisible, setModal, setVisibleAddModal }) => {
    const { t } = useTranslation()
    const { styles } = useContext(StoreContext)

    const [activeList, setActiveList] = useState(glb_sv.activeList)
    const [allListFav, setAllListFav] = useState(glb_sv.allListFav)

    const [loading, setLoading] = useState(false)
    const tempFav = useRef([])

    useEffect(() => {
        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.CHANGE_LIST_FAV) {
                setAllListFav([...glb_sv.allListFav])
            } else if (msg.type === eventList.CHANGE_LIST_ACTIVE) {
                setActiveList({ ...glb_sv.activeList })
                setAllListFav([...glb_sv.allListFav])
            }
        })
        return () => {
            commonEvent.unsubscribe()
        }
    }, [])

    const hideModal = () => {
        setModal(false)
    }

    const addNewFav = () => {
        setModal(false)
        InteractionManager.runAfterInteractions(() => {
            setTimeout(() => {
                setVisibleAddModal(true)
            }, 0)
        })
    }

    const changeActiveList = (item) => {
        if (activeList.c1 === item.c1) {
            setModal(false)
            return
        }
        glb_sv.eventMarket.next({ type: eventList.LOADING_FAV })
        setModal(false)
        InteractionManager.runAfterInteractions(() => {
            setActiveList(item)
            glb_sv.activeList = item
            glb_sv.commonEvent.next({ type: eventList.CHANGE_LIST_ACTIVE })
        })
    }

    const getFavInfo = () => {
        const InputParams = ['3', '', '0']
        sendRequest(ServiceInfo.GET_FAV_INFO, InputParams, getFavInfoProc, true, getFavInfoTimeout)
        tempFav.current = []
        setLoading(true)
    }

    const getFavInfoTimeout = () => {
        setLoading(false)
    }

    const getFavInfoProc = (reqInfoMap, message) => {
        setLoading(false)
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsonArr = []
            const strdata = message.Data
            try {
                jsonArr = strdata ? JSON.parse(strdata) : []
                tempFav.current = tempFav.current.concat(jsonArr)
            } catch (error) {
                console.log(error)
                return
            }

            if (Number(message.Packet) <= 0) {
                for (let i = 0; i < tempFav.current.length; i++) {
                    const element = tempFav.current[i]
                    const isFav = glb_sv.allListFav.find((e) => e.c1 === element.c1)
                    if (isFav) {
                        isFav.c2 = element.c2
                    } else {
                        glb_sv.allListFav.push({
                            ...element,
                            type: 'watchlist',
                            ListStock: [],
                        })
                    }
                }
                setAllListFav([...glb_sv.allListFav])
            }
        }
    }

    return (
        <Modal
            hideModalContentWhileAnimating={true}
            isVisible={isModalVisible}
            useNativeDriver={true}
            onBackButtonPress={hideModal}
            onBackdropPress={hideModal}
            onModalHide={hideModal}
        >
            <View
                style={{
                    backgroundColor: styles.PRIMARY__BG__COLOR,
                    padding: 24,
                    justifyContent: 'flex-start',
                    borderRadius: 12,
                }}
            >
                {allListFav.filter((e) => e.type === 'suggest').length ? (
                    <>
                        <Text
                            style={{
                                marginBottom: dimensions.vertical(17),
                                fontSize: fontSizes.xmedium,
                                color: styles.PRIMARY__CONTENT__COLOR,
                                fontWeight: fontWeights.semiBold,
                            }}
                        >
                            {t('stock_recommandation')}
                        </Text>
                        <ScrollView style={{ maxHeight: dimensions.HIEGHT * 0.2 }}>
                            {allListFav
                                .filter((e) => e.type === 'suggest')
                                .map((item, index) => (
                                    <TouchableOpacity
                                        key={item.c1}
                                        style={{ flexDirection: 'row', paddingVertical: 12.5 }}
                                        onPress={() => changeActiveList(item)}
                                    >
                                        <CheckboxIcon
                                            active={item.c1 === activeList.c1}
                                            colorActive={styles.GREEN__COLOR}
                                            colorunActive={styles.ICON__PRIMARY}
                                        />
                                        <Text
                                            style={{
                                                color: styles.PRIMARY__CONTENT__COLOR,
                                                opacity: item.c1 === activeList.c1 ? 1 : 0.64,
                                                marginLeft: dimensions.vertical(8),
                                                fontSize: fontSizes.medium,
                                            }}
                                        >
                                            {item.c2}
                                        </Text>
                                    </TouchableOpacity>
                                ))}
                        </ScrollView>
                    </>
                ) : null}
                <Text
                    style={{
                        marginVertical: dimensions.vertical(17),
                        fontSize: fontSizes.xmedium,
                        color: styles.PRIMARY__CONTENT__COLOR,
                        fontWeight: fontWeights.semiBold,
                    }}
                >
                    {t('investment_portfolio')}
                </Text>
                <ScrollView
                    refreshControl={<RefreshControl refreshing={loading} tintColor={styles.PRIMARY__CONTENT__COLOR} onRefresh={getFavInfo} />}
                    style={{ minHeight: dimensions.HIEGHT * 0.25, maxHeight: dimensions.HIEGHT * 0.35 }}
                >
                    {allListFav
                        .filter((e) => e.type !== 'suggest')
                        .map((item, index) => (
                            <TouchableOpacity key={item.c1} style={{ flexDirection: 'row', paddingVertical: 12.5 }} onPress={() => changeActiveList(item)}>
                                <CheckboxIcon active={item.c1 === activeList.c1} colorActive={styles.GREEN__COLOR} colorunActive={styles.ICON__PRIMARY} />
                                <Text
                                    style={{
                                        color: styles.PRIMARY__CONTENT__COLOR,
                                        opacity: item.c1 === activeList.c1 ? 1 : 0.64,
                                        marginLeft: dimensions.vertical(8),
                                        fontSize: fontSizes.medium,
                                    }}
                                >
                                    {item.c2 === 'own_stock_list' ? t('own_stock_list') : item.isOddlot ? `(${t('odd_lot')}) ${item.c2}` : item.c2}
                                </Text>
                            </TouchableOpacity>
                        ))}
                </ScrollView>

                <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                    <Button noBorder transparent onPress={addNewFav}>
                        <PlusIcon color={styles.PRIMARY} />
                        <Text style={{ color: styles.GREEN__COLOR, fontSize: fontSizes.medium }}> {t('add_new_favorites')}</Text>
                    </Button>
                </View>
            </View>
        </Modal>
    )
}

const PlusIcon = memo(PlusIconMemo)
function PlusIconMemo({ color }) {
    return (
        <Svg height={20} viewBox="0 0 20 20" width={20} xmlns="http://www.w3.org/2000/svg">
            <Rect fill={color} height={20} rx={2} width={20} />
            <Path d="M10 5.816v7.812M13.906 9.722H6.094" stroke="#fff" strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.563} />
        </Svg>
    )
}

const CheckboxIcon = memo(CheckboxIconMemo)
function CheckboxIconMemo({ colorActive, colorunActive, active }) {
    if (active)
        return (
            <Svg fill="none" height={24} viewBox="0 0 24 24" width={24} xmlns="http://www.w3.org/2000/svg">
                <Path d="M0 12C0 5.383 5.383 0 12 0s12 5.383 12 12-5.383 12-12 12S0 18.617 0 12z" fill={colorActive} opacity={0.2} />
                <Path
                    d="M12.125 4C7.645 4 4 7.645 4 12.125s3.645 8.125 8.125 8.125 8.125-3.645 8.125-8.125S16.605 4 12.125 4zm4.229 5.402l-5.25 6.25a.625.625 0 01-.47.223h-.01a.625.625 0 01-.464-.207l-2.25-2.5a.625.625 0 11.929-.836l1.769 1.966 4.788-5.7a.625.625 0 01.957.804z"
                    fill={colorActive}
                />
            </Svg>
        )
    else
        return (
            <Svg height={20} style={{ marginHorizontal: 2 }} viewBox="0 0 20 20" width={20} xmlns="http://www.w3.org/2000/svg">
                <Path d="M1 10c0-4.962 4.038-9 9-9s9 4.038 9 9-4.038 9-9 9-9-4.038-9-9z" opacity={0.64} stroke={colorunActive} strokeWidth={2} />
            </Svg>
        )
}
