import React from 'react'
import { Container } from 'native-base'

export const ContainerCustom = (props) => <Container style={{ backgroundColor: props.backgroundColor }} {...props} />
