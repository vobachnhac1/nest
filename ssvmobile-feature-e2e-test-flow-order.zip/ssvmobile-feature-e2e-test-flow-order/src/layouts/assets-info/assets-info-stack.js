import React, { memo, useCallback, useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { View } from 'react-native'

import HeaderComponent from '../../components/header'
import NotAuthView from '../../components/notAuth-view'
import { StoreContext } from '../../store'
import { eventList, glb_sv } from '../../utils'
import AssetsInfo from './index'

function AssetsInfoStack({ navigation }) {
    const { styles, authFlag } = useContext(StoreContext)
    const { t } = useTranslation()

    const [, updateState] = useState()
    const forceUpdate = useCallback(() => updateState({}), [])

    useEffect(() => {
        glb_sv.focusAssetInfo = true
        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.EKYC_SUCCESS) {
                forceUpdate()
            }
        })

        return () => {
            glb_sv.focusAssetInfo = false
            commonEvent.unsubscribe()
        }
    }, [])

    if (!authFlag || glb_sv.objShareGlb.userInfo.c9 === 'N') {
        return <NotAuthView isBottom={false} navigation={navigation} />
    }

    return (
        <View style={{ flex: 1, backgroundColor: styles.PRIMARY__BG__COLOR }}>
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft={true}
                navigation={navigation}
                title={t('sb_assetsMng')}
                titleAlgin="flex-start"
            />
            <View style={{ flex: 1, paddingBottom: 8 }}>
                <AssetsInfo navigation={navigation} />
            </View>
        </View>
    )
}

export default memo(AssetsInfoStack)
