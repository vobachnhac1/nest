import React, { useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { GestureResponderEvent, StyleSheet, TouchableOpacity, View } from 'react-native'
import Svg, { Circle, G, Path } from 'react-native-svg'
import { Button } from 'native-base'

import { Text } from '../../../basic-components'
import { StoreContext } from '../../../store'
import { dimensions as dm, fontSizes, fontSizes as fs, fontWeights as fw } from '../../../styles'

interface IEmptyView {
    isRender?: boolean
    isShowReload?: boolean
    refreshFunction?: (event: GestureResponderEvent) => void
    [key: string]: any
}

function EmptyView({ isRender = true, isShowReload = false, refreshFunction, ...props }: IEmptyView) {
    const { t } = useTranslation()
    const { styles } = useContext(StoreContext)

    if (isRender) {
        return (
            <View style={UI.View} {...props}>
                <TouchableOpacity style={UI.Image} onPress={refreshFunction}>
                    <Svg
                        height={121}
                        viewBox="0 0 164 121"
                        width={164}
                        fill="none"
                        // xmlns="http://www.w3.org/2000/svg"
                    >
                        <Path
                            d="M128.337 70.322h0l-11.9 43.333s0 0 0 0c-.923 3.354-3.437 5.518-6.167 5.542h-.002l-66.433.3 1.174-5.4v-.001l10.054-45.907s0 0 0 0c.363-1.634 1.513-2.633 2.741-2.613h.01l67.853-.076s0 0 0 0c.915 0 1.742.558 2.272 1.474.53.915.732 2.14.398 3.348z"
                            fill="#FFC107"
                            fillOpacity={0.05}
                            stroke="#FAD416"
                        />
                        <Path
                            d="M100.047 54.981v.002l5.963 54.941v.001l.002.024a9.348 9.348 0 00.047.411c.037.275.099.662.199 1.12.199.911.554 2.119 1.179 3.271.625 1.152 1.535 2.274 2.853 2.97.973.514 2.14.78 3.528.68-.955.509-2.787 1.042-6.225.963v0h-.013l-63.36.136s0 0 0 0c-1.505-.001-2.932-1.415-3.152-3.482v-.001l-5.535-50.802v-.003c-.141-1.232.182-2.39.776-3.232.595-.84 1.439-1.34 2.353-1.34h.003l36.357-.218.234-.002.149-.181 6.203-7.558h0c.61-.747 1.382-1.126 2.19-1.126h.001L96.87 51.5h.001c1.533 0 2.956 1.393 3.176 3.481z"
                            stroke="#FAD416"
                        />
                        <Circle cx={71} cy={93} fill="#FAD416" r={3} />
                        <Circle cx={82} cy={93} fill="#FAD416" r={3} />
                        <Circle cx={93} cy={93} fill="#FAD416" r={3} />
                    </Svg>
                </TouchableOpacity>
                <View style={UI.Text_Empty}>
                    <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fs.small }}>{t<string>('empty_list')}</Text>
                </View>

                {isShowReload ? (
                    <View>
                        <Button
                            style={{ backgroundColor: styles.PRIMARY, justifyContent: 'center', alignSelf: 'center', width: 200 }}
                            onPress={refreshFunction}
                        >
                            <Text style={{ color: '#FFF', fontSize: fontSizes.small }}>{t<string>('refresh')}</Text>
                        </Button>
                    </View>
                ) : null}
            </View>
        )
    }
    return <View />
}

export default EmptyView

const UI = StyleSheet.create({
    Image: {
        alignItems: 'center',
        justifyContent: 'center',
        width: '100%',
    },
    Text_Empty: {
        alignItems: 'center',
        justifyContent: 'center',
        paddingVertical: dm.vertical(32),
        width: '100%',
    },
    View: {
        alignItems: 'center',
        justifyContent: 'center',
        // height: dm.vertical(80),
    },
})
