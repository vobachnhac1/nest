import React, { useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { StyleSheet, TouchableOpacity, View } from 'react-native'

import { Text } from '../../../../basic-components'
import { StoreContext } from '../../../../store'
import { dimensions as dm, fontSizes as fs, fontWeights, IconSvg } from '../../../../styles'

export const OtherUtilsEmailReport = ({ setIsMonthlyReport = () => null, isMonthlyReport }) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()

    const [isCheckContent, setIsCheckContent] = useState(isMonthlyReport || false)
    useEffect(() => {
        setIsCheckContent(isMonthlyReport)
    }, [isMonthlyReport])

    useEffect(() => {
        setIsMonthlyReport(isCheckContent)
    }, [isCheckContent])

    return (
        <>
            <View style={[UI.RowAction]}>
                <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fs.normal, fontWeight: fontWeights.bold }}>{t('recivce_report_via_email')}</Text>
            </View>
            <View style={UI.row}>
                <TouchableOpacity
                    activeOpacity={0.9}
                    style={{ flexDirection: 'row', alignItems: 'center', marginTop: dm.vertical(16) }}
                    onPress={() => setIsCheckContent((value) => !value)}
                >
                    <View style={{ paddingTop: 2 }}>
                        <IconSvg.CheckboxIcon active={isCheckContent} colorActive={styles.PRIMARY} colorunActive={styles.PRIMARY__CONTENT__COLOR} />
                    </View>
                    <Text
                        style={{
                            fontSize: fs.normal,
                            color: styles.PRIMARY__CONTENT__COLOR,
                            marginLeft: dm.moderate(8),
                            marginRight: 16,
                        }}
                    >
                        {t('monthly_report')}
                    </Text>
                </TouchableOpacity>
            </View>
        </>
    )
}

const UI = StyleSheet.create({
    RowAction: { alignItems: 'center', flexDirection: 'row', paddingHorizontal: dm.moderate(16), paddingTop: dm.vertical(16) },
    row: {
        alignItems: 'center',
        borderRadius: 12,
        flexDirection: 'row',
        marginHorizontal: dm.moderate(16),
    },
})
