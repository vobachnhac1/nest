import React, { Component, createRef } from 'react'
import { ActivityIndicator, Platform, StyleSheet, View } from 'react-native'
import WebView from 'react-native-webview'
import moment from 'moment'

import { glb_sv, reqFunct, sendRequest } from '../../../../../utils'

const source = Platform.select({
    ios: require('../../../../../basic-components/custom-chart/index.html'),
    android: { uri: 'file:///android_asset/index.html' },
})

const ServiceInfo = {
    GET_HISTORY_ASSETS: {
        reqFunct: reqFunct.GET_HISTORY_ASSETS,
        WorkerName: 'FOSqAsset',
        ServiceName: 'FOSqAsset_Online_1',
        Operation: 'Q',
    },
}

export default class ChartForeignerTrade extends Component {
    constructor(props) {
        super(props)
        this.chart = createRef()

        this.state = {
            webviewKey: new Date().getTime(),
            loading: true,
        }
    }
    lastMessageDayAssetsWeightByMonth = null
    // ---------------------------
    componentDidMount() {
        setTimeout(() => {
            this.setState({ loading: false })
            this.getHistoryProfitLossIndex()
            this.getHistoryAssetsIndex()
        }, 2000)
    }

    getHistoryProfitLossIndex = () => {
        const inputParams = [
            '02',
            moment(glb_sv.objShareGlb.workDate, 'YYYYMMDD').subtract(12, 'months').format('YYYYMMDD'),
            glb_sv.objShareGlb.workDate,
            glb_sv.objShareGlb.AcntMain,
        ]
        sendRequest(ServiceInfo.GET_HISTORY_ASSETS, inputParams, this.getHistoryProfitLossIndexResult, true, this.getHistoryProfitLossIndexTimeout)
    }

    getHistoryProfitLossIndexTimeout = () => {
        console.log('getHistoryProfitLossIndexTimeout')
    }

    getHistoryProfitLossIndexResult = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {}
            this.chart.current &&
                this.chart.current.injectJavaScript(`
                window.dataProfitLossIndex = ${JSON.stringify(jsondata)};
                if (window.eventMarket) {
                    window.eventMarket.next({ type: 'highchart-render', value: 'dataProfitLossIndex' })
                }
                true;
            `)

            if (jsondata && jsondata.length && jsondata[0]) {
                this.getHistoryAssetsIndex(jsondata[0].c0)
            }
        }
    }

    getHistoryAssetsIndex = (value) => {
        const inputParams = ['04', moment(value, 'YYYYMMDD').format('YYYYMMDD'), glb_sv.objShareGlb.workDate, 'HSXIndex']
        sendRequest(ServiceInfo.GET_HISTORY_ASSETS, inputParams, this.getHistoryAssetsIndexResult, true, this.getHistoryAssetsIndexTimeout)
    }

    getHistoryAssetsIndexTimeout = () => {
        console.log('getHistoryAssetsIndexTimeout')
    }
    // 05
    getHistoryAssetsIndexResult = (reqInfoMap, message) => {
        // console.log("getHistoryAssetsIndexResult -> message", message)
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {}

            this.chart.current &&
                this.chart.current.injectJavaScript(`
                window.dataRatioIndex = ${JSON.stringify(jsondata)};
                if (window.eventMarket) {
                    window.eventMarket.next({ type: 'highchart-render', value: 'dataRatioIndex' })
                }
                true;
            `)
        }
    }

    reload = () => {
        this.setState({
            webviewKey: this.state.webviewKey + 1,
        })
    }

    onMessage = (event) => {
        const {
            nativeEvent: { data },
        } = event
        const message = JSON.parse(data)

        if (message && message.fromdt && message.todt && message.type === 'assets_weight_by_month') {
            // this.getHistoryAssetsFull(message.fromdt, message.todt)
            // this.props.lastMessageDayAssetsWeightByMonth = message // Lưu lại message cuối cùng để dùng lại khi thay đổi sub
        }
        console.log('ChartForeignerTrade -> message', message)
    }

    shouldComponentUpdate(nextProps, nextState) {
        console.log('shouldComponentUpdate')
        if (nextState.webviewKey !== this.state.webviewKey || nextState.loading !== this.state.loading || nextProps.userInfo !== this.props.userInfo) {
            return true
        }
        if (nextProps.theme !== this.props.theme) {
            this.chart.current?.reload()
            return true
        }
        return false
    }

    render() {
        return (
            <>
                {this.state.loading ? (
                    <View style={{ alignItems: 'center', justifyContent: 'center' }}>
                        <ActivityIndicator color={this.props.styles.PRIMARY} />
                    </View>
                ) : null}
                <WebView
                    allowUniversalAccessFromFileURLs={true}
                    domStorageEnabled={true}
                    injectedJavaScriptBeforeContentLoaded={`
                    window.chartName = 'my_performance_profit_loss_compare';
                    window.asset_weight = '${this.props.t('asset_weight')}';
                    window.assets_weight = '${this.props.t('assets_weight')}';
                    window.statictis = '${this.props.t('statictis')}';
                    window.profit_or_loss_ratio = '${this.props.t('profit_or_loss_ratio')}';
                    window.cal_profit_loss = '${this.props.t('cal_profit_loss')}';
                    window.ratio_index = '${this.props.t('ratio_index')}';
                    window.absolute_efficiency = '${this.props.t('absolute_efficiency')}';
                    window.compare_vnindex = '${this.props.t('compare_vnindex')}';
                    window.title_assets = '${this.props.t('title_assets')}';
                    window.title_cash = '${this.props.t('title_cash')}';
                    window.title_debt = '${this.props.t('common_debt')}';

                    window.workDate = '${glb_sv.objShareGlb.workDate}';
                    window.theme = '${this.props.theme}'
                    window.PRIMARY__CONTENT__COLOR = '${this.props.styles.PRIMARY__CONTENT__COLOR}';
                    window.PRIMARY = '${this.props.styles.PRIMARY}';
                    window.REF__COLOR = '${this.props.styles.REF__COLOR}';
                    window.PRIMARY__BG__COLOR = '${this.props.styles.PRIMARY__BG__COLOR}';
                    window.DIVIDER__COLOR = '${this.props.styles.DIVIDER__COLOR}';
                    window.ICON__PRIMARY = '${this.props.styles.ICON__PRIMARY}';
                    window.dataProfitLossIndex = [];
                    window.dataRatioIndex = [];
                `}
                    javaScriptEnabled
                    source={source}
                    // source={{
                    //     uri: 'http://192.168.1.31:3000' || 'http://localhost:3000/',
                    // }}
                    key={this.state.webviewKey}
                    originWhitelist={['*']}
                    ref={this.chart}
                    scrollEnabled={false}
                    style={styles.webView}
                    onContentProcessDidTerminate={this.reload}
                    androidLayerType="hardware"
                    // androidHardwareAccelerationDisabled
                    onMessage={this.onMessage}
                />
            </>
        )
    }
}

const styles = StyleSheet.create({
    webView: {
        backgroundColor: 'transparent',
        flex: 1,
    },
})
