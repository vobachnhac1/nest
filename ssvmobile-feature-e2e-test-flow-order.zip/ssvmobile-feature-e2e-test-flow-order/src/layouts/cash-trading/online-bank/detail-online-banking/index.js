import React, { useContext } from 'react'
import { useTranslation } from 'react-i18next'
import moment from 'moment'
import { Container, Content } from 'native-base'

import HeaderComponent from '../../../../components/header'
import { RowData } from '../../../../components/trading-component'
import { StoreContext } from '../../../../store'
import { FormatNumber } from '../../../../utils'

// Khai báo component
export default function DetailOnlineBanking({ navigation, route }) {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()
    const { params = {} } = route
    const { data = {} } = params
    // Start define all bussiness state
    // End define form bussiness state
    // -------------------------------------------   Dùng useEffect get các dữ liệu cần thiết còn thiếu
    // -------------------------------------------   Viết các hàm để set lại bussiness form state. Nên viết đúng một chuẩn duy nhất để dễ control

    // -------------------------------------------   Khai báo các hàm gửi (request) lên server

    const getColor = (status) => {
        if (status === 'N') return styles.REF__COLOR
        if (status === 'R' || status === 'D') return styles.DOWN__COLOR
        if (status === 'Y') return styles.UP__COLOR
    }

    return (
        <Container style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft
                navigation={navigation}
                title={t('sb_orderHis_dt_vise')}
                titleAlgin="flex-start"
                transparent
            />
            <Content>
                <RowData textLeft={t('time')} textRight={moment(data.c0, 'DDMMYYYY').format('DD/MM/YYYY')} />
                <RowData textLeft={t('transaction_type_short')} textRight={data.c2} />
                <RowData textLeft={t('amount_drawal')} textRight={FormatNumber(data.c8, 0, 0)} />
                <RowData dataSub={[data.c3, data.c4]} textLeft={t('acnt_no')} />
                <RowData textLeft={t('common_full_name')} textRight={data.c5} />
                <RowData textLeft={t('common_note')} textRight={data.c9} />
                <RowData textLeft={t('common_chanel')} textRight={data.c14} />
                <RowData textLeft={t('common_work_user')} textRight={data.c11} />
                <RowData textLeft={t('common_work_time')} textRight={moment(data.c13, 'DDMMYYYY').format('DD/MM/YYYY')} />
                <RowData last rightColor={getColor(data.c15)} textLeft={t('approve_status')} textRight={data.c20} />
            </Content>
        </Container>
    )
}
