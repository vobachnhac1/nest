import React, { createRef, PureComponent } from 'react'
import { Platform, StyleSheet, View } from 'react-native'
import WebView from 'react-native-webview'
import throttle from 'lodash/throttle'

import { eventList, glb_sv } from '../../utils'

const source = Platform.select({
    ios: require('../../basic-components/custom-chart/index.html'),
    android: { uri: 'file:///android_asset/index.html' },
})

export default class Chart extends PureComponent {
    constructor(props) {
        super(props)
        this.chart = createRef()
        this.state = {
            webviewKey: new Date().getTime(),
        }
        this.indexCode = props.code
        this.flagdataSMA5 = props.flagdataSMA5
        this.flagdataSMA10 = props.flagdataSMA10
        this.flagdataSMA20 = props.flagdataSMA20
        this.flagdataSMA30 = props.flagdataSMA30

        this.throttled = throttle((newValue) => {
            if (!newValue) return
            this.chart.current &&
                this.chart.current.injectJavaScript(`
                if (window.eventMarket) window.eventMarket.next({ type: 'lightchart-realtime', newIndexNode: ${JSON.stringify(newValue)} })
                true;
            `)
        }, 0)
        this.dataInfo =
            this.props.type === 'INDEX' ? glb_sv.IndexMarket[this.indexCode] : glb_sv.StockMarket[this.indexCode] ? glb_sv.StockMarket[this.indexCode] : {}

        this.data =
            this.props.type === 'INDEX'
                ? glb_sv.IndexMarket[this.indexCode]
                    ? glb_sv.IndexMarket[this.indexCode].arrMinutes
                    : []
                : glb_sv.StockMarket[this.indexCode]
                ? glb_sv.StockMarket[this.indexCode].arrMinutes
                : []
        this.ref = this.dataInfo.ref
    }

    componentDidMount() {
        this.eventMarket = glb_sv.eventMarket.subscribe((msg) => {
            if (msg.type === eventList.SUB_INDEX && msg.newIndexNode && msg.msgKey === this.indexCode) {
                if (!msg.newIndexNode) return
                this.chart.current &&
                    this.chart.current.injectJavaScript(`
                    if (window.eventMarket) window.eventMarket.next({ type: 'lightchart-realtime', newIndexNode: ${JSON.stringify(msg.newIndexNode)} })
                    true;
                `)
            } else if (msg.type === eventList.SUB_INDEX && msg.isHistory && msg.msgKey === this.indexCode) {
                this.data = glb_sv.IndexMarket[this.indexCode].indexArr
                this.chart.current &&
                    this.chart.current.injectJavaScript(`
                    if (window.eventMarket) window.eventMarket.next({ type: 'lightchart-history', data: ${JSON.stringify(this.data)} })
                    true;
                `)
            } else if (msg.type === eventList.SUB_STOCK && msg.message === 'EP' && msg.msgKey === this.indexCode && this.props.type === 'STOCK') {
                if (!msg.newIndexNode) return
                this.chart.current &&
                    this.chart.current.injectJavaScript(`
                    if (window.eventMarket) window.eventMarket.next({ type: 'lightchart-realtime', newIndexNode: ${JSON.stringify(msg.newIndexNode)} })
                    true;
                `)
            } else if (msg.type === eventList.GET_DATA_EP_CHART_DONE && msg.msgKey === this.indexCode) {
                this.data = glb_sv.StockMarket[this.indexCode]?.arrMinutes || []
                this.chart.current &&
                    this.chart.current.injectJavaScript(`
                    if (window.eventMarket) window.eventMarket.next({ type: 'lightchart-history', data: ${JSON.stringify(this.data)} })
                    true;
                `)
            } else if (msg.type === eventList.GET_DATA_I_MINUTES_DONE && msg.msgKey === this.indexCode) {
                this.data = glb_sv.IndexMarket[this.indexCode]?.arrMinutes || []
                this.chart.current &&
                    this.chart.current.injectJavaScript(`
                    if (window.eventMarket) window.eventMarket.next({ type: 'lightchart-history', data: ${JSON.stringify(this.data)} })
                    true;
                `)
            } else if (msg.type === eventList.RESET_DATA) {
                this.data = []
                this.chart.current &&
                    this.chart.current.injectJavaScript(`
                    if (window.eventMarket) window.eventMarket.next({ type: 'lightchart-history', data: ${JSON.stringify(this.data)} })
                    true;
                `)
            }
        })
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.flagdataSMA5 !== this.props.flagdataSMA5) {
            this.chart.current &&
                this.chart.current.injectJavaScript(`
                if (window.eventMarket) window.eventMarket.next({ type: 'lightchart-change-ma', flagdataSMA5: ${nextProps.flagdataSMA5}, flagdataSMA10: ${nextProps.flagdataSMA10}, flagdataSMA20: ${nextProps.flagdataSMA20}, flagdataSMA30: ${nextProps.flagdataSMA30} })
            `)
        }
        if (nextProps.flagdataSMA10 !== this.props.flagdataSMA10) {
            this.chart.current &&
                this.chart.current.injectJavaScript(`
                if (window.eventMarket) window.eventMarket.next({ type: 'lightchart-change-ma', flagdataSMA5: ${nextProps.flagdataSMA5}, flagdataSMA10: ${nextProps.flagdataSMA10}, flagdataSMA20: ${nextProps.flagdataSMA20}, flagdataSMA30: ${nextProps.flagdataSMA30} })
            `)
        }
        if (nextProps.flagdataSMA20 !== this.props.flagdataSMA20) {
            this.chart.current &&
                this.chart.current.injectJavaScript(`
                if (window.eventMarket) window.eventMarket.next({ type: 'lightchart-change-ma', flagdataSMA5: ${nextProps.flagdataSMA5}, flagdataSMA10: ${nextProps.flagdataSMA10}, flagdataSMA20: ${nextProps.flagdataSMA20}, flagdataSMA30: ${nextProps.flagdataSMA30} })
            `)
        }
        if (nextProps.flagdataSMA30 !== this.props.flagdataSMA30) {
            this.chart.current &&
                this.chart.current.injectJavaScript(`
                if (window.eventMarket) window.eventMarket.next({ type: 'lightchart-change-ma', flagdataSMA5: ${nextProps.flagdataSMA5}, flagdataSMA10: ${nextProps.flagdataSMA10}, flagdataSMA20: ${nextProps.flagdataSMA20}, flagdataSMA30: ${nextProps.flagdataSMA30} })
            `)
        }
    }

    componentWillUnmount() {
        this.eventMarket.unsubscribe()
        this.throttled.cancel()
    }

    reload = () => {
        this.setState({
            webviewKey: this.state.webviewKey + 1,
        })
    }

    render() {
        return (
            <View style={{ height: 250 }}>
                <WebView
                    allowUniversalAccessFromFileURLs={true}
                    androidHardwareAccelerationDisabled
                    androidLayerType="software"
                    domStorageEnabled={true}
                    source={source}
                    // source={{
                    //     uri: 'http://192.168.1.24:3000',
                    // }}
                    injectedJavaScriptBeforeContentLoaded={`
                    window.chartName = 'LightChart_Intraday_StockInfo';
                    const now = new Date();
                    new Date().toLocaleString();
                    window.flagdataSMA30 = ${JSON.stringify(this.flagdataSMA30)}
                    window.flagdataSMA5 = ${JSON.stringify(this.flagdataSMA5)}
                    window.flagdataSMA10 = ${JSON.stringify(this.flagdataSMA10)}
                    window.flagdataSMA20 = ${JSON.stringify(this.flagdataSMA20)}
                    window.dataLightChart = ${JSON.stringify(this.data)}
                    window.ref = ${this.ref}
                    window.theme = '${this.props.theme}'
                    true;
                `}
                    javaScriptEnabled
                    key={this.state.webviewKey}
                    originWhitelist={['*']}
                    ref={this.chart}
                    scrollEnabled={false}
                    style={styles.webView}
                    onContentProcessDidTerminate={this.reload}
                    onShouldStartLoadWithRequest={(request) => {
                        return true
                    }}
                />
            </View>
        )
    }
}

const styles = StyleSheet.create({
    webView: {
        backgroundColor: 'transparent',
        flex: 1,
    },
})
