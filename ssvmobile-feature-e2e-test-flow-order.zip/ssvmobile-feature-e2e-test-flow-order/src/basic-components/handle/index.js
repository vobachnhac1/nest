import { StyleSheet } from 'react-native'

export const enhance = (arrStyle) => {
    return StyleSheet.flatten(arrStyle)
}

export const checkKeyInObject = (T, key) => {
    return Object.keys(T).includes(key)
}
