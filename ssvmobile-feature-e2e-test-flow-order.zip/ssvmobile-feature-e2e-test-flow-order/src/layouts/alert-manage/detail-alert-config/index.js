import React, { useContext, useEffect, useMemo, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { FlatList, Pressable, RefreshControl, StyleSheet, TouchableOpacity, View } from 'react-native'
import Modal from 'react-native-modal'
import DateTimePickerModal from 'react-native-modal-datetime-picker'
import ToastGlobal from 'react-native-toast-message'
import throttle from 'lodash/throttle'
import moment from 'moment'
import { Col, Container, Content, Row, Textarea } from 'native-base'

import IconCalendar from '../../../assets/images/common/calendar.svg'
import { CustomFloatInput, Text } from '../../../basic-components'
import HeaderComponent from '../../../components/header'
import ModalLoading from '../../../components/modal-loading'
import { IntraPrice } from '../../../components/stock-info'
import { ButtonCustom, EmptyView, ModalBottomContent, ModalBottomRowSelect, RowTitleGroup } from '../../../components/trading-component'
import { StoreContext } from '../../../store'
import { dimensions as dm, fontSizes as fs, fontWeights as fw, IconSvg } from '../../../styles'
import { eventList, FormatNumber, glb_sv, sendRequest, subcribeFunctStream, wait } from '../../../utils'
import SearchStock from '../../place-order/search-stock'
import { AlertRowInput, BlockBasicInfoStock } from '../component'

const ServiceInfo = {
    queryCondition: {
        WorkerName: 'FOSqMSS01',
        ServiceName: 'FOSqMSS01_GetList',
        Operation: 'Q',
    },
    confirmCreateAlert: {
        WorkerName: 'FOSxMSS01',
        ServiceName: 'FOSxMSS01_ManagementList',
        Operation: 'I',
    },
    confirmUpdateAlert: {
        WorkerName: 'FOSxMSS01',
        ServiceName: 'FOSxMSS01_ManagementList',
        Operation: 'U',
    },
}

const generateNoteArr = (currCondition, listCondition) => {
    let string = ''
    currCondition.map((item, index) => {
        string =
            string + `${mapNameCondition(listCondition, item.c1, item.c2)} ${item.c4} ${FormatNumber(item.c5)}${currCondition.length === index + 1 ? '' : '; '}`
    })
    return string
}

const mapNameCondition = (listCondition, keyOfCondition, conditionCode) => {
    const condition = listCondition.find((cond) => cond.data.c0 === keyOfCondition && cond.data.c1 === conditionCode)
    return condition?.label || ''
}

const DetailAlertConfigLayout = ({ navigation, route }) => {
    const { t } = useTranslation()
    const { styles, theme, language, fractionPrice } = useContext(StoreContext)
    const { params = {} } = route
    const [refreshing, setRefreshing] = useState(false)
    const [stock, setStock] = useState(glb_sv.StockMarket[params?.data?.c2 ? params?.data?.c4 : ''] || {})
    const stockCode = useRef('')
    const [loading, setLoading] = useState(false)

    const throttled = useRef(
        throttle(() => {
            const newValue = glb_sv.StockMarket[stockCode.current]
            setStock(newValue ? { ...newValue } : { t55: stockCode.current, TP: [], EP: [], PO: [] })
        }, 100),
    )

    const initFormState = {
        c0: '01', // Command: 01 (Tạo alert), 02 (Update) ==> Fix cứng khi gửi request
        c1: glb_sv.objShareGlb.workDate, // Trading date
        c2: '', // Seq of Alert
        c3: '1', // Key: 1 (Stock), 2 (Index)
        c4: '', // Mã CK hoặc Index (depend on c3)
        c5: '1', // Loại xử lý: 1 (Chỉ thông báo: Mặc định), 2 (Tự động đặt lệnh)
        c6: 'N', // SMS
        c7: 'Y', // Email
        c8: 'Y', // Notify
        c9: moment(glb_sv.objShareGlb.workDate).add(1, 'day').toDate(), // Ngày bắt đầu
        c10: moment(glb_sv.objShareGlb.workDate).add(5, 'day').toDate(), // Ngày hết hạn
    }

    const [dataForm, setDataForm] = useState(initFormState)
    const [listCurrentConditionAlert, setListCurrentConditionAlert] = useState([])
    const [listCondition, setListCondition] = useState([])

    const [isUpdateAlert, setIsUpdateAlert] = useState(params?.data?.c2 ? true : false)
    const [isOpenModal, setIsOpenModal] = useState(false)
    const [modalDateFrom, setModalDateFrom] = useState(false)
    const [modalDateTo, setModalDateTo] = useState(false)
    const [isSelectCondition, setIsSelectCondition] = useState(false)

    const action = {
        deleteRowConditon: (index) => deleteRowConditon(index),
        onEditAlert: (item) => onEditAlert(item),
        confirmAddOrUpdateAlert: () => confirmAddOrUpdateAlert(),
    }

    const goBackAndRefresh = () => {
        // console.log('onRefresh', params.onRefresh, typeof params.onRefresh)
        if (typeof params.onRefresh === 'function') {
            setTimeout(() => {
                params.onRefresh()
            }, 300)
        }
        navigation.goBack()
    }

    useEffect(() => {
        if (params?.data?.c2) {
            // setDataForm(params.data)
            onEditAlert(params.data)
            subcribeFunctStream('SUB', ['MDDS|SI', 'MDDS|TP'], [params?.data?.c4])
            stockCode.current = params?.data?.c4
        } else {
            setDataForm(initFormState)
            addNewRowConditon() // Default add 1 dòng
        }
        queryCondition()
        // ------------------------
        const eventMarket = glb_sv.eventMarket.subscribe((msg) => {
            if (msg.type === eventList.SUB_STOCK && msg.message !== 'EP' && msg.msgKey === stockCode.current) {
                console.log(stockCode.current, msg)
                throttled.current()
            }
            if (msg.type === eventList.REQ_AFTER_SUB_INFO && msg.value.includes(stockCode.current)) {
                if (glb_sv.StockMarket[stockCode.current]) {
                    throttled.current(glb_sv.StockMarket[stockCode.current])
                } else
                    setStock({
                        t55: stockCode.current,
                        TP: [],
                        PO: [],
                    })
            }
            if (msg.type === eventList.REQ_RE_GET_MKT_INF) {
                subcribeFunctStream('SUB', ['MDDS|SI', 'MDDS|TP'], [stockCode.current])
            }
            if (msg.type === eventList.RECONNECT_MARKET) {
                subcribeFunctStream('SUB', ['MDDS|SI', 'MDDS|TP'], [stockCode.current])
            }
        })

        return () => {
            eventMarket.unsubscribe()
            throttled.current.cancel()
        }
    }, [])

    const confirmAddOrUpdateAlert = () => {
        // console.log('dataForm', dataForm)
        if (listCurrentConditionAlert.length === 0) {
            ToastGlobal.show({
                text2: t('let_add_some_condition'),
                type: 'warning',
            })
            return
        }
        // ------ Cấu hình thông báo
        if (dataForm.c6 === 'N' && dataForm.c7 === 'N' && dataForm.c8 === 'N') {
            ToastGlobal.show({
                text2: t('add_one_notify_method'),
                type: 'warning',
            })
            return
        }
        // ------Mã chứng khoán
        if (dataForm.c4 === '') {
            ToastGlobal.show({
                text2: t('choose_symbol_trading'),
                type: 'warning',
            })
            return
        }
        // ------ Giá trị của cảnh báo
        let errCount = 0
        listCurrentConditionAlert.forEach((cond) => {
            if (Number(cond.c5) === 0) errCount++
        })
        if (errCount > 0) {
            ToastGlobal.show({
                text2: t('value_must_be_more_than_zero'),
                type: 'warning',
            })
            return
        }
        // ------ Check ngày thông báo
        const workDate = moment(glb_sv.objShareGlb.workDate)
        const startDate = moment(dataForm.c9)
        const endDate = moment(dataForm.c10)
        if (workDate.diff(startDate) > 0) {
            ToastGlobal.show({
                text2: t('startDate_mustbe_after_workDate'),
                type: 'warning',
            })
            return
        }
        if (startDate.diff(endDate) > 0) {
            ToastGlobal.show({
                text2: t('endDate_mustbe_after_startDate'),
                type: 'warning',
            })
            return
        }
        // Add alert -------------------
        if (!isUpdateAlert) {
            let inputParams = [
                '01', // Command: 01 (Tạo alert), 02 (Update Alert)
                dataForm.c3, // Key: 1 (Stock), 2 (Index)
                dataForm.c4, // Mã CK hoặc Index (depend on key)
                dataForm.c5, // Loại xử lý: 1 (Chỉ thông báo: Mặc định), 2 (Tự động đặt lệnh)
                dataForm.c6, // SMS
                dataForm.c7, // Email
                dataForm.c8, // Notify
                moment(dataForm.c9).format('YYYYMMDD'), // Ngày bắt đầu
                moment(dataForm.c10).format('YYYYMMDD'), // Ngày hết hạn
            ]

            listCurrentConditionAlert.map((item, idx) => {
                console.log('item add', item)
                const tempArr = [item.c1, item.c2, item.c3, item.c4, String(item.c5)]
                inputParams = inputParams.concat(tempArr)
            })
            console.log('inputParams', inputParams)
            sendRequest(ServiceInfo.confirmCreateAlert, inputParams, handleAddAlert)
            setLoading(true)
        } else {
            // Update alert
            let inputParams = [
                '02', // Command: 01 (Tạo alert), 02 (Update Alert)
                dataForm.c1, // Trading date
                dataForm.c2, // Seq of Alert
                dataForm.c3, // Key: 1 (Stock), 2 (Index)
                dataForm.c4, // Mã CK hoặc Index (depend on key)
                dataForm.c5, // Loại xử lý: 1 (Chỉ thông báo: Mặc định), 2 (Tự động đặt lệnh)
                dataForm.c6, // SMS
                dataForm.c7, // Email
                dataForm.c8, // Notify
                moment(dataForm.c9).format('YYYYMMDD'), // Ngày bắt đầu
                moment(dataForm.c10).format('YYYYMMDD'), // Ngày hết hạn
            ]
            listCurrentConditionAlert.map((item) => {
                const tempArr = [item.c1, item.c2, item.c3, item.c4, String(item.c5)]
                inputParams = inputParams.concat(tempArr)
            })
            console.log('inputParams', inputParams)
            sendRequest(ServiceInfo.confirmUpdateAlert, inputParams, handleAddAlert)
            setLoading(true)
        }
    }

    const handleAddAlert = (reqInfoMap, message) => {
        setLoading(false)
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {}
            console.log('jsondata jsondata', message)
            goBackAndRefresh()
            // onRefresh()
        }
    }
    const deleteRowConditon = (index) => {
        const currentListConfigCondition = listCurrentConditionAlert.filter((item, i) => i !== index)
        setListCurrentConditionAlert(currentListConfigCondition)
    }
    const onEditAlert = (item) => {
        setIsUpdateAlert(true)
        setDataForm({
            c0: '02', // Command: 01 (Tạo alert), 02 (Update) ==> Fix cứng khi gửi request
            c1: item.c0, // Trading date
            c2: item.c1, // Seq of Alert
            c3: item.c3, // Key: 1 (Stock), 2 (Index)
            c4: item.c4, // Mã CK hoặc Index (depend on c3)
            c5: item.c5, // Loại xử lý: 1 (Chỉ thông báo: Mặc định), 2 (Tự động đặt lệnh)
            c6: item.c6, // SMS
            c7: item.c7, // Email
            c8: item.c8, // Notify
            c9: moment(item.c9, 'YYYYMMDD').toDate(), // Ngày bắt đầu
            c10: moment(item.c10, 'YYYYMMDD').toDate(), // Ngày hết hạn
        })
        const ConvertedCondition = []
        const Tempt = item?.c13.split('|')
        Tempt.map((item) => {
            const splited = item.split(',')
            ConvertedCondition.push({
                c0: splited[0], // Subseq of condition
                c1: splited[1], // Key of condition
                c2: splited[3], // Condtion code
                c3: splited[2], // Condition operator: Default 1 (AND)
                c4: splited[4], // Dấu so sánh
                c5: splited[5], // Value of condition
            })
        })
        setListCurrentConditionAlert(ConvertedCondition)
    }

    const addNewRowConditon = (isReset, condition) => {
        const currentListConfigCondition = isReset ? [] : [...listCurrentConditionAlert]
        currentListConfigCondition.push({
            c0: '', // Subseq of condition
            c1: condition?.data?.c0 || '1', // Key of condition
            c2: condition?.data?.c1 || '1', // Condtion code
            c3: '1', // Condition operator: Default 1 (AND)
            c4: '>=', // Dấu so sánh
            c5: '0', // Value of condition
        })
        setListCurrentConditionAlert(currentListConfigCondition)
        hideModal()
    }

    const hideModal = () => {
        setIsOpenModal(false)
        setModalDateFrom(false)
        setModalDateTo(false)
        setIsSelectCondition(false)
    }
    // ----------------------------------------
    const onRefresh = () => {
        setRefreshing(true)
        wait(300).then(() => setRefreshing(false))
    }
    // ------------------------------------------------
    const queryCondition = () => {
        const inputParams = ['03']
        sendRequest(ServiceInfo.queryCondition, inputParams, handleQueryCondition)
    }

    const handleQueryCondition = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {}
            const convertedList = jsondata.map((item) => {
                return {
                    value: item.c0 + '|' + item.c1,
                    label: item.c2,
                    data: item,
                }
            })
            setListCondition(convertedList)
        }
    }

    // ------------------
    const changeStock = (stk, type) => {
        if (stk === stock.t55) {
            stockCode.current = stk
        } else {
            if (stockCode.current) {
                // Unsub nếu đang sub trước đó
                subcribeFunctStream('UNSUB', ['MDDS|SI', 'MDDS|TP'], [stockCode.current])
            }
            stockCode.current = stk
            setDataForm((prev) => ({ ...prev, c4: stk }))
            subcribeFunctStream('SUB', ['MDDS|SI', 'MDDS|TP'], [stk])
        }
    }

    const StylePriceCRFVV = { color: styles.SECOND__CONTENT__COLOR, fontSize: fs.smallest }
    const StyleTextCeil = { color: styles.CEIL__COLOR, fontSize: fs.smallest }

    const StyleTextRef = { color: styles.REF__COLOR, fontSize: fs.smallest }

    const StyleTextFloor = { color: styles.FLOOR__COLOR, fontSize: fs.smallest }

    const ViewBasicStockInfo = () => {
        return (
            <View style={UI.view_price_t31}>
                <IntraPrice
                    change={fractionPrice ? FormatNumber(stock.t31_incr / 1000, 2) : FormatNumber(stock.t31_incr)}
                    indexValueChang={stock.t31_incr_per}
                    price={fractionPrice ? FormatNumber((stock.t31 || stock.t260) / 1000, 2, 0, '---') : FormatNumber(stock.t31 || stock.t260, 0, 0, '---')}
                    ratio={FormatNumber(stock.t31_incr_per, 2)}
                    status={glb_sv.getColor(stock.t31, stock, styles)}
                />

                <View style={UI.marginRight8}>
                    <Text style={StylePriceCRFVV}>{t('ceiling')}</Text>
                    <Text style={StyleTextCeil}>
                        {stock.t332 ? (fractionPrice ? FormatNumber((stock.U29 || stock.t332) / 1000, 2) : FormatNumber(stock.U29 || stock.t332)) : '---'}
                    </Text>
                </View>
                <View style={UI.marginRight8}>
                    <Text style={StylePriceCRFVV}>{t('reference')}</Text>
                    <Text style={StyleTextRef}>
                        {stock.t260 ? (fractionPrice ? FormatNumber((stock.U31 || stock.t260) / 1000, 2) : FormatNumber(stock.U31 || stock.t260)) : '---'}
                    </Text>
                </View>
                <View style={UI.marginRight8}>
                    <Text style={StylePriceCRFVV}>{t('floor')}</Text>
                    <Text style={StyleTextFloor}>
                        {stock.t333 ? (fractionPrice ? FormatNumber((stock.U30 || stock.t333) / 1000, 2) : FormatNumber(stock.U30 || stock.t333)) : '---'}
                    </Text>
                </View>
            </View>
        )
    }
    return (
        <Container style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft
                leftButtonLink={() => goBackAndRefresh()}
                navigation={navigation}
                title={t(isUpdateAlert ? 'alerts_editing' : 'create_new_alerts')}
                titleAlgin="flex-start"
                transparent
            />
            <Content
                refreshControl={<RefreshControl refreshing={refreshing} tintColor={styles.PRIMARY__CONTENT__COLOR} onRefresh={onRefresh} />}
                style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}
            >
                <SearchStock changeStock={changeStock} stock={stock} />
                {stock.t55 ? <ViewBasicStockInfo /> : null}
                {stock.t55 ? (
                    <BlockBasicInfoStock
                        t137={stock.t137 ? (fractionPrice ? FormatNumber(stock.t137 / 1000, 2) : FormatNumber(stock.t137)) : '---'}
                        t137Color={glb_sv.getColor(stock.t137, stock, styles)}
                        t139={stock.t139 ? (fractionPrice ? FormatNumber(stock.t139 / 1000, 2) : FormatNumber(stock.t139)) : '---'}
                        t139Color={glb_sv.getColor(stock.t139, stock, styles)}
                        t266={stock.t266 ? (fractionPrice ? FormatNumber(stock.t266 / 1000, 2) : FormatNumber(stock.t266)) : '---'}
                        t2661={stock.t2661 ? (fractionPrice ? FormatNumber(stock.t2661 / 1000, 2) : FormatNumber(stock.t2661)) : '---'}
                        t2661Color={glb_sv.getColor(stock.t2661, stock, styles)}
                        t266Color={glb_sv.getColor(stock.t266, stock, styles)}
                        t3301={stock.t3301 ? FormatNumber(stock.t3301, 0, 0, 'short') : '---'}
                        t3871={stock.t3871 ? FormatNumber(stock.t3871, 0, 0, 'short') : '---'}
                        t391={stock.t391 ? FormatNumber(stock.t391, 0, 0, 'short') : '---'}
                        t397_t398={
                            (stock.t397 ? FormatNumber(stock.t397, 0, 0, 'short') : '---') +
                            '/' +
                            (stock.t398 ? FormatNumber(stock.t398, 0, 0, 'short') : '---')
                        }
                    />
                ) : null}

                {/* --------------- */}
                <FlatList
                    data={listCurrentConditionAlert}
                    keyExtractor={(item, index) => index.toString()}
                    ListEmptyComponent={EmptyView}
                    renderItem={({ item, index }) => {
                        return (
                            <AlertRowInput
                                alertName={mapNameCondition(listCondition, item.c1, item.c2)}
                                conditionInfo={item}
                                deleteRowConditon={() => action.deleteRowConditon(index)}
                                indexCondition={index}
                                listCondition={listCondition}
                                listCurrentConditionAlert={listCurrentConditionAlert}
                                setListCurrentConditionAlert={setListCurrentConditionAlert}
                            />
                        )
                    }}
                    style={{ marginTop: dm.vertical(8) }}
                />

                <View style={[UI.ButtonAdd, { backgroundColor: styles.PRIMARY }]}>
                    <TouchableOpacity
                        onPress={() => {
                            setIsSelectCondition(true)
                        }}
                    >
                        <Text style={{ color: '#fff', fontWeight: fw.bold }}>{t('confirm_add_condition')}</Text>
                    </TouchableOpacity>
                </View>

                <Row>
                    <Col size={12}>
                        <Pressable onPress={() => setModalDateFrom(true)}>
                            <View pointerEvents="none" style={UI.RowFilter}>
                                <CustomFloatInput
                                    label={t('common_from_date')}
                                    rightComponent={
                                        <IconCalendar fill={styles.PRIMARY__CONTENT__COLOR} style={{ marginVertical: dm.vertical(20), marginRight: 5 }} />
                                    }
                                    staticLabel
                                    value={moment(dataForm.c9).format('DD/MM/YYYY')}
                                />
                            </View>
                        </Pressable>
                    </Col>
                    <Col size={12}>
                        <Pressable onPress={() => setModalDateTo(true)}>
                            <View pointerEvents="none" style={UI.RowFilter}>
                                <CustomFloatInput
                                    label={t('common_to_date')}
                                    rightComponent={
                                        <IconCalendar fill={styles.PRIMARY__CONTENT__COLOR} style={{ marginVertical: dm.vertical(20), marginRight: 5 }} />
                                    }
                                    staticLabel
                                    value={moment(dataForm.c10).format('DD/MM/YYYY')}
                                />
                            </View>
                        </Pressable>
                    </Col>
                </Row>
                {/* Email/ SMS/ Notify */}
                <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                    <View style={UI.RowCheckBox}>
                        <TouchableOpacity
                            activeOpacity={0.9}
                            style={UI.RowCheckBoxTouch}
                            onPress={() => setDataForm((prev) => ({ ...prev, c8: prev.c8 === 'Y' ? 'N' : 'Y' }))}
                        >
                            <View style={{ paddingTop: 2 }}>
                                <IconSvg.CheckboxIcon
                                    active={dataForm.c8 === 'Y'}
                                    colorActive={styles.PRIMARY}
                                    colorunActive={styles.PRIMARY__CONTENT__COLOR}
                                />
                            </View>
                            <Text
                                style={{
                                    fontSize: fs.small,
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                    marginLeft: dm.moderate(8),
                                    marginRight: 16,
                                }}
                            >
                                <Text
                                    style={{
                                        fontSize: fs.small,
                                        color: dataForm.c8 === 'Y' ? styles.PRIMARY__CONTENT__COLOR : styles.SECOND__CONTENT__COLOR,
                                        fontWeight: fw.medium,
                                    }}
                                >
                                    {t('common_notify')}
                                </Text>
                            </Text>
                        </TouchableOpacity>
                    </View>
                    <View style={UI.RowCheckBox}>
                        <TouchableOpacity
                            activeOpacity={0.9}
                            style={UI.RowCheckBoxTouch}
                            onPress={() => setDataForm((prev) => ({ ...prev, c7: prev.c7 === 'Y' ? 'N' : 'Y' }))}
                        >
                            <View style={{ paddingTop: 2 }}>
                                <IconSvg.CheckboxIcon
                                    active={dataForm.c7 === 'Y'}
                                    colorActive={styles.PRIMARY}
                                    colorunActive={styles.PRIMARY__CONTENT__COLOR}
                                />
                            </View>
                            <Text
                                style={{
                                    fontSize: fs.small,
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                    marginLeft: dm.moderate(8),
                                    marginRight: 16,
                                }}
                            >
                                <Text
                                    style={{
                                        fontSize: fs.small,
                                        color: dataForm.c7 === 'Y' ? styles.PRIMARY__CONTENT__COLOR : styles.SECOND__CONTENT__COLOR,
                                        fontWeight: fw.medium,
                                    }}
                                >
                                    {t('email')}
                                </Text>
                            </Text>
                        </TouchableOpacity>
                    </View>
                    <View style={UI.RowCheckBox}>
                        {/* <TouchableOpacity
                            activeOpacity={0.9}
                            onPress={() => setDataForm((prev) => ({ ...prev, c6: prev.c6 === 'Y' ? 'N' : 'Y' }))}
                            style={UI.RowCheckBoxTouch}>
                            <View style={{ paddingTop: 2 }}>
                                <IconSvg.CheckboxIcon
                                    active={dataForm.c6 === 'Y'}
                                    colorActive={styles.PRIMARY}
                                    colorunActive={styles.PRIMARY__CONTENT__COLOR}
                                />
                            </View>
                            <Text
                                style={{
                                    fontSize: fs.small,
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                    marginLeft: dm.moderate(8),
                                    marginRight: 16,
                                }}>
                                <Text
                                    style={{
                                        fontSize: fs.small,
                                        color: dataForm.c6 === 'Y' ? styles.PRIMARY__CONTENT__COLOR : styles.SECOND__CONTENT__COLOR,
                                        fontWeight: fw.medium,
                                    }}>
                                    {t('head_sms')}
                                </Text>
                            </Text>
                        </TouchableOpacity> */}
                    </View>
                </View>

                <View style={{ paddingHorizontal: dm.moderate(16), marginTop: dm.moderate(16) }}>
                    <Textarea
                        disabled
                        rowSpan={5}
                        style={{ borderRadius: 8, borderWidth: 0, backgroundColor: styles.INPUT__BG, color: styles.PRIMARY__CONTENT__COLOR }}
                        value={generateNoteArr(listCurrentConditionAlert, listCondition)}
                        onChangeText={(value) => null}
                    />
                </View>
                <ButtonCustom text={t(isUpdateAlert ? 'alerts_editing' : 'create_new_alerts')} type="confirm" onPress={confirmAddOrUpdateAlert} />
                <ButtonCustom last text={t('common_Cancel')} type="back" onPress={() => goBackAndRefresh()} />
            </Content>
            {modalDateFrom && (
                <DateTimePickerModal
                    cancelTextIOS={t('common_Cancel')}
                    confirmTextIOS={t('common_Ok')}
                    date={dataForm.c9}
                    headerTextIOS={t('common_birthday')}
                    isDarkModeEnabled={theme.includes('DARK')}
                    isVisible={modalDateFrom}
                    locale={language === 'VI' ? 'vi_VN' : 'en_US'}
                    mode="date"
                    onCancel={hideModal}
                    onConfirm={(value) => {
                        hideModal()
                        setDataForm((prev) => ({ ...prev, c9: value }))
                    }}
                />
            )}
            {modalDateTo && (
                <DateTimePickerModal
                    cancelTextIOS={t('common_Cancel')}
                    confirmTextIOS={t('common_Ok')}
                    date={dataForm.c10}
                    headerTextIOS={t('common_birthday')}
                    isDarkModeEnabled={theme.includes('DARK')}
                    isVisible={modalDateTo}
                    locale={language === 'VI' ? 'vi_VN' : 'en_US'}
                    mode="date"
                    onCancel={hideModal}
                    onConfirm={(value) => {
                        hideModal()
                        setDataForm((prev) => ({ ...prev, c10: value }))
                    }}
                />
            )}
            {isSelectCondition && (
                <Modal
                    hideModalContentWhileAnimating={true}
                    isVisible={isSelectCondition}
                    style={UI.bottomModal}
                    useNativeDriver={true}
                    onBackButtonPress={() => hideModal()}
                    onBackdropPress={() => hideModal()}
                >
                    <ModalBottomContent title={t('Chọn điều kiện')}>
                        {listCondition.map((item, index) => (
                            <ModalBottomRowSelect key={index} text={t(item.label)} onPress={() => addNewRowConditon(false, item)} />
                        ))}
                    </ModalBottomContent>
                </Modal>
            )}
            {loading && <ModalLoading content={t('processing')} visible={loading} />}
        </Container>
    )
}

export default DetailAlertConfigLayout

const UI = StyleSheet.create({
    ButtonAdd: {
        alignItems: 'center',
        alignSelf: 'flex-end',
        borderRadius: 16,
        justifyContent: 'center',
        marginHorizontal: dm.moderate(16),
        marginVertical: 16,
        paddingHorizontal: 16,
        paddingVertical: 8,
        width: dm.WIDTH * 0.4,
    },
    RowCheckBox: {
        borderRadius: 12,
        flexDirection: 'row',
        marginHorizontal: dm.moderate(16),
        marginTop: dm.vertical(12),
    },
    RowCheckBoxTouch: { alignItems: 'center', flexDirection: 'row', marginTop: dm.vertical(16) },
    RowFilter: {
        marginHorizontal: dm.moderate(8),
        marginVertical: dm.vertical(8),
    },
    bottomModal: {
        justifyContent: 'flex-end',
        margin: 0,
    },
    marginRight8: { marginRight: 8 },
    view_price_t31: { alignItems: 'center', flexDirection: 'row', marginHorizontal: dm.moderate(4), marginTop: 4 },
})
