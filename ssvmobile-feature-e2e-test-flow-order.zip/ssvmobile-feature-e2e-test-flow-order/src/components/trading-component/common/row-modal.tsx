import React, { useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { StyleSheet, View } from 'react-native'

import { Text } from '../../../basic-components'
import { StoreContext } from '../../../store'
import { dimensions as dm, fontSizes as fs, fontWeights as fw } from '../../../styles'

interface IRowDataModal {
    textLeft?: string
    textRight?: string
    textRight2?: string
    rightComponent?: any
    dataSub?: string[]
    rightColor?: string
    type?: 'modal' | ''
    last?: boolean
}

const RowDataModal = ({
    textLeft, // Nội dung Bên trái
    textRight, // Nội dung bên phải
    textRight2, // Nội dung phụ bên phải
    rightComponent, // Commponent bên phải nếu có (Sử dụng input, ...)
    dataSub = [], // Nội dung sub
    rightColor, // Color bên phải
    type = 'modal', // type của Row
    last, // có phải là button cuối cùng của list button hay không
    ...props
}: IRowDataModal) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()
    return (
        <View
            style={{
                paddingVertical: dm.vertical(8),
                marginHorizontal: dm.moderate(16),
                flexDirection: 'row',
                borderBottomColor: '#444c575d', // styles.DIVIDER__MODAL__COLOR,
                borderBottomWidth: last ? 0 : StyleSheet.hairlineWidth,
            }}
        >
            <View style={{ flex: 12, justifyContent: 'center' }}>
                <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fs.verySmall }}>{t<string>(textLeft || '')}</Text>
            </View>
            <View style={{ flex: 12 }}>
                {dataSub[0] ? (
                    <View style={{ flex: 1, flexDirection: 'row' }}>
                        <Text style={{ fontSize: fs.small, color: styles.PRIMARY__CONTENT__COLOR }}>{dataSub[0]}</Text>
                        <View style={{ ...UI.Badge_Sub, backgroundColor: styles.PRIMARY }}>
                            <Text style={{ color: '#fff', fontSize: fs.verySmall, fontWeight: fw.bold }}>{dataSub[1]}</Text>
                        </View>
                    </View>
                ) : null}
                {textRight ? (
                    <Text style={{ color: rightColor ? rightColor : styles.PRIMARY__CONTENT__COLOR, fontSize: fs.small }}>{t<string>(textRight)}</Text>
                ) : null}
                {textRight2 ? <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fs.verySmall }}>{t<string>(textRight2)}</Text> : null}
                {rightComponent}
            </View>
        </View>
    )
}

export default RowDataModal

const UI = StyleSheet.create({
    Badge_Sub: {
        alignItems: 'center',
        borderRadius: 4,
        height: dm.moderate(20),
        justifyContent: 'center',
        marginLeft: 4,
        width: dm.moderate(20),
    },
})
