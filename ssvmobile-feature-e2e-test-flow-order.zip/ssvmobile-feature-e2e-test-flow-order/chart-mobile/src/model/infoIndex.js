export default class InfoIndex {
    constructor() {
        this.indexArr = []
        this.ref = 0
        this.indexValue = 0 // t3
        this.indexValueChang = 0 // t5
        this.indexRatioChang = 0 // t6
        this.indexTotalQty = 0
        this.indexTotalValue = 0
        this.indexCode = '' // t2
        this.indexName = '' // t18
        this.increase = 0
        this.equaCeil = 0
        this.noChange = 0
        this.decrease = 0
        this.equaFloor = 0
        this.statusName = '' // t340 name
        this.statusCode = '' // t340
        // this.messageI = [];
        this.qtyBiglot = 0
        this.valueBiglot = 0
        this.lastSeq = 0 // Seq of last message
        this.timeServer = ''
        this.indexHighest = 0
        this.indexLowest = 0
        this.indexOpen = 0
        this.indexClose = 0
        this.indexColor = 'orange'

        this.t340 = ''
        this.t340_code = ''
        this.t340_nm = ''
        this.timeIndex = ''
    }
}
