import React, { useContext } from 'react'
import { useTranslation } from 'react-i18next'

import { StoreContext } from '../../store'
import { AppModalProps } from './type'

export const useAppModal = ({
    linkCallback,
    onCallBack,
    middleComponent,
    notTouch,
    icon,
    title,
    colorTitle,
    typeColor,
    footerComponent,
    cancelCallBack,
    showCancel,
    content,
    titleOK,
    isVisible,
    isBackdropClose = true,
}: AppModalProps) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()

    const handleConfirm = () => {
        if (typeof linkCallback === 'function') {
            linkCallback()
        } else if (typeof onCallBack === 'function') {
            onCallBack()
        }
    }

    const handleCancel = () => {
        if (cancelCallBack) {
            cancelCallBack()
        } else if (!showCancel && linkCallback) {
            linkCallback()
        } else if (typeof onCallBack === 'function') {
            onCallBack()
        }
    }

    return {
        isVisible,
        t,
        styles,
        handleConfirm,
        handleCancel,
        linkCallback,
        onCallBack,
        middleComponent,
        notTouch,
        icon,
        title,
        colorTitle,
        typeColor,
        footerComponent,
        cancelCallBack,
        showCancel,
        content,
        titleOK,
        isBackdropClose,
    }
}
