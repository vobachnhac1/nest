import React, { useContext, useEffect, useRef, useState } from 'react'
import { ActivityIndicator, Platform, View } from 'react-native'
import { WebView } from 'react-native-webview'

import Chart from '../../components/f2-chart'
import { StoreContext } from '../../store'
import { dimensions } from '../../styles'

const IOS = Platform.OS === 'ios' ? true : false

// const data = [{color: "#EFADFF", x: "Tiền", y: [0, 0.41]}, {color: "#AFAAFF", x: "Cổ phiếu", y: [50.19, 100]}, {color: "#92EB7E", x: "Tài sản", y: [0, 100]}, {color: "#FF3300", x: "Dư nợ", y: [100, 100]}, {color: "#5B9BD5", x: "Tài sản ròng", y: [0, 100]}]

const ColumnChart = ({ dataChart, dataChartDefault, isVisibleChart, isLoadingChart, timeoutView }) => {
    const { styles } = useContext(StoreContext)
    const barChartHeight = (dimensions.HIEGHT - dimensions.moderate(500)) / 2
    const webViewRef = useRef(null)
    const [loading, setLoading] = useState(false)

    useEffect(() => {
        const isDefaultData = JSON.stringify([...dataChart]) === JSON.stringify([...dataChartDefault])
        if (isDefaultData && isLoadingChart) {
            setLoading(true)
        } else {
            setLoading(false)
        }
        webViewRef.current?.repaint(`(() => {
            window.chart?.guide().clear();
            ${JSON.stringify(dataChart)}.forEach(function(obj) {
              const guide = window.chart?.guide().text({
                position: [ obj.x, obj.y[1]],
                content: obj.hideLabel ? null : !(obj.y[1] - obj.y[0]) ? null : (obj.y[1] - obj.y[0]).toFixed(2) + '%',
                style: {
                  textBaseline: 'bottom',
                  textAlign: 'center',
                  color: '${styles.PRIMARY__CONTENT__COLOR}',
                  fill: '${styles.PRIMARY__CONTENT__COLOR}',
                  fontWeight: 'bold',
                },
                offsetY: -2
              });
              guide.repaint();
            });
            window.chart?.repaint()
      })()`)
    }, [dataChart, isLoadingChart])

    return (
        <View style={{ paddingLeft: 5, minWidth: (dimensions.WIDTH - dimensions.moderate(16)) / 2 }}>
            <View style={{ height: barChartHeight > 160 ? barChartHeight : 160, backgroundColor: styles.PRIMARY__BG__COLOR }}>
                <Chart
                    data={dataChart}
                    initScript={IOS ? chartAssetIOS(dataChart, styles) : chartAssetAndroid(dataChart, styles)}
                    ref={webViewRef}
                    webView={WebView}
                />
                {timeoutView}
            </View>
            {loading ? (
                <ActivityIndicator
                    color="#494949"
                    size={30}
                    style={{ position: 'absolute', bottom: '80%', right: '50%', transform: [{ translateX: 15 }, { translateY: 15 }] }}
                />
            ) : null}
        </View>
    )
}

export default ColumnChart

const chartAssetAndroid = (data, styles) => `
  setTimeout(() => {
    const chart = new F2.Chart({
      id: 'chart',
      pixelRatio: window.devicePixelRatio,
    });
    // --------------
    chart.source(${JSON.stringify(data)}, {
      y: {
        tickCount: 5,
      }
    });
    chart.axis('x', {
      label: function label(text) {
        const cfg = {};
        cfg.fill = '${styles.PRIMARY__CONTENT__COLOR}';
        cfg.fontWeight = 'bold';
        return cfg;
      }
    });
    chart.axis('y', false);
    // -------
    // -------
    chart.interval().position('x*y').animate({
      appear: {
        animation: 'shapesScaleInY'
      }
    });
    chart.render();
    window.chart = chart
  },1000);
  true;
`

const chartAssetIOS = (data, styles) => `
  setTimeout(() => {
    const chart = new F2.Chart({
      id: 'chart',
      pixelRatio: window.devicePixelRatio,
    });
    chart.source(${JSON.stringify(data)}, {
      y: {
        tickCount: 5
      }
    });
    chart.axis('x', {
      label: function label(text) {
        const cfg = {};
        cfg.fill = '${styles.PRIMARY__CONTENT__COLOR}';
        cfg.fontWeight = 'bold';
        return cfg;
      }
    });
    chart.axis('y', false);

    chart.interval().position('x*y').animate({
      appear: {
        animation: 'shapesScaleInY'
      }
    });
    chart.render();
    window.chart = chart
  },1000);
  true;
`
