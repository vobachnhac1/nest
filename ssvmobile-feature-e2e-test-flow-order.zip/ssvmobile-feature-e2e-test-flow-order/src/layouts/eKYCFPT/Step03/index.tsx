/**
 * STEP 3:
 * Bao gồm đăng ký các tiện ích, ...
 */

import React, { forwardRef, useContext, useImperativeHandle } from 'react'
import { useTranslation } from 'react-i18next'
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native'
import { dimensions, fontSizes, fontWeights } from '@mts-styles/index'
import { useNavigation } from '@react-navigation/native'
import { Container, Tab, Tabs } from 'native-base'

import { StoreContext } from '../../../store'
import { ISwitchStep } from '..'
import { AdditionInfoStep1 } from './AdditionInfo/addition_info_step_1'
import { AdditionInfoStep2 } from './AdditionInfo/addition_info_step_2'
import { useAdditionInfo } from './AdditionInfo/useAdditionInfo'

interface IFourthStep {
    switchStep: ISwitchStep
}

export const FourthStep = forwardRef(({ switchStep, subActiveStep }, ref) => {
    const navigation = useNavigation()
    const { styles } = useContext(StoreContext)

    const additionalInfoProps = useAdditionInfo({ navigation, switchStep })
    const { t } = useTranslation()

    return (
        <>
            <View style={UI.container}>
                {/* <AdditionalInfo {...additionalInfoProps} /> */}
                <Tabs locked page={subActiveStep} renderTabBar={() => <View />}>
                    <Tab heading={t('1')}>
                        <AdditionInfoStep1 {...additionalInfoProps} />
                    </Tab>
                    <Tab heading={t('2')}>
                        <AdditionInfoStep2 {...additionalInfoProps} />
                    </Tab>
                </Tabs>
            </View>
        </>
    )
})

const UI = StyleSheet.create({
    container: {
        flex: 1,
        // height: HIEGHT - 200,
        alignContent: 'space-between',
        justifyContent: 'space-between',
    },
    image: {
        alignContent: 'flex-start',
        alignItems: 'center',
        height: 80,
        justifyContent: 'flex-start',
        marginVertical: 10,
    },
    modal: {
        justifyContent: 'flex-end',
        margin: 0,
    },
    row: {
        alignItems: 'center',
        borderRadius: 12,
        flexDirection: 'row',
        marginHorizontal: dimensions.moderate(16),
        marginTop: dimensions.vertical(12),
    },
    rowNote: {
        alignItems: 'center',
        borderRadius: 12,
        flexDirection: 'row',
        marginHorizontal: dimensions.moderate(8),
        marginTop: dimensions.vertical(12),
    },
    styleContainer: (styles) => ({
        backgroundColor: styles.PRIMARY__BG__COLOR,
        flex: 1,
    }),
})
