import { MutableRefObject } from 'react'

export type CustomModalRef = {
    show: (message?: string) => void
    hide: () => void
}

export default class ModalController {
    static modalRef: MutableRefObject<CustomModalRef>
    static setModalRef = (ref: any) => {
        this.modalRef = ref
    }

    static showModal = (modalProps) => {
        this.modalRef.current?.show(modalProps)
    }
    static hideModal = () => {
        this.modalRef.current?.hide()
    }
}
