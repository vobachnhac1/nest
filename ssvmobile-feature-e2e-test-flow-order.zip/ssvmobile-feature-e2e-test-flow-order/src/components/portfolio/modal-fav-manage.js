import React, { memo, useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { InteractionManager, StyleSheet, TouchableOpacity, View } from 'react-native'
import Modal from 'react-native-modal'
import Svg, { Path, Rect } from 'react-native-svg'

import { Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { dimensions, fontSizes, fontWeights, IconSvg } from '../../styles'
import { glb_sv } from '../../utils'

const ModalFavManage = ({
    setVisibleAddModal,
    visibleModalManageList,
    setVisibleModalManageList,
    changeSearchScreen,
    setVisibleDeleteModal,
    setVisibleEditModal,
    onChangePriceboard,
    setVisibleAddModalOddlot,
}) => {
    const { t } = useTranslation()
    const { styles } = useContext(StoreContext)

    const addStock = () => {
        setVisibleModalManageList(false)
        InteractionManager.runAfterInteractions(() => {
            setTimeout(() => {
                changeSearchScreen()
            }, 0)
        })
    }

    const addFav = () => {
        setVisibleModalManageList(false)
        InteractionManager.runAfterInteractions(() => {
            setTimeout(() => {
                setVisibleAddModal(true)
            }, 0)
        })
    }

    const editFav = () => {
        setVisibleModalManageList(false)
        InteractionManager.runAfterInteractions(() => {
            setTimeout(() => {
                setVisibleEditModal(true)
            }, 0)
        })
    }

    const deleteFav = () => {
        setVisibleModalManageList(false)
        InteractionManager.runAfterInteractions(() => {
            setTimeout(() => {
                setVisibleDeleteModal(true)
            }, 0)
        })
    }

    const switchPriceboard = () => {
        setVisibleModalManageList(false)
        InteractionManager.runAfterInteractions(() => {
            setTimeout(() => {
                onChangePriceboard && onChangePriceboard()
            }, 0)
        })
    }

    const addFavOddlot = () => {
        setVisibleModalManageList(false)
        InteractionManager.runAfterInteractions(() => {
            setTimeout(() => {
                setVisibleAddModalOddlot(true)
            }, 0)
        })
    }

    return (
        <Modal
            isVisible={visibleModalManageList}
            style={UI.modal}
            swipeDirection={['down']}
            onBackButtonPress={() => setVisibleModalManageList(false)}
            onBackdropPress={() => setVisibleModalManageList(false)}
            onSwipeComplete={() => setVisibleModalManageList(false)}
        >
            <View
                style={{
                    backgroundColor: styles.PRIMARY__BG__COLOR,
                    padding: dimensions.moderate(24),
                    justifyContent: 'flex-start',
                    borderTopLeftRadius: 12,
                    borderTopRightRadius: 12,
                    paddingBottom: glb_sv.activeList.type === 'watchlist' ? 50 : 150,
                }}
            >
                <Text
                    style={{
                        marginBottom: dimensions.vertical(24),
                        fontSize: fontSizes.xmedium,
                        color: styles.PRIMARY__CONTENT__COLOR,
                        fontWeight: fontWeights.semiBold,
                    }}
                >
                    {t('fav_manage')}
                </Text>
                {glb_sv.activeList.type === 'watchlist' ? (
                    <TouchableOpacity style={UI.row} onPress={addStock}>
                        <PlusIcon color={styles.GREEN__DARK__COLOR} />
                        <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.medium, marginLeft: dimensions.moderate(12) }}>
                            {t('add_stock')}
                        </Text>
                    </TouchableOpacity>
                ) : null}
                <TouchableOpacity style={UI.row} onPress={addFav}>
                    <PlusIcon color={styles.GREEN__COLOR} />
                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.medium, marginLeft: dimensions.moderate(12) }}>
                        {t('add_new_favorites')} {t('even_lot')}
                    </Text>
                </TouchableOpacity>
                <TouchableOpacity style={UI.row} onPress={addFavOddlot}>
                    <PlusIcon color={styles.GREEN__COLOR} />
                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.medium, marginLeft: dimensions.moderate(12) }}>
                        {t('add_new_favorites')} {t('odd_lot')}
                    </Text>
                </TouchableOpacity>
                {glb_sv.activeList.type === 'watchlist' ? (
                    <TouchableOpacity style={UI.row} onPress={editFav}>
                        <EditIcon color={styles.YELLOW__COLOR} />
                        <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.medium, marginLeft: dimensions.moderate(12) }}>
                            {' '}
                            {t('modify_nm_of_fav')}
                        </Text>
                    </TouchableOpacity>
                ) : null}
                {glb_sv.activeList.type === 'watchlist' ? (
                    <TouchableOpacity style={UI.row} onPress={deleteFav}>
                        <DeleteIcon color={styles.RED__COLOR} />
                        <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.medium, marginLeft: dimensions.moderate(12) }}>
                            {' '}
                            {t('remove_a_favorites')}
                        </Text>
                    </TouchableOpacity>
                ) : null}
            </View>
        </Modal>
    )
}

const PlusIcon = memo(PlusIconMemo)
function PlusIconMemo({ color }) {
    return (
        <Svg height={36} viewBox="0 0 36 36" width={36}>
            <Rect fill={color} height={36} opacity={0.1} rx={8} width={36} />
            <Path
                d="M26 12.093A2.093 2.093 0 0023.907 10H12.093A2.093 2.093 0 0010 12.093v11.814c0 1.156.937 2.093 2.093 2.093h11.814A2.093 2.093 0 0026 23.907V12.093zM13.591 23.065a.466.466 0 01-.57-.57l.574-2.144 2.14 2.14-2.143.574zm9.237-7.793l-6.33 6.33-2.129-2.128 6.33-6.33c.3-.3.787-.3 1.087 0l1.042 1.041c.3.3.3.787 0 1.088z"
                fill={color}
            />
            <Path
                d="M22.828 15.273l-6.33 6.33-2.129-2.13 6.33-6.33c.3-.3.787-.3 1.087 0l1.042 1.042c.3.3.3.787 0 1.088zM13.591 23.065a.466.466 0 01-.57-.57l.574-2.144 2.14 2.14-2.143.574z"
                fill={color}
            />
            <Path
                d="M18.67 18.644h2.686a.644.644 0 000-1.288H18.67V14.67a.67.67 0 10-1.342 0v2.685h-2.685a.644.644 0 000 1.288h2.685v2.685a.67.67 0 101.342 0v-2.685z"
                fill="#fff"
            />
        </Svg>
    )
}

const EditIcon = memo(EditIconMemo)
function EditIconMemo({ color }) {
    return (
        <Svg height={36} viewBox="0 0 36 36" width={36}>
            <Rect fill={color} height={36} opacity={0.1} rx={8} width={36} />
            <Path
                d="M26 12.093A2.093 2.093 0 0023.907 10H12.093A2.093 2.093 0 0010 12.093v11.814c0 1.156.937 2.093 2.093 2.093h11.814A2.093 2.093 0 0026 23.907V12.093zM13.591 23.065a.466.466 0 01-.57-.57l.574-2.144 2.14 2.14-2.143.574zm9.237-7.793l-6.33 6.33-2.129-2.128 6.33-6.33c.3-.3.787-.3 1.087 0l1.042 1.041c.3.3.3.787 0 1.088z"
                fill={color}
            />
        </Svg>
    )
}

const DeleteIcon = memo(DeleteIconMemo)
function DeleteIconMemo({ color }) {
    return (
        <Svg height={36} viewBox="0 0 36 36" width={36}>
            <Rect fill={color} height={36} opacity={0.1} rx={8} width={36} />
            <Path
                d="M25.5 9.875h-15c-.69 0-1.25.56-1.25 1.25v.625c0 .69.56 1.25 1.25 1.25h15c.69 0 1.25-.56 1.25-1.25v-.625c0-.69-.56-1.25-1.25-1.25zM10.908 14.25a.313.313 0 00-.312.345l1.028 9.866a1.875 1.875 0 001.863 1.664h9.027a1.875 1.875 0 001.862-1.656v-.008l1.026-9.866a.314.314 0 00-.313-.345H10.91zm9.722 7.058a.625.625 0 11-.884.884L18 20.447l-1.745 1.745a.625.625 0 01-.884-.884l1.745-1.745-1.745-1.746a.625.625 0 01.883-.884L18 18.678l1.745-1.745a.625.625 0 01.884.884l-1.745 1.745 1.745 1.746z"
                fill={color}
            />
        </Svg>
    )
}

const UI = StyleSheet.create({
    modal: {
        justifyContent: 'flex-end',
        margin: 0,
    },
    row: {
        alignItems: 'center',
        flexDirection: 'row',
        marginBottom: dimensions.vertical(12),
        padding: dimensions.moderate(7),
    },
})

export default memo(ModalFavManage)
