import React, { memo, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Animated, FlatList, InteractionManager, ScrollView, StyleSheet, View } from 'react-native'
import { ScrollableTab, Tab, Tabs } from 'native-base'
import SyncStorage from 'sync-storage'

import { StoreContext } from '../../../store'
import { dimensions, fontSizes, fontWeights } from '../../../styles'
import { eventList, FormatNumber, glb_sv, reqFunct, sendRequest, STORE_KEY, subcribeFunctStream } from '../../../utils'
import HeaderTop from './HeaderTop'
import OptionsTop from './OptionsTop'
import RowTop from './RowTop'

const ServiceInfo = {
    GET_MARKET_TOP: {
        reqFunct: reqFunct.GET_MARKET_TOP,
        WorkerName: 'FOSqMkt02',
        ServiceName: 'FOSqMkt02_MktInfo',
        Operation: 'Q',
        ClientSentTime: '0',
    },
}

const listTimeHis = ['1W', '1M', '3M', '6M', '1Y', '2Y', '3Y']

function getInitPage() {
    if (glb_sv.TYPE_TOP_MARKET === 'TOP_QTY_UP') return 1
    if (glb_sv.TYPE_TOP_MARKET === 'FRG_VAL_UP') return 2
    if (glb_sv.TYPE_TOP_MARKET === 'TOP_PRI_UP') return 3
    if (glb_sv.TYPE_TOP_MARKET === 'TOP_PRI_DOWN') return 4
    return 0
}

function TopMaket({ active, navigateStockInfo, scrollY, height, handleScrollTop }) {
    const { styles, fractionPrice, applicationSettings } = useContext(StoreContext)
    const { t } = useTranslation()
    const dataRef = useRef([])
    const [type, setType] = useState(glb_sv.TYPE_TOP_MARKET)
    const [page, setPage] = useState(getInitPage)

    const [activeOtp, setActiveOtp] = useState('1D')
    const activeOtpRef = useRef('1D')

    const [loading, setLoading] = useState(true)

    const timeoutChangeTabRef = useRef(null)
    const tabY = useRef(new Animated.Value(0))

    const [dataTopValue, setDataTopValue] = useState([])
    const [dataTopVolume, setDataTopVolume] = useState([])
    const [dataTopFrg, setDataTopFrg] = useState([])
    const [dataTopInc, setDataTopInc] = useState([])
    const [dataTopDec, setDataTopDec] = useState([])

    const [sort, setSort] = useState('')
    const sortRef = useRef('')

    const [, updateState] = useState()
    const forceUpdate = useCallback(() => updateState({}), [])

    useEffect(() => {
        tabY.current = scrollY.interpolate({
            inputRange: [0, height, height + 1],
            outputRange: [0, 0, 1],
        })
        InteractionManager.runAfterInteractions(() => {
            forceUpdate()
        })
    }, [height, scrollY])

    useEffect(() => {
        if (activeOtpRef.current === '1D') {
            setDataTopValue([...glb_sv.lastDataMarketTop.TOP_VAL_UP])
            setDataTopVolume([...glb_sv.lastDataMarketTop.TOP_QTY_UP])
            setDataTopFrg([...glb_sv.lastDataMarketTop.FRG_VAL_UP])
            setDataTopInc([...glb_sv.lastDataMarketTop.TOP_PRI_UP])
            setDataTopDec([...glb_sv.lastDataMarketTop.TOP_PRI_DOWN])
            setLoading(false)
        } else {
            setDataTopValue([])
            setDataTopVolume([])
            setDataTopFrg([])
            setDataTopInc([])
            setDataTopDec([])
            if (listTimeHis.includes(activeOtpRef.current)) {
                const index = active.includes('HSX') ? '01' : active.includes('HNXUpcomIndex') ? '05' : '03'
                let typee = 'TU'
                if (glb_sv.TYPE_TOP_MARKET === 'TOP_PRI_DOWN') typee = 'TD'
                if (glb_sv.TYPE_TOP_MARKET === 'TOP_QTY_UP') typee = 'TV'
                if (glb_sv.TYPE_TOP_MARKET === 'TOP_VAL_UP') typee = 'TA'
                if (glb_sv.TYPE_TOP_MARKET === 'FRG_VAL_UP') typee = 'FA'
                if (glb_sv.dataHisMrktop[activeOtpRef.current][glb_sv.TYPE_TOP_MARKET + index]) {
                    const newData = glb_sv.dataHisMrktop[activeOtpRef.current][glb_sv.TYPE_TOP_MARKET + index].map((item) => {
                        return {
                            S: item.c3,
                            C: item.c6 * 1000,
                            CHGR: item.c11,
                            TVOL: item.c8,
                            TVAL: item.c9,
                            O: item.c4 * 1000,
                            FBA: item.c16 * 1e9,
                            FSA: item.c17 * 1e9,
                        }
                    })
                    if (glb_sv.TYPE_TOP_MARKET === 'TOP_VAL_UP') setDataTopValue(newData)
                    if (glb_sv.TYPE_TOP_MARKET === 'TOP_QTY_UP') setDataTopVolume(newData)
                    if (glb_sv.TYPE_TOP_MARKET === 'FRG_VAL_UP') setDataTopFrg(newData)
                    if (glb_sv.TYPE_TOP_MARKET === 'TOP_PRI_UP') setDataTopInc(newData)
                    if (glb_sv.TYPE_TOP_MARKET === 'TOP_PRI_DOWN') setDataTopDec(newData)
                    setLoading(false)
                    return
                }
                const inval = ['1', index, activeOtpRef.current, typee, '-1']
                sendRequest(ServiceInfo.GET_MARKET_TOP, inval, handleGetMarketTop, true, handleGetMarketTopTimeout)
                dataRef.current = []
            }
        }

        const eventMarket = glb_sv.eventMarket.subscribe((msg) => {
            if (msg.type === eventList.MKT_TOP && glb_sv.TYPE_TOP_MARKET === msg.TOP) {
                if (activeOtpRef.current !== '1D') return
                const newData = msg.ITEMS
                if (glb_sv.TYPE_TOP_MARKET === 'TOP_VAL_UP') setDataTopValue(newData)
                if (glb_sv.TYPE_TOP_MARKET === 'TOP_QTY_UP') setDataTopVolume(newData)
                if (glb_sv.TYPE_TOP_MARKET === 'FRG_VAL_UP') setDataTopFrg(newData)
                if (glb_sv.TYPE_TOP_MARKET === 'TOP_PRI_UP') setDataTopInc(newData)
                if (glb_sv.TYPE_TOP_MARKET === 'TOP_PRI_DOWN') setDataTopDec(newData)
                setLoading(false)
            }

            if (msg.type === eventList.RECONNECT_MARKET) {
                if (activeOtpRef.current === '1D') {
                } else {
                    setDataTopValue([])
                    setDataTopVolume([])
                    setDataTopFrg([])
                    setDataTopInc([])
                    setDataTopDec([])
                    if (listTimeHis.includes(activeOtpRef.current)) {
                        const index = active.includes('HSX') ? '01' : active.includes('HNXUpcomIndex') ? '05' : '03'
                        let typee = 'TU'
                        if (glb_sv.TYPE_TOP_MARKET === 'TOP_PRI_DOWN') typee = 'TD'
                        if (glb_sv.TYPE_TOP_MARKET === 'TOP_QTY_UP') typee = 'TV'
                        if (glb_sv.TYPE_TOP_MARKET === 'TOP_VAL_UP') typee = 'TA'
                        if (glb_sv.TYPE_TOP_MARKET === 'FRG_VAL_UP') typee = 'FA'
                        if (glb_sv.dataHisMrktop[activeOtpRef.current][type + index]) {
                            const newData = glb_sv.dataHisMrktop[activeOtpRef.current][type + index].map((item) => {
                                return {
                                    S: item.c3,
                                    C: item.c6 * 1000,
                                    CHGR: item.c11,
                                    TVOL: item.c8,
                                    TVAL: item.c9,
                                    O: item.c4 * 1000,
                                    FBA: item.c16 * 10e9,
                                    FSA: item.c17 * 10e9,
                                }
                            })
                            if (glb_sv.TYPE_TOP_MARKET === 'TOP_VAL_UP') setDataTopValue(newData)
                            if (glb_sv.TYPE_TOP_MARKET === 'TOP_QTY_UP') setDataTopVolume(newData)
                            if (glb_sv.TYPE_TOP_MARKET === 'FRG_VAL_UP') setDataTopFrg(newData)
                            if (glb_sv.TYPE_TOP_MARKET === 'TOP_PRI_UP') setDataTopInc(newData)
                            if (glb_sv.TYPE_TOP_MARKET === 'TOP_PRI_DOWN') setDataTopDec(newData)
                            return
                        }
                        const inval = ['1', index, activeOtpRef.current, typee, '-1']
                        sendRequest(ServiceInfo.GET_MARKET_TOP, inval, handleGetMarketTop, true, handleGetMarketTopTimeout)
                        dataRef.current = []
                    }
                }
            }

            if (msg.type === eventList.RESET_DATA) {
                setDataTopValue([])
                setDataTopVolume([])
                setDataTopFrg([])
                setDataTopInc([])
                setDataTopDec([])
            }
        })

        return () => {
            eventMarket.unsubscribe()
        }
    }, [active])

    const changeOtpion = useCallback((value) => {
        setActiveOtp(value)
        setDataTopValue([])
        setDataTopVolume([])
        setDataTopFrg([])
        setDataTopInc([])
        setDataTopDec([])
        setLoading(true)
        handleScrollTop()

        activeOtpRef.current = value
        if (timeoutChangeTabRef.current) clearTimeout(timeoutChangeTabRef.current)
        timeoutChangeTabRef.current = setTimeout(() => {
            if (value === '1D') {
                setDataTopValue(glb_sv.lastDataMarketTop.TOP_VAL_UP)
                setDataTopVolume(glb_sv.lastDataMarketTop.TOP_QTY_UP)
                setDataTopFrg(glb_sv.lastDataMarketTop.FRG_VAL_UP)
                setDataTopInc(glb_sv.lastDataMarketTop.TOP_PRI_UP)
                setDataTopDec(glb_sv.lastDataMarketTop.TOP_PRI_DOWN)
                if (active.includes('HNXUpcomIndex')) {
                    subcribeFunctStream('SUB', [glb_sv.TYPE_TOP_MARKET], ['UPC'])
                } else if (active.includes('HNX')) {
                    subcribeFunctStream('SUB', [glb_sv.TYPE_TOP_MARKET], ['HNX'])
                } else {
                    subcribeFunctStream('SUB', [glb_sv.TYPE_TOP_MARKET], ['HSX'])
                }
            } else {
                if (active.includes('HNXUpcomIndex')) {
                    subcribeFunctStream('UNSUB', [glb_sv.TYPE_TOP_MARKET], ['UPC'])
                } else if (active.includes('HNX')) {
                    subcribeFunctStream('UNSUB', [glb_sv.TYPE_TOP_MARKET], ['HNX'])
                } else {
                    subcribeFunctStream('UNSUB', [glb_sv.TYPE_TOP_MARKET], ['HSX'])
                }
                const index = active.includes('HSX') ? '01' : active.includes('HNXUpcomIndex') ? '05' : '03'
                let typee = 'TU'
                if (glb_sv.TYPE_TOP_MARKET === 'TOP_PRI_DOWN') typee = 'TD'
                if (glb_sv.TYPE_TOP_MARKET === 'TOP_QTY_UP') typee = 'TV'
                if (glb_sv.TYPE_TOP_MARKET === 'TOP_VAL_UP') typee = 'TA'
                if (glb_sv.TYPE_TOP_MARKET === 'FRG_VAL_UP') typee = 'FA'
                if (glb_sv.dataHisMrktop[value][glb_sv.TYPE_TOP_MARKET + index]) {
                    const newData = glb_sv.dataHisMrktop[value][glb_sv.TYPE_TOP_MARKET + index].map((item) => {
                        return {
                            S: item.c3,
                            C: item.c6 * 1000,
                            CHGR: item.c11,
                            TVOL: item.c8,
                            TVAL: item.c9,
                            O: item.c4 * 1000,
                            FBA: item.c16 * 1e9,
                            FSA: item.c17 * 1e9,
                        }
                    })
                    if (glb_sv.TYPE_TOP_MARKET === 'TOP_VAL_UP') setDataTopValue(newData)
                    if (glb_sv.TYPE_TOP_MARKET === 'TOP_QTY_UP') setDataTopVolume(newData)
                    if (glb_sv.TYPE_TOP_MARKET === 'FRG_VAL_UP') setDataTopFrg(newData)
                    if (glb_sv.TYPE_TOP_MARKET === 'TOP_PRI_UP') setDataTopInc(newData)
                    if (glb_sv.TYPE_TOP_MARKET === 'TOP_PRI_DOWN') setDataTopDec(newData)
                    return
                }
                const inval = ['1', index, value, typee, '-1']
                sendRequest(ServiceInfo.GET_MARKET_TOP, inval, handleGetMarketTop, true, handleGetMarketTopTimeout)
                dataRef.current = []
            }
        }, 500)
    }, [])

    const handleGetMarketTopTimeout = () => {
        setLoading(false)
    }

    const handleGetMarketTop = (reqInfoMap, message) => {
        setLoading(false)
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) { }
            dataRef.current = dataRef.current.concat(jsondata)
            if (Number(message.Packet) <= 0) {
                hanldeDataHistoryMarketTop(dataRef.current)
            }
        }
    }

    const hanldeDataHistoryMarketTop = (data) => {
        const newData = data.map((item) => {
            return {
                S: item.c3,
                C: item.c6 * 1000,
                CHGR: item.c11,
                TVOL: item.c8,
                TVAL: item.c9,
                O: item.c4 * 1000,
                FBA: item.c16 * 1e9,
                FSA: item.c17 * 1e9,
            }
        })
        if (glb_sv.TYPE_TOP_MARKET === 'TOP_VAL_UP') setDataTopValue(newData)
        if (glb_sv.TYPE_TOP_MARKET === 'TOP_QTY_UP') setDataTopVolume(newData)
        if (glb_sv.TYPE_TOP_MARKET === 'FRG_VAL_UP') setDataTopFrg(newData)
        if (glb_sv.TYPE_TOP_MARKET === 'TOP_PRI_UP') setDataTopInc(newData)
        if (glb_sv.TYPE_TOP_MARKET === 'TOP_PRI_DOWN') setDataTopDec(newData)
        const index = active.includes('HSX') ? '01' : active.includes('HNXUpcomIndex') ? '05' : '03'
        glb_sv.dataHisMrktop[activeOtpRef.current][glb_sv.TYPE_TOP_MARKET + index] = data.slice()
    }

    const changeTab = ({ i }) => {
        InteractionManager.runAfterInteractions(() => {
            let tab = 'TOP_VAL_UP'
            if (i === 1) tab = 'TOP_QTY_UP'
            if (i === 2) tab = 'FRG_VAL_UP'
            if (i === 3) tab = 'TOP_PRI_UP'
            if (i === 4) tab = 'TOP_PRI_DOWN'
            if (glb_sv.TYPE_TOP_MARKET === tab) return
            handleScrollTop()

            if (active.includes('HNXUpcomIndex')) {
                subcribeFunctStream('UNSUB', [glb_sv.TYPE_TOP_MARKET], ['UPC'])
            } else if (active.includes('HNX')) {
                subcribeFunctStream('UNSUB', [glb_sv.TYPE_TOP_MARKET], ['HNX'])
            } else {
                subcribeFunctStream('UNSUB', [glb_sv.TYPE_TOP_MARKET], ['HSX'])
            }

            glb_sv.TYPE_TOP_MARKET = tab
            setType(tab)

            setLoading(true)
            SyncStorage.set(STORE_KEY.TYPE_TOP_MARKET, tab)

            if (activeOtpRef.current === '1D') {
                if (active.includes('HNXUpcomIndex')) {
                    subcribeFunctStream('SUB', [glb_sv.TYPE_TOP_MARKET], ['UPC'])
                } else if (active.includes('HNX')) {
                    subcribeFunctStream('SUB', [glb_sv.TYPE_TOP_MARKET], ['HNX'])
                } else {
                    subcribeFunctStream('SUB', [glb_sv.TYPE_TOP_MARKET], ['HSX'])
                }
                setLoading(false)
            } else {
                setDataTopValue([])
                setDataTopVolume([])
                setDataTopFrg([])
                setDataTopInc([])
                setDataTopDec([])
                if (listTimeHis.includes(activeOtpRef.current)) {
                    const index = active.includes('HSX') ? '01' : active.includes('HNXUpcomIndex') ? '05' : '03'
                    let typee = 'TU'
                    if (tab === 'TOP_PRI_DOWN') typee = 'TD'
                    if (tab === 'TOP_QTY_UP') typee = 'TV'
                    if (tab === 'TOP_VAL_UP') typee = 'TA'
                    if (tab === 'FRG_VAL_UP') typee = 'FA'
                    if (glb_sv.dataHisMrktop[activeOtpRef.current][tab + index]) {
                        const newData = glb_sv.dataHisMrktop[activeOtpRef.current][tab + index].map((item) => {
                            return {
                                S: item.c3,
                                C: item.c6 * 1000,
                                CHGR: item.c11,
                                TVOL: item.c8,
                                TVAL: item.c9,
                                O: item.c4 * 1000,
                                FBA: item.c16 * 1e9,
                                FSA: item.c17 * 1e9,
                            }
                        })
                        if (glb_sv.TYPE_TOP_MARKET === 'TOP_VAL_UP') setDataTopValue(newData)
                        if (glb_sv.TYPE_TOP_MARKET === 'TOP_QTY_UP') setDataTopVolume(newData)
                        if (glb_sv.TYPE_TOP_MARKET === 'FRG_VAL_UP') setDataTopFrg(newData)
                        if (glb_sv.TYPE_TOP_MARKET === 'TOP_PRI_UP') setDataTopInc(newData)
                        if (glb_sv.TYPE_TOP_MARKET === 'TOP_PRI_DOWN') setDataTopDec(newData)
                        setLoading(false)
                        return
                    }
                    const inval = ['1', index, activeOtpRef.current, typee, '-1']
                    sendRequest(ServiceInfo.GET_MARKET_TOP, inval, handleGetMarketTop, true, handleGetMarketTopTimeout)
                    dataRef.current = []
                }
            }
        })
    }

    const changeTypeSort = useCallback((changed) => { }, [])

    // -------------------
    const ScrollableTabUI = useMemo(
        () =>
            StyleSheet.flatten([
                {
                    height: 34,
                    elevation: 0,
                    borderBottomColor: styles.DIVIDER__COLOR,
                    borderBottomWidth: 1,
                },
            ]),
        [styles],
    )
    const ScrollableTabUnderLineUI = useMemo(
        () => StyleSheet.flatten([{ backgroundColor: styles.PRIMARY__CONTENT__COLOR, borderRadius: 2, height: 2 }]),
        [styles],
    )
    const ScrollableViewUI = useMemo(
        () =>
            StyleSheet.flatten([
                {
                    backgroundColor: styles.PRIMARY__BG__COLOR,
                    marginTop: dimensions.vertical(12),
                    marginBottom: dimensions.vertical(4),
                    position: 'absolute',
                    top: 34,
                    marginHorizontal: dimensions.moderate(16),
                },
            ]),
        [styles],
    )

    const ViewDividerUI = useMemo(() => StyleSheet.flatten([{ height: 37, backgroundColor: styles.PRIMARY__BG__COLOR }]), [styles])

    const PrimaryBG = { backgroundColor: styles.PRIMARY__BG__COLOR, paddingHorizontal: dimensions.moderate(12) }
    const PrimaryBGActive = useMemo(
        () =>
            StyleSheet.flatten([
                applicationSettings.application_style.tab_style === '2.0'
                    ? { backgroundColor: styles.ACTIVE__TAB__HIGHLIGHT__BG, borderTopRightRadius: 6, borderTopLeftRadius: 6, marginLeft: 2 }
                    : { backgroundColor: styles.PRIMARY__BG__COLOR },
            ]),
        [styles],
    )
    const textStyleUI = useMemo(() => StyleSheet.flatten([{ color: styles.SECOND__CONTENT__COLOR }, [UI.tab]]), [styles])
    const textActiveStyleUI = useMemo(
        () => StyleSheet.flatten([{ color: applicationSettings.application_style.tab_style === '2.0' ? '#fff' : styles.PRIMARY }, [UI.tab]]),
        [styles],
    )

    const AnimatedMemoUI = useMemo(() => StyleSheet.flatten([{ transform: [{ translateY: tabY.current }], zIndex: 1, width: '100%' }]), [tabY.current])

    return (
        <Tabs
            initialPage={page}
            renderTabBar={(props) => (
                <Animated.View style={AnimatedMemoUI}>
                    <ScrollableTab {...props} backgroundColor={styles.PRIMARY__BG__COLOR} style={ScrollableTabUI} underlineStyle={ScrollableTabUnderLineUI} />
                    <View style={ViewDividerUI} />
                    <View style={PrimaryBG}>
                        <HeaderTop activeOtp={activeOtp} changeTypeSort={changeTypeSort} sort="" typeTop={glb_sv.TYPE_TOP_MARKET} />
                    </View>
                    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={ScrollableViewUI}>
                        <OptionsTop active={activeOtp === '1D'} styles={styles} title={'1 ' + t('day')} value="1D" onChange={changeOtpion} />
                        <OptionsTop active={activeOtp === '1W'} styles={styles} title={'5 ' + t('day')} value="1W" onChange={changeOtpion} />
                        <OptionsTop active={activeOtp === '1M'} styles={styles} title={t('one_month')} value="1M" onChange={changeOtpion} />
                        <OptionsTop active={activeOtp === '3M'} styles={styles} title={t('three_month')} value="3M" onChange={changeOtpion} />
                        <OptionsTop active={activeOtp === '6M'} styles={styles} title={t('six_month')} value="6M" onChange={changeOtpion} />
                        <OptionsTop active={activeOtp === '1Y'} styles={styles} title={'1 ' + t('year')} value="1Y" onChange={changeOtpion} />
                        <OptionsTop active={activeOtp === '2Y'} styles={styles} title={'2 ' + t('year')} value="2Y" onChange={changeOtpion} />
                        <OptionsTop active={activeOtp === '3Y'} isLast={true} styles={styles} title={'3 ' + t('year')} value="3Y" onChange={changeOtpion} />
                    </ScrollView>
                </Animated.View>
            )}
            onChangeTab={(tab) => changeTab(tab)}
        >
            <Tab
                activeTabStyle={PrimaryBGActive}
                activeTextStyle={textActiveStyleUI}
                heading={t('top_10_stocks_value_trade')}
                tabStyle={PrimaryBG}
                textStyle={textStyleUI}
            >
                <DataTabsMemo
                    activeOtp={activeOtp}
                    data={dataTopValue}
                    fractionPrice={fractionPrice}
                    navigateStockInfo={navigateStockInfo}
                    styles={styles}
                    type={type}
                />
            </Tab>
            <Tab
                activeTabStyle={PrimaryBGActive}
                activeTextStyle={textActiveStyleUI}
                heading={t('top_10_stocks_shares_trade')}
                tabStyle={PrimaryBG}
                textStyle={textStyleUI}
            >
                <DataTabsMemo
                    activeOtp={activeOtp}
                    data={dataTopVolume}
                    fractionPrice={fractionPrice}
                    navigateStockInfo={navigateStockInfo}
                    styles={styles}
                    type={type}
                />
            </Tab>
            <Tab activeTabStyle={PrimaryBGActive} activeTextStyle={textActiveStyleUI} heading={t('top_value_frg')} tabStyle={PrimaryBG} textStyle={textStyleUI}>
                <DataTabsMemo
                    activeOtp={activeOtp}
                    data={dataTopFrg}
                    fractionPrice={fractionPrice}
                    navigateStockInfo={navigateStockInfo}
                    styles={styles}
                    type={type}
                    typeTop="FRG_VAL_UP"
                />
            </Tab>
            <Tab
                activeTabStyle={PrimaryBGActive}
                activeTextStyle={textActiveStyleUI}
                heading={t('top_10_stocks_incre')}
                tabStyle={PrimaryBG}
                textStyle={textStyleUI}
            >
                <DataTabsMemo
                    activeOtp={activeOtp}
                    data={dataTopInc}
                    fractionPrice={fractionPrice}
                    navigateStockInfo={navigateStockInfo}
                    styles={styles}
                    type={type}
                />
            </Tab>

            <Tab
                activeTabStyle={PrimaryBGActive}
                activeTextStyle={textActiveStyleUI}
                heading={t('top_10_stocks_decre')}
                tabStyle={PrimaryBG}
                textStyle={textStyleUI}
            >
                <DataTabsMemo activeOtp={activeOtp} data={dataTopDec} navigateStockInfo={navigateStockInfo} type={type} />
            </Tab>
        </Tabs>
    )
}

// const DataTabs = memo(DataTabsMemo)
const DataTabsMemo = memo(({ data, navigateStockInfo, activeOtp, type, typeTop }) => {
    const { styles, fractionPrice } = useContext(StoreContext)

    const renderItem = useCallback(({ item }) => {
        return (
            <RowTop
                activeOtp={activeOtp}
                item={item}
                navigateStockInfo={navigateStockInfo}
                ratioValue={FormatNumber(item.CHGR, 2)} // col 2
                styles={styles}
                title={item.S} // col 1
                typeTop={typeTop}
                value={
                    typeTop === 'FRG_VAL_UP'
                        ? FormatNumber(item.FSA, 2, 0, 'short') // col 4
                        : item.C === 777777710000
                            ? 'ATO'
                            : item.C === 777777720000
                                ? 'ATC'
                                : fractionPrice
                                    ? FormatNumber(item.C / 1000, 2, 1)
                                    : FormatNumber(item.C, 0, 1)
                }
                value_market={
                    typeTop === 'FRG_VAL_UP'
                        ? FormatNumber(item.FBA - item.FSA, 2, 0, 'short') // col 5
                        : type !== 'TOP_VAL_UP'
                            ? FormatNumber(item.TVOL, 0, 1, 'short')
                            : FormatNumber(item.TVAL, 0, 1, 'short')
                }
                valueCol3={
                    typeTop === 'FRG_VAL_UP'
                        ? FormatNumber(item.FBA, 2, 0, 'short') // col 3
                        : fractionPrice
                            ? FormatNumber(item.O / 1000, 2, 1)
                            : FormatNumber(item.O, 0, 1)
                }
            />
        )
    })

    const FlatListWrapUI = useMemo(
        () => StyleSheet.flatten([{ backgroundColor: styles.PRIMARY__BG__COLOR, flex: 1, paddingHorizontal: dimensions.moderate(16), minHeight: 400 }]),
        [styles],
    )

    return (
        <View style={FlatListWrapUI}>
            <FlatList data={data} keyExtractor={(item, index) => type + item.S + index} renderItem={renderItem} scrollEnabled={false} />
        </View>
    )
})

const UI = StyleSheet.create({
    tab: {
        fontSize: fontSizes.small,
        fontWeight: fontWeights.medium,
        marginLeft: 0,
        marginRight: 0,
    },
})
export default memo(TopMaket)
