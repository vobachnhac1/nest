import React, { useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Pressable, StyleSheet, View } from 'react-native'

import ArrowRight from '../../../assets/images/common/ic_arrow_right.svg'
import { CustomFloatInput } from '../../../basic-components'
import ModalSelection from '../../../components/list-selections'
import { ButtonCustom, RowTitleGroup } from '../../../components/trading-component'
import { useUpdateEffect } from '../../../hoc'
import { StoreContext } from '../../../store'
import { StoreTrading } from '../../../store-trading'
import { dimensions as dm } from '../../../styles'
import { eventList, glb_sv, reqFunct, sendRequest } from '../../../utils'
import FormatNumber from '../../../utils/formatNumber/FormatNumber'

// Khai báo ServiceInfo (nếu có)
const ServiceInfo = {
    getListBankTran: {
        reqFunct: reqFunct.GET_LIST_BANK_TRANS, //Lấy DS ngân hàng chuyển
        WorkerName: 'FOSqAccount',
        ServiceName: 'FOSqAccount_Common',
        ClientSentTime: '0',
        Operation: 'Q',
        // TestInput: ["07", "%"]
    },
    getListActReceive: {
        reqFunct: reqFunct.GET_LIST_ACT_RECEIVE, // Lấy DS số tài khoản hưởng (CTCK)
        WorkerName: 'FOSqCash',
        ServiceName: 'FOSqCash_Common',
        ClientSentTime: '0',
        Operation: 'Q',
        // TestInput: ["02", "00"]
    },
}
// Khai báo component
const StepTwo = ({
    navigation,
    bankTransfer,
    setBankTransfer,
    bankTransferAct,
    setBankTransferAct,
    actReceive,
    setActReceive,
    bankReceive,
    setBankReceive,
    amoutTransfer,
    setAmoutTransfer,
    switchStep,
    errCtrl,
    setErrCtrl,
    _validateValue,
}) => {
    const { t } = useTranslation()
    const { styles } = useContext(StoreContext)
    const { userInfo } = useContext(StoreTrading)
    const [isOpenModalSelection, setIsOpenModalSelection] = useState(false)
    const [infoSelection, setInfoSelection] = useState({
        type: '',
        callback: () => {},
    })

    // -------------------------------------------   Dùng useEffect get các dữ liệu cần thiết còn thiếu
    useEffect(() => {
        if (glb_sv.ListBankTrans.length === 0) {
            getListBankTran()
        }
        if (glb_sv.ListBankReceive.length === 0) {
            getListActReceive()
        }

        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.LOGIN_SUCCESS) {
                // reCall service FOSq
                if (glb_sv.ListBankTrans.length === 0) {
                    getListBankTran()
                }
                if (glb_sv.ListBankReceive.length === 0) {
                    getListActReceive()
                }
            }
        })

        return () => {
            commonEvent.unsubscribe()
        }
    }, [])
    useUpdateEffect(() => {
        _validateValue(0)
    }, [bankTransfer])
    useUpdateEffect(() => {
        _validateValue(2)
    }, [actReceive])
    useUpdateEffect(() => {
        _validateValue(3)
    }, [bankReceive])
    useUpdateEffect(() => {
        _validateValue(4)
    }, [amoutTransfer])
    // -------------------------------------------   Viết các hàm để set lại bussiness form state. Nên viết đúng một chuẩn duy nhất để dễ control
    const selectBankTransfer = (value) => {
        setBankTransfer(value)
    }
    const selectBankTransferAct = (value) => {
        setBankTransferAct(value)
    }
    const selectActReceive = (value) => {
        setActReceive(value)
        setBankReceive(value)
    }
    const selectBankReceive = (value) => {
        setActReceive(value)
        setBankReceive(value)
    }
    const selectAmoutTransfer = (value) => {
        setAmoutTransfer(value)
    }
    // -------------------------------------------   Khai báo các hàm gửi (request) lên server
    const getListBankTran = () => {
        const inputParams = ['07', '%']
        sendRequest(ServiceInfo.getListBankTran, inputParams, handleGetListBankTran)
    }
    const getListActReceive = () => {
        const inputParams = ['02', userInfo.actn_curr]
        sendRequest(ServiceInfo.getListActReceive, inputParams, handleGetListActReceive)
    }
    // -------------------------------------------   Khai báo các hàm nhận (handle respone) dữ liệu từ server

    const handleGetListBankTran = (reqInfoMap, message) => {
        console.log('getListBankTran', reqInfoMap, message)
        // -- process after get result --
        let ListBankTranTemp = []
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata
            try {
                jsondata = JSON.parse(message.Data)
            } catch (err) {
                // glb_sv.logMessage(err);
                jsondata = []
            }
            ListBankTranTemp = ListBankTranTemp.concat(jsondata)
            if (Number(message.Packet) <= 0) {
                const bankTransferList = ListBankTranTemp.map((item) => {
                    const label = item.c1
                    const value = item
                    return { label, value }
                })
                glb_sv.ListBankTrans = bankTransferList
            }
        }
    }
    // ----------------------------------------------------

    const handleGetListActReceive = (reqInfoMap, message) => {
        // -- process after get result --
        let ListBankReceiveTemp = []
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata
            try {
                jsondata = JSON.parse(message.Data)
            } catch (err) {
                jsondata = []
            }
            ListBankReceiveTemp = ListBankReceiveTemp.concat(jsondata)
            if (Number(message.Packet) <= 0) {
                const bankSecList = ListBankReceiveTemp.map((item) => {
                    const label = item.c2 + ' - ' + item.c1
                    const value = item
                    return { label, value }
                })
                glb_sv.ListBankReceive = bankSecList
            }
        }
    }

    return (
        <View>
            <View style={{ flex: 1, marginRight: dm.halfIndent }}>
                <View style={[UI.GroupInput, { borderColor: styles.PRIMARY__BORDER__COLOR }]}>
                    <RowTitleGroup text={t('trans_sub_account')} type="group" />
                    <Pressable
                        onPress={() => {
                            setInfoSelection({ type: 'PICK_BANK_TRANSFER', callback: selectBankTransfer })
                            setIsOpenModalSelection(true)
                        }}
                    >
                        <View pointerEvents="none" style={UI.RowInput}>
                            <CustomFloatInput
                                animationDuration={100}
                                editable={false}
                                errCtrl={t(errCtrl[0])}
                                label={t('select_bank_from')}
                                maxLength={35}
                                rightComponent={
                                    <ArrowRight style={{ color: styles.PRIMARY__CONTENT__COLOR, marginVertical: dm.vertical(22), marginRight: 10 }} />
                                }
                                value={bankTransfer?.label}
                            />
                        </View>
                    </Pressable>

                    <View style={UI.RowInput}>
                        <CustomFloatInput
                            animationDuration={100}
                            errCtrl={errCtrl[1]}
                            label={t('input_transfer_account_number')}
                            maxLength={35}
                            placeholderTextColor={styles.PLACEHODLER__COLOR}
                            value={bankTransferAct}
                            onChangeText={(bankTransferAct) => selectBankTransferAct(bankTransferAct)}
                        />
                    </View>
                    <RowTitleGroup text={t('receive_sub_account')} type="group" />
                    <Pressable
                        onPress={() => {
                            setInfoSelection({ type: 'PICK_BANK_RECEIVE', callback: selectBankReceive })
                            setIsOpenModalSelection(true)
                        }}
                    >
                        <View pointerEvents="none" style={UI.RowInput}>
                            <CustomFloatInput
                                animationDuration={10}
                                errCtrl={errCtrl[2]}
                                label={t('chose_bank_account')}
                                maxLength={35}
                                rightComponent={
                                    <ArrowRight style={{ color: styles.PRIMARY__CONTENT__COLOR, marginVertical: dm.vertical(22), marginRight: 10 }} />
                                }
                                value={bankReceive?.value?.c2}
                            />
                        </View>
                    </Pressable>

                    <Pressable
                        onPress={() => {
                            setInfoSelection({ type: 'PICK_ACCOUNT_RECEIVE', callback: selectActReceive })
                            setIsOpenModalSelection(true)
                        }}
                    >
                        <View pointerEvents="none" style={UI.RowInput}>
                            <CustomFloatInput
                                animationDuration={10}
                                errCtrl={errCtrl[3]}
                                label={t('choose_heir_bank')}
                                maxLength={35}
                                rightComponent={
                                    <ArrowRight style={{ color: styles.PRIMARY__CONTENT__COLOR, marginVertical: dm.vertical(22), marginRight: 10 }} />
                                }
                                value={actReceive?.value?.c1}
                            />
                        </View>
                    </Pressable>
                    <RowTitleGroup text={t('transc_amount_cash')} type="group" />
                    <View style={UI.RowInput}>
                        <CustomFloatInput
                            animationDuration={100}
                            errCtrl={errCtrl[4]}
                            keyboardType="number-pad"
                            label={t('deposit_amount')}
                            placeholderTextColor={styles.PLACEHODLER__COLOR}
                            value={FormatNumber(amoutTransfer) === '0' ? '' : FormatNumber(amoutTransfer)}
                            onChangeText={(amout) => selectAmoutTransfer(glb_sv.filterNumber(amout))}
                        />
                    </View>
                </View>
                <ButtonCustom text={t('common_confirm')} type="confirm" onPress={() => switchStep.onFinish()} />
                <ButtonCustom last text={t('common_back')} type="back" onPress={() => switchStep.prev()} />
            </View>
            <ModalSelection
                actionType={infoSelection.type}
                getSelectValue={infoSelection.callback}
                isOpen={isOpenModalSelection}
                setIsOpen={setIsOpenModalSelection}
            />
        </View>
    )
}
const UI = StyleSheet.create({
    GroupInput: {
        marginVertical: dm.halfVerticalIndent,
        paddingHorizontal: dm.halfIndent,
    },
    RowInput: {
        marginLeft: dm.moderate(8),
        marginVertical: dm.vertical(8),
    },
})
export default StepTwo
