const COLORS = {
    TRANSPARENT: 'transparent',
    GREEN: '#2ecc71',
    BLACK_30: 'rgba(0,0,0,0.3)',
    WHITE: '#ffffff',
}

export default COLORS
