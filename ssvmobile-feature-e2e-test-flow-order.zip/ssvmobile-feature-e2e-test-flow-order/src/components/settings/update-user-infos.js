import React, { useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Keyboard, Pressable, StyleSheet, TouchableOpacity, View } from 'react-native'
import Modal from 'react-native-modal'
import DateTimePickerModal from 'react-native-modal-datetime-picker'
import ToastGlobal from 'react-native-toast-message'
import moment from 'moment'
import { Container, Content } from 'native-base'

import CONFIG, { activeCode } from '../../assets/config'
import { CustomFloatInput, Text } from '../../basic-components'
import HeaderComponent from '../../components/header'
import { ButtonCustom } from '../../components/trading-component'
import { allowCompanyRender } from '../../hoc'
import ModalOtpInput from '../../layouts/login/modal-authen-otp-acc-holder'
import { StoreContext } from '../../store'
import { dimensions, dimensions as dm, fontSizes, fontSizes as fs, fontWeights as fw, IconSvg } from '../../styles'
import { dataCryption, reqFunct, sendRequest } from '../../utils'

const ServiceInfo = {
    UPDATE_INFO_REQUEST: {
        reqFunct: reqFunct.UPDATE_INFO_REQUEST,
        WorkerName: 'FOSxID02',
        ServiceName: 'FOSxID02_UserInformation',
        ClientSentTime: '0',
        Operation: 'U',
    },
}

const initErrCtrl = [
    {
        error: false,
        message: 'common_plz_input_full_name',
    },
    {
        error: false,
        message: 'common_plz_input_your_home_address',
    },
    {
        error: false,
        message: 'common_plz_input_your_email_address',
    },
    {
        error: false,
        message: 'common_plz_input_your_mobile_number',
    },
    {
        error: false,
        message: 'common_plz_input_your_birthday',
    },
]

const genderList = [
    { value: 'M', name: 'common_male' },
    { value: 'F', name: 'common_female' },
    { value: 'O', name: 'common_other' },
]

function UpdateUserInfo({ navigation, route }) {
    const { userInfoData, updateInfoCallback } = route.params

    const { styles, theme, language } = useContext(StoreContext)
    const { t } = useTranslation()

    // const [originFullName, setOriginFullName] = useState(userInfoData.c0)
    // const [originBirthday, setOriginBirthday] = useState(userInfoData.c5.trim()) // String with format YYYYMMDD
    // const [originGender, setOriginGender] = useState(userInfoData.c3.trim()) // Single code M,F,O
    // const [originAddress, setOriginAddress] = useState(userInfoData.c22)
    // const [originEmail, setOriginEmail] = useState(userInfoData.c32.trim())
    // const [originPhone, setOriginPhone] = useState(userInfoData.c35.trim())

    const [fullName, setFullName] = useState('')
    const [birthday, setBirthday] = useState('') // String with format YYYYMMDD
    const [gender, setGender] = useState('') // Single code M,F,O
    const [address, setAddress] = useState()
    const [email, setEmail] = useState('')
    const [phone, setPhone] = useState('')

    const [modalBirthday, setModalBirthday] = useState(false)
    const [visibleGender, setVisibleGender] = useState(false)

    useEffect(() => {
        // console.log('userInfoData', userInfoData)
        if (allowCompanyRender(['888', '061'])) {
            setFullName(userInfoData.c0)
            setBirthday(userInfoData.c8?.trim())
            setGender(userInfoData.c7)
            setAddress(userInfoData.c11)
            setEmail(userInfoData.c12)
            setPhone(userInfoData.c13)
        } else {
            setFullName(userInfoData.c0)
            setBirthday(userInfoData.c5?.trim())
            setGender(userInfoData.c3)
            setAddress(userInfoData.c22)
            setEmail(userInfoData.c32)
            setPhone(userInfoData.c35)
        }
    }, [userInfoData])

    // OTP
    const [spinner, setSpinner] = useState(false)
    const [otpMessage, setOtpMessage] = useState('')
    const [timeOTP, setTimeOTP] = useState(30)
    const [visibleModalAuthen, setVisibleModalAuthen] = useState(false)
    const [otpCode, setOtpCode] = useState('')
    const is_user_information_update = !!CONFIG[activeCode].application_style.is_user_information_update

    const hideDatePicker = () => {
        setModalBirthday(false)
    }

    const onInfosUpdateConfirm = () => {
        console.log('onInfosUpdateConfirm')

        if (fullName?.trim() === '' && userInfoData.c1 === 'Y') {
            ToastGlobal.show({
                type: 'warning',
                text2: t('common_plz_input_full_name'),
            })
        } else if (birthday === '' && userInfoData.c8 === 'Y') {
            ToastGlobal.show({
                type: 'warning',
                text2: t('common_plz_input_your_birthday'),
            })
        } else if (gender === '' && userInfoData.c4 === 'Y') {
            ToastGlobal.show({
                type: 'warning',
                text2: t('common_select_your_gender'),
            })
        } else if (address?.trim() === '' && userInfoData.c23 === 'Y') {
            ToastGlobal.show({
                type: 'warning',
                text2: t('common_plz_input_your_home_address'),
            })
        } else if (email?.trim() === '' && userInfoData.c33 === 'Y') {
            ToastGlobal.show({
                type: 'warning',
                text2: t('common_plz_input_your_email_address'),
            })
        } else if (phone?.trim() === '' && userInfoData.c36 === 'Y') {
            ToastGlobal.show({
                type: 'warning',
                text2: t('common_plz_input_your_mobile_number'),
            })
        } else if (phone?.trim().length !== 10 && userInfoData.c36 === 'Y') {
            ToastGlobal.show({
                type: 'warning',
                text2: t('common_plz_mobile_number_length'),
            })
        } else {
            setTimeOTP(0)
            sendUpdateInfosRequest('')
        }
    }

    const sendUpdateInfosRequest = (otp) => {
        const inputParams = ['info', otp ? dataCryption.encryptString(otp) : '']

        // if (fullName !== originFullName) {
        //     inputParams.push('name')
        //     inputParams.push(fullName)
        // }

        // if (birthday !== originBirthday) {
        //     inputParams.push('bir_day')
        //     inputParams.push(moment(birthday).format('YYYYMMDD'))
        // }

        // if (gender !== originGender) {
        //     inputParams.push('sex')
        //     inputParams.push(gender)
        // }

        // if (email !== originEmail) {
        //     inputParams.push('email')
        //     inputParams.push(email)
        // }

        // if (phone !== originPhone) {
        //     inputParams.push('phone')
        //     inputParams.push(phone)
        // }

        // if (address !== originAddress) {
        //     inputParams.push('contact_addr')
        //     inputParams.push(address)
        // }

        console.log('sendUpdateInfosRequest inputParams: ', inputParams)
        sendRequest(ServiceInfo.UPDATE_INFO_REQUEST, inputParams, handleInfosUpdate)
    }

    // -----------------------------------------
    const otpAuthenCallBack = (otpCode) => {
        console.log('otpAuthenCallBack otpCode: ', otpCode)
        sendUpdateInfosRequest(otpCode)
    }

    // -----------------------------------------
    const handleInfosUpdate = (reqInfoMap, message) => {
        const msgCode = message.Code
        if (msgCode === '010021') {
            // sendUpdateInfosRequest('123456')
            try {
                const jsondata = message.Data ? JSON.parse(message.Data) : []
                if (jsondata) {
                    const time = jsondata[0].c0
                    setTimeOTP(Number(time))
                }
                setVisibleModalAuthen(true)
            } catch (err) {
                console.log(err)
            }
        } else {
            if (Number(message.Result) === 0) {
                ToastGlobal.show({
                    type: 'warning',
                    text2: message.Message,
                })
            } else {
                ToastGlobal.show({
                    type: 'success',
                    text2: message.Message,
                })

                navigation.goBack()
                updateInfoCallback(true)
            }
        }
    }

    console.log('userInfoData', userInfoData)

    return (
        <Container>
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft={true}
                navigation={navigation}
                title={t('update_info')}
                titleAlgin="flex-start"
            />

            <Content keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false} style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
                <View style={{ paddingHorizontal: dm.moderate(16) }}>
                    <CustomFloatInput
                        editable={false}
                        label={t('customer_fullname')}
                        maxLength={50}
                        numberOfLines={1}
                        placeholderTextColor={styles.PLACEHODLER__COLOR}
                        staticLabel
                        value={fullName}
                        onChangeText={(value) => setFullName(value)}
                    />
                </View>

                <Pressable
                    disabled={true}
                    onPress={() => {
                        if (birthday === '') {
                            setBirthday(moment().subtract(20, 'year').format('YYYYMMDD'))
                        }
                        setModalBirthday(true)
                    }}
                >
                    <View pointerEvents="none" style={{ paddingHorizontal: dm.moderate(16), paddingTop: dm.moderate(8) }}>
                        <CustomFloatInput
                            editable={false}
                            label={t('common_birthday')}
                            placeholderTextColor={styles.PLACEHODLER__COLOR}
                            staticLabel
                            value={birthday === '' ? '' : moment(birthday).format('DD/MM/YYYY')}
                        />
                    </View>
                </Pressable>

                <Pressable
                    disabled={true}
                    onPress={() => {
                        setVisibleGender(true)
                        Keyboard.dismiss()
                    }}
                >
                    <View pointerEvents="none" style={{ paddingHorizontal: dm.moderate(16), paddingTop: dm.moderate(8) }}>
                        <CustomFloatInput
                            editable={false}
                            label={t('gender')}
                            placeholderTextColor={styles.PLACEHODLER__COLOR}
                            staticLabel
                            value={gender === 'M' ? t('common_male') : gender === 'F' ? t('common_female') : gender === 'O' ? t('common_other') : ''}
                        />
                    </View>
                </Pressable>

                <View style={{ paddingHorizontal: dm.moderate(16), paddingTop: dm.moderate(8) }}>
                    <CustomFloatInput
                        editable={false}
                        label={t('contact_address')}
                        maxLength={100}
                        numberOfLines={1}
                        placeholderTextColor={styles.PLACEHODLER__COLOR}
                        staticLabel
                        value={address}
                        onChangeText={(value) => setAddress(value)}
                    />
                </View>

                <View style={{ paddingHorizontal: dm.moderate(16), paddingTop: dm.moderate(8) }}>
                    <CustomFloatInput
                        autoCapitalize="none"
                        editable={false}
                        label={t('email')}
                        maxLength={50}
                        numberOfLines={1}
                        placeholderTextColor={styles.PLACEHODLER__COLOR}
                        staticLabel
                        value={email}
                        onChangeText={(value) => setEmail(value)}
                    />
                </View>

                <View style={{ paddingHorizontal: dm.moderate(16), paddingTop: dm.moderate(8) }}>
                    <CustomFloatInput
                        editable={false}
                        keyboardType="number-pad"
                        label={t('phone')}
                        maxLength={10}
                        numberOfLines={1}
                        placeholderTextColor={styles.PLACEHODLER__COLOR}
                        staticLabel
                        value={phone}
                        onChangeText={(value) => setPhone(value)}
                    />
                </View>

                {/* <ButtonCustom
                    text={t('common_update')}
                    onPress={() => {
                        console.log('userInfoData', userInfoData, is_user_information_update)
                        onInfosUpdateConfirm('')
                    }}
                    disabled={!is_user_information_update}
                    type="confirm"
                /> */}
            </Content>

            <DateTimePickerModal
                cancelTextIOS={t('common_Cancel')}
                confirmTextIOS={t('common_Ok')}
                date={moment(birthday).toDate()}
                headerTextIOS=""
                isDarkModeEnabled={theme.includes('DARK')}
                isVisible={modalBirthday}
                locale={language === 'VI' ? 'vi_VN' : 'en_US'}
                mode="date"
                onCancel={hideDatePicker}
                onConfirm={(value) => {
                    hideDatePicker()
                    setBirthday(value)
                }}
            />

            {visibleGender ? (
                <Modal
                    isVisible={visibleGender}
                    style={UI.bottomModal}
                    useNativeDriver={true}
                    onBackButtonPress={() => setVisibleGender(false)}
                    onBackdropPress={() => setVisibleGender(false)}
                >
                    <View
                        style={{
                            backgroundColor: styles.PRIMARY__BG__COLOR,
                            padding: dimensions.moderate(24),
                            justifyContent: 'flex-start',
                            borderTopLeftRadius: 12,
                            borderTopRightRadius: 12,
                        }}
                    >
                        {genderList.map((item) => (
                            <TouchableOpacity
                                key={item.value}
                                style={UI.row}
                                onPress={() => {
                                    setGender(item.value)
                                    setVisibleGender(false)
                                }}
                            >
                                <IconSvg.CheckboxIcon
                                    active={gender === item.value}
                                    colorActive={styles.PRIMARY}
                                    colorunActive={styles.PRIMARY__CONTENT__COLOR}
                                />
                                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal, marginLeft: dimensions.moderate(12) }}>
                                    {t(item.name)}
                                </Text>
                            </TouchableOpacity>
                        ))}
                    </View>
                </Modal>
            ) : null}

            {timeOTP ? (
                <ModalOtpInput
                    callbackAfterConfirm={otpAuthenCallBack}
                    message={otpMessage}
                    navigation
                    setVisible={setVisibleModalAuthen}
                    time={timeOTP}
                    visible={visibleModalAuthen}
                />
            ) : null}
        </Container>
    )
}

const UI = StyleSheet.create({
    ErrorBorder: {
        borderColor: '#EB5C55',
        borderWidth: 1,
    },
    ErrorStyle: {
        color: '#EB5C55',
        fontSize: fs.smallest,
        fontStyle: 'italic',
        fontWeight: fw.light,
    },
    GroupInput: {
        marginVertical: dm.halfVerticalIndent,
        paddingHorizontal: dm.halfIndent,
    },
    RowInput: {
        marginLeft: dm.moderate(8),
        marginVertical: dm.vertical(8),
    },
    bottomModal: {
        justifyContent: 'flex-end',
        margin: 0,
    },
    row: {
        borderRadius: 12,
        flexDirection: 'row',
        marginTop: dimensions.vertical(12),
    },
})

export default UpdateUserInfo
