import React, { useMemo, useRef } from 'react'
import { Platform, StyleSheet, Text, TextInput, View } from 'react-native'
import Animated, { useAnimatedReaction } from 'react-native-reanimated'

import ProgressCircle from '../components/progressCircle'
import useAnimatedValue from '../hooks/useAnimatedValue'
import type { CircularProgressProps } from '../types'
import COLORS from '../utils/colors'
import styles from './styles'

const AnimatedInput = Animated.createAnimatedComponent(TextInput)

const CircularProgress: React.FC<CircularProgressProps> = ({
    value,
    initialValue = 0,
    circleBackgroundColor = COLORS.TRANSPARENT,
    radius = 60,
    duration = 500,
    delay = 0,
    maxValue = 100,
    strokeLinecap = 'round',
    onAnimationComplete = () => null,
    activeStrokeColor = COLORS.GREEN,
    activeStrokeSecondaryColor = null,
    activeStrokeWidth = 10,
    inActiveStrokeColor = COLORS.BLACK_30,
    inActiveStrokeWidth = 10,
    inActiveStrokeOpacity = 1,
    clockwise = true,
    rotation = 0,
    title = '',
    titleStyle = {},
    titleColor,
    titleFontSize,
    progressValueColor,
    progressValueStyle = {},
    progressValueFontSize,
    valuePrefix = '',
    valueSuffix = '',
    showProgressValue = true,
    subtitle = '',
    subtitleStyle = {},
    subtitleColor,
    subtitleFontSize,
    progressFormatter = (v: number) => {
        'worklet'

        return Math.round(v)
    },
    allowFontScaling = true,
    dashedStrokeConfig = { count: 0, width: 0 },
}: CircularProgressProps) => {
    const { animatedCircleProps, animatedTextProps, progressValue } = useAnimatedValue({
        initialValue,
        radius,
        maxValue,
        clockwise,
        delay,
        value,
        duration,
        onAnimationComplete,
        activeStrokeWidth,
        inActiveStrokeWidth,
        valuePrefix,
        progressFormatter,
        valueSuffix,
    })

    const inputRef = useRef<any>(null)

    if (Platform.OS === 'web') {
        // only run the reaction on web platform.
        useAnimatedReaction(
            () => {
                return progressValue.value
            },
            (data, prevData) => {
                if (data !== prevData && inputRef.current) {
                    inputRef.current.value = data
                }
            },
        )
    }

    const styleProps = useMemo(
        () => ({
            radius,
            rotation,
            progressValueColor,
            progressValueFontSize,
            progressValueStyle,
            activeStrokeColor,
            titleStyle,
            titleColor,
            titleFontSize,
            showProgressValue,
            subtitleColor,
            subtitleFontSize,
            subtitleStyle,
        }),
        [
            radius,
            rotation,
            progressValueColor,
            progressValueFontSize,
            progressValueStyle,
            activeStrokeColor,
            titleStyle,
            titleColor,
            titleFontSize,
            showProgressValue,
            subtitleColor,
            subtitleFontSize,
            subtitleStyle,
        ],
    )

    return (
        <View style={styles(styleProps).container}>
            <View style={styles(styleProps).rotatingContainer}>
                <ProgressCircle
                    activeStrokeColor={activeStrokeColor}
                    activeStrokeSecondaryColor={activeStrokeSecondaryColor}
                    activeStrokeWidth={activeStrokeWidth}
                    animatedCircleProps={animatedCircleProps}
                    circleBackgroundColor={circleBackgroundColor}
                    dashedStrokeConfig={dashedStrokeConfig}
                    inActiveStrokeColor={inActiveStrokeColor}
                    inActiveStrokeOpacity={inActiveStrokeOpacity}
                    inActiveStrokeWidth={inActiveStrokeWidth}
                    radius={radius}
                    strokeLinecap={strokeLinecap}
                />
            </View>
            <View style={[StyleSheet.absoluteFillObject, styles(styleProps).valueContainer]}>
                {showProgressValue && (
                    <AnimatedInput
                        allowFontScaling={allowFontScaling}
                        animatedProps={animatedTextProps}
                        defaultValue={`${valuePrefix}${initialValue}${valueSuffix}`}
                        editable={false}
                        ref={inputRef}
                        style={[styles(styleProps).input, progressValueStyle, styles(styleProps).fromProps]}
                        underlineColorAndroid={COLORS.TRANSPARENT}
                    />
                )}
                {title && title !== '' ? (
                    <Text allowFontScaling={allowFontScaling} numberOfLines={3} style={[styles(styleProps).title, titleStyle]}>
                        {title}
                    </Text>
                ) : null}
                {subtitle && subtitle !== '' ? (
                    <Text allowFontScaling={allowFontScaling} numberOfLines={1} style={[styles(styleProps).title, styles(styleProps).subtitle, subtitleStyle]}>
                        {subtitle}
                    </Text>
                ) : null}
            </View>
        </View>
    )
}

export default CircularProgress
