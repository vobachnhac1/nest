import React, { memo, useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { StyleSheet, View } from 'react-native'
import { Col, Row, Text } from 'native-base'

import { StoreContext } from '../../../store'
import { dimensions as dm, fontSizes as fs, fontWeights as fw } from '../../../styles'

// const listTimeHis = ['1W', '1M', '3M', '1Y'];
interface IHeaderList {
    typeHeader: string
    bgColor?: string
    colSpan: number[]
    noPadding?: boolean
}
interface IListTypeHeader {
    [key: string]: IListTypeHeaderItem[]
}
interface IListTypeHeaderItem {
    title: string
    align: 'left' | 'right' | 'center'
    justifyContent: 'center' | 'flex-start' | 'flex-end' | 'start' | 'end'
    titleSec?: string
}

const ListTypeHeader: IListTypeHeader = {
    ORDER_LIST: [
        { title: 'stock_symbol_short', align: 'left', justifyContent: 'flex-start' },
        { title: 'volume_evaluation', align: 'right', justifyContent: 'center' },
        { title: 'last_price', align: 'right', justifyContent: 'center' },
        { title: 'priceboard_matching_price', align: 'right', justifyContent: 'center' },
        { title: 'order_status', align: 'right', justifyContent: 'flex-end' },
    ],
    DEPOSIT_HISTORY: [
        { title: 'acnt_no', align: 'left', justifyContent: 'flex-start' },
        { title: 'cash_amount_increase', align: 'right', justifyContent: 'center' },
        // { title: 'time', align: 'center', justifyContent: 'center' },
        { title: 'order_status', align: 'right', justifyContent: 'flex-end' },
    ],
    ADVANCE_LENDING: [
        { title: 'settlement_date', align: 'left', justifyContent: 'flex-start' },
        { title: 'cash_amount_increase', align: 'center', justifyContent: 'center' },
        { title: 'order_status', align: 'right', justifyContent: 'flex-end' },
    ],
    RENEW_MARGIN_CONTRACT: [
        { title: 'date_loan', align: 'left', justifyContent: 'flex-start' },
        { title: 'date_due', align: 'center', justifyContent: 'center' },
        { title: 'outstanding_balance', align: 'right', justifyContent: 'flex-end' },
    ],
    RIGHT_INFO: [
        { title: 'right', align: 'left', justifyContent: 'flex-start' },
        { title: 'date_trading_not_right', align: 'right', justifyContent: 'flex-end' },
    ],
    AUNOUNCEMENT_ORDER: [
        { title: 'symbol_short', align: 'left', justifyContent: 'center' },
        { title: 'price', align: 'left', justifyContent: 'center' },
        { title: 'qty', align: 'center', justifyContent: 'center' },
        { title: 'time', align: 'right', justifyContent: 'center' },
    ],
    BANK_WITHDRAWAL: [
        { title: 'symbol_short', align: 'left', justifyContent: 'flex-start' },
        { title: 'create_order', align: 'center', justifyContent: 'flex-end' },
        { title: 'cash_amount_increase', align: 'right', justifyContent: 'center' },
        { title: 'order_status', align: 'right', justifyContent: 'flex-end' },
    ],
    HIS_ODD_LOST: [
        { title: 'symbol_short', align: 'left', justifyContent: 'flex-start' },
        { title: 'qty', align: 'center', justifyContent: 'center' },
        { title: 'price', align: 'center', justifyContent: 'center' },
        { title: 'order_status', align: 'right', justifyContent: 'flex-end' },
    ],
    LIST_CONTRACT_REPAY_MARGIN: [
        { title: 'date_loan', align: 'left', justifyContent: 'flex-start' },
        { title: 'date_due', align: 'center', justifyContent: 'center' },
        { title: 'outstanding_balance', align: 'right', justifyContent: 'end' },
    ],
    HIS_REPAY_MARGIN_PER_CONTRACT: [
        { title: 'repay_date', align: 'left', justifyContent: 'flex-start' },
        { title: 'repay_amount', align: 'center', justifyContent: 'center' },
        { title: 'outstanding_balance', align: 'right', justifyContent: 'end' },
    ],
    CONFIRM_ORDER: [
        { title: 'symbol_short', align: 'left', justifyContent: 'start' },
        { title: 'hist_ord_dt_volume', align: 'center', justifyContent: 'center' },
        { title: 'price', align: 'center', justifyContent: 'center' },
        { title: 'order_status', align: 'right', justifyContent: 'end' },
    ],
    DETAIL_ORDERS: [
        { title: 'symbol_short', align: 'left', justifyContent: 'start' },
        { title: 'hist_ord_dt_volume', align: 'center', justifyContent: 'center' },
        { title: 'price', align: 'center', justifyContent: 'center' },
        { title: 'last_price', align: 'center', justifyContent: 'center' },
        { title: 'order_status', align: 'right', justifyContent: 'end' },
    ],
    ADDITIONAL_STOCK_RELEASE: [
        { title: 'symbol_short', align: 'left', justifyContent: 'start' },
        { title: 'qty', align: 'left', justifyContent: 'center' },
        { title: 'buy_register_date', align: 'center', justifyContent: 'center' },
        { title: 'order_status', align: 'right', justifyContent: 'end' },
    ],
    TRANSACTION_HISTORY: [
        { title: 'header_transfer_acc', align: 'left', justifyContent: 'start' },
        { title: 'header_receive_acc', align: 'center', justifyContent: 'start' },
        { title: 'symbol_short', align: 'center', justifyContent: 'start' },
        { title: 'hist_ord_dt_volume', align: 'center', justifyContent: 'start' },
        { title: 'order_status', align: 'right', justifyContent: 'start' },
    ],
    INTERNAL_TRANSFER: [
        { title: 'header_transfer_acc', align: 'left', justifyContent: 'start' },
        { title: 'header_receive_acc', align: 'center', justifyContent: 'start' },
        { title: 'amount_drawal', align: 'center', justifyContent: 'start' },
        { title: 'order_status', align: 'right', justifyContent: 'start' },
    ],
    ASSET_TABLE: [
        { title: 'stock', align: 'left', justifyContent: 'start' },
        { title: 'common_amount', titleSec: 'cost_price', align: 'center', justifyContent: 'start' },
        { title: 'avg_buy_values', titleSec: 'present_values', align: 'center', justifyContent: 'end' },
        { title: 'common_profit', titleSec: 'profit_ratio', align: 'center', justifyContent: 'end' },
    ],
    HISTORY_PRICE_TABLE: [
        { title: 'day', align: 'left', justifyContent: 'start' },
        { title: 'common_change', align: 'right', justifyContent: 'start' },
        { title: 'highest', align: 'right', justifyContent: 'end' },
        { title: 'lowest', align: 'right', justifyContent: 'end' },
        { title: 'close_price', align: 'right', justifyContent: 'end' },
    ],
    HIS_ONLINE_BANK: [
        { title: 'transaction_information', align: 'left', justifyContent: 'start' },
        { title: 'day', align: 'right', justifyContent: 'end' },
        { title: 'order_status', align: 'right', justifyContent: 'end' },
    ],
    HISTORY_MARGIN_EXTENSION: [
        { title: 'loan_amount', align: 'left', justifyContent: 'flex-start' },
        { title: 'loan_current', align: 'center', justifyContent: 'center' },
        { title: 'order_status', align: 'right', justifyContent: 'flex-end' },
    ],
    REGULAR_ORDER_LIST: [
        { title: 'priority', align: 'left', justifyContent: 'start' },
        { title: 'symbol_short', align: 'center', justifyContent: 'center' },
        { title: 'profit_ratio', align: 'center', justifyContent: 'center' },
        { title: 'value_temp', align: 'right', justifyContent: 'end' },
    ],
    HISTORY_REGULAR_ORDER_LIST: [
        { title: 'short_symbol', align: 'left', justifyContent: 'center' },
        { title: 'profit_ratio', align: 'center', justifyContent: 'center' },
        { title: 'buy_qtty', align: 'right', justifyContent: 'end' },
        { title: 'priceboard_matching_quantity', align: 'right', justifyContent: 'end' },
        { title: 'buying_value', align: 'right', justifyContent: 'center' },
    ],
    MARGIN_STATUS_LIST: [
        // { title: 'common_index', align: 'left', justifyContent: 'start' },
        { title: 'margin_no', align: 'left', justifyContent: 'start' },
        { title: 'margin_tb_time_request', align: 'center', justifyContent: 'center' },
        { title: 'register_margin_item_status', align: 'right', justifyContent: 'end' },
    ],
    RIGHT_INFO_EXPECTED: [
        { title: 'right_type', align: 'left', justifyContent: 'start' },
        { title: 'ex_right_date', align: 'center', justifyContent: 'center' },
        { title: 'record_date', align: 'center', justifyContent: 'center' },
        { title: 'content', align: 'center', justifyContent: 'center' },
    ],
    ECONTRACT_LIST: [
        { title: 'econtract_header_filename', align: 'left', justifyContent: 'flex-start' },
        { title: 'econtract_header_status', align: 'left', justifyContent: 'center' },
        { title: 'econtract_header_verification', align: 'right', justifyContent: 'end' },
    ],
}

const getJustifyContent = (Value: IListTypeHeaderItem['justifyContent']) => {
    if (Value === 'start') return 'flex-start'
    if (Value === 'end') return 'flex-end'
    if (Value === 'center') return 'center'
    return Value
}

const HeaderList = ({ typeHeader = 'DEPOSIT_HISTORY', bgColor, colSpan = [], noPadding }: IHeaderList) => {
    const { t } = useTranslation()
    const { styles } = useContext(StoreContext)
    return (
        <Row
            style={{
                ...UI.HeaderTop_view,
                borderBottomColor: styles.DIVIDER__COLOR,
                marginHorizontal: dm.moderate(noPadding ? 4 : 16),
                backgroundColor: bgColor,
            }}
        >
            {ListTypeHeader[typeHeader].map((item, i) => (
                <Col
                    key={i}
                    size={colSpan[i]}
                    style={{
                        justifyContent: getJustifyContent(item.justifyContent),
                    }}
                >
                    <Text style={{ fontWeight: fw.bold, fontSize: fs.verySmall, textAlign: item.align, color: styles.HEADER__CONTENT__COLOR }}>
                        {t<string>(item.title)}
                        {item.title === 'profit_ratio' ? '(%)' : ''}
                    </Text>
                    {item.titleSec && (
                        <Text style={{ fontWeight: fw.bold, fontSize: fs.verySmall, textAlign: item.align, color: styles.HEADER__CONTENT__COLOR }}>
                            {t<string>(item.titleSec)}
                        </Text>
                    )}
                </Col>
            ))}
        </Row>
    )
}

export default memo(HeaderList)

const UI = StyleSheet.create({
    HeaderTop_view: {
        borderBottomWidth: 1,
        flex: 0,
        paddingBottom: dm.vertical(12),
        paddingTop: dm.vertical(12),
    },
})
