import React, { memo, useContext, useEffect, useLayoutEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Animated, InteractionManager, StyleSheet, TouchableOpacity, View } from 'react-native'
import throttle from 'lodash/throttle'
import { Badge, Col, Row } from 'native-base'

import { Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { dimensions, fontSizes, fontWeights } from '../../styles'
import { eventList, FormatNumber, FormatNumberAC, glb_sv } from '../../utils'
import ChartBuySell from './chart-price/chart-buy-sell'

const maxCallback = (max, cur) => Math.max(max, cur.t1321, cur.t1331)

const ListBuySell = ({ stockCode, handleChangePrice }) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()

    const mounted = useRef(true)

    const [objData, setData] = useState({
        data: [],
        total: 0,
    })

    const throttled = useRef(
        throttle(
            () => {
                if (glb_sv.StockMarket[stockCode]) {
                    const newData = glb_sv.StockMarket[stockCode].TP
                    const newTotal = newData.reduce(maxCallback, -Infinity)
                    InteractionManager.runAfterInteractions(() => {
                        if (mounted.current)
                            setData({
                                data: [...newData],
                                total: newTotal,
                            })
                    })
                }
            },
            500,
            { trailing: true },
        ),
    )

    useEffect(() => {
        const eventMarket = glb_sv.eventMarket.subscribe((msg) => {
            if (msg.type === eventList.SUB_STOCK && msg.message === 'TP' && msg.msgKey === stockCode) {
                throttled.current()
            }
            if (msg.type === eventList.SUBSCRIBE_DONE && msg.msgKey === stockCode) {
                throttled.current()
            }
            if (msg.type === eventList.RESET_DATA) {
                InteractionManager.runAfterInteractions(() => {
                    if (mounted.current)
                        setData({
                            data: [],
                            total: 0,
                        })
                })
            }
        })
        throttled.current()
        return () => {
            mounted.current = false
            eventMarket.unsubscribe()
            throttled.current.cancel()
        }
    }, [])

    return (
        <View style={UI.Table__View}>
            <Text
                style={{
                    color: styles.PRIMARY__CONTENT__COLOR,
                    marginBottom: dimensions.halfIndent,
                    fontSize: fontSizes.medium,
                    fontWeight: fontWeights.medium,
                }}
            >
                {t('priceboard_over_buy_sell_info')}
            </Text>
            <ChartBuySell TP={objData.data} />
            <Row style={{ ...UI.Item__Row__Head, backgroundColor: styles.HEADER__BG__COLOR }}>
                <Col style={UI.Item__Left}>
                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal, fontWeight: fontWeights.medium }}>{t('share')}</Text>
                    <Text style={{ color: styles.UP__COLOR, fontSize: fontSizes.normal, fontWeight: fontWeights.medium }}>{t('priceboard_bid_short')}</Text>
                </Col>
                <Col style={UI.Item__Right}>
                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal, fontWeight: fontWeights.medium }}>{t('share')}</Text>
                    <Text style={{ color: styles.DOWN__COLOR, fontSize: fontSizes.normal, fontWeight: fontWeights.medium }}>
                        {t('priceboard_over_sell_quantity')}
                    </Text>
                </Col>
            </Row>
            {objData.data.map((item, i) => (
                <RowBuySell
                    color_t132={glb_sv.getColor(item.t132, glb_sv.StockMarket[stockCode], styles)}
                    color_t133={glb_sv.getColor(item.t133, glb_sv.StockMarket[stockCode], styles)}
                    handleChangePrice={handleChangePrice}
                    index={i + 1}
                    isOddQty={glb_sv.StockMarket[stockCode] ? glb_sv.StockMarket[stockCode].t167 === 'BO' : false}
                    key={`BuySell__Row__${i}`}
                    t132={item.t132}
                    t1321={item.t1321}
                    t133={item.t133}
                    t1331={item.t1331}
                    total={objData.total}
                />
            ))}
        </View>
    )
}

export const RowBuySell = memo(({ t1321 = 0, t132 = 0, t133 = 0, t1331 = 0, index, total, handleChangePrice, color_t132, color_t133, isOddQty }) => {
    const { styles, fractionPrice, fractionQty } = useContext(StoreContext)

    const WIDTH_BG = useRef(0)
    const widthBuy = useRef(new Animated.Value(0))
    const widthSell = useRef(new Animated.Value(0))

    useLayoutEffect(() => {
        if (!WIDTH_BG.current) return
        if (total === 0) return
        widthBuy.current.setValue((t1321 / total) * WIDTH_BG.current, 2)
        widthSell.current.setValue((t1331 / total) * WIDTH_BG.current, 2)
    }, [t1321, t1331, total])

    // console.log('isOddQty', isOddQty)
    // console.log('ListBuySell isOddQty', isOddQty)

    return (
        <Row style={UI.Item__Row}>
            <Col style={{ flexDirection: 'row' }}>
                <View style={{ backgroundColor: styles.HEADER__BG__COLOR, width: 18, borderRadius: 2, alignItems: 'center', justifyContent: 'center' }}>
                    <Text style={{ fontSize: fontSizes.tiny, color: styles.PRIMARY__CONTENT__COLOR, fontWeight: fontWeights.medium }}>{index}</Text>
                </View>
                <View
                    style={UI.Item__Left__Row}
                    onLayout={(e) => {
                        if (!WIDTH_BG.current) {
                            WIDTH_BG.current = e.nativeEvent.layout.width - 5
                            widthBuy.current.setValue((t1321 / total) * WIDTH_BG.current, 2)
                            widthSell.current.setValue((t1331 / total) * WIDTH_BG.current, 2)
                        }
                    }}
                >
                    <View style={UI.Item__View}>
                        <Text
                            style={{
                                fontSize: fontSizes.tiny,
                                color: styles.PRIMARY__CONTENT__COLOR,
                                fontWeight: fontWeights.medium,
                                lineHeight: fontSizes.tiny,
                            }}
                        >
                            {fractionQty && !isOddQty ? FormatNumberAC(t1321, 0, 1) : FormatNumber(t1321, 0, 1, 'short')}
                        </Text>
                    </View>
                    <TouchableOpacity
                        style={UI.Item__View}
                        onPress={() => {
                            handleChangePrice && handleChangePrice(t132, 'sell')
                        }}
                    >
                        <Text style={{ color: color_t132, fontSize: fontSizes.tiny, fontWeight: fontWeights.medium, lineHeight: fontSizes.tiny }}>
                            {t132 == 777777710000
                                ? 'ATO'
                                : t132 == 777777720000
                                ? 'ATC'
                                : fractionPrice
                                ? FormatNumber(t132 / 1000, 2, 1)
                                : FormatNumber(t132, 0, 1)}
                        </Text>
                    </TouchableOpacity>
                </View>
                <Animated.View style={{ backgroundColor: styles.BID__COLOR, width: widthBuy.current, position: 'absolute', right: 0, height: 18 }} />
            </Col>
            <Col style={{ width: 8 }} />
            <Col style={{ flexDirection: 'row-reverse' }}>
                <View style={{ backgroundColor: styles.HEADER__BG__COLOR, width: 18, borderRadius: 2, alignItems: 'center', justifyContent: 'center' }}>
                    <Text style={{ fontSize: fontSizes.tiny, color: styles.PRIMARY__CONTENT__COLOR, fontWeight: fontWeights.medium }}>{index}</Text>
                </View>
                <View style={UI.Item__Right_Row}>
                    <View style={{ alignItems: 'flex-end', justifyContent: 'flex-end', ...UI.Item__View }}>
                        <Text
                            style={{
                                fontSize: fontSizes.tiny,
                                color: styles.PRIMARY__CONTENT__COLOR,
                                textAlign: 'left',
                                fontWeight: fontWeights.medium,
                                lineHeight: fontSizes.tiny,
                            }}
                        >
                            {fractionQty && !isOddQty ? FormatNumberAC(t1331, 0, 1) : FormatNumber(t1331, 0, 1, 'short')}
                        </Text>
                    </View>
                    <TouchableOpacity
                        style={UI.Item__View}
                        onPress={() => {
                            handleChangePrice && handleChangePrice(t133, 'buy')
                        }}
                    >
                        <Text style={{ color: color_t133, fontSize: fontSizes.tiny, fontWeight: fontWeights.medium, lineHeight: fontSizes.tiny }}>
                            {t133 == 777777710000
                                ? 'ATO'
                                : t133 == 777777720000
                                ? 'ATC'
                                : fractionPrice
                                ? FormatNumber(t133 / 1000, 2, 1)
                                : FormatNumber(t133, 0, 1)}
                        </Text>
                    </TouchableOpacity>
                </View>
                <Animated.View style={{ backgroundColor: styles.ASK__COLOR, width: widthSell.current, position: 'absolute', right: 0, height: 18 }} />
            </Col>
        </Row>
    )
})

export default ListBuySell

const UI = StyleSheet.create({
    Item__Badge: {
        alignItems: 'center',
        borderRadius: 2,
        height: 20,
        paddingLeft: 0,
        paddingRight: 0,
        width: 20,
    },
    Item__Left: {
        alignItems: 'center',
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingHorizontal: 5,
    },
    Item__Left__Row: {
        alignItems: 'center',
        flexDirection: 'row',
        flex: 1,
        justifyContent: 'space-between',
        zIndex: 1,
    },
    Item__Right: {
        alignItems: 'center',
        flexDirection: 'row-reverse',
        justifyContent: 'space-between',
        paddingHorizontal: 5,
    },
    Item__Right_Row: {
        alignItems: 'center',
        flexDirection: 'row-reverse',
        flex: 1,
        justifyContent: 'space-between',
        zIndex: 1,
    },
    Item__Row: {
        height: 18,
        marginVertical: 2,
    },
    Item__Row__Head: {
        borderRadius: 2,
        paddingVertical: 8,
    },
    Item__View: {
        paddingHorizontal: 8,
        paddingVertical: 4,
    },
    Table__View: {
        marginTop: dimensions.vertical(16),
    },
})
