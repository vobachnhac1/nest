/* eslint-disable no-restricted-syntax */
import React, { memo, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import {
    ActivityIndicator,
    Animated,
    Dimensions,
    InteractionManager,
    LayoutAnimation,
    Platform,
    StyleSheet,
    TouchableOpacity,
    UIManager,
    View,
} from 'react-native'
import DeviceInfo from 'react-native-device-info'
import Orientation from 'react-native-orientation-locker'
import AntDesign from 'react-native-vector-icons/AntDesign'
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons'
import cloneDeep from 'lodash/cloneDeep'
import isEqual from 'lodash/isEqual'
import throttle from 'lodash/throttle'
import uniq from 'lodash/uniq'
import moment from 'moment'
import { Button, Right, Toast } from 'native-base'
import SyncStorage from 'sync-storage'

import IC_MENU from '../../assets/images/common/ic_hambuger.svg'
import Refresh from '../../assets/images/common/refresh.svg'
import { Text } from '../../basic-components'
import SwipeListView from '../../basic-components/swipe-list-view'
import { StoreContext } from '../../store'
import { dimensions, fontSizes, fontWeights, IconSvg } from '../../styles'
import { eventList, FormatNumber, FormatNumberAC, glb_sv, reqFunct, Screens, socket_sv, STORE_KEY, subcribeFunct, subcribeFunctStream } from '../../utils'
import sendRequest from '../../utils/sendRequest'
import { SparklinesChart } from '../victory-chart'
import { RemoveStockInListFav } from './favorite-func/favorite.action'
import HeaderOfList from './header-of-list'
import ModalManageList from './modal-fav-manage'

const isTablet = DeviceInfo.isTablet()
const { height, width } = Dimensions.get('window')
const isFiveColumn = width > 600 && width < 910
const isSevenColumn = width > 910

if (Platform.OS === 'android' && UIManager.setLayoutAnimationEnabledExperimental) {
    UIManager.setLayoutAnimationEnabledExperimental(true)
}

const ServiceInfo = {
    removeStockFromFavList: {
        reqFunct: reqFunct.REMOVE_STOCK_IN_FAV_LIST,
        WorkerName: 'FOSxID01',
        ServiceName: 'FOSxID01_FavoritesMgt',
        ClientSentTime: '0',
        Operation: 'D',
    },
    getDetailList: {
        reqFunct: reqFunct.GET_DETAIL_FAV_LIST,
        WorkerName: 'FOSqID01',
        ServiceName: 'FOSqID01_FavoritesMgt',
        Operation: 'Q',
        ClientSentTime: '0',
    },
    GET_LIST_OWN: {
        reqFunct: reqFunct.GET_LIST_OWN,
        WorkerName: 'FOSqStock',
        ServiceName: 'FOSqStock_01_online',
        Operation: 'Q',
        ClientSentTime: '0',
    },
}

function ListFavoriteStock({ navigation, showListFav, setVisibleEditModal, setVisibleDeleteModal, setVisibleAddModal, setVisibleAddModalOddlot }) {
    const { styles, language } = useContext(StoreContext)

    const [activeList, setActiveList] = useState({ ...glb_sv.activeList })
    const activeListRef = useRef([...glb_sv.activeList.ListStock])

    const { t } = useTranslation()
    const [listDataSub, setListDataSub] = useState([])
    const VIEW_HEIGHT_LIST = useRef(dimensions.HIEGHT)
    const VIEW_HEIGHT_ROW = useRef(60.5)
    const CURRENT_SCROLL = useRef(0)

    const [sort, setSort] = useState('')
    const sortRef = useRef('')

    const delayTimeout = useRef(null)
    const removeStockFlag = useRef(false)

    const viewScreen = useRef(true)
    const throttled = useRef(throttle(() => setDataInfoSort(), 1000))

    const [loading, setLoading] = useState(false)

    const timeouFocusScreen = useRef(null)

    const firstTime = useRef(true)

    const listSuggest = useRef([])

    const listRef = useRef(null)

    // manage list
    const [visibleModalManageList, setVisibleModalManageList] = useState(false)

    const [updateStock, setUpdateStock] = useState(0)

    const tempFavList = useRef([])

    useEffect(() => {
        setListDataSub([])
    }, [language])

    useEffect(() => {
        const focusScreen = navigation.addListener('focus', (e) => {
            viewScreen.current = true
            if (timeouFocusScreen.current) clearTimeout(timeouFocusScreen.current)
            timeouFocusScreen.current = setTimeout(
                () => {
                    const NoHeadArr = Math.round(CURRENT_SCROLL.current / VIEW_HEIGHT_ROW.current)
                    const NoTailArr = Math.ceil(VIEW_HEIGHT_LIST.current / VIEW_HEIGHT_ROW.current)

                    const newList = activeListRef.current.slice(NoHeadArr, NoHeadArr + NoTailArr)

                    if (newList.length) {
                        glb_sv.subListCur = newList

                        if (isTablet) {
                            if (glb_sv.activeList.isOddlot) {
                                if (glb_sv.activeList.ListStock.length) {
                                    subcribeFunctStream('SUB', ['MDDS|SI', 'MDDS|TO', 'MDDS|PO'], glb_sv.activeList.ListStock)
                                }
                                setTimeout(() => {
                                    if (glb_sv.activeList.ListStock.length)
                                        subcribeFunctStream('UNSUB', ['MDDS|SI', 'MDDS|TO', 'MDDS|PO'], glb_sv.activeList.ListStock)
                                    subcribeFunct(subcribeFunctTimeout, null, 'SUB', ['MDDS|SI', 'MDDS|TO', 'MDDS|PO'], newList)
                                }, 50)
                            } else {
                                if (glb_sv.activeList.ListStock.length) {
                                    subcribeFunctStream('SUB', ['MDDS|SI', 'MDDS|TP', 'INTRADAY_1s'], glb_sv.activeList.ListStock)
                                }
                                setTimeout(() => {
                                    if (glb_sv.activeList.ListStock.length)
                                        subcribeFunctStream('UNSUB', ['MDDS|SI', 'MDDS|TP', 'INTRADAY_1s'], glb_sv.activeList.ListStock)
                                    subcribeFunct(subcribeFunctTimeout, null, 'SUB', ['MDDS|SI', 'MDDS|TP', 'INTRADAY_1s'], newList)
                                }, 50)
                            }
                        } else {
                            if (glb_sv.activeList.isOddlot) {
                                if (glb_sv.activeList.ListStock.length) subcribeFunctStream('SUB', ['MDDS|SI'], glb_sv.activeList.ListStock)
                                setTimeout(() => {
                                    if (glb_sv.activeList.ListStock.length) subcribeFunctStream('UNSUB', ['MDDS|SI'], glb_sv.activeList.ListStock)
                                    subcribeFunct(subcribeFunctTimeout, null, 'SUB', ['MDDS|SI'], newList)
                                }, 50)
                            } else {
                                if (glb_sv.activeList.ListStock.length) subcribeFunctStream('SUB', ['MDDS|SI', 'INTRADAY_1s'], glb_sv.activeList.ListStock)
                                setTimeout(() => {
                                    if (glb_sv.activeList.ListStock.length)
                                        subcribeFunctStream('UNSUB', ['MDDS|SI', 'INTRADAY_1s'], glb_sv.activeList.ListStock)
                                    subcribeFunct(subcribeFunctTimeout, null, 'SUB', ['MDDS|SI', 'INTRADAY_1s'], newList)
                                }, 50)
                            }
                        }
                        if (glb_sv.activeList.type !== 'suggest') {
                            if (socket_sv.timeMarket) {
                                if (moment(socket_sv.timeMarket, 'HH:mm:ss') - moment('13:00:00', 'HH:mm:ss') > 0) {
                                    subcribeFunctStream('GET_HIST', ['INTRADAY_5m'], newList, [0], [500])
                                } else subcribeFunctStream('GET_HIST', ['INTRADAY_1m'], newList, [0], [500])
                            } else subcribeFunctStream('GET_HIST', ['INTRADAY_1m'], newList, [0], [500])
                        }
                        // throttled.current();
                        setDataInfoSort()
                    }
                },
                firstTime ? 0 : 1000,
            )
            firstTime.current = false
        })
        const blurScreen = navigation.addListener('blur', (e) => {
            if (timeouFocusScreen.current) clearTimeout(timeouFocusScreen.current)
            if (!viewScreen.current) return
            viewScreen.current = false
            if (glb_sv.activeList.ListStock.length) {
                if (isTablet) {
                    if (glb_sv.activeList.isOddlot) {
                        subcribeFunctStream('UNSUB', ['MDDS|SI', 'MDDS|TO', 'MDDS|PO'], glb_sv.activeList.ListStock)
                    } else {
                        subcribeFunctStream('UNSUB', ['MDDS|SI', 'MDDS|TP', 'INTRADAY_1s'], glb_sv.activeList.ListStock)
                    }
                } else {
                    if (glb_sv.activeList.isOddlot) {
                        subcribeFunctStream('UNSUB', ['MDDS|SI'], glb_sv.activeList.ListStock)
                    } else {
                        subcribeFunctStream('UNSUB', ['MDDS|SI', 'INTRADAY_1s'], glb_sv.activeList.ListStock)
                    }
                }
            }
        })

        setLoading(false)
        setActiveList({ ...glb_sv.activeList })
        activeListRef.current = [...glb_sv.activeList.ListStock]
        setDataInfoSort()
        handleSubRow()

        const eventMarket = glb_sv.eventMarket.subscribe((msg) => {
            if (msg.type === eventList.SUB_STOCK && msg.message !== 'EP' && glb_sv.subListCur.some((e) => e === msg.msgKey)) {
                if (!viewScreen.current) return
                if (!isTablet && !msg.isUpdateWatchlistMobile) {
                    return
                }
                if (!msg.isUpdateWatchlistTablet) return
                setUpdateStock((prev) => prev + 1)
            } else if (msg.type === eventList.SUBSCRIBE_DONE) {
                setDataInfoSort()
                if (isEqual(glb_sv.subListCur, msg.arrSub)) {
                    getEpAfterSort()
                }
            } else if (msg.type === eventList.LOADING_FAV) {
                setLoading(true)
            } else if (msg.type === eventList.REQ_RE_GET_MKT_INF || msg.type === eventList.RESET_DATA) {
                if (!viewScreen.current) return
                // if (isTablet) {
                //     subcribeFunctStream('SUB', ['MDDS|SI', 'MDDS|TP', 'INTRADAY_1s'], activeListRef.current);
                // } else {
                //     subcribeFunctStream('SUB', ['MDDS|SI', 'INTRADAY_1s'], activeListRef.current);
                // }
                handleSubRow()
            } else if (msg.type === eventList.RECONNECT_MARKET) {
                if (!viewScreen.current) return
                handleSubRow()
            }
        })
        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.CHANGE_LIST_STOCK) {
                sortRef.current = ''
                setSort('')
                setActiveList(cloneDeep(glb_sv.activeList))
                activeListRef.current = glb_sv.activeList.ListStock.slice()
                setDataInfoSort()
                InteractionManager.runAfterInteractions(() => {
                    handleSubRow(null, null, true)
                })
            } else if (msg.type === eventList.CHANGE_LIST_ACTIVE) {
                sortRef.current = ''
                setSort('')
                setActiveList(cloneDeep(glb_sv.activeList))
                activeListRef.current = glb_sv.activeList.ListStock.slice()

                setDataInfoSort()
                if (isTablet) {
                    if (glb_sv.activeList.isOddlot) {
                        subcribeFunctStream('SUB', ['MDDS|SI', 'MDDS|TO', 'MDDS|PO'], glb_sv.activeList.ListStock)
                    } else {
                        subcribeFunctStream('SUB', ['MDDS|SI', 'MDDS|TP', 'INTRADAY_1s'], glb_sv.activeList.ListStock)
                    }
                } else {
                    if (glb_sv.activeList.isOddlot) {
                        subcribeFunctStream('SUB', ['MDDS|SI'], glb_sv.activeList.ListStock)
                    } else {
                        subcribeFunctStream('SUB', ['MDDS|SI', 'INTRADAY_1s'], glb_sv.activeList.ListStock)
                    }
                }
                handleSubRow(null, null, 'new')
                setLoading(false)
                setTimeout(() => {
                    if (glb_sv.activeList.c1 === 'watchlist_owner') {
                        getStockListOwn()
                    } else {
                        getDetailFavList()
                    }
                }, 1000)
            }
        })

        return () => {
            focusScreen()
            blurScreen()

            eventMarket.unsubscribe()
            commonEvent.unsubscribe()
            throttled.current.cancel()
        }
    }, [])

    const subcribeFunctTimeout = () => {
        if (!viewScreen.current) return
        if (isTablet) {
            if (glb_sv.activeList.isOddlot) {
                subcribeFunct(subcribeFunctTimeout, null, 'SUB', ['MDDS|SI', 'MDDS|TO', 'MDDS|PO'], glb_sv.subListCur)
            } else {
                subcribeFunct(subcribeFunctTimeout, null, 'SUB', ['MDDS|SI', 'MDDS|TP', 'INTRADAY_1s'], glb_sv.subListCur)
            }
        } else {
            if (glb_sv.activeList.isOddlot) {
                subcribeFunct(subcribeFunctTimeout, null, 'SUB', ['MDDS|SI'], glb_sv.subListCur)
            } else {
                subcribeFunct(subcribeFunctTimeout, null, 'SUB', ['MDDS|SI', 'INTRADAY_1s'], glb_sv.subListCur)
            }
        }
    }

    const handleButton = () => {
        if (activeList.c1) navigation.navigate(Screens.SEARCH_STOCK, { actionType: 'FAV_ACTION' })
        else {
            setVisibleAddModal(true)
        }
    }

    const handleSubRow = (y, all, type) => {
        if (all) {
            const newList = glb_sv.activeList.ListStock.slice()
            if (newList.length) {
                if (isTablet) {
                    if (glb_sv.activeList.isOddlot) {
                        subcribeFunctStream('UNSUB', ['MDDS|SI', 'MDDS|TO', 'MDDS|PO'], newList)
                    } else {
                        subcribeFunctStream('UNSUB', ['MDDS|SI', 'MDDS|TP', 'INTRADAY_1s'], newList)
                    }
                } else {
                    if (glb_sv.activeList.isOddlot) {
                        subcribeFunctStream('UNSUB', ['MDDS|SI'], newList)
                    } else {
                        subcribeFunctStream('UNSUB', ['MDDS|SI', 'INTRADAY_1s'], newList)
                    }
                }
            }
            return
        }
        CURRENT_SCROLL.current = y || CURRENT_SCROLL.current

        if (delayTimeout.current) clearTimeout(delayTimeout.current)
        delayTimeout.current = setTimeout(() => {
            const NoHeadArr = Math.round(CURRENT_SCROLL.current / VIEW_HEIGHT_ROW.current)
            const NoTailArr = Math.ceil(VIEW_HEIGHT_LIST.current / VIEW_HEIGHT_ROW.current)

            const newList = activeListRef.current.slice(NoHeadArr, NoHeadArr + NoTailArr)

            if (newList.length) {
                glb_sv.subListCur = newList

                if (type || !isEqual(newList, activeListRef.current)) {
                    if (isTablet) {
                        if (glb_sv.activeList.isOddlot) {
                            subcribeFunctStream('UNSUB', ['MDDS|SI', 'MDDS|TO', 'MDDS|PO'], glb_sv.activeList.ListStock)
                            subcribeFunct(subcribeFunctTimeout, null, 'SUB', ['MDDS|SI', 'MDDS|TO', 'MDDS|PO'], newList)
                        } else {
                            subcribeFunctStream('UNSUB', ['MDDS|SI', 'MDDS|TP', 'INTRADAY_1s'], glb_sv.activeList.ListStock)
                            subcribeFunct(subcribeFunctTimeout, null, 'SUB', ['MDDS|SI', 'MDDS|TP', 'INTRADAY_1s'], newList)
                        }
                    } else {
                        if (glb_sv.activeList.isOddlot) {
                            subcribeFunctStream('UNSUB', ['MDDS|SI'], glb_sv.activeList.ListStock)
                            subcribeFunct(subcribeFunctTimeout, null, 'SUB', ['MDDS|SI'], newList)
                        } else {
                            subcribeFunctStream('UNSUB', ['MDDS|SI', 'INTRADAY_1s'], glb_sv.activeList.ListStock)
                            subcribeFunct(subcribeFunctTimeout, null, 'SUB', ['MDDS|SI', 'INTRADAY_1s'], newList)
                        }
                    }
                }
                if (glb_sv.activeList.type !== 'suggest') {
                    setTimeout(() => {
                        if (socket_sv.timeMarket) {
                            if (moment(socket_sv.timeMarket, 'HH:mm:ss') - moment('13:00:00', 'HH:mm:ss') > 0) {
                                subcribeFunctStream('GET_HIST', ['INTRADAY_5m'], newList, [0], [500])
                            } else subcribeFunctStream('GET_HIST', ['INTRADAY_1m'], newList, [0], [500])
                        } else subcribeFunctStream('GET_HIST', ['INTRADAY_1m'], newList, [0], [500])
                    }, 100)
                }

                // throttled.current();
                setDataInfoSort()
            }
        }, 200)
    }

    const removeStock = useCallback(
        ({ isOpen, direction, value, key }) => {
            LayoutAnimation.configureNext(LayoutAnimation.Presets.spring)
            if (direction === 'right') {
                if (value < -190 && !removeStockFlag.current) {
                    removeStockFlag.current = true
                    if (glb_sv.authFlag) {
                        const InputParams = ['FAV_ITEM_REMOVE', activeList.c1, key]
                        sendRequest(ServiceInfo.removeStockFromFavList, InputParams, handleRmStkFrFavList, true, removeStkFavListTimeout, '', 3000)
                    } else {
                        removeStockFlag.current = false
                        const current = glb_sv.allListFav.find((x) => x.c1 === activeList.c1)
                        current.ListStock = current.ListStock.filter((e) => e !== key)
                        glb_sv.activeList = { ...current }

                        setActiveList(cloneDeep(glb_sv.activeList))
                        activeListRef.current = glb_sv.activeList.ListStock.slice()

                        setDataInfoSort()
                        if (!viewScreen.current) return
                        handleSubRow()
                    }
                }
            }
        },
        [activeList],
    )

    const removeStkFavListTimeout = () => {
        removeStockFlag.current = false
        listRef.current?.closeAllOpenRows()
        Toast.show({
            text: t('request_hanlde_not_success_try_again'),
            type: 'warning',
            position: 'bottom',
        })
    }

    const handleRmStkFrFavList = (reqInfoMap, message) => {
        removeStockFlag.current = false
        if (Number(message.Result) === 0) {
            if (message.Code === '010012') {
                // Toast.show({
                //     text: t('request_hanlde_not_success_try_again'),
                //     type: 'warning',
                //     position: 'bottom',
                // })
            } else {
                Toast.show({
                    text: message.Message,
                    type: 'warning',
                    position: 'bottom',
                })
            }
            listRef.current?.closeAllOpenRows()
            return
        } else {
            const current = glb_sv.allListFav.find((x) => x.c1 === reqInfoMap.inputParam[1])
            current.ListStock = current.ListStock.filter((e) => e !== reqInfoMap.inputParam[2])
            glb_sv.activeList = { ...current }
            setActiveList(cloneDeep(glb_sv.activeList))
            setDataInfoSort()
            handleSubRow()
        }
    }

    const setDataInfoSort = () => {
        const listSub = glb_sv.activeList.ListStock.map((e) => {
            if (glb_sv.activeList.type === 'suggest') {
                const objSug = listSuggest.current.find((temp) => temp.c1 === e) || { c5: 25000, c4: '2' }
                return (
                    { ...glb_sv.StockMarket[e], priceSuggest: objSug.c5, typeSuggest: objSug.c4 === '1' ? 'buy_upcase' : 'sell_upcase' } || {
                        t55: e,
                        EP: [],
                        priceSuggest: objSug.c5,
                        typeSuggest: objSug.c4 === '1' ? 'buy_upcase' : 'sell_upcase',
                    }
                )
            }
            return glb_sv.StockMarket[e] || { t55: e, EP: [] }
        })
        const newList = cloneDeep(listSub)
        if (sortRef.current) {
            newList.sort(sortColumn)
        }
        InteractionManager.runAfterInteractions(() => {
            setListDataSub(newList)
        })
    }

    const changeTypeSort = useCallback((changed) => {
        if (sortRef.current === '' || !sortRef.current.includes(changed)) {
            sortRef.current = changed + '|down'
            setSort(changed + '|down')
            const newList = glb_sv.activeList.ListStock.map((e) => {
                return glb_sv.StockMarket[e] || { t55: e, EP: [] }
            })
            newList.sort(sortColumn)
            activeListRef.current = newList.map((e) => e.t55)
            handleSubRow()
            setListDataSub(newList)
            return
        }
        if (sortRef.current === changed + '|down') {
            sortRef.current = changed + '|up'
            setSort(changed + '|up')
            const newList = glb_sv.activeList.ListStock.map((e) => {
                return glb_sv.StockMarket[e] || { t55: e, EP: [] }
            })
            newList.sort(sortColumn)
            activeListRef.current = newList.map((e) => e.t55)
            handleSubRow()
            setListDataSub(newList)
            return
        }
        if (sortRef.current === changed + '|up') {
            sortRef.current = ''
            setSort('')
            const newList = glb_sv.activeList.ListStock.map((e) => {
                return glb_sv.StockMarket[e] || { t55: e, EP: [] }
            })
            activeListRef.current = glb_sv.activeList.ListStock.slice()
            handleSubRow()
            setListDataSub(newList)
            return
        }
    }, [])

    function sortColumn(a, b) {
        const [key, direction] = sortRef.current.split('|')
        if (direction === 'up') {
            if (a[key] > b[key]) return 1
            if (a[key] < b[key]) return -1
            return 0
        }
        if (direction === 'down') {
            if (a[key] < b[key]) return 1
            if (a[key] > b[key]) return -1
            return 0
        }
    }

    const getEpAfterSort = (list) => {
        const NoHeadArr = Math.round(CURRENT_SCROLL.current / VIEW_HEIGHT_ROW.current)
        const NoTailArr = Math.ceil(VIEW_HEIGHT_LIST.current / VIEW_HEIGHT_ROW.current)

        const newList = glb_sv.activeList.ListStock.slice(NoHeadArr, NoHeadArr + NoTailArr)

        if (newList.length) {
            glb_sv.subListCur = newList
            if (glb_sv.activeList.type !== 'suggest') {
                if (socket_sv.timeMarket) {
                    if (moment(socket_sv.timeMarket, 'HH:mm:ss') - moment('13:00:00', 'HH:mm:ss') > 0) {
                        subcribeFunctStream('GET_HIST', ['INTRADAY_5m'], newList, [0], [500])
                    } else subcribeFunctStream('GET_HIST', ['INTRADAY_1m'], newList, [0], [500])
                } else subcribeFunctStream('GET_HIST', ['INTRADAY_1m'], newList, [0], [500])
            }
        }
    }

    const onChangePriceboard = useCallback(() => {
        if (!glb_sv.activeList.ListStock) return
        const newList = glb_sv.activeList.ListStock.map((e) => glb_sv.StockMarket[e] || { t55: e })
        viewScreen.current = false
        Orientation.lockToLandscapeRight()
        navigation.navigate(Screens.PRICEBOARD, { list: newList })
    }, [])

    const renderFooter = useMemo(() => {
        return (
            <View style={UI.viewFooter}>
                {activeList.type === 'watchlist' && activeList.ListStock.length ? (
                    <Button style={{ backgroundColor: styles.PRIMARY, justifyContent: 'center', alignSelf: 'center', width: 231 }} onPress={handleButton}>
                        <Text style={UI.textNewStock}>{t('new_stock')}</Text>
                    </Button>
                ) : null}
            </View>
        )
    }, [activeList.type, activeList.ListStock.length])

    const HiddenItemWithActions = (props) => {
        const { swipeAnimatedValue, leftActionActivated, data } = props

        return (
            <Animated.View style={[UI.rowBack]}>
                {!leftActionActivated && (
                    <Animated.View
                        style={[
                            UI.backRightBtn,
                            UI.backRightBtnRight,
                            {
                                flex: 1,
                                opacity: swipeAnimatedValue.interpolate({
                                    inputRange: [-400, 0],
                                    outputRange: [1, 0],
                                    extrapolate: 'clamp',
                                }),
                            },
                        ]}
                    >
                        <Animated.View style={[UI.backRightBtn, UI.backRightBtnRight]}>
                            <MaterialCommunityIcons
                                color="#fff"
                                name="trash-can-outline"
                                size={25}
                                onPress={() => {
                                    removeStockFlag.current = false
                                    onRightActionStatusChange({ key: data.item?.t55 })
                                }}
                            />
                        </Animated.View>
                    </Animated.View>
                )}
            </Animated.View>
        )
    }

    const renderHiddenItem = (data, rowMap) => {
        const rowActionAnimatedValue = new Animated.Value(75)
        const rowHeightAnimatedValue = new Animated.Value(60)

        return <HiddenItemWithActions data={data} rowActionAnimatedValue={rowActionAnimatedValue} rowHeightAnimatedValue={rowHeightAnimatedValue} />
    }

    const onRightActionStatusChange = ({ key }) => {
        if (!key) return
        if (!removeStockFlag.current) {
            removeStockFlag.current = true
            // throttled.current(); // chua biet tac dung gi
            if (glb_sv.authFlag) {
                if (!glb_sv.activeList.ListStock.includes(key)) return
                const InputParams = ['FAV_ITEM_REMOVE', activeList.c1, key]
                sendRequest(ServiceInfo.removeStockFromFavList, InputParams, handleRmStkFrFavList, true, removeStkFavListTimeout, '', 3000)
            } else {
                RemoveStockInListFav(activeList.c1, key)
                removeStockFlag.current = false
            }
        }
    }

    const onRightAction = (key) => {}

    const changeSearchScreen = useCallback(() => {
        navigation.navigate(Screens.SEARCH_STOCK, { actionType: 'FAV_ACTION' })
    }, [])

    const showManageList = useCallback(() => {
        setVisibleModalManageList(true)
    }, [])

    const refreshFavStockList = useCallback(() => {
        if (!glb_sv.authFlag) return
        setLoading(true)
        if (glb_sv.activeList.c1 === 'watchlist_owner') {
            getStockListOwn()
        } else {
            getDetailFavList()
        }
    }, [])

    const getStockListOwn = () => {
        if (!glb_sv.objShareGlb.AcntMain) return
        const InputParams = [glb_sv.objShareGlb.AcntMain]
        sendRequest(ServiceInfo.GET_LIST_OWN, InputParams, getStockListOwnResult, true, getStockListOwnTimeout, '', 0, 'equal_input')
        tempFavList.current = []
    }

    const getStockListOwnTimeout = () => {
        setLoading(false)
    }

    const getStockListOwnResult = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            setLoading(false)
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
                tempFavList.current = tempFavList.current.concat(jsondata.map((e) => e.c0))
            } catch (err) {
                setLoading(false)
                return
            }

            if (Number(message.Packet) <= 0) {
                const newWatchlist = {
                    c1: 'watchlist_owner',
                    c2: 'own_stock_list',
                    type: 'own',
                    ListStock: tempFavList.current,
                }
                const dataSort = SyncStorage.get(STORE_KEY.SORT_FAV) || {}
                const sortList = dataSort[reqInfoMap.inputParam[1]] || []
                const newSortListFilterStockRemove = filterArray(sortList, newWatchlist.ListStock)
                newWatchlist.ListStock = uniq(newSortListFilterStockRemove.concat(newWatchlist.ListStock))

                glb_sv.listStockOwn = newWatchlist
                const obj = glb_sv.allListFav.find((x) => x.c1 === 'watchlist_owner')
                if (obj) {
                    obj.ListStock = newWatchlist.ListStock
                }
                glb_sv.activeList = newWatchlist
                setActiveList({ ...glb_sv.activeList })
                activeListRef.current = glb_sv.activeList.ListStock.slice()
                setDataInfoSort()
                InteractionManager.runAfterInteractions(() => {
                    handleSubRow(null, null, true)
                    setLoading(false)
                })
            }
        }
    }

    const getDetailFavList = () => {
        const groupId = glb_sv.activeList.c1
        const InputParams = ['4', String(groupId)]
        sendRequest(ServiceInfo.getDetailList, InputParams, handleGetDetailFavList, true, getDetailFavListTimeout)
        tempFavList.current = []
    }

    const getDetailFavListTimeout = () => {
        setLoading(false)
    }

    const handleGetDetailFavList = (reqInfoMap, message) => {
        const idFav = reqInfoMap.inputParam[1]
        if (Number(message.Result) === 0) {
            setLoading(false)
            return
        } else {
            let dataArr = []
            try {
                dataArr = message.Data ? JSON.parse(message.Data) : []
                tempFavList.current = tempFavList.current.concat(dataArr.map((e) => e.c3))
            } catch (error) {
                setLoading(false)
                return
            }
            if (Number(message.Packet) <= 0) {
                const obj = glb_sv.allListFav.find((x) => x.c1 === idFav)
                if (obj) {
                    obj.ListStock = tempFavList.current
                    const dataSort = SyncStorage.get(STORE_KEY.SORT_FAV) || {}
                    const sortList = dataSort[idFav] || []
                    const newSortListFilterStockRemove = filterArray(sortList, obj.ListStock)
                    obj.ListStock = uniq(newSortListFilterStockRemove.concat(obj.ListStock))

                    glb_sv.activeList.ListStock = obj.ListStock

                    setActiveList({ ...glb_sv.activeList })
                    activeListRef.current = glb_sv.activeList.ListStock.slice()
                    setDataInfoSort()
                    InteractionManager.runAfterInteractions(() => {
                        handleSubRow(null, null, true)
                        setLoading(false)
                    })
                }
            }
        }
    }

    return (
        <View style={{ flex: 1, paddingBottom: 8 }}>
            <HeaderView
                c1={activeList.c1}
                c2={activeList.c2 === 'own_stock_list' ? t('own_stock_list') : activeList.isOddlot ? `(${t('odd_lot')}) ${activeList.c2}` : activeList.c2}
                changeSearchScreen={changeSearchScreen}
                changeTypeSort={changeTypeSort}
                ListStock={activeList.ListStock}
                refreshFavStockList={refreshFavStockList}
                showListFav={showListFav}
                showManageList={showManageList}
                sort={sort}
                type={activeList.type}
                onChangePriceboard={onChangePriceboard}
            />
            <View
                style={[UI.flex1, activeList.ListStock.length ? {} : { alignItems: 'center', marginTop: 50 }]}
                onLayout={(event) => {
                    const { height } = event.nativeEvent.layout
                    VIEW_HEIGHT_LIST.current = height
                }}
            >
                {!loading ? (
                    activeList.ListStock.length ? (
                        <SwipeListView
                            data={listDataSub}
                            disableLeftSwipe={activeList.type === 'suggest' || activeList.type === 'own' ? true : false}
                            disableRightSwipe={true}
                            extraData={updateStock}
                            keyExtractor={(item, index) => item?.t55 || index.toString()}
                            ListFooterComponent={renderFooter}
                            ref={listRef}
                            renderHiddenItem={renderHiddenItem}
                            renderItem={({ item }) => (
                                <StockItem
                                    isOddlot={activeList.isOddlot}
                                    navigation={navigation}
                                    removeStock={removeStock}
                                    t132_1={glb_sv.StockMarket[item.t55]?.t132_1}
                                    t133_1={glb_sv.StockMarket[item.t55]?.t133_1}
                                    t260={glb_sv.StockMarket[item.t55]?.t260}
                                    t31={glb_sv.StockMarket[item.t55]?.t31}
                                    t31_incr={glb_sv.StockMarket[item.t55]?.t31_incr}
                                    t31_incr_per={glb_sv.StockMarket[item.t55]?.t31_incr_per}
                                    t3301={glb_sv.StockMarket[item.t55]?.t3301}
                                    t391={glb_sv.StockMarket[item.t55]?.t391}
                                    t55={item.t55}
                                />
                            )}
                            rightActionValue={-400}
                            rightActivationValue={-400}
                            rightOpenValue={-400}
                            scrollEventThrottle={100}
                            showsVerticalScrollIndicator={false}
                            style={UI.swipe_list_view}
                            onRightAction={onRightAction}
                            onRightActionStatusChange={onRightActionStatusChange}
                            onScroll={(e) => handleSubRow(e.nativeEvent.contentOffset.y)}
                        />
                    ) : (
                        <>
                            <IconSvg.IconFolderEmpty />
                            <Text
                                style={{
                                    fontSize: fontSizes.medium,
                                    fontWeight: fontWeights.medium,
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                    lineHeight: dimensions.moderate(26),
                                }}
                            >
                                {t('watchlist_empty')}
                            </Text>
                            {activeList.type === 'watchlist' || !activeList.type ? (
                                <Text style={{ fontSize: fontSizes.small, color: styles.ICON__CLOCK, lineHeight: dimensions.moderate(23) }}>
                                    {activeList.c1 ? t('let_add_stock_watchlist') : t('let_add_watchlist')}
                                </Text>
                            ) : null}
                            {activeList.type === 'watchlist' || !activeList.type ? (
                                <Button
                                    style={{
                                        backgroundColor: styles.PRIMARY,
                                        justifyContent: 'center',
                                        alignSelf: 'center',
                                        width: 231,
                                        marginTop: dimensions.vertical(71),
                                    }}
                                    onPress={handleButton}
                                >
                                    <Text style={{ color: '#FFF', fontSize: fontSizes.small }}>{activeList.c1 ? t('new_stock') : t('add_watchlist')}</Text>
                                </Button>
                            ) : null}
                        </>
                    )
                ) : (
                    <ActivityIndicator color={styles.PRIMARY} size="large" />
                )}
            </View>
            {visibleModalManageList && (
                <ModalManageList
                    changeSearchScreen={changeSearchScreen}
                    navigation={navigation}
                    setVisibleAddModal={setVisibleAddModal}
                    setVisibleAddModalOddlot={setVisibleAddModalOddlot}
                    setVisibleDeleteModal={setVisibleDeleteModal}
                    setVisibleEditModal={setVisibleEditModal}
                    setVisibleModalManageList={setVisibleModalManageList}
                    visibleModalManageList={visibleModalManageList}
                />
            )}
        </View>
    )
}
export default memo(ListFavoriteStock, () => true)

const HeaderView = memo(
    ({
        c1,
        c2,
        type,
        ListStock,
        sort,
        showListFav,
        changeTypeSort,
        changeSearchScreen,
        onChangePriceboard,
        showManageList,
        navigation,
        refreshFavStockList,
    }) => {
        const { styles } = useContext(StoreContext)
        if (!c1) return null
        return (
            <>
                <View style={{ flexDirection: 'row', paddingHorizontal: dimensions.moderate(16) }}>
                    <TouchableOpacity style={{ flex: 1, flexDirection: 'row', alignItems: 'center', paddingRight: 25 }} onPress={showListFav}>
                        <IC_MENU style={{ color: styles.ICON__PRIMARY }} />
                        <Text numberOfLines={1} style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.medium, fontWeight: fontWeights.semiBold }}>
                            {' '}
                            {c2}
                        </Text>
                    </TouchableOpacity>
                    <View style={{ flexDirection: 'row' }}>
                        {['own', 'suggest'].includes(type) ? null : (
                            <TouchableOpacity
                                style={{
                                    marginRight: dimensions.moderate(12),
                                    backgroundColor: styles.BUTTON__SECONDARY,
                                    justifyContent: 'center',
                                    borderRadius: 18,
                                    width: dimensions.moderate(36),
                                    height: dimensions.moderate(36),
                                    alignItems: 'center',
                                }}
                                onPress={changeSearchScreen}
                            >
                                <IconSvg.PlusPureIcon color={styles.ICON__PRIMARY} />
                            </TouchableOpacity>
                        )}
                        <TouchableOpacity style={{ marginRight: dimensions.moderate(12) }} onPress={refreshFavStockList}>
                            <View style={{ backgroundColor: styles.BUTTON__SECONDARY, padding: 4, borderRadius: 12 }}>
                                <Refresh fill={styles.ICON__PRIMARY} height={24} style={{ opacity: 0.85 }} width={24} />
                            </View>
                        </TouchableOpacity>
                        {ListStock.length ? (
                            <TouchableOpacity style={{ marginRight: dimensions.moderate(12) }} onPress={onChangePriceboard}>
                                <IconSvg.IconPhoneRotate BUTTON__SECONDARY={styles.BUTTON__SECONDARY} ICON__PRIMARY={styles.ICON__PRIMARY} isBigger={true} />
                            </TouchableOpacity>
                        ) : null}
                        <TouchableOpacity onPress={showManageList}>
                            <IconSvg.IconThreeDotHorizontal BUTTON__SECONDARY={styles.BUTTON__SECONDARY} ICON__PRIMARY={styles.ICON__PRIMARY} />
                        </TouchableOpacity>
                    </View>
                </View>

                <HeaderOfList changeTypeSort={changeTypeSort} navigation={navigation} sort={sort} type={type} />
            </>
        )
    },
)

const StockItem = memo(({ t55, navigation, isOddlot }) => {
    const stockInfo = glb_sv.StockMarket[t55] || { TP: [], PO: [] }
    const { styles, fractionPrice, fractionQty } = useContext(StoreContext)

    const renderT31 = () => {
        if (isOddlot) {
            return fractionPrice
                ? FormatNumber((stockInfo.t31_PO || stockInfo.t260) / 1000, 2, 0, '---')
                : FormatNumber(stockInfo.t31_PO || stockInfo.t260, 0, 0, '---')
        } else {
            return fractionPrice
                ? FormatNumber((stockInfo.t31 || stockInfo.t260) / 1000, 2, 0, '---')
                : FormatNumber(stockInfo.t31 || stockInfo.t260, 0, 0, '---')
        }
    }

    const renderT31Incr = () => {
        if (isOddlot) {
            return stockInfo.t31_PO
                ? (stockInfo.t31_incr_PO > 0 ? '+' : '') +
                      (fractionPrice ? FormatNumber(stockInfo.t31_incr_PO / 1000, 2) : FormatNumber(stockInfo.t31_incr_PO)) +
                      ' ' +
                      (stockInfo.t31_incr_per_PO > 0 ? '+' : '') +
                      (FormatNumber(stockInfo.t31_incr_per_PO, 2) + '%')
                : '---  ---'
        } else {
            return stockInfo.t31
                ? (stockInfo.t31_incr > 0 ? '+' : '') +
                      (fractionPrice ? FormatNumber(stockInfo.t31_incr / 1000, 2) : FormatNumber(stockInfo.t31_incr)) +
                      ' ' +
                      (stockInfo.t31_incr_per > 0 ? '+' : '') +
                      (FormatNumber(stockInfo.t31_incr_per, 2) + '%')
                : '---  ---'
        }
    }

    const TouchView = useMemo(
        () =>
            StyleSheet.flatten([
                {
                    flex: 1,
                    flexDirection: 'row',
                    borderBottomColor: styles.DIVIDER__COLOR,
                    height: 60.5,
                    backgroundColor: styles.PRIMARY__BG__COLOR,
                    alignItems: 'center',
                },
            ]),
        [styles],
    )

    const TextT55 = useMemo(
        () => StyleSheet.flatten([{ color: styles.PRIMARY__CONTENT__COLOR, fontWeight: fontWeights.medium, fontSize: fontSizes.small, marginLeft: 5 }]),
        [styles],
    )

    const TextTU9 = useMemo(() => StyleSheet.flatten([{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.smallest }]), [styles])

    const ViewT31 = useMemo(
        () => StyleSheet.flatten([{ backgroundColor: glb_sv.getColor(stockInfo.t31, stockInfo, styles, 't31'), width: '100%', borderRadius: 4, padding: 5 }]),
        [styles, glb_sv.getColor(stockInfo.t31, stockInfo, styles, 't31')],
    )

    const ViewT31Oddlot = useMemo(
        () =>
            StyleSheet.flatten([
                { backgroundColor: glb_sv.getColor(stockInfo.t31_PO, stockInfo, styles, 't31_PO'), width: '100%', borderRadius: 4, padding: 5 },
            ]),
        [styles, glb_sv.getColor(stockInfo.t31_PO, stockInfo, styles, 't31_PO')],
    )

    const TextT31Ratio = useMemo(
        () =>
            StyleSheet.flatten([
                {
                    color: glb_sv.getColor(stockInfo.t31, stockInfo, styles, 't31'),
                    fontSize: fontSizes.smallest,
                    fontWeight: fontWeights.semiBold,
                    textAlign: 'center',
                },
            ]),
        [styles, glb_sv.getColor(stockInfo.t31, stockInfo, styles, 't31')],
    )

    const TextT31RatioOddlot = useMemo(
        () =>
            StyleSheet.flatten([
                {
                    color: glb_sv.getColor(stockInfo.t31_PO, stockInfo, styles, 't31_PO'),
                    fontSize: fontSizes.smallest,
                    fontWeight: fontWeights.semiBold,
                    textAlign: 'center',
                },
            ]),
        [styles, glb_sv.getColor(stockInfo.t31_PO, stockInfo, styles, 't31_PO')],
    )

    const TextT132 = useMemo(
        () =>
            StyleSheet.flatten([{ color: glb_sv.getColor(stockInfo.t132_1, stockInfo, styles, 't132_1'), fontSize: fontSizes.verySmall, textAlign: 'right' }]),
        [styles, glb_sv.getColor(stockInfo.t132_1, stockInfo, styles, 't132_1')],
    )

    const TextT133 = useMemo(
        () => StyleSheet.flatten([{ color: glb_sv.getColor(stockInfo.t133_1, stockInfo, styles, 't133_1'), fontSize: fontSizes.verySmall }]),
        [styles, glb_sv.getColor(stockInfo.t133_1, stockInfo, styles, 't133_1')],
    )

    const TextQty = useMemo(() => StyleSheet.flatten([{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.verySmall }]), [styles])

    return (
        <TouchableOpacity activeOpacity={0.6} style={TouchView} onPress={() => navigation.navigate(Screens.STOCK_INFO, { stockCode: stockInfo.t55 })}>
            <View style={UI.view_t55}>
                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <Text style={TextT55}>{t55}</Text>
                    {stockInfo.U34 === 'Y' && (
                        <AntDesign
                            color={styles.REF__COLOR}
                            name="star"
                            size={16}
                            onPress={() => {
                                navigation.navigate(Screens.RIGHT_INFO, { stockParam: stockInfo.t55, nameStock: stockInfo.U9 })
                            }}
                        />
                    )}
                </View>
                <Text numberOfLines={1} style={TextTU9}>
                    {stockInfo.U9}
                </Text>
            </View>

            <View style={UI.viewChart}>{isOddlot ? null : <SparklinesChart stockCode={t55} styles={styles} />}</View>
            <View style={UI.flex3}>
                <View style={isOddlot ? ViewT31Oddlot : ViewT31}>
                    <Text style={UI.textPrice}>
                        {/* {fractionPrice ? FormatNumber((stockInfo.t31 || stockInfo.t260) / 1000, 2, 0, '---') : FormatNumber(stockInfo.t31 || stockInfo.t260, 0, 0, '---')} */}
                        {renderT31()}
                    </Text>
                </View>
                <Text numberOfLines={1} style={isOddlot ? TextT31RatioOddlot : TextT31Ratio}>
                    {/* {stockInfo.t31 ? ((stockInfo.t31_incr > 0 ? '+' : '') +
                        (fractionPrice ? FormatNumber(stockInfo.t31_incr / 1000, 2) : FormatNumber(stockInfo.t31_incr)) + ' ' +
                        (stockInfo.t31_incr_per > 0 ? '+' : '') +
                        (FormatNumber(stockInfo.t31_incr_per, 2) + '%'))
                        : '---  ---'} */}
                    {renderT31Incr()}
                </Text>
            </View>
            {isFiveColumn ||
                (isSevenColumn && (
                    <Right style={UI.flex3}>
                        <Text style={TextT132}>
                            {stockInfo.t132_1 === 777777710000
                                ? 'ATO'
                                : stockInfo.t132_1 === 777777720000
                                ? 'ATC'
                                : stockInfo.t132_1
                                ? fractionPrice
                                    ? FormatNumber(stockInfo.t132_1 / 1000, 2)
                                    : FormatNumber(stockInfo.t132_1)
                                : '---'}
                        </Text>
                    </Right>
                ))}
            {isFiveColumn ||
                (isSevenColumn && (
                    <Right style={UI.flex3}>
                        <Text style={TextT133}>
                            {stockInfo.t133_1 === 777777710000
                                ? 'ATO'
                                : stockInfo.t133_1 === 777777720000
                                ? 'ATC'
                                : stockInfo.t133_1
                                ? fractionPrice
                                    ? FormatNumber(stockInfo.t133_1 / 1000, 2)
                                    : FormatNumber(stockInfo.t133_1)
                                : '---'}
                        </Text>
                    </Right>
                ))}
            {isSevenColumn && (
                <Right style={UI.flex3}>
                    <Text style={TextQty}>{fractionQty ? FormatNumberAC(stockInfo.t391, 0, 1) : FormatNumber(stockInfo.t391, 0, 0, 'short')}</Text>
                </Right>
            )}
            {isSevenColumn && (
                <Right style={UI.flex3}>
                    <Text style={TextQty}>{fractionQty ? FormatNumberAC(stockInfo.t3301, 0, 1) : FormatNumber(stockInfo.t3301, 0, 0, 'short')}</Text>
                </Right>
            )}
        </TouchableOpacity>
    )
}, areEqual)

function areEqual(prev, next) {
    if (!isFiveColumn && !isSevenColumn) {
        return prev.t260 === next.t260 && prev.t31 === next.t31 && prev.t31_incr === next.t31_incr && prev.t31_incr_per === next.t31_incr_per
    }
    if (isFiveColumn || isSevenColumn) {
        return (
            prev.t260 === next.t260 &&
            prev.t31 === next.t31 &&
            prev.t31_incr === next.t31_incr &&
            prev.t31_incr_per === next.t31_incr_per &&
            prev.t132_1 === next.t132_1 &&
            prev.t133_1 === next.t133_1
        )
    }
    if (isSevenColumn) {
        return (
            prev.t31 === next.t31 &&
            prev.t260 === next.t260 &&
            prev.t31_incr === next.t31_incr &&
            prev.t31_incr_per === next.t31_incr_per &&
            prev.t132_1 === next.t132_1 &&
            prev.t133_1 === next.t133_1 &&
            prev.t391 === next.t391 &&
            prev.t3301 === next.t3301
        )
    }
    return false
}

const StockItemSuggest = memo(({ t55, navigation, priceSuggest = 25000, typeSuggest = 'sell_upcase' }) => {
    const stockInfo = glb_sv.StockMarket[t55] || { TP: [], PO: [] }
    const { styles, fractionPrice } = useContext(StoreContext)
    const { t } = useTranslation()

    const TouchView = useMemo(
        () =>
            StyleSheet.flatten([
                {
                    flex: 1,
                    height: 60.5,
                    backgroundColor: styles.PRIMARY__BG__COLOR,
                    borderBottomColor: styles.BUTTON__SECONDARY,
                    borderBottomWidth: 1,
                    paddingTop: 5,
                },
            ]),
        [styles],
    )

    const TextT55 = useMemo(
        () => StyleSheet.flatten([{ color: styles.PRIMARY__CONTENT__COLOR, fontWeight: fontWeights.medium, fontSize: fontSizes.small }]),
        [styles],
    )

    const ButtonBuy = useMemo(
        () =>
            StyleSheet.flatten([
                {
                    borderColor: styles.UP__COLOR,
                    borderWidth: 1,
                    height: 32,
                    borderRadius: 32,
                    backgroundColor: styles.PRIMARY__BG__COLOR,
                    paddingHorizontal: dimensions.moderate(20),
                },
            ]),
        [styles],
    )

    const TextBuy = useMemo(() => StyleSheet.flatten([{ color: styles.UP__COLOR, fontSize: fontSizes.verySmall }]), [styles])

    const ButtonSell = useMemo(
        () => StyleSheet.flatten([{ backgroundColor: styles.DOWN__COLOR, height: 32, borderRadius: 32, paddingHorizontal: dimensions.moderate(20) }]),
        [styles],
    )

    const TextSecond = useMemo(() => StyleSheet.flatten([{ color: styles.PRIMARY__CONTENT__COLOR, opacity: 0.34 }]), [styles])

    return (
        <TouchableOpacity activeOpacity={0.6} style={TouchView} onPress={() => navigation.navigate(Screens.STOCK_INFO, { stockCode: stockInfo.t55 })}>
            <View style={UI.view_left_suggest}>
                <View style={UI.view_t55_suggest}>
                    <Text style={TextT55}>{t55}</Text>
                </View>
                <View style={UI.flex1}>
                    <Text style={[UI.textPriceSuggest, { color: glb_sv.getColor(stockInfo.t31, stockInfo, styles) }]}>
                        {fractionPrice ? FormatNumber((stockInfo.t31 || stockInfo.t260) / 1000, 2, 0) : FormatNumber(stockInfo.t31 || stockInfo.t260)}
                    </Text>
                </View>
                <View style={UI.flex1}>
                    <Text numberOfLines={1} style={{ color: glb_sv.getColor(stockInfo.t31, stockInfo, styles), ...UI.textPriceSuggest }}>
                        {stockInfo.t31_incr_per > 0 ? '+' : ''}
                        {FormatNumber(stockInfo.t31_incr_per, 2)}%
                    </Text>
                </View>
                <View style={UI.buy_sell_suggest}>
                    <Button style={ButtonBuy}>
                        <Text style={TextBuy}>{t('common_buy')}</Text>
                    </Button>
                    <Button style={ButtonSell}>
                        <Text style={UI.text_sell}>{t('common_sell')}</Text>
                    </Button>
                </View>
            </View>
            <Text style={{ fontSize: fontSizes.verySmall }}>
                <Text style={TextSecond}>{t('recommendations')} </Text>
                <Text style={{ color: typeSuggest === 'sell_upcase' ? styles.DOWN__COLOR : styles.UP__COLOR }}>{t(typeSuggest)} </Text>
                <Text style={TextSecond}>{t('price_lowcase')} </Text>
                <Text style={{ color: glb_sv.getColor(priceSuggest, stockInfo, styles) }}>
                    {fractionPrice ? FormatNumber(priceSuggest / 1000, 2, 0) : FormatNumber(priceSuggest)}
                </Text>
            </Text>
        </TouchableOpacity>
    )
}, areEqualSuggest)

function areEqualSuggest(prev, next) {
    return prev.t260 === next.t260 && prev.t31 === next.t31 && prev.t31_incr === next.t31_incr && prev.t31_incr_per === next.t31_incr_per
}

const UI = StyleSheet.create({
    backRightBtn: {
        alignItems: 'flex-end',
        bottom: 0,
        justifyContent: 'center',
        paddingRight: 17,
        position: 'absolute',
        top: 0,
        width: 500,
    },
    backRightBtnRight: {
        backgroundColor: 'red',
        borderBottomRightRadius: 5,
        borderTopRightRadius: 5,
        right: 0,
    },

    buy_sell_suggest: {
        flex: 1.8,
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
    flex1: {
        flex: 1,
    },
    flex3: {
        flex: 3,
    },
    rowBack: {
        alignItems: 'center',
        borderRadius: 5,
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
        margin: 5,
        marginBottom: 15,
        paddingLeft: 15,
    },
    swipe_list_view: {
        flex: 1,
        paddingHorizontal: dimensions.moderate(16),
    },
    textNewStock: {
        color: '#FFF',
        fontSize: fontSizes.small,
    },
    textPrice: {
        color: '#FFF',
        fontSize: fontSizes.small,
        fontWeight: fontWeights.semiBold,
        lineHeight: fontSizes.small + 2,
        textAlign: 'center',
    },
    textPriceSuggest: {
        fontSize: fontSizes.small,
        fontWeight: fontWeights.medium,
        lineHeight: fontSizes.small + 2,
        textAlign: 'left',
    },
    text_sell: {
        color: '#FFF',
        fontSize: fontSizes.verySmall,
    },
    trash: {
        height: 25,
        marginRight: 7,
        width: 25,
    },
    viewChart: {
        flex: 3,
        maxWidth: 100,
        minWidth: 100,
    },
    viewFooter: {
        alignItems: 'center',
        alignSelf: 'center',
        justifyContent: 'center',
        marginTop: dimensions.vertical(16),
    },
    view_left_suggest: {
        alignItems: 'center',
        flexDirection: 'row',
    },
    view_t55: {
        alignContent: 'flex-start',
        flex: 6,
        justifyContent: 'flex-start',
    },
    view_t55_suggest: {
        alignContent: 'flex-start',
        flex: 1,
        justifyContent: 'flex-start',
    },
})

//  B1: Get list stock into FAV active
//  B2: SUB all stock
//  B3: After receive msg SUBSCRIBE_DONE, handle get stock viewable [subrListCurrent] -> RESEND get EP
//  //////////
//  If receive msg SUB_STOCK, compare [subrListCurrent] with msgKey if true render list else skip
//  Handle the same for SparklinesChart

// hàm dùng để lọc những ở mảng arr1 không có ở mảng arr2
const filterArray = (arr1, arr2) => {
    const filtered = arr1.filter((el) => {
        return arr2.indexOf(el) >= 0
    })
    return filtered
}
