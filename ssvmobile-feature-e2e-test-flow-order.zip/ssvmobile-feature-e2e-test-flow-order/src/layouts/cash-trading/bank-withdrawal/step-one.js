import React, { useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { FlatList, Text, TouchableOpacity, View } from 'react-native'
import DateTimePickerModal from 'react-native-modal-datetime-picker'
import ToastGlobal from 'react-native-toast-message'
import ModalController from '@mts-components/appModal/modalControlller'
import moment from 'moment'
import { Row } from 'native-base'

import Account from '../../../components/account'
import { ButtonCustom, ColTableData, RowData, RowTableData, RowTitleGroup } from '../../../components/trading-component'
import EmptyView from '../../../components/trading-component/empty-view'
import HeaderList from '../../../components/trading-component/header-list'
import { StoreContext } from '../../../store'
import { StoreTrading } from '../../../store-trading'
import { dimensions as dm, fontSizes as fs, IconSvg } from '../../../styles'
import { eventList, FormatNumber, glb_sv, reqFunct, Screens, sendRequest } from '../../../utils'

// Khai báo ServiceInfo (nếu có)
const ServiceInfo = {
    GET_CURRENT_CASH_BY_SUB: {
        reqFunct: reqFunct.GET_CURRENT_CASH_BY_SUB,
        WorkerName: 'FOSqCash',
        ServiceName: 'FOSqCash_0201_2',
        ClientSentTime: '0',
        Operation: 'Q',
        // TestInput: ['1', userInfo.actn_curr, '00']
    },
    GET_HIS_PAY_ON_ACCOUT_BY_SUB: {
        reqFunct: reqFunct.GET_HIS_PAY_ON_ACCOUT_BY_SUB,
        WorkerName: 'FOSqCash',
        ServiceName: 'FOSqCash_0201_1',
        ClientSentTime: '0',
        Operation: 'Q',
        // TestInput: ["2", "888c000354", "00"]
    },
    GET_HIS_PAY_ON_ACCOUT_BY_ACT: {
        reqFunct: reqFunct.GET_HIS_PAY_ON_ACCOUT_BY_ACT,
        WorkerName: 'FOSqCash',
        ServiceName: 'FOSqCash_0201_1',
        ClientSentTime: '0',
        Operation: 'Q',
        // TestInput: ["2", "888c000354", "%"]
    },
    GET_WITHDRAW_HISTORY: {
        reqFunct: reqFunct.GET_WITHDRAW_HISTORY,
        WorkerName: 'FOSqCash',
        ServiceName: 'FOSqCash_0201_2',
        ClientSentTime: '0',
        Operation: 'Q',
    },
}

// Khai báo component
const StepOne = ({ navigation, currentSubCash, setCurrentSubCash, switchStep, hisWithDrawalList, setHisWithDrawalList, refreshing }) => {
    const { styles, theme, language } = useContext(StoreContext)
    const { userInfo } = useContext(StoreTrading)

    const { t } = useTranslation()

    const colSpan = [1, 1, 1, 1]
    // -------------------------------------------   Khai báo các state nội bộ component
    // -------------------------------------------   Dùng useEffect get các dữ liệu cần thiết còn thiếu
    useEffect(() => {
        // Prepare data
        getCurrentCashBySub() // Lấy số dư hiện tại
        getHisWithDrawal()

        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.LOGIN_SUCCESS) {
                // reCall service FOSq
                getCurrentCashBySub() // Lấy số dư hiện tại
                getHisWithDrawal()
            }
        })

        return () => {
            commonEvent.unsubscribe()
        }
    }, [userInfo.sub_curr, userInfo.actn_curr])

    useEffect(() => {
        getCurrentCashBySub()
        getHisWithDrawal()
    }, [glb_sv.checkLoadHistory])

    useEffect(() => {
        if (refreshing) {
            getCurrentCashBySub()
            getHisWithDrawal()
        }
    }, [refreshing])

    // -------------------------------------------   Viết các hàm để set lại bussiness form state. Nên viết đúng một chuẩn duy nhất để dễ control

    // -------------------------------------------   Khai báo các hàm gửi (request) lên server
    const getHisWithDrawal = () => {
        if (!userInfo.actn_curr) {
            ToastGlobal.show({
                type: 'warning',
                text2: t('warning_account_is_empty'),
            })
            return
        }
        // TODO
        // const from_dt = moment(glb_sv.objShareGlb.workDate, 'YYYYMMDD').subtract(12, 'months').format('YYYYMMDD')
        // const to_dt = glb_sv.objShareGlb.workDate
        const inputParams = ['2', userInfo.actn_curr, '%', moment(from_dt).format('YYYYMMDD'), moment(to_dt).format('YYYYMMDD')]
        sendRequest(ServiceInfo.GET_WITHDRAW_HISTORY, inputParams, handleGetHisWithDrawal)
    }
    const getCurrentCashBySub = () => {
        if (!userInfo.actn_curr) {
            ToastGlobal.show({
                type: 'warning',
                text2: t('warning_account_is_empty'),
            })
            return
        }

        const inputParams = ['1', userInfo.actn_curr, userInfo.sub_curr]
        sendRequest(ServiceInfo.GET_CURRENT_CASH_BY_SUB, inputParams, handleGetCurrentCashBySub)
    }

    // -------------------------------------------   Khai báo các hàm nhận (handle respone) dữ liệu từ server

    // -------------------------------------------   Khai báo các hàm nhận (handle respone) dữ liệu từ server
    const handleGetHisWithDrawal = (reqInfoMap, message) => {
        // -- process after get result --
        if (Number(message.Result) === 0) {
            setHisWithDrawalList([])
            return
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
                setHisWithDrawalList(jsondata)
                return
            } catch (err) {}
        }
    }

    const handleGetCurrentCashBySub = (reqInfoMap, message) => {
        // console.log("🚀 ~ file: step-one.js ~ line 154 ~ handleGetCurrentCashBySub ~ message", message)
        // -- process after get result --
        if (Number(message.Result) === 0) {
            // console.warn("false handleGetCurrentCashBySub", reqInfoMap, message['Data'], message['Message']);
            setCurrentSubCash({})
            return
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {}
            setCurrentSubCash(jsondata[0])
        }
    }
    // -----------------------------------------
    const getColor = (status) => {
        if (status === 'N') return styles.REF__COLOR
        if (status === 'R' || status === 'D') return styles.DOWN__COLOR
        if (status === 'Y') return styles.UP__COLOR
    }
    const getColorSub = (sub) => {
        const listColor = [styles.UP__COLOR, styles.REF__COLOR, styles.DOWN__COLOR]
        return listColor[Number(sub)] || styles.REF__COLOR
    }

    const ViewLastTransfer = ({ item, index }) => {
        return (
            <>
                <RowTableData
                    key={index}
                    type="table"
                    onPress={() =>
                        navigation.navigate(Screens.DETAIL_WITHDRAWAL, {
                            data: item,
                            onRefreshHist: () => {
                                getCurrentCashBySub()
                                getHisWithDrawal()
                            },
                        })
                    }
                >
                    <ColTableData colorSub={getColorSub(item.c3)} colSpan={colSpan[0]} dataSub={[item.c2, item.c3]} />
                    <ColTableData colSpan={colSpan[1]} text={moment(item.c0, 'DDMMYYYY').format('DD/MM/YYYY')} textAlign="right" />
                    <ColTableData colSpan={colSpan[1]} text={FormatNumber(item.c8, 0, 0)} textAlign="right" />
                    <ColTableData colorText={getColor(item.c24)} colSpan={colSpan[2]} text={item.c30} textAlign="right" />
                </RowTableData>
            </>
        )
    }

    const [from_dt, setFromDt] = useState(
        glb_sv.objShareGlb.workDate ? moment(glb_sv.objShareGlb.workDate, 'YYYYMMDD').add(-1, 'M').subtract(1, 'day').toDate() : moment().toDate(),
    )
    const [to_dt, setToDt] = useState(glb_sv.objShareGlb.workDate ? moment(glb_sv.objShareGlb.workDate, 'YYYYMMDD').toDate() : moment().toDate())

    const [isDatePickerFrom, setisDatePickerFrom] = useState(false)
    const [isDatePickerTo, setisDatePickerTo] = useState(false)
    useEffect(() => {
        if (moment(from_dt).diff(moment(to_dt), 'days') <= 0) {
            getHisWithDrawal()
        } else {
            ModalController.showModal({
                icon: <IconSvg.ErrorIcon color={styles.WARN__COLOR} />,
                title: t('common_notify'),
                content: t('error_date'),
                typeColor: styles.WARN__COLOR,
                showCancel: false,
                linkCallback: () => {
                    setHisWithDrawalList([])
                },
            })
        }
    }, [from_dt, to_dt])
    const hideDatePicker = () => {
        setisDatePickerFrom(false)
        setisDatePickerTo(false)
    }
    const FilterComponent = () => {
        return (
            <Row style={{ marginTop: dm.vertical(8), justifyContent: 'center' }}>
                <TouchableOpacity
                    style={{
                        justifyContent: 'flex-start',
                        borderRadius: 8,
                        backgroundColor: styles.BUTTON__THIRD,
                        padding: dm.moderate(8),
                        flexDirection: 'row',
                        alignItems: 'center',
                    }}
                    onPress={() => setisDatePickerFrom(true)}
                >
                    <View style={{ marginRight: dm.moderate(20) }}>
                        <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fs.normal }}>
                            {t('common_from_date')}
                            {'  '}
                        </Text>
                        <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fs.normal }}>{moment(from_dt).format('DD/MM/YYYY')}</Text>
                    </View>
                    <IconSvg.DateIcon color={styles.PRIMARY__CONTENT__COLOR} />
                </TouchableOpacity>
                <View style={{ width: dm.moderate(60) }} />
                <TouchableOpacity
                    style={{
                        justifyContent: 'flex-start',
                        borderRadius: 8,
                        backgroundColor: styles.BUTTON__THIRD,
                        padding: dm.moderate(8),
                        flexDirection: 'row',
                        alignItems: 'center',
                    }}
                    onPress={() => setisDatePickerTo(true)}
                >
                    <View style={{ marginRight: dm.moderate(20) }}>
                        <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fs.normal }}>
                            {t('common_to_date')}
                            {'  '}
                        </Text>
                        <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fs.normal }}>{moment(to_dt).format('DD/MM/YYYY')}</Text>
                    </View>
                    <IconSvg.DateIcon color={styles.PRIMARY__CONTENT__COLOR} />
                </TouchableOpacity>
            </Row>
        )
    }
    return (
        <View>
            <Account navigation={navigation} />
            <RowData rightColor={styles.PRIMARY} textLeft={t('cash_amount')} textRight={FormatNumber(Number(currentSubCash.c4), 0)} type="info" />

            <RowData
                last
                textLeft={t('cash_available')}
                textRight={glb_sv.activeCode === '081' ? FormatNumber(Number(currentSubCash.c7), 0) : FormatNumber(Number(currentSubCash.c5), 0)}
                type="bold"
            />

            <ButtonCustom
                text={t('continue')}
                type="confirm"
                onPress={() => {
                    if (!userInfo.actn_curr) {
                        ToastGlobal.show({
                            type: 'warning',
                            text2: t('warning_account_is_empty'),
                        })
                        return
                    }

                    switchStep.next()
                }}
            />
            <RowTitleGroup hasDivider text={t('transaction_history')} />
            <FilterComponent />
            <HeaderList colSpan={colSpan} typeHeader="BANK_WITHDRAWAL" />
            <FlatList
                data={hisWithDrawalList}
                keyExtractor={(item, index) => String(index)}
                ListEmptyComponent={EmptyView}
                renderItem={ViewLastTransfer}
                scrollEnabled={false}
                style={{ marginBottom: dm.vertical(32), paddingHorizontal: dm.moderate(16) }}
            />
            {isDatePickerFrom && (
                <DateTimePickerModal
                    cancelTextIOS={t('common_Cancel')}
                    confirmTextIOS={t('common_Ok')}
                    date={from_dt}
                    headerTextIOS=""
                    isDarkModeEnabled={theme.includes('DARK')}
                    isVisible={isDatePickerFrom}
                    locale={language === 'VI' ? 'vi_VN' : 'en_US'}
                    mode="date"
                    onCancel={hideDatePicker}
                    onConfirm={(value) => {
                        setisDatePickerFrom(false)
                        setFromDt(value)
                    }}
                />
            )}

            {isDatePickerTo && (
                <DateTimePickerModal
                    cancelTextIOS={t('common_Cancel')}
                    confirmTextIOS={t('common_Ok')}
                    date={to_dt}
                    headerTextIOS=""
                    isDarkModeEnabled={theme.includes('DARK')}
                    isVisible={isDatePickerTo}
                    locale={language === 'VI' ? 'vi_VN' : 'en_US'}
                    mode="date"
                    onCancel={hideDatePicker}
                    onConfirm={(value) => {
                        setisDatePickerTo(false)
                        setToDt(value)
                    }}
                />
            )}
        </View>
    )
}

export default StepOne
