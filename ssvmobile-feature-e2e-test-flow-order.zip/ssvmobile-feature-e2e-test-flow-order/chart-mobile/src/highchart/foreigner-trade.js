/* eslint-disable react-native/no-raw-text */
import React, { PureComponent } from 'react'
import { renderToString } from 'react-dom/server'
import Highcharts from 'highcharts'
import Treemap from 'highcharts/modules/treemap'
import { sum } from 'lodash'

import FormatNumber from '../formatNumber/FormatNumber'

Treemap(Highcharts)
export default class ForeignerTradeChart extends PureComponent {
    // constructor(props) {
    //     super(props);
    // }

    async componentDidMount() {
        // window.topFgrSell = [{ "CE": 67400, "CHGR": -1.59, "CHGV": -1000, "CP": 62000, "FBA": 21047148669, "FBV": 336000, "FL": 58600, "FSA": 246890570731, "FSV": 3941400, "MK": "HPG", "REF": 63000, "S": "HPG", "TVAL": 1851973690000, "TVOL": 29660200 }, { "CE": 137400, "CHGR": 0, "CHGV": 0, "CP": 128500, "FBA": 41110522328, "FBV": 321300, "FL": 119600, "FSA": 203671738070, "FSV": 1591800, "MK": "NVL", "REF": 128500, "S": "NVL", "TVAL": 540962270000, "TVOL": 4592900 }, { "CE": 38700, "CHGR": -1.1, "CHGV": -400, "CP": 35800, "FBA": 108098023934, "FBV": 3000000, "FL": 33700, "FSA": 108098023934, "FSV": 3000000, "MK": "ACB", "REF": 36200, "S": "ACB", "TVAL": 352291460000, "TVOL": 12777000 }, { "CE": 99500, "CHGR": -1.94, "CHGV": -1800, "CP": 91200, "FBA": 57480063957, "FBV": 618900, "FL": 86500, "FSA": 84905920940, "FSV": 914200, "MK": "VNM", "REF": 93000, "S": "VNM", "TVAL": 389794520000, "TVOL": 4282000 }, { "CE": 141700, "CHGR": -1.13, "CHGV": -1500, "CP": 131000, "FBA": 19626167686, "FBV": 148400, "FL": 123300, "FSA": 76811847655, "FSV": 580800, "MK": "VIC", "REF": 132500, "S": "VIC", "TVAL": 153967550000, "TVOL": 1164200 }, { "CE": 20350, "CHGR": 5.77, "CHGV": 1100, "CP": 20150, "FBA": 60932931235, "FBV": 3066500, "FL": 17750, "FSA": 60984594571, "FSV": 3069100, "MK": "SBT", "REF": 19050, "S": "SBT", "TVAL": 85123295000, "TVOL": 7283900 }, { "CE": 106000, "CHGR": -1.11, "CHGV": -1100, "CP": 98000, "FBA": 87549502392, "FBV": 885200, "FL": 92200, "FSA": 60074071117, "FSV": 607400, "MK": "VHM", "REF": 99100, "S": "VHM", "TVAL": 310814580000, "TVOL": 3242600 }, { "CE": 108700, "CHGR": -0.1, "CHGV": -100, "CP": 101500, "FBA": 55974821048, "FBV": 535600, "FL": 94500, "FSA": 51930337153, "FSV": 496900, "MK": "MSN", "REF": 101600, "S": "MSN", "TVAL": 354911300000, "TVOL": 3396000 }, { "CE": 104900, "CHGR": -0.2, "CHGV": -200, "CP": 97900, "FBA": 23496484220, "FBV": 238400, "FL": 91300, "FSA": 43208299841, "FSV": 438400, "MK": "VCB", "REF": 98100, "S": "VCB", "TVAL": 115461960000, "TVOL": 1271500 }, { "CE": 66600, "CHGR": 1.12, "CHGV": 700, "CP": 63000, "FBA": 215513873975, "FBV": 3456100, "FL": 58000, "FSA": 40862892166, "FSV": 655300, "MK": "VPB", "REF": 62300, "S": "VPB", "TVAL": 1530341190000, "TVOL": 24541400 }, { "CE": 33950, "CHGR": -2.36, "CHGV": -750, "CP": 31000, "FBA": 7553927213, "FBV": 240200, "FL": 29550, "FSA": 40618869229, "FSV": 1291600, "MK": "VRE", "REF": 31750, "S": "VRE", "TVAL": 160849590000, "TVOL": 5114700 }, { "CE": 35500, "CHGR": -1.51, "CHGV": -500, "CP": 32700, "FBA": 55059483492, "FBV": 1663500, "FL": 30900, "FSA": 37348434729, "FSV": 1128400, "MK": "MBB", "REF": 33200, "S": "MBB", "TVAL": 674717810000, "TVOL": 25385100 }, { "CE": 161000, "CHGR": 1.13, "CHGV": 1700, "CP": 152200, "FBA": 13013403612, "FBV": 85000, "FL": 140000, "FSA": 36437530113, "FSV": 238000, "MK": "SAB", "REF": 150500, "S": "SAB", "TVAL": 36452840000, "TVOL": 295100 }, { "CE": 26000, "CHGR": 1.44, "CHGV": 350, "CP": 24650, "FBA": 80903186218, "FBV": 3221400, "FL": 22600, "FSA": 35137408530, "FSV": 1399100, "MK": "STB", "REF": 24300, "S": "STB", "TVAL": 1456930415000, "TVOL": 58012000 }, { "CE": 41600, "CHGR": -1.03, "CHGV": -400, "CP": 38500, "FBA": 472804764, "FBV": 12000, "FL": 36200, "FSA": 32325819341, "FSV": 820444, "MK": "NLG", "REF": 38900, "S": "NLG", "TVAL": 175154465000, "TVOL": 4465544 }, { "CE": 21450, "CHGR": 4.99, "CHGV": 1000, "CP": 21050, "FBA": 909920002, "FBV": 43600, "FL": 18650, "FSA": 31475718977, "FSV": 1508200, "MK": "CII", "REF": 20050, "S": "CII", "TVAL": 92298445000, "TVOL": 4422600 }, { "CE": 38300, "CHGR": 0.28, "CHGV": 100, "CP": 35900, "FBA": 2373039217, "FBV": 66800, "FL": 33300, "FSA": 29172751571, "FSV": 821200, "MK": "KBC", "REF": 35800, "S": "KBC", "TVAL": 293709785000, "TVOL": 8267800 }, { "CE": 23300, "CHGR": -0.69, "CHGV": -150, "CP": 21650, "FBA": 729007857, "FBV": 33300, "FL": 20300, "FSA": 27319186318, "FSV": 1247900, "MK": "LPB", "REF": 21800, "S": "LPB", "TVAL": 456479325000, "TVOL": 22731300 }, { "CE": 44250, "CHGR": 1.69, "CHGV": 700, "CP": 42100, "FBA": 1165638398, "FBV": 27300, "FL": 38550, "FSA": 19939675165, "FSV": 467000, "MK": "BID", "REF": 41400, "S": "BID", "TVAL": 228401080000, "TVOL": 5349300 }, { "CE": 57000, "CHGR": -0.56, "CHGV": -300, "CP": 53000, "FBA": 8547529449, "FBV": 160400, "FL": 49600, "FSA": 19423781074, "FSV": 364500, "MK": "PLX", "REF": 53300, "S": "PLX", "TVAL": 91225160000, "TVOL": 1711900 }, { "CE": 0, "CHGR": 0, "CHGV": 0, "CP": 0, "FBA": 1362404243281, "FBV": 38370600, "FL": 0, "FSA": 366877460083, "FSV": 14263575, "MK": "OTHERS", "REF": 0, "S": "OTHERS", "TVAL": 0, "TVOL": 0 }];
        // window.topFgrBuy = [{ "CE": 66600, "CHGR": 1.12, "CHGV": 700, "CP": 63000, "FBA": 215513873975, "FBV": 3456100, "FL": 58000, "FSA": 40862892166, "FSV": 655300, "MK": "VPB", "REF": 62300, "S": "VPB", "TVAL": 1530341190000, "TVOL": 24541400 }, { "CE": 38700, "CHGR": -1.1, "CHGV": -400, "CP": 35800, "FBA": 108098023934, "FBV": 3000000, "FL": 33700, "FSA": 108098023934, "FSV": 3000000, "MK": "ACB", "REF": 36200, "S": "ACB", "TVAL": 352291460000, "TVOL": 12777000 }, { "CE": 24150, "CHGR": 1.55, "CHGV": 350, "CP": 22950, "FBA": 99563909257, "FBV": 4300200, "FL": 21050, "FSA": 129658595, "FSV": 5600, "MK": "MSB", "REF": 22600, "S": "MSB", "TVAL": 309793745000, "TVOL": 17680100 }, { "CE": 106000, "CHGR": -1.11, "CHGV": -1100, "CP": 98000, "FBA": 87549502392, "FBV": 885200, "FL": 92200, "FSA": 60074071117, "FSV": 607400, "MK": "VHM", "REF": 99100, "S": "VHM", "TVAL": 310814580000, "TVOL": 3242600 }, { "CE": 26000, "CHGR": 1.44, "CHGV": 350, "CP": 24650, "FBA": 80903186218, "FBV": 3221400, "FL": 22600, "FSA": 35137408530, "FSV": 1399100, "MK": "STB", "REF": 24300, "S": "STB", "TVAL": 1456930415000, "TVOL": 58012000 }, { "CE": 20350, "CHGR": 5.77, "CHGV": 1100, "CP": 20150, "FBA": 60932931235, "FBV": 3066500, "FL": 17750, "FSA": 60984594571, "FSV": 3069100, "MK": "SBT", "REF": 19050, "S": "SBT", "TVAL": 85123295000, "TVOL": 7283900 }, { "CE": 99500, "CHGR": -1.94, "CHGV": -1800, "CP": 91200, "FBA": 57480063957, "FBV": 618900, "FL": 86500, "FSA": 84905920940, "FSV": 914200, "MK": "VNM", "REF": 93000, "S": "VNM", "TVAL": 389794520000, "TVOL": 4282000 }, { "CE": 108700, "CHGR": -0.1, "CHGV": -100, "CP": 101500, "FBA": 55974821048, "FBV": 535600, "FL": 94500, "FSA": 51930337153, "FSV": 496900, "MK": "MSN", "REF": 101600, "S": "MSN", "TVAL": 354911300000, "TVOL": 3396000 }, { "CE": 35500, "CHGR": -1.51, "CHGV": -500, "CP": 32700, "FBA": 55059483492, "FBV": 1663500, "FL": 30900, "FSA": 37348434729, "FSV": 1128400, "MK": "MBB", "REF": 33200, "S": "MBB", "TVAL": 674717810000, "TVOL": 25385100 }, { "CE": 41900, "CHGR": -3.7, "CHGV": -1450, "CP": 37750, "FBA": 46954331718, "FBV": 1216500, "FL": 36500, "FSA": 18712256487, "FSV": 484800, "MK": "HSG", "REF": 39200, "S": "HSG", "TVAL": 996481695000, "TVOL": 25817000 }, { "CE": 137400, "CHGR": 0, "CHGV": 0, "CP": 128500, "FBA": 41110522328, "FBV": 321300, "FL": 119600, "FSA": 203671738070, "FSV": 1591800, "MK": "NVL", "REF": 128500, "S": "NVL", "TVAL": 540962270000, "TVOL": 4592900 }, { "CE": 37100, "CHGR": -1.44, "CHGV": -500, "CP": 34200, "FBA": 37877730521, "FBV": 1086600, "FL": 32300, "FSA": 12298236083, "FSV": 352800, "MK": "SSI", "REF": 34700, "S": "SSI", "TVAL": 559231610000, "TVOL": 16042700 }, { "CE": 60000, "CHGR": -0.18, "CHGV": -100, "CP": 56000, "FBA": 30138481571, "FBV": 533400, "FL": 52200, "FSA": 3497510329, "FSV": 61900, "MK": "BVH", "REF": 56100, "S": "BVH", "TVAL": 58463230000, "TVOL": 1034700 }, { "CE": 34300, "CHGR": -1.87, "CHGV": -600, "CP": 31500, "FBA": 27882231343, "FBV": 870900, "FL": 29900, "FSA": 9434944973, "FSV": 294700, "MK": "NKG", "REF": 32100, "S": "NKG", "TVAL": 300051740000, "TVOL": 9372100 }, { "CE": 104900, "CHGR": -0.2, "CHGV": -200, "CP": 97900, "FBA": 23496484220, "FBV": 238400, "FL": 91300, "FSA": 43208299841, "FSV": 438400, "MK": "VCB", "REF": 98100, "S": "VCB", "TVAL": 115461960000, "TVOL": 1271500 }, { "CE": 67400, "CHGR": -1.59, "CHGV": -1000, "CP": 62000, "FBA": 21047148669, "FBV": 336000, "FL": 58600, "FSA": 246890570731, "FSV": 3941400, "MK": "HPG", "REF": 63000, "S": "HPG", "TVAL": 1851973690000, "TVOL": 29660200 }, { "CE": 141700, "CHGR": -1.13, "CHGV": -1500, "CP": 131000, "FBA": 19626167686, "FBV": 148400, "FL": 123300, "FSA": 76811847655, "FSV": 580800, "MK": "VIC", "REF": 132500, "S": "VIC", "TVAL": 153967550000, "TVOL": 1164200 }, { "CE": 91800, "CHGR": -0.7, "CHGV": -600, "CP": 85200, "FBA": 17698826384, "FBV": 205300, "FL": 79800, "FSA": 17914350330, "FSV": 207800, "MK": "FPT", "REF": 85800, "S": "FPT", "TVAL": 179203850000, "TVOL": 2284000 }, { "CE": 28750, "CHGR": 2.97, "CHGV": 800, "CP": 27700, "FBA": 15133661229, "FBV": 544700, "FL": 25050, "FSA": 227824531, "FSV": 8200, "MK": "DIG", "REF": 26900, "S": "DIG", "TVAL": 208915095000, "TVOL": 7549400 }, { "CE": 161000, "CHGR": 1.13, "CHGV": 1700, "CP": 152200, "FBA": 13013403612, "FBV": 85000, "FL": 140000, "FSA": 36437530113, "FSV": 238000, "MK": "SAB", "REF": 150500, "S": "SAB", "TVAL": 36452840000, "TVOL": 295100 }, { "CE": 0, "CHGR": 0, "CHGV": 0, "CP": 0, "FBA": 247349458492, "FBV": 12036700, "FL": 0, "FSA": 1653514931308, "FSV": 38845219, "MK": "OTHERS", "REF": 0, "S": "OTHERS", "TVAL": 0, "TVOL": 0 }]
        this.chart = Highcharts.chart('chart', {
            chart: {
                animation: false,
                type: 'treemap',
                margin: 0,
            },
            series: [
                {
                    type: 'treemap',
                    layoutAlgorithm: 'stripes',
                    alternateStartingDirection: true,
                    levels: [
                        {
                            level: 1,
                            layoutAlgorithm: 'squarified',
                            alternateStartingDirection: true,
                            borderWidth: 4,
                            borderColor: window.theme === 'LIGHT' ? '#F8F8F8' : '#3A3A3A',
                            dataLabels: {
                                enabled: true,
                                align: 'left',
                                verticalAlign: 'top',
                                className: 'label_treemap',
                                padding: 0,
                                useHTML: true,
                                formatter() {
                                    return renderToString(<SectionTitle node={this} />)
                                },
                            },
                        },
                        {
                            level: 2,
                            layoutAlgorithm: 'squarified',
                            dataLabels: {
                                enabled: true,
                                padding: 0,
                                x: 0,
                                y: 0,
                                className: 'label_treemap_item',
                                absoluteBox: {
                                    y: 0,
                                },
                                style: {
                                    textShadow: false,
                                    textOutline: false,
                                    color: '#25253e',
                                    whiteSpace: 'normal',
                                    fontSize: '12px',
                                    fontWeight: 'normal',
                                },
                            },
                        },
                    ],
                    data: convertDataTreeMap(window.topFgrBuy, window.topFgrSell),
                },
            ],
            title: {
                text: '',
            },
            tooltip: {
                enabled: true,
                formatter: function (node) {
                    // console.log(node, 'node', this)
                    return renderToString(<TooltipComponent node={this} />)
                },
            },
            credits: { enabled: false },
        })

        this.eventMarket = window.eventMarket.subscribe((msg) => {
            if (msg.type === 'highchart-history') {
                this.chart.series[0].setData(convertDataTreeMap(window.topFgrBuy, window.topFgrSell))
            }
            if (msg.type === 'highchart-realtime') {
                this.chart.series[0].setData(convertDataTreeMap(window.topFgrBuy, window.topFgrSell))
            }
            if (msg.type === 'change-language') {
                this.chart.redraw(false)
            }
        })
    }

    componentWillUnmount() {
        this.eventMarket.unsubscribe()
    }

    render() {
        return <div id="chart" style={{ height: 'calc(100vh)', width: 'calc(100vw)' }} />
    }
}

const SectionTitle = ({ node }) => {
    const { level } = node.point.node
    if (node.point.shapeArgs && level === 1) {
        const { width } = node.point.shapeArgs
        return (
            <div
                style={{
                    width: `${width}px`,
                    height: `${0}px`,
                    cursor: 'pointer',
                }}
            >
                <div className="title_group_treemap">
                    {node.point.options.name}: {FormatNumber(node.point.value, 0, 0, 'short')}
                </div>
            </div>
        )
    }
    if (node.point.shapeArgs && level === 2) {
        return <span />
    }
    return <span />
}

const TooltipComponent = ({ node }) => {
    if (node.point.node.level === 1) return null
    return (
        <div className="flex flex-direction-row" style={{ fontSize: 14 }}>
            <div className="flex-1">
                <span>{window.short_symbol}: </span>
                <span style={{ fontWeight: 'bold' }}>{node.point.renderName}</span>
            </div>
            <br />
            <div className="flex-1">
                <span>{window.head_current_right}: </span>
                <span>{FormatNumber(node.point.nodeData.CP)}</span>
                <br />

                <span>{window.priceboard_total_value_foreign_buy}: </span>
                <span>{FormatNumber(node.point.nodeData.FBA, 0, 0, 'short')}</span>
                <br />
                <span>{window.priceboard_total_value_foreign_sell}: </span>
                <span>{FormatNumber(node.point.nodeData.FSA, 0, 0, 'short')}</span>
                <br />
                <span>{window.trade_total_net_value}: </span>
                <span>{FormatNumber(node.point.nodeData.FBA - node.point.nodeData.FSA, 0, 0, 'short')}</span>
                <br />
            </div>
        </div>
    )
}

const getRenderLabelText = (item, index) => {
    // if (index < 100) {
    //     const val = FormatNumber(item.CHGR, 2)
    //     if (val === '0.00') return item.S
    //     return `${item.S} (${val}%)`
    // }
    return item.S
}

const getColor = (value, ref, ceil, floor) => {
    if (value === 0) return '#e2ae02'
    if (value === ceil) return '#f618fb'
    if (value === floor) return '#00d3b8'
    if (value > ref) return '#2ECC71'
    if (value < ref) return '#EB5C55'
    return '#e2ae02'
}

const convertDataTreeMap = (topFgrBuy, topFgrSell) => {
    const totalBuy = sum(topFgrBuy.map((item) => item.FBA))
    const totalSell = sum(topFgrSell.map((item) => item.FSA))
    const newData = [
        {
            id: 'Buy',
            name: window.priceboard_total_value_foreign_buy,
            sortIndex: 0,
            value: totalBuy || null,
            color: '#2ECC71',
        },
        {
            id: 'Sell',
            name: window.priceboard_total_value_foreign_sell,
            sortIndex: 1,
            value: totalSell || null,
            color: '#e2ae02',
        },
    ]
    topFgrBuy.forEach((item, index) => {
        newData.push({
            parent: 'Buy',
            name: getRenderLabelText(item, index), // item.S + ` (${FormatNumber(item.CHGR, 2)}%)`,
            renderName: item.S + ` (${FormatNumber(item.CHGR, 2)}%)`,
            value: item.FBA,
            color: getColor(item.CP || item.CHGR, item.REF || 0, item.CE, item.FL),
            nodeData: item,
        })
    })
    topFgrSell.forEach((item, index) => {
        newData.push({
            parent: 'Sell',
            name: getRenderLabelText(item, index), //item.S + ` (${FormatNumber(item.CHGR, 2)}%)`,
            renderName: item.S + ` (${FormatNumber(item.CHGR, 2)}%)`,
            value: item.FSA,
            color: getColor(item.CP || item.CHGR, item.REF || 0, item.CE, item.FL),
            nodeData: item,
        })
    })

    return newData
}
