import React, { useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { InteractionManager, Keyboard, Pressable, StyleSheet, View } from 'react-native'
import Modal from 'react-native-modal'
import { SafeAreaView } from 'react-native-safe-area-context'
import ToastGlobal from 'react-native-toast-message'

import IconArrowRight from '../../../assets/images/common/ic_arrow_right.svg'
import { CustomFloatInput, Text } from '../../../basic-components'
import ModalSelection from '../../../components/list-selections'
import ModalLoading from '../../../components/modal-loading'
import { ButtonCustom, RowData, RowTitleGroup } from '../../../components/trading-component'
import { useLoading, useUpdateEffect } from '../../../hoc'
import { StoreContext } from '../../../store'
import { StoreTrading } from '../../../store-trading'
import { dimensions as dm, fontSizes as fs, fontWeights as fw } from '../../../styles'
import { glb_sv, reqFunct, sendRequest } from '../../../utils'
import FormatNumber from '../../../utils/formatNumber/FormatNumber'

// Khai báo ServiceInfo (nếu có)
const ServiceInfo = {
    getListBankTran: {
        reqFunct: reqFunct.GET_LIST_BANK_TRANS, //Lấy DS ngân hàng chuyển
        WorkerName: 'FOSqCash',
        ServiceName: 'FOSqCash_Common',
        ClientSentTime: '0',
        Operation: 'Q',
    },
    GET_BANK_ACCOUNT_LIST: {
        reqFunct: reqFunct.GET_BANK_ACCOUNT_LIST, // Lấy list danh sách ngân hàng
        WorkerName: 'FOSqAccount',
        ServiceName: 'FOSqAccount_Common',
        ClientSentTime: '0',
        Operation: 'Q',
    },
    CHECK_OTHER_BANK_ACCOUNT: {
        reqFunct: reqFunct.CHECK_OTHER_BANK_ACCOUNT, // Check STK NH có cùng chủ tài khoản
        WorkerName: 'FOSqCash',
        ServiceName: 'FOSqCash_0201_2',
        ClientSentTime: '0',
        Operation: 'Q',
    },
}

// Khai báo component
const StepTwo = ({
    navigation,
    actReceive,
    setActReceive,
    amountWithDrawal,
    setAmountWithDrawal,
    switchStep,
    currentSubCash,
    errCtrl,
    setErrCtrl,
    _validateValue,
}) => {
    const { t } = useTranslation()
    const { styles } = useContext(StoreContext)
    const { userInfo } = useContext(StoreTrading)

    const [isOpenModalSelection, setIsOpenModalSelection] = useState(false)
    const [infoSelection, setInfoSelection] = useState({
        type: '',
        callback: () => {},
    })

    //#region Modal Thêm mới NH cùng chủ TK
    const [isModalOtherBank, setIsModalOtherBank] = useState(false)
    const [otherBankAcntNum, setOtherBankAcntNum] = useState('')
    const [listBankAccount, setListBankAccount] = useState([])
    const [otherBankSelected, setOtherBankSelected] = useState({})
    const [isOpenModalOtherBankSelection, setIsOpenModalOtherBankSelection] = useState(false)
    const [otherBankInfoSelection, setOtherBankInfoSelection] = useState({
        type: '',
        callback: () => {},
    })
    const [errorText, setErrorText] = useState('')
    const [checkOtherBankFlag, setCheckOtherBankFlag] = useLoading(false)
    //#endregion

    const TAG = 'BankWithDrawal_StepTwo'

    useEffect(() => {
        // console.log(TAG, 'useEffect userInfo: ', userInfo)
        getListBankTran()
    }, [userInfo.sub_curr, userInfo.actn_curr])

    useUpdateEffect(() => {
        _validateValue(0)
    }, [actReceive])
    useUpdateEffect(() => {
        _validateValue(1)
    }, [amountWithDrawal])

    useEffect(() => {
        getBankAccount()

        return () => {
            // second
        }
    }, [])

    const getBankAccount = () => {
        setListBankAccount([])
        const inputParams = ['25', '%'] // input: 25 => Lấy danh sách ngân hàng thuộc Napas
        sendRequest(ServiceInfo.GET_BANK_ACCOUNT_LIST, inputParams, handleGetBankAccount)
    }

    const handleGetBankAccount = (reqInfoMap, message) => {
        // console.log('handleGetBankAccount: ', message)
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {}
            const listBank = jsondata.map((item, index) => ({ index, value: item.c0, label: item.c1 + ' ' + item.c3, data: item }))
            setListBankAccount(listBank)
        }
    }

    const checkOtherBank = (bankAcntNum, bankCode) => {
        //Kiểm tra xác thực tài khoản ngân hàng nhận chuyển tiền
        setErrorText('')
        setCheckOtherBankFlag(true)
        const inputParams = ['4', bankAcntNum, bankCode, userInfo.actn_name]
        sendRequest(ServiceInfo.CHECK_OTHER_BANK_ACCOUNT, inputParams, handleCheckOtherBank, true, handleCheckOtherBankTimeout)
    }

    const handleCheckOtherBank = (reqInfoMap, message) => {
        // console.log('handleCheckOtherBank: ', reqInfoMap, message)
        setCheckOtherBankFlag(false)
        if (Number(message.Result) === 0) {
            setErrorText(message.Message)
            return
        } else {
            // Check tài khoản ok => Đóng Modal Thêm TK Khác + Đóng Modal chọn tài khoản
            setIsModalOtherBank(false)
            setIsOpenModalSelection(false)
            const fakeAccountReceive = {
                label: otherBankAcntNum + ' - ' + otherBankSelected.data.c1, // SKT + Tên NH
                value: {
                    c1: otherBankSelected.value, // Mã NH
                    c3: otherBankAcntNum, // STK
                    c6: otherBankSelected.data.c1 + ' ' + otherBankSelected.data.c3, // Tên
                },
            }
            if (glb_sv.withdrawalBankList.findIndex(({ value }) => value.c1 === otherBankSelected.value && value.c3 === otherBankAcntNum) === -1) {
                glb_sv.withdrawalBankList.push(fakeAccountReceive)
            }
            setActReceive(fakeAccountReceive)
            setOtherBankAcntNum('')
            setOtherBankSelected({})
        }
    }

    const handleCheckOtherBankTimeout = () => {
        setErrorText(t('request_hanlde_not_success_try_again'))
        setCheckOtherBankFlag(false)
    }

    const hideModalOtherBank = () => {
        setIsModalOtherBank(false)
        InteractionManager.runAfterInteractions(() => {
            // Mở modal chọn ngân hàng chuyển
            setIsOpenModalSelection(true)
        })
    }

    const callBackSelectBankInModalOtherBank = (value) => {
        setOtherBankSelected(value)
    }

    const validateCheckBank = () => {
        if (!otherBankAcntNum || !otherBankAcntNum.trim()) {
            setErrorText(t('warning_bank_acc_number_is_empty'))
            return false
        }
        if (!otherBankSelected || !otherBankSelected.value) {
            setErrorText(t('common_plz_input_your_bank_info'))
            return false
        }
        return true
    }

    const selectActReceive = (value) => {
        setActReceive(value)
    }

    const getListBankTran = () => {
        const inputParams = ['03', userInfo.actn_curr]
        sendRequest(ServiceInfo.getListBankTran, inputParams, handleGetListBankTran)
    }

    const handleGetListBankTran = (reqInfoMap, message) => {
        // console.log(TAG, 'handleGetListBankTran message: ', message)
        let ListBankTranTemp = []
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata
            try {
                jsondata = JSON.parse(message.Data)
            } catch (err) {
                // glb_sv.logMessage(err);
                jsondata = []
            }
            ListBankTranTemp = ListBankTranTemp.concat(jsondata)
            if (Number(message.Packet) <= 0) {
                const bankTransferList = ListBankTranTemp.map((item) => {
                    const label = item.c3 + ' - ' + item.c6
                    const value = item
                    return { label, value }
                })
                glb_sv.withdrawalBankList = bankTransferList
                if (bankTransferList.length == 1) {
                    setActReceive(bankTransferList[0])
                }
            }
        }
    }

    const onPressWithDrawal = (amount) => {
        setAmountWithDrawal(amount)
    }

    const fullWithdawAction = () => {
        // console.log('fullWithdawAction')
        if (currentSubCash) {
            setAmountWithDrawal(currentSubCash.c5)
            Keyboard.dismiss()
            switchStep.onFinish()
        }
    }

    return (
        <View>
            <View style={{ flex: 1, marginRight: dm.halfIndent }}>
                <View style={[UI.GroupInput, { borderColor: styles.PRIMARY__BORDER__COLOR }]}>
                    <RowTitleGroup text={t('receive_account_information')} type="group" />
                    <Pressable
                        onPress={() => {
                            setInfoSelection({ type: 'PICK_WITHDRAWAL_ACCOUNT_RECEIVE', callback: selectActReceive })
                            setIsOpenModalSelection(true)
                        }}
                    >
                        <View pointerEvents="none" style={UI.RowInput}>
                            <CustomFloatInput
                                animationDuration={100}
                                editable={false}
                                errCtrl={t(errCtrl[0])}
                                label={t('choose_heir_bank')}
                                numberOfLines={1}
                                rightComponent={
                                    <IconArrowRight style={{ color: styles.PRIMARY__CONTENT__COLOR, marginVertical: dm.vertical(20), marginRight: 5 }} />
                                }
                                value={actReceive?.value?.c6}
                            />
                        </View>
                    </Pressable>

                    <RowData textLeft={t('acc_number_full')} textRight={actReceive?.value?.c3} />

                    <RowData textLeft={t('cash_amount')} textRight={FormatNumber(currentSubCash.c4, 0, 0)} />

                    <RowData
                        textLeft={t('cash_available')}
                        textRight={glb_sv.activeCode === '081' ? FormatNumber(Number(currentSubCash.c7), 0) : FormatNumber(Number(currentSubCash.c5), 0)}
                    />

                    <RowData textLeft={t('pia_available')} textRight={FormatNumber(currentSubCash.c11, 0, 0)} />

                    <Pressable onPress={fullWithdawAction}>
                        <RowData
                            last
                            rightColor={styles.PRIMARY}
                            textLeft={t('withdrawal_available_qty')}
                            textRight={FormatNumber(currentSubCash.c5, 0, 0)}
                            type="bold"
                        />
                    </Pressable>

                    <View style={UI.RowInput}>
                        <View style={UI.RowInput}>
                            <CustomFloatInput
                                animationDuration={100}
                                errCtrl={errCtrl[1]}
                                keyboardType="number-pad"
                                label={t('cash_amount_drawal')}
                                placeholderTextColor={styles.PLACEHODLER__COLOR}
                                value={FormatNumber(amountWithDrawal) == '0' ? '' : FormatNumber(amountWithDrawal)}
                                onChangeText={(amount) => onPressWithDrawal(glb_sv.filterNumber(amount))}
                            />
                        </View>
                    </View>

                    <ButtonCustom
                        disabled={checkOtherBankFlag}
                        text={t('common_confirm')}
                        type="confirm"
                        onPress={() => {
                            if (actReceive?.value) {
                                Keyboard.dismiss()
                                switchStep.onFinish()
                            } else {
                                ToastGlobal.show({
                                    text2: t('warning_heir_account'),
                                    type: 'warning',
                                })
                            }
                        }}
                    />

                    <ButtonCustom disabled={checkOtherBankFlag} last text={t('common_back')} type="back" onPress={() => switchStep.prev()} />
                </View>
            </View>

            {isOpenModalSelection ? (
                <ModalSelection
                    actionType={infoSelection.type}
                    callBackOtherFunction={() => {
                        setIsModalOtherBank(true)
                    }}
                    getSelectValue={infoSelection.callback}
                    isOpen={isOpenModalSelection}
                    setIsOpen={setIsOpenModalSelection}
                />
            ) : null}

            {isModalOtherBank ? (
                <>
                    <Modal
                        animationIn="slideInUp"
                        animationOut="slideOutDown"
                        hideModalContentWhileAnimating={true}
                        isVisible={isModalOtherBank}
                        style={UI.ModalOtherBank}
                        useNativeDriver={true}
                        onBackButtonPress={hideModalOtherBank}
                        onBackdropPress={hideModalOtherBank}
                    >
                        <View
                            style={{
                                flex: 1,
                                backgroundColor: styles.PRIMARY__BG__COLOR,
                            }}
                        >
                            <SafeAreaView style={{ flex: 1 }}>
                                <RowTitleGroup text={t('add_new_bank_account')} type="group" />
                                <View style={UI.RowInputOtherBank}>
                                    <CustomFloatInput
                                        animationDuration={100}
                                        keyboardType="number-pad"
                                        label={t('input_bank_acc_number')}
                                        placeholderTextColor={styles.PLACEHODLER__COLOR}
                                        value={otherBankAcntNum}
                                        onChangeText={(acc) => setOtherBankAcntNum(acc)}
                                    />
                                </View>
                                <View style={UI.RowInputOtherBank}>
                                    <Pressable
                                        onPress={() => {
                                            setOtherBankInfoSelection({ type: 'PICK_BANK_EKYC', callback: callBackSelectBankInModalOtherBank })
                                            setIsOpenModalOtherBankSelection(true)
                                        }}
                                    >
                                        <View pointerEvents="none">
                                            <CustomFloatInput
                                                animationDuration={100}
                                                editable={false}
                                                errCtrl={t(errCtrl[0])}
                                                label={t('bank_cd')}
                                                numberOfLines={1}
                                                rightComponent={
                                                    <IconArrowRight
                                                        style={{ color: styles.PRIMARY__CONTENT__COLOR, marginVertical: dm.vertical(20), marginRight: 5 }}
                                                    />
                                                }
                                                value={otherBankSelected.label}
                                            />
                                        </View>
                                    </Pressable>
                                </View>
                                <View style={UI.RowWarning}>
                                    <Text style={UI.ErrorStyle}>{errorText}</Text>
                                </View>
                                <ButtonCustom
                                    last
                                    text={t('common_Ok')}
                                    type="confirm"
                                    onPress={() => {
                                        if (validateCheckBank()) {
                                            checkOtherBank(otherBankAcntNum, otherBankSelected.value)
                                        }
                                    }}
                                />
                                <ButtonCustom last text={t('common_Cancel')} type="back" onPress={hideModalOtherBank} />
                            </SafeAreaView>
                        </View>
                    </Modal>
                </>
            ) : null}
            {isOpenModalOtherBankSelection ? (
                <ModalSelection
                    actionType={otherBankInfoSelection.type}
                    getSelectValue={otherBankInfoSelection.callback}
                    isOpen={isOpenModalOtherBankSelection}
                    listSelectionsProps={listBankAccount}
                    setIsOpen={setIsOpenModalOtherBankSelection}
                />
            ) : null}
            {checkOtherBankFlag ? <ModalLoading content={t('common_processing')} visible={checkOtherBankFlag} /> : null}
        </View>
    )
}
const UI = StyleSheet.create({
    ContainerModalOtherBank: {
        flexDirection: 'row',
        height: dm.vertical(40),
        marginTop: dm.vertical(16),
        paddingHorizontal: dm.moderate(16),
    },
    ErrorBorder: {
        borderColor: '#EB5C55',
        borderWidth: 1,
    },
    ErrorStyle: {
        color: '#EB5C55',
        fontSize: fs.smallest,
        fontStyle: 'italic',
        fontWeight: fw.light,
    },
    GroupInput: {
        marginVertical: dm.halfVerticalIndent,
        paddingHorizontal: dm.halfIndent,
    },
    ModalOtherBank: {
        margin: 0,
    },
    RowInput: {
        marginLeft: dm.moderate(8),
        marginVertical: dm.vertical(8),
    },
    RowInputOtherBank: {
        marginLeft: dm.moderate(16),
        marginRight: dm.moderate(16),
        marginVertical: dm.vertical(8),
    },
    RowWarning: {
        marginBottom: dm.moderate(16),
        marginHorizontal: dm.moderate(16),
    },
})
export default StepTwo
