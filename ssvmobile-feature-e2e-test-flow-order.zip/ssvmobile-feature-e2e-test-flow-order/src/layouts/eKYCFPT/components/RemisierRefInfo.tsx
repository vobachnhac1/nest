import React, { useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { InteractionManager, StyleSheet, TextInput, TouchableOpacity, View } from 'react-native'
import ToastGlobal from 'react-native-toast-message'
import AntDesign from 'react-native-vector-icons/AntDesign'

import IconRightArrow from '../../../assets/images/common/ic_arrow_right.svg'
import { Text } from '../../../basic-components'
import ModalSelection from '../../../components/list-selections'
import { RowTitleGroup } from '../../../components/trading-component'
import { StoreContext } from '../../../store'
import { dimensions as dm, fontSizes as fs } from '../../../styles'
import { glb_sv, reqFunct, sendRequest } from '../../../utils'
import { configUIEkyc } from '../config'

const ServiceInfo: IServiceInfo = {
    GET_BROKER_REMISIER_LIST: {
        reqFunct: reqFunct.GET_BROKER_REMISIER_LIST,
        WorkerName: 'FOSqID02',
        ServiceName: 'FOSqID02_HOSUserInformation',
        Operation: 'Q',
    },
}
interface IRemisierRefInfoProps {
    onChangeRemisierRefInfo: (callbackData: { refCode: string; refName: string }) => void
    inputType: 'select' | 'input'
}

export const RemisierRefInfo = ({ inputType, onChangeRemisierRefInfo = () => null }: IRemisierRefInfoProps) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()
    const [referrerCode, setReferrerCode] = useState('')
    const [referrerName, setReferrerName] = useState('')
    const [brokerRemisierList, setBrokerRemisierList] = useState<any[]>([])
    const [selectedRemisier, setSelectedRemisier] = useState<{ value: string; label: string; data: any }>({ value: '', label: '', data: {} })
    const [infoSelection, setInfoSelection] = useState<{
        type: string
        callback: (item?: any) => any
    }>({
        type: '',
        callback: () => {},
    })
    // -----------------------
    const [isOpenModalSelect, setIsOpenModalSelect] = useState(false)
    useEffect(() => {
        // Nếu là type select thì gọi service lấy danh sách luôn
        if (inputType === 'select' && isOpenModalSelect) {
            getBrokerRemisierList()
        }
    }, [inputType, isOpenModalSelect])

    //------------------------
    const timeOutCheckName = useRef<any>(null)
    useEffect(() => {
        setReferrerName('')
        if (timeOutCheckName.current) {
            clearTimeout(timeOutCheckName.current)
        }
        timeOutCheckName.current = setTimeout(() => {
            checkNameByReferrerCode()
        }, 1000)
    }, [referrerCode])

    useEffect(() => {
        if (inputType === 'select') {
            onChangeRemisierRefInfo({
                refCode: selectedRemisier.value,
                refName: selectedRemisier.data?.c1,
            })
        } else {
            onChangeRemisierRefInfo({
                refCode: referrerCode,
                refName: referrerName,
            })
        }
    }, [referrerCode, referrerName, selectedRemisier])

    const getBrokerRemisierList = () => {
        // console.log('getBrokerList', brokerList, glb_sv.brokerRemisierList.length)
        if (!glb_sv.brokerRemisierList.length) {
            const inval = ['brk_rem']
            sendRequest(ServiceInfo.GET_BROKER_REMISIER_LIST, inval, onGetBrokerListResult)
        } else {
            setBrokerRemisierList(glb_sv.brokerRemisierList || [])
        }
    }

    const onGetBrokerListResult = (reqInfoMap, message) => {
        // setLoading(false)

        if (Number(message.Result) === 0) {
            ToastGlobal.show({
                text2: message.Message,
                type: 'warning',
            })
            return
        } else {
            let tempDataList = []
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {
                jsondata = []
            }
            tempDataList = tempDataList.concat(jsondata)

            if (Number(message.Packet) <= 0) {
                glb_sv.brokerRemisierList = tempDataList
                InteractionManager.runAfterInteractions(() => {
                    setBrokerRemisierList(tempDataList)
                })
            }
        }
    }

    const checkNameByReferrerCode = () => {
        const matchRemisier = brokerRemisierList.filter((item) => item.c2 === '2').find((item) => item.c0 === referrerCode)
        setReferrerName(matchRemisier?.c1)
    }
    // ---------------------------
    const onPressSelect = () => {
        setInfoSelection({ type: 'NORMAL_SELECT', callback: onSelect })
        setIsOpenModalSelect(true)
    }

    // -----
    const onSelect = (item) => {
        setSelectedRemisier(item)
    }

    const brokerRemisierListConvert = brokerRemisierList
        .filter((item) => item.c2 === '2')
        .map((item) => {
            return {
                label: configUIEkyc.is_show_broker_remisier_id ? item.c0 : item.c1 + ` (${item.c0})`,
                value: item.c0,
                data: item,
            }
        })
    // console.log('brokerRemisierListConvert', brokerRemisierListConvert)
    return (
        <>
            {inputType === 'input' ? <RowTitleGroup hasDivider text={t('remisier_staff')} /> : null}
            {inputType === 'input' ? (
                <>
                    <View style={[UI.row, { alignItems: 'center' }, { display: 'flex' }]}>
                        <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fs.small, flex: 4 }}>{t<string>('code_remisier')}</Text>
                        <View
                            style={{
                                flex: 5,
                                backgroundColor: styles.INPUT__BG,
                                paddingHorizontal: 10,
                                paddingVertical: 8,
                                borderRadius: 4,
                            }}
                        >
                            <TextInput
                                autoCapitalize="none"
                                placeholder={t('code_remisier')}
                                placeholderTextColor={styles.PLACEHODLER__COLOR}
                                returnKeyType="next"
                                style={{
                                    fontSize: fs.small,
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                    textAlignVertical: 'center',
                                }}
                                value={referrerCode}
                                onChangeText={(value) => {
                                    setReferrerCode(value)
                                }}
                                onFocus={getBrokerRemisierList}
                            />
                        </View>
                    </View>

                    <View style={[UI.row, { alignItems: 'center' }, { display: 'flex' }]}>
                        <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fs.small, flex: 4 }}>{t<string>('name_remisier')}</Text>
                        <View
                            style={{
                                flex: 5,
                                backgroundColor: styles.INPUT__BG,
                                paddingHorizontal: 10,
                                paddingVertical: 8,
                                borderRadius: 4,
                            }}
                        >
                            <TextInput
                                autoCapitalize="none"
                                editable={false}
                                placeholder={t('name_remisier')}
                                placeholderTextColor={styles.PLACEHODLER__COLOR}
                                returnKeyType="done"
                                style={{
                                    fontSize: fs.small,
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                    textAlignVertical: 'center',
                                }}
                                value={referrerName}
                                onChangeText={(value) => {
                                    setReferrerName(value)
                                }}
                            />
                        </View>
                    </View>
                </>
            ) : null}

            {inputType === 'select' ? (
                <TouchableOpacity onPress={onPressSelect}>
                    <View style={[UI.GroupInputSelect]}>
                        <View style={{ flex: 4 }}>
                            <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fs.small, textAlignVertical: 'center' }}>
                                {t<string>('remisier_staff')}
                            </Text>
                        </View>
                        <View style={{ flex: 5, flexDirection: 'row', justifyContent: 'flex-end' }}>
                            <Text numberOfLines={1} style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fs.small, width: '90%' }}>
                                {configUIEkyc.is_show_brk_rem_id && selectedRemisier.data ? `${selectedRemisier.data?.c0 || ''} - ` : ''}
                                {selectedRemisier.data?.c1}
                            </Text>
                            {selectedRemisier.label ? (
                                <TouchableOpacity onPress={() => setSelectedRemisier({ value: '', label: '', data: {} })}>
                                    <AntDesign color={styles.ICON__PRIMARY} name="closecircleo" size={20} style={{ marginHorizontal: dm.moderate(5) }} />
                                </TouchableOpacity>
                            ) : (
                                <IconRightArrow style={{ color: styles.ICON__PRIMARY }} />
                            )}
                        </View>
                    </View>
                </TouchableOpacity>
            ) : null}

            {inputType === 'select' ? (
                // @ts-expect-error
                <ModalSelection
                    actionType={infoSelection.type}
                    getSelectValue={infoSelection.callback}
                    isOpen={isOpenModalSelect}
                    listSelectionsProps={brokerRemisierListConvert}
                    setIsOpen={setIsOpenModalSelect}
                />
            ) : null}
        </>
    )
}

const UI = StyleSheet.create({
    BlankSpace: {
        height: 10,
        width: dm.moderate(40),
    },
    ButtonDelete: {
        alignItems: 'center',
        height: '100%',
        justifyContent: 'center',
        position: 'absolute',
        right: 0,
    },
    GroupInput: {
        marginVertical: dm.halfVerticalIndent,
        paddingHorizontal: dm.halfIndent,
    },
    GroupInputSelect: {
        flexDirection: 'row',
        marginHorizontal: dm.moderate(16),
        marginVertical: dm.halfVerticalIndent,
    },
    RowInput: {
        marginLeft: dm.moderate(8),
        marginVertical: dm.vertical(8),
    },
    modal: {
        justifyContent: 'flex-end',
        margin: 0,
    },
    row: {
        alignItems: 'center',
        borderRadius: 12,
        flexDirection: 'row',
        marginHorizontal: dm.moderate(16),
        marginTop: dm.vertical(12),
    },
})
