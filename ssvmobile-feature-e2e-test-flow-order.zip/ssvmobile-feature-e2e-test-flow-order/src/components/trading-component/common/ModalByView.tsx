import React, { useRef } from 'react'
import { StyleSheet, TouchableOpacity, View, ViewStyle } from 'react-native'
import { HIEGHT, WIDTH } from '@mts-styles/helper/dimensions'

import { dimensions as dm } from '../../../styles'

interface IModalByViewProps {
    isVisible: boolean
    children: React.ReactNode
    hideModalContentWhileAnimating?: boolean
    useNativeDriver?: boolean
    onBackdropPress?: () => void
    onBackButtonPress?: () => void
    style?: ViewStyle
}

export const ModalByView = ({
    isVisible = false,
    children = null,
    onBackdropPress,
    onBackButtonPress,
    useNativeDriver,
    hideModalContentWhileAnimating,
}: IModalByViewProps) => {
    const _onBackdropPress = () => {
        // console.log('_onBackdropPress');
        if (typeof onBackdropPress === 'function') {
            onBackdropPress()
        }
    }

    const onPressOutSide = () => {
        // console.log('onPressOutSide');
        _onBackdropPress()
    }

    return (
        <View style={[UI.ModalView, { display: isVisible ? 'flex' : 'none' }]}>
            <TouchableOpacity activeOpacity={1} style={{ width: '100%', height: '100%' }} onPress={onPressOutSide}>
                <View
                    pointerEvents="box-none"
                    style={[UI.ModalViewInside]}
                    onStartShouldSetResponder={(event) => true}
                    onTouchEnd={(e) => {
                        e.stopPropagation()
                    }}
                >
                    {children}
                </View>
            </TouchableOpacity>
        </View>
    )
}

const UI = StyleSheet.create({
    ModalView: {
        alignContent: 'center',
        backgroundColor: '#00000060',
        height: HIEGHT,
        justifyContent: 'center',
        marginTop: -HIEGHT,
        position: 'relative',
        width: WIDTH,
    },
    ModalViewInside: {
        alignContent: 'center',
        height: '100%',
        justifyContent: 'center',
        padding: dm.moderate(32),
        position: 'relative',
        width: '100%',
    },
})
