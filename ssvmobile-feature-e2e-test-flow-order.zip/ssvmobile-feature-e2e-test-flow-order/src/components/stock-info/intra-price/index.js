import React, { memo } from 'react'
import { StyleSheet, View } from 'react-native'
import Svg, { Path } from 'react-native-svg'
import { Row } from 'native-base'

import { Text } from '../../../basic-components'
import { dimensions, fontSizes, fontWeights } from '../../../styles'

const IntraPrice = ({ price, change, ratio, status, onChange, indexValueChang, isPlaceOrder }) => {
    return (
        <Row style={{ marginLeft: isPlaceOrder ? 0 : dimensions.moderate(8), alignItems: 'center' }} onPress={onChange}>
            {isPlaceOrder ? null : (
                <View style={{ height: dimensions.moderate(32) }}>
                    {indexValueChang ? (
                        <Svg height={dimensions.moderate(32)} viewBox="0 0 32 32" width={dimensions.moderate(32)} xmlns="http://www.w3.org/2000/svg">
                            <Path d="M26 32H6a6 6 0 01-6-6V6a6 6 0 016-6h20a6 6 0 016 6v20a6 6 0 01-6 6z" fill={status} opacity={0.1} />
                            {indexValueChang > 0 ? (
                                <Path
                                    d="M16 7.875a8.125 8.125 0 100 16.25 8.125 8.125 0 000-16.25zm3.569 8.307a.628.628 0 01-.884.003l-2.06-2.044v5.218a.625.625 0 11-1.25 0v-5.218l-2.06 2.044a.625.625 0 11-.88-.888l3.125-3.101a.625.625 0 01.88 0l3.125 3.1a.623.623 0 01.004.886z"
                                    fill={status}
                                />
                            ) : (
                                <Path
                                    d="M16.125 24.125a8.125 8.125 0 110-16.25 8.125 8.125 0 010 16.25zm3.569-8.307a.628.628 0 00-.884-.003l-2.06 2.044V12.64a.625.625 0 10-1.25 0v5.218l-2.06-2.044a.625.625 0 10-.88.888l3.125 3.101a.625.625 0 00.88 0l3.125-3.1a.623.623 0 00.004-.886z"
                                    fill={status}
                                />
                            )}
                        </Svg>
                    ) : null}
                </View>
            )}

            <Text style={{ ...UI.price, color: status }}> {price}</Text>
            <View style={{ marginHorizontal: dimensions.moderate(5), flexDirection: 'column', marginTop: 3 }}>
                <Text
                    style={{
                        fontSize: fontSizes.smallest,
                        color: status,
                        lineHeight: fontSizes.smallest + 1,
                    }}
                >
                    {indexValueChang > 0 ? '+' : ''}
                    {change}
                </Text>
                <Text
                    style={{
                        fontSize: fontSizes.smallest,
                        lineHeight: fontSizes.smallest + 1,
                        color: status,
                    }}
                >
                    {indexValueChang > 0 ? '+' : ''}
                    {ratio}%
                </Text>
            </View>
        </Row>
    )
}

export default memo(IntraPrice)

const UI = StyleSheet.create({
    price: {
        fontSize: dimensions.moderate(26),
        fontWeight: fontWeights.semiBold,
        lineHeight: dimensions.moderate(39),
    },
})
