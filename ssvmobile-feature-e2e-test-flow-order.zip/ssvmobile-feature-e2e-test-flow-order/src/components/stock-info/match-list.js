import React, { memo, useContext, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { FlatList, StyleSheet, TouchableOpacity, View } from 'react-native'
import cloneDeep from 'lodash/cloneDeep'
import moment from 'moment'
import { Row } from 'native-base'

import { Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { dimensions, fontSizes, fontWeights } from '../../styles'
import { FormatNumber, FormatNumberAC, glb_sv } from '../../utils'

const ItemMemo = ({ item, stockCode, onPress }) => {
    const { styles, fractionPrice, fractionQty } = useContext(StoreContext)
    const stock = glb_sv.StockMarket[stockCode] || {}
    return (
        <Row style={UI.item} onPress={onPress}>
            <Text numberOfLines={1} style={{ ...UI.title, width: '33.33%', color: styles.SECOND__CONTENT__COLOR }}>
                {moment(item.t52, 'YYYYMMDD-HH:mm:ss').format('HH:mm:ss')}
            </Text>
            <Text numberOfLines={1} style={{ ...UI.title, width: '33.33%', color: glb_sv.getColor(item.t31, stock, styles), textAlign: 'right' }}>
                {fractionPrice ? FormatNumber(item.t31 / 1000, 2) : FormatNumber(item.t31)}
            </Text>
            <Text
                numberOfLines={1}
                style={{
                    ...UI.title,
                    width: '33.33%',
                    color: item.U16 === 'S' ? styles.UP__COLOR : item.U16 === 'B' ? styles.DOWN__COLOR : styles.PRIMARY__CONTENT__COLOR,
                    textAlign: 'right',
                }}
            >
                {fractionQty ? FormatNumberAC(item.t32, 0, 0) : FormatNumber(item.t32, 0, 0, 'short')}
            </Text>
        </Row>
    )
}
const Item = memo(ItemMemo)

const MatchList = ({ EP, changeTimeMatch, stockCode }) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()
    return (
        <View style={{ flex: 1, borderRightColor: styles.DIVIDER__COLOR, borderRightWidth: 1, paddingRight: 5 }}>
            <FlatList
                data={cloneDeep(EP)
                    .slice(-13)
                    .sort(function (a, b) {
                        if (a.t52 < b.t52) return 1
                        if (a.t52 > b.t52) return -1
                        if (a.t52 === b.t52) {
                            if (a.seq < b.seq) return 1
                            if (a.seq > b.seq) return -1
                            if (a.seq === b.seq) {
                                if (a.subseq < b.subseq) return 1
                                if (a.subseq > b.subseq) return -1
                            }
                        }
                        return 0
                    })}
                keyExtractor={(item, index) => String(index)}
                renderItem={({ item }) => <Item item={item} key={item.t52 + item.seq + item.subseq} stockCode={stockCode} onPress={changeTimeMatch} />}
                style={{ paddingHorizontal: 5 }}
            />
            {EP.length ? (
                <TouchableOpacity style={{ marginBottom: dimensions.vertical(16) }} onPress={changeTimeMatch}>
                    <Text style={{ color: styles.PRIMARY, fontSize: fontSizes.verySmall, fontWeight: fontWeights.medium }}>{t('view_all') + ' >'}</Text>
                </TouchableOpacity>
            ) : null}
        </View>
    )
}

const UI = StyleSheet.create({
    item: {
        alignItems: 'center',
        flex: 0,
    },
    title: {
        fontSize: fontSizes.verySmall,
        paddingVertical: 6,
    },
})

export default memo(MatchList)
