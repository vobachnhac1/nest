import { default as React, useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Dimensions, Image, StyleSheet, Text, TouchableOpacity, View } from 'react-native'
import ToastGlobal from 'react-native-toast-message'
import WebView from 'react-native-webview'
import ModalLoading from '@mts-components/modal-loading'
import { COLORS } from '@mts-styles/colors'
import { eventList, glb_sv } from '@mts-utils/index'
import Clipboard from '@react-native-clipboard/clipboard'
import CookieManager from '@react-native-cookies/cookies'
import jwt_decode from 'jwt-decode'
import { isEmpty } from 'lodash'
import throttle from 'lodash/throttle'
import { Container } from 'native-base'

import CONTRACT_EMPTY from '../../../../assets/images/common/contract_empty.png'
import HeaderComponent from '../../../../components/header'
import useLoading from '../../../../hoc/useLoading'
import { StoreContext } from '../../../../store'
import { colors, dimensions as dm, fontSizes, fontWeights as fw, IconSvg } from '../../../../styles'

const { width, height } = Dimensions.get('window')

const useWebKit = true

export interface IEcontractItem {
    c0?: string //
    c1?: string //
    c2?: string //
    c3: string // contract name
    c4?: string // Y/N : Khách hàng đã kí
    c5?: string // Y/N : SSV đã ký
    c6: string // url / uri
    c7: string // cookie name
    c8: string // cookie value
    c9?: string //
    c10: string // username
    c11: string // password
    c12?: string //
    c13?: string //
    c14?: string // cancel status
    c15?: string // rejects status
    c16?: string
    c17?: string
    c18?: string // envId
    c19?: string // contactId
}

const InfoLoginView = ({ isShowUserInfo, translate, copyUser, copyPassword, styles }) => {
    if (!isShowUserInfo) {
        return null
    }
    return (
        <View style={InfoViewStyles.container}>
            <View style={InfoViewStyles.accountView}>
                <Text>{`${translate('acnt_no')}: ********`}</Text>
                <TouchableOpacity onPress={copyUser}>
                    <Text style={{ color: styles.PRIMARY }}>{translate('econtract_copy')}</Text>
                </TouchableOpacity>
            </View>
            <View style={InfoViewStyles.passwordView}>
                <Text>{`${translate('econtract_info_password')}: ********`}</Text>
                <TouchableOpacity onPress={copyPassword}>
                    <Text style={{ color: styles.PRIMARY }}>{translate('econtract_copy')}</Text>
                </TouchableOpacity>
            </View>
        </View>
    )
}

const EContractViewDetail = ({ navigation, route }) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()
    const {
        c6: uri,
        c3: contractName,
        c7: cookieName,
        c8: cookieValue,
        c10: userName,
        c11: password,
        c18: envId,
        c19: contactId,
    }: IEcontractItem = route?.params?.item
    const [isShowUserInfo, setShowUserInfo] = useState(false)
    const [newCookieValue, setNewCookieValue] = useState(cookieValue)

    const [loadingConfirm, setLoadingConfirm] = useLoading(true)
    const [showWebView, setShowWebView] = useState(false)
    const [showEmptyEcontract, setShowEmptyEcontract] = useState(false)

    useEffect(() => {
        if (isEmpty(uri)) {
            setLoadingConfirm(false)

            setShowEmptyEcontract(true)

            return
        }
        const cookieDecode = cookieValue ? jwt_decode(cookieValue) : { exp: 0 }
        const timestampNow = Date.now()
        const timestampExp = cookieDecode.exp * 1000
        if (timestampNow > timestampExp || !cookieDecode) {
            getNewCookieValue()
        } else {
            fetchingCallback()
        }
    }, [])

    let hasRunGoBack = false
    const goBack = () => {
        if (!hasRunGoBack) {
            navigation.canGoBack() && navigation.goBack()
            hasRunGoBack = true
        }
    }

    const throttledGoback = throttle(goBack, 2000)

    useEffect(() => {
        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.NOTIFY_ECONTRACT_CUS) {
                throttledGoback()
            }
        })
        return () => {
            commonEvent.unsubscribe()
        }
    }, [navigation])

    const getNewCookieValue = () => {
        const apiFPT = glb_sv.dataEkycInfo?.c4 + '/api/econtract'
        const body = {
            contactId: contactId,
            envId: envId,
        }
        const requestOptions = {
            method: 'POST',
            headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
            body: JSON.stringify(body),
        }
        fetch(`${apiFPT}/getNewCookie`, requestOptions)
            .then(async (res) => {
                return res.json()
            })
            .then(async (data) => {
                if (!isEmpty(data?.response?.cookieValue)) {
                    setNewCookieValue(data.response.cookieValue)
                } else {
                    // console.log('GetNewCookie ERROR: ', data)
                }
            })
            .catch((err) => {
                // console.log('GetNewCookie ERROR: ', err)
            })
            .finally(() => {
                fetchingCallback()
            })
    }

    const fetchingCallback = () => {
        setShowWebView(true)
    }

    const onNavigationStateChange = (webViewState) => {
        const { url } = webViewState
        if (url.includes('demo.econtract.fpt.com.vn')) {
            const lastSegment = url?.split('/')?.pop()
            if (lastSegment === 'act') {
                const newCookie = {
                    secure: true,
                    domain: 'demo.econtract.fpt.com.vn',
                    httpOnly: true,
                    version: '1',
                    value: newCookieValue,
                    path: '/',
                    name: cookieName,
                }
                CookieManager.set(url, newCookie, useWebKit)
                setShowUserInfo(false)
            }
        }
    }

    const onLoadProgress = (event) => {
        const { url } = event?.nativeEvent
        const lastSegment = url?.split('/')?.pop()
        if (lastSegment === 'login') {
            setShowUserInfo(true)
        } else {
            setShowUserInfo(false)
        }
    }

    const onPresCopy = (value) => {
        Clipboard.setString(value)
        ToastGlobal.show({
            type: 'success',
            text2: t('econtract_copy_info_success'),
        })
    }

    return (
        <Container style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft={true}
                navigation={navigation}
                title={contractName}
                titleAlgin="flex-start"
            />
            {showEmptyEcontract ? (
                <View style={InfoViewStyles.View}>
                    <Image source={CONTRACT_EMPTY} style={InfoViewStyles.Image} />
                    <View style={InfoViewStyles.textEmptyView}>
                        <Text style={InfoViewStyles.textEmptyStyle(styles)}>{t<string>('contract_list_empty_message_1')}</Text>
                    </View>
                </View>
            ) : null}
            {showWebView ? (
                <WebView
                    allowUniversalAccessFromFileURLs={true}
                    javaScriptEnabled
                    originWhitelist={['*']}
                    scrollEnabled
                    sharedCookiesEnabled={true}
                    source={{ uri }}
                    style={{ width: width, height: height }}
                    thirdPartyCookiesEnabled={true}
                    useWebKit
                    onLoadEnd={() => setLoadingConfirm(false)}
                    onLoadProgress={(event) => {
                        onLoadProgress(event)
                    }}
                    onNavigationStateChange={onNavigationStateChange}
                />
            ) : null}
            <InfoLoginView
                copyPassword={() => onPresCopy(password)}
                copyUser={() => onPresCopy(userName)}
                isShowUserInfo={isShowUserInfo}
                styles={styles}
                translate={t}
            />
            {loadingConfirm ? (
                <ModalLoading content={t('common_processing')} setLoading={setLoadingConfirm} showTimeoutMessage={false} visible={loadingConfirm} />
            ) : null}
        </Container>
    )
}

export default EContractViewDetail

const InfoViewStyles = StyleSheet.create({
    Image: {
        alignItems: 'center',
        height: 214,
        justifyContent: 'center',
        marginVertical: dm.vertical(18),
        resizeMode: 'contain',
    },
    View: {
        alignItems: 'center',
        justifyContent: 'center',
    },
    accountView: { alignContent: 'center', flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
    container: { justifyContent: 'space-between', paddingHorizontal: 80, paddingVertical: 16, width: '100%' },
    passwordView: { alignContent: 'center', flexDirection: 'row', justifyContent: 'space-between' },
    textEmptyStyle: (styles) => ({ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal, textAlign: 'center' }),
    textEmptyView: {
        alignItems: 'center',
        justifyContent: 'center',
        paddingVertical: dm.vertical(32),
        width: '100%',
    },
    textEmptyWarningStyle: (styles) => ({
        color: COLORS.YELLOW_F1F510,
        fontSize: fontSizes.verySmall,
        textAlign: 'center',
        fontStyle: 'italic',
        marginTop: dm.vertical(16),
    }),
})
