import React, { useContext } from 'react'
import { ScrollView, View } from 'react-native'

import { Text } from '../../../basic-components'
import { StoreContext } from '../../../store'
import { dimensions, dimensions as dm, fontSizes as fs, fontWeights as fw } from '../../../styles'

interface IModalBottomContent {
    children: any
    title: string
    type?: 'confirm' | 'cancel'
}

const ModalBottomContent = ({
    children,
    title = '', // Nội dung modal
    type = 'confirm', // type của button
}: IModalBottomContent) => {
    const { styles } = useContext(StoreContext)

    return (
        <View
            style={{
                backgroundColor: styles.HEADER__BG__COLOR,
                borderTopLeftRadius: 16,
                borderTopRightRadius: 16,
                borderColor: 'rgba(0, 0, 0, 0.1)',
                paddingTop: dm.vertical(16),
                paddingBottom: dm.vertical(40),
                height: 'auto',
                maxHeight: dimensions.HIEGHT * 0.7,
                minHeight: dimensions.HIEGHT * 0.2,
            }}
        >
            <Text
                style={{
                    fontSize: fs.xmedium,
                    fontWeight: fw.semiBold,
                    color: styles.PRIMARY__CONTENT__COLOR,
                    textAlign: 'center',
                    marginHorizontal: dm.moderate(16),
                    marginBottom: dm.vertical(24),
                }}
            >
                {title}
            </Text>
            <ScrollView>{children}</ScrollView>
        </View>
    )
}

export default ModalBottomContent
