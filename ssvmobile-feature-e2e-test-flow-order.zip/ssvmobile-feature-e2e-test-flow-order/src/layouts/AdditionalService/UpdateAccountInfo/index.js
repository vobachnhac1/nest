import React, { useContext, useEffect, useLayoutEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { KeyboardAvoidingView, RefreshControl, ScrollView } from 'react-native'
import RNRestart from 'react-native-restart'
import ToastGlobal from 'react-native-toast-message'
import { CommonActions } from '@react-navigation/native'
import { Button, Container, Content, Form, Icon, Input, Item, Toast } from 'native-base'
import SyncStorage from 'sync-storage'

// import Spinner from 'react-native-loading-spinner-overlay';
import { Text } from '../../../basic-components'
import HeaderComponent from '../../../components/header'
import { ButtonCustom } from '../../../components/trading-component'
import { useLoading } from '../../../hoc'
import { StoreContext } from '../../../store'
import { dimensions, fontSizes, IconSvg } from '../../../styles'
import { UIbasic, UIcomponent } from '../../../styles/appUI'
import { dataCryption, glb_sv, reqFunct, Screens, sendRequest, socket_sv, STORE_KEY } from '../../../utils'
import ModalAuthenOtp from '../../login/modal-authen-otp'
import UpdateBankAccountInfo from './UpdateBankAccountInfo'
import UpdateCommonAccountInfo from './UpdateCommonAccountInfo'
import UpdateMarginInfo from './UpdateMarginInfo'
import UpdateOtherService from './UpdateOtherService'

export default function UpdateAccountInfo({ navigation, route }) {
    const { userData } = route.params

    const { styles, setAuth } = useContext(StoreContext)
    const { t } = useTranslation()
    const [refreshing, setRefreshing] = useLoading(false)

    const onRefresh = () => {
        if (refreshing) return
        setRefreshing(true)
        setRefreshing(false)
    }

    return (
        <Container
            style={{
                backgroundColor: styles.PRIMARY__BG__COLOR,
            }}
        >
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft
                navigation={navigation}
                title={t('update_acc_info')}
                titleAlgin="flex-start"
                transparent
            />
            <Content
                refreshControl={
                    <RefreshControl
                        refreshing={refreshing}
                        onRefresh={onRefresh}
                        // title={t('pull_refresh')}
                        // titleColor={styles.PRIMARY__CONTENT__COLOR}
                        tintColor={styles.PRIMARY__CONTENT__COLOR}
                    />
                }
                style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}
            >
                {/* <ScrollView showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled" style={{ paddingHorizontal: dimensions.moderate(8) }}> */}
                {/* <KeyboardAvoidingView behavior='padding'> */}
                <UpdateCommonAccountInfo refreshing={refreshing} userData={userData} onRefresh={onRefresh} />
                <UpdateBankAccountInfo refreshing={refreshing} userData={userData} onRefresh={onRefresh} />
                <UpdateMarginInfo refreshing={refreshing} userData={userData} onRefresh={onRefresh} />
                <UpdateOtherService refreshing={refreshing} userData={userData} onRefresh={onRefresh} />
                {/* </KeyboardAvoidingView>
            </ScrollView> */}
            </Content>
        </Container>
    )
}
