import React, { memo, useEffect, useRef, useState } from 'react'
import { Defs, LinearGradient, Stop } from 'react-native-svg'
import maxBy from 'lodash/maxBy'
import minBy from 'lodash/minBy'
import moment from 'moment'
import { VictoryArea, VictoryAxis, VictoryChart, VictoryLine } from 'victory-native'

import { eventList, glb_sv } from '../../../utils'

const initData = [
    {
        x: 1601370904,
        y: 1,
        y0: 0,
    },
    {
        x: 1601370964,
        y: 1,
        y0: 0,
    },
]

function SparklinesChartIndex({ index, width, height, styles }) {
    const [configData, setConfigData] = useState({
        chartData: initData,
        colorChart: styles.REF__COLOR,
        refLineData: [],
    })
    const configDataRef = useRef({
        chartData: initData,
        colorChart: styles.REF__COLOR,
        refLineData: [],
    })

    const dataIntraday = useRef([])
    const lastData = useRef(null)

    const mounted = useRef(true)

    useEffect(() => {
        const eventMarket = glb_sv.eventMarket.subscribe((msg) => {
            if (msg.type === eventList.GET_DATA_I_MINUTES_DONE && msg.value.includes(index)) {
                const data = glb_sv.IndexMarket[index] ? glb_sv.IndexMarket[index].arrMinutes : []
                if (!data.length) return
                if (dataIntraday.current && dataIntraday.current.length < 300 && dataIntraday.current.length >= data.length) return

                dataIntraday.current = [...data]
                lastData.current = data[data.length - 1]
                if (!glb_sv.IndexMarket[index].ref) return
                convert2chartVictory([...dataIntraday.current])
            }
            if (msg.type === eventList.REQ_AFTER_SUB_INDEX) {
                if (msg.value.includes(index)) {
                    convert2chartVictory([...dataIntraday.current])
                }
            }
            if (msg.type === eventList.MKT_INTRADAY && msg.S === index) {
                if (lastData.current && lastData.current.T === msg.T) {
                    return
                }
                const value = {
                    ...msg,
                    time: moment(glb_sv.timeServer + '-' + msg.T, 'YYYYMMDD-HH:mm:ss').valueOf(),
                }
                lastData.current = { ...value }
                dataIntraday.current.push({
                    ...value,
                })
                convert2chartVictory([...dataIntraday.current])
            }
            if (msg.type === eventList.RESET_DATA) {
                lastData.current = null
                dataIntraday.current = []
                convert2chartVictory([])
            }
        })
        const data = glb_sv.IndexMarket[index] ? glb_sv.IndexMarket[index].arrMinutes : []
        if (data.length) {
            dataIntraday.current = [...data]
            lastData.current = data[data.length - 1]
            convert2chartVictory([...dataIntraday.current])
        }

        return () => {
            mounted.current = false
            eventMarket.unsubscribe()
        }
    }, [])

    const getColorChart = (lastItem) => {
        if (!lastItem) return styles.REF__COLOR

        const ratio = glb_sv.IndexMarket[index].indexValueChang
        if (ratio < 0) return styles.DOWN__COLOR
        if (ratio > 0) return styles.UP__COLOR
        return styles.REF__COLOR
    }

    const convert2chartVictory = (arr) => {
        const victoryDataChart = []
        // set data cho chart
        const minValue =
            minBy(arr, function (o) {
                return o.C
            }) || {}
        const maxValue =
            maxBy(arr, function (o) {
                return o.C
            }) || {}

        let value_y0 = minValue.C - (maxValue.C - minValue.C) / 4
        if (minValue.C === maxValue.C) value_y0 = minValue.C * 0.95
        for (let index = 0; index < arr.length; index++) {
            victoryDataChart.push({
                x: arr[index].time,
                y: arr[index].C,
                y0: value_y0,
            })
        }
        if (victoryDataChart.length <= 1) {
            configDataRef.current.chartData = initData
            if (mounted.current)
                setConfigData({
                    ...configDataRef.current,
                })
            return
        } else {
            configDataRef.current.chartData = victoryDataChart
        }
        // set màu cho chart
        const tempt = [...arr]
        const lastItem = tempt.pop()
        const colorCharts = getColorChart(lastItem)
        configDataRef.current.colorChart = colorCharts

        if (mounted.current)
            setConfigData({
                ...configDataRef.current,
            })
    }

    return (
        <VictoryChart height={height || 40} padding={0} width={width || 85}>
            <VictoryAxis
                style={{
                    axis: { stroke: 'transparent' },
                    ticks: { stroke: 'transparent' },
                    tickLabels: { fill: 'transparent' },
                }}
            />
            <Defs>
                <LinearGradient id="gradientStroke" x1="0%" x2="0%" y1="0%" y2="100%">
                    <Stop offset="0%" stopColor={configData.colorChart} stopOpacity="0.2" />
                    <Stop offset="100%" stopColor={configData.colorChart} stopOpacity="0" />
                </LinearGradient>
            </Defs>

            <VictoryArea
                data={configData.chartData || []}
                style={{
                    data: {
                        fill: 'url(#gradientStroke)',
                        stroke: `${configData.colorChart}`,
                        strokeWidth: 1,
                    },
                }}
            />
            {/* <VictoryLine
                style={{
                    data: { stroke: styles.HEADER__CONTENT__COLOR, strokeWidth: 1, strokeDasharray: '3,5', },
                }}
                data={configData.refLineData}
            /> */}
        </VictoryChart>
    )
}

export default memo(SparklinesChartIndex)
