/* eslint-disable no-restricted-syntax */
import React, { useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { InteractionManager } from 'react-native'
// import Spinner from 'react-native-loading-spinner-overlay';
import ToastGlobal from 'react-native-toast-message'
import ModalController from '@mts-components/appModal/modalControlller'
import { EKYC_TRACKING_STEP, useSaveCurrentStep } from '@mts-layouts/eKYCFPT/hooks/useSaveCurrentStep'
import debounce from 'lodash/debounce'
import isEmpty from 'lodash/isEmpty'

import { useAlertModal, useAlertModalCommonCode, useModalOtpWhenErr } from '../../../../hoc'
import useLoading from '../../../../hoc/useLoading'
import { StoreContext } from '../../../../store'
import { StoreTrading } from '../../../../store-trading'
import { IconSvg } from '../../../../styles'
import { reqFunct, Screens, sendRequest } from '../../../../utils'
import ekycService from '../../ekycService'

const ServiceInfo: IServiceInfo = {
    EKYC_UPDATE: {
        reqFunct: reqFunct.EKYC_UPDATE,
        WorkerName: 'FOSxID01',
        ServiceName: 'FOSxID01_EKYCMgt',
        ClientSentTime: '0',
        Operation: 'U',
        TimeOut: 20,
    },
    API_UPLOAD: {
        reqFunct: reqFunct.API_UPLOAD,
        WorkerName: 'FOSxCommon02',
        ServiceName: 'FOSxCommon02_Token_Mgt',
        ClientSentTime: '0',
        Operation: 'Q',
    },
    CHK_BANK_ACT_NO: {
        reqFunct: reqFunct.CHK_BANK_ACT_NO,
        WorkerName: 'FOSqAccount',
        ServiceName: 'FOSqAccount_Common_3',
        ClientSentTime: '0',
        Operation: 'Q',
    },
    GET_INSTITUATION: {
        reqFunct: reqFunct.GET_INSTITUATION,
        WorkerName: 'FOSqAccount',
        ServiceName: 'FOSqAccount_Common_1',
        Operation: 'Q',
    },
}

export const useAdditionInfo = ({ navigation, switchStep }) => {
    const { styles } = useContext(StoreContext)
    const { setUserInfo } = useContext(StoreTrading)
    const { t } = useTranslation()

    const [loading, setLoading] = useLoading(false)
    const [loadingRegister, setLoadingRegister] = useLoading(false)
    const { saveData } = useSaveCurrentStep()
    // Bank
    const [bankLinkType, setBankLinkType] = useState('1')
    const [bankAccNum, setBankAccNum] = useState('')
    const [selectedBank, setSelectedBank] = useState<{ label?: string; value?: string }>({})
    const [bankAccLink, setBankAccLink] = useState<IServiceResponeData>({})

    // -----
    const [expandRegisterBank, setExpandRegisterBank] = useState(true)
    const [expandRegisterMarginService, setExpandRegisterMarginService] = useState(true)

    const [dataForContract, setDataForContract] = useState({})
    const [checkAutoPIA, setCheckAutoPIA] = useState(false)
    const [isCheckBrokerageServices, setisCheckBrokerageServices] = useState(false)
    const [isShowReviewModal, setIsShowReviewModal] = useState(false)
    const [referrerCode, setReferrerCode] = useState('')
    const [referrerName, setReferrerName] = useState('')
    const [visibleInstitutional, setVisibleInstitutional] = useState(false)
    const [institutionalList, setInstitutionalList] = useState<IServiceResponeData[]>([])
    const [institutional, setInstitutional] = useState('')
    const onChangeBrokerOrRemierRefInfo = (info) => {
        const delayedFn = debounce(() => {
            if (!isEmpty(info.data) && info?.data?.c2 === '1') {
                ekycService.additionalData.brokerInfo = { brokerID: info?.data?.c0, brokerName: info?.data?.c1 }
            }
        }, 1000)
        delayedFn()
    }
    const [isBankOk, setIsBankOk] = useState(false) // Bank đã ok chưa: thực hiện thay đổi trạng thái bank not ok khi change data bank

    useEffect(() => {
        setIsBankOk(false)
    }, [bankLinkType, bankAccNum, selectedBank, bankAccLink])

    const validate = () => {
        // if (!checkNote) return false
        return true
    }

    const getInstituation = () => {
        const inval = ['06', '%']
        sendRequest(ServiceInfo.GET_INSTITUATION, inval, getInstituationResult)
    }

    const getInstituationResult = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {
                return
            }
            InteractionManager.runAfterInteractions(() => {
                console.log('getInstituationResult', jsondata)
                setInstitutionalList(jsondata)
            })
        }
    }

    const onChangeReferrerInfo = (referrerInfo) => {
        if (!isEmpty(referrerInfo)) {
            ekycService.additionalData.referrerCode = referrerInfo.refCode
            ekycService.additionalData.referrerName = referrerInfo.refName
            ekycService.additionalData.institutional = referrerInfo.institutional
        }
        setReferrerCode(referrerInfo.refCode || '')
        setReferrerName(referrerInfo.refName || '')
    }

    const bankAccConfirmCallback = (item) => {
        console.log('bankAccConfirmCallback', item)
        setBankAccNum(item.bankAccNum.trim())
        setSelectedBank(item.selectedBank)
        if (item.bankInfoObj) {
            setBankAccLink(item.bankInfoObj)
        } else {
            const defaultBank = {
                c0: '',
                c1: t('shanhan_bank'),
            }
            setBankAccLink(defaultBank)
        }
    }
    const onChangeOtherInformation = (data) => {
        console.log('onChangeOtherInformation', data)
        setDataForContract(data)
    }
    const onChangeCheckBrokerageServices = (isCheck: boolean) => {
        console.log('onChangeCheckBrokerageServices', isCheck)
        setisCheckBrokerageServices(isCheck)
    }

    const checkBeforeNextStep = (callback: () => void, isCheckBankOk = false) => {
        // 1. Check bank
        // 2. Check Register Service
        // 3. Check Other Data
        // Save data
        if (bankLinkType === '1') {
            // Nếu đã chọn ngân hàng thì phải chọn chi nhánh
            if (selectedBank.label) {
                if (!bankAccLink?.c0) {
                    ToastGlobal.show({
                        text2: t('warning_branch_bank'),
                        type: 'warning',
                    })
                    return
                }
            }

            // Nếu có chọn ngân hàng và chi nhánh thì phải điền số tài khoản
            if (bankAccLink?.c1?.length) {
                if (!bankAccLink?.c0) {
                    ToastGlobal.show({
                        text2: t('warning_branch_bank'),
                        type: 'warning',
                    })
                    return
                } else if (!bankAccNum) {
                    ToastGlobal.show({
                        text2: t('warning_bank_acc_number_is_empty'),
                        type: 'warning',
                    })
                    return
                }
            }
            // Nếu nhập số tài khoản thì yêu cầu chọn ngân hàng
            if (bankAccNum) {
                if (!bankAccLink?.c0) {
                    ToastGlobal.show({
                        text2: t('warning_branch_bank'),
                        type: 'warning',
                    })
                    return
                }
                if (!isBankOk && !isCheckBankOk) {
                    checkBank()
                    // Đang check bank thì return
                    return
                }
            }
        } else if (bankLinkType === '0') {
            if (!bankAccNum) {
                ToastGlobal.show({
                    text2: t('warning_bank_acc_number_is_empty'),
                    type: 'warning',
                })
                return
            }
            if (!isBankOk && !isCheckBankOk) {
                checkBank()
                // Đang check bank thì return
                return
            }
        }
        // --- Set Data and Next step
        ekycService.userData.bankAccNum = bankAccNum
        // @ts-expect-error
        ekycService.userData.bankAccLink = bankAccLink
        ekycService.userData.bankLinkType = bankLinkType
        ekycService.dataForContract = dataForContract
        ekycService.additionalData.checkAutoPIA = checkAutoPIA
        ekycService.additionalData.isCheckBrokerageServices = isCheckBrokerageServices

        saveData(ekycService, EKYC_TRACKING_STEP.OTHER_INFO_DONE)

        if (typeof callback === 'function') {
            callback()
        }
    }

    const checkBank = () => {
        // Gọi service check ngân hàng hợp lệ
        const inputParams = ['CHK_BANK_ACT_NO', bankAccLink.c0, bankAccNum, ekycService.userData.name]
        sendRequest(ServiceInfo.CHK_BANK_ACT_NO, inputParams, handleCheckBankResult, true, handleCheckBankTimeout)
        setLoading(true)
    }

    const handleCheckBankResult = (reqInfoMap, message) => {
        setLoading(false)
        if (Number(message.Result) === 0) {
            const { hasAlertCommonCode } = useAlertModalCommonCode(message, {})
            const { hasAlertErrOtp } = useModalOtpWhenErr(message, {
                continueVerify: !hasAlertCommonCode,
                callback: checkBank,
            })
            // Checkbank failed nhưng có muốn tiếp tục hay không?: Không
            useAlertModal(message, {
                continueVerify: !hasAlertErrOtp,
                titleOK: t('common_alert_agree').toLocaleUpperCase(),
                // callback: () => setIsBankOk(true) // Không cho tiếp tục
            })
            return
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
                // -----
                setIsBankOk(true)
                InteractionManager.runAfterInteractions(() => {
                    checkBeforeNextStep(() => setIsShowReviewModal(true), true)
                })
            } catch (err) {}
        }
    }

    const handleCheckBankTimeout = (info) => {
        setLoading(false)
        InteractionManager.runAfterInteractions(() => {
            // navigation.navigate(Screens.ALERT_MODAL, {
            // icon: <IconSvg.ErrorIcon color={styles.INFO__COLOR} />,
            // title: t('common_notify').toLocaleUpperCase(),
            // colorTitle: styles.EKYC__COLOR,
            // content: t('can_not_get_bank_account_information'),
            // titleOK: t('common_alert_agree').toLocaleUpperCase(),
            // typeColor: styles.INFO__COLOR,
            // // linkCallback: () => setIsBankOk(true), // Không cho tiếp tục
            // showCancel: false,
            // cancelCallBack: null,
            // })
            ModalController.showModal({
                icon: <IconSvg.ErrorIcon color={styles.INFO__COLOR} />,
                title: t('common_notify').toLocaleUpperCase(),
                colorTitle: styles.EKYC__COLOR,
                content: t('can_not_get_bank_account_information'),
                titleOK: t('common_alert_agree').toLocaleUpperCase(),
                typeColor: styles.INFO__COLOR,
                // linkCallback: () => setIsBankOk(true), // Không cho tiếp tục
                showCancel: false,
                cancelCallBack: null,
            })
        })
    }

    return {
        styles,
        bankAccNum,
        bankAccLink,
        bankAccConfirmCallback,
        expandRegisterMarginService,
        onChangeCheckBrokerageServices,
        onChangeOtherInformation,
        loading,
        checkBeforeNextStep,
        isShowReviewModal,
        loadingRegister,
        setIsShowReviewModal,
        switchStep,
        setLoadingRegister,
        institutionalList,
        t,
        bankLinkType,
        setExpandRegisterBank,
        expandRegisterBank,
        setBankAccNum,
        setBankAccLink,
        setBankLinkType,
        navigation,
        onChangeBrokerOrRemierRefInfo,
        getInstituation,
        setVisibleInstitutional,
        visibleInstitutional,
        setInstitutional,
        institutional,
        setReferrerCode,
        setReferrerName,
        onChangeReferrerInfo,
    }
}
