import React, { memo, useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { StyleSheet, View } from 'react-native'
import { Col, Row, Text } from 'native-base'

import { StoreContext } from '../../store'
import { dimensions, dimensions as dm, fontSizes as fs, fontWeights as fw } from '../../styles'

const HeaderList = ({ bgColor, noPadding }) => {
    const { t } = useTranslation()
    const { styles } = useContext(StoreContext)
    return (
        <Row
            style={{
                ...UI.HeaderTop_view,
                borderBottomColor: styles.DIVIDER__COLOR,
                marginHorizontal: dimensions.moderate(8),
                backgroundColor: bgColor,
            }}
        >
            <Col
                size={1}
                style={{
                    justifyContent: 'flex-start',
                }}
            >
                <Text style={{ fontWeight: fw.bold, fontSize: fs.verySmall, textAlign: 'center', color: styles.HEADER__CONTENT__COLOR }}>
                    {t('short_symbol')}
                </Text>
            </Col>
            <Col
                size={3}
                style={{
                    justifyContent: 'flex-start',
                }}
            >
                <Text style={{ fontWeight: fw.bold, fontSize: fs.verySmall, textAlign: 'left', color: styles.HEADER__CONTENT__COLOR }}>{t('event_tab')}</Text>
            </Col>
            <Col
                size={1}
                style={{
                    justifyContent: 'flex-end',
                }}
            >
                <Text style={{ fontWeight: fw.bold, fontSize: fs.verySmall, textAlign: 'right', color: styles.HEADER__CONTENT__COLOR }}>
                    {t('last_regist_date')}
                </Text>
            </Col>
        </Row>
    )
}

export default memo(HeaderList)

const UI = StyleSheet.create({
    HeaderTop_view: {
        borderBottomWidth: 1,
        flex: 0,
        paddingBottom: dm.vertical(12),
        paddingTop: dm.vertical(12),
    },
})
