import React, { createRef, PureComponent } from 'react'
import { ActivityIndicator, Dimensions, Platform, StyleSheet } from 'react-native'
import WebView from 'react-native-webview'

const changeData = (DATA_LINE, DATA_VOLUME) => `
setTimeout(() => {
  if (!chart) return true;
  if (areaSeries) areaSeries.setData(${JSON.stringify(DATA_LINE)});
  if (volumeSeries) volumeSeries.setData(${JSON.stringify(DATA_VOLUME)});
  if (chart && chartIntra) chart.timeScale().fitContent();
  true;
}, 100);
`

const changeDataMA = (DATA, key) => `
setTimeout(() => {
  if (!chart) return true; 
  if (lineMA5 && ${key} === 5) lineMA5.setData(${JSON.stringify(DATA)});
  if (lineMA10 && ${key} === 10) lineMA10.setData(${JSON.stringify(DATA)});
  if (lineMA20 && ${key} === 20) lineMA20.setData(${JSON.stringify(DATA)});
  if (lineMA30 && ${key} === 30) lineMA30.setData(${JSON.stringify(DATA)});
  true;
}, 100);
`

const source = Platform.select({
    ios: require('./light-chart.html'),
    android: { uri: 'file:///android_asset/light-chart.html' },
})

export default class LightChart extends PureComponent {
    static defaultProps = {
        onChange: () => {},
        initScript: '',
        data: [],
    }

    constructor(props) {
        super(props)
        this.chart = createRef()
        this.state = {
            deviceWidth: Dimensions.get('window').width,
            deviceHeight: Dimensions.get('window').height,
            webviewKey: 0,
        }
    }

    handleDimensionsUpdate = () => {
        // Here we update the device dimensions in the state if the layout changed
        // (triggering a render)
        const deviceWidth = Dimensions.get('window').width
        const deviceHeight = Dimensions.get('window').height
        if (deviceWidth !== this.state.deviceWidth || deviceHeight !== this.state.deviceHeight) {
            this.setState({ deviceWidth, deviceHeight }, this.repaint)
        }
    }

    componentWillReceiveProps(nextProps) {
        const { DATA_LINE, DATA_SMA5, DATA_SMA10, DATA_SMA20, DATA_SMA30 } = this.props
        if (!nextProps.DATA_LINE || !nextProps.DATA_LINE.length) return
        if (DATA_LINE !== nextProps.DATA_LINE) {
            this.update(nextProps.DATA_LINE, nextProps.DATA_VOLUME)
        }
        if (DATA_SMA5 !== nextProps.DATA_SMA5) {
            this.updateMA(nextProps.DATA_SMA5, 5, nextProps.typeTime)
        }
        if (DATA_SMA10 !== nextProps.DATA_SMA10) {
            this.updateMA(nextProps.DATA_SMA10, 10, nextProps.typeTime)
        }
        if (DATA_SMA20 !== nextProps.DATA_SMA20) {
            this.updateMA(nextProps.DATA_SMA20, 20, nextProps.typeTime)
        }
        if (DATA_SMA30 !== nextProps.DATA_SMA30) {
            this.updateMA(nextProps.DATA_SMA30, 30, nextProps.typeTime)
        }
    }

    update = (DATA_LINE, DATA_VOLUME) => {
        this.chart.current && this.chart.current.injectJavaScript(changeData(DATA_LINE, DATA_VOLUME))
    }

    updateMA = (DATA, key, typeTime) => {
        this.chart.current && this.chart.current.injectJavaScript(changeDataMA(DATA, key, typeTime))
    }

    repaint = () => {
        this.setState(
            {
                repaint: true,
            },
            () => {
                this.setState({ repaint: false })
            },
        )
    }

    reload = () => {
        this.setState({
            webviewKey: this.state.webviewKey + 1,
        })
    }

    onMessage = (event) => {
        const {
            nativeEvent: { data },
        } = event
        const { onLoadMore } = this.props
        const tooltip = JSON.parse(data)
        onLoadMore && onLoadMore(tooltip)
    }

    render() {
        const { initScript } = this.props

        return (
            <WebView
                allowUniversalAccessFromFileURLs={true}
                androidLayerType="software"
                domStorageEnabled={true}
                injectedJavaScript={initScript}
                javaScriptEnabled
                key={this.state.webviewKey}
                originWhitelist={['*']}
                ref={this.chart}
                renderLoading={() => <ActivityIndicator />}
                scrollEnabled={false}
                source={source}
                style={styles.webView}
                onContentProcessDidTerminate={this.reload}
                onMessage={this.onMessage}
                onShouldStartLoadWithRequest={(request) => {
                    return true
                }}
            />
        )
    }
}

const styles = StyleSheet.create({
    webView: {
        backgroundColor: 'transparent',
        flex: 1,
    },
})
