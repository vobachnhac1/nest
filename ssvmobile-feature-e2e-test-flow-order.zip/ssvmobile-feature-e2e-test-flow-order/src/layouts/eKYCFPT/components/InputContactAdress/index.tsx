import React, { useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Keyboard, Pressable, StyleSheet, TextInput, TouchableWithoutFeedback, View } from 'react-native'
import { TouchableOpacity } from 'react-native-gesture-handler'
import AntDesign from 'react-native-vector-icons/AntDesign'

import ArrowRight from '../../../../assets/images/common/ic_arrow_right.svg'
import { CustomFloatInput, Text } from '../../../../basic-components'
import ModalSelection from '../../../../components/list-selections'
import { StoreContext } from '../../../../store'
import { dimensions, fontSizes } from '../../../../styles'
import { reqFunct, sendRequest } from '../../../../utils'
import { removeSpecialSymbolForAddress } from '../../helpers'

interface IInputContactAdressProps {
    onChangeContactAddress: (contactAddress: string, details: { province: any; district: any; ward: any; detailsAdress: string }) => void
}
interface IItemSelect {
    label: string
    value: string
    data: IServiceResponeData | any
}

const ServiceInfo: IServiceInfo = {
    getProvince: {
        // Tỉnh thành
        reqFunct: reqFunct.GET_LIST_PROVICE,
        ServiceName: 'FOSqAccount_Common',
        WorkerName: 'FOSqAccount',
        Operation: 'Q',
    },
    getDistrict: {
        // Quận/Huyện
        reqFunct: reqFunct.GET_LIST_DISTRICT,
        ServiceName: 'FOSqAccount_Common',
        WorkerName: 'FOSqAccount',
        Operation: 'Q',
    },
    getWard: {
        // Phường xã
        reqFunct: reqFunct.GET_LIST_WARD,
        ServiceName: 'FOSqAccount_Common',
        WorkerName: 'FOSqAccount',
        Operation: 'Q',
    },
}

export const InputContactAdress = ({ onChangeContactAddress }: IInputContactAdressProps) => {
    const { t } = useTranslation()
    const addrContactRef = useRef<any>()
    const { styles } = useContext(StoreContext)
    // ----
    const [province, setProvice] = useState<IItemSelect | undefined>({ label: '', value: '', data: {} })
    const [district, setDistrict] = useState<IItemSelect | undefined>({ label: '', value: '', data: {} })
    const [ward, setWard] = useState<IItemSelect | undefined>({ label: '', value: '', data: {} })
    const [contactAddress, setContactAddress] = useState('')
    // --- list select
    const [listProvince, setListProvice] = useState<IItemSelect[]>([])
    const [listDistrict, setListDistrict] = useState<IItemSelect[]>([])
    const [listWard, setListWard] = useState<IItemSelect[]>([])
    // ---
    const [isOpenModalSelect, setIsOpenModalSelect] = useState(false)
    const [listSelection, setListSelection] = useState<IItemSelect[]>([])
    const [infoSelection, setInfoSelection] = useState<{
        type: string
        callback: (item?: IItemSelect) => void
    }>({
        type: '',
        callback: () => {},
    })

    useEffect(() => {
        getDataProvice()
    }, [])

    useEffect(() => {
        const addrString = `${contactAddress}, ${ward?.label}, ${district?.label}, ${province?.label}`
        onChangeContactAddress(addrString, {
            province,
            district,
            ward,
            detailsAdress: contactAddress,
        })
    }, [province, district, ward, contactAddress])

    const getDataProvice = () => {
        setListSelection([])
        const InputParams = ['26', '%']
        sendRequest(ServiceInfo.getProvince, InputParams, handleDataProvice)
    }
    const handleDataProvice = (reqInfoMap, message: IServiceRespone) => {
        // console.log('message >>',reqInfoMap, message)

        if (Number(message.Result) === 0) {
        } else {
            let jsondata: IServiceResponeData[] = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
                const dataSelect = jsondata.map((item) => ({ label: item.c1, value: item.c0, data: item }))
                // @ts-expect-error
                setListProvice(dataSelect)
                // @ts-expect-error
                setListSelection(dataSelect)
            } catch (err) {
                return
            }
        }
    }
    // -----
    const getDataDistrict = () => {
        setListSelection([])
        const InputParams = ['27', province?.value, '%']
        sendRequest(ServiceInfo.getProvince, InputParams, handleDataDistrict)
    }
    const handleDataDistrict = (reqInfoMap, message: IServiceRespone) => {
        if (Number(message.Result) === 0) {
        } else {
            let jsondata: IServiceResponeData[] = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
                const dataSelect = jsondata.map((item) => ({ label: item.c1, value: item.c0, data: item }))
                // @ts-expect-error
                setListDistrict(dataSelect)
                // @ts-expect-error
                setListSelection(dataSelect)
            } catch (err) {
                return
            }
        }
    }
    // -----
    const getDataWard = () => {
        setListSelection([])
        const InputParams = ['28', province?.value, district?.value, '%']
        sendRequest(ServiceInfo.getProvince, InputParams, handleDataWard)
    }
    const handleDataWard = (reqInfoMap, message: IServiceRespone) => {
        if (Number(message.Result) === 0) {
        } else {
            let jsondata: IServiceResponeData[] = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
                const dataSelect = jsondata.map((item) => ({ label: item.c1, value: item.c0, data: item }))
                // @ts-expect-error
                setListWard(dataSelect)
                // @ts-expect-error
                setListSelection(dataSelect)
            } catch (err) {
                return
            }
        }
    }
    const onPressSelectProvince = () => {
        getDataProvice()
        setInfoSelection({ type: 'NORMAL_SELECT', callback: setProvice })
        setIsOpenModalSelect(true)
    }
    const onPressSelectDistrict = () => {
        getDataDistrict()
        setInfoSelection({ type: 'NORMAL_SELECT', callback: setDistrict })
        setIsOpenModalSelect(true)
    }
    const onPressSelectWard = () => {
        getDataWard()
        setInfoSelection({ type: 'NORMAL_SELECT', callback: setWard })
        setIsOpenModalSelect(true)
    }

    return (
        <>
            <View style={{ marginHorizontal: dimensions.moderate(16) }}>
                <Text
                    style={{
                        color: styles.SECOND__CONTENT__COLOR,
                        fontSize: fontSizes.small,
                        paddingVertical: 2,
                    }}
                >
                    {t<string>('contact_address')} <Text style={{ color: 'red' }}>*</Text>
                </Text>
            </View>
            <Pressable onPress={onPressSelectProvince}>
                <View style={[UI.RowInput]}>
                    <CustomFloatInput
                        animationDuration={100}
                        ellipsizeMode="end"
                        isSelectInput
                        label={t('common_province')}
                        numberOfLines={1}
                        rightComponent={
                            province?.label ? (
                                <View style={UI.BlankSpace} />
                            ) : (
                                <TouchableOpacity style={{ paddingVertical: 8 }} onPress={onPressSelectProvince}>
                                    <ArrowRight style={{ color: styles.PRIMARY__CONTENT__COLOR, marginRight: 10 }} />
                                </TouchableOpacity>
                            )
                        }
                        value={province?.label}
                    />
                    <View style={UI.ButtonDelete}>
                        {province?.label ? (
                            <TouchableWithoutFeedback>
                                <TouchableOpacity
                                    style={{ paddingHorizontal: 8, paddingVertical: 8 }}
                                    onPress={() => {
                                        setProvice({ label: '', value: '', data: {} })
                                        setDistrict({ label: '', value: '', data: {} })
                                        setWard({ label: '', value: '', data: {} })
                                    }}
                                >
                                    <AntDesign
                                        color={styles.ICON__PRIMARY}
                                        name="closecircleo"
                                        size={20}
                                        style={{ marginHorizontal: dimensions.moderate(5) }}
                                    />
                                </TouchableOpacity>
                            </TouchableWithoutFeedback>
                        ) : null}
                    </View>
                </View>
            </Pressable>
            <Pressable onPress={onPressSelectDistrict}>
                <View style={[UI.RowInput]}>
                    <CustomFloatInput
                        animationDuration={100}
                        ellipsizeMode="end"
                        isSelectInput
                        label={t('common_district')}
                        numberOfLines={1}
                        rightComponent={
                            district?.label ? (
                                <View style={UI.BlankSpace} />
                            ) : (
                                <TouchableOpacity style={{ paddingVertical: 8 }} onPress={onPressSelectDistrict}>
                                    <ArrowRight style={{ color: styles.PRIMARY__CONTENT__COLOR, marginRight: 10 }} />
                                </TouchableOpacity>
                            )
                        }
                        value={district?.label}
                    />
                    <View style={UI.ButtonDelete}>
                        {district?.label ? (
                            <TouchableWithoutFeedback>
                                <TouchableOpacity
                                    style={{ paddingHorizontal: 8, paddingVertical: 8 }}
                                    onPress={() => {
                                        setDistrict({ label: '', value: '', data: {} })
                                        setWard({ label: '', value: '', data: {} })
                                    }}
                                >
                                    <AntDesign
                                        color={styles.ICON__PRIMARY}
                                        name="closecircleo"
                                        size={20}
                                        style={{ marginHorizontal: dimensions.moderate(5) }}
                                    />
                                </TouchableOpacity>
                            </TouchableWithoutFeedback>
                        ) : null}
                    </View>
                </View>
            </Pressable>
            <Pressable onPress={onPressSelectWard}>
                <View style={[UI.RowInput]}>
                    <CustomFloatInput
                        animationDuration={100}
                        ellipsizeMode="end"
                        isSelectInput
                        label={t('common_ward')}
                        numberOfLines={1}
                        rightComponent={
                            ward?.label ? (
                                <View style={UI.BlankSpace} />
                            ) : (
                                <TouchableOpacity style={{ paddingVertical: 8 }} onPress={onPressSelectWard}>
                                    <ArrowRight style={{ color: styles.PRIMARY__CONTENT__COLOR, marginRight: 10 }} />
                                </TouchableOpacity>
                            )
                        }
                        value={ward?.label}
                    />
                    <View style={UI.ButtonDelete}>
                        {ward?.label ? (
                            <TouchableWithoutFeedback>
                                <TouchableOpacity
                                    style={{ paddingHorizontal: 8, paddingVertical: 8 }}
                                    onPress={() => {
                                        setWard({ label: '', value: '', data: {} })
                                    }}
                                >
                                    <AntDesign
                                        color={styles.ICON__PRIMARY}
                                        name="closecircleo"
                                        size={20}
                                        style={{ marginHorizontal: dimensions.moderate(5) }}
                                    />
                                </TouchableOpacity>
                            </TouchableWithoutFeedback>
                        ) : null}
                    </View>
                </View>
            </Pressable>
            <View style={[UI.column]}>
                <Text
                    style={{
                        color: styles.SECOND__CONTENT__COLOR,
                        fontSize: fontSizes.small,
                        paddingVertical: 2,
                        marginBottom: 8,
                    }}
                >
                    {t<string>('common_address_details')}
                    <Text style={{ color: 'red' }}>*</Text>
                </Text>
                <Pressable
                    // onPress={() => addrContactRef.current?.focus()}
                    style={{
                        flex: 1,
                        width: '100%',
                        justifyContent: 'flex-start',
                        borderRadius: 8,
                        backgroundColor: styles.INPUT__BG,
                        padding: dimensions.moderate(8),
                    }}
                >
                    <TextInput
                        maxLength={100}
                        multiline
                        numberOfLines={2}
                        placeholderTextColor={styles.SECOND__CONTENT__COLOR}
                        ref={addrContactRef}
                        returnKeyType="done"
                        style={{
                            color: styles.PRIMARY__CONTENT__COLOR,
                            ...UI.RowEditAbleStyle,
                        }}
                        value={contactAddress}
                        onBlur={() => (contactAddress === '' ? setContactAddress('-') : null)}
                        onChangeText={(value) => {
                            // Replace all but accept "/" for address
                            setContactAddress(removeSpecialSymbolForAddress(value))
                            // setAddrContact(value.replace(/\r?\n|\r/g, ''))
                        }}
                        onFocus={() => (contactAddress === '-' ? setContactAddress('') : null)}
                        onSubmitEditing={() => {
                            // addrContactRef.current.focus()
                            Keyboard.dismiss()
                            // scrollViewRef.current?.scrollToEnd({ animated: true })
                        }}
                    />
                </Pressable>
            </View>

            <ModalSelection
                actionType={infoSelection.type}
                getSelectValue={infoSelection.callback}
                isOpen={isOpenModalSelect}
                listSelectionsProps={listSelection}
                setIsOpen={setIsOpenModalSelect}
            />
        </>
    )
}

const UI = StyleSheet.create({
    BlankSpace: {
        height: 10,
        width: dimensions.moderate(40),
    },
    ButtonDelete: {
        alignItems: 'center',
        height: '100%',
        justifyContent: 'center',
        position: 'absolute',
        right: 0,
    },
    RowEditAbleStyle: {
        borderRadius: 4,
        flex: 5,
        fontSize: fontSizes.small,
        padding: 0,
        paddingHorizontal: 5,
        paddingVertical: 8,
        textAlignVertical: 'top',
    },
    RowInput: {
        marginHorizontal: dimensions.moderate(16),
        marginVertical: dimensions.vertical(8),
    },
    column: {
        alignItems: 'flex-start',
        borderRadius: 12,
        flexDirection: 'column',
        marginHorizontal: dimensions.moderate(16),
        marginTop: dimensions.vertical(6),
        paddingVertical: 2,
    },
})
