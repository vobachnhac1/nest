import React, { memo, useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { ScrollView, StyleSheet, View } from 'react-native'
import { Button, Row } from 'native-base'

import { Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { dimensions, fontSizes, fontWeights } from '../../styles'

const RowOrderType = ({ orderTps, orderTp, onChangeOrderTp }) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()
    return (
        <Row style={UI.margin_top_row}>
            <View style={UI.left_row}>
                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontWeight: fontWeights.light }}>{t('order_tp')}</Text>
            </View>
            <View style={{ flex: 8, flexDirection: 'row' }}>
                <ScrollView horizontal keyboardShouldPersistTaps="handled">
                    {orderTps.map((item) => (
                        <Button
                            key={item.key}
                            small
                            style={{ backgroundColor: item.key === orderTp ? styles.PRIMARY : styles.BUTTON__SECONDARY, padding: 3, marginLeft: 2 }}
                            onPress={() => onChangeOrderTp(item)}
                        >
                            <Text
                                style={{
                                    color: item.key === orderTp ? 'white' : styles.PRIMARY__CONTENT__COLOR,
                                    fontSize: fontSizes.verySmall,
                                    paddingHorizontal: 5,
                                }}
                            >
                                {item.name}
                            </Text>
                        </Button>
                    ))}
                </ScrollView>
            </View>
        </Row>
    )
}
export default memo(RowOrderType, areEqualRowOrderTypeMemo)

function areEqualRowOrderTypeMemo(prev, next) {
    if (prev.orderTps === next.orderTps && prev.orderTp === next.orderTp) return true
    else return false
}

const UI = StyleSheet.create({
    left_row: {
        flex: 4,
        flexDirection: 'row',
        paddingVertical: 5,
    },
    margin_top_row: {
        marginTop: dimensions.halfIndent,
    },
})
