import React, { useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { ActivityIndicator, StyleSheet, ViewStyle } from 'react-native'
import ToastGlobal from 'react-native-toast-message'
import { Button, Row } from 'native-base'

import { Text } from '../../../basic-components'
import { StoreContext } from '../../../store'
import { dimensions as dm, fontSizes as fs, fontWeights as fw } from '../../../styles'

interface IButtonCustom {
    text: string
    disabled?: boolean
    isLoading?: boolean
    showTimeoutMessage?: boolean
    type?: 'buy' | 'sell' | 'cancel' | 'confirm' | 'back'
    last?: boolean
    first?: boolean
    visible?: boolean
    color?: string
    noPadding?: boolean
    children?: any
    [key: string]: any
    customStyle?: ViewStyle
}

const MAX_VISIBLE_LOADING_TIME = 20000
// -----------
const EkycButton = ({
    text = '', // Nội dung button
    disabled = false, // Có disable hay không
    isLoading = false, // Hiển thị loading cho button
    showTimeoutMessage = true, // show message toast khi Loading dừng do hết timeout
    type = 'buy', // type của button
    last = false, // có phải là button cuối cùng của list button hay không
    first = true, // có phải là button đầu tiên cùng của list button hay không
    visible = true,
    color = '',
    noPadding = false,
    children,
    customStyle,
    ...props
}: IButtonCustom) => {
    const [isVisibleLoading, setIsVisibleLoading] = useState(false)
    const { styles } = useContext(StoreContext)
    const maxVisible = useRef<null | ReturnType<typeof setTimeout>>(null)

    const { t } = useTranslation()
    useEffect(() => {
        setIsVisibleLoading(isLoading)
        if (isLoading) {
            maxVisible.current = setTimeout(() => {
                setIsVisibleLoading(false)
                if (showTimeoutMessage) {
                    ToastGlobal.show({
                        text2: t('processing_failed_please_check_and_try_again'),
                        type: 'warning',
                    })
                }
            }, MAX_VISIBLE_LOADING_TIME)
        } else {
            clearTimeout(maxVisible.current!)
        }
        return () => {
            clearTimeout(maxVisible.current!)
        }
    }, [isLoading])

    const getColorButton = (type, color) => {
        if (color) return color
        if (type === 'buy' || type === 'confirm') return styles.PRIMARY
        if (type === 'sell' || type === 'cancel') return styles.SELL__BG
        if (type === 'back') return 'transparent'
    }
    return (
        // <Row
        //     style={{
        //         paddingTop: dm.vertical(4),
        //         paddingBottom: dm.vertical(4),
        //         paddingHorizontal: noPadding ? 0 : dm.moderate(16),
        //         height: visible ? 'auto' : 0,
        //     }}
        // >
        <Button
            {...props}
            disabled={disabled || isVisibleLoading}
            style={{
                width: '90%',
                alignSelf: 'center',
                marginTop: last ? dm.vertical(0) : dm.vertical(16),
                justifyContent: 'center',
                borderRadius: 8,
                opacity: disabled || isVisibleLoading ? 0.5 : 1,
                backgroundColor: getColorButton(type, color),
                ...customStyle,
            }}
            transparent={type === 'back' ? true : false}
        >
            {isVisibleLoading && <ActivityIndicator color={'#fff'} style={UI.LoadingIndicator} />}
            <Text
                style={{
                    color: type === 'back' ? styles.SECOND__CONTENT__COLOR : '#f5f5f5',
                    fontWeight: type === 'back' ? fw.medium : fw.bold,
                    fontSize: fs.normal,
                }}
            >
                {t(text).toUpperCase()}
                {children}
            </Text>
        </Button>
        // </Row>
    )
}

export default EkycButton

const UI = StyleSheet.create({
    LoadingIndicator: {
        marginRight: 4,
    },
})
