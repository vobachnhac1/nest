/**
 * STEP 2: XÁC THỰCCHỨNG MINH THƯ/ VERIFY ID CARD
 * Gồm 3 bước nhỏ
 * 2.1 Xác thực CMND/CCCD mặt trước
 * 2.2 Xác thực CMND/CCCD mặt sau
 * 2.3 Xác thực khuôn mặt
 * 2.4 Xác thực thông tin đã eKyc
 */

import React, { useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { ActivityIndicator, Image, InteractionManager, Platform, ScrollView, StyleSheet, View } from 'react-native'
import { useNavigation } from '@react-navigation/native'
import { Container, Tab, Tabs } from 'native-base'

import { useLoading } from '../../../hoc'
import { StoreContext } from '../../../store'
import { dimensions, dimensions as dm, fontSizes as fs, fontWeights as fw, IconSvg } from '../../../styles'
import { ISwitchStep } from '../index'
import { CamreraFaceDetection } from './CameraFaceDetect'
import ConfirmInfo from './CommonInfo'
import { StepEkyc01 } from './StepEkyc01'
import { StepEkyc02 } from './StepEkyc02'

interface ISecondStepProps {
    switchStep: ISwitchStep
    subActiveStep: number
    handleProcessStep01: any
    isClearDataAndStartFromBegin: boolean
    activeStep: number
    onProcessUploaded: any
    forceRender: any
    onClearAllDataAndStartAgain: any
    handleProcessStep03: any
    isRenderStepThree: boolean
    forceUpdateStepThree: any
    ekycStep01Props: any
    ekycStep02Props: any
    ekycStepInfoProps: any
    navigation: any
    confirmInfoRef: any
    cameraFaceDetactRef: any
    scanFaceStepRef: any
}

export const SecondStep = ({
    switchStep,
    subActiveStep,
    isClearDataAndStartFromBegin,
    activeStep,
    onClearAllDataAndStartAgain,
    handleProcessStep03,
    isRenderStepThree,
    forceUpdateStepThree,
    ekycStep01Props,
    ekycStep02Props,
    navigation,
    confirmInfoRef,
    scanFaceStepRef,
    isRenderStepInfo,
    forceUpdateStepInfo,
}: ISecondStepProps) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()

    return (
        <View style={[UI.container, { backgroundColor: styles.PRIMARY__BG__COLOR }]}>
            <Tabs locked page={subActiveStep} renderTabBar={() => <View />}>
                <Tab heading={t('1')} style={{ backgroundColor: styles.PRIMARY__BG__COLOR, padding: 16 }}>
                    <StepEkyc01 {...ekycStep01Props} />
                </Tab>
                <Tab heading={t('2')} style={{ backgroundColor: styles.PRIMARY__BG__COLOR, padding: 16 }}>
                    <StepEkyc02 {...ekycStep02Props} />
                </Tab>
                <Tab heading={t('3')} style={{ backgroundColor: styles.PRIMARY__BG__COLOR, paddingBottom: 16 }}>
                    {subActiveStep === 2 || isRenderStepThree ? (
                        <CamreraFaceDetection
                            activeStep={activeStep}
                            forceRender={forceUpdateStepThree}
                            isClearDataAndStartFromBegin={isClearDataAndStartFromBegin}
                            ref={scanFaceStepRef}
                            subActiveStep={subActiveStep}
                            switchStep={switchStep}
                            onClearAllDataAndStartAgain={onClearAllDataAndStartAgain}
                            onProcessUploaded={handleProcessStep03}
                        />
                    ) : (
                        <ActivityIndicator color={styles.PRIMARY__CONTENT__COLOR} />
                    )}
                </Tab>
                <Tab heading={t('4')} style={{ backgroundColor: styles.PRIMARY__BG__COLOR, paddingBottom: 24 }}>
                    {isRenderStepInfo ? (
                        <ConfirmInfo forceRender={forceUpdateStepInfo} navigation={navigation} ref={confirmInfoRef} switchStep={switchStep} />
                    ) : null}
                </Tab>
            </Tabs>
        </View>
    )
}

const UI = StyleSheet.create({
    container: {
        alignContent: 'space-between',
        flex: 1,
        justifyContent: 'space-between',
    },
})
