import React, { useContext } from 'react'

import ErrorView from '../../components/trading-component/error-view'
import { StoreContext } from '../../store'
/**
 *
 * @returns {Component}         Return Data Component when connected true
 */
const ErrorLoading =
    (typeUser = 'normal') =>
    (Component) => {
        // ['normal', 'broker', 'both']

        const CheckUser = (props) => {
            const { connected } = useContext(StoreContext)
            if (!connected) {
                return <ErrorView {...props} />
            } else {
                return <Component {...props} />
            }
        }
        return CheckUser
    }

export default ErrorLoading
