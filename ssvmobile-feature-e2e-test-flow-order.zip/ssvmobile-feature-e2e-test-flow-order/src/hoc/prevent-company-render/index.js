import { glb_sv, reqFunct, Screens, socket_sv } from '../../utils'

const arrCompany = ['888', '102', '061', '020', '004', '023', '075', '082']

/**
 * Là một function. Return true or false
 * @param {Array} arrPrevent    Array các công ty không cho hiển thị
 * @returns {Boolean}           True went active Company have permission to access this Page|Tab|Scree|Component
 */
const preventCompanyRender = (arrPrevent = []) => {
    const AllowCompany = arrCompany.filter((c) => !arrPrevent.includes(c))
    const activeCode = glb_sv.activeCode
    return AllowCompany.includes(activeCode)
}

export default preventCompanyRender
