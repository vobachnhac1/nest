import React, { memo, useContext, useEffect, useRef, useState } from 'react'

import { glb_sv, socket_sv } from '../utils'
/**
 * Hàm có tác dụng: Như useEffect nhưng đợi tới khi có socket kết nối mới thực hiện effect
 * @param {Function} effect Truyền vào function như UseEffect
 * @param {Array} dependencies Array dependencies tương tự UseEffect
 */

export const useEffectAwaitConnectionTrading = (effect, dependencies) => {
    const checkConnectionRef = useRef<any>(null)

    useEffect(() => {
        checkConnectionRef.current = setInterval(() => {
            if (socket_sv.socket_trading?.connected) {
                clearInterval(checkConnectionRef.current)
                effect()
            }
        }, 1000)

        return () => {
            clearInterval(checkConnectionRef.current)
        }
    }, dependencies)
}
