import React, { useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { StyleSheet, TouchableOpacity, View } from 'react-native'

import { Text } from '../../../../basic-components'
import { StoreContext } from '../../../../store'
import { dimensions as dm, fontSizes as fs, fontWeights, IconSvg } from '../../../../styles'

export const OtherUtilsSMS = ({ setIsSMSFree = () => null, setIsSMSAlert = () => null, setIsSMSCharge = () => null, isSMSFree, isSMSAlert, isSMSCharge }) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()

    const [isCheckContent, setIsCheckContent] = useState(isSMSFree || false)
    const [isCheckContent02, setIsCheckContent02] = useState(isSMSAlert || false)
    const [isCheckContent03, setIsCheckContent03] = useState(isSMSCharge || false)

    useEffect(() => {
        setIsCheckContent(isSMSFree)
    }, [isSMSFree])
    useEffect(() => {
        setIsCheckContent02(isSMSAlert)
    }, [isSMSAlert])
    useEffect(() => {
        setIsCheckContent03(isSMSCharge)
    }, [isSMSCharge])

    useEffect(() => {
        setIsSMSFree(isCheckContent)
    }, [isCheckContent])

    useEffect(() => {
        setIsSMSAlert(isCheckContent02)
    }, [isCheckContent02])

    useEffect(() => {
        setIsSMSCharge(isCheckContent03)
    }, [isCheckContent03])

    return (
        <>
            <View style={[UI.RowAction]}>
                <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fs.normal, fontWeight: fontWeights.bold }}>{t('head_sms')}</Text>
            </View>
            <View style={UI.row}>
                <TouchableOpacity
                    activeOpacity={0.9}
                    style={{ flexDirection: 'row', alignItems: 'center', marginTop: dm.vertical(16) }}
                    onPress={() => setIsCheckContent((value) => !value)}
                >
                    <View style={{ paddingTop: 2 }}>
                        <IconSvg.CheckboxIcon active={isCheckContent} colorActive={styles.PRIMARY} colorunActive={styles.PRIMARY__CONTENT__COLOR} />
                    </View>
                    <View>
                        <View>
                            <Text
                                style={{
                                    fontSize: fs.normal,
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                    marginLeft: dm.moderate(8),
                                    marginRight: 16,
                                }}
                            >
                                {t('free_sms')}
                            </Text>
                        </View>
                        <View>
                            <Text
                                style={{
                                    fontSize: fs.verySmall,
                                    color: styles.SECOND__CONTENT__COLOR,
                                    marginLeft: dm.moderate(8),
                                    marginRight: 16,
                                }}
                            >
                                {t('free_sms_note')}
                            </Text>
                        </View>
                    </View>
                </TouchableOpacity>
            </View>
            <View style={UI.row}>
                <TouchableOpacity
                    activeOpacity={0.9}
                    style={{ flexDirection: 'row', alignItems: 'center', marginTop: dm.vertical(16) }}
                    onPress={() => setIsCheckContent02((value) => !value)}
                >
                    <View style={{ paddingTop: 2 }}>
                        <IconSvg.CheckboxIcon active={isCheckContent02} colorActive={styles.PRIMARY} colorunActive={styles.PRIMARY__CONTENT__COLOR} />
                    </View>
                    <View>
                        <View>
                            <Text
                                style={{
                                    fontSize: fs.normal,
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                    marginLeft: dm.moderate(8),
                                    marginRight: 16,
                                }}
                            >
                                {t('notify_sms')}
                            </Text>
                        </View>
                        <View>
                            <Text
                                style={{
                                    fontSize: fs.verySmall,
                                    color: styles.SECOND__CONTENT__COLOR,
                                    marginLeft: dm.moderate(8),
                                    marginRight: 16,
                                }}
                            >
                                {t('notify_sms_note')}
                            </Text>
                        </View>
                    </View>
                </TouchableOpacity>
            </View>
            <View style={UI.row}>
                <TouchableOpacity
                    activeOpacity={0.9}
                    style={{ flexDirection: 'row', alignItems: 'center', marginTop: dm.vertical(16) }}
                    onPress={() => setIsCheckContent03((value) => !value)}
                >
                    <View style={{ paddingTop: 2 }}>
                        <IconSvg.CheckboxIcon active={isCheckContent03} colorActive={styles.PRIMARY} colorunActive={styles.PRIMARY__CONTENT__COLOR} />
                    </View>
                    <View>
                        <View>
                            <Text
                                style={{
                                    fontSize: fs.normal,
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                    marginLeft: dm.moderate(8),
                                    marginRight: 16,
                                }}
                            >
                                {t('advance_sms')}
                            </Text>
                        </View>
                        <View>
                            <Text
                                style={{
                                    fontSize: fs.verySmall,
                                    color: styles.SECOND__CONTENT__COLOR,
                                    marginLeft: dm.moderate(8),
                                    marginRight: 16,
                                }}
                            >
                                {t('advance_sms_note')}
                            </Text>
                        </View>
                    </View>
                </TouchableOpacity>
            </View>
        </>
    )
}

const UI = StyleSheet.create({
    RowAction: { alignItems: 'center', flexDirection: 'row', paddingHorizontal: dm.moderate(16), paddingTop: dm.vertical(16) },
    row: {
        alignItems: 'center',
        borderRadius: 12,
        flexDirection: 'row',
        marginHorizontal: dm.moderate(16),
    },
})
