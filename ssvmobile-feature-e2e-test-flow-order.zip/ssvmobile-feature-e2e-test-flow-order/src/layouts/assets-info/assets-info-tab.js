import React, { memo, useCallback, useContext, useEffect, useState } from 'react'
import { InteractionManager, View } from 'react-native'
import { getStatusBarHeight } from 'react-native-status-bar-height'
import SyncStorage from 'sync-storage'

import { FocusAwareStatusBar } from '../../basic-components'
import NotAuthView from '../../components/notAuth-view'
import { StoreContext } from '../../store'
import { eventList, glb_sv, Screens, STORE_KEY } from '../../utils'
import AssetsInfo from './index'

function MainPage({ navigation }) {
    const { theme, styles, authFlag } = useContext(StoreContext)

    const [, updateState] = useState()
    const forceUpdate = useCallback(() => updateState({}), [])

    useEffect(() => {
        glb_sv.focusAssetInfo = true
        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.EKYC_SUCCESS) {
                forceUpdate()
            }
        })

        return () => {
            glb_sv.focusAssetInfo = false
            commonEvent.unsubscribe()
        }
    }, [])

    useEffect(() => {
        if (!authFlag && !SyncStorage.get(STORE_KEY.AutoLoginMode)) {
            InteractionManager.runAfterInteractions(() => {
                setTimeout(() => {
                    navigation.navigate(Screens.SIGN_IN)
                }, 0)
            })
        }
    }, [authFlag])

    if (!authFlag || glb_sv.objShareGlb.userInfo.c9 === 'N') {
        return <NotAuthView isBottom={true} navigation={navigation} />
    }

    return (
        <View style={{ flex: 1, backgroundColor: styles.PRIMARY__BG__COLOR }}>
            <FocusAwareStatusBar backgroundColor={'transparent'} barStyle={theme.includes('DARK') ? 'light-content' : 'dark-content'} translucent={true} />
            <View style={{ flex: 1, paddingBottom: 8, marginTop: getStatusBarHeight() }}>
                <AssetsInfo navigation={navigation} />
            </View>
        </View>
    )
}

export default memo(MainPage)
