import { alertType, eventList, glb_sv } from '../utils'

/**
 * Hàm có tác dụng: gọi otp khi có error
 *
 */

interface IUseModalOtpWhenErrOptions {
    callback: (...arg: any[]) => void
    continueVerify: boolean
}

const useModalOtpWhenErr = (message: IServiceRespone, { callback = () => console.log('callback successs'), continueVerify }: IUseModalOtpWhenErrOptions) => {
    if (!continueVerify) return { hasAlertErrOtp: false }
    // ------------------
    if (glb_sv.otpCases.includes(message.Code)) {
        glb_sv.commonEvent.next({
            type: eventList.SHOW_ALERT,
            alertType: alertType.OTP_AUTHEN_ERR,
            message,
            callback,
        })
        return { hasAlertErrOtp: true }
    }
    return { hasAlertErrOtp: false }
}

export default useModalOtpWhenErr
