import React, { useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { StyleSheet, View } from 'react-native'
import { Col } from 'native-base'

import { Text } from '../../../basic-components'
import { StoreContext } from '../../../store'
import { dimensions as dm, fontSizes as fs, fontWeights as fw } from '../../../styles'

interface IRowTableData {
    type?: 'table'
    colSpan?: number
    dataSub?: string[]
    colorSub?: string
    text: string
    text2?: string
    textAlign?: 'left' | 'right' | 'center'
    colorText?: string
    colorText2?: string
    typeOrder?: 'buy' | 'sell'
    underline?: boolean
    [key: string]: any
}

const RowTableData = ({
    type = 'table', // type của table
    colSpan, //
    dataSub = [], //
    colorSub, //
    text,
    text2,
    textAlign = 'left', //
    colorText,
    colorText2,
    typeOrder,
    underline,
    ...props
}: IRowTableData) => {
    const { styles, language } = useContext(StoreContext)
    const { t } = useTranslation()
    const getTextTypeOrder = (typeOrder) => {
        if (language === 'VI') {
            if (typeOrder === 'buy') return 'M'
            if (typeOrder === 'sell') return 'B'
            if (typeOrder === 'hold') return 'G'
        } else {
            if (typeOrder === 'buy') return 'B'
            if (typeOrder === 'sell') return 'S'
            if (typeOrder === 'hold') return 'H'
        }
    }
    return (
        <Col
            size={colSpan}
            style={{
                justifyContent: typeOrder ? 'flex-start' : 'center',
                flexDirection: typeOrder ? 'row' : 'column',
                alignItems: typeOrder ? 'center' : undefined,
            }}
        >
            {typeOrder ? (
                <View
                    style={{
                        width: dm.moderate(18),
                        height: dm.moderate(18),
                        marginRight: 4,
                        backgroundColor: typeOrder === 'buy' ? styles.UP__COLOR : typeOrder === 'sell' ? styles.DOWN__COLOR : '#f2c94c',
                        justifyContent: 'center',
                        alignItems: 'center',
                        borderRadius: 16,
                    }}
                >
                    <Text style={{ color: '#fff', fontSize: fs.verySmall, fontWeight: fw.bold }}>{getTextTypeOrder(typeOrder)}</Text>
                </View>
            ) : null}
            {dataSub[0] ? (
                <View style={{ flex: 1, flexDirection: 'row' }}>
                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fs.verySmall }}>{dataSub[0]}</Text>
                    <View style={{ ...UI.Badge_Sub, backgroundColor: colorSub }}>
                        <Text style={{ color: '#fff', fontSize: fs.verySmall, fontWeight: fw.bold }}>{dataSub[1]}</Text>
                    </View>
                </View>
            ) : null}
            {text ? (
                <Text
                    style={{
                        color: colorText ? colorText : styles.PRIMARY__CONTENT__COLOR,
                        fontSize: fs.verySmall,
                        textAlign: textAlign,
                        textDecorationLine: underline ? 'underline' : undefined,
                        textDecorationStyle: underline ? 'dotted' : undefined,
                    }}
                >
                    {text}
                </Text>
            ) : null}
            {text2 ? (
                <Text
                    style={{
                        color: colorText2 ? colorText2 : styles.SECOND__CONTENT__COLOR,
                        fontSize: fs.verySmall,
                        textAlign: textAlign,
                        textDecorationLine: underline ? 'underline' : undefined,
                        textDecorationStyle: underline ? 'dotted' : undefined,
                    }}
                >
                    {text2}
                </Text>
            ) : null}
        </Col>
    )
}

export default RowTableData

const UI = StyleSheet.create({
    Badge_Sub: {
        alignItems: 'center',
        borderRadius: 4,
        height: dm.moderate(16),
        justifyContent: 'center',
        marginLeft: 4,
        width: dm.moderate(16),
    },
})
