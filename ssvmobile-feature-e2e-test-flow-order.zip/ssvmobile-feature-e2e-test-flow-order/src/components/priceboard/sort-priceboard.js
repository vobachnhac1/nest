import React, { useCallback, useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Pressable, StyleSheet, View } from 'react-native'
import DeviceInfo from 'react-native-device-info'
import DraggableFlatList from 'react-native-draggable-flatlist'
import Orientation from 'react-native-orientation-locker'
import { SafeAreaView } from 'react-native-safe-area-context'
import AntDesign from 'react-native-vector-icons/AntDesign'
import Feather from 'react-native-vector-icons/Feather'
import CheckBox from '@react-native-community/checkbox'
import { Button, Left, ListItem, Right } from 'native-base'
import SyncStorage from 'sync-storage'

import IconBack from '../../assets/images/common/ic_back.svg'
import { Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { dimensions, fontSizes } from '../../styles'
import { glb_sv, STORE_KEY } from '../../utils'

const isTablet = DeviceInfo.isTablet()

const SortPriceboard = ({ navigation, route }) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()
    const { isOddlot } = route.params

    const [HEDAER_TABLE, setHeader] = useState(isOddlot ? glb_sv.LIST_HEADER_PRICEBOARD_ODDLOT : glb_sv.LIST_HEADER_PRICEBOARD)
    const [show, showSort] = useState(false)

    useEffect(() => {
        Orientation.lockToPortrait()

        return () => {
            Orientation.lockToLandscapeRight()
        }
    }, [])

    const changeStatus = (item) => {
        if (item.type === 't55') return
        showSort(true)
        const newList = [...HEDAER_TABLE]
        const newItem = newList.find((e) => e.type === item.type)
        if (newItem) {
            newItem.isShow = !newItem.isShow
        }
        setHeader(newList)
    }

    const renderItem = ({ item, index, drag, isActive }) => {
        return (
            <ListItem
                activeOpacity={0.6}
                noBorder
                style={{ backgroundColor: isActive ? styles.PRIMARY : '', marginLeft: 0, paddingLeft: 16 }}
                underlayColor="transparent"
                onLongPress={drag}
                onPress={() => changeStatus(item)}
            >
                <Left>
                    <Text style={{ fontSize: fontSizes.normal, color: isActive ? 'white' : styles.SECOND__CONTENT__COLOR }}>{index + 1} </Text>
                    <Text
                        style={{
                            fontSize: fontSizes.medium,
                            color: isActive ? 'white' : styles.PRIMARY__CONTENT__COLOR,
                        }}
                    >
                        {t(item.type)}
                    </Text>
                </Left>
                <Right style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                    {item.type !== 't55' ? <CheckBox disabled={true} tintColors={{ true: styles.PRIMARY }} value={item.isShow} /> : <View />}
                    <Feather color={isActive ? 'white' : styles.SECOND__CONTENT__COLOR} name="menu" size={30} />
                </Right>
            </ListItem>
        )
    }

    const goBack = () => {
        Orientation.lockToLandscapeRight()
        navigation.pop()
    }

    const handleSort = () => {
        const newList = [...HEDAER_TABLE]
        if (isOddlot) {
            glb_sv.LIST_HEADER_PRICEBOARD_ODDLOT = newList
            SyncStorage.set(STORE_KEY.LIST_HEADER_PRICEBOARD_ODDLOT, newList)
        } else {
            glb_sv.LIST_HEADER_PRICEBOARD = newList
            SyncStorage.set(STORE_KEY.LIST_HEADER_PRICEBOARD, newList)
        }

        route.params.setHeader(newList)
        Orientation.lockToLandscapeRight()
        navigation.pop()
    }

    const renderSepartor = useCallback(() => {
        return <View style={{ borderBottomColor: styles.DIVIDER__COLOR, borderBottomWidth: 1 }} />
    }, [])

    return (
        <View
            style={{
                flex: 1,
                backgroundColor: styles.PRIMARY__BG__COLOR,
            }}
        >
            <SafeAreaView style={{ flex: 1, backgroundColor: styles.PRIMARY__BG__COLOR }}>
                <View style={{ flexDirection: 'row', height: isTablet ? 50 : 40, paddingHorizontal: 5, marginTop: 5 }}>
                    <Button style={{ paddingTop: 0, paddingBottom: 0, height: dimensions.vertical(35), flex: 0 }} transparent onPress={goBack}>
                        <IconBack style={{ color: styles.ICON__PRIMARY }} />
                    </Button>
                    <View style={{ flexDirection: 'column', flex: 1, borderRadius: 10, padding: 0, justifyContent: 'center', alignItems: 'center' }}>
                        <Text style={{ fontSize: fontSizes.xmedium, color: styles.PRIMARY__CONTENT__COLOR }}>{t('manage_priceboard')}</Text>
                    </View>
                    <Pressable disabled={!show} hitSlop={10} style={{ paddingTop: 8, paddingBottom: 0, paddingHorizontal: 6 }} onPress={handleSort}>
                        <AntDesign color={show ? styles.PRIMARY : styles.PRIMARY__BG__COLOR} name="check" size={24} />
                    </Pressable>
                </View>
                <View style={{ flex: 1, flexGrow: 1, flexShrink: 1 }}>
                    <DraggableFlatList
                        data={HEDAER_TABLE}
                        ItemSeparatorComponent={renderSepartor}
                        keyExtractor={(item, index) => `draggable-item-${item.type}`}
                        renderItem={renderItem}
                        onDragEnd={({ data }) => {
                            showSort(true)
                            setHeader(data)
                        }}
                    />
                </View>
            </SafeAreaView>
        </View>
    )
}

const UI = StyleSheet.create({
    container: {
        marginVertical: dimensions.halfIndent,
        paddingHorizontal: dimensions.halfIndent,
    },
    header: {
        paddingVertical: 6,
    },
    item: {
        alignItems: 'center',
    },
    title: {
        fontSize: fontSizes.small,
        paddingVertical: 8,
    },
})

export default SortPriceboard
