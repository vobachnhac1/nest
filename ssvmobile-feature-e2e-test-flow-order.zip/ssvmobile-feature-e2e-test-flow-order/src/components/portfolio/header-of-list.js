import React, { memo, useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { Dimensions, StyleSheet, View } from 'react-native'
import { Body, Row } from 'native-base'

import { Text } from '../../basic-components'
import OrderByComponent from '../../basic-components/order-by'
import { StoreContext } from '../../store'
import { dimensions, fontSizes } from '../../styles'

const { width } = Dimensions.get('window')
const isFiveColumn = width > 600 && width < 910
const isSevenColumn = width > 910

const HeaderOfList = ({ sort, changeTypeSort, type, noPadding }) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()

    if (type === 'suggest') {
        return (
            <Row style={UI.HeaderTop__view}>
                <Body style={{ flexDirection: 'row', justifyContent: 'flex-start', flex: 1, alignItems: 'flex-start' }}>
                    <OrderByComponent
                        changeTypeSort={changeTypeSort}
                        notSort={true}
                        sortType="t55"
                        status={sort === 't55|up' ? 'asc' : sort === 't55|down' ? 'desc' : ''}
                        title={t('short_symbol')}
                    />
                </Body>
                <Body style={{ flexDirection: 'row', justifyContent: 'flex-start', flex: 1, alignItems: 'flex-start' }}>
                    <OrderByComponent
                        changeTypeSort={changeTypeSort}
                        notSort={true}
                        sortType="t31"
                        status={sort === 't31|up' ? 'asc' : sort === 't31|down' ? 'desc' : ''}
                        title={t('price')}
                    />
                </Body>
                <Body style={{ flexDirection: 'row', justifyContent: 'flex-start', flex: 1, alignItems: 'flex-start' }}>
                    <OrderByComponent
                        changeTypeSort={changeTypeSort}
                        notSort={true}
                        sortType="t31_incr"
                        status={sort === 't31_incr|up' ? 'asc' : sort === 't31_incr|down' ? 'desc' : ''}
                        title="-/+ (%)"
                    />
                </Body>
                <View style={{ flex: 1.8 }} />
            </Row>
        )
    }

    return (
        <Row
            style={[
                UI.HeaderTop__view,
                {
                    backgroundColor: styles.PRIMARY__BG__COLOR,
                    paddingHorizontal: noPadding ? 0 : dimensions.moderate(16),
                    borderBottomColor: styles.DIVIDER__COLOR,
                    borderBottomWidth: 1,
                },
            ]}
        >
            <Body style={{ flexDirection: 'row', justifyContent: 'flex-start', flex: 6, alignItems: 'flex-start' }}>
                <OrderByComponent
                    changeTypeSort={changeTypeSort}
                    sortType="t55"
                    status={sort === 't55|up' ? 'asc' : sort === 't55|down' ? 'desc' : ''}
                    title={t('short_symbol')}
                />
            </Body>

            <View style={{ minWidth: 100, maxWidth: 100, flex: 3 }} />
            <View style={UI.column}>
                {/* <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, fontWeight: '500' }}>
                    {t('price')}
                </Text> */}
                <OrderByComponent
                    changeTypeSort={changeTypeSort}
                    sortType="t31_incr_per"
                    status={sort === 't31_incr_per|up' ? 'asc' : sort === 't31_incr_per|down' ? 'desc' : ''}
                    title={t('common_change')}
                />
            </View>
            {isFiveColumn ||
                (isSevenColumn && (
                    <View style={UI.column}>
                        <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, fontWeight: '500' }}>{t('priceboard_buy_price_1')}</Text>
                    </View>
                ))}
            {isFiveColumn ||
                (isSevenColumn && (
                    <View style={UI.column}>
                        <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, fontWeight: '500' }}>
                            {t('priceboard_sell_price_1')}
                        </Text>
                    </View>
                ))}
            {isSevenColumn && (
                <View style={UI.column}>
                    <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, fontWeight: '500' }}>{t('priceboard_qty')}</Text>
                </View>
            )}
            {isSevenColumn && (
                <View style={UI.column}>
                    <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, fontWeight: '500' }}>{t('priceboard_short_room')}</Text>
                </View>
            )}
        </Row>
    )
}

export default memo(HeaderOfList)

const UI = StyleSheet.create({
    HeaderTop__view: {
        flex: 0,
        paddingVertical: dimensions.moderate(8),
    },
    column: {
        alignItems: 'flex-end',
        flex: 3,
        justifyContent: 'center',
    },
})
