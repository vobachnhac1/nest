import React, { memo, useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { Platform, StyleSheet, View } from 'react-native'

import { Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { fontSizes } from '../../styles'
import { WIDTH } from '../../styles/helper/dimensions'

const MessageErrorNetwork = () => {
    // return null
    const { t } = useTranslation()
    const { connected } = useContext(StoreContext)
    if (connected) return null
    return (
        <View style={styles.containerToaster}>
            <View style={styles.container}>
                <View style={styles.contentContainer}>
                    <Text style={styles.text}>{t('network_error')}</Text>
                </View>
            </View>
        </View>
    )
}

export default memo(MessageErrorNetwork)

const styles = StyleSheet.create({
    container: {
        alignItems: 'center',
        flex: 1,
        justifyContent: 'center',
        marginHorizontal: 0,
        paddingTop: Platform.os === 'ios' ? 33 : 28,
    },
    containerToaster: {
        backgroundColor: 'red',
        height: 56,
        justifyContent: 'center',
        width: '100%',
        // elevation: 56 + (Platform.os === 'ios' ? 33 : 28),
    },
    contentContainer: {
        alignItems: 'center',
        elevation: 8,
        flexDirection: 'row',
        paddingHorizontal: 5,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.16,
        shadowRadius: 8,
        width: Math.min(WIDTH, 414),
    },
    errorContainer: {
        backgroundColor: 'red',
    },
    errorText: {
        color: 'white',
    },
    infoContainer: {
        backgroundColor: 'skyblue',
    },
    infoText: {
        color: 'white',
    },
    successContainer: {
        backgroundColor: 'green',
    },
    successText: {
        color: 'white',
    },
    text: {
        color: 'white',
        flex: 1,
        fontSize: fontSizes.small,
        textAlign: 'center',
    },
})
