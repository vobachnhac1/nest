import React, { PureComponent } from 'react'
import dayjs from 'dayjs'
import { createChart, PriceScaleMode } from 'lightweight-charts'
import cloneDeep from 'lodash/cloneDeep'
import throttle from 'lodash/throttle'
import moment from 'moment'

export default class Chart extends PureComponent {
    constructor(props) {
        super(props)
        this.data = window.dataLightChart
        // .sort(function (a, b) {
        //     if (a.seq > b.seq) return 1
        //     if (a.seq < b.seq) return -1
        //     if (a.seq === b.seq) {
        //         if (a.subseq > b.subseq) return 1
        //         if (a.subseq < b.subseq) return -1
        //     }
        //     return 0
        // });

        this.ref = window.ref
        this.timeChart = '1D'
        this.flagdataSMA5 = window.flagdataSMA5
        this.flagdataSMA10 = window.flagdataSMA10
        this.flagdataSMA20 = window.flagdataSMA20
        this.flagdataSMA30 = window.flagdataSMA30

        this.throttled = throttle(
            () => {
                this.parseDataHistory(this.data)
                this.areaSeries.setData(this.DATA_LINE)
                if (this.DATA_SMA5) this.lineMA5.setData(this.DATA_SMA5)
                if (this.DATA_SMA10) this.lineMA10.setData(this.DATA_SMA10)
                if (this.DATA_SMA20) this.lineMA20.setData(this.DATA_SMA20)
                if (this.DATA_SMA30) this.lineMA30.setData(this.DATA_SMA30)
                this.volumeSeries.setData(this.DATA_VOLUME)
                this.lineRef.setData(this.dataRef)
                this.chart.timeScale().fitContent()
            },
            500,
            { trailing: true },
        )
    }

    componentDidMount() {
        this.parseDataHistory(this.data)
        const chartElement = document.getElementById('lightchart')
        this.chart = createChart(chartElement, {
            width: window.screen.width - 4,
            height: 250,
            rightPriceScale: {
                scaleMargins: {
                    top: 0.1,
                    bottom: 0.1,
                    mode: PriceScaleMode.Percentage,
                },
                borderVisible: false,
            },
            timeScale: {
                timeVisible: true,
                secondsVisible: true,
                borderVisible: false,
                barSpacing: 40,
            },
            layout: window.theme.includes('DARK')
                ? {
                      backgroundColor: 'transparent',
                      textColor: '#93969C',
                      fontSize: 8,
                  }
                : {
                      backgroundColor: 'transparent',
                      fontSize: 8,
                  },
            grid: window.theme.includes('DARK')
                ? {
                      vertLines: {
                          color: 'rgba(42, 46, 57, 0.6)',
                      },
                      horzLines: {
                          color: 'rgba(42, 46, 57, 0.6)',
                      },
                  }
                : {
                      vertLines: {
                          color: 'rgba(42, 46, 57, 0.05)',
                      },
                      horzLines: {
                          color: 'rgba(42, 46, 57, 0.05)',
                      },
                  },
            handleScroll: true,
            handleScale: false,
        })
        this.areaSeries = this.chart.addAreaSeries({
            topColor: 'rgba(33, 150, 243, 0.4)',
            bottomColor: 'rgba(33, 150, 243, 0)',
            lineColor: 'rgba(33, 150, 243, 1)',
            lineWidth: 1,
        })

        this.lineRef = this.chart.addLineSeries({
            color: '#FFBC16',
            lineWidth: 1,
            lastValueVisible: false,
            priceLineVisible: false,
        })
        this.lineMA5 = this.chart.addLineSeries({
            color: '#FFA43B',
            lineWidth: 1,
            lastValueVisible: false,
            priceLineVisible: false,
        })

        this.lineMA10 = this.chart.addLineSeries({
            color: '#00CFED',
            lineWidth: 1,
            lastValueVisible: false,
            priceLineVisible: false,
        })
        this.lineMA20 = this.chart.addLineSeries({
            color: '#FF725B',
            lineWidth: 1,
            lastValueVisible: false,
            priceLineVisible: false,
        })
        this.lineMA30 = this.chart.addLineSeries({
            color: '#196EEE',
            lineWidth: 1,
            lastValueVisible: false,
            priceLineVisible: false,
        })
        this.volumeSeries = this.chart.addHistogramSeries({
            color: '#26a69a',
            lineWidth: 1,
            priceFormat: {
                type: 'volume',
            },
            overlay: true,
            scaleMargins: {
                top: 0.8,
                bottom: 0.05,
            },
        })

        this.areaSeries.setData(this.DATA_LINE)
        this.lineMA5.setData(this.DATA_SMA5)
        this.lineMA10.setData(this.DATA_SMA10)
        this.lineMA20.setData(this.DATA_SMA20)
        this.lineMA30.setData(this.DATA_SMA30)
        this.volumeSeries.setData(this.DATA_VOLUME)
        this.lineRef.setData(this.dataRef)

        this.chart.applyOptions({
            localization: {
                locale: window.locale,
                priceFormatter: function (price) {
                    return formatNumber(price)
                },
            },
        })

        this.chart.timeScale().fitContent()

        this.eventMarket = window.eventMarket.subscribe((msg) => {
            if (msg.type === 'lightchart-history') {
                this.data = msg.data
                this.parseDataHistory(this.data)
                this.areaSeries.setData(this.DATA_LINE)
                this.lineMA5.setData(this.DATA_SMA5)
                this.lineMA10.setData(this.DATA_SMA10)
                this.lineMA20.setData(this.DATA_SMA20)
                this.lineMA30.setData(this.DATA_SMA30)
                this.volumeSeries.setData(this.DATA_VOLUME)
                this.lineRef.setData(this.dataRef)
            }
            if (msg.type === 'lightchart-realtime') {
                if (this.data.length) {
                    const lastNode = this.data[this.data.length - 1]
                    if (lastNode && msg.newIndexNode) {
                        if (lastNode.time < msg.newIndexNode.time) {
                            this.data.push(msg.newIndexNode)
                            this.throttled()
                        } else {
                            lastNode.C = msg.newIndexNode.C
                            lastNode.V = msg.newIndexNode.V
                            this.throttled()
                        }
                    }
                } else {
                    this.data.push(msg.newIndexNode)
                    this.throttled()
                }
            }
            if (msg.type === 'lightchart-change-ma') {
                this.flagdataSMA5 = msg.flagdataSMA5
                this.flagdataSMA10 = msg.flagdataSMA10
                this.flagdataSMA20 = msg.flagdataSMA20
                this.flagdataSMA30 = msg.flagdataSMA30

                this.DATA_SMA5 = this.flagdataSMA5 ? SMA(this.DATA_LINE, 5) : []
                this.DATA_SMA10 = this.flagdataSMA10 ? SMA(this.DATA_LINE, 10) : []
                this.DATA_SMA20 = this.flagdataSMA20 ? SMA(this.DATA_LINE, 20) : []
                this.DATA_SMA30 = this.flagdataSMA30 ? SMA(this.DATA_LINE, 30) : []

                this.lineMA5.setData(this.DATA_SMA5)
                this.lineMA10.setData(this.DATA_SMA10)
                this.lineMA20.setData(this.DATA_SMA20)
                this.lineMA30.setData(this.DATA_SMA30)
            }
        })
    }

    componentWillUnmount() {
        this.eventMarket.unsubscribe()
        this.unmount = true
    }

    parseDataHistory = (data) => {
        let dataChart = []
        if (data.length > 500 || moment() > moment('10:00:00', 'HH:mm:ss')) dataChart = chartConvertMinutes(data)
        else dataChart = chartConvertSecond(data)

        const dataStock_line = []
        const dataStock_volume = []

        for (let index = 0; index < dataChart.length; index++) {
            const timeStamp = dateToChartTimeMinute(dayjs(dataChart[index].time).toDate())
            dataStock_line.push({ value: dataChart[index].C, time: timeStamp })
            dataStock_volume.push({
                value: dataChart[index].V,
                time: timeStamp,
            })
        }

        if (dataStock_line.length && this.timeChart === '1D') {
            const dataRef = [
                { value: this.ref, time: dataStock_line[0].time },
                { value: this.ref, time: dataStock_line[dataStock_line.length - 1].time },
            ]
            const dataSMA5 = this.flagdataSMA5 ? SMA(dataStock_line, 5) : []
            const dataSMA10 = this.flagdataSMA10 ? SMA(dataStock_line, 10) : []
            const dataSMA20 = this.flagdataSMA20 ? SMA(dataStock_line, 20) : []
            const dataSMA30 = this.flagdataSMA30 ? SMA(dataStock_line, 30) : []

            this.DATA_LINE = dataStock_line
            this.DATA_SMA5 = dataSMA5
            this.DATA_SMA10 = dataSMA10
            this.DATA_SMA20 = dataSMA20
            this.DATA_SMA30 = dataSMA30
            this.DATA_VOLUME = dataStock_volume
            this.dataRef = dataRef
        } else {
            this.DATA_LINE = dataStock_line
            this.DATA_VOLUME = dataStock_volume
            this.DATA_SMA5 = []
            this.DATA_SMA10 = []
            this.DATA_SMA20 = []
            this.DATA_SMA30 = []
            this.dataRef = []
        }
    }

    render() {
        return <div id="lightchart" />
    }
}

function formatNumber(n) {
    let newValue = n,
        unit = ''
    if (Number(n) > 10 ** 6) {
        unit = 'M'
        newValue = n / 10 ** 6
    }
    if (Number(n) > 10 ** 9) {
        unit = 'B'
        newValue = n / 10 ** 9
    }
    if (Number(n) > 10 ** 12) {
        unit = 'T'
        newValue = n / 10 ** 12
    }
    if (unit) return Math.round(newValue * 100) / 100 + unit
    return String(Math.round(n * 100) / 100).replace(/\B(?=(\d{3})+(?!\d))/g, ',')
}

function dateToChartTimeMinute(date) {
    return Date.UTC(date.getFullYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes(), date.getSeconds(), 0) / 1000
}

function chartConvertSecond(data) {
    const arr = []
    for (let index = 0; index < data.length; index++) {
        const curItem = data[index]
        const prevItem = arr[arr.length - 1]
        const obj = cloneDeep(curItem)
        if (!arr.length) {
            arr.push(obj)
        } else {
            if (prevItem) {
                const momentCur = dayjs(curItem.time)
                const momentPrev = dayjs(prevItem.time)
                if (momentCur.second() === momentPrev.second() && momentCur.minute() === momentPrev.minute() && momentCur.hour() === momentPrev.hour()) {
                    if (index === data.length - 1) {
                        obj.time = momentCur.add(1, 'second').valueOf()
                        arr.push(obj)
                    } else {
                        prevItem.C = curItem.C
                        prevItem.V = prevItem.V + curItem.V
                    }
                    continue
                } else {
                    arr.push(obj)
                }
            }
        }
    }
    return arr
}

function chartConvertMinutes(data) {
    const arr = []
    for (let index = 0; index < data.length; index++) {
        const curItem = data[index]
        const prevItem = arr[arr.length - 1]
        const obj = cloneDeep(curItem)
        if (!arr.length) {
            arr.push(obj)
        } else {
            if (prevItem) {
                const momentCur = dayjs(curItem.time)
                const momentPrev = dayjs(prevItem.time)
                if (momentCur.minute() === momentPrev.minute() && momentCur.hour() === momentPrev.hour()) {
                    if (index === data.length - 1) {
                        obj.time = momentCur.add(1, 'second').valueOf()
                        arr.push(obj)
                    } else {
                        prevItem.C = curItem.C
                        prevItem.V = prevItem.V + curItem.V
                    }
                    continue
                } else {
                    arr.push(obj)
                }
            }
        }
    }
    return arr
}

function SMA(data, period) {
    const result = []
    if (data.length < period) return result
    for (let index = period; index < data.length; index++) {
        let sum = 0,
            periodDivide = 0
        for (let temp = index; temp > index - period; temp--) {
            if (data[temp].value) {
                periodDivide += 1
                sum += data[temp].value
            }
        }
        if (periodDivide) {
            const ma = {
                value: Math.round((sum / periodDivide) * 100) / 100,
                time: data[index].time,
            }
            result.push(ma)
        }
    }
    return result
}
