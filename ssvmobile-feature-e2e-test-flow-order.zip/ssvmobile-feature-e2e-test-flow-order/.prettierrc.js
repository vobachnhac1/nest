module.exports = {
  bracketSpacing: true,
  singleQuote: true,
  trailingComma: 'all',
  tabWidth: 4,
  printWidth: 160,
  semi: false
};
