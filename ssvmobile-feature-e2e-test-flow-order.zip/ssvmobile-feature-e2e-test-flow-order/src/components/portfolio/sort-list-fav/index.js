import React, { memo, useCallback, useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { InteractionManager, Pressable, StyleSheet, View } from 'react-native'
import DeviceInfo from 'react-native-device-info'
import DraggableFlatList from 'react-native-draggable-flatlist'
import { SafeAreaView } from 'react-native-safe-area-context'
import AntDesign from 'react-native-vector-icons/AntDesign'
import Entypo from 'react-native-vector-icons/Entypo'
import Feather from 'react-native-vector-icons/Feather'
import { Button, Left, ListItem, Right } from 'native-base'
import SyncStorage from 'sync-storage'

import IconBack from '../../../assets/images/common/ic_back.svg'
import { FocusAwareStatusBar, Text } from '../../../basic-components'
import { StoreContext } from '../../../store'
import { dimensions, fontSizes } from '../../../styles'
import { eventList, glb_sv, STORE_KEY } from '../../../utils'

const isTablet = DeviceInfo.isTablet()

const SortPriceboard = ({ navigation, route }) => {
    const { styles, theme } = useContext(StoreContext)
    const { t } = useTranslation()

    const [listStock, setListStock] = useState([])
    const [show, showSort] = useState(false)
    const listStockRef = useRef([])

    useEffect(() => {
        InteractionManager.runAfterInteractions(() => {
            setListStock([...glb_sv.activeList.ListStock])
            listStockRef.current = [...glb_sv.activeList.ListStock]
        })
    }, [])

    const changeStatus = (item) => {
        if (item.type === 't55') return
        showSort(true)
        const newList = [...listStock]
        const newItem = newList.find((e) => e.type === item.type)
        if (newItem) {
            newItem.isShow = !newItem.isShow
        }
        setListStock(newList)
    }

    const renderItem = ({ item, index, drag, isActive }) => {
        return <RenderItem drag={drag} index={index} isActive={isActive} item={item} moveToTop={moveToTop} styles={styles} />
    }

    const goBack = () => {
        navigation.pop()
    }

    const handleSort = () => {
        const newList = [...listStock]

        glb_sv.activeList.ListStock = newList
        const isFav = glb_sv.allListFav.find((item) => item.c1 === glb_sv.activeList.c1)
        if (isFav) {
            isFav.ListStock = newList
        }
        const dataSort = SyncStorage.get(STORE_KEY.SORT_FAV) || {}
        dataSort[glb_sv.activeList.c1] = newList
        SyncStorage.set(STORE_KEY.SORT_FAV, dataSort)

        glb_sv.commonEvent.next({ type: eventList.CHANGE_LIST_STOCK, isActiveFav: true })

        InteractionManager.runAfterInteractions(() => {
            setTimeout(() => {
                navigation.goBack()
            }, 0)
        })
    }

    const moveToTop = useCallback((item) => {
        const newList = listStockRef.current.filter((e) => e !== item)
        newList.unshift(item)
        listStockRef.current = newList
        setListStock(newList)
        showSort(true)
    }, [])

    const renderSepartor = useCallback(() => {
        return <View style={{ borderBottomColor: styles.DIVIDER__COLOR, borderBottomWidth: 1 }} />
    }, [])

    return (
        <View
            style={{
                flex: 1,
                backgroundColor: styles.PRIMARY__BG__COLOR,
            }}
        >
            <FocusAwareStatusBar backgroundColor={'transparent'} barStyle={theme.includes('DARK') ? 'light-content' : 'dark-content'} translucent={true} />
            <SafeAreaView style={{ flex: 1, backgroundColor: styles.PRIMARY__BG__COLOR }}>
                <View style={{ flexDirection: 'row', height: isTablet ? 50 : 40, paddingHorizontal: 5, marginTop: 5 }}>
                    <Button style={{ paddingTop: 0, paddingBottom: 0, height: dimensions.vertical(35), flex: 0 }} transparent onPress={goBack}>
                        <IconBack style={{ color: styles.ICON__PRIMARY }} />
                    </Button>
                    <View style={{ flex: 1, borderRadius: 10, padding: 0, justifyContent: 'center', alignItems: 'center' }}>
                        <Text style={{ fontSize: fontSizes.xmedium, color: styles.PRIMARY__CONTENT__COLOR }}>{t('sort_fav')}</Text>
                    </View>
                    <Pressable disabled={!show} hitSlop={10} style={{ paddingTop: 8, paddingBottom: 0, paddingHorizontal: 6 }} onPress={handleSort}>
                        <AntDesign color={show ? styles.PRIMARY : styles.PRIMARY__BG__COLOR} name="check" size={24} />
                    </Pressable>
                </View>
                <View style={{ flex: 1, flexGrow: 1, flexShrink: 1 }}>
                    <DraggableFlatList
                        data={listStock}
                        ItemSeparatorComponent={renderSepartor}
                        keyExtractor={(item, index) => `draggable-item-${item}`}
                        renderItem={renderItem}
                        showsVerticalScrollIndicator={false}
                        onDragEnd={({ data }) => {
                            showSort(true)
                            setListStock(data)
                        }}
                    />
                </View>
            </SafeAreaView>
        </View>
    )
}

const RenderItem = memo(({ item, index, drag, isActive, styles, moveToTop }) => {
    return (
        <ListItem
            activeOpacity={0.6}
            noBorder
            style={{ backgroundColor: isActive ? styles.PRIMARY : '', marginLeft: 0, paddingLeft: 16 }}
            underlayColor="transparent"
            onLongPress={drag}
        >
            <Left>
                <Text style={{ fontSize: fontSizes.normal, color: isActive ? 'white' : styles.SECOND__CONTENT__COLOR }}>{index + 1} </Text>
                <Text
                    style={{
                        fontSize: fontSizes.medium,
                        color: isActive ? 'white' : styles.PRIMARY__CONTENT__COLOR,
                    }}
                >
                    {item}
                </Text>
            </Left>
            <Right style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                {index === 0 ? (
                    <View />
                ) : (
                    <Entypo color={isActive ? 'white' : styles.SECOND__CONTENT__COLOR} name="align-top" size={30} onPress={() => moveToTop(item)} />
                )}
                <Feather color={isActive ? 'white' : styles.SECOND__CONTENT__COLOR} name="menu" size={30} />
            </Right>
        </ListItem>
    )
})

const UI = StyleSheet.create({
    container: {
        marginVertical: dimensions.halfIndent,
        paddingHorizontal: dimensions.halfIndent,
    },
    header: {
        paddingVertical: 6,
    },
    item: {
        alignItems: 'center',
    },
    title: {
        fontSize: fontSizes.small,
        paddingVertical: 8,
    },
})

export default SortPriceboard
