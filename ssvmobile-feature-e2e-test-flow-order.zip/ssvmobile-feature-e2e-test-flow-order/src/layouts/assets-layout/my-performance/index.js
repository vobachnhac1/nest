import React, { memo, useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { StyleSheet, View } from 'react-native'
import { useIsFocused } from '@react-navigation/native'

import { RowTitleGroup } from '../../../components/trading-component'
import { StoreContext } from '../../../store'
import { eventList, glb_sv } from '../../../utils'
import { AssetsWeight } from './ChartWebView/AssetsWeight'
import { ChartProfitLossColumn } from './ChartWebView/ChartProfitLossColumn/index.js'
import ChartMyPerformance from './ChartWebView/ChartProfitLossCompare/webview'

function MyPerformance({ userInfo }) {
    const { theme, styles } = useContext(StoreContext)
    const { t } = useTranslation()
    const isFocused = useIsFocused()
    const [show, setShow] = useState(true)

    useEffect(() => {
        if (isFocused) setShow(true)
        const eventMarket = glb_sv.eventMarket.subscribe((msg) => {
            if (msg.type === eventList.CHANGE_LANGUAGE) {
                setShow(false)
            }
        })
        return () => {
            eventMarket.unsubscribe()
        }
    }, [isFocused])

    return (
        <View style={[UI.view, { backgroundColor: styles.PRIMARY__BG__COLOR }]}>
            <AssetsWeight userInfo={userInfo} />
            <ChartProfitLossColumn userInfo={userInfo} />
            <RowTitleGroup hasDivider />
            <View style={{ minHeight: 400 }}>{show ? <ChartMyPerformance styles={styles} t={t} theme={theme} userInfo={userInfo} /> : null}</View>
        </View>
    )
}

const UI = StyleSheet.create({
    view: {
        flex: 1,
        // minHeight: 800
    },
})

export default memo(MyPerformance)
