import React, { Component, createRef } from 'react'
import { Platform, StyleSheet } from 'react-native'
import WebView from 'react-native-webview'

import { dimensions } from '../../../../styles'
import { glb_sv } from '../../../../utils'

const source = Platform.select({
    ios: require('../../../../basic-components/custom-chart/index.html'),
    android: { uri: 'file:///android_asset/index.html' },
})

// export default memo(WebviewPieChartAssetOwn)
export default class WebviewPieChartAssetOwn extends Component {
    constructor(props) {
        super(props)
        this.chartRef = createRef()

        this.state = {
            webviewKey: new Date().getTime(),
        }
    }

    componentWillReceiveProps(nextProps) {
        if (this.chartRef) {
            this.chartRef.current.injectJavaScript(`
            window.DataAssetPieChart = ${nextProps.dataChart};
            if (window.eventMarket) {
                window.eventMarket.next({ type: 'highcharts-assetsPieChart' })
            }
            true;
        `)
            if (nextProps.t !== this.props.t) {
                this.chartRef.current &&
                    this.chartRef.current.injectJavaScript(`
                window.asset_ratio = '${this.props.t('asset_ratio')}';
            if (window.eventMarket) {
                window.eventMarket.next({ type: 'change-language' })
            }
            true;
        `)
            }
        }
    }

    shouldComponentUpdate(nextProps, nextState) {
        if (nextState.webviewKey !== this.state.webviewKey) {
            return true
        }
        return false
    }
    reload = () => {
        this.setState({
            webviewKey: this.state.webviewKey + 1,
        })
    }

    render() {
        return (
            <WebView
                allowUniversalAccessFromFileURLs={true}
                androidLayerType="hardware"
                domStorageEnabled={true}
                injectedJavaScriptBeforeContentLoaded={`
                    new Date().toLocaleString();
                    window.theme = '${this.props.theme}';
                    window.chartName = 'AssetPieChartOwn';
                    window.DataAssetPieChart = ${this.props.dataChart || '[]'};
                    window.timeServer = ${glb_sv.timeServer};

                    window.asset_ratio = '${this.props.t('asset_ratio')}';
                `}
                source={source}
                // source={{
                //     uri: 'http://192.168.1.9:3000' || 'http://localhost:3000/',
                // }}
                javaScriptEnabled
                key={this.state.webviewKey}
                originWhitelist={['*']}
                ref={this.chartRef}
                scrollEnabled={false}
                style={UI.webView}
                onContentProcessDidTerminate={this.reload}
            />
        )
    }
}

const UI = StyleSheet.create({
    webView: {
        backgroundColor: 'transparent',
        flex: 1,
    },
})
