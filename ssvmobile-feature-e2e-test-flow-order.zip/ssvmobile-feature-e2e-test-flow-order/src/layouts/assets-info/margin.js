import React, { memo, useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { RefreshControl, ScrollView, StyleSheet, TouchableOpacity, View } from 'react-native'
import { Toast } from 'native-base'

import { Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { StoreTrading } from '../../store-trading'
import { dimensions, fontSizes, fontWeights, IconSvg } from '../../styles'
import { eventList, FormatNumber, glb_sv, reqFunct, Screens, sendRequest, subcribeFunct } from '../../utils'

const ServiceInfo = {
    GET_ASSETS_GUAR_INFO: {
        reqFunct: reqFunct.GET_ASSETS_GUAR_INFO,
        WorkerName: 'FOSqMargin',
        ServiceName: 'FOSqLendingMargin_Online_1450_1',
        Operation: 'Q',
        ClientSentTime: '0',
    },
    GET_MARGIN_STOCK_LIST: {
        reqFunct: reqFunct.GET_MARGIN_STOCK_LIST,
        WorkerName: 'FOSqMargin',
        ServiceName: 'FOSqLendingMargin_Online_1480_12',
        Operation: 'Q',
        ClientSentTime: '0',
    },
}

function AssetsMarginInfo({ isActive, navigation }) {
    const { styles } = useContext(StoreContext)
    const { userInfo } = useContext(StoreTrading)

    const { t } = useTranslation()

    const [data, setData] = useState({})

    const [list, setList] = useState([])
    const tempList = useRef([])

    const [refreshing, setRefresh] = useState(false)
    const timeoutRefresh = useRef(null)
    const mounted = useRef(true)

    useEffect(() => {
        mounted.current = true
        if (isActive) {
            setRefresh(true)
            getAssetsGuarInfo()
            getAssetsStockList()
        }

        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.LOGIN_SUCCESS) {
                if (isActive) {
                    getAssetsGuarInfo()
                    getAssetsStockList()
                }
            }
        })

        return () => {
            if (timeoutRefresh.current) clearTimeout(timeoutRefresh.current)
            mounted.current = false
            commonEvent.unsubscribe()
        }
    }, [userInfo, isActive])

    const getAssetsGuarInfo = () => {
        const { actn_curr, sub_curr } = userInfo
        // const dataSub = glb_sv.objShareGlb['acntNoInfo'].find(e => (e.AcntNo + e.SubNo) === (actn_curr + sub_curr));
        // if (!dataSub.MarginYN) return;

        const InputParams = [actn_curr, sub_curr]
        sendRequest(ServiceInfo.GET_ASSETS_GUAR_INFO, InputParams, getAssetsGuarInfoResult, true, getAssetsGuarInfoTimeout, '', 0, 'equal_service')
        setData({})
    }

    const getAssetsGuarInfoTimeout = () => {
        setRefresh(false)
    }

    const getAssetsGuarInfoResult = (reqInfoMap, message) => {
        if (!mounted.current) return
        setRefresh(false)
        if (Number(message.Result) === 0) {
            // if (message.Code == 'XXXXX5' || message.Code === '080063' || message.Code === '010012') {
            //     Toast.show({
            //         text: t('request_hanlde_not_success_try_again'),
            //         type: 'warning',
            //         position: 'bottom'
            //     })
            // } else {
            //     Toast.show({
            //         text: message['Message'],
            //         type: 'warning',
            //         position: 'bottom'
            //     })
            // }
            return
        } else {
            try {
                const jsondata = message.Data ? JSON.parse(message.Data)[0] : {}
                setData(jsondata)
            } catch (err) {
                console.log('getAssetsGuarInfoResult', err)
            }
        }
    }

    const getAssetsStockList = () => {
        if (!mounted.current) return
        const { actn_curr, sub_curr } = userInfo
        const InputParams = [actn_curr, sub_curr]
        sendRequest(ServiceInfo.GET_MARGIN_STOCK_LIST, InputParams, getAssetsStockListResult, true, getAssetsStockListTimeout, '', 0, 'equal_service')
        tempList.current = []
        setList([])
    }

    const getAssetsStockListTimeout = () => {
        setRefresh(false)
    }

    const getAssetsStockListResult = (reqInfoMap, message) => {
        if (!mounted.current) return
        setRefresh(false)
        if (Number(message.Result) === 0) {
            // if (message.Code == 'XXXXX5' || message.Code === '080063' || message.Code === '010012') {
            //     Toast.show({
            //         text: t('request_hanlde_not_success_try_again'),
            //         type: 'warning',
            //         position: 'bottom'
            //     })
            // } else {
            //     Toast.show({
            //         text: message['Message'],
            //         type: 'warning',
            //         position: 'bottom'
            //     })
            // }
            return
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {
                console.log('getAssetsStockListResult', err)
                return
            }
            tempList.current = tempList.current.concat(jsondata)
            if (Number(message.Packet) <= 0) {
                setList([...tempList.current])
            }
        }
    }

    const onRefresh = () => {
        if (refreshing) return
        if (!mounted.current) return
        setRefresh(true)
        if (timeoutRefresh.current) clearTimeout(timeoutRefresh.current)
        timeoutRefresh.current = setTimeout(() => {
            getAssetsGuarInfo()
            getAssetsStockList()
        }, 1000)
    }

    const getOrder = (stk) => {
        if (glb_sv.configInfo.application_style.default_style === '1.1') {
            glb_sv.objLastOrder.orderTp = '01'
            glb_sv.objLastOrder.stockCode = stk
            glb_sv.objLastOrder.price = 0
            glb_sv.objLastOrder.qty = 0
            navigation.navigate(Screens.PLACE_ORDER_TAB, {
                t55: stk,
                sell_buy: 'sell',
            })
        } else {
            glb_sv.commonEvent.next({
                type: eventList.ORDER,
                buysell_tp: 'sell',
                stk_cd: stk,
            })
        }
    }

    return (
        <ScrollView
            refreshControl={
                <RefreshControl
                    refreshing={refreshing}
                    onRefresh={onRefresh}
                    // title={t('pull_refresh')}
                    // titleColor={styles.PRIMARY__CONTENT__COLOR}
                    tintColor={styles.PRIMARY__CONTENT__COLOR}
                />
            }
            showsVerticalScrollIndicator={false}
            style={{ backgroundColor: styles.PRIMARY__BG__COLOR, paddingHorizontal: dimensions.moderate(8) }}
        >
            <Text style={{ fontSize: fontSizes.medium, fontWeight: fontWeights.bold, marginTop: 8, marginBottom: 4, color: styles.PRIMARY__CONTENT__COLOR }}>
                {t('general_info')}
            </Text>

            <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('current_maintenance_ratio')}</Text>
                <Text style={{ color: styles.UP__COLOR, fontSize: fontSizes.small, fontWeight: fontWeights.bold, flex: 1, textAlign: 'right' }}>
                    {FormatNumber(data.c2, 2) + ' %'}
                </Text>
            </View>

            <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('total_assets_guaranteed')}</Text>
                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small, fontWeight: fontWeights.medium, flex: 1, textAlign: 'right' }}>
                    {FormatNumber(data.c51)}
                </Text>
            </View>

            <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('total_pushed_assets')}</Text>
                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small, fontWeight: fontWeights.medium, flex: 1, textAlign: 'right' }}>
                    {FormatNumber(data.c50)}
                </Text>
            </View>

            <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('net_assets')}</Text>
                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small, fontWeight: fontWeights.medium, flex: 1, textAlign: 'right' }}>
                    {FormatNumber(data.c52)}
                </Text>
            </View>

            <Text style={{ fontSize: fontSizes.medium, fontWeight: fontWeights.bold, marginTop: 24, marginBottom: 4, color: styles.PRIMARY__CONTENT__COLOR }}>
                {t('cash_assets')}
            </Text>

            <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('total_cash_assets')}</Text>
                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small, fontWeight: fontWeights.medium, flex: 1, textAlign: 'right' }}>
                    {FormatNumber(data.c11)}
                </Text>
            </View>

            <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('cash_amount')}</Text>
                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small, fontWeight: fontWeights.medium, flex: 1, textAlign: 'right' }}>
                    {FormatNumber(data.c12)}
                </Text>
            </View>

            <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('blockade_custody')}</Text>
                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small, fontWeight: fontWeights.medium, flex: 1, textAlign: 'right' }}>
                    {FormatNumber(Number(data.c13) + Number(data.c14) + Number(data.c15))}
                </Text>
            </View>

            <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('cash_right_wait')}</Text>
                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small, fontWeight: fontWeights.medium, flex: 1, textAlign: 'right' }}>
                    {FormatNumber(data.c18)}
                </Text>
            </View>

            <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('cash_wait_avail')}</Text>
                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small, fontWeight: fontWeights.medium, flex: 1, textAlign: 'right' }}>
                    {FormatNumber(data.c16)}
                </Text>
            </View>

            <View style={[UI.row, { borderBottomWidth: 0 }]}>
                <View style={{ flexDirection: 'row', flex: 1, alignItems: 'center' }}>
                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small }}>{t('total_stock_assets_are_assessed')}</Text>
                    <IconSvg.InfoCircleIcon color={styles.PRIMARY__CONTENT__COLOR} />
                </View>

                <Text style={{ color: styles.UP__COLOR, fontSize: fontSizes.small, fontWeight: fontWeights.medium, flex: 1, textAlign: 'right' }}>
                    {FormatNumber(data.c20)}
                </Text>
            </View>
            <View style={[UI.row, { borderBottomWidth: 0 }]}>
                <View style={{ flexDirection: 'row', flex: 1, alignItems: 'center' }}>
                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small }}>{t('loan_information')}</Text>
                    <IconSvg.InfoCircleIcon color={styles.PRIMARY__CONTENT__COLOR} />
                </View>
                <Text style={{ color: styles.DOWN__COLOR, fontSize: fontSizes.small, fontWeight: fontWeights.medium, flex: 1, textAlign: 'right' }}>
                    {FormatNumber(data.c31)}
                </Text>
            </View>

            <Text style={{ fontSize: fontSizes.medium, fontWeight: fontWeights.bold, marginTop: 24, marginBottom: 4, color: styles.PRIMARY__CONTENT__COLOR }}>
                {t('margin_stock_info')}
            </Text>

            <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                <Text style={[UI.text_header, { color: styles.FIFTH__CONTENT__COLOR, textAlign: 'left', flex: 0.55 }]}>{t('stock_symbol_short')}</Text>
                <Text style={[UI.text_header, { color: styles.FIFTH__CONTENT__COLOR }]}>{t('volume_evaluation')}</Text>
                <Text style={[UI.text_header, { color: styles.FIFTH__CONTENT__COLOR }]}>{t('price_valuation')}</Text>
                <Text style={[UI.text_header, { color: styles.FIFTH__CONTENT__COLOR }]}>{t('push_asset_ratio')}</Text>
                <Text style={[UI.text_header, { color: styles.FIFTH__CONTENT__COLOR, flex: 1.25 }]}>{t('asset_for_buy_power')}</Text>
            </View>
            {list.map((item) => (
                <TouchableOpacity key={item.c2} style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]} onPress={() => getOrder(item.c2)}>
                    <Text numberOfLines={1} style={[UI.text_body, { color: styles.UP__COLOR, textAlign: 'left', flex: 0.55 }]}>
                        {item.c2}
                    </Text>
                    <Text style={[UI.text_body, { color: styles.PRIMARY__CONTENT__COLOR }]}>{FormatNumber(item.c3)}</Text>
                    <Text style={[UI.text_body, { color: styles.PRIMARY__CONTENT__COLOR }]}>{FormatNumber(item.c5)}</Text>
                    <Text style={[UI.text_body, { color: styles.PRIMARY__CONTENT__COLOR }]}>{FormatNumber(Number(item.c14))}</Text>
                    <Text style={[UI.text_body, { color: styles.PRIMARY__CONTENT__COLOR, flex: 1.25 }]}>{FormatNumber(item.c15)}</Text>
                </TouchableOpacity>
            ))}
        </ScrollView>
    )
}

export default memo(AssetsMarginInfo)

const UI = StyleSheet.create({
    row: {
        borderBottomWidth: 1,
        flexDirection: 'row',
        paddingVertical: dimensions.vertical(12),
    },
    text_body: {
        flex: 1,
        fontSize: fontSizes.verySmall,
        fontWeight: fontWeights.medium,
        paddingRight: 3,
        textAlign: 'right',
    },
    text_header: {
        flex: 1,
        fontSize: fontSizes.smallest,
        fontWeight: fontWeights.semiBold,
        paddingRight: 3,
        textAlign: 'right',
    },
})
