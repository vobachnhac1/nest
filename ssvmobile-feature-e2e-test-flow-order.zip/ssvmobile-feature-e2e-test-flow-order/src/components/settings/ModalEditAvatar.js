import React, { Component, useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { ActivityIndicator, Image, PermissionsAndroid, Platform, StyleSheet, TouchableOpacity, View } from 'react-native'
import { launchCamera, launchImageLibrary } from 'react-native-image-picker'
import Modal from 'react-native-modal'
import Svg, { Circle, ClipPath, Defs, G, LinearGradient, Path, Stop } from 'react-native-svg'
import ToastGlobal from 'react-native-toast-message'
import AntDesign from 'react-native-vector-icons/AntDesign'
import SyncStorage from 'sync-storage'

import CONFIG from '../../assets/config'
import { Text } from '../../basic-components'
import AvatarImage from '../../basic-components/avatar'
import { ButtonCustom, ColTableData, ModalContent, RowDataModal, RowTableData, RowTitleGroup, StockInfoRowView } from '../../components/trading-component'
import { StoreContext } from '../../store'
import { StoreTrading } from '../../store-trading'
import { dimensions as dm, fontSizes as fs, fontWeights as fw, IconSvg } from '../../styles'
import { eventList, glb_sv, InfoStatistic, socket_sv, STORE_KEY } from '../../utils'

const ServiceInfo = {
    UPDATE_INFO_REQUEST: {
        WorkerName: 'FOSxID02',
        ServiceName: 'FOSxID02_UserInformation',
        ClientSentTime: '0',
        Operation: 'U',
    },
}
const ModalEditAvatar = ({ isOpenModal, setIsOpenModal, avatarUrl }) => {
    const TAG = 'ModalEditAvatar'

    const { styles, language, activeCode } = useContext(StoreContext)
    const { userInfo } = useContext(StoreTrading)
    const { t } = useTranslation()
    const [fileInfo, setFileInfo] = useState({})
    const [loading, setLoading] = useState(false)
    // All orther state
    useEffect(() => {}, [])

    const hideModal = () => {
        setIsOpenModal(false)
        setLoading(false)
        setFileInfo({})
    }
    const onConfirm = () => {
        handleChangeImage()
    }

    const requestCameraPermission = async () => {
        if (Platform.OS === 'android') {
            try {
                const granted = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.CAMERA, {
                    title: 'Camera Permission',
                    message: 'App needs camera permission',
                })
                // If CAMERA Permission is granted
                return granted === PermissionsAndroid.RESULTS.GRANTED
            } catch (err) {
                console.warn(err)
                return false
            }
        } else return true
    }

    const requestExternalWritePermission = async () => {
        if (Platform.OS === 'android') {
            try {
                const granted = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE, {
                    title: 'External Storage Write Permission',
                    message: 'App needs write permission',
                })
                // If WRITE_EXTERNAL_STORAGE Permission is granted
                return granted === PermissionsAndroid.RESULTS.GRANTED
            } catch (err) {
                console.warn(err)
                alert('Write permission err', err)
            }
            return false
        } else return true
    }

    const capturePicture = async (type) => {
        console.log('capturePicture')
        const options = {
            mediaType: type,
            quality: 1,
            maxWidth: 600,
            maxHeight: 1000,
            saveToPhotos: true,
            includeBase64: true,
        }
        const isCameraPermitted = await requestCameraPermission()
        const isStoragePermitted = await requestExternalWritePermission()
        if (isCameraPermitted && isStoragePermitted) {
            launchCamera(options, (response) => {
                console.log('Response = ', response)

                if (response.didCancel) {
                    // alert('User cancelled camera picker')
                    return
                } else if (response.errorCode == 'camera_unavailable') {
                    alert('Camera not available on device')
                    return
                } else if (response.errorCode == 'permission') {
                    alert('Permission not satisfied')
                    return
                } else if (response.errorCode == 'others') {
                    alert(response.errorMessage)
                    return
                }
                console.log('base64 -> ', response.assets[0].base64)
                console.log('uri -> ', response.assets[0].uri)
                console.log('width -> ', response.assets[0].width)
                console.log('height -> ', response.assets[0].height)
                console.log('fileSize -> ', response.assets[0].fileSize)
                console.log('type -> ', response.assets[0].type)
                console.log('fileName -> ', response.assets[0].fileName)
                setFileInfo(response.assets[0])
            })
        }
    }

    const choosePicture = (type) => {
        console.log(TAG, 'choosePicture')
        const options = {
            mediaType: type,
            maxWidth: 600,
            maxHeight: 1000,
            quality: 1,
            includeBase64: true,
        }
        launchImageLibrary(options, (response) => {
            // console.log('Response = ', response)

            if (response.didCancel) {
                // alert('User cancelled camera picker')
                return
            } else if (response.errorCode == 'camera_unavailable') {
                alert('Camera not available on device')
                return
            } else if (response.errorCode == 'permission') {
                alert('Permission not satisfied')
                return
            } else if (response.errorCode == 'others') {
                alert(response.errorMessage)
                return
            }
            // console.log('base64 -> ', response.assets[0].base64)
            console.log(TAG, ' uri -> ', response.assets[0].uri)
            console.log(TAG, ' width -> ', response.assets[0].width)
            console.log(TAG, ' height -> ', response.assets[0].height)
            console.log(TAG, ' fileSize -> ', response.assets[0].fileSize)
            console.log(TAG, ' type -> ', response.assets[0].type)
            console.log(TAG, ' fileName -> ', response.assets[0].fileName)
            setFileInfo(response.assets[0])
        })
    }

    const handleChangeImage = async () => {
        setLoading(true)
        // -------------------
        const file = fileInfo
        if (!file.type) {
            // Case không có ảnh thì OK --> k làm gì
            setLoading(false)
            hideModal()
            return
        }
        if (file && file.type !== 'image/jpeg' && file.type !== 'image/jpg' && file.type !== 'image/heic' && file.type !== 'image/png') {
            ToastGlobal.show({
                text2: t('img_type_incorrect'),
                type: 'warning',
            })
            setLoading(false)
            hideModal()
            return
        }
        if (file.fileSize > 5242880) {
            ToastGlobal.show({
                text2: t('file_to_large_5mb'),
                type: 'warning',
            })
            setLoading(false)
            hideModal()
            return
        }

        setTimeout(async () => {
            const arraySplit = file.fileName?.split('.') || []
            const fileType = arraySplit[arraySplit.length - 1]
            // console.log(
            //     'nnn',
            //     JSON.stringify({
            //         encodeType: 'base64',
            //         name: userInfo.actn_curr + '.' + fileType,
            //         size: file.fileSize,
            //         imgType: fileType,
            //     }),
            // )
            const userID = glb_sv.objShareGlb.userInfo.c1
            const requestOptions = {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    encodeType: 'base64',
                    image_data: file.base64,
                    name: userID,
                    size: file.fileSize,
                    imgType: fileType,
                }),
            }

            const avatarDomain = glb_sv.configInfo.avatar_restful_domain
            await fetch(`${avatarDomain}/file/storeavatar`, requestOptions)
                .then((res) => {
                    console.log(TAG, ' Upload response: ', JSON.stringify(res))
                    setLoading(false)
                    hideModal()
                    return res.json()
                })

                .then((data) => {
                    console.log(TAG, ' Upload data', data)

                    if (data.success) {
                        const arrSplit = data?.data?.path?.split('/') || []
                        glb_sv.imageAvatarUrl = `${avatarDomain}/assets/upload_avatar/${arrSplit[arrSplit.length - 1]}`
                        glb_sv.commonEvent.next({ type: eventList.UPDATE_AVATAR_URL, urlAvatar: glb_sv.imageAvatarUrl })
                        ToastGlobal.show({
                            text2: t('update_avatar_success'),
                            type: 'success',
                        })
                    } else {
                        ToastGlobal.show({
                            text2: t('err_upload_avatar'),
                            type: 'warning',
                        })
                    }
                })
                .catch((err) => {
                    console.log(TAG, ' Upload err', err)
                    ToastGlobal.show({
                        text2: t('err_upload_avatar'),
                        type: 'warning',
                    })
                })
        }, 1000)
    }

    const renderFileUri = () => {
        if (fileInfo.uri) {
            return <AvatarImage avatar={fileInfo.uri} noTick />
        } else {
            return <AvatarImage noTick />
        }
    }

    return (
        <>
            {isOpenModal ? (
                <Modal isVisible={isOpenModal} useNativeDriver={true} onBackButtonPress={hideModal} onBackdropPress={hideModal}>
                    <ModalContent title={t('profile_photo')} type="confirm">
                        <TouchableOpacity onPress={() => choosePicture('photo')}>
                            <View style={{ justifyContent: 'center', alignItems: 'center', flexDirection: 'row', height: 140 }}>
                                <View style={UI.ImageSections}>{renderFileUri()}</View>
                            </View>
                        </TouchableOpacity>
                        {loading ? <ActivityIndicator color={styles.PRIMARY} /> : null}
                        <TouchableOpacity onPress={() => capturePicture('photo')}>
                            <View style={{ flexDirection: 'row', paddingHorizontal: dm.moderate(16), paddingTop: dm.vertical(16) }}>
                                <View style={{ alignItems: 'center', flex: 1 }}>
                                    <AntDesign
                                        color={styles.PRIMARY__CONTENT__COLOR}
                                        name="camerao"
                                        size={28}
                                        style={{
                                            paddingLeft: dm.moderate(8),
                                        }}
                                    />
                                </View>
                                <View style={{ flex: 5, justifyContent: 'center' }}>
                                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fs.normal }}>{t('take_a_photo')}</Text>
                                </View>
                            </View>
                        </TouchableOpacity>
                        <TouchableOpacity onPress={() => choosePicture('photo')}>
                            <View style={{ flexDirection: 'row', paddingHorizontal: dm.moderate(16), paddingTop: dm.vertical(16) }}>
                                <View style={{ alignItems: 'center', flex: 1 }}>
                                    <AntDesign
                                        color={styles.PRIMARY__CONTENT__COLOR}
                                        name="picture"
                                        size={28}
                                        style={{
                                            paddingLeft: dm.moderate(8),
                                        }}
                                    />
                                </View>
                                <View style={{ flex: 5, justifyContent: 'center' }}>
                                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fs.normal }}>{t('choose_a_photo')}</Text>
                                </View>
                            </View>
                        </TouchableOpacity>
                        <View style={{ height: 8 }} />
                        <ButtonCustom disabled={loading} text={t('common_Ok')} type="confirm" onPress={onConfirm} />
                        {/* <ButtonCustom text={'common_Cancel'} onPress={hideModal} type="back" last /> */}
                        <View style={{ height: 8 }} />
                    </ModalContent>
                </Modal>
            ) : null}
        </>
    )
}

export default ModalEditAvatar

const UI = StyleSheet.create({
    ImageSections: {
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'center',
        paddingHorizontal: 8,
        paddingVertical: 8,
    },
    images: {
        borderColor: 'black',
        borderWidth: 1,
        height: 150,
        marginHorizontal: 3,
        width: 150,
    },
})
