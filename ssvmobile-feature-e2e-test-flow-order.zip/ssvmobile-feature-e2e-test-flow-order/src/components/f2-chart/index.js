import React, { createRef, PureComponent } from 'react'
import { Platform, StyleSheet } from 'react-native'
import WebView from 'react-native-webview'

const changeData = (data) => `
  if (chart && chart.changeData) chart.changeData(${JSON.stringify(data)});
  else {
    setTimeout(() => {
      if (chart && chart.changeData) chart.changeData(${JSON.stringify(data)});
    }, 1000);
  }
`

const changeDataAll = (data, colorMap) => `
  const DATA = ${JSON.stringify(data)}
  const COLOR_MAP = ${JSON.stringify(colorMap)}
  chart.changeData(DATA);
  const legendItems = [];
DATA.forEach(function(obj) {
  const item = {
    name: obj.price,
    value: '    ' + obj.ratio * 100 + '%',
    marker: {
      symbol: 'square',
      fill: COLOR_MAP[obj.price],
      radius: 4
    }
  };
  legendItems.push(item);
});
chart.legend({
  position: 'right',
  custom: true,
  items: legendItems,
  nameStyle: {
    fill: '#808080'
  },
  valueStyle: {
    fill: '#333',
    fontWeight: 'bold'
  }
});
chart.interval()
  .position('const*ratio')
  .color('price', function(val) {
    return COLOR_MAP[val];
  })
  .adjust('stack')
  .style({
    lineWidth: 1,
    stroke: '#fff'
  });
`

const source = Platform.select({
    ios: require('./f2chart.html'),
    android: { uri: 'file:///android_asset/f2chart.html' },
})

export default class Chart extends PureComponent {
    static defaultProps = {
        onChange: () => {},
        initScript: '',
        data: [],
    }

    constructor(props) {
        super(props)
        this.chart = createRef()
        this.state = {
            webviewKey: new Date().getTime(),
        }
    }

    componentWillReceiveProps(nextProps) {
        const { data, colorMap, type, rePaint } = this.props
        if (type === 'repaint') {
            this.chart.current && this.chart.current.injectJavaScript(rePaint)
            return
        }
        if (data !== nextProps.data) {
            this.update(nextProps.data)
        }
    }

    update = (data) => {
        this.chart.current && this.chart.current.injectJavaScript(changeData(data))
    }

    updateAll = (data, colorMap) => {
        this.chart.current && this.chart.current.injectJavaScript(changeDataAll(data, colorMap))
    }

    repaint = (script) => {
        // console.log('script', script)
        this.chart.current && this.chart.current.injectJavaScript(script)
    }

    onMessage = (event) => {
        const {
            nativeEvent: { data },
        } = event
        const { onChange } = this.props
        const tooltip = JSON.parse(data)
        onChange(tooltip)
    }

    reload = () => {
        this.setState({
            webviewKey: this.state.webviewKey + 1,
        })
    }

    render() {
        const { data, onChange, initScript, ...props } = this.props

        return (
            <WebView
                allowUniversalAccessFromFileURLs={true}
                androidHardwareAccelerationDisabled
                androidLayerType="software"
                domStorageEnabled={true}
                injectedJavaScript={initScript}
                javaScriptEnabled
                key={this.state.webviewKey}
                originWhitelist={['*']}
                ref={this.chart}
                scrollEnabled={false}
                source={source}
                style={styles.webView}
                onContentProcessDidTerminate={this.reload}
                onMessage={this.onMessage}
                onShouldStartLoadWithRequest={(request) => {
                    return true
                }}
                {...props}
            />
        )
    }
}

const styles = StyleSheet.create({
    webView: {
        backgroundColor: 'transparent',
        flex: 1,
    },
})
