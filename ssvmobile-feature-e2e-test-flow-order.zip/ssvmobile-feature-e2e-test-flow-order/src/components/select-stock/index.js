import React, { useContext, useEffect, useLayoutEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { FlatList, Keyboard, StatusBar, Text, TextInput, View } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import AntDesign from 'react-native-vector-icons/AntDesign'
import { Body, Button, Icon, ListItem, Right } from 'native-base'
import SyncStorage from 'sync-storage'

import { StoreContext } from '../../store'
import { fontSizes, fontWeights } from '../../styles'
import { eventList, glb_sv, reqFunct, Screens, socket_sv, STORE_KEY } from '../../utils'
import ModalAddStock2FavList from '../modal-add-stock-fav'

export default function SelectStock({ navigation, route }) {
    const { actionType, changeStock } = route.params

    const { styles, language, recentStkList, setRecentStkList, theme } = useContext(StoreContext)

    const { t } = useTranslation()
    const [seach, setSearch] = useState('')
    const [listStock, setListStock] = useState([])
    const [isModalVisible, setModal] = useState(false)
    const timeOutSearch = useRef(null)
    const [selectStock, setSelectStock] = useState('')

    const [recentList, setRecentList] = useState([])

    const searchRef = useRef('')

    useEffect(() => {
        getListRencent()
        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.CHANGE_LIST_STOCK) {
                getListRencent()
                if (!searchRef.current) return
                const newList = glb_sv.mrk_stklist
                    .filter((e) => e.t55.includes(searchRef.current))
                    .slice(0, 30)
                    .sort(function (a, b) {
                        if (a.t55 > b.t55) return -1
                        if (a.t55 < b.t55) return 1
                        return 0
                    })
                const newList1 = []
                newList.forEach((element) => {
                    const obj = glb_sv.mrk_stklist.find((e) => e.t55 === element.t55)
                    if (obj) {
                        const cloneObj = { ...obj }
                        glb_sv.allListFav.forEach((item) => {
                            if (item.ListStock.some((temp) => temp === cloneObj.t55)) {
                                cloneObj.isFav = true
                                if (cloneObj.ExistNameFav) {
                                    cloneObj.ExistNameFav += ', ' + item.c2
                                } else cloneObj.ExistNameFav = item.c2
                            }
                        })
                        newList1.push(cloneObj)
                    }
                })
                setListStock(newList1)
            }
            if (msg.type === eventList.REQ_GET_MKT_INF_FIRST) {
                getListRencent()
            }
        })
        const eventMarket = glb_sv.eventMarket.subscribe((msg) => {
            if (msg.type === eventList.REQ_RE_GET_MKT_INF) {
                getListRencent()
            }
        })

        return () => {
            commonEvent.unsubscribe()
            eventMarket.unsubscribe()
        }
    }, [])

    const getListRencent = () => {
        const newList = []
        recentStkList.forEach((element) => {
            const obj = glb_sv.mrk_stklist.find((e) => e.t55 === element)
            if (obj) {
                const cloneObj = { ...obj }
                glb_sv.allListFav.forEach((item) => {
                    if (item.ListStock.some((temp) => temp === cloneObj.t55)) {
                        cloneObj.isFav = true
                        if (cloneObj.ExistNameFav) {
                            cloneObj.ExistNameFav += ', ' + item.c2
                        } else cloneObj.ExistNameFav = item.c2
                    }
                })
                newList.push(cloneObj)
            }
        })
        setRecentList(newList)
        return newList
    }

    const getListStock = (value) => {
        const name = value ? value.toUpperCase() : ''
        searchRef.current = name
        setSearch(name)
        if (name === '') {
            if (timeOutSearch.current) clearTimeout(timeOutSearch.current)
            setListStock([])
            return
        }
        if (timeOutSearch.current) clearTimeout(timeOutSearch.current)
        timeOutSearch.current = setTimeout(() => {
            const newList = glb_sv.mrk_stklist
                .filter((e) => e.t55.includes(name) || e.U9.toUpperCase().includes(name))
                .slice(0, 30)
                .sort(function (a, b) {
                    if (a.t55 > b.t55) return -1
                    if (a.t55 < b.t55) return 1
                    return 0
                })

            const newList1 = []
            newList.forEach((element) => {
                const obj = glb_sv.mrk_stklist.find((e) => e.t55 === element.t55)
                if (obj) {
                    const cloneObj = { ...obj }
                    glb_sv.allListFav.forEach((item) => {
                        if (item.ListStock.some((temp) => temp === cloneObj.t55)) {
                            cloneObj.isFav = true
                            if (cloneObj.ExistNameFav) {
                                cloneObj.ExistNameFav += ', ' + item.c2
                            } else cloneObj.ExistNameFav = item.c2
                        }
                    })
                    newList1.push(cloneObj)
                }
            })
            setListStock(newList1)
        }, 300)
    }

    const StockItem = ({ item }) => {
        return (
            <ListItem activeOpacity={0.6} style={{ borderBottomColor: styles.DIVIDER__COLOR }} underlayColor="transparent" onPress={() => handleStock(item)}>
                <Body
                    style={{
                        flexDirection: 'column',
                        justifyContent: 'flex-start',
                        flex: 2,
                    }}
                >
                    <Text
                        style={{
                            color: styles.PRIMARY__CONTENT__COLOR,
                            fontWeight: fontWeights.medium,
                        }}
                    >
                        {item.t55}{' '}
                        <Text
                            style={{
                                color: styles.SECOND__CONTENT__COLOR,
                                fontSize: fontSizes.verySmall,
                                fontWeight: fontWeights.normal,
                            }}
                        >
                            {getExchange(item.U10)}
                        </Text>
                    </Text>
                    <Text
                        style={{
                            color: styles.SECOND__CONTENT__COLOR,
                            fontSize: fontSizes.small,
                        }}
                    >
                        {item.U9}
                    </Text>
                </Body>
            </ListItem>
        )
    }

    const handleStock = (item) => {
        const newList = recentStkList.filter((e) => e !== item.t55)
        if (newList.length >= 5) {
            newList.pop()
        }
        newList.unshift(item.t55)
        SyncStorage.set(STORE_KEY.RECENT_STOCK_LIST, newList)
        setRecentStkList(newList)

        const newList1 = []
        newList.forEach((element) => {
            const obj = glb_sv.mrk_stklist.find((e) => e.t55 === element)
            if (obj) {
                const cloneObj = { ...obj }
                glb_sv.allListFav.forEach((item) => {
                    if (item.ListStock.some((temp) => temp === cloneObj.t55)) {
                        cloneObj.isFav = true
                        if (cloneObj.ExistNameFav) {
                            cloneObj.ExistNameFav += ', ' + item.c2
                        } else cloneObj.ExistNameFav = item.c2
                    }
                })
                newList1.push(cloneObj)
            }
        })
        setRecentList(newList1)

        if (actionType === 'RIGHT_INFO') {
            changeStock(item.t55, item.U9)
            navigation.pop()
            return
        }

        navigation.navigate(Screens.STOCK_INFO, { stockCode: item.t55 })
    }

    const getExchange = (type) => {
        if (type === '01') return 'HOSE'
        if (type === '03') return 'HNX'
        if (type === '05') return 'UPCOM'
    }

    const resetData = () => {
        setSearch('')
        setListStock([])
    }

    const ListEmpty = () => {
        return (
            <View style={{ justifyContent: 'center', flex: 1, margin: 10 }}>
                <Text style={{ textAlign: 'center', color: styles.PRIMARY__CONTENT__COLOR }}>{t('no_match_result')}</Text>
            </View>
        )
    }

    const onPressAddStockToList = (stk) => {
        Keyboard.dismiss()
        setSelectStock(stk)
        setModal(true)
        return
    }

    const onChangeStatus = () => {
        getListRencent()

        if (!searchRef.current) return
        const newList = glb_sv.mrk_stklist
            .filter((e) => e.t55.includes(searchRef.current))
            .slice(0, 30)
            .sort(function (a, b) {
                if (a.t55 > b.t55) return -1
                if (a.t55 < b.t55) return 1
                return 0
            })
        const newList1 = []
        newList.forEach((element) => {
            const obj = glb_sv.mrk_stklist.find((e) => e.t55 === element.t55)
            if (obj) {
                const cloneObj = { ...obj }
                glb_sv.allListFav.forEach((item) => {
                    if (item.ListStock.some((temp) => temp === cloneObj.t55)) {
                        cloneObj.isFav = true
                        if (cloneObj.ExistNameFav) {
                            cloneObj.ExistNameFav += ', ' + item.c2
                        } else cloneObj.ExistNameFav = item.c2
                    }
                })
                newList1.push(cloneObj)
            }
        })
        setListStock(newList1)
    }

    return (
        <View
            style={{
                flex: 1,
                backgroundColor: styles.PRIMARY__BG__COLOR,
            }}
        >
            <SafeAreaView style={{ flex: 1 }}>
                <View
                    style={{
                        flexDirection: 'row',
                        height: 35,
                        paddingHorizontal: 5,
                        marginTop: 5,
                    }}
                >
                    <View
                        style={{
                            backgroundColor: styles.HEADER__BG__COLOR,
                            flexDirection: 'row',
                            flex: 1,
                            borderRadius: 10,
                            padding: 0,
                        }}
                    >
                        <AntDesign color={styles.PLACEHODLER__COLOR} name="search1" size={20} style={{ paddingVertical: 7, paddingLeft: 5 }} />
                        <TextInput
                            autoCapitalize="characters"
                            placeholder={t('hint_stock_search')}
                            placeholderTextColor={styles.PLACEHODLER__COLOR}
                            style={{
                                color: styles.PRIMARY__CONTENT__COLOR,
                                fontSize: fontSizes.small,
                                padding: 0,
                                paddingHorizontal: 5,
                                flex: 1,
                            }}
                            value={seach}
                            onChangeText={(search) => getListStock(search)}
                        />
                        {seach ? (
                            <AntDesign
                                color={styles.PLACEHODLER__COLOR}
                                name="closecircle"
                                size={20}
                                style={{ paddingVertical: 7, paddingHorizontal: 5 }}
                                onPress={resetData}
                            />
                        ) : null}
                    </View>
                    <Button style={{ paddingVertical: 0, paddingHorizontal: 10, height: 35 }} transparent onPress={() => navigation.pop()}>
                        <Text style={{ color: styles.BUTTON__TEXT__ACTIVE, fontSize: fontSizes.xxmedium }}>{t('common_Cancel')}</Text>
                    </Button>
                </View>

                {listStock.length === 0 && seach.length === 0 ? (
                    recentList.length ? (
                        <View style={{ marginTop: 10 }}>
                            <Text
                                style={{
                                    color: styles.HEADER__CONTENT__COLOR,
                                    paddingHorizontal: 5,
                                }}
                            >
                                {t('search_recent')}
                            </Text>
                            {recentList.map((item) => (
                                <StockItem item={item} key={item.t55} />
                            ))}
                        </View>
                    ) : null
                ) : (
                    <FlatList
                        data={listStock}
                        keyboardShouldPersistTaps="always"
                        keyExtractor={(item, index) => item?.t55 || index.toString()}
                        ListEmptyComponent={ListEmpty}
                        renderItem={StockItem}
                        style={{ marginBottom: 10 }}
                    />
                )}
            </SafeAreaView>

            <ModalAddStock2FavList
                isModalVisible={isModalVisible}
                navigation={navigation}
                selectStock={selectStock}
                setModal={setModal}
                styles={styles}
                onChangeStatus={onChangeStatus}
            />
        </View>
    )
}
