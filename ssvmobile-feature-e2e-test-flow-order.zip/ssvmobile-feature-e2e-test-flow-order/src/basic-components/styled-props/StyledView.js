import styled from 'styled-components/native'

const StyledView = styled.View`
    background-color: ${(props) => props.backgroundColor || 'transparent'};
    height: ${(props) => (props.height ? props.height + 'px' : 'auto')};
    width: ${(props) => (props.width ? props.width + 'px' : 'auto')};
    padding: ${(props) => props.padding || 0}px;
    padding-right: ${(props) => props.paddingRight || 0}px;
    padding-left: ${(props) => props.paddingLeft || 0}px;
    padding-top: ${(props) => props.paddingTop || 0}px;
    padding-bottom: ${(props) => props.paddingBottom || 0}px;
    border-color: ${(props) => props.borderColor || 'transparent'};
    border-width: ${(props) => props.borderWidth || 0}px;
    border-radius: ${(props) => props.borderRadius || 0}px;
    margin: ${(props) => props.margin || 0}px;
    margin-right: ${(props) => props.marginRight || 0}px;
    margin-left: ${(props) => props.marginLeft || 0}px;
    margin-top: ${(props) => props.marginTop || 0}px;
    margin-bottom: ${(props) => props.marginBottom || 0}px;
    position: ${(props) => props.position || 'relative'};
    flex-direction: ${(props) => props.flexDirection || 'column'};
    top: ${(props) => props.top || 0}px;
    left: ${(props) => props.left || 0}px;
    z-index: ${(props) => props.zIndex || 0};
    border-top-left-radius: ${(props) => props.borderTopLeftRadius || props.borderRadius || 0}px;
    border-bottom-left-radius: ${(props) => props.borderBottomLeftRadius || props.borderRadius || 0}px;
`

export default StyledView
