import React, { useContext, useMemo } from 'react'
import { StyleSheet, View, ViewProps } from 'react-native'

import { Text } from '../../../basic-components'
import { StoreContext } from '../../../store'
import { dimensions as dm, fontSizes as fs, fontWeights as fw } from '../../../styles'

interface IRowTitleGroup {
    text?: string
    iconRight?: any
    type?: 'table' | 'group'
    hasDivider?: boolean
    rightComponent?: any
    iconLeft?: any
    style?: ViewProps['style']
    styleTitle?: string
    noPaddingHorizontal?: boolean
    prefixIcon?: React.ReactNode
}

const RowTitleGroup = ({
    text = '', // Nội dung header
    iconRight = null, // Right Component
    type = 'table', // type của header
    hasDivider, // Có divider hay không
    rightComponent,
    iconLeft,
    style,
    styleTitle,
    noPaddingHorizontal,
    prefixIcon,
}: IRowTitleGroup) => {
    const { styles } = useContext(StoreContext)

    const RowStyleMemo = useMemo(
        () =>
            StyleSheet.flatten([
                {
                    paddingHorizontal: type === 'group' ? (noPaddingHorizontal ? 0 : dm.moderate(12)) : dm.moderate(16),
                    marginTop: type === 'group' ? dm.vertical(8) : dm.vertical(16),
                    paddingTop: dm.vertical(6),
                    borderColor: styles.DIVIDER__COLOR,
                    borderTopWidth: hasDivider ? 6 : 0,
                    marginBottom: type === 'group' ? dm.moderate(6) : 0,
                    flexDirection: 'row',
                    ...style,
                },
            ]),
        [styles, style, type, hasDivider, noPaddingHorizontal],
    )

    return (
        <View style={RowStyleMemo}>
            {prefixIcon ? (
                <View style={UI.PrefixIcon}>
                    <View>{prefixIcon}</View>
                </View>
            ) : null}
            <View style={UI.RowLeft}>
                {text ? (
                    <Text
                        style={[
                            UI.RowLeftText,
                            {
                                color: styleTitle || styles.PRIMARY__CONTENT__COLOR, //'#e0e0e0'
                            },
                        ]}
                    >
                        {text}
                    </Text>
                ) : null}
                {iconLeft}
            </View>
            <View style={UI.RowRight}>
                <View>{iconRight ? iconRight : rightComponent}</View>
            </View>
        </View>
    )
}

export default RowTitleGroup

const UI = StyleSheet.create({
    PrefixIcon: { justifyContent: 'flex-start', marginRight: 4 },
    RowLeft: { alignItems: 'center', flexDirection: 'row', flex: 1 },
    RowLeftText: {
        fontSize: fs.medium,
        fontWeight: fw.bold,
        marginRight: 5,
    },
    RowRight: { justifyContent: 'flex-end' },
})
