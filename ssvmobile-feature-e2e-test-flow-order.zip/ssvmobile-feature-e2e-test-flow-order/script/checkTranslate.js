/**
 * Tính năng chính
 * 1. Cảnh báo khi thiếu key trong main file (vi, en, cn, zh, ko)
 * 2. Cảnh báo khi nội dung của key bị trùng ở nhiều file
 *
 */

// Path for translation
const jsonPath = '../src/translate/language'
const listCompany = ['081']
const listLanguage = ['en', 'vi', 'cn', 'zh', 'ko']
// Prepare data
const _en = require(`${jsonPath}/en.json`)
const _vi = require(`${jsonPath}/vi.json`)
const _cn = require(`${jsonPath}/cn.json`)
const _zh = require(`${jsonPath}/zh.json`)
const _ko = require(`${jsonPath}/ko.json`)
let countMissingKeyInMainFile = 0

// All key
const allKeyObj = {}
listLanguage.forEach((langName) => {
    // Check main file
    const mainTranslateFile = require(`${jsonPath}/${langName}.json`) || {}
    for (const [key, value] of Object.entries(mainTranslateFile)) {
        const hasOwnProperty = Object.prototype.hasOwnProperty.call(allKeyObj, key)
        if (!hasOwnProperty) {
            allKeyObj[key] = true
        }
    }
    // Check custom company file
    listCompany.forEach((company) => {
        try {
            const customTranslateFile = require(`${jsonPath}/${company}_${langName}.json`) || {}
            for (const [key, value] of Object.entries(customTranslateFile)) {
                const hasOwnProperty = Object.prototype.hasOwnProperty.call(allKeyObj, key)
                if (!hasOwnProperty) {
                    countMissingKeyInMainFile++
                    allKeyObj[key] = true
                }
            }
        } catch (error) {}
    })
})
// -----------
if (countMissingKeyInMainFile) {
    console.error('Check translation failed -', countMissingKey, ' missing key in Main file found')
} else {
}

let countMissingKey = 0
// ------
const startCheckTranslationMissingKey = () => {
    for (const [key, value] of Object.entries(allKeyObj)) {
        if (!_en[key]) {
            countMissingKey++
        }
    }
    for (const [key, value] of Object.entries(allKeyObj)) {
        if (!_vi[key]) {
            countMissingKey++
        }
    }
    for (const [key, value] of Object.entries(allKeyObj)) {
        if (!_cn[key]) {
            countMissingKey++
        }
    }
    for (const [key, value] of Object.entries(allKeyObj)) {
        if (!_zh[key]) {
            countMissingKey++
        }
    }
    for (const [key, value] of Object.entries(allKeyObj)) {
        if (!_ko[key]) {
            countMissingKey++
        }
    }
    if (countMissingKey) {
        console.error('Check translation failed -', countMissingKey, 'missing key found')
    } else {
    }
    return
}

const checkDublicateTranslationContent = () => {
    // -----
    for (const [key, value] of Object.entries(allKeyObj)) {
        checkDublicateContentByKey(key)
    }
}

const excludeKeyCheckDublicate = [
    'roa(%)',
    'roe(%)',
    't31_incr',
    't31_incr_per',
    'in_decrease',
    'year_short',
    'week_short',
    'price_PT',
    'price_PLO',
    'price_MTL',
    'price_Mp',
    'price_MOK',
    'price_MAK',
    'price_ATO',
    'price_ATC',
    'order_MOK',
    'mrk_upc',
    'mrk_hose',
    'mrk_hnx',
    'month_short',
    'ATO_session',
    'ATC_session',
    'order_ATC',
    'order_ATO',
    'order_Mp',
    'order_MTL',
    'order_PLO',
    'reference',
    'ceiling',
    'floor',
    'email',
    'buy_short',
    'sell_short',
    'head_sms',
    'pb_num',
    'pe_num',
    'eps(vnd/cp)',
    'profit_loss_ratio',
    'order_MAK',
]

const checkDublicateContentByKey = (key) => {
    if (excludeKeyCheckDublicate.includes(key)) {
        // Skip check for this key
        return
    }
    // ---- EN
    if (_en[key] === _vi[key]) {
        if (_en[key] === undefined || _en[key] === '') return
    }
    if (_en[key] === _cn[key]) {
        if (_en[key] === undefined || _en[key] === '') return
    }
    if (_en[key] === _zh[key]) {
        if (_en[key] === undefined || _en[key] === '') return
    }
    if (_en[key] === _ko[key]) {
        if (_en[key] === undefined || _en[key] === '') return
    }
    // ------ VI
    if (_vi[key] === _cn[key]) {
        if (_vi[key] === undefined || _vi[key] === '') return
    }
    if (_vi[key] === _zh[key]) {
        if (_vi[key] === undefined || _vi[key] === '') return
    }
    if (_vi[key] === _ko[key]) {
        if (_vi[key] === undefined || _vi[key] === '') return
    }
    // ----- CN
    if (_cn[key] === _zh[key]) {
        if (_cn[key] === undefined || _cn[key] === '') return
        // CN-zH hiện tại đang giống nhau rất nhiều ==> tạm thời bỏ qua
    }
    if (_cn[key] === _ko[key]) {
        if (_cn[key] === undefined || _cn[key] === '') return
    }
    // ----- zH
    if (_zh[key] === _ko[key]) {
        if (_zh[key] === undefined || _zh[key] === '') return
    }
}

const removeUnnessesaryKeyOnCustomCompanyTranslate = () => {
    listCompany.map((company) => {
        // Remove key if dublicate
    })
}

module.exports = {
    startCheckTranslationMissingKey,
    checkDublicateTranslationContent,
    removeUnnessesaryKeyOnCustomCompanyTranslate,
}
startCheckTranslationMissingKey()
checkDublicateTranslationContent()
removeUnnessesaryKeyOnCustomCompanyTranslate()
