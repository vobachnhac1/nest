import React, { useEffect, useRef, useState } from 'react'
import Highcharts from 'highcharts'
import Treemap from 'highcharts/modules/treemap'
import HighchartsReact from 'highcharts-react-official'

Treemap(Highcharts)

const HighChartAssetsPieChart = () => {
    const [dataChart, setDataChart] = useState([])
    const chartRef = useRef(null)

    useEffect(() => {
        const eventMarket = window.eventMarket.subscribe((msg) => {
            if (msg.type === 'highcharts-assetsPieChart') {
                convertedAndUpdateData()
            }
        })
        convertedAndUpdateData()
        return () => {
            eventMarket?.unsubscribe()
        }
    }, [])

    const convertedAndUpdateData = () => {
        const data = window.DataAssetPieChart || []
        setDataChart([...data])
    }

    const options = {
        chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: 'pie',
            height: 400,
        },
        title: {
            text: null,
        },
        tooltip: {
            formatter: function () {
                return (
                    this.point.name +
                    '<b style="color:' +
                    this.point.colorProfit +
                    '">' +
                    ' (' +
                    this.point.profitRatio +
                    ')' +
                    '</b> </br>' +
                    this.series.name +
                    ': <b>' +
                    Math.round(this.point.percentage * 10) / 10 +
                    '%</b>'
                )
            },
            // pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b> </br> <b style="color:{point.colorProfit}">({point.profitRatio:.1f})</b>',
        },
        accessibility: {
            point: {
                valueSuffix: '%',
            },
        },
        plotOptions: {
            pie: {
                size: 200,
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {
                    enabled: true,
                    format: '<b>{point.name}</b>: {point.percentage:.1f}%',
                    style: {
                        color: 'var(--TEXT__1)',
                        fontSize: 'var(--xnormal)',
                        textOutline: false,
                    },
                },
            },
        },
        series: [
            {
                name: window.asset_ratio,
                colorByPoint: true,
                innerSize: '70%',
                data: dataChart,
            },
        ],
        credits: { enabled: false },
    }

    return (
        <div id="highcharts-assetsPieChart" style={{ height: 'calc(100vh)', width: 'calc(100vw)' }}>
            {/* <span style={{ color: 'red'}}> none </span> */}
            {/* {loading ? <span style={{ color: 'red'}}> Loading </span> : null} */}
            <HighchartsReact
                callback={(chart) => {
                    const elm = document.getElementById('highcharts-assetsPieChart')
                    chart.update({
                        chart: {
                            height: elm?.offsetHeight,
                        },
                    })
                }}
                highcharts={Highcharts}
                options={options}
                ref={chartRef}
            />
        </div>
    )
}

export default HighChartAssetsPieChart
