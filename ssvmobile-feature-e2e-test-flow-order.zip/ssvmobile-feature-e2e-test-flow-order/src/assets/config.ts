import Config from 'react-native-config'
import { getBuildNumber, getVersion } from 'react-native-device-info'
import moment from 'moment'

import defaultApplictionConfig from './application_config'
import { CONFIG_PRODUCTION } from './config_production'
import { CONFIG_TEST } from './config_test'

export const ENV = 'CONFIG_TEST'
export type IActiveCode = '081'
export type ICompanyName = 'shinhan'

export const Company: { [key in ICompanyName]: IActiveCode } = {
    shinhan: '081',
}
const currentDate = new Date()
export const activeCode = '081'
export const APP_VERSION = getVersion()
export let APP_BUILD_NUMBER = `${moment(currentDate).format('YYYYMMDD')}.${getBuildNumber()}${Config.CUSTOM_APP_CONFIG === 'CONFIG_TEST' ? '-(UAT)' : ''}`

const getConfig = (env: 'CONFIG_TEST' | 'CONFIG_PRODUCTION') => {
    switch (env) {
        case 'CONFIG_TEST':
            return CONFIG_TEST
        case 'CONFIG_PRODUCTION':
            return CONFIG_PRODUCTION
        default:
            APP_BUILD_NUMBER += '-E'
            return CONFIG_TEST
    }
}

const getApplicationConfig = (env: 'CONFIG_TEST' | 'CONFIG_PRODUCTION', activeCode: IActiveCode) => {
    return defaultApplictionConfig[activeCode] || {}
}

export const application_config = getApplicationConfig(ENV, activeCode)

// @ts-expect-error
const CONFIG: IAltMasterConfig = getConfig(ENV)
CONFIG.active_code = activeCode
CONFIG[activeCode].build_version = APP_VERSION
export default CONFIG

interface IAltMasterConfig {
    active_code: IActiveCode
    '081': IAltMasterConfigPerCompany
}

export interface IAltMasterConfigPerCompany {
    server_node_list: Servernodelist[]
    avatar_restful_domain?: string
    sub_path_stream?: string
    sub_path_trading?: string
    build_version: string
    comp_full: string
    comp_full_e: string
    comp_full_cn?: string
    copyright: string
    copyright_e: string
    copyright_cn?: string
    expiretime: number
    openLinkIos?: string
    discexpire: number
    riskdisclosure_link?: string
    branch_location?: string
    list_index?: string[]
    language_list?: string[]
    shortName?: string
    logo_text?: string
    term_service?: string
    privacy_policy?: string
    link_playStore?: string
    link_appStore?: string
    public?: boolean
    debug?: boolean
    latencyTime?: number
    appIdOnesignal?: string
    isFinance?: boolean
    additionalStockRelease?: boolean
    fraction_qty?: string
    support_phone_number?: string
    avatar_default_url?: string
    econtract_download_url?: string
    application_style: Applicationstyle
}

interface Applicationstyle {
    default_style?: string
    auto_start_login_screen?: boolean
    default_hide_assets?: boolean
    is_ekyc_bank_acc_link?: boolean
    show_get_iotp?: boolean
    is_default_order_price?: boolean
    is_iotp_off?: boolean
    is_profit_loss_screen_on?: boolean
    is_history_login_screen_on?: boolean
    is_order_price_unit_default_1000?: boolean
    is_change_otp_type_screen_on?: boolean
    is_oauth2?: boolean
    is_reset_trading_code?: boolean
    is_oddlot_info_order?: boolean
    zalo_support_link?: string
    is_show_pass_forget_warning?: boolean
    is_show_SMS_OTP_Modal?: boolean
    is_information_change?: boolean
    is_update_phone_email?: boolean
    is_update_account_info_screen_on?: boolean
    is_hide_fee?: boolean
    grid_column?: 3 | 4
    tab_style?: '2.0' | '1.0' | '1.1'
    tabbar_style?: '2.0' | '1.0' | '1.1'
    is_userguide_service?: {
        vi: string
        en: string
    }
    is_show_oldlot_note?: boolean
    is_user_information_update?: boolean
    zalo_support_content_key?: string
    default_theme?: 'DARK' | 'LIGHT'
    is_show_registration_popup?: boolean
    is_update_user_info_screen_on?: boolean
    is_show_expected_rights_screen?: boolean // hiện màn hình Expected rights info (SSV only)
    is_show_query_by_ex_right_day?: boolean // hiện query rights info theo tháng trên màn hình Rights info (SSV only)
    is_show_disclaimer_notification?: boolean // hiện popup thông báo thông tin quyền trên màn hình Rights info (SSV only)
    is_hide_rights_detail?: boolean // ẩn màn hình Rights detail (SSV only)
    is_show_expected_rights_info?: boolean // hiển thị bảng Quyền dự kiến trong danh mục trong màn hình rights info
    screen_sign_up?: {
        is_warn_account_exist_required_login?: true // Warn và navigate tới login nếu đã tồn tại
    }
}

export interface Servernodelist {
    index: number
    is_single_socket?: boolean
    location: string
    key_name: string
    key_name_note: string
    icon: string
    stream_server: StreamServerConfig
    trading_server: TradingServerConfig
}

export interface StreamServerConfig {
    ip_address: string[]
}

export interface TradingServerConfig {
    ip_address: string[]
}
