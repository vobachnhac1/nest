import React, { memo } from 'react'
import { Platform, View } from 'react-native'
import { WebView } from 'react-native-webview'

import { StoreContext } from '../../../store'
import { dimensions } from '../../../styles'
import { glb_sv } from '../../../utils'
import Chart from '../../f2-chart'

const IOS = Platform.OS === 'ios' ? true : false

const ColumnChartPrice = ({ stockCode, data }) => {
    const stock = glb_sv.StockMarket[stockCode] || {}

    if (!stock.t260 || !data.length) return <View />
    const { styles } = React.useContext(StoreContext)

    data.sort(function (a, b) {
        if (a.P > b.P) return 1
        if (a.P < b.P) return -1
        return 0
    }).forEach((element) => {
        element.color = glb_sv.getColor(element.P, stock, styles)
    })

    return (
        <View style={{ paddingLeft: 5, minWidth: (dimensions.WIDTH - dimensions.moderate(16)) / 2 }}>
            <View style={{ height: 360, backgroundColor: styles.PRIMARY__BG__COLOR }}>
                <Chart data={data} initScript={IOS ? chartPriceIOS(data) : chartPriceAndroid(data)} webView={WebView} />
            </View>
            <View style={{ height: 20 }} />
        </View>
    )
}

export default memo(ColumnChartPrice)

const chartPriceAndroid = (data) => `
setTimeout(() => {
const chart = new F2.Chart({
  id: 'chart',
  pixelRatio: window.devicePixelRatio,
});
chart.source(${JSON.stringify(data)}, {
    P: {
        type: 'cat'
      },
Q: {
    tickCount: 3
},
grid: (text, index, total) => {
    return {
      stroke: '#cacaca'
    }
},
});
chart.legend(false)
chart.tooltip(false);
chart.coord({
    transposed: true
});
chart.axis('P', {
    label: function label(text) {
        return {
            text: window.formatNumber(text * 1),
            fill: '#cacaca'
        };
    }
});

chart.axis('Q', {
    position: 'right',
    label: function label(text) {
        return {
            text: window.nFormatter(text * 1, 2),
            fill: '#cacaca'
        };
    },
    grid: function grid(text) {
        return {
            stroke: '#cacaca80'
        }
    },
    line: {
        stroke: 'transparent',
        lineWidth: 0
    }
});
if (${JSON.stringify(data)}.length > 6) {
    chart.interval().position('P*Q').color('color', function(val) {
        return val;
    })
} else {
    chart.interval().position('P*Q').color('color', function(val) {
        return val;
    }).size(10);
}
chart.render();
window.chart = chart
},1000);
true;
`

const chartPriceIOS = (data) => `
setTimeout(() => {
const chart = new F2.Chart({
  id: 'chart',
  pixelRatio: window.devicePixelRatio,
});
chart.source(${JSON.stringify(data)}, {
    P: {
        type: 'cat'
      },
Q: {
    tickCount: 3
},
grid: (text, index, total) => {
    return {
      stroke: '#cacaca'
    }
},
});
chart.legend(false)
chart.tooltip(false);
chart.coord({
    transposed: true
});
chart.axis('P', {
    label: function label(text) {
        return {
            text: window.formatNumber(text * 1),
            fill: '#cacaca'
        };
    }
});

chart.axis('Q', {
    position: 'right',
    label: function label(text) {
        return {
            text: window.nFormatter(text * 1, 2),
            fill: '#cacaca'
        };
    },
    grid: function grid(text) {
        return {
            stroke: '#cacaca80'
        }
    },
    line: {
        stroke: 'transparent',
        lineWidth: 0
    }
});
if (${JSON.stringify(data)}.length > 6) {
    chart.interval().position('P*Q').color('color', function(val) {
        return val;
    })
} else {
    chart.interval().position('P*Q').color('color', function(val) {
        return val;
    }).size(10);
}
chart.render();
window.chart = chart
},1000);
true;
`
