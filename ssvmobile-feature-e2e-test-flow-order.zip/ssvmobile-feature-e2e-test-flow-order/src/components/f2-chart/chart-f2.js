import React, { Component, createRef } from 'react'
import { Platform, StyleSheet } from 'react-native'
import WebView from 'react-native-webview'

import { eventList, glb_sv } from '../../utils'

const source = Platform.select({
    ios: require('../../basic-components/custom-chart/index.html'),
    android: { uri: 'file:///android_asset/index.html' },
})

export default class Chart extends Component {
    constructor(props) {
        super(props)
        this.chart = createRef()
        this.state = {
            webviewKey: new Date().getTime(),
        }
        this.dataIndex = []
        glb_sv.listActiveIndex.forEach((temp) => {
            const newData = glb_sv.IndexMarket[temp].arrMinutes
            const newList = glb_sv.chartConvert2Minutes(newData)
            this.dataIndex = this.dataIndex.concat(newList)
        })
    }

    componentDidMount() {
        this.eventMarket = glb_sv.eventMarket.subscribe((msg) => {
            if (msg.type === eventList.SUB_INDEX && msg.newIndexNode && glb_sv.isVisibleMarket) {
                this.chart.current &&
                    this.chart.current.injectJavaScript(`
                    if (window.eventMarket) window.eventMarket.next({ type: 'f2-realtime', newIndexNode: ${JSON.stringify(msg.newIndexNode)} })
                    true;
                `)
            }
            if (msg.type === eventList.GET_DATA_I_MINUTES_DONE) {
                this.dataIndex = []
                glb_sv.listActiveIndex.forEach((temp) => {
                    const newData = glb_sv.IndexMarket[temp].arrMinutes
                    const newList = glb_sv.chartConvert2Minutes(newData)
                    this.dataIndex = this.dataIndex.concat(newList)
                })

                setTimeout(() => {
                    this.chart.current &&
                        this.chart.current.injectJavaScript(`
                    window.dataMarket = ${JSON.stringify(this.dataIndex)}
                    if (window.eventMarket) window.eventMarket.next({ type: 'f2-history', data: ${JSON.stringify(this.dataIndex)} })
                    true;
                `)
                }, 2000)
            }
            if (msg.type === eventList.RESET_DATA) {
                this.dataIndex = []
                this.chart.current &&
                    this.chart.current.injectJavaScript(`
                    window.dataMarket = [];
                    if (window.eventMarket) window.eventMarket.next({ type: 'f2-history', data: ${JSON.stringify(this.dataIndex)} })
                    true;
                `)

                setTimeout(() => {
                    this.chart.current &&
                        this.chart.current.injectJavaScript(`
                    if (window.eventMarket) window.eventMarket.next({ type: 'change_color_f2', data: '' })
                `)
                }, 0)

                setTimeout(() => {
                    this.chart.current &&
                        this.chart.current.injectJavaScript(`
                        if (window.eventMarket) window.eventMarket.next({ type: 'change_color_f2', data: '${this.props.active}' })
                    `)
                }, 100)
            }
        })
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.active !== this.props.active) {
            this.chart.current &&
                this.chart.current.injectJavaScript(`
                if (window.eventMarket) window.eventMarket.next({ type: 'change_color_f2', data: '${nextProps.active}' })
            `)
        }
        if (nextProps.theme !== this.props.theme) {
            this.chart.current &&
                this.chart.current.injectJavaScript(`
            if (window.eventMarket) window.eventMarket.next({ type: 'f2_theme', data: '${nextProps.theme}' })
        `)
        }
    }

    componentWillUnmount() {
        this.eventMarket.unsubscribe()
    }

    reload = () => {
        this.setState({
            webviewKey: this.state.webviewKey + 1,
        })
    }

    shouldComponentUpdate() {
        return false
    }

    render() {
        return (
            <WebView
                allowUniversalAccessFromFileURLs={true}
                androidHardwareAccelerationDisabled
                androidLayerType="hardware"
                domStorageEnabled={true}
                source={source}
                // source={{
                //     uri: 'http://localhost:3000/' || 'http://192.168.1.10:3000'
                // }}
                injectedJavaScriptBeforeContentLoaded={`
                    new Date().toLocaleString();
                    window.theme = '${this.props.theme}';
                    window.isMarket = true;
                    window.active = '${this.props.active || glb_sv.listActiveIndex[0]}';
                    window.listIndex = ${JSON.stringify(glb_sv.listActiveIndex)}
                    window.dataMarket = ${JSON.stringify(this.dataIndex)}
                `}
                javaScriptEnabled
                key={this.state.webviewKey}
                originWhitelist={['*']}
                ref={this.chart}
                scrollEnabled={false}
                style={styles.webView}
                onContentProcessDidTerminate={this.reload}
            />
        )
    }
}

const styles = StyleSheet.create({
    webView: {
        backgroundColor: 'transparent',
        flex: 1,
    },
})
