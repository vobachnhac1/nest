import React, { useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Image, RefreshControl, ScrollView, StyleSheet, TouchableOpacity } from 'react-native'
import ToastGlobal from 'react-native-toast-message'
import { removeAccents } from '@mts-utils/formatString/formatString'
import Clipboard from '@react-native-clipboard/clipboard'
import isEmpty from 'lodash/isEmpty'
import { Container, Content, Row, View } from 'native-base'

import IconCopy from '../../assets/images/common/ic_copy.svg'
import { Text } from '../../basic-components'
import Account from '../../components/account'
import HeaderComponent from '../../components/header'
import { RowTitleGroup } from '../../components/trading-component'
import { StoreContext } from '../../store'
import { StoreTrading } from '../../store-trading'
import { dimensions, IconSvg } from '../../styles'
import { glb_sv, reqFunct, sendRequest, wait } from '../../utils'

const ServiceInfo = {
    getListBankTran: {
        reqFunct: reqFunct.GET_LIST_BANK_TRANS, //Lấy DS ngân hàng chuyển
        WorkerName: 'FOSqCash',
        ServiceName: 'FOSqCash_Common',
        ClientSentTime: '0',
        Operation: 'Q',
    },
}

const listBank = ['100200235844', '1007797979', '147001536703', '1541150087177']

const AccountMessage = ({ message, styles, index, subSelected, onClickCopy }) => {
    const accountSelected = subSelected === index ? { color: styles.PRIMARY__CONTENT__COLOR } : { color: styles.HEADER__CONTENT__COLOR }
    return (
        <Row style={{ alignItems: 'center', marginBottom: 10 }}>
            <Text style={{ fontSize: 12, flex: 1, fontWeight: 'bold', ...accountSelected }}>{message || '--'}</Text>
            <TouchableOpacity onPress={() => onClickCopy(message)}>
                <IconCopy fill={styles.ICON__PRIMARY} style={UI.icon} />
            </TouchableOpacity>
        </Row>
    )
}

const BankItem = ({ item, avatarDomain, styles, onClickCopy }) => {
    const linkIcon = `${avatarDomain}/assets/bank_icon/${item.c0}.png`
    return (
        <Row style={{ marginTop: 10, alignItems: 'center', justifyContent: 'space-between' }}>
            <View style={{ padding: 5, borderWidth: 1, borderColor: styles.BORDER__MODAL, borderRadius: 8, backgroundColor: '#FFF' }}>
                <Image resizeMode={'contain'} source={{ uri: linkIcon }} style={{ width: 60, height: 40 }} />
            </View>
            <View style={{ flex: 1, marginLeft: 10 }}>
                <Text style={{ fontWeight: 'bold', marginBottom: 5, color: styles.PRIMARY__CONTENT__COLOR }}>{item.c2}</Text>
                <Text style={{ fontWeight: '500', color: styles.SIXTH__CONTENT__COLOR }}>{item.c1}</Text>
            </View>
            <TouchableOpacity onPress={() => onClickCopy(item.c2)}>
                <IconCopy fill={styles.SIXTH__CONTENT__COLOR} style={UI.icon} />
            </TouchableOpacity>
        </Row>
    )
}

export default function DepositGuide({ navigation, route }) {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()
    const [listBankAccount, setListBankAccount] = useState([])
    const [subSelected, setSubSelected] = useState(Number(glb_sv.userInfo.sub_curr))
    const refreshing = useRef(false)
    const avatarDomain = glb_sv.configInfo.avatar_restful_domain
    const { userInfo } = useContext(StoreTrading)
    const getListBankAccount = () => {
        const inputParams = ['02', '']
        sendRequest(ServiceInfo.getListBankTran, inputParams, handleGetBankAccount)
    }

    useEffect(() => {
        getListBankAccount()
    }, [])

    const handleGetBankAccount = (reqInfoMap, message) => {
        refreshing.current = false
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata = []
            const listBankData = []
            try {
                jsondata = JSON.parse(message.Data)
                jsondata.map((item) => {
                    if (listBank.includes(item.c2)) {
                        listBankData.push(item)
                    }
                })
                setListBankAccount(listBankData)
            } catch (err) {
                return
            }
        }
    }

    const onRefresh = () => {
        refreshing.current = true
        wait(300).then(() => {
            getListBankAccount()
        })
    }

    const onClickCopy = (text) => {
        if (!text) return
        Clipboard.setString(String(text))
        ToastGlobal.show({
            text2: t('copied'),
            type: 'success',
            position: 'bottom',
        })
    }

    const _onClickBackButton = () => {
        navigation.goBack()
    }

    const onChangeSub = (sub) => {
        setSubSelected(Number(sub))
    }

    const depositMessage = (sub) => `${t('deposit_guide_deposit')} ${userInfo.actn_curr}${sub}  ${removeAccents(userInfo.actn_name)}`

    return (
        <Container>
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft
                leftButtonLink={_onClickBackButton}
                navigation={navigation}
                title={t('deposit_guide_header')}
                titleAlgin="flex-start"
                transparent
            />
            <Content
                refreshControl={<RefreshControl refreshing={refreshing.current} tintColor={styles.PRIMARY__CONTENT__COLOR} onRefresh={onRefresh} />}
                style={{ ...UI.container, backgroundColor: styles.PRIMARY__BG__COLOR }}
            >
                <ScrollView>
                    <View style={{ flexDirection: 'row', paddingHorizontal: dimensions.moderate(8), marginTop: dimensions.moderate(4) }}>
                        <Account changeSub={(e) => onChangeSub(e.sub_curr)} navigation={navigation} noPadding />
                    </View>

                    <RowTitleGroup hasDivider />

                    <Row style={{ alignItems: 'center', padding: 10, flexWrap: 'wrap' }}>
                        <IconSvg.ErrorIcon color={styles.WARN__COLOR} />
                        <Text style={{ color: 'red', marginLeft: 10, flex: 1 }}>{t('deposit_guide_hint')}</Text>
                    </Row>

                    <View
                        style={[
                            UI.viewMessage,
                            {
                                backgroundColor: styles.BUTTON__PRIMARY__DISABLED,
                                borderColor: styles.LINE_MA30,
                            },
                        ]}
                    >
                        {!isEmpty(userInfo.sub_list) &&
                            userInfo?.sub_list.map((item, index) => (
                                <AccountMessage
                                    index={index}
                                    message={depositMessage(item)}
                                    styles={styles}
                                    subSelected={subSelected}
                                    onClickCopy={onClickCopy}
                                />
                            ))}
                    </View>

                    <View style={UI.wrap}>
                        <Text style={{ color: styles.SIXTH__CONTENT__COLOR }}>{t('deposit_guide_beneficiary')}</Text>
                        <Text style={{ ...UI.content, fontSize: 16, color: styles.PRIMARY__CONTENT__COLOR }}>{t('deposit_guide_received_account')}</Text>
                        <Text style={{ color: styles.SIXTH__CONTENT__COLOR, marginTop: 16 }}>{t('deposit_guide_account_received')}</Text>
                        {listBankAccount.map((item) => (
                            <BankItem avatarDomain={avatarDomain} item={item} styles={styles} onClickCopy={onClickCopy} />
                        ))}
                    </View>
                </ScrollView>
            </Content>
        </Container>
    )
}

const UI = StyleSheet.create({
    container: {
        paddingHorizontal: dimensions.halfIndent,
    },
    content: {
        borderBottomWidth: 1,
        fontSize: 18,
        fontWeight: 'bold',
        paddingTop: dimensions.moderate(4),
    },
    icon: {
        height: 20,
        width: 20,
    },
    logo: {
        resizeMode: 'contain',
        width: dimensions.WIDTH * 0.3,
    },
    logoBox: {
        alignItems: 'center',
        backgroundColor: 'white',
        borderRadius: 15,
        borderWidth: 3,
        flexDirection: 'row',
        height: 80,
        justifyContent: 'center',
        width: dimensions.WIDTH * 0.35,
    },
    qrFooter: {
        alignSelf: 'center',
        fontSize: 15,
        fontWeight: 'bold',
        paddingTop: dimensions.moderate(8),
    },
    qrTitle: {
        alignSelf: 'center',
        flexDirection: 'row',
        paddingVertical: dimensions.moderate(16),
    },
    qrcode: {
        alignSelf: 'center',
        borderRadius: 18,
        marginVertical: dimensions.moderate(12),
        padding: dimensions.moderate(12),
    },
    qrcodeInner: {
        alignSelf: 'center',
        borderRadius: 15,
        paddingHorizontal: dimensions.moderate(16),
        width: '100%',
    },
    title: {
        fontSize: 15,
        paddingLeft: dimensions.moderate(24),
    },
    viewMessage: {
        borderRadius: 12,
        borderWidth: 1,
        paddingHorizontal: 16,
        paddingVertical: 8,
    },
    wrap: {
        paddingHorizontal: dimensions.halfIndent,
        paddingVertical: dimensions.moderate(16),
    },
    wrapContent: {
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
    wrapLogo: {
        justifyContent: 'space-around',
        marginVertical: dimensions.moderate(16),
        paddingHorizontal: dimensions.halfIndent,
    },
})
