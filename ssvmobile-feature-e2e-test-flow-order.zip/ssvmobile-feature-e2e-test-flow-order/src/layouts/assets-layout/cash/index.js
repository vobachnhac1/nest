import React, { memo, useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { ActivityIndicator, StyleSheet } from 'react-native'
import { Text, View } from 'native-base'

import ErrorView from '../../../components/trading-component/error-view'
import { StoreContext } from '../../../store'
import { dimensions, fontSizes, fontWeights } from '../../../styles'
import { FormatNumber, glb_sv } from '../../../utils'

const Cash = ({ assetInfo, isTimeout, refreshStockOwn, isLoading }) => {
    const activeCodeArr = ['004']
    const { t } = useTranslation()
    const { styles } = useContext(StoreContext)

    const RowDataAsset = ({ title, value, isSubRow }) => (
        <View style={[isSubRow ? UI.rowSub : UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
            <View style={{ flexDirection: 'row', flex: 1 }}>
                <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{title}</Text>
            </View>
            <Text
                style={[
                    UI.TextRight,
                    {
                        color: styles.PRIMARY__CONTENT__COLOR,
                    },
                ]}
            >
                {value}
            </Text>
        </View>
    )
    return (
        <View style={{ flex: 1 }}>
            {isLoading ? (
                <View style={{ paddingVertical: dimensions.moderate(50) }}>
                    <ActivityIndicator color="#494949" size={30} />
                </View>
            ) : isTimeout ? (
                <ErrorView refresh={refreshStockOwn} />
            ) : (
                <View style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
                    <RowDataAsset title={t('total_cash_assets')} value={FormatNumber(assetInfo.c39)} />
                    {activeCodeArr.includes(glb_sv.activeCode) ? <RowDataAsset title={t('buy_available')} value={FormatNumber(assetInfo.c35)} /> : null}
                    <RowDataAsset title={t('amount_widthdraw')} value={FormatNumber(assetInfo.c25)} />
                    <RowDataAsset title={t('amount_blockade')} value={`${FormatNumber(assetInfo.c4) !== '0' ? '-' : ''} ${FormatNumber(assetInfo.c4)}`} />
                    <RowDataAsset title={t('cash_in_custody')} value={`${FormatNumber(assetInfo.c3) !== '0' ? '-' : ''} ${FormatNumber(assetInfo.c3)}`} />
                    <RowDataAsset title={t('cash_from_right_waitting')} value={FormatNumber(assetInfo.c9)} />

                    <RowDataAsset title={t('cash_wait_avail')} value={FormatNumber(assetInfo.c8)} />
                    {Number(assetInfo.c26) > 0 ? <RowDataAsset isSubRow title={t('cash_wait_avail') + ' T0'} value={FormatNumber(assetInfo.c26)} /> : null}
                    {Number(assetInfo.c27) > 0 ? <RowDataAsset isSubRow title={t('cash_wait_avail') + ' T1'} value={FormatNumber(assetInfo.c27)} /> : null}
                    {Number(assetInfo.c28) > 0 ? <RowDataAsset isSubRow title={t('cash_wait_avail') + ' T2'} value={FormatNumber(assetInfo.c28)} /> : null}

                    <RowDataAsset title={t('div_wait_comeback')} value={FormatNumber(assetInfo.c11)} />
                </View>
            )}
        </View>
    )
}

const UI = StyleSheet.create({
    TextRight: {
        flex: 1,
        fontSize: fontSizes.small,
        fontWeight: fontWeights.bold,
        textAlign: 'right',
    },
    row: {
        borderBottomWidth: 1,
        flexDirection: 'row',
        marginHorizontal: dimensions.moderate(16),
        paddingVertical: dimensions.vertical(9),
    },
    rowSub: {
        borderBottomWidth: 1,
        flexDirection: 'row',
        marginLeft: dimensions.moderate(32),
        marginRight: dimensions.moderate(16),
        paddingVertical: dimensions.vertical(9),
    },
})

export default memo(Cash)
