import React, { useContext, useEffect } from 'react'
import { useTranslation } from 'react-i18next'
import { NativeModules, View } from 'react-native'
import Svg, { Path } from 'react-native-svg'
import { navigate2Ekyc } from '@mts-utils/navigate2Ekyc'
import { useNavigation } from '@react-navigation/native'
import { Button, Container, Content } from 'native-base'

import { Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { dimensions as dm, fontSizes, fontSizes as fs, fontWeights } from '../../styles'
import { IOS } from '../../styles/helper/dimensions'
import { eventList, glb_sv, Screens } from '../../utils'
import HeaderComponent from '../header'

const NotAuthView = ({ wrongUser, wrongActiveCode, isBottom }) => {
    const navigation = useNavigation()
    const { styles, language, authFlag } = useContext(StoreContext)
    const { t } = useTranslation()

    const openTradingAct = () => {
        navigate2Ekyc({ IOS, NativeModules, styles })
    }

    const handleLogin = () => {
        navigation.navigate(Screens.SIGN_IN, { redirect: '' })
    }

    // userInfo.c9
    // Y: Account authentication approve by SEC
    // W: Account authentication and waiting approve
    // A: All information approved.
    // N: Account not authentication then show message from service output and if user select Y then show eKYC function if have ekyc, If don’t have ekyc then show form input account information.
    return (
        <Container>
            {isBottom ? null : <HeaderComponent colorTitle={styles.PRIMARY__CONTENT__COLOR} isShowLeft navigation={navigation} title={t('common_notify')} />}
            <Content style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
                <View
                    style={{
                        flex: 1,
                        flexDirection: 'column',
                        alignItems: 'center',
                        justifyContent: 'center',
                        height: dm.HIEGHT - 112,
                        textAlign: 'center',
                        paddingHorizontal: 42,
                    }}
                >
                    {!authFlag || !glb_sv.objShareGlb.userInfo.c9 ? (
                        <View
                            style={{
                                marginBottom: dm.moderate(100),
                            }}
                        >
                            <View style={{ textAlign: 'center', justifyContent: 'center', alignItems: 'center' }}>
                                <Svg fill="none" height="84" viewBox="0 0 43 64" width="63" xmlns="http://www.w3.org/2000/svg">
                                    <Path
                                        d="M36.9 17.1998V33.7998H32.2V17.1998C32.2 10.8998 27.4 5.7998 21.5 5.7998C15.6 5.7998 10.8 10.8998 10.8 17.2998V33.7998H6.10001V17.1998C6.10001 8.1998 13 0.799805 21.5 0.799805C30 0.799805 36.9 8.1998 36.9 17.1998Z"
                                        fill="#C7C7C7"
                                    />
                                    <Path d="M6.10001 21.5L10.8 21.7V33.8H6.10001V21.5Z" fill="#A6A6A6" />
                                    <Path d="M36.9 22.7996V33.7996H32.2V22.5996L36.9 22.7996Z" fill="#A6A6A6" />
                                    <Path d="M42.9 24.3999H0.100006V63.2999H42.9V24.3999Z" fill="#FFC727" />
                                    <Path d="M42.9 24.3999H21.5V63.2999H42.9V24.3999Z" fill="black" opacity="0.1" />
                                    <Path
                                        d="M23.3 45.1997L25.1 53.6997H17.5L19.3 45.1997C18.2 44.4997 17.5 43.2997 17.5 41.9997C17.5 39.8997 19.2 38.1997 21.3 38.1997C23.4 38.1997 25.1 39.8997 25.1 41.9997C25.1 43.3997 24.4 44.4997 23.3 45.1997Z"
                                        fill="#263238"
                                    />
                                </Svg>
                            </View>
                            <Text
                                style={{
                                    textAlign: 'center',
                                    marginTop: 20,
                                    fontSize: fs.big,
                                    fontWeight: fontWeights.medium,
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                }}
                            >
                                {t('please_login')}
                            </Text>
                            {!wrongUser && (
                                <Text style={{ textAlign: 'center', color: styles.TEXT_COLOR, fontSize: fs.small, paddingHorizontal: dm.moderate(5) }}>
                                    {t('notify_required_login')}
                                </Text>
                            )}
                            <Button
                                style={{
                                    alignSelf: 'center',
                                    marginTop: dm.vertical(36),
                                    backgroundColor: styles.PRIMARY,
                                    borderRadius: 8,
                                    paddingHorizontal: dm.moderate(50),
                                }}
                                onPress={handleLogin}
                            >
                                <Text style={{ color: '#FFF', fontSize: fontSizes.normal }}>{t('login')}</Text>
                            </Button>
                        </View>
                    ) : null}

                    {glb_sv.objShareGlb.userInfo.c9 === 'W' ? (
                        <View
                            style={{
                                marginBottom: dm.moderate(100),
                            }}
                        >
                            <View style={{ textAlign: 'center', justifyContent: 'center', alignItems: 'center' }}>
                                <Svg fill="none" height="84" viewBox="0 0 43 64" width="63" xmlns="http://www.w3.org/2000/svg">
                                    <Path
                                        d="M36.9 17.1998V33.7998H32.2V17.1998C32.2 10.8998 27.4 5.7998 21.5 5.7998C15.6 5.7998 10.8 10.8998 10.8 17.2998V33.7998H6.10001V17.1998C6.10001 8.1998 13 0.799805 21.5 0.799805C30 0.799805 36.9 8.1998 36.9 17.1998Z"
                                        fill="#C7C7C7"
                                    />
                                    <Path d="M6.10001 21.5L10.8 21.7V33.8H6.10001V21.5Z" fill="#A6A6A6" />
                                    <Path d="M36.9 22.7996V33.7996H32.2V22.5996L36.9 22.7996Z" fill="#A6A6A6" />
                                    <Path d="M42.9 24.3999H0.100006V63.2999H42.9V24.3999Z" fill="#FFC727" />
                                    <Path d="M42.9 24.3999H21.5V63.2999H42.9V24.3999Z" fill="black" opacity="0.1" />
                                    <Path
                                        d="M23.3 45.1997L25.1 53.6997H17.5L19.3 45.1997C18.2 44.4997 17.5 43.2997 17.5 41.9997C17.5 39.8997 19.2 38.1997 21.3 38.1997C23.4 38.1997 25.1 39.8997 25.1 41.9997C25.1 43.3997 24.4 44.4997 23.3 45.1997Z"
                                        fill="#263238"
                                    />
                                </Svg>
                            </View>

                            <Text
                                style={{
                                    textAlign: 'center',
                                    marginTop: 20,
                                    fontSize: fs.big,
                                    fontWeight: fontWeights.medium,
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                }}
                            >
                                {t('your_act_trading_is_pending')}
                            </Text>
                        </View>
                    ) : null}

                    {glb_sv.objShareGlb.userInfo.c9 === 'N' ? (
                        <View
                            style={{
                                marginBottom: dm.moderate(100),
                            }}
                        >
                            <View style={{ textAlign: 'center', justifyContent: 'center', alignItems: 'center' }}>
                                <Svg fill="none" height="84" viewBox="0 0 43 64" width="63" xmlns="http://www.w3.org/2000/svg">
                                    <Path
                                        d="M36.9 17.1998V33.7998H32.2V17.1998C32.2 10.8998 27.4 5.7998 21.5 5.7998C15.6 5.7998 10.8 10.8998 10.8 17.2998V33.7998H6.10001V17.1998C6.10001 8.1998 13 0.799805 21.5 0.799805C30 0.799805 36.9 8.1998 36.9 17.1998Z"
                                        fill="#C7C7C7"
                                    />
                                    <Path d="M6.10001 21.5L10.8 21.7V33.8H6.10001V21.5Z" fill="#A6A6A6" />
                                    <Path d="M36.9 22.7996V33.7996H32.2V22.5996L36.9 22.7996Z" fill="#A6A6A6" />
                                    <Path d="M42.9 24.3999H0.100006V63.2999H42.9V24.3999Z" fill="#FFC727" />
                                    <Path d="M42.9 24.3999H21.5V63.2999H42.9V24.3999Z" fill="black" opacity="0.1" />
                                    <Path
                                        d="M23.3 45.1997L25.1 53.6997H17.5L19.3 45.1997C18.2 44.4997 17.5 43.2997 17.5 41.9997C17.5 39.8997 19.2 38.1997 21.3 38.1997C23.4 38.1997 25.1 39.8997 25.1 41.9997C25.1 43.3997 24.4 44.4997 23.3 45.1997Z"
                                        fill="#263238"
                                    />
                                </Svg>
                            </View>
                            <Text
                                style={{ marginTop: 20, textAlign: 'center', color: styles.TEXT_COLOR, fontSize: fs.small, paddingHorizontal: dm.moderate(5) }}
                            >
                                {t('notify_act_not_allow_trading_please_provide_info')}
                            </Text>
                            <Button
                                style={{
                                    alignSelf: 'center',
                                    marginTop: dm.vertical(36),
                                    backgroundColor: styles.PRIMARY,
                                    borderRadius: 8,
                                    paddingHorizontal: dm.moderate(50),
                                }}
                                onPress={openTradingAct}
                            >
                                <Text style={{ color: '#FFF', fontSize: fontSizes.normal }}>{t('open_trading_account')}</Text>
                            </Button>
                        </View>
                    ) : null}
                </View>
            </Content>
        </Container>
    )
}

export default NotAuthView
