import React from 'react'
import { Image, ScrollView, StyleSheet, View } from 'react-native'
import { RNCamera } from 'react-native-camera'
import Modal from 'react-native-modal'

import ImageCamera from '../../../assets/images/common/camera.png'
import EKYC_NOTE_03 from '../../../assets/images/common/ekyc_card_corner.png'
import EKYC_NOTE_02 from '../../../assets/images/common/ekyc_card_glare.png'
import EKYC_NOTE_01 from '../../../assets/images/common/ekyc_id_card.png'
import ICON_APPROVE from '../../../assets/images/common/ic_approve.png'
import ICON_REJECT from '../../../assets/images/common/ic_reject.png'
import { Text } from '../../../basic-components'
import { ButtonCustom, ModalContent } from '../../../components/trading-component'
import { dimensions, dimensions as dm, fontSizes as fs, fontWeights as fw, IconSvg } from '../../../styles'
import { HIEGHT, WIDTH } from '../../../styles/helper/dimensions'
import EkycButton from '../components/EkycButton'

const FRAME_DETECTION = {
    center: {
        y: HIEGHT / 4 - 250 / 2,
        x: WIDTH / 2 - 200 / 2,
    },
    cameraHeight: Math.round(((WIDTH - 65) / 3) * 2.2),
}

export const StepEkyc02 = ({
    styles,
    forceUpdate,
    t,
    alertModal,
    setAlertModal,
    loading,
    uploaded,
    urlSuccess,
    takePicture,
    renderFileUri,
    cameraRef,
    listMessage,
    onRemoveImages,
    onUploadData,
    setLoading,
    switchStep,
}) => {
    return (
        <>
            <ScrollView showsVerticalScrollIndicator={false}>
                <View>
                    <View>
                        <Text style={[UI.subTitle, { color: styles.PRIMARY }]}>{t('back_id_card').toUpperCase()}</Text>
                    </View>
                    <View
                        style={{
                            backgroundColor: styles.SERVICE__BACKGROUND__WRAP,
                            paddingHorizontal: 8,
                            paddingVertical: 8,
                            marginTop: 8,
                            borderRadius: 4,
                        }}
                    >
                        <Text style={{ textAlign: 'center', fontSize: fs.verySmall, color: 'orange' }}>{t('note_back_id_card')}</Text>
                    </View>
                </View>
                <View style={UI.borderCamera}>
                    <View style={UI.cameraArea}>
                        {urlSuccess ? (
                            renderFileUri()
                        ) : (
                            <RNCamera
                                androidCameraPermissionOptions={{
                                    title: t('title_permission_camera'),
                                    message: t('msg_permission_camera'),
                                    buttonPositive: t('common_alert_agree'),
                                    buttonNegative: t('common_Cancel'),
                                }}
                                captureAudio={false}
                                defaultVideoQuality={RNCamera.Constants.VideoQuality['1080p']}
                                ref={cameraRef}
                                style={UI.camera}
                                type={RNCamera.Constants.Type.back}
                                updateTrickProps={forceUpdate}
                            />
                        )}
                    </View>
                </View>
                <View style={[UI.row, { marginTop: dm.moderate(20) }]}>
                    <View style={UI.col}>
                        <View style={[UI.noteImageWrap, { borderColor: styles.EKYC__BORDER__NOTE, backgroundColor: styles.EKYC__BACKGROUND__NOTE }]}>
                            <Image source={EKYC_NOTE_01} style={UI.image} />
                            <Image source={ICON_APPROVE} style={UI.iconFloat} />
                        </View>
                        <Text style={{ color: styles.SECOND__CONTENT__COLOR, alignItems: 'center', textAlign: 'center' }}>{t('note_valid_image')}</Text>
                    </View>
                    <View style={UI.col}>
                        <View style={[UI.noteImageWrap, { borderColor: styles.EKYC__BORDER__NOTE, backgroundColor: styles.EKYC__BACKGROUND__NOTE }]}>
                            <Image source={EKYC_NOTE_02} style={UI.image} />
                            <Image source={ICON_REJECT} style={UI.iconFloat} />
                        </View>
                        <Text style={{ color: styles.SECOND__CONTENT__COLOR, alignItems: 'center', textAlign: 'center' }}>{t('note_not_blur_glare')}</Text>
                    </View>
                    <View style={UI.col}>
                        <View style={[UI.noteImageWrap, { borderColor: styles.EKYC__BORDER__NOTE, backgroundColor: styles.EKYC__BACKGROUND__NOTE }]}>
                            <Image source={EKYC_NOTE_03} style={UI.image} />
                            <Image source={ICON_REJECT} style={UI.iconFloat} />
                        </View>
                        <Text style={{ color: styles.SECOND__CONTENT__COLOR, alignItems: 'center', textAlign: 'center' }}>{t('note_not_cut_corner')}</Text>
                    </View>
                </View>
                {listMessage?.length > 0 ? (
                    <View style={{ marginTop: 5 }}>
                        {listMessage.map((item) => (
                            <Text key={item} style={{ color: 'orange' }}>
                                - {t(item)}
                            </Text>
                        ))}
                    </View>
                ) : null}
                <View
                    style={{
                        justifyContent: 'center',
                        flexDirection: 'column',
                        alignContent: 'center',
                        alignItems: 'center',
                        marginBottom: 10,
                    }}
                >
                    {!urlSuccess ? (
                        <>
                            <ButtonCustom text="" onPress={takePicture}>
                                <View style={UI.capture}>
                                    <Image source={ImageCamera} style={{ width: 32, height: 32 }} />
                                    <Text
                                        style={{
                                            color: '#f5f5f5',
                                            fontWeight: fw.bold,
                                            fontSize: fs.normal,
                                            marginLeft: 8,
                                        }}
                                    >
                                        {t('back_id_card').toUpperCase()}
                                    </Text>
                                </View>
                            </ButtonCustom>
                        </>
                    ) : (
                        <View>
                            <ButtonCustom color={styles.INPUT__BG} text={t('take_again')} type="back" onPress={onRemoveImages} />
                            {/* {uploaded !== false ? (
                            <ButtonCustom disabled={!urlSuccess} isLoading={loading} last text={t('verify_face')} onPress={() => onUploadData(urlSuccess)} />
                        ) : null} */}
                        </View>
                    )}
                </View>
            </ScrollView>
            <View style={{ flexDirection: 'row', paddingBottom: 16 }}>
                <EkycButton
                    customStyle={{ flex: 1, marginEnd: 16 }}
                    text={t('common_button_previous')}
                    onPress={() => switchStep.prev({ step: 1, subStep: 1 })}
                />
                <EkycButton
                    customStyle={{ flex: 1 }}
                    disabled={!urlSuccess}
                    isLoading={loading}
                    showTimeoutMessage={false}
                    text={t('common_button_next')}
                    onPress={onUploadData}
                />
            </View>
            <Modal
                isVisible={alertModal}
                style={{ marginLeft: 5, marginRight: 5 }}
                useNativeDriver={true}
                onBackButtonPress={() => {
                    setAlertModal(false)
                }}
            >
                <ModalContent iconComponent={<IconSvg.ErrorIcon color={styles.ERROR__COLOR} />} title={t('notify_info')}>
                    <View
                        style={{
                            paddingHorizontal: dm.moderate(16),
                            alignItems: 'center',
                            flexDirection: 'column',
                            justifyContent: 'center',
                        }}
                    >
                        {listMessage.map((item, index) => (
                            <View
                                key={'err_' + index}
                                style={{
                                    alignItems: 'center',
                                    flexDirection: 'row',
                                    justifyContent: 'center',
                                    paddingVertical: dm.moderate(4),
                                }}
                            >
                                <Text style={{ flex: 1, marginLeft: dm.moderate(6), fontSize: fs.normal, color: styles.PRIMARY__CONTENT__COLOR }}>
                                    {t(item)}
                                </Text>
                            </View>
                        ))}
                    </View>
                    <ButtonCustom
                        text={t('common_alert_agree')}
                        type="confirm"
                        onPress={() => {
                            setAlertModal(false)
                        }}
                    />
                </ModalContent>
            </Modal>
            {/* <Spinner visible={loading} /> */}
        </>
    )
}

const UI = StyleSheet.create({
    borderCamera: {
        // working
        marginTop: 10,
        padding: 10,
        borderWidth: 2,
        borderRadius: 5,
        borderColor: 'green',
        height: 'auto',
    },
    camera: {
        // working
        justifyContent: 'flex-end',
        alignItems: 'center',
        flexGrow: 1,
    },
    cameraArea: {
        // working
        height: FRAME_DETECTION.cameraHeight,
        // width: WIDTH - 65,
        borderRadius: 5,
        overflow: 'hidden',
    },
    capture: {
        alignItems: 'center',
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
    },
    col: {
        marginHorizontal: dm.moderate(8),
        width: '30%',
    },
    container: {
        alignContent: 'space-between',
        flex: 1,
        height: HIEGHT - 200,
        justifyContent: 'space-between',
        marginLeft: 20,
        marginRight: 20,
    },
    iconFloat: {
        height: 25,
        position: 'absolute',
        right: -15,
        top: -15,
        width: 25,
    },
    image: {
        alignContent: 'flex-start',
        alignItems: 'center',
        aspectRatio: 4 / 3,
        borderRadius: 0,
        height: 'auto',
        justifyContent: 'flex-start',
        resizeMode: 'contain',
        width: '100%',
    },
    noteImageWrap: {
        borderRadius: 10,
        borderWidth: 2,
        marginBottom: dm.moderate(8),
        padding: '8%',
        position: 'relative',
    },
    row: {
        alignContent: 'space-between',
        alignItems: 'flex-start',
        flexDirection: 'row',
        justifyContent: 'space-evenly',
        marginLeft: dm.moderate(4),
        marginRight: dm.moderate(8),
        marginTop: dm.vertical(12),
    },
    subTitle: { fontSize: fs.xmedium, fontWeight: fw.bold, marginBottom: 16, textAlign: 'center' },
    wrap: { flexDirection: 'column', justifyContent: 'center', paddingHorizontal: dimensions.moderate(16) },
})
