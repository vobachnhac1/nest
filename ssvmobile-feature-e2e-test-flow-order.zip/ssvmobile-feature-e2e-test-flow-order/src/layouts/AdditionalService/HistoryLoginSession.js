import React, { useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { ActivityIndicator, FlatList, Pressable, RefreshControl, StyleSheet, View } from 'react-native'
import DateTimePickerModal from 'react-native-modal-datetime-picker'
import AntDesign from 'react-native-vector-icons/AntDesign'
import Ionicons from 'react-native-vector-icons/Ionicons'
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons'
import moment from 'moment'
import { Col, Container, Content, Icon, Row } from 'native-base'

import IconCalendar from '../../assets/images/common/calendar.svg'
import { CustomFloatInput, Text } from '../../basic-components'
import HeaderComponent from '../../components/header'
import { EmptyView, RowTitleGroup } from '../../components/trading-component'
import { useLoading } from '../../hoc'
import { StoreContext } from '../../store'
import { dimensions as dm, fontSizes as fs } from '../../styles'
import { glb_sv, reqFunct, sendRequest, wait } from '../../utils'

const ServiceInfo = {
    GET_LOGIN_SESSION: {
        reqFunct: reqFunct.GET_LOGIN_SESSION,
        WorkerName: 'FOSqID02',
        ServiceName: 'FOSqID02_LoginSession',
        Operation: 'Q',
    },
}

function HistoryLoginSession({ navigation }) {
    const { styles, language, theme } = useContext(StoreContext)
    const { t } = useTranslation()

    const [sessionHistory, setSessionHistory] = useState([])
    const [fromDt, setFromDt] = useState(moment()?.subtract(7, 'day')?.toDate())
    const [toDt, setToDt] = useState(moment()?.toDate())
    const [isViewToday, setIsViewToday] = useState(true)

    const [isDatePickerFrom, setisDatePickerFrom] = useState(false)
    const [isDatePickerTo, setisDatePickerTo] = useState(false)
    const [loading, setLoading] = useLoading(false)

    useEffect(() => {
        getLoginSessionHistory()
    }, [toDt, fromDt])

    const getLoginSessionHistory = () => {
        setSessionHistory([])
        const InputParams = ['history', moment(fromDt).format('YYYYMMDD'), moment(toDt).format('YYYYMMDD')] //toDt?.format('YYYYMMDD')
        sendRequest(ServiceInfo.GET_LOGIN_SESSION, InputParams, getLoginSessionHistoryResult)
        setLoading(true)
    }

    const getLoginSessionHistoryResult = (reqInfoMap, message) => {
        setLoading(false)
        // console.log('getLoginSessionHistoryResult -> message', message)
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata
            if (!message.Data) return
            try {
                jsondata = JSON.parse(message.Data)
                setSessionHistory(jsondata.sort((a, b) => moment(a.c2, 'YYYYMMDDHHmmss').valueOf() - moment(b.c2, 'YYYYMMDDHHmmss').valueOf()))
            } catch (err) {
                console.log('getLoginSessionHistoryResult -> err', err)
                return
            }
        }
    }

    const IconDevicesFactory = (type = '', color) => {
        if (type === 'Web') {
            return <MaterialCommunityIcons name="web" size={20} style={{ color: color || styles.PRIMARY__CONTENT__COLOR, paddingRight: 4 }} />
        }
        if (type.toLocaleLowerCase() === 'android' || type.toLocaleUpperCase() === 'IOS') {
            return <Ionicons name="phone-portrait-outline" size={20} style={{ color: color || styles.PRIMARY__CONTENT__COLOR, paddingRight: 4 }} />
        }
        if (type === 'Home') {
            return <AntDesign name="iconfontdesktop" size={20} style={{ color: color || styles.PRIMARY__CONTENT__COLOR, paddingRight: 4 }} />
        }
        return <View />
    }

    const OnlineStatus = () => {
        return (
            <View style={[UI.Row, { justifyContent: 'center', alignItems: 'center' }]}>
                <View>
                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fs.small, fontStyle: 'italic', textAlignVertical: 'center' }}>
                        {t('online_status')}
                    </Text>
                </View>
                <View style={{ margin: 4, backgroundColor: styles.UP__COLOR, width: 8, height: 8, borderRadius: 10 }} />
            </View>
        )
    }

    const RowInfo = ({ item }) => {
        // console.log('RowInfo', item, moment(item.c2, 'YYYYMMDDHHmmss').valueOf())
        return (
            <>
                <View style={[UI.Group, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                    <View style={[UI.Row]}>
                        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                            {IconDevicesFactory(item.c5, styles.PRIMARY__CONTENT__COLOR)}
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fs.medium, fontWeight: 'bold' }}>
                                {item.c5}
                                {item.c6 ? ` (v${item.c6})` : ''}
                            </Text>
                        </View>
                        {!item.c3?.trim() ? <OnlineStatus /> : null}
                    </View>
                    <View style={[UI.Row]}>
                        <View>
                            <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fs.normal }}>{t('connection_time')}</Text>
                        </View>
                        <View>
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fs.normal }}>
                                {moment(item.c2, 'YYYYMMDDHHmmss').format('DD-MM-YYYY HH:mm:ss')}
                            </Text>
                        </View>
                    </View>
                    {item.c3?.trim() ? (
                        <View style={[UI.Row]}>
                            <View>
                                <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fs.normal }}>{t('disconnection_time')}</Text>
                            </View>
                            <View>
                                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fs.normal }}>
                                    {moment(item.c3, 'YYYYMMDDHHmmss').format('DD-MM-YYYY HH:mm:ss')}
                                </Text>
                            </View>
                        </View>
                    ) : null}
                    <View style={[UI.Row]}>
                        <View>
                            <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fs.normal }}>{t('IP Adresss')}</Text>
                        </View>
                        <View>
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fs.normal }}>{item.c8}</Text>
                        </View>
                    </View>
                    {item.c10?.trim() ? (
                        <>
                            <View style={[UI.Row]}>
                                <View>
                                    <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fs.normal }}>{t('device_info')}</Text>
                                </View>
                            </View>
                            <View style={[UI.Row]}>
                                <View>
                                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fs.normal }}>{item.c10}</Text>
                                </View>
                            </View>
                        </>
                    ) : null}
                </View>
            </>
        )
    }
    const hideDatePicker = () => {
        setisDatePickerFrom(false)
        setisDatePickerTo(false)
    }
    const onRefresh = React.useCallback(() => {
        setLoading(true)
        getLoginSessionHistory()
        wait(300).then(() => setLoading(false))
    }, [fromDt, toDt])

    return (
        <Container>
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft={true}
                navigation={navigation}
                title={t('history_login')}
                titleAlgin="flex-start"
            />

            <Content
                keyboardShouldPersistTaps="handled"
                refreshControl={
                    <RefreshControl
                        refreshing={loading}
                        tintColor={styles.PRIMARY__CONTENT__COLOR}
                        onRefresh={onRefresh} // title={t('pull_refresh')}
                    />
                }
                showsVerticalScrollIndicator={false}
                style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}
            >
                <View style={UI.GroupFilter}>
                    <Row>
                        <Col size={12}>
                            <Pressable onPress={() => setisDatePickerFrom(true)}>
                                <View pointerEvents="none" style={UI.RowFilter}>
                                    <CustomFloatInput
                                        label={t('common_from_date')}
                                        rightComponent={
                                            <IconCalendar fill={styles.PRIMARY__CONTENT__COLOR} style={{ marginVertical: dm.vertical(20), marginRight: 5 }} />
                                        }
                                        staticLabel
                                        value={moment(fromDt).format('DD/MM/YYYY')}
                                    />
                                </View>
                            </Pressable>
                        </Col>
                        <Col size={12}>
                            <Pressable onPress={() => setisDatePickerTo(true)}>
                                <View pointerEvents="none" style={UI.RowFilter}>
                                    <CustomFloatInput
                                        label={t('common_to_date')}
                                        rightComponent={
                                            <IconCalendar fill={styles.PRIMARY__CONTENT__COLOR} style={{ marginVertical: dm.vertical(20), marginRight: 5 }} />
                                        }
                                        staticLabel
                                        value={moment(toDt).format('DD/MM/YYYY')}
                                    />
                                </View>
                            </Pressable>
                        </Col>
                    </Row>
                </View>
                {/* <View style={{ flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }}>
                    <TouchableOpacity onPress={() => setIsViewToday(false)}>
                        <View
                            style={{
                                paddingHorizontal: 16,
                                paddingVertical: 4,
                                backgroundColor: isViewToday ? styles.BUTTON__SECONDARY : styles.PRIMARY,
                                borderRadius: 10,
                                marginRight: 12,
                            }}>
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontWeight: fw.bold, fontSize: fs.normal }}>{t('Today')}</Text>
                        </View>
                    </TouchableOpacity>
                    <TouchableOpacity onPress={() => setIsViewToday(true)}>
                        <View
                            style={{
                                paddingHorizontal: 16,
                                paddingVertical: 4,
                                backgroundColor: !isViewToday ? styles.BUTTON__SECONDARY : styles.PRIMARY,
                                borderRadius: 10,
                                marginRight: 12,
                            }}>
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontWeight: fw.bold, fontSize: fs.normal }}>{t('History ')}</Text>
                        </View>
                    </TouchableOpacity>
                </View> */}
                <FlatList
                    data={sessionHistory}
                    inverted={true}
                    keyExtractor={(item, index) => moment(item.c2, 'YYYYMMDDHHmmss').valueOf()}
                    ListEmptyComponent={EmptyView}
                    renderItem={RowInfo}
                    style={{ marginBottom: dm.vertical(32), marginHorizontal: dm.moderate(16), marginTop: dm.vertical(16) }}
                />
            </Content>

            {isDatePickerFrom ? (
                <DateTimePickerModal
                    cancelTextIOS={t('common_Cancel')}
                    confirmTextIOS={t('common_Ok')}
                    date={fromDt}
                    headerTextIOS=""
                    isDarkModeEnabled={theme.includes('DARK')}
                    isVisible={isDatePickerFrom}
                    locale={language === 'VI' ? 'vi_VN' : 'en_US'}
                    mode="date"
                    onCancel={hideDatePicker}
                    onConfirm={(value) => {
                        setisDatePickerFrom(false)
                        setFromDt(value)
                    }}
                />
            ) : null}

            {isDatePickerTo ? (
                <DateTimePickerModal
                    cancelTextIOS={t('common_Cancel')}
                    confirmTextIOS={t('common_Ok')}
                    date={toDt}
                    headerTextIOS=""
                    isDarkModeEnabled={theme.includes('DARK')}
                    isVisible={isDatePickerTo}
                    locale={language === 'VI' ? 'vi_VN' : 'en_US'}
                    mode="date"
                    onCancel={hideDatePicker}
                    onConfirm={(value) => {
                        setisDatePickerTo(false)
                        setToDt(value)
                    }}
                />
            ) : null}
        </Container>
    )
}

const UI = StyleSheet.create({
    Group: {
        borderBottomWidth: 1,
        marginBottom: dm.vertical(16),
        paddingBottom: dm.vertical(8),
    },
    GroupFilter: {
        flex: 1,
        marginHorizontal: dm.moderate(8),
        marginVertical: dm.vertical(4),
    },
    Row: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingBottom: 4,
    },
    RowFilter: {
        marginHorizontal: dm.moderate(4),
        marginVertical: dm.vertical(8),
    },
    RowLeft: {},
    RowRight: {},
})

export default HistoryLoginSession
