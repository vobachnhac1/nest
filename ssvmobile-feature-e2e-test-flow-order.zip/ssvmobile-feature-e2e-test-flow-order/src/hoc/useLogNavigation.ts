import React from 'react'
import { NavigationContainerRef } from '@react-navigation/native'

/**
 * Hàm có tác dụng: log current navigation when change screen
 */

const getActiveRouteName = (state) => {
    const route = state.routes[state.index]
    if (route?.state) {
        return getActiveRouteName(route.state)
    }
    console.log('🖥🚀🖥🚀🖥🚀🖥🚀🖥🚀🖥🚀🖥🚀', route)

    return route.name
}

const useLogNavigation = (): { onStateChange: (state) => void; navigationRef: React.RefObject<NavigationContainerRef> } => {
    const routeNameRef = React.useRef(null)
    const navigationRef = React.useRef<NavigationContainerRef>(null)

    React.useEffect(() => {
        const state = navigationRef?.current?.getRootState()
        routeNameRef.current = getActiveRouteName(state)
    }, [])

    const onStateChange = (state) => {
        const currentRouteName = getActiveRouteName(state)

        routeNameRef.current = currentRouteName
    }

    return { onStateChange, navigationRef }
}

export default useLogNavigation
