import React, { useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { StyleSheet, TouchableOpacity, View } from 'react-native'
import Modal from 'react-native-modal'
import { RadioButton } from 'react-native-paper'
import RenderHTML from 'react-native-render-html'
import { Radio } from 'native-base'

import { Text } from '../../../basic-components'
import { ButtonCustom, ModalContent } from '../../../components/trading-component'
import { StoreContext } from '../../../store'
import { dimensions, dimensions as dm, fontSizes, fontSizes as fs, fontWeights, IconSvg } from '../../../styles'

interface IFATCAInfomationProps {
    setCheckFATCA: (value: '0' | '1' | '2') => void
    checkFATCA: '0' | '1' | '2'
}

export const FATCAInfomation = ({ setCheckFATCA = (fatca: '0' | '1' | '2') => null, checkFATCA }: IFATCAInfomationProps) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()
    const [FATCAValue, setFATCAValue] = useState<'0' | '1' | '2'>(checkFATCA)
    const [modalDetailsFATCA, setModalDetailsFATCA] = useState(false)

    useEffect(() => {
        setCheckFATCA(FATCAValue)
    }, [FATCAValue])
    const escapeHtml = (text: string): string => {
        return text
            .replace(/&amp;/g, '&')
            .replace(/&lt;/g, '<')
            .replace(/&gt;/g, '>')
            .replace(/&quot/g, '"')
            .replace(/&#039;/g, "'")
    }

    return (
        <>
            <View style={[UI.row]}>
                <View>
                    <TouchableOpacity onPress={() => setModalDetailsFATCA(true)}>
                        <Text style={{ color: styles.EKYC__ROYAL__BLUE, marginVertical: 16, textAlign: 'left', fontSize: 18 }}>
                            {t<string>('ekyc_fatca_title').toUpperCase()}
                            <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontStyle: 'italic', marginLeft: 8 }}> ({t<string>('common_Detail')})</Text>
                        </Text>
                    </TouchableOpacity>
                </View>
                <View style={UI.option}>
                    <TouchableOpacity onPress={() => setFATCAValue('0')}>
                        <IconSvg.RadioButtonIcon active={FATCAValue === '0'} colorActive={styles.PRIMARY} colorunActive={styles.SECOND__CONTENT__COLOR} />
                    </TouchableOpacity>
                    <TouchableOpacity onPress={() => setFATCAValue('0')}>
                        <RenderHTML
                            baseStyle={{
                                fontSize: fontSizes.normal,
                                color: styles.EKYC__SILVER,
                                overflow: 'visible',
                                textAlign: 'justify',
                                marginLeft: 8,
                                marginRight: 8,
                            }}
                            source={{
                                html: escapeHtml(t<string>('ekyc_fatca_option_01') || ''),
                            }}
                        />
                    </TouchableOpacity>
                </View>
                <View style={UI.option}>
                    <TouchableOpacity onPress={() => setFATCAValue('1')}>
                        <IconSvg.RadioButtonIcon active={FATCAValue === '1'} colorActive={styles.PRIMARY} colorunActive={styles.SECOND__CONTENT__COLOR} />
                    </TouchableOpacity>
                    <TouchableOpacity onPress={() => setFATCAValue('1')}>
                        <RenderHTML
                            baseStyle={{
                                fontSize: fontSizes.normal,
                                color: styles.EKYC__SILVER,
                                overflow: 'visible',
                                textAlign: 'justify',
                                marginLeft: 8,
                                marginRight: 8,
                            }}
                            source={{
                                html: escapeHtml(t<string>('ekyc_fatca_option_02') || ''),
                            }}
                        />
                    </TouchableOpacity>
                </View>
                <View style={UI.option}>
                    <TouchableOpacity onPress={() => setFATCAValue('2')}>
                        <IconSvg.RadioButtonIcon active={FATCAValue === '2'} colorActive={styles.PRIMARY} colorunActive={styles.SECOND__CONTENT__COLOR} />
                    </TouchableOpacity>
                    <TouchableOpacity onPress={() => setFATCAValue('2')}>
                        <RenderHTML
                            baseStyle={{
                                fontSize: fontSizes.normal,
                                color: styles.EKYC__NOTE__C,
                                overflow: 'visible',
                                textAlign: 'justify',
                                marginLeft: 8,
                                marginRight: 8,
                            }}
                            source={{
                                html: escapeHtml(t<string>('ekyc_fatca_option_03') || ''),
                            }}
                        />
                    </TouchableOpacity>
                </View>
            </View>
            <Modal
                hideModalContentWhileAnimating
                isVisible={modalDetailsFATCA}
                style={{ marginLeft: 5, marginRight: 5 }}
                useNativeDriver={true}
                onBackButtonPress={() => {
                    setModalDetailsFATCA(false)
                }}
            >
                <ModalContent iconComponent={null} title={t('')}>
                    <View
                        style={{
                            paddingHorizontal: dm.moderate(16),
                            alignItems: 'center',
                            flexDirection: 'column',
                            justifyContent: 'center',
                        }}
                    >
                        <View
                            style={{
                                alignItems: 'center',
                                flexDirection: 'row',
                                justifyContent: 'center',
                                paddingVertical: dm.moderate(4),
                            }}
                        >
                            <Text
                                style={{
                                    flex: 1,
                                    marginLeft: dm.moderate(6),
                                    fontSize: fs.normal,
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                    textAlign: 'justify',
                                }}
                            >
                                {t<string>('ekyc_fatca_note_01')}
                            </Text>
                        </View>
                        <View
                            style={{
                                alignItems: 'center',
                                flexDirection: 'row',
                                justifyContent: 'center',
                                paddingVertical: dm.moderate(4),
                            }}
                        >
                            <Text
                                style={{
                                    flex: 1,
                                    marginLeft: dm.moderate(6),
                                    fontSize: fs.normal,
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                    textAlign: 'justify',
                                }}
                            >
                                {t<string>('ekyc_fatca_note_02')}
                            </Text>
                        </View>
                    </View>
                    <ButtonCustom
                        text={t('common_alert_agree')}
                        type="confirm"
                        onPress={() => {
                            setModalDetailsFATCA(false)
                        }}
                    />
                </ModalContent>
            </Modal>
        </>
    )
}

const UI = StyleSheet.create({
    option: {
        alignItems: 'flex-start',
        alignSelf: 'flex-start',
        flex: 1,
        flexDirection: 'row',
        marginBottom: 16,
        paddingRight: dimensions.moderate(16),
    },
    row: {
        alignItems: 'center',
        borderRadius: 12,
        flexDirection: 'column',
        marginHorizontal: dm.moderate(16),
    },
})
