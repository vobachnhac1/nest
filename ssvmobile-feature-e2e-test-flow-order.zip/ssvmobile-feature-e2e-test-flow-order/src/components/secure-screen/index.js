import React, { useContext, useEffect, useRef, useState } from 'react'
import { AppState, Image, InteractionManager, StyleSheet, View } from 'react-native'
import Modal from 'react-native-modal'

import { Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { fontSizes } from '../../styles'
import { HIEGHT, IOS, WIDTH } from '../../styles/helper/dimensions'
import { eventList, glb_sv, IMAGE } from '../../utils'

const showSecurityScreenFromAppState = (appState) => ['background', 'inactive'].includes(appState)

export default function SecureScreen() {
    // -------------
    const activeCodeArr = ['081']

    const { styles, activeCode, language, theme, imageTheme } = useContext(StoreContext)

    const [isVisible, setVisible] = useState(false)
    const handleInteraction = useRef(null)
    const forceVisible = useRef(false)

    useEffect(() => {
        if (IOS) {
            AppState.addEventListener('change', handleAppStateChange)
            const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
                if (msg.type === eventList.AUTHEN_BIOMETRIC) {
                    forceVisible.current = msg.isShow
                }
            })
            return () => {
                AppState.removeEventListener('change', handleAppStateChange)
                commonEvent.unsubscribe()
            }
        }
    }, [])

    const handleAppStateChange = (nextAppState) => {
        if (forceVisible.current) return
        const showSecurityScreen = showSecurityScreenFromAppState(nextAppState)
        handleInteraction.current?.cancel()
        handleInteraction.current = InteractionManager.runAfterInteractions(() => {
            setTimeout(() => {
                setVisible(showSecurityScreen)
            }, 0)
        })
    }

    return (
        <>
            {isVisible && IOS && (
                <Modal
                    animationIn="fadeIn"
                    animationInTiming={100}
                    animationOut="fadeOut"
                    animationOutTiming={100}
                    coverScreen={true}
                    hideModalContentWhileAnimating={true}
                    isVisible={isVisible}
                    style={UI.modal}
                    useNativeDriver={true}
                    useNativeDriverForBackdrop={true}
                >
                    <View style={{ flex: 1, backgroundColor: theme === 'DARK' ? '#000' : '#FFF' }} />
                    {/* <View style={{ flex: 1, backgroundColor: styles.PRIMARY__BG__COLOR }}>
                {activeCodeArr.includes(glb_sv.activeCode) ? (
                    <View
                        style={{
                            flex: 1,
                            justifyContent: 'center',
                            alignItems: 'center',
                        }}>
                        <Image
                            source={
                                theme === 'DARK'
                                    ? require('../../assets/images/logo/081_splash_logo.png')
                                    : require('../../assets/images/logo/081_splash_logo_grey.png')
                            }
                            resizeMode="contain"
                            style={{
                                width: 300,
                                height: 200,
                            }}
                        />
                    </View>
                ) : (
                    <View
                        style={{
                            flex: 1,
                            justifyContent: 'center',
                            alignItems: 'center',
                        }}>
                        <Image
                            source={imageTheme.LOGO}
                            resizeMode="contain"
                            style={{
                                width: 300,
                                height: 200,
                            }}
                        />

                        <Text style={{ fontSize: fontSizes.medium, color: styles.PRIMARY__CONTENT__COLOR }}>{glb_sv.configInfo.logo_text}</Text>
                    </View>
                )}

                <Text style={{ fontSize: fontSizes.verySmall, color: styles.FOURTH__CONTENT__COLOR, textAlign: 'center', marginBottom: 30 }}>
                    {language === 'VI'
                        ? glb_sv.configInfo.copyright
                        : language === 'CN' || language === 'ZH'
                        ? glb_sv.configInfo.copyright_cn
                        : glb_sv.configInfo.copyright_e}
                </Text>
            </View> */}
                </Modal>
            )}
        </>
    )
}

const UI = StyleSheet.create({
    modal: {
        margin: 0,
    },
    view_in_top: {
        ...StyleSheet.absoluteFill,
        height: HIEGHT + 20,
        width: WIDTH,
    },
})
