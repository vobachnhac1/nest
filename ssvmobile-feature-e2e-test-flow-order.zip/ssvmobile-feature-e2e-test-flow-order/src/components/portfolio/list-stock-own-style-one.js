/* eslint-disable no-restricted-syntax */
import React, { memo, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Dimensions, InteractionManager, Pressable, ScrollView, StyleSheet, TouchableOpacity, View } from 'react-native'
import Orientation from 'react-native-orientation-locker'
import ModalController from '@mts-components/appModal/modalControlller'
import allowCompanyRender from '@mts-hooks/allow-company-render'
import { COLORS } from '@mts-styles/colors'
import { useNavigation } from '@react-navigation/native'
import { Button } from 'native-base'

import { StyledText, StyledView, Text } from '../../basic-components'
import { ModalAddFav, ModalDeleteFav, ModalEditNameFav } from '../../components/portfolio'
import { StoreContext } from '../../store'
import { dimensions, fontSizes, fontWeights, IconSvg } from '../../styles'
import { FormatNumber, glb_sv, Screens } from '../../utils'
import { SparklinesChart, SparklinesChartMulti } from '../victory-chart'
import GmailStyleSwipeableRow from './GmailStyleSwipeableRow'
import HeaderOfList from './header-of-list'
import ModalManageList from './modal-fav-manage'

const { width } = Dimensions.get('window')
const isFiveColumn = width > 600 && width < 910
const isSevenColumn = width > 910

export const HeaderView = memo(({ c1, c2, type, ListStock, sort, changeTypeSort, onChangePriceboard }) => {
    const { styles } = useContext(StoreContext)
    if (!c1) return null
    return (
        <>
            <View style={UI.header}>
                <View style={UI.headerLeft}>
                    <Text numberOfLines={1} style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.medium, fontWeight: fontWeights.semiBold }}>
                        {c2}
                    </Text>
                </View>
                <View style={UI.row}>
                    {ListStock.length ? (
                        <TouchableOpacity style={{ marginRight: dimensions.moderate(12) }} onPress={onChangePriceboard}>
                            <IconSvg.IconPhoneRotate BUTTON__SECONDARY={styles.BUTTON__SECONDARY} ICON__PRIMARY={styles.ICON__PRIMARY} />
                        </TouchableOpacity>
                    ) : null}
                </View>
            </View>

            <HeaderOfList changeTypeSort={changeTypeSort} sort={sort} type={type} />
        </>
    )
})

export const HeaderWatchlistMarket = memo(({ allListFav, activeList, changeActiveList, sort, changeTypeSort, addNewStock }) => {
    const { styles } = useContext(StoreContext)
    const navigation = useNavigation()
    const { t } = useTranslation()

    const [visibleModalManageList, setVisibleModalManageList] = useState(false)
    const [visibleAddModal, setVisibleAddModal] = useState(false)
    const [visibleEditModal, setVisibleEditModal] = useState(false)
    const [visibleDeleteModal, setVisibleDeleteModal] = useState(false)

    const scrolviewRef = useRef(null)

    useEffect(() => {
        InteractionManager.runAfterInteractions(() => {
            scrolviewRef.current?.scrollTo({
                animated: true,
                x: 0,
            })
        })
    }, [allListFav, activeList])

    const changeSearchScreen = useCallback(() => {
        navigation.navigate(Screens.SEARCH_STOCK, { actionType: 'FAV_ACTION' })
    }, [])

    const onChangePriceboard = useCallback(() => {
        const listDataSub = glb_sv.activeList.ListStock.map((e) => glb_sv.StockMarket[e] || { t55: e })
        if (listDataSub.length) {
            Orientation.lockToLandscapeRight()
            navigation.navigate(Screens.PRICEBOARD, { list: listDataSub })
        }
    }, [])

    return (
        <>
            <View style={[UI.row, { backgroundColor: styles.PRIMARY__BG__COLOR, paddingHorizontal: dimensions.moderate(12) }]}>
                <ScrollView horizontal ref={scrolviewRef}>
                    {allListFav.map((item) => (
                        <Pressable key={item.c1} onPress={() => changeActiveList(item)}>
                            <StyledView
                                backgroundColor={styles.BUTTON__SECONDARY}
                                borderColor={activeList.c1 === item.c1 ? styles.PRIMARY : styles.BUTTON__SECONDARY}
                                borderRadius={8}
                                borderWidth={StyleSheet.hairlineWidth}
                                marginRight={5}
                                paddingBottom={8}
                                paddingLeft={8}
                                paddingRight={8}
                                paddingTop={8}
                            >
                                <StyledText color={activeList.c1 === item.c1 ? styles.PRIMARY : styles.PRIMARY__CONTENT__COLOR}>
                                    {item.c2 === 'own_stock_list' ? t('own_stock_list') : item.c2}
                                </StyledText>
                            </StyledView>
                        </Pressable>
                    ))}
                </ScrollView>

                <TouchableOpacity style={{ paddingLeft: 8 }} onPress={() => setVisibleModalManageList(true)}>
                    <IconSvg.IconThreeDotHorizontal BUTTON__SECONDARY={styles.BUTTON__SECONDARY} ICON__PRIMARY={styles.ICON__PRIMARY} />
                </TouchableOpacity>
            </View>

            <View style={{ paddingHorizontal: dimensions.moderate(12) }}>
                {activeList.ListStock?.length ? (
                    <HeaderOfList changeTypeSort={changeTypeSort} noPadding={true} sort={sort} type={activeList.type} />
                ) : (
                    <EmptyWatchlistView activeList={activeList} addNewStock={addNewStock} />
                )}
            </View>

            {visibleAddModal && <ModalAddFav isModalVisible={visibleAddModal} navigation={navigation} setModal={setVisibleAddModal} styles={styles} />}
            {visibleEditModal && <ModalEditNameFav isModalVisible={visibleEditModal} navigation={navigation} setModal={setVisibleEditModal} styles={styles} />}
            {visibleDeleteModal && (
                <ModalDeleteFav isModalVisible={visibleDeleteModal} navigation={navigation} setModal={setVisibleDeleteModal} styles={styles} />
            )}
            <ModalManageList
                changeSearchScreen={changeSearchScreen}
                navigation={navigation}
                setVisibleAddModal={setVisibleAddModal}
                setVisibleDeleteModal={setVisibleDeleteModal}
                setVisibleEditModal={setVisibleEditModal}
                setVisibleModalManageList={setVisibleModalManageList}
                visibleModalManageList={visibleModalManageList}
                onChangePriceboard={onChangePriceboard}
            />
        </>
    )
})

export const StockItem = memo(({ t55, onRemoveStock, isShowSwipe, iDItemFav, isOddlot }) => {
    const navigation = useNavigation()
    const stockInfo = glb_sv.StockMarket[t55] || {}
    const { styles, fractionPrice } = useContext(StoreContext)
    const { t } = useTranslation()

    const renderT31 = () => {
        if (isOddlot) {
            return fractionPrice
                ? FormatNumber((stockInfo.t31_PO || stockInfo.t260) / 1000, 2, 0, '---')
                : FormatNumber(stockInfo.t31_PO || stockInfo.t260, 0, 0, '---')
        } else {
            return fractionPrice
                ? FormatNumber((stockInfo.t31 || stockInfo.t260) / 1000, 2, 0, '---')
                : FormatNumber(stockInfo.t31 || stockInfo.t260, 0, 0, '---')
        }
    }

    const renderT31Incr = () => {
        if (isOddlot) {
            return stockInfo.t31_PO
                ? (stockInfo.t31_incr_PO > 0 ? '+' : '') +
                (fractionPrice ? FormatNumber(stockInfo.t31_incr_PO / 1000, 2) : FormatNumber(stockInfo.t31_incr_PO)) +
                ' ' +
                (stockInfo.t31_incr_per_PO > 0 ? '+' : '') +
                (FormatNumber(stockInfo.t31_incr_per_PO, 2) + '%')
                : '---  ---'
        } else {
            return stockInfo.t31
                ? (stockInfo.t31_incr > 0 ? '+' : '') +
                (fractionPrice ? FormatNumber(stockInfo.t31_incr / 1000, 2) : FormatNumber(stockInfo.t31_incr)) +
                ' ' +
                (stockInfo.t31_incr_per > 0 ? '+' : '') +
                (FormatNumber(stockInfo.t31_incr_per, 2) + '%')
                : '---  ---'
        }
    }

    const TouchView = {
        flex: 1,
        flexDirection: 'row',
        borderBottomColor: styles.DIVIDER__COLOR,
        backgroundColor: styles.PRIMARY__BG__COLOR,
        alignItems: 'center',
        paddingHorizontal: dimensions.moderate(12),
        marginBottom: dimensions.moderate(12),
    }

    const TouchViewNotSwipe = {
        flex: 1,
        flexDirection: 'row',
        borderBottomColor: styles.DIVIDER__COLOR,
        backgroundColor: styles.PRIMARY__BG__COLOR,
        alignItems: 'center',
        paddingHorizontal: dimensions.moderate(12),
        marginVertical: 10,
    }

    const TextT55 = { color: glb_sv.getColor(stockInfo.t31, stockInfo, styles, 't31'), fontWeight: fontWeights.medium, fontSize: fontSizes.small }

    const TextTU9 = { color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.smallest }

    const ViewT31 = useMemo(
        () => StyleSheet.flatten([{ backgroundColor: glb_sv.getColor(stockInfo.t31, stockInfo, styles, 't31'), width: '100%', borderRadius: 4, padding: 5 }]),
        [styles, glb_sv.getColor(stockInfo.t31, stockInfo, styles, 't31')],
    )

    const TextT31Ratio = useMemo(
        () =>
            StyleSheet.flatten([
                {
                    color: glb_sv.getColor(stockInfo.t31, stockInfo, styles),
                    fontSize: fontSizes.smallest,
                    fontWeight: fontWeights.semiBold,
                    textAlign: 'center',
                },
            ]),
        [styles, glb_sv.getColor(stockInfo.t31, stockInfo, styles, 't31')],
    )

    const TextT55Oddlot = useMemo(
        () =>
            StyleSheet.flatten([
                { color: glb_sv.getColor(stockInfo.t31_PO, stockInfo, styles, 't31_PO'), fontWeight: fontWeights.medium, fontSize: fontSizes.small },
            ]),
        [styles, glb_sv.getColor(stockInfo.t31_PO, stockInfo, styles, 't31_PO')],
    )

    const ViewT31Oddlot = useMemo(
        () =>
            StyleSheet.flatten([
                { backgroundColor: glb_sv.getColor(stockInfo.t31_PO, stockInfo, styles, 't31_PO'), width: '100%', borderRadius: 4, padding: 5 },
            ]),
        [styles, glb_sv.getColor(stockInfo.t31_PO, stockInfo, styles, 't31_PO')],
    )

    const TextT31RatioOddlot = useMemo(
        () =>
            StyleSheet.flatten([
                {
                    color: glb_sv.getColor(stockInfo.t31_PO, stockInfo, styles),
                    fontSize: fontSizes.smallest,
                    fontWeight: fontWeights.semiBold,
                    textAlign: 'center',
                },
            ]),
        [styles, glb_sv.getColor(stockInfo.t31_PO, stockInfo, styles, 't31_PO')],
    )

    const onPressDetail = () => {
        navigation.navigate(Screens.STOCK_INFO, { stockCode: t55 })
    }

    if (isShowSwipe) {
        if (allowCompanyRender(['081', '888'])) {
            return (
                <Pressable
                    style={TouchView}
                    onLongPress={
                        () =>
                            ModalController.showModal({
                                icon: <IconSvg.DeleteIcon color={styles.WARN__COLOR} />,
                                content: t('delete_stock_item_des'),
                                typeColor: styles.WARN__COLOR,
                                showCancel: true,
                                linkCallback: () => {
                                    onRemoveStock(t55)
                                },
                            })

                        // navigation.navigate(Screens.ALERT_MODAL, {
                        // icon: <IconSvg.DeleteIcon color={styles.WARN__COLOR} />,
                        // content: t('delete_stock_item_des'),
                        // typeColor: styles.WARN__COLOR,
                        // showCancel: true,
                        // linkCallback: () => onRemoveStock(t55),
                        // })
                    }
                    onPress={onPressDetail}
                >
                    <View style={UI.view_t55}>
                        <Text style={isOddlot ? TextT55Oddlot : TextT55}>{t55}</Text>
                        <Text numberOfLines={1} style={TextTU9}>
                            {stockInfo.U9}
                        </Text>
                    </View>
                    <View style={UI.viewChart}>{isOddlot ? null : <SparklinesChartMulti iDItemFav={iDItemFav} stockCode={t55} styles={styles} />}</View>
                    <View style={UI.flex3}>
                        <View style={isOddlot ? ViewT31Oddlot : ViewT31}>
                            <Text style={UI.textPrice}>{renderT31()}</Text>
                        </View>
                        <Text numberOfLines={1} style={isOddlot ? TextT31RatioOddlot : TextT31Ratio}>
                            {renderT31Incr()}
                        </Text>
                    </View>
                </Pressable>
            )
        }
        return (
            <GmailStyleSwipeableRow styles={styles} t55={t55} onRemoveStock={onRemoveStock}>
                <Pressable style={TouchView} onPress={onPressDetail}>
                    <View style={UI.view_t55}>
                        <Text style={isOddlot ? TextT55Oddlot : TextT55}>{t55}</Text>
                        <Text numberOfLines={1} style={TextTU9}>
                            {stockInfo.U9}
                        </Text>
                    </View>

                    <View style={UI.viewChart}>{isOddlot ? null : <SparklinesChartMulti iDItemFav={iDItemFav} stockCode={t55} styles={styles} />}</View>
                    <View style={UI.flex3}>
                        <View style={isOddlot ? ViewT31Oddlot : ViewT31}>
                            <Text style={UI.textPrice}>{renderT31()}</Text>
                        </View>
                        <Text numberOfLines={1} style={isOddlot ? TextT31RatioOddlot : TextT31Ratio}>
                            {renderT31Incr()}
                        </Text>
                    </View>
                </Pressable>
            </GmailStyleSwipeableRow>
        )
    }

    return (
        <Pressable style={TouchViewNotSwipe} onPress={onPressDetail}>
            <View style={UI.view_t55}>
                <Text style={TextT55}>{t55}</Text>
                <Text numberOfLines={1} style={TextTU9}>
                    {stockInfo.U9}
                </Text>
            </View>

            <View style={UI.viewChart}>
                <SparklinesChartMulti iDItemFav={iDItemFav} stockCode={t55} styles={styles} />
            </View>

            <View style={UI.flex3}>
                <View style={ViewT31}>
                    <Text style={UI.textPrice}>
                        {fractionPrice
                            ? FormatNumber((stockInfo.t31 || stockInfo.t260) / 1000, 2, 0, '---')
                            : FormatNumber(stockInfo.t31 || stockInfo.t260, 0, 0, '---')}
                    </Text>
                </View>
                <Text numberOfLines={1} style={TextT31Ratio}>
                    {stockInfo.t31
                        ? (stockInfo.t31_incr > 0 ? '+' : '') +
                        (fractionPrice ? FormatNumber(stockInfo.t31_incr / 1000, 2) : FormatNumber(stockInfo.t31_incr)) +
                        ' ' +
                        (stockInfo.t31_incr_per > 0 ? '+' : '') +
                        (FormatNumber(stockInfo.t31_incr_per, 2) + '%')
                        : '---  ---'}
                </Text>
            </View>
        </Pressable>
    )
}, areEqual)

export const StockItemRemoveAble = memo(({ t55, onRemoveStock }) => {
    const navigation = useNavigation()
    const stockInfo = glb_sv.StockMarket[t55] || {}
    const { styles, fractionPrice, fractionQty } = useContext(StoreContext)

    const TouchView = useMemo(
        () =>
            StyleSheet.flatten([
                {
                    flex: 1,
                    flexDirection: 'row',
                    borderBottomColor: styles.DIVIDER__COLOR,
                    height: 60.5,
                    backgroundColor: styles.PRIMARY__BG__COLOR,
                    alignItems: 'center',
                    paddingHorizontal: dimensions.moderate(12),
                },
            ]),
        [styles],
    )

    const TextT55 = useMemo(
        () => StyleSheet.flatten([{ color: styles.PRIMARY__CONTENT__COLOR, fontWeight: fontWeights.medium, fontSize: fontSizes.small }]),
        [styles],
    )

    const TextTU9 = useMemo(() => StyleSheet.flatten([{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.smallest }]), [styles])

    const ViewT31 = useMemo(
        () => StyleSheet.flatten([{ backgroundColor: glb_sv.getColor(stockInfo.t31, stockInfo, styles, 't31'), width: '100%', borderRadius: 4, padding: 5 }]),
        [styles, glb_sv.getColor(stockInfo.t31, stockInfo, styles, 't31')],
    )

    const TextT31Ratio = useMemo(
        () =>
            StyleSheet.flatten([
                {
                    color: glb_sv.getColor(stockInfo.t31, stockInfo, styles),
                    fontSize: fontSizes.smallest,
                    fontWeight: fontWeights.semiBold,
                    textAlign: 'center',
                },
            ]),
        [styles, glb_sv.getColor(stockInfo.t31, stockInfo, styles, 't31')],
    )

    return (
        <GmailStyleSwipeableRow styles={styles} t55={t55} onRemoveStock={onRemoveStock}>
            <TouchableOpacity activeOpacity={0.6} style={TouchView} onPress={() => navigation.navigate(Screens.STOCK_INFO, { stockCode: stockInfo.t55 })}>
                <View style={UI.view_t55}>
                    <View style={UI.row}>
                        <Text style={TextT55}>{t55}</Text>
                    </View>
                    <Text numberOfLines={1} style={TextTU9}>
                        {stockInfo.U9}
                    </Text>
                </View>

                <View style={UI.viewChart}>
                    <SparklinesChart stockCode={t55} styles={styles} />
                </View>
                <View style={UI.flex3}>
                    <View style={ViewT31}>
                        <Text style={UI.textPrice}>
                            {fractionPrice
                                ? FormatNumber((stockInfo.t31 || stockInfo.t260) / 1000, 2, 0, '---')
                                : FormatNumber(stockInfo.t31 || stockInfo.t260, 0, 0, '---')}
                        </Text>
                    </View>
                    <Text numberOfLines={1} style={TextT31Ratio}>
                        {stockInfo.t31
                            ? (stockInfo.t31_incr > 0 ? '+' : '') +
                            (fractionPrice ? FormatNumber(stockInfo.t31_incr / 1000, 2) : FormatNumber(stockInfo.t31_incr)) +
                            ' ' +
                            (stockInfo.t31_incr_per > 0 ? '+' : '') +
                            (FormatNumber(stockInfo.t31_incr_per, 2) + '%')
                            : '---  ---'}
                    </Text>
                </View>
            </TouchableOpacity>
        </GmailStyleSwipeableRow>
    )
}, areEqual)

export const StockItemOwn = memo(({ t55 }) => {
    const navigation = useNavigation()
    const stockInfo = glb_sv.StockMarket[t55] || {}
    const { styles, fractionPrice, fractionQty } = useContext(StoreContext)

    const TouchView = useMemo(
        () =>
            StyleSheet.flatten([
                {
                    flex: 1,
                    flexDirection: 'row',
                    borderBottomColor: styles.DIVIDER__COLOR,
                    height: 60.5,
                    backgroundColor: styles.PRIMARY__BG__COLOR,
                    alignItems: 'center',
                    paddingHorizontal: dimensions.moderate(12),
                },
            ]),
        [styles],
    )

    const TextT55 = useMemo(
        () => StyleSheet.flatten([{ color: styles.PRIMARY__CONTENT__COLOR, fontWeight: fontWeights.medium, fontSize: fontSizes.small }]),
        [styles],
    )

    const TextTU9 = useMemo(() => StyleSheet.flatten([{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.smallest }]), [styles])

    const ViewT31 = useMemo(
        () => StyleSheet.flatten([{ backgroundColor: glb_sv.getColor(stockInfo.t31, stockInfo, styles, 't31'), width: '100%', borderRadius: 4, padding: 5 }]),
        [styles, glb_sv.getColor(stockInfo.t31, stockInfo, styles, 't31')],
    )

    const TextT31Ratio = useMemo(
        () =>
            StyleSheet.flatten([
                {
                    color: glb_sv.getColor(stockInfo.t31, stockInfo, styles),
                    fontSize: fontSizes.smallest,
                    fontWeight: fontWeights.semiBold,
                    textAlign: 'center',
                },
            ]),
        [styles, glb_sv.getColor(stockInfo.t31, stockInfo, styles, 't31')],
    )

    return (
        <TouchableOpacity activeOpacity={0.6} style={TouchView} onPress={() => navigation.navigate(Screens.STOCK_INFO, { stockCode: stockInfo.t55 })}>
            <View style={UI.view_t55}>
                <View style={UI.row}>
                    <Text style={TextT55}>{t55}</Text>
                </View>
                <Text numberOfLines={1} style={TextTU9}>
                    {stockInfo.U9}
                </Text>
            </View>

            <View style={UI.viewChart}>
                <SparklinesChart stockCode={t55} styles={styles} />
            </View>
            <View style={UI.flex3}>
                <View style={ViewT31}>
                    <Text style={UI.textPrice}>
                        {stockInfo.t31
                            ? fractionPrice
                                ? FormatNumber(stockInfo.t31 / 1000, 2, 0, '---')
                                : FormatNumber(stockInfo.t31 === 0 ? stockInfo.t260 : stockInfo.t31, 0, 0, '---')
                            : '---'}
                    </Text>
                </View>
                <Text numberOfLines={1} style={TextT31Ratio}>
                    {stockInfo.t31
                        ? (stockInfo.t31_incr > 0 ? '+' : '') +
                        (fractionPrice ? FormatNumber(stockInfo.t31_incr / 1000, 2) : FormatNumber(stockInfo.t31_incr)) +
                        ' ' +
                        (stockInfo.t31_incr_per > 0 ? '+' : '') +
                        (FormatNumber(stockInfo.t31_incr_per, 2) + '%')
                        : '---  ---'}
                </Text>
            </View>
        </TouchableOpacity>
    )
}, areEqual)

function areEqual(prev, next) {
    if (!isFiveColumn && !isSevenColumn) {
        return prev.t260 === next.t260 && prev.t31 === next.t31 && prev.t31_incr === next.t31_incr && prev.t31_incr_per === next.t31_incr_per
    }
    if (isFiveColumn || isSevenColumn) {
        return (
            prev.t260 === next.t260 &&
            prev.t31 === next.t31 &&
            prev.t31_incr === next.t31_incr &&
            prev.t31_incr_per === next.t31_incr_per &&
            prev.t132_1 === next.t132_1 &&
            prev.t133_1 === next.t133_1
        )
    }
    if (isSevenColumn) {
        return (
            prev.t31 === next.t31 &&
            prev.t260 === next.t260 &&
            prev.t31_incr === next.t31_incr &&
            prev.t31_incr_per === next.t31_incr_per &&
            prev.t132_1 === next.t132_1 &&
            prev.t133_1 === next.t133_1 &&
            prev.t391 === next.t391 &&
            prev.t3301 === next.t3301
        )
    }
    return false
}

const EmptyWatchlistViewMemo = ({ addNewStock }) => {
    const { t } = useTranslation()
    const { styles } = useContext(StoreContext)

    const TextLine1 = useMemo(
        () =>
            StyleSheet.flatten([
                { fontSize: fontSizes.medium, fontWeight: fontWeights.medium, color: styles.PRIMARY__CONTENT__COLOR, lineHeight: dimensions.moderate(26) },
            ]),
        [styles],
    )

    const TextLine2 = useMemo(
        () => StyleSheet.flatten([{ fontSize: fontSizes.small, color: styles.ICON__CLOCK, lineHeight: dimensions.moderate(23) }]),
        [styles],
    )

    const StyleButtonBuy = useMemo(
        () =>
            StyleSheet.flatten([
                {
                    backgroundColor: styles.PRIMARY,
                    height: dimensions.vertical(45, 0.5),
                    marginVertical: dimensions.indent,
                    borderRadius: 5,
                    paddingHorizontal: 50,
                    alignSelf: 'center',
                },
            ]),
        [styles],
    )

    const StyleBuySellText = useMemo(() => StyleSheet.flatten([{ fontSize: fontSizes.medium, color: 'white', fontWeight: fontWeights.bold }]), [])

    return (
        <View style={UI.view_emty_watchlist}>
            <IconSvg.IconFolderEmpty />
            <Text style={TextLine1}>{t('watchlist_empty')}</Text>
            <Text style={TextLine2}>{t('let_add_stock_watchlist')}</Text>

            <Button style={StyleButtonBuy} onPress={addNewStock}>
                <Text style={StyleBuySellText}>{t('new_stock')}</Text>
            </Button>
        </View>
    )
}
export const EmptyWatchlistView = memo(EmptyWatchlistViewMemo)

const UI = StyleSheet.create({
    flex3: {
        flex: 3,
    },
    header: {
        flexDirection: 'row',
        paddingHorizontal: dimensions.moderate(16),
    },
    headerLeft: {
        alignItems: 'center',
        flex: 1,
        flexDirection: 'row',
    },
    row: {
        flexDirection: 'row',
    },
    textPrice: {
        color: COLORS.WHITE,
        fontSize: fontSizes.small,
        fontWeight: fontWeights.semiBold,
        lineHeight: fontSizes.small + 2,
        textAlign: 'center',
    },
    viewChart: {
        flex: 3,
        maxWidth: 100,
        minWidth: 100,
    },
    view_emty_watchlist: {
        alignItems: 'center',
        justifyContent: 'center',
        marginVertical: 30,
    },
    view_t55: {
        alignContent: 'flex-start',
        flex: 6,
        justifyContent: 'flex-start',
    },
})
