import React, { useContext } from 'react'
import { TFunction, useTranslation } from 'react-i18next'
import { StyleSheet, Text } from 'react-native'
import { fontSizes as fs } from '@mts-styles/index'
import moment from 'moment'
import { Col, Row } from 'native-base'

import { StoreContext } from '../../../../store'

const getStatusAndColor = ({
    cancelStatus,
    styles,
    t,
    customerSignStatus,
    rejectStatus,
}: {
    cancelStatus: 'Y' | 'N'
    styles: any
    t: TFunction
    customerSignStatus: 'Y' | 'N'
    rejectStatus: 'Y' | 'N'
}) => {
    const color = styles.WARN__COLOR
    const status = t('register_margin_item_signed')
    if (rejectStatus === 'Y')
        return {
            color: styles.ERROR__COLOR,
            status: t('econtract_item_reject'),
        }
    if (cancelStatus === 'Y')
        return {
            color: styles.ERROR__COLOR,
            status: t('econtract_item_cancel'),
        }
    if (customerSignStatus === 'Y')
        return {
            color: styles.SUCCESS__COLOR,
            status: t('econtract_item_signed'),
        }
    return { color, status }
}

export const MarginItem = ({ item, colSpan, index }) => {
    const { c1: registerDate, c4: customerSignStatus, c5: SSVSignStatus, c14: cancelStatus, c15: rejectStatus, c17: registerTime } = item

    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()

    const { status, color } = getStatusAndColor({ cancelStatus, styles, t, customerSignStatus, rejectStatus })

    return (
        <Row style={[UI.container, { borderColor: styles.DIVIDER__COLOR, borderBottomWidth: 1, paddingBottom: 8, alignItems: 'center' }]}>
            <Col size={colSpan[0]} style={{ marginLeft: 8 }}>
                <Text style={[UI.textValue, { color: styles.PRIMARY__CONTENT__COLOR }]}>{index + 1}</Text>
            </Col>
            <Col size={colSpan[1]} style={{ alignItems: 'center' }}>
                <Text style={[UI.textValue, { color: styles.PRIMARY__CONTENT__COLOR }]}>
                    {moment(registerTime, 'YYYYMMDD-HH:mm:ss').format('DD/MM/YYYY HH:mm')}
                </Text>
            </Col>
            {/* {rejectStatus === 'Y' || (SSVSignStatus === 'N' && customerSignStatus === 'Y') ? (
                <Col style={UI.RowAction} size={colSpan[2]} />
            ) : */}

            <Col size={colSpan[2]} style={UI.RowAction}>
                <Text style={{ color: color }}>{status}</Text>
            </Col>
        </Row>
    )
}

const UI = StyleSheet.create({
    RowAction: { flexDirection: 'row', justifyContent: 'flex-end', marginLeft: 8 },
    bthText: { fontSize: fs.small },
    btn: {
        alignItems: 'flex-end',
        borderRadius: 8,
        height: 25,
        justifyContent: 'center',
        paddingHorizontal: 5,
    },
    btnDownloadFile: {
        alignItems: 'center',
        borderRadius: 5,
        height: 25,
        justifyContent: 'center',
        marginRight: 10,
        width: 25,
    },
    container: { flex: 1, flexDirection: 'row', marginTop: 10, paddingBottom: 12 },
    divider: { height: 10 },
    flex1: { flex: 1 },
    iconDownload: { fontSize: 15 },
    itemName: { flex: 2, marginRight: 5 },
    textValue: { fontSize: fs.small },
    verifyView: { flex: 1.5, flexDirection: 'row', marginLeft: 10 },
})
