import React, { memo, useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { InteractionManager, Pressable, Text, View } from 'react-native'
import AntDesign from 'react-native-vector-icons/AntDesign'
import ModalController from '@mts-components/appModal/modalControlller'
import { COLORS } from '@mts-styles/colors'
import moment from 'moment'
import { VictoryAxis, VictoryBar, VictoryChart } from 'victory-native'

import { StoreContext } from '../../../store'
import { dimensions, fontSizes, IconSvg } from '../../../styles'
import { eventList, glb_sv, reqFunct, Screens, sendRequest, subcribeFunct } from '../../../utils'

const list_T = [
    {
        value: 'T',
        name: 'T',
    },
    {
        value: 'T1',
        name: 'T-1',
    },
    {
        value: 'T2',
        name: 'T-2',
    },
    {
        value: 'T3',
        name: 'T-3',
    },
    {
        value: 'T4',
        name: 'T-4',
    },
]

const ServiceInfo = {
    GET_HISTORY_CASH_FLOW: {
        reqFunct: reqFunct.GET_HISTORY_CASH_FLOW,
        WorkerName: 'FOSqMkt03',
        ServiceName: 'FOSqMkt03_HistTrading',
        ClientSentTime: '0',
        Operation: 'Q',
    },
}

const CashFlow = ({ code, navigation, isIndex, showName }) => {
    const { t } = useTranslation()
    const { styles } = useContext(StoreContext)
    const [data, setData] = useState([])
    const [min, setMin] = useState(0)
    const [max, setMax] = useState(0)

    const [active, setActive] = useState('T')
    const activeRef = useRef('T')

    const [typeChart, setTypeChart] = useState('acl')
    const typeChartRef = useRef('acl')

    useEffect(() => {
        InteractionManager.runAfterInteractions(() => {
            setTimeout(() => {
                subcribeFunct(null, null, 'GET_HIST', ['BUY_SELL_FLOW'], [code], [0], [500], isIndex ? 'INDEX' : 'STOCK')
                // subcribeFunct(null, null, 'SUB', ['BUY_SELL_FLOW'], [code])
            }, 700)
        })

        const eventMarket = glb_sv.eventMarket.subscribe((msg) => {
            if (msg.type === eventList.BUY_SELL_FLOW && msg.msgKey === code && activeRef.current === 'T') {
                if (typeChartRef.current === 'rt') {
                    handleDataRealtime()
                } else {
                    handleDataAccumulate()
                }
                if (msg.isHistory) {
                    subcribeFunct(null, null, 'SUB', ['BUY_SELL_FLOW'], [code])
                }
            }
        })

        changeActive(activeRef.current)

        return () => {
            eventMarket.unsubscribe()
            subcribeFunct(null, null, 'UNSUB', ['BUY_SELL_FLOW'], [code])
        }
    }, [code])

    const handleDataAccumulate = () => {
        if (isIndex) {
            if (glb_sv.IndexMarket[code]) {
                handleDataHistory(glb_sv.IndexMarket[code].BUY_SELL_FLOW.T.acl)
            }
        } else {
            if (glb_sv.StockMarket[code]) {
                handleDataHistory(glb_sv.StockMarket[code].BUY_SELL_FLOW.T.acl)
            }
        }
    }

    const handleDataHistory = (arrays) => {
        if (!arrays.length) {
            setData([])
            setMin(0)
            return
        }
        const minV = arrays.reduce(function (prev, curr) {
            return prev.y < curr.y ? prev : curr
        }).y
        const maxV = arrays.reduce(function (prev, curr) {
            return prev.y > curr.y ? prev : curr
        }).y

        const array = arrays.map((item) => ({
            x: item.x,
            y: item.y,
            y0: minV < 0 ? minV : 0,
        }))

        setData(array)
        setMin(minV < 0 ? minV : 0)
        setMax(maxV)
    }

    const getHistoryCashFlow = () => {
        setData([])
        const key =
            activeRef.current === 'T1' ? '1' : activeRef.current === 'T2' ? '2' : activeRef.current === 'T3' ? '3' : activeRef.current === 'T4' ? '4' : ''
        if (!key) return
        const InputParams = ['BUY_SELL_FLOW', key, code]
        sendRequest(ServiceInfo.GET_HISTORY_CASH_FLOW, InputParams, getHistoryCashFlowResult, true, getHistoryCashFlowTimeout)
    }

    const getHistoryCashFlowTimeout = () => { }

    const getHistoryCashFlowResult = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
        } else {
            let jsondata = []
            try {
                if (message.Data) {
                    jsondata = JSON.parse(message.Data)
                }
            } catch (err) {
                console.warn('getHistoryCashFlowResult error', err)
                return
            }
            if (jsondata.length) {
                const key = reqInfoMap.inputParam[1] === '1' ? 'T1' : reqInfoMap.inputParam[1] === '2' ? 'T2' : reqInfoMap.inputParam[1] === '3' ? 'T3' : 'T4'
                const arrayRT = jsondata.map((item) => ({
                    x: moment(item.c1, 'HH:mm:ss').valueOf(),
                    y: Number((item.c4 - item.c5).toFixed(2)),
                }))
                const arrayAcl = jsondata.map((item) => ({
                    x: moment(item.c1, 'HH:mm:ss').valueOf(),
                    y: Number((item.c8 - item.c9).toFixed(2)),
                }))
                if (isIndex) {
                    glb_sv.IndexMarket[code].BUY_SELL_FLOW[key].rt = arrayRT
                    glb_sv.IndexMarket[code].BUY_SELL_FLOW[key].acl = arrayAcl
                } else {
                    glb_sv.StockMarket[code].BUY_SELL_FLOW[key].rt = arrayRT
                    glb_sv.StockMarket[code].BUY_SELL_FLOW[key].acl = arrayAcl
                }
                if (typeChartRef.current === 'rt') {
                    handleDataHistory(arrayRT)
                } else {
                    handleDataHistory(arrayAcl)
                }
            }
        }
    }

    const changeActive = (value) => {
        setActive(value)
        activeRef.current = value
        if (value === 'T') {
            if (typeChartRef.current === 'rt') {
                handleDataRealtime()
            } else {
                handleDataAccumulate()
            }
        } else {
            if (isIndex) {
                if (glb_sv.IndexMarket[code] && glb_sv.IndexMarket[code].BUY_SELL_FLOW[value].acl.length) {
                    if (typeChartRef.current === 'rt') {
                        handleDataHistory(glb_sv.IndexMarket[code].BUY_SELL_FLOW[value].rt)
                    } else {
                        handleDataHistory(glb_sv.IndexMarket[code].BUY_SELL_FLOW[value].acl)
                    }
                } else {
                    getHistoryCashFlow()
                }
            } else {
                if (glb_sv.StockMarket[code] && glb_sv.StockMarket[code].BUY_SELL_FLOW[value].acl.length) {
                    if (typeChartRef.current === 'rt') {
                        handleDataHistory(glb_sv.StockMarket[code].BUY_SELL_FLOW[value].rt)
                    } else {
                        handleDataHistory(glb_sv.StockMarket[code].BUY_SELL_FLOW[value].acl)
                    }
                } else {
                    getHistoryCashFlow()
                }
            }
        }
    }

    const changeTypeChart = () => {
        if (typeChartRef.current === 'rt') {
            typeChartRef.current = 'act'
            setTypeChart('acl')
            if (activeRef.current === 'T') {
                handleDataAccumulate()
            } else {
                if (isIndex) {
                    handleDataHistory(glb_sv.IndexMarket[code].BUY_SELL_FLOW[activeRef.current].acl)
                } else {
                    handleDataHistory(glb_sv.StockMarket[code].BUY_SELL_FLOW[activeRef.current].acl)
                }
            }
        } else {
            typeChartRef.current = 'rt'
            setTypeChart('rt')
            if (activeRef.current === 'T') {
                handleDataRealtime()
            } else {
                if (isIndex) {
                    handleDataHistory(glb_sv.IndexMarket[code].BUY_SELL_FLOW[activeRef.current].rt)
                } else {
                    handleDataHistory(glb_sv.StockMarket[code].BUY_SELL_FLOW[activeRef.current].rt)
                }
            }
        }
    }

    const handleDataRealtime = () => {
        if (isIndex) {
            if (glb_sv.IndexMarket[code]) {
                handleDataHistory(glb_sv.IndexMarket[code].BUY_SELL_FLOW.T.rt)
            }
        } else {
            if (glb_sv.StockMarket[code]) {
                handleDataHistory(glb_sv.StockMarket[code].BUY_SELL_FLOW.T.rt)
            }
        }
    }

    const openInfo = () => {
        // navigation.navigate(Screens.ALERT_MODAL, {
        //     title: t('cash_flow_market'),
        //     content: t('tooltip_cash_flow'),
        //     typeColor: styles.INFO__COLOR,
        // })
        ModalController.showModal({
            title: t('cash_flow_market'),
            content: t('tooltip_cash_flow'),
            typeColor: styles.INFO__COLOR,
        })
    }

    return (
        <View>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: isIndex ? dimensions.moderate(12) : 0 }}>
                <View style={{ flexDirection: 'row' }}>
                    <Text style={{ color: !showName ? styles.PRIMARY__CONTENT__COLOR : styles.PRIMARY, fontSize: fontSizes.medium, fontWeight: '600' }}>
                        {t('cash_flow_market')}
                        {!showName ? '' : code === 'HSXIndex' ? 'HSX' : code === 'HNXIndex' ? 'HNX' : code === 'HNXUpcomIndex' ? 'UPC' : ''}
                    </Text>
                    <Pressable hitSlop={12} style={{ paddingTop: 2 }} onPress={openInfo}>
                        <IconSvg.InfoIcon color={styles.PRIMARY__CONTENT__COLOR} />
                    </Pressable>
                </View>

                <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.verySmall, marginTop: 1 }}>{t('billion_vnd__unit')}</Text>
            </View>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: isIndex ? dimensions.moderate(12) : 0, marginTop: 6 }}>
                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <View
                        style={{
                            width: 8,
                            height: 8,
                            borderRadius: 4,
                            backgroundColor: styles.UP__COLOR,
                        }}
                    />
                    <Text style={{ fontSize: fontSizes.smallest, color: styles.PRIMARY__CONTENT__COLOR }}>{t('net_flow_positive_signal')}</Text>
                </View>
                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <View
                        style={{
                            width: 8,
                            height: 8,
                            borderRadius: 4,
                            backgroundColor: styles.DOWN__COLOR,
                        }}
                    />
                    <Text style={{ fontSize: fontSizes.smallest, color: styles.PRIMARY__CONTENT__COLOR }}>{t('net_flow_negative_signal')}</Text>
                </View>
            </View>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: isIndex ? dimensions.moderate(12) : 0, marginTop: 6 }}>
                <View style={{ flexDirection: 'row' }}>
                    {list_T.map((item) => (
                        <Pressable
                            key={item.value}
                            style={{
                                marginRight: 3,
                                borderRadius: 2,
                                width: 45,
                                paddingHorizontal: 4,
                                paddingVertical: 2,
                                backgroundColor: styles.SECOND__BG__COLOR,
                                borderWidth: 1,
                                borderColor: active === item.value ? styles.PRIMARY : styles.SECOND__CONTENT__COLOR,
                            }}
                            onPress={() => changeActive(item.value)}
                        >
                            <Text
                                style={{
                                    color: active === item.value ? styles.PRIMARY : styles.SECOND__CONTENT__COLOR,
                                    fontSize: fontSizes.small,
                                    textAlign: 'center',
                                }}
                            >
                                {item.name}
                            </Text>
                        </Pressable>
                    ))}
                </View>
                <Pressable
                    style={{
                        flexDirection: 'row',
                        marginRight: 3,
                        borderRadius: 2,
                        paddingHorizontal: 4,
                        paddingVertical: 2,
                        backgroundColor: styles.PRIMARY,
                    }}
                    onPress={changeTypeChart}
                >
                    <Text
                        style={{
                            color: COLORS.WHITE,
                            fontSize: fontSizes.small,
                            textAlign: 'center',
                        }}
                    >
                        {typeChart === 'rt' ? t('realtime') : t('accumulate')}
                    </Text>
                    <AntDesign color="#FFF" name="swap" size={fontSizes.small + 6} />
                </Pressable>
            </View>

            <VictoryChart
                height={340}
                padding={{
                    right: 20,
                    top: 30,
                    bottom: 20,
                    left: 50,
                }}
            >
                <VictoryAxis
                    offsetY={max && min ? Math.abs(min / ((max * 1.1 - min * 1.1) / 320)) : 0}
                    orientation="bottom"
                    scale="linear"
                    style={{
                        tickLabels: { fontSize: 10, padding: 0, fontWeight: '500', fill: styles.PRIMARY__CONTENT__COLOR },
                        axis: { stroke: 'transparent' },
                    }}
                    tickCount={7}
                    tickFormat={(t) => moment(t).format('HH:mm')}
                />

                <VictoryAxis
                    dependentAxis
                    domain={[min * 1.1, max * 1.1]}
                    offsetX={5}
                    style={{
                        tickLabels: { fontSize: 10, padding: 5, fontWeight: '500', fill: styles.PRIMARY__CONTENT__COLOR },
                        axis: { stroke: 'transparent' },
                        grid: { stroke: styles.BORDER__MODAL, strokeDasharray: '5' },
                    }}
                    tickCount={9}
                    tickFormat={(y) => y.toFixed()}
                />
                <VictoryBar
                    data={data}
                    style={{
                        data: {
                            fill: ({ datum }) => {
                                return datum.y < 0 ? styles.DOWN__COLOR : styles.UP__COLOR
                            },
                        },
                    }}
                />
            </VictoryChart>
        </View>
    )
}

export default memo(CashFlow)
