import React, { memo, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Animated, InteractionManager, Platform, RefreshControl, StyleSheet, View } from 'react-native'
import { ScrollView } from 'react-native-gesture-handler'
import { SafeAreaView } from 'react-native-safe-area-context'
import { getStatusBarHeight } from 'react-native-status-bar-height'
import { useIsFocused } from '@react-navigation/native'
import throttle from 'lodash/throttle'
import uniq from 'lodash/uniq'
import { Container, Content, DefaultTabBar, ScrollableTab, Tab, Tabs } from 'native-base'
import SyncStorage from 'sync-storage'

import { FocusAwareStatusBar, Text } from '../../basic-components'
import Account from '../../components/account'
import NotAuthView from '../../components/notAuth-view'
import { useCustomInteraction, useUpdateEffect } from '../../hoc'
import { StoreContext } from '../../store'
import { StoreTrading } from '../../store-trading'
import { dimensions, fontSizes, fontWeights } from '../../styles'
import { eventList, FormatNumber, glb_sv, reqFunct, Screens, sendRequest, STORE_KEY, subcribeFunct, wait } from '../../utils'
import AssetPart from './assets-part'
import Cash from './cash'
import Debt from './debt'
import MyPerformance from './my-performance'
import ProfitLossCalculator from './profit-loss-calculator'

const DEFAUT_THROTTLE_TIME = Platform.select({ ios: 1000, android: 2000, default: 2000 })

const ServiceInfo = {
    GET_ASSETS_TOTAL_INFO: {
        reqFunct: reqFunct.GET_ASSETS_TOTAL_INFO,
        WorkerName: 'FOSqAsset',
        ServiceName: 'FOSqAsset_1801_1',
        Operation: 'Q',
        ClientSentTime: '0',
    },

    GET_ASSETS_STOCK_LIST: {
        reqFunct: reqFunct.GET_ASSETS_STOCK_LIST + 'ASSETS_OVERVIEW',
        WorkerName: 'FOSqAsset',
        ServiceName: 'FOSqAsset_1801_1',
        Operation: 'Q',
        ClientSentTime: '0',
    },
}

const AssetInfos = ({ navigation }) => {
    const TAG = 'AssetInfos'

    const { styles, theme, applicationSettings } = useContext(StoreContext)
    const { t } = useTranslation()
    const [tab, setTab] = useState(0)
    const isFocused = useIsFocused()
    // ------------
    const [assetInfo, setAsset] = useState({})
    const [isAllSub, setAllSub] = useState(false)
    const isAllSubRef = useRef(false)
    const [dataStock, setDataStock] = useState([])
    const tempList = useRef([])
    const [refreshing, setRefresh] = useState(false)
    const [updateChart, setUpdateChart] = useState(true)
    const [isLoading, setIsLoading] = useState(true)
    const [isTimeout, setIsTimemout] = useState(false)
    //------
    const scrollRef = React.useRef(null)
    // ------
    const [totalValue, setTotalValue] = useState(0)
    const [totalValueRatio, setTotalValueRatio] = useState(0)

    const [objTotal, setObjTotal] = useState({
        avg_buy_values: 0,
        present_values: 0,
        cal_profit_loss: 0,
    })

    const [dataPieChart, setDataPieChart] = useState([])

    const { userInfo, setUserInfo } = useContext(StoreTrading)
    const userInfoRef = useRef({ ...userInfo })

    const isFirstRef = useRef(false)

    const subStockList = useRef([])
    const timeoutSub = useRef(null)

    const throttled = useRef(
        throttle(
            () => {
                tempList.current.forEach((item, index) => {
                    const stockInfo = glb_sv.StockMarket[item.c2] || { t31: item.c15 }
                    item.c17 = Number(item.c17)
                    item.c25 = Number(item.c25)
                    item.c15 = stockInfo.t31 || item.c15
                    item.c18 = item.c17 * (Number(item.c25) + Number(item.c14))
                    item.c16 = item.c15 * (Number(item.c25) + Number(item.c14))
                    item.c19 = (item.c15 - item.c17) * (Number(item.c25) + Number(item.c14))
                    item.c20 = item.c17 == 0 ? 100 : Math.round(((item.c15 - item.c17) / item.c17) * 10000) / 100
                    item.t31_incr_per = stockInfo.t31_incr_per || 0
                    // console.log('t31_incr_per', stockInfo.t31_incr_per)
                })

                const avg_buy_values = tempList.current.reduce(function (a, b) {
                    return a + Number(b.c18)
                }, 0)
                const present_values = tempList.current.reduce(function (a, b) {
                    return a + Number(b.c16)
                }, 0)
                const total = tempList.current.reduce(function (a, b) {
                    return a + Number(b.c19)
                }, 0)

                setObjTotal({
                    avg_buy_values,
                    present_values,
                    cal_profit_loss: total,
                })
                // console.log('>>>>>>>>>', avg_buy_values, present_values, !avg_buy_values ? 0 : Math.round((total / avg_buy_values) * 10000) / 100)

                setTotalValue(total)
                setTotalValueRatio(!avg_buy_values ? 0 : Math.round((total / avg_buy_values) * 10000) / 100)
                setDataStock(tempList.current)
                handleDataChart(tempList.current)
            },
            DEFAUT_THROTTLE_TIME,
            { trailing: true },
        ),
    )

    useEffect(() => {
        // console.log('>>>>>>', isFocused, userInfo)
        if (!isFocused) {
            if (subStockList.current.length) {
                InteractionManager.runAfterInteractions(() => {
                    subcribeFunct(null, null, 'UNSUB', ['MDDS|SI'], subStockList.current)
                })
            }
            if (timeoutSub.current) clearTimeout(timeoutSub.current)
            return
        }

        if (isFirstRef?.current) {
            userInfoRef.current = userInfo
            isAllSubRef.current = false
            setAllSub(false)
        }

        getAssetsTotalInfo()

        return () => {
            isFirstRef.current = false
        }
    }, [userInfo, isFocused])

    useEffect(() => {
        // if (!isFocused) {
        //     console.log('!isFocused >>>>>> eventMarket')
        //     return
        // }

        userInfoRef.current = userInfo
        isAllSubRef.current = true
        setAllSub(true)

        isFirstRef.current = true

        getAssetsTotalInfo()

        const eventMarket = glb_sv.eventMarket.subscribe((msg) => {
            if (msg.type === eventList.SUB_STOCK && msg.message === 'SI') {
                // console.log('msg', glb_sv.StockMarket[msg.msgKey].t55, ': ', glb_sv.StockMarket[msg.msgKey].t31)
                throttled.current()
            } else if (msg.type === eventList.RECONNECT_MARKET) {
                if (subStockList.current.length) {
                    InteractionManager.runAfterInteractions(() => {
                        subcribeFunct(null, null, 'SUB', ['MDDS|SI'], subStockList.current)
                    })
                }
            }
        })

        return () => {
            eventMarket.unsubscribe()
            throttled.current.cancel()
            if (subStockList.current.length) {
                InteractionManager.runAfterInteractions(() => {
                    subcribeFunct(null, null, 'UNSUB', ['MDDS|SI'], subStockList.current)
                })
            }
        }
    }, [])

    useUpdateEffect(() => {
        // useUpdateEffect --> bỏ qua lần đầu tiên
        setUpdateChart(true)
        wait(300).then(() => setUpdateChart(false))
    }, [theme])

    const handleDataChart = (data) => {
        if (!data.length) {
            tempList.current = []
            setObjTotal({
                avg_buy_values: 0,
                present_values: 0,
                cal_profit_loss: 0,
            })
            return
        }
        // Data cho biểu đồ tài sản
        const temp = []
        tempList.current.forEach((item) => {
            if (!temp.includes(item.c2)) {
                temp.push(item.c2)
            }
        })
        const dataConvert = {}
        temp.forEach((itemTemp) => {
            tempList.current.map((item, index) => {
                if (item.c2 == itemTemp) {
                    dataConvert[item.c2] = (dataConvert[item.c2] ? dataConvert[item.c2] : 0) + Number(item.c16)
                }
            })
        })

        const dataChart = convertDataPieChart({ ...dataConvert })
        setDataPieChart((prev) => dataChart)
    }

    const convertDataPieChart = (dataConvert) => {
        // -----------
        const totalValueStock = Object.keys(dataConvert).reduce((prev, item) => {
            return prev + dataConvert[item]
        }, 0)
        //-----------------
        const arrColor = ['#1890FF', '#13C2C2', '#2FC25B', '#FACC14', '#F04864', '#8543E0', '#3436C7', '#223273']
        const present_values_chart = Object.keys(dataConvert).reduce((prev, item) => {
            return Number(prev) + Number(dataConvert[item])
        }, 0)

        // -----------
        const percentData = {}
        Object.keys(dataConvert).forEach((e) => {
            if (dataConvert[e] / totalValueStock < 0.05) {
                percentData.other = (percentData.other || 0) + dataConvert[e]
            } else {
                percentData[e] = dataConvert[e]
            }
        })
        const dataChart = Object.keys(percentData).map((e, index) => {
            return {
                name: e === 'other' ? t('other_stocks') : e,
                y: percentData[e], // Asset Ratio
                colorProfit: styles.REF__COLOR,
                profitRatio: (percentData[e] ? Math.round((percentData[e] / present_values_chart) * 100) / 100 : 0) + '%',
                color: arrColor[index % arrColor.length],
            }
        })

        return dataChart
    }
    // -------------- Get Data Assets

    const getAssetsTotalInfo = () => {
        const { actn_curr, sub_curr } = userInfoRef.current
        if (!actn_curr || !sub_curr) {
            // [broker] - Nếu không có tài khoản sub thì không gửi request
            setIsLoading(false)
            setUpdateChart(false)
            return
        }
        // ---------
        setAsset([])
        tempList.current = []
        setDataStock([])
        setObjTotal({
            avg_buy_values: 0,
            present_values: 0,
            cal_profit_loss: 0,
        })
        // -------
        const InputParams = ['01', actn_curr, isAllSubRef.current && userInfoRef.current.sub_list.length > 1 ? '%' : sub_curr]
        sendRequest(ServiceInfo.GET_ASSETS_TOTAL_INFO, InputParams, getAssetsTotalInfoResult, true, getAssetsTotalInfoTimeout, '', null, 'equal_service')
    }

    const getAssetsTotalInfoTimeout = () => {
        setUpdateChart(false)
    }

    const getAssetsTotalInfoResult = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            setUpdateChart(false)
            return
        } else {
            let jsondata = {}
            try {
                jsondata = message.Data ? JSON.parse(message.Data)[0] : {}
            } catch (err) {
                setUpdateChart(false)
            }

            InteractionManager.runAfterInteractions(() => {
                setTimeout(() => {
                    setAsset(jsondata)
                    setUpdateChart(true)
                    getAssetsStockList()
                }, 0)
            })
        }
    }
    // -------------- Get Data Stock Own

    const getAssetsStockList = () => {
        const { actn_curr, sub_curr } = userInfoRef.current
        if (!actn_curr || !sub_curr) {
            // [broker] - Nếu không có tài khoản sub thì không gửi request
            setIsLoading(false)
            setUpdateChart(false)
            return
        }
        // ---------
        tempList.current = []
        setDataStock([])
        const InputParams = ['02', actn_curr, isAllSubRef.current && userInfoRef.current.sub_list.length > 1 ? '%' : sub_curr]
        sendRequest(ServiceInfo.GET_ASSETS_STOCK_LIST, InputParams, getAssetsStockListResult, true, getAssetsStockListTimeout, '', 0, 'equal_service')
        setIsLoading(true)
        setIsTimemout(false)
        if (timeoutSub.current) clearTimeout(timeoutSub.current)
    }

    const getAssetsStockListTimeout = () => {
        setIsTimemout(true)
        setIsLoading(false)
    }

    const getAssetsStockListResult = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            setIsTimemout(true)
            return
        } else {
            setIsTimemout(false)
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {
                return
            }
            tempList.current = tempList.current.concat(jsondata)
            if (Number(message.Packet) <= 0) {
                if (glb_sv.activeCode === '081') {
                    tempList.current = tempList.current.filter((x) => x.c4 !== 0 || x.c25 + x.c14 !== 0)
                }
                tempList.current.forEach((item, index) => {
                    const stockInfo = glb_sv.StockMarket[item.c2] || { t31: item.c15 }
                    item.c17 = Number(item.c17)
                    item.c25 = Number(item.c25)
                    item.c15 = stockInfo.t31 || item.c15
                    item.c18 = item.c17 * (Number(item.c25) + Number(item.c14))
                    item.c16 = item.c15 * (Number(item.c25) + Number(item.c14))
                    item.c19 = (item.c15 - item.c17) * (Number(item.c25) + Number(item.c14))
                    item.c20 = item.c17 == 0 ? 100 : Math.round(((item.c15 - item.c17) / item.c17) * 10000) / 100
                })

                const avg_buy_values = tempList.current.reduce(function (a, b) {
                    return a + Number(b.c18) // Tổng giá trị vốn
                }, 0)
                const present_values = tempList.current.reduce(function (a, b) {
                    return a + Number(b.c16) // Tổng giá trị thị trường
                }, 0)
                const total = tempList.current.reduce(function (a, b) {
                    return a + Number(b.c19) // Tổng giá trị lãi lỗ
                }, 0)

                setObjTotal({
                    avg_buy_values,
                    present_values,
                    cal_profit_loss: total,
                })

                setTotalValue(total)
                setTotalValueRatio(!avg_buy_values ? 0 : Math.round((total / avg_buy_values) * 10000) / 100)
                setIsLoading(false)
                setDataStock(tempList.current)
                handleDataChart(tempList.current)

                const list_stock = uniq(tempList.current.map((e) => e.c2))
                if (subStockList.current.length) {
                    subcribeFunct(null, null, 'UNSUB', ['MDDS|SI'], subStockList.current)
                }
                subStockList.current = list_stock
                if (subStockList.current.length) {
                    timeoutSub.current = setTimeout(() => {
                        subcribeFunct(null, null, 'SUB', ['MDDS|SI'], subStockList.current)
                    }, 1000)
                    setTimeout(() => {
                        throttled.current()
                    }, 4000)
                }
            }
        }
    }

    const changeAllSub = useCallback((value) => {
        isAllSubRef.current = value
        setAllSub(value)
        getAssetsTotalInfo()
    }, [])

    const changeSub = useCallback((value) => {
        isAllSubRef.current = false
        userInfoRef.current = value
        setAllSub(false)
        setUserInfo(value)
        getAssetsTotalInfo()
    }, [])

    const refreshStockOwn = useCallback(() => {
        setAsset({})
        setIsTimemout(false)
        setUpdateChart(false)

        getAssetsTotalInfo()
    }, [])

    const onRefresh = () => {
        if (refreshing) return

        setRefresh(true)
        wait(1000).then(() => {
            setUpdateChart(false)
            getAssetsTotalInfo()
            setRefresh(false)
        })
    }

    const onChangeTab = (value) => {
        setTab(value.i)
    }

    const StyleContainer = {
        backgroundColor: styles.PRIMARY__BG__COLOR,
        flex: 1,
    }

    const StyleUnderline = {
        backgroundColor: applicationSettings.application_style.tab_style === '2.0' ? 'transparent' : styles.PRIMARY,
        borderRadius: 2,
        height: 2,
    }

    const StyleTabBar = { backgroundColor: styles.PRIMARY__BG__COLOR, borderColor: styles.DIVIDER__COLOR, height: 30 }

    const StyleBgPrimary = { backgroundColor: styles.PRIMARY__BG__COLOR }

    const StyleBgPrimaryActive =
        applicationSettings.application_style.tab_style === '2.0'
            ? { backgroundColor: styles.TABBAR__BG__COLOR, borderTopRightRadius: 6, borderTopLeftRadius: 6, marginLeft: 2 }
            : { backgroundColor: styles.PRIMARY__BG__COLOR }

    const StyleTextPrimary = { color: applicationSettings.application_style.tab_style === '2.0' ? '#fff' : styles.PRIMARY }

    const StyleTextSecond = { color: styles.SECOND__CONTENT__COLOR }

    return (
        <>
            <View style={{ flexDirection: 'row', marginHorizontal: dimensions.moderate(6, 0.3) }}>
                {userInfo.sub_list.length < 2 ? (
                    <Account navigation={navigation} noPadding={true} />
                ) : (
                    <Account changeAll={changeAllSub} changeSub={changeSub} isAll={isAllSub} navigation={navigation} noPadding={true} showSubAll={true} />
                )}
            </View>
            <View style={[StyleContainer, { marginBottom: 50, flex: 1 }]}>
                <Tabs
                    page={tab}
                    renderTabBar={(props) => (
                        <ScrollableTab {...props} backgroundColor={styles.PRIMARY__BG__COLOR} style={StyleTabBar} underlineStyle={StyleUnderline} />
                    )}
                    onChangeTab={onChangeTab}
                >
                    <Tab
                        activeTabStyle={StyleBgPrimaryActive}
                        activeTextStyle={StyleTextPrimary}
                        heading={t('sb_assetsMng')}
                        tabStyle={StyleBgPrimary}
                        textStyle={StyleTextSecond}
                    >
                        <Container>
                            <ScrollView style={StyleContainer}>
                                <AssetPart
                                    assetInfo={assetInfo}
                                    dataPieChart={dataPieChart}
                                    dataStock={dataStock}
                                    isLoading={isLoading}
                                    isTimeout={isTimeout}
                                    navigation={navigation}
                                    objTotal={objTotal}
                                    refreshStockOwn={refreshStockOwn}
                                    setDataStock={setDataStock}
                                    tempList={tempList}
                                    updateChart={updateChart}
                                    userInfo={userInfo}
                                />
                                <View style={UI.bottomSpacing} />
                            </ScrollView>
                        </Container>
                    </Tab>
                    <Tab
                        activeTabStyle={StyleBgPrimaryActive}
                        activeTextStyle={StyleTextPrimary}
                        heading={t('title_cash')}
                        tabStyle={StyleBgPrimary}
                        textStyle={StyleTextSecond}
                    >
                        <Container>
                            <ScrollView style={StyleContainer}>
                                <Cash assetInfo={assetInfo} isTimeout={isTimeout} refreshStockOwn={refreshStockOwn} />
                                <View style={UI.bottomSpacing} />
                            </ScrollView>
                        </Container>
                    </Tab>
                    <Tab
                        activeTabStyle={StyleBgPrimaryActive}
                        activeTextStyle={StyleTextPrimary}
                        heading={t('total_debt')}
                        tabStyle={StyleBgPrimary}
                        textStyle={StyleTextSecond}
                    >
                        <Container>
                            <ScrollView style={StyleContainer}>
                                <Debt
                                    // assetInfo={assetInfo}
                                    isAllSubRef={isAllSubRef}
                                    isLoading={isLoading}
                                    isTimeout={isTimeout}
                                    refreshStockOwn={refreshStockOwn}
                                    setIsLoading={setIsLoading}
                                    setIsTimemout={setIsTimemout}
                                />
                                <View style={UI.bottomSpacing} />
                            </ScrollView>
                        </Container>
                    </Tab>
                    <Tab
                        activeTabStyle={StyleBgPrimaryActive}
                        activeTextStyle={StyleTextPrimary}
                        heading={t('sb_performance')}
                        tabStyle={StyleBgPrimary}
                        textStyle={StyleTextSecond}
                    >
                        <Container>
                            <ScrollView style={StyleContainer}>
                                <MyPerformance userInfo={userInfo} />
                                <View style={UI.bottomSpacing} />
                            </ScrollView>
                        </Container>
                    </Tab>
                    <Tab
                        activeTabStyle={StyleBgPrimaryActive}
                        activeTextStyle={StyleTextPrimary}
                        heading={t('profit_loss_calculator_title')}
                        tabStyle={StyleBgPrimary}
                        textStyle={StyleTextSecond}
                    >
                        <Container>
                            <ProfitLossCalculator isAllSub={isAllSubRef.current} navigation={navigation} />
                        </Container>
                    </Tab>
                </Tabs>
            </View>
            <View style={{ backgroundColor: styles.PRIMARY__BG__COLOR, position: 'absolute', bottom: 0, width: dimensions.WIDTH }}>
                <View
                    style={[
                        UI.view_total,
                        {
                            borderColor: totalValue >= 0 ? styles.UP__COLOR : styles.DOWN__COLOR,
                            backgroundColor: totalValue >= 0 ? styles.UP__COLOR + '1a' : styles.DOWN__COLOR + '1a',
                        },
                    ]}
                >
                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                        <Text
                            style={{
                                fontSize: fontSizes.small,
                                fontWeight: fontWeights.medium,
                                color: styles.PRIMARY__CONTENT__COLOR,
                                marginLeft: dimensions.moderate(8),
                            }}
                        >
                            {t('profit_loss')}
                        </Text>
                    </View>

                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                        <Text
                            style={{
                                color: totalValue >= 0 ? styles.UP__COLOR : styles.DOWN__COLOR,
                                fontSize: fontSizes.small,
                                fontWeight: fontWeights.medium,
                                textAlign: 'right',
                            }}
                        >
                            {FormatNumber(totalValue)}
                        </Text>
                        <Text
                            style={{
                                color: totalValue >= 0 ? styles.UP__COLOR : styles.DOWN__COLOR,
                                fontSize: fontSizes.verySmall,
                                opacity: 0.64,
                                textAlign: 'right',
                            }}
                        >
                            {' ('}
                            {FormatNumber(totalValueRatio, 2)}
                            {'%)'}
                        </Text>
                    </View>
                </View>
            </View>
        </>
    )
}

function MainPage({ navigation }) {
    useCustomInteraction()
    const { theme, styles, authFlag } = useContext(StoreContext)

    const [, updateState] = useState()
    const forceUpdate = useCallback(() => updateState({}), [])

    useEffect(() => {
        glb_sv.focusAssetInfo = true
        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.EKYC_SUCCESS) {
                forceUpdate()
            }
        })

        return () => {
            glb_sv.focusAssetInfo = false
            commonEvent.unsubscribe()
        }
    }, [])

    useEffect(() => {
        if (!authFlag && !SyncStorage.get(STORE_KEY.AutoLoginMode)) {
            InteractionManager.runAfterInteractions(() => {
                setTimeout(() => {
                    navigation.navigate(Screens.SIGN_IN)
                }, 0)
            })
        }
    }, [authFlag])

    const StyleContainer = {
        backgroundColor: styles.PRIMARY__BG__COLOR,
        flex: 1,
    }

    if (!authFlag || glb_sv.objShareGlb.userInfo.c9 === 'N') {
        return <NotAuthView isBottom={true} navigation={navigation} />
    }

    return (
        <SafeAreaView edges={['top']} style={StyleContainer}>
            <FocusAwareStatusBar backgroundColor={'transparent'} barStyle={theme.includes('DARK') ? 'light-content' : 'dark-content'} translucent={true} />
            <View style={{ flex: 1 }}>
                <AssetInfos navigation={navigation} />
            </View>
        </SafeAreaView>
    )
}

export default memo(MainPage)

const UI = StyleSheet.create({
    bottomSpacing: { height: Platform.OS === 'ios' ? 250 : 150 },
    view_total: {
        borderRadius: 8,
        borderWidth: 0.5,
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginHorizontal: dimensions.moderate(8),
        marginVertical: 8,
        padding: dimensions.moderate(8),
    },
})
