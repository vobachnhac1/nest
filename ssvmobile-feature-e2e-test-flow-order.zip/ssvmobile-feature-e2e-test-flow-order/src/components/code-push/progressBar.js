import React, { Component } from 'react'
import { Animated, Easing, Image, StyleSheet, Text, View } from 'react-native'
import PropTypes from 'prop-types'

export default class CusProgressBar extends Component {
    static propTypes = {
        ...View.propTypes,
        progress: PropTypes.number,
        buffer: PropTypes.number,
        progressColor: PropTypes.string,
        bufferColor: PropTypes.string,
        progressAniDuration: PropTypes.number,
        bufferAniDuration: PropTypes.number,
    }

    static defaultProps = {
        progressColor: '#89C0FF',
        bufferColor: 'rgba(255,0,0,0.7)',
        progressAniDuration: 100,
        bufferAniDuration: 100,
    }

    constructor(props) {
        super(props)
        this._progressAni = new Animated.Value(0)
        this._bufferAni = new Animated.Value(0)
        this.progressRef = React.createRef()
        this.bufferRef = React.createRef()
    }

    componentWillReceiveProps(nextProps) {
        console.log('---componentWillReceiveProps')
        console.log(nextProps)
        this._progress = nextProps.progress
        this._buffer = nextProps.buffer
    }

    UNSAFE_componentWillMount() {
        this._progress = this.props.progress
        this._buffer = this.props.buffer
    }

    render() {
        return (
            <View style={[{ height: 15, width: 200, backgroundColor: '#ddd', borderRadius: 7.5 }, this.props.style]}>
                <View style={[{ height: 15, width: 200, backgroundColor: '#ddd', borderRadius: 7.5 }, this.props.style]} onLayout={this._onLayout.bind(this)}>
                    <Animated.View
                        ref={this.progressRef}
                        style={{
                            position: 'absolute',
                            width: this._progressAni,
                            backgroundColor: this.props.progressColor,
                            borderRadius: 7.5,
                        }}
                    />
                </View>
                <Animated.View
                    ref={this.bufferRef}
                    style={{
                        position: 'absolute',
                        width: 33,
                        height: 15,
                        alignItems: 'center',
                        justifyContent: 'center',
                        flexDirection: 'row',
                        marginLeft: this._bufferAni,
                    }}
                >
                    <Text style={{ color: '#fff', fontSize: 10 }}>{this.props.currProgress}</Text>
                    <Image resizeMode={'contain'} source={require('./airplane.png')} style={{ width: 15, height: 15, marginLeft: 2 }} />
                </Animated.View>
            </View>
        )
    }

    _onLayout({
        nativeEvent: {
            layout: { width, height },
        },
    }) {
        if (width > 0 && this.totalWidth !== width) {
            const progress = this._getProgress()
            const buffer = this._getBuffer()
            this.totalWidth = width
            progress.setNativeProps({
                style: {
                    height: height,
                },
            })

            buffer.setNativeProps({
                style: {
                    height: height,
                },
            })

            this._startAniProgress(this.progress)
            this._startAniBuffer(this.buffer)
        }
    }

    _startAniProgress(progress) {
        if (this._progress >= 0 && this.totalWidth !== 0) {
            Animated.timing(this._progressAni, {
                toValue: progress * this.totalWidth,
                duration: this.props.progressAniDuration,
                easing: Easing.linear,
                useNativeDriver: false,
            }).start()
        }
    }

    _startAniBuffer(buffer) {
        if (this._buffer >= 0 && this.totalWidth !== 0) {
            Animated.timing(this._bufferAni, {
                toValue: buffer * this.totalWidth,
                duration: this.props.bufferAniDuration,
                useNativeDriver: false,
            }).start()
        }
    }

    _getProgress() {
        if (typeof this.progressRef.current !== 'undefined') {
            return this.progressRef.current
        }
        return this.progressRef.current
    }

    _getBuffer() {
        if (typeof this.bufferRef.current !== 'undefined') {
            return this.bufferRef.current
        }
        return this.bufferRef.current
    }
}

Object.defineProperty(CusProgressBar.prototype, 'progress', {
    set(value) {
        if (value >= 0 && this._progress !== value) {
            this._progress = value
            this._startAniProgress(value)
        }
    },
    get() {
        return this._progress
    },
    enumerable: true,
})

Object.defineProperty(CusProgressBar.prototype, 'buffer', {
    set(value) {
        if (value >= 0 && this._buffer !== value) {
            this._buffer = value
            this._startAniBuffer(value)
        }
    },
    get() {
        return this._buffer
    },
    enumerable: true,
})
