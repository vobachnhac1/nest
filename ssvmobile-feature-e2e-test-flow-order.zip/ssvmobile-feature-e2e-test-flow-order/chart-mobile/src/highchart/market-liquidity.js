/* eslint-disable react-native/no-raw-text */
import React, { useEffect, useRef, useState } from 'react'
import { renderToString } from 'react-dom/server'
import dayjs from 'dayjs'
import Highcharts from 'highcharts'
import HighchartsReact from 'highcharts-react-official'

import FormatNumber from '../formatNumber/FormatNumber'

const HighChartLiquity = () => {
    const [dataChart, setDataChart] = useState([])
    const [liquidityData5Day, setLiquidityData5Day] = useState([])

    const chartRef = useRef(null)

    useEffect(() => {
        const eventMarket = window.eventMarket.subscribe((msg) => {
            if (msg.type === 'highchart-liquity') {
                convertedAndUpdateData()
            }
            if (msg.type === 'highchart-liquity-avg-5days') {
                // convertedAndUpdateData()
                setTimeout(() => {
                    const data = window.DataLiquity5day || []
                    setLiquidityData5Day((prev) => [...data])
                }, 500)
            }
            if (msg.type === 'change-language') {
                chartRef.current?.chart.redraw(false)
            }
        })
        convertedAndUpdateData()
        return () => {
            eventMarket?.unsubscribe()
        }
    }, [])

    const convertedAndUpdateData = () => {
        setTimeout(() => {
            const data = window.DataLiquity || []
            setDataChart([...data])
        }, 100)
    }

    const options = {
        chart: {
            type: 'area',
            // height: heightChart,
        },
        title: {
            text: '',
        },
        subtitle: {
            text: '',
        },
        xAxis: {
            lineWidth: 0,
            minorGridLineWidth: 0,
            labels: {
                formatter: function () {
                    const text = String(dayjs(this.value).format('HH:mm'))
                    return text
                },
                padding: 0,
                style: { fontSize: 'var(--normal)', color: 'var(--TEXT__1)' },
            },
            tickInterval: 1800000,
            minorTickLength: 0,
            tickLength: 0,
            // min: dataRef[0][0],
            // max: dataRef[1][0],
        },
        yAxis: {
            min: 8,
            title: {
                formatter: function () {
                    const text = String(dayjs(this.value).format('HH:mm'))
                    return text
                },
                text: window.title_liquidity_trading_value + ' (' + window.unit_billions + ' VND)',
                style: {
                    color: 'var(--TEXT__1)',
                    fontSize: 'var(--xnormal)',
                },
            },
            labels: {
                style: {
                    color: 'var(--TEXT__1)',
                    fontSize: 'var(--xnormal)',
                },
                formatter: function () {
                    return '<span style="font-size: var(--normal);">' + FormatNumber(this.value / 1000000000, 0, 1, 'short') + '</span>'
                },
            },
        },
        tooltip: {
            formatter: function () {
                return renderToString(<TooltipComponent node={this} />)
            },
            shared: true,
            useHTML: true,
        },
        plotOptions: {
            column: {
                pointPadding: 0.2,
                borderWidth: 0,
            },
            series: {
                boostThreshold: 500,
                connectNulls: true,
                animation: false,
                marker: {
                    enabled: false,
                    radius: 4,
                },
                line: {
                    animation: false,
                    lineWidth: 1,
                },
            },
            line: {
                animation: false,
                lineWidth: 2,
            },
            area: {
                fillOpacity: 0.4,
            },
        },
        legend: { itemStyle: { color: 'var(--TEXT__1)', fontSize: 'var(--xnormal)' }, itemHoverStyle: { color: 'var(--TEXT__1)' } },
        series: [
            {
                name: window.avg_5days_trading_value, //"Trading value avg 5 days",//window.avg_5days_trading_value, //t('avg_5days_trading_value'),
                color: window.colorsTheme?.LIQUIDITY__AREA__BRAND__COLOR__2 || '#704DFB',
                data: convertDataLineAVG5Days(liquidityData5Day, dataChart[0]?.T.slice(0, 8)), //convertDataLineAVG5Days(liquidityData5Day),
                dashStyle: 'solid',
            },
            {
                name: window.common_daily, //"Trading value" , //window.common_daily, //t('common_daily'),
                color: window.colorsTheme?.LIQUIDITY__AREA__BRAND__COLOR__1 || '#27D1E6',
                data: convertDataLine(dataChart),
                dashStyle: 'solid',
            },
            {
                name: '',
                color: 'transparent',
                data: convertDataLine(dataChart, 'ref'),
            },
        ],
        credits: { enabled: false },
    }

    const TooltipComponent = ({ node }) => {
        return (
            <div className="flex flex-direction-column" style={{ fontSize: 'var(--normal)', display: 'flex', flexDirection: 'column' }}>
                <div className="flex-1" style={{ flex: 1 }}>
                    <span>{window.hist_ord_dt_time}: </span>
                    {/* <span>{'Time'}: </span> */}
                    <span style={{ fontWeight: 'bold' }}>{String(dayjs(node.x).format('HH:mm:ss'))}</span>
                </div>
                {/* <br /> */}
                <div className="flex-1" style={{ flex: 1 }}>
                    <span>
                        {node.points[0]?.color === window.colorsTheme?.LIQUIDITY__AREA__BRAND__COLOR__1
                            ? window.title_liquidity_trading_value
                            : window.avg_5days_trading_value}
                        :{' '}
                    </span>
                    {/* <span>{node.points[0]?.color === window.colorsTheme?.LIQUIDITY__AREA__BRAND__COLOR__1 ? 'Trading value' : 'Trading value avg 5 days'}: </span> */}
                    <span style={{ fontWeight: 'bold' }}>{FormatNumber(node.points[0]?.y, 0, 0, 'short')}</span>
                </div>
                {node?.points[1] ? (
                    <div className="flex-1" style={{ flex: 1 }}>
                        <span>
                            {node.points[1]?.color === window.colorsTheme?.LIQUIDITY__AREA__BRAND__COLOR__1
                                ? window.title_liquidity_trading_value
                                : window.avg_5days_trading_value}
                            :{' '}
                        </span>
                        {/* <span>{node.points[1]?.color === window.colorsTheme?.LIQUIDITY__AREA__BRAND__COLOR__1 ? 'Trading value' : 'Trading value avg 5 days'}: </span> */}
                        <span style={{ fontWeight: 'bold' }}>{FormatNumber(node.points[1]?.y, 0, 0, 'short')}</span>
                    </div>
                ) : null}
            </div>
        )
    }

    return (
        <div id="highcharts-liquidity" style={{ height: 'calc(100vh)', width: 'calc(100vw)' }}>
            {/* <span style={{ color: 'red' }}>{JSON.stringify(convertDataLineAVG5Days(liquidityData5Day, dataChart[0]?.T.slice(0, 8))).slice(0, 300)}</span> */}
            {/* <span style={{ color: 'red' }}>none</span> */}
            {/* {loading ? <span style={{ color: 'red'}}> Loading </span> : null} */}
            <HighchartsReact
                callback={(chart) => {
                    const elm = document.getElementById('highcharts-liquidity')
                    chart.update({
                        chart: {
                            height: elm?.offsetHeight,
                        },
                    })
                }}
                highcharts={Highcharts}
                options={options}
                ref={chartRef}
            />
        </div>
    )
}

export default HighChartLiquity

const convertDataLine = (data, type) => {
    if (type === 'ref') {
        const firts = { ...data[0] }
        const serverTime = firts.T?.slice(0, 8) || '20210222'
        return [
            [dayjs(serverTime, 'YYYYMMDD').hour(9).valueOf(), 0],
            [dayjs(serverTime, 'YYYYMMDD').hour(15).valueOf(), 0],
        ]
    }
    // const minTime = dayjs('20210222', 'YYYYMMDD').hour(9).valueOf()
    // const maxTime = dayjs('20210222', 'YYYYMMDD').hour(15).valueOf()
    // let prevTime = 0

    const newData = []
    data.forEach((item) => {
        let value = 0
        const time = item.time //dayjs('20210222' + item?.t52?.slice(8, 100), 'YYYYMMDD-HH:mm:ss').valueOf()
        if (item.TV) {
            value = Number(item.TV)
        } else {
            value = null
            // return
        }
        // value = item.V

        // if (item.U10 === '01') {
        // } else {
        //     value = item.t211 + item.t221 + item.t241
        // }
        newData.push([time, value])
        // if (time >= minTime && time <= maxTime) {
        // }
    })
    // console.log('newData', newData.length, newData)
    return newData
}

const convertDataLineAVG5Days = (data, serverTime = '20210222') => {
    // const minTime = dayjs(serverTime, 'YYYYMMDD').hour(9).valueOf()
    // const maxTime = dayjs(serverTime, 'YYYYMMDD').hour(15).valueOf()
    const newData = []
    data.forEach((item) => {
        const value = Number(item.c3)
        const time = dayjs(serverTime + '-' + item.c1, 'YYYYMMDD-HH:mm:ss').valueOf()

        // if (time >= minTime && time <= maxTime) {
        newData.push([time, Number(value)])
        // }
    })
    return newData
}
