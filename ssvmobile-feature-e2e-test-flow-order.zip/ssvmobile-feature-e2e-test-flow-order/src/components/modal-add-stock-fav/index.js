import React, { memo, useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { InteractionManager, ScrollView, TouchableOpacity, TouchableWithoutFeedback, View } from 'react-native'
import Modal from 'react-native-modal'
import Svg, { Path, Rect } from 'react-native-svg'
import { Button, Toast } from 'native-base'

import { Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { dimensions, fontSizes, fontWeights } from '../../styles'
import { eventList, glb_sv, reqFunct, saveStatisticTrackingStock } from '../../utils'
import sendRequest from '../../utils/sendRequest'
import { AddStockToListFav, RemoveStockInListFav } from '../portfolio/favorite-func/favorite.action'

const ServiceInfo = {
    AddStockToFavList: {
        reqFunct: reqFunct.ADD_STOCK_TO_FAV_LIST,
        WorkerName: 'FOSxID01',
        ServiceName: 'FOSxID01_FavoritesMgt',
        ClientSentTime: '0',
        Operation: 'I',
    },
    removeStockFromFavList: {
        reqFunct: reqFunct.REMOVE_STOCK_IN_FAV_LIST,
        WorkerName: 'FOSxID01',
        ServiceName: 'FOSxID01_FavoritesMgt',
        ClientSentTime: '0',
        Operation: 'D',
    },
}

const AddStockFav = ({ isModalVisible, setModal, setVisibleAddModal, selectStock, onChangeStatus, onChangeStatusStk }) => {
    const { t } = useTranslation()
    const { styles } = useContext(StoreContext)

    const [allListFav, setAllListFav] = useState(glb_sv.allListFav)

    const currentAction = useRef(null)

    useEffect(() => {
        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.CHANGE_LIST_FAV || msg.type === eventList.CHANGE_LIST_STOCK || msg.type === eventList.CHANGE_LIST_ACTIVE) {
                setAllListFav([...glb_sv.allListFav])
            }
        })

        return () => {
            commonEvent.unsubscribe()
        }
    }, [])

    const handleAddStockToFavList = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            if (message.Code === '010012') {
                Toast.show({
                    text: t('request_hanlde_not_success_try_again'),
                    type: 'warning',
                    position: 'bottom',
                })
            } else {
                Toast.show({
                    text: message.Message,
                    type: 'warning',
                    position: 'bottom',
                })
            }
            return
        } else {
            try {
                const current = glb_sv.allListFav.find((x) => x.c1 === reqInfoMap.inputParam[1])
                current.ListStock.push(selectStock)
                setAllListFav([...glb_sv.allListFav])
                if (glb_sv.activeList.c1 === current.c1) {
                    glb_sv.activeList = { ...current }
                    glb_sv.commonEvent.next({ type: eventList.CHANGE_LIST_STOCK, value: selectStock, isSub: true })
                } else {
                    setTimeout(() => {
                        onChangeStatus()
                    }, 0)
                }
                onChangeStatusStk && onChangeStatusStk(true)
                if (glb_sv.allListFav.filter((e) => e.type === 'watchlist').length === 1) {
                    setTimeout(() => {
                        setModal(false)
                    }, 500)
                }
            } catch (err) {
                console.log('error', err)
            }
        }
    }

    const handleRmStkFrFavList = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            if (message.Code === '010012') {
                Toast.show({
                    text: t('request_hanlde_not_success_try_again'),
                    type: 'warning',
                    position: 'bottom',
                })
            } else {
                Toast.show({
                    text: message.Message,
                    type: 'warning',
                    position: 'bottom',
                })
            }
            return
        } else {
            try {
                const current = glb_sv.allListFav.find((x) => x.c1 === reqInfoMap.inputParam[1])
                current.ListStock = current.ListStock.filter((e) => e !== selectStock)
                setAllListFav([...glb_sv.allListFav])
                if (glb_sv.activeList.c1 === current.c1) {
                    glb_sv.activeList = { ...current }
                    glb_sv.commonEvent.next({ type: eventList.CHANGE_LIST_STOCK, value: selectStock, isSub: false })
                } else {
                    setTimeout(() => {
                        onChangeStatus()
                    }, 100)
                }
                const isFav = glb_sv.allListFav
                    .filter((e) => e.type === 'watchlist')
                    .find((e) => {
                        if (e.ListStock.find((stk) => stk === selectStock)) {
                            return e
                        }
                    })
                if (isFav) {
                    onChangeStatusStk && onChangeStatusStk(true)
                } else {
                    onChangeStatusStk && onChangeStatusStk(false)
                }
                if (glb_sv.allListFav.filter((e) => e.type === 'watchlist').length === 1) {
                    setTimeout(() => {
                        setModal(false)
                    }, 500)
                }
            } catch (err) {
                console.log('error', err)
            }
        }
    }

    const hanldeStockFav = (item) => {
        if (!selectStock) return
        const value = !checkExistInWatchList(item.ListStock, selectStock)

        if (glb_sv.authFlag) {
            if (value) {
                const InputParams = ['FAV_ITEM_ADD', item.c1, selectStock]
                sendRequest(ServiceInfo.AddStockToFavList, InputParams, handleAddStockToFavList, true, handleStockFavTimeout)

                saveStatisticTrackingStock(selectStock)
            }
            if (value === false) {
                const InputParams = ['FAV_ITEM_REMOVE', item.c1, selectStock]
                sendRequest(ServiceInfo.removeStockFromFavList, InputParams, handleRmStkFrFavList, true, handleStockFavTimeout)
            }
        } else {
            if (value) {
                AddStockToListFav(item.c1, selectStock)
                if (glb_sv.allListFav.filter((e) => e.type === 'watchlist').length === 1) {
                    setTimeout(() => {
                        setModal(false)
                    }, 500)
                }
            }
            if (value === false) {
                RemoveStockInListFav(item.c1, selectStock)
                if (glb_sv.allListFav.filter((e) => e.type === 'watchlist').length === 1) {
                    setTimeout(() => {
                        setModal(false)
                    }, 500)
                }
            }
            setAllListFav([...glb_sv.allListFav])

            const isFav = glb_sv.allListFav.find((e) => {
                if (e.ListStock.find((stk) => stk === selectStock)) {
                    return e
                }
            })
            if (isFav) {
                onChangeStatusStk && onChangeStatusStk(true)
            } else {
                onChangeStatusStk && onChangeStatusStk(false)
            }

            setTimeout(() => {
                onChangeStatus()
            }, 100)
        }
    }

    const handleStockFavTimeout = () => {
        Toast.show({
            text: t('request_hanlde_not_success_try_again'),
            type: 'warning',
            position: 'bottom',
        })
    }

    const checkExistInWatchList = (ListStock, stock) => {
        if (ListStock.some((e) => e === stock)) return true
        return false
    }

    const addNewFav = () => {
        setModal(false)
        InteractionManager.runAfterInteractions(() => {
            setTimeout(() => {
                setVisibleAddModal(true)
            }, 0)
        })
    }

    const dismiss = () => {
        setModal(false)
    }

    return (
        <Modal
            coverScreen={false}
            customBackdrop={
                <TouchableWithoutFeedback onPress={dismiss}>
                    <View
                        style={{
                            flex: 1,
                            backgroundColor: '#000',
                        }}
                    />
                </TouchableWithoutFeedback>
            }
            hideModalContentWhileAnimating={true}
            isVisible={isModalVisible}
            useNativeDriver={true}
            onBackButtonPress={dismiss}
            onBackdropPress={dismiss}
        >
            <View
                style={{
                    backgroundColor: styles.HEADER__BG__COLOR,
                    padding: dimensions.moderate(24),
                    justifyContent: 'flex-start',
                    borderRadius: 4,
                    borderColor: 'rgba(0, 0, 0, 0.1)',
                }}
            >
                <Text style={{ fontSize: fontSizes.xmedium, fontWeight: fontWeights.semiBold, color: styles.PRIMARY__CONTENT__COLOR }}>{t('favorites')}</Text>
                <ScrollView style={{ minHeight: dimensions.HIEGHT * 0.3, maxHeight: dimensions.HIEGHT * 0.6, marginTop: dimensions.vertical(17) }}>
                    {allListFav
                        .filter((e) => e.type === 'watchlist')
                        .map((item, index) => (
                            <TouchableOpacity
                                activeOpacity={1}
                                key={item.c1}
                                style={{ flexDirection: 'row', paddingVertical: dimensions.vertical(12) }}
                                onPress={() => hanldeStockFav(item)}
                            >
                                <CheckboxIcon
                                    active={checkExistInWatchList(item.ListStock, selectStock)}
                                    colorActive={styles.GREEN__COLOR}
                                    colorunActive={styles.ICON__PRIMARY}
                                />
                                <Text
                                    style={{
                                        color: styles.PRIMARY__CONTENT__COLOR,
                                        opacity: checkExistInWatchList(item.ListStock, selectStock) ? 1 : 0.64,
                                        marginLeft: dimensions.vertical(8),
                                        fontSize: fontSizes.medium,
                                    }}
                                >
                                    {item.c2}
                                </Text>
                            </TouchableOpacity>
                        ))}
                </ScrollView>
                <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                    <Button noBorder transparent onPress={addNewFav}>
                        <PlusIcon color={styles.PRIMARY} />
                        <Text style={{ color: styles.GREEN__COLOR, fontSize: fontSizes.medium }}> {t('add_new_favorites')}</Text>
                    </Button>
                </View>
                <View style={{ flexDirection: 'row', justifyContent: 'center', marginTop: 36 }}>
                    <Button
                        style={{
                            borderRadius: 8,
                            backgroundColor: styles.PRIMARY,
                            height: dimensions.vertical(42),
                            width: dimensions.moderate(231),
                            alignItems: 'center',
                            justifyContent: 'center',
                        }}
                        onPress={() => setModal(false)}
                    >
                        <Text style={{ color: '#FFF', fontSize: fontSizes.medium }}>{t('common_Close')}</Text>
                    </Button>
                </View>
            </View>
        </Modal>
    )
}

export default memo(AddStockFav)

const CheckboxIcon = memo(CheckboxIconMemo)
function CheckboxIconMemo({ colorActive, colorunActive, active }) {
    if (active)
        return (
            <Svg fill="none" height={24} viewBox="0 0 24 24" width={24} xmlns="http://www.w3.org/2000/svg">
                <Path d="M0 12C0 5.383 5.383 0 12 0s12 5.383 12 12-5.383 12-12 12S0 18.617 0 12z" fill={colorActive} opacity={0.2} />
                <Path
                    d="M12.125 4C7.645 4 4 7.645 4 12.125s3.645 8.125 8.125 8.125 8.125-3.645 8.125-8.125S16.605 4 12.125 4zm4.229 5.402l-5.25 6.25a.625.625 0 01-.47.223h-.01a.625.625 0 01-.464-.207l-2.25-2.5a.625.625 0 11.929-.836l1.769 1.966 4.788-5.7a.625.625 0 01.957.804z"
                    fill={colorActive}
                />
            </Svg>
        )
    else
        return (
            <Svg height={24} viewBox="0 0 20 20" width={24} xmlns="http://www.w3.org/2000/svg">
                <Path d="M1 10c0-4.962 4.038-9 9-9s9 4.038 9 9-4.038 9-9 9-9-4.038-9-9z" opacity={0.64} stroke={colorunActive} strokeWidth={2} />
            </Svg>
        )
}

const PlusIcon = memo(PlusIconMemo)
function PlusIconMemo({ color }) {
    return (
        <Svg height={20} viewBox="0 0 20 20" width={20} xmlns="http://www.w3.org/2000/svg">
            <Rect fill={color} height={20} rx={2} width={20} />
            <Path d="M10 5.816v7.812M13.906 9.722H6.094" stroke="#fff" strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.563} />
        </Svg>
    )
}
