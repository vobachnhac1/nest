import React, { memo, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Animated, FlatList, InteractionManager, ScrollView, StyleSheet, View } from 'react-native'
import { ScrollableTab, Tab, Tabs } from 'native-base'
import SyncStorage from 'sync-storage'

import { useCustomInteraction } from '../../../hoc'
import { StoreContext } from '../../../store'
import { dimensions, fontSizes, fontWeights } from '../../../styles'
import { eventList, FormatNumber, glb_sv, reqFunct, sendRequest, STORE_KEY, subcribeFunctStream } from '../../../utils'
import HeaderTop from './HeaderTop'
import OptionsTop from './OptionsTop'
import RowTop from './RowTop'

const ServiceInfo = {
    GET_MARKET_TOP: {
        reqFunct: reqFunct.GET_MARKET_TOP,
        WorkerName: 'FOSqMkt02',
        ServiceName: 'FOSqMkt02_MktInfo',
        Operation: 'Q',
        ClientSentTime: '0',
    },
}

const listTimeHis = ['1W', '1M', '3M', '6M', '1Y', '2Y', '3Y']

function TopMaket({ active, navigateStockInfo, handleScrollTop = {} }) {
    useCustomInteraction()
    const { styles, fractionPrice, applicationSettings } = useContext(StoreContext)
    const { t } = useTranslation()
    const dataRef = useRef([])
    const [type, setType] = useState(glb_sv.TYPE_TOP_MARKET)
    const [page, setPage] = useState(0)

    const [activeOtp, setActiveOtp] = useState('1D')
    const activeOtpRef = useRef('1D')

    const [loading, setLoading] = useState(true)

    const timeoutChangeTabRef = useRef(null)

    const [dataTopValue, setDataTopValue] = useState([])
    const [dataTopVolume, setDataTopVolume] = useState([])
    const [dataTopFrg, setDataTopFrg] = useState([])
    const [dataTopInc, setDataTopInc] = useState([])
    const [dataTopDec, setDataTopDec] = useState([])

    const isSub = useRef(false)

    const sortRef = useRef('')
    const [sort, setSort] = useState('')

    const activeRef = useRef('')

    useEffect(() => {
        hanldeData()

        const eventMarket = glb_sv.eventMarket.subscribe((msg) => {
            if (msg.type === eventList.MKT_TOP && glb_sv.TYPE_TOP_MARKET === msg.TOP) {
                if (activeOtpRef.current !== '1D') return
                changeTypeSortData()
                setLoading(false)
                return
            } else if (msg.type === eventList.RECONNECT_MARKET) {
                changeTypeSortData()
                return
            } else if (msg.type === eventList.RESET_DATA) {
                setDataTopValue([])
                setDataTopVolume([])
                setDataTopFrg([])
                setDataTopInc([])
                setDataTopDec([])
                return
            } else if (msg.type === eventList.FOCUS_MARKET) {
                if (msg.value === true && !isSub.current) {
                    isSub.current = true
                    hanldeData()
                } else if (msg.value === false && isSub.current) {
                    isSub.current = false
                    if (activeOtpRef.current === '1D') {
                        if (active.includes('HNXUpcomIndex')) {
                            subcribeFunctStream('UNSUB', [glb_sv.TYPE_TOP_MARKET], ['UPC'])
                        } else if (active.includes('HNX')) {
                            subcribeFunctStream('UNSUB', [glb_sv.TYPE_TOP_MARKET], ['HNX'])
                        } else {
                            subcribeFunctStream('UNSUB', [glb_sv.TYPE_TOP_MARKET], ['HSX'])
                        }
                    }
                }
                return
            }
        })

        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.CHANGE_TAB_TOP_MARKET && msg.isHeader) {
                changeTab({ i: msg.tab })
            } else if (msg.type === eventList.CHANGE_OPTIONS_TOP_MARKET) {
                changeOtpion(msg.value)
            } else if (msg.type === eventList.TOP_MARKET_SORT_COLUMN) {
                sortRef.current = msg.value
                changeTypeSortData()
            } else if (msg.type === eventList.REQ_GET_MKT_INF_FIRST) {
                isSub.current = true
                hanldeData()
            }
        })
        return () => {
            eventMarket.unsubscribe()
            commonEvent.unsubscribe()
        }
    }, [active])

    const changeOtpion = (value) => {
        setActiveOtp(value)
        setDataTopValue([])
        setDataTopVolume([])
        setDataTopFrg([])
        setDataTopInc([])
        setDataTopDec([])
        setLoading(true)
        // handleScrollTop()

        activeOtpRef.current = value
        if (timeoutChangeTabRef.current) clearTimeout(timeoutChangeTabRef.current)
        timeoutChangeTabRef.current = setTimeout(() => {
            hanldeData()
        }, 500)
    }

    const hanldeData = () => {
        if (activeOtpRef.current === '1D') {
            changeTypeSortData()
            if (activeRef.current) {
                if (activeRef.current.includes('HNXUpcomIndex')) {
                    subcribeFunctStream('UNSUB', [glb_sv.TYPE_TOP_MARKET], ['UPC'])
                } else if (activeRef.current.includes('HNX')) {
                    subcribeFunctStream('UNSUB', [glb_sv.TYPE_TOP_MARKET], ['HNX'])
                } else {
                    subcribeFunctStream('UNSUB', [glb_sv.TYPE_TOP_MARKET], ['HSX'])
                }
            }
            activeRef.current = active
            if (active.includes('HNXUpcomIndex')) {
                subcribeFunctStream('SUB', [glb_sv.TYPE_TOP_MARKET], ['UPC'])
            } else if (active.includes('HNX')) {
                subcribeFunctStream('SUB', [glb_sv.TYPE_TOP_MARKET], ['HNX'])
            } else {
                subcribeFunctStream('SUB', [glb_sv.TYPE_TOP_MARKET], ['HSX'])
            }
        } else {
            if (active.includes('HNXUpcomIndex')) {
                subcribeFunctStream('UNSUB', [glb_sv.TYPE_TOP_MARKET], ['UPC'])
            } else if (active.includes('HNX')) {
                subcribeFunctStream('UNSUB', [glb_sv.TYPE_TOP_MARKET], ['HNX'])
            } else {
                subcribeFunctStream('UNSUB', [glb_sv.TYPE_TOP_MARKET], ['HSX'])
            }
            const index = active.includes('HSX') ? '01' : active.includes('HNXUpcomIndex') ? '05' : '03'
            let typee = 'TU'
            if (glb_sv.TYPE_TOP_MARKET === 'TOP_PRI_DOWN') typee = 'TD'
            if (glb_sv.TYPE_TOP_MARKET === 'TOP_QTY_UP') typee = 'TV'
            if (glb_sv.TYPE_TOP_MARKET === 'TOP_VAL_UP') typee = 'TA'
            if (glb_sv.TYPE_TOP_MARKET === 'FRG_VAL_UP') typee = 'FA'
            if (glb_sv.dataHisMrktop[activeOtpRef.current][glb_sv.TYPE_TOP_MARKET + index]) {
                changeTypeSortData()
                return
            }
            const inval = ['1', index, activeOtpRef.current, typee, '-1']
            sendRequest(ServiceInfo.GET_MARKET_TOP, inval, handleGetMarketTop, true, handleGetMarketTopTimeout)
            dataRef.current = []
        }
    }

    const handleGetMarketTopTimeout = () => {
        setLoading(false)
    }

    const handleGetMarketTop = (reqInfoMap, message) => {
        setLoading(false)
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) { }
            dataRef.current = dataRef.current.concat(jsondata)
            if (Number(message.Packet) <= 0) {
                const newData = dataRef.current.map((item) => {
                    return {
                        S: item.c3,
                        C: item.c6 * 1000,
                        CHGR: item.c11,
                        TVOL: item.c8,
                        TVAL: item.c9,
                        O: item.c4 * 1000,
                        FBA: item.c16 * 1e9,
                        FSA: item.c17 * 1e9,
                    }
                })

                const index = active.includes('HSX') ? '01' : active.includes('HNXUpcomIndex') ? '05' : '03'
                glb_sv.dataHisMrktop[activeOtpRef.current][glb_sv.TYPE_TOP_MARKET + index] = newData.slice()
                changeTypeSortData()
            }
        }
    }

    const changeTab = ({ i }) => {
        setPage(i)
        let tab = 'TOP_VAL_UP'
        if (i === 1) tab = 'TOP_QTY_UP'
        if (i === 2) tab = 'FRG_VAL_UP'
        if (i === 3) tab = 'TOP_PRI_UP'
        if (i === 4) tab = 'TOP_PRI_DOWN'
        glb_sv.commonEvent.next({ type: eventList.CHANGE_TAB_TOP_MARKET, tab: i, isTab: true })
        if (glb_sv.TYPE_TOP_MARKET === tab) return
        // handleScrollTop()

        if (active.includes('HNXUpcomIndex')) {
            subcribeFunctStream('UNSUB', [glb_sv.TYPE_TOP_MARKET], ['UPC'])
        } else if (active.includes('HNX')) {
            subcribeFunctStream('UNSUB', [glb_sv.TYPE_TOP_MARKET], ['HNX'])
        } else {
            subcribeFunctStream('UNSUB', [glb_sv.TYPE_TOP_MARKET], ['HSX'])
        }

        glb_sv.TYPE_TOP_MARKET = tab
        setType(tab)

        setLoading(true)
        SyncStorage.set(STORE_KEY.TYPE_TOP_MARKET, tab)

        if (activeOtpRef.current === '1D') {
            if (active.includes('HNXUpcomIndex')) {
                subcribeFunctStream('SUB', [glb_sv.TYPE_TOP_MARKET], ['UPC'])
            } else if (active.includes('HNX')) {
                subcribeFunctStream('SUB', [glb_sv.TYPE_TOP_MARKET], ['HNX'])
            } else {
                subcribeFunctStream('SUB', [glb_sv.TYPE_TOP_MARKET], ['HSX'])
            }
            setLoading(false)
        } else {
            setDataTopValue([])
            setDataTopVolume([])
            setDataTopFrg([])
            setDataTopInc([])
            setDataTopDec([])
            if (listTimeHis.includes(activeOtpRef.current)) {
                const index = active.includes('HSX') ? '01' : active.includes('HNXUpcomIndex') ? '05' : '03'
                let typee = 'TU'
                if (tab === 'TOP_PRI_DOWN') typee = 'TD'
                if (tab === 'TOP_QTY_UP') typee = 'TV'
                if (tab === 'TOP_VAL_UP') typee = 'TA'
                if (tab === 'FRG_VAL_UP') typee = 'FA'
                if (glb_sv.dataHisMrktop[activeOtpRef.current][tab + index]) {
                    changeTypeSortData()
                    setLoading(false)
                    return
                }
                const inval = ['1', index, activeOtpRef.current, typee, '-1']
                sendRequest(ServiceInfo.GET_MARKET_TOP, inval, handleGetMarketTop, true, handleGetMarketTopTimeout)
                dataRef.current = []
            }
        }
    }

    const changeTypeSortData = () => {
        InteractionManager.runAfterInteractions(() => {
            if (activeOtpRef.current === '1D') {
                if (glb_sv.TYPE_TOP_MARKET === 'TOP_VAL_UP') {
                    const newSortList = [...glb_sv.lastDataMarketTop.TOP_VAL_UP]
                    newSortList.sort(sortColumn)
                    setDataTopValue(newSortList)
                } else if (glb_sv.TYPE_TOP_MARKET === 'TOP_QTY_UP') {
                    const newSortList = [...glb_sv.lastDataMarketTop.TOP_QTY_UP]
                    newSortList.sort(sortColumn)
                    setDataTopVolume(newSortList)
                } else if (glb_sv.TYPE_TOP_MARKET === 'FRG_VAL_UP') {
                    const newSortList = [...glb_sv.lastDataMarketTop.FRG_VAL_UP]
                    newSortList.sort(sortColumn)
                    setDataTopFrg(newSortList)
                } else if (glb_sv.TYPE_TOP_MARKET === 'TOP_PRI_UP') {
                    const newSortList = [...glb_sv.lastDataMarketTop.TOP_PRI_UP]
                    newSortList.sort(sortColumn)
                    setDataTopInc(newSortList)
                } else if (glb_sv.TYPE_TOP_MARKET === 'TOP_PRI_DOWN') {
                    const newSortList = [...glb_sv.lastDataMarketTop.TOP_PRI_DOWN]
                    newSortList.sort(sortColumn)
                    setDataTopDec(newSortList)
                }
            } else {
                const index = active.includes('HSX') ? '01' : active.includes('HNXUpcomIndex') ? '05' : '03'
                if (glb_sv.dataHisMrktop[activeOtpRef.current][glb_sv.TYPE_TOP_MARKET + index]) {
                    const newData = glb_sv.dataHisMrktop[activeOtpRef.current][glb_sv.TYPE_TOP_MARKET + index].slice()
                    if (glb_sv.TYPE_TOP_MARKET === 'TOP_VAL_UP') setDataTopValue(newData.sort(sortColumn))
                    if (glb_sv.TYPE_TOP_MARKET === 'TOP_QTY_UP') setDataTopVolume(newData.sort(sortColumn))
                    if (glb_sv.TYPE_TOP_MARKET === 'FRG_VAL_UP') setDataTopFrg(newData.sort(sortColumn))
                    if (glb_sv.TYPE_TOP_MARKET === 'TOP_PRI_UP') setDataTopInc(newData.sort(sortColumn))
                    if (glb_sv.TYPE_TOP_MARKET === 'TOP_PRI_DOWN') setDataTopDec(newData.sort(sortColumn))
                    return
                }
            }
        })
    }

    function sortColumn(a, b) {
        const [key, direction] = sortRef.current.split('|')
        const newKey = getKeySortColumn(key)
        if (newKey === 'FBA_FSA') {
            const a_value = a.FBA - a.FSA
            const b_value = b.FBA - b.FSA
            if (direction === 'up') {
                if (a_value > b_value) return 1
                if (a_value < b_value) return -1
                return 0
            }
            if (direction === 'down') {
                if (a_value < b_value) return 1
                if (a_value > b_value) return -1
                return 0
            }
        }
        if (direction === 'up') {
            if (a[newKey] > b[newKey]) return 1
            if (a[newKey] < b[newKey]) return -1
            return 0
        }
        if (direction === 'down') {
            if (a[newKey] < b[newKey]) return 1
            if (a[newKey] > b[newKey]) return -1
            return 0
        }
    }

    const getKeySortColumn = (value) => {
        if (value === 'col1') return 'S'
        if (value === 'col2') return 'CHGR'
        if (value === 'col3') {
            if (glb_sv.TYPE_TOP_MARKET === 'FRG_VAL_UP') return 'FBA'
            else return 'O'
        }
        if (value === 'col4') {
            if (glb_sv.TYPE_TOP_MARKET === 'FRG_VAL_UP') return 'FSA'
            else return 'C'
        }
        if (value === 'col5') {
            if (glb_sv.TYPE_TOP_MARKET === 'FRG_VAL_UP') return 'FBA_FSA'
            else if (glb_sv.TYPE_TOP_MARKET !== 'TOP_VAL_UP') return 'TVOL'
            else return 'TVAL'
        }
    }

    const changeTypeSort = useCallback((changed) => {
        if (sortRef.current === '' || !sortRef.current.includes(changed)) {
            sortRef.current = changed + '|down'
            setSort(changed + '|down')
        } else if (sortRef.current === changed + '|down') {
            sortRef.current = changed + '|up'
            setSort(changed + '|up')
        } else if (sortRef.current === changed + '|up') {
            sortRef.current = ''
            setSort('')
        }
        changeTypeSortData()
    }, [])

    const PrimaryBG = useMemo(() => StyleSheet.flatten([{ backgroundColor: styles.PRIMARY__BG__COLOR }]), [styles])
    const PrimaryBGActive = useMemo(
        () =>
            StyleSheet.flatten([
                applicationSettings.application_style.tab_style === '2.0'
                    ? { backgroundColor: styles.ACTIVE__TAB__HIGHLIGHT__BG, borderTopRightRadius: 6, borderTopLeftRadius: 6, marginLeft: 2 }
                    : { backgroundColor: styles.PRIMARY__BG__COLOR },
            ]),
        [styles],
    )
    const textStyleUI = useMemo(() => StyleSheet.flatten([{ color: styles.SECOND__CONTENT__COLOR, ...UI.tab }]), [styles])
    const textActiveStyleUI = useMemo(
        () => StyleSheet.flatten([{ color: applicationSettings.application_style.tab_style === '2.0' ? '#fff' : styles.PRIMARY, ...UI.tab }]),
        [styles],
    )
    const ViewDividerUI = useMemo(() => StyleSheet.flatten([{ height: 37, backgroundColor: styles.PRIMARY__BG__COLOR }]), [styles])
    const HeaderTopWrapperUI = useMemo(
        () =>
            StyleSheet.flatten([
                {
                    backgroundColor: styles.PRIMARY__BG__COLOR,
                    paddingHorizontal: dimensions.moderate(12),
                },
            ]),
        [styles],
    )
    const ScrollableTabUI = useMemo(
        () =>
            StyleSheet.flatten([
                {
                    height: 30,
                    elevation: 0,
                    borderBottomColor: styles.DIVIDER__COLOR,
                    borderBottomWidth: 1,
                },
            ]),
        [styles],
    )

    const ScrollViewWrapUI = useMemo(
        () =>
            StyleSheet.flatten([
                {
                    backgroundColor: styles.PRIMARY__BG__COLOR,
                    marginVertical: dimensions.vertical(4),
                    position: 'absolute',
                    top: 34,
                    marginHorizontal: dimensions.moderate(12),
                },
            ]),
        [styles],
    )

    const StyleUnderline = useMemo(
        () =>
            StyleSheet.flatten([
                { backgroundColor: applicationSettings.application_style.tab_style === '2.0' ? 'transparent' : styles.PRIMARY, borderRadius: 2, height: 2 },
            ]),
        [styles],
    )

    return (
        <Tabs
            page={page}
            renderTabBar={(props) => (
                <View>
                    <ScrollableTab {...props} backgroundColor={styles.PRIMARY__BG__COLOR} style={ScrollableTabUI} underlineStyle={StyleUnderline} />
                    <View style={ViewDividerUI} />
                    <View style={HeaderTopWrapperUI}>
                        <HeaderTop activeOtp={activeOtp} changeTypeSort={changeTypeSort} sort={sort} typeTop={glb_sv.TYPE_TOP_MARKET} />
                    </View>
                    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={ScrollViewWrapUI}>
                        <OptionsTop active={activeOtp === '1D'} styles={styles} title={'1 ' + t('day')} value="1D" onChange={changeOtpion} />
                        <OptionsTop active={activeOtp === '1W'} styles={styles} title={'5 ' + t('day')} value="1W" onChange={changeOtpion} />
                        <OptionsTop active={activeOtp === '1M'} styles={styles} title={t('one_month')} value="1M" onChange={changeOtpion} />
                        <OptionsTop active={activeOtp === '3M'} styles={styles} title={t('three_month')} value="3M" onChange={changeOtpion} />
                        <OptionsTop active={activeOtp === '6M'} styles={styles} title={t('six_month')} value="6M" onChange={changeOtpion} />
                        <OptionsTop active={activeOtp === '1Y'} styles={styles} title={'1 ' + t('year')} value="1Y" onChange={changeOtpion} />
                        <OptionsTop active={activeOtp === '2Y'} styles={styles} title={'2 ' + t('year')} value="2Y" onChange={changeOtpion} />
                        <OptionsTop active={activeOtp === '3Y'} isLast={true} styles={styles} title={'3 ' + t('year')} value="3Y" onChange={changeOtpion} />
                    </ScrollView>
                </View>
            )}
            onChangeTab={(tab) => changeTab(tab)}
        >
            <Tab
                activeTabStyle={PrimaryBGActive}
                activeTextStyle={textActiveStyleUI}
                heading={t('top_10_stocks_value_trade')}
                tabStyle={PrimaryBG}
                textStyle={textStyleUI}
            >
                <DataTabsMemo
                    activeOtp={activeOtp}
                    data={dataTopValue}
                    fractionPrice={fractionPrice}
                    navigateStockInfo={navigateStockInfo}
                    styles={styles}
                    type={type}
                />
            </Tab>
            <Tab
                activeTabStyle={PrimaryBGActive}
                activeTextStyle={textActiveStyleUI}
                heading={t('top_10_stocks_shares_trade')}
                tabStyle={PrimaryBG}
                textStyle={textStyleUI}
            >
                <DataTabsMemo
                    activeOtp={activeOtp}
                    data={dataTopVolume}
                    fractionPrice={fractionPrice}
                    navigateStockInfo={navigateStockInfo}
                    styles={styles}
                    type={type}
                />
            </Tab>
            <Tab activeTabStyle={PrimaryBGActive} activeTextStyle={textActiveStyleUI} heading={t('top_value_frg')} tabStyle={PrimaryBG} textStyle={textStyleUI}>
                <DataTabsMemo
                    activeOtp={activeOtp}
                    data={dataTopFrg}
                    fractionPrice={fractionPrice}
                    navigateStockInfo={navigateStockInfo}
                    styles={styles}
                    type={type}
                    typeTop="FRG_VAL_UP"
                />
            </Tab>
            <Tab
                activeTabStyle={PrimaryBGActive}
                activeTextStyle={textActiveStyleUI}
                heading={t('top_10_stocks_incre')}
                tabStyle={PrimaryBG}
                textStyle={textStyleUI}
            >
                <DataTabsMemo
                    activeOtp={activeOtp}
                    data={dataTopInc}
                    fractionPrice={fractionPrice}
                    navigateStockInfo={navigateStockInfo}
                    styles={styles}
                    type={type}
                />
            </Tab>

            <Tab
                activeTabStyle={PrimaryBGActive}
                activeTextStyle={textActiveStyleUI}
                heading={t('top_10_stocks_decre')}
                tabStyle={PrimaryBG}
                textStyle={textStyleUI}
            >
                <DataTabsMemo activeOtp={activeOtp} data={dataTopDec} navigateStockInfo={navigateStockInfo} type={type} />
            </Tab>
        </Tabs>
    )
}

const DataTabsMemo = memo(({ data, navigateStockInfo, activeOtp, type, typeTop }) => {
    const { styles, fractionPrice } = useContext(StoreContext)

    const renderItem = useCallback(({ item }) => {
        return (
            <RowTop
                activeOtp={activeOtp}
                item={item}
                navigateStockInfo={navigateStockInfo}
                ratioValue={FormatNumber(item.CHGR, 2)} // col 2
                styles={styles}
                title={item.S} // col 1
                typeTop={typeTop}
                value={
                    typeTop === 'FRG_VAL_UP'
                        ? FormatNumber(item.FSA, 2, 0, 'short') // col 4
                        : item.C === 777777710000
                            ? 'ATO'
                            : item.C === 777777720000
                                ? 'ATC'
                                : fractionPrice
                                    ? FormatNumber(item.C / 1000, 2, 1)
                                    : FormatNumber(item.C, 0, 1)
                }
                value_market={
                    typeTop === 'FRG_VAL_UP'
                        ? FormatNumber(item.FBA - item.FSA, 2, 0, 'short') // col 5
                        : type !== 'TOP_VAL_UP'
                            ? FormatNumber(item.TVOL, 0, 1, 'short')
                            : FormatNumber(item.TVAL, 0, 1, 'short')
                }
                valueCol3={
                    typeTop === 'FRG_VAL_UP'
                        ? FormatNumber(item.FBA, 2, 0, 'short') // col 3
                        : fractionPrice
                            ? FormatNumber(item.O / 1000, 2, 1)
                            : FormatNumber(item.O, 0, 1)
                }
            />
        )
    })
    const FlatListWrapper = useMemo(
        () =>
            StyleSheet.flatten([
                {
                    backgroundColor: styles.PRIMARY__BG__COLOR,
                    flex: 1,
                    paddingHorizontal: dimensions.moderate(16),
                    minHeight: 400,
                },
            ]),
        [styles],
    )

    return (
        <View style={FlatListWrapper}>
            <FlatList
                data={data}
                keyExtractor={(item, index) => type + item.S + index}
                listKey={(item, index) => type + item.S + index}
                renderItem={renderItem}
                scrollEnabled={false}
                showsVerticalScrollIndicator={false}
            />
        </View>
    )
})

const HeaderTopMarketMemo = () => {
    const { styles, applicationSettings } = useContext(StoreContext)
    const { t } = useTranslation()
    const [page, setPage] = useState(0)
    const [activeOtp, setActiveOtp] = useState('1D')

    const sortRef = useRef('')
    const [sort, setSort] = useState('')

    useEffect(() => {
        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.CHANGE_TAB_TOP_MARKET && msg.isTab) {
                setPage(msg.tab)
            }
        })
        return () => {
            commonEvent.unsubscribe()
        }
    }, [])

    const changeTab = ({ i }) => {
        setPage(i)
        glb_sv.commonEvent.next({ type: eventList.CHANGE_TAB_TOP_MARKET, tab: i, isHeader: true })
    }

    const changeOtpion = (value) => {
        setActiveOtp(value)
        glb_sv.commonEvent.next({ type: eventList.CHANGE_OPTIONS_TOP_MARKET, value })
    }

    const changeTypeSort = useCallback((changed) => {
        if (sortRef.current === '' || !sortRef.current.includes(changed)) {
            sortRef.current = changed + '|down'
            setSort(changed + '|down')
        } else if (sortRef.current === changed + '|down') {
            sortRef.current = changed + '|up'
            setSort(changed + '|up')
        } else if (sortRef.current === changed + '|up') {
            sortRef.current = ''
            setSort('')
        }
        glb_sv.commonEvent.next({ type: eventList.TOP_MARKET_SORT_COLUMN, value: sortRef.current })
    }, [])

    const ScrollableTabUI = useMemo(
        () =>
            StyleSheet.flatten([
                {
                    height: 34,
                    elevation: 0,
                    borderBottomColor: styles.DIVIDER__COLOR,
                    borderBottomWidth: 1,
                },
            ]),
        [styles],
    )

    const ViewDividerUI = useMemo(() => StyleSheet.flatten([{ height: 37, backgroundColor: styles.PRIMARY__BG__COLOR }]), [styles])
    const HeaderTopWrapperUI = useMemo(
        () =>
            StyleSheet.flatten([
                {
                    backgroundColor: styles.PRIMARY__BG__COLOR,
                    paddingHorizontal: dimensions.moderate(12),
                },
            ]),
        [styles],
    )
    const ScrollViewWrapUI = useMemo(
        () =>
            StyleSheet.flatten([
                {
                    backgroundColor: styles.PRIMARY__BG__COLOR,
                    marginTop: dimensions.vertical(12),
                    marginBottom: dimensions.vertical(4),
                    position: 'absolute',
                    top: 34,
                    marginHorizontal: dimensions.moderate(16),
                },
            ]),
        [styles],
    )
    const PrimaryBG = { backgroundColor: styles.PRIMARY__BG__COLOR }
    const PrimaryBGActive = useMemo(
        () =>
            StyleSheet.flatten([
                applicationSettings.application_style.tab_style === '2.0'
                    ? { backgroundColor: styles.ACTIVE__TAB__HIGHLIGHT__BG, borderTopRightRadius: 6, borderTopLeftRadius: 6, marginLeft: 2 }
                    : { backgroundColor: styles.PRIMARY__BG__COLOR },
            ]),
        [styles],
    )
    const textStyleUI = useMemo(() => StyleSheet.flatten([{ color: styles.SECOND__CONTENT__COLOR, ...UI.tab }]), [styles])
    const textActiveStyleUI = useMemo(() => StyleSheet.flatten([{ color: styles.PRIMARY__CONTENT__COLOR, ...UI.tab }]), [styles])

    return (
        <Tabs
            page={page}
            renderTabBar={(props) => (
                <View>
                    <ScrollableTab {...props} backgroundColor={styles.PRIMARY__BG__COLOR} style={ScrollableTabUI} underlineStyle={{ height: 0 }} />
                    <View style={ViewDividerUI} />
                    <View style={HeaderTopWrapperUI}>
                        <HeaderTop activeOtp={activeOtp} changeTypeSort={changeTypeSort} sort={sort} typeTop={glb_sv.TYPE_TOP_MARKET} />
                    </View>
                    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={ScrollViewWrapUI}>
                        <OptionsTop active={activeOtp === '1D'} styles={styles} title={'1 ' + t('day')} value="1D" onChange={changeOtpion} />
                        <OptionsTop active={activeOtp === '1W'} styles={styles} title={'5 ' + t('day')} value="1W" onChange={changeOtpion} />
                        <OptionsTop active={activeOtp === '1M'} styles={styles} title={t('one_month')} value="1M" onChange={changeOtpion} />
                        <OptionsTop active={activeOtp === '3M'} styles={styles} title={t('three_month')} value="3M" onChange={changeOtpion} />
                        <OptionsTop active={activeOtp === '6M'} styles={styles} title={t('six_month')} value="6M" onChange={changeOtpion} />
                        <OptionsTop active={activeOtp === '1Y'} styles={styles} title={'1 ' + t('year')} value="1Y" onChange={changeOtpion} />
                        <OptionsTop active={activeOtp === '2Y'} styles={styles} title={'2 ' + t('year')} value="2Y" onChange={changeOtpion} />
                        <OptionsTop active={activeOtp === '3Y'} isLast={true} styles={styles} title={'3 ' + t('year')} value="3Y" onChange={changeOtpion} />
                    </ScrollView>
                </View>
            )}
            onChangeTab={(tab) => changeTab(tab)}
        >
            <Tab
                activeTabStyle={PrimaryBGActive}
                activeTextStyle={textActiveStyleUI}
                heading={t('top_10_stocks_value_trade')}
                tabStyle={PrimaryBG}
                textStyle={textStyleUI}
            />
            <Tab
                activeTabStyle={PrimaryBGActive}
                activeTextStyle={textActiveStyleUI}
                heading={t('top_10_stocks_shares_trade')}
                tabStyle={PrimaryBG}
                textStyle={textStyleUI}
            />
            <Tab
                activeTabStyle={PrimaryBGActive}
                activeTextStyle={textActiveStyleUI}
                heading={t('top_value_frg')}
                tabStyle={PrimaryBG}
                textStyle={textStyleUI}
            />
            <Tab
                activeTabStyle={PrimaryBGActive}
                activeTextStyle={textActiveStyleUI}
                heading={t('top_10_stocks_incre')}
                tabStyle={PrimaryBG}
                textStyle={textStyleUI}
            />
            <Tab
                activeTabStyle={PrimaryBGActive}
                activeTextStyle={textActiveStyleUI}
                heading={t('top_10_stocks_decre')}
                tabStyle={PrimaryBG}
                textStyle={textStyleUI}
            />
        </Tabs>
    )
}
export const HeaderTopMarket = memo(HeaderTopMarketMemo)

const UI = StyleSheet.create({
    tab: {
        fontSize: fontSizes.small,
        fontWeight: fontWeights.medium,
        marginLeft: 0,
        marginRight: 0,
    },
})
export default memo(TopMaket)
