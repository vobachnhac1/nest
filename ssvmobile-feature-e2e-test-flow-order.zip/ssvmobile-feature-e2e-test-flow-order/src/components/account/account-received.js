import React, { memo, useContext } from 'react'
import { ScrollView, StyleSheet, Text, View } from 'react-native'
import { Button, Row } from 'native-base'

import { StoreContext } from '../../store'
import { StoreTrading } from '../../store-trading'
import { dimensions as dm, fontSizes as fs, fontWeights as fw } from '../../styles'

const Account = ({ setSub_curr2, sub_curr2 }) => {
    const { styles } = useContext(StoreContext)
    const { userInfo } = useContext(StoreTrading)

    const changeSubActTake = (item) => {
        setSub_curr2(item)
    }

    return (
        <Row style={UI.Common__Row}>
            <View style={{ flex: 7, flexDirection: 'row' }}>
                <View style={[UI.name_act]}>
                    <Text numberOfLines={1} style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fs.small }}>
                        {userInfo.actn_curr}
                    </Text>
                    <Text
                        numberOfLines={1}
                        style={{
                            color: styles.SECOND__CONTENT__COLOR,
                            fontSize: fs.smallest,
                        }}
                    >
                        {userInfo.actn_name}
                    </Text>
                </View>
                <View
                    style={{
                        flexDirection: 'row',
                        backgroundColor: styles.PRIMARY__BG__COLOR,
                        alignItems: 'center',
                        flex: 1,
                        marginLeft: dm.moderate(12),
                    }}
                >
                    <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                        {userInfo.sub_list.map((item) => (
                            <Button
                                key={item}
                                style={{
                                    backgroundColor: sub_curr2 === item ? styles.PRIMARY : styles.BUTTON__SECONDARY,
                                    marginVertical: dm.vertical(4),
                                    display: item === userInfo.sub_curr ? 'none' : 'flex',
                                    height: dm.moderate(32),
                                    width: dm.moderate(32),
                                    marginLeft: 6,
                                    marginRight: 2,
                                    justifyContent: 'center',
                                    borderRadius: 8,
                                }}
                                onPress={() => changeSubActTake(item)}
                            >
                                <Text
                                    style={{
                                        color: sub_curr2 === item ? 'white' : styles.PRIMARY__CONTENT__COLOR,
                                        fontSize: fs.small,
                                        fontWeight: item === userInfo.sub_curr ? fw.bold : fw.medium,
                                        textAlign: 'center',
                                    }}
                                >
                                    {item}
                                </Text>
                            </Button>
                        ))}
                    </ScrollView>
                </View>
            </View>
        </Row>
    )
}

export default memo(Account)

const UI = StyleSheet.create({
    Common__Row: {
        paddingBottom: dm.vertical(4),
        paddingHorizontal: dm.moderate(16),
        paddingTop: dm.vertical(16),
    },
    icon_name_act: {
        alignSelf: 'center',
        paddingHorizontal: 8,
        paddingTop: 8,
        paddingVertical: 5,
    },
    name_act: {
        paddingTop: 8,
        paddingVertical: 5,
        // flex: 3
    },
})
