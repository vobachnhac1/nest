import Text from './Text'

export default Text
