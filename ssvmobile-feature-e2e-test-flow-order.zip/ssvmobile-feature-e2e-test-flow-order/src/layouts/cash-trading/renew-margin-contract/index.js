import React from 'react'

import { glb_sv } from '../../../utils'
import RenewMarginContract from './renew-margin-contract'
import RenewMarginContractSSV from './renew-margin-contract-ssv'

function MarginExtension({ navigation, route }) {
    // if (['081', '888'].includes(glb_sv.activeCode)) {
    return <RenewMarginContractSSV navigation={navigation} route={route} />
    // }

    // return <RenewMarginContract navigation={navigation} route={route} />
}

export default MarginExtension
