const fs = require('fs')

fs.copyFile(
    'node_modules/@codler/react-native-keyboard-aware-scroll-view/lib/KeyboardAwareHOC.js',
    'node_modules/native-base/node_modules/@codler/react-native-keyboard-aware-scroll-view/lib/KeyboardAwareHOC.js',
    (err) => {
        if (err) throw err
        console.log('File was copied to destination')
    },
)
