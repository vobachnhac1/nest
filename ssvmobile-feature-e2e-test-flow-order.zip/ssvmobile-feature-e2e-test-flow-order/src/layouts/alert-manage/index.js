import React, { useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { FlatList, RefreshControl, StyleSheet, TouchableOpacity, View } from 'react-native'
import Modal from 'react-native-modal'
import Svg, { Path } from 'react-native-svg'
import { Container, Content, Fab, Icon, Tab, Tabs } from 'native-base'

import { Text } from '../../basic-components'
import HeaderComponent from '../../components/header'
import ModalLoading from '../../components/modal-loading'
import NotAuthView from '../../components/notAuth-view'
import { ButtonCustom, EmptyView, ModalContent, RowDataModal, RowTitleGroup } from '../../components/trading-component'
import { useLoading } from '../../hoc'
import { StoreContext } from '../../store'
import { dimensions as dm, fontSizes as fs, fontWeights } from '../../styles'
import { FormatNumber, Screens, sendRequest, wait } from '../../utils'
import { AlertRowView } from './component'

const generateNote = (textCondition, listCondition) => {
    let string = ''
    const ConvertedCondition = []
    const Tempt = textCondition.split('|')
    Tempt.map((item) => {
        const splited = item.split(',')
        ConvertedCondition.push({
            c0: splited[0], // Subseq of condition
            c1: splited[1], // Key of condition
            c2: splited[3], // Condtion code
            c3: splited[2], // Condition operator: Default 1 (AND)
            c4: splited[4], // Dấu so sánh
            c5: splited[5], // Value of condition
        })
    })
    ConvertedCondition.map((item, index) => {
        string =
            string +
            `${mapNameCondition(listCondition, item.c1, item.c2)} ${item.c4} ${FormatNumber(item.c5)}${index + 1 === ConvertedCondition.length ? '' : '; '} `
    })
    return string
}

const mapNameCondition = (listCondition, keyOfCondition, conditionCode) => {
    const condition = listCondition.find((cond) => cond.data.c0 === keyOfCondition && cond.data.c1 === conditionCode)
    return condition?.label || ''
}

const ServiceInfo = {
    getListAlertConfig: {
        WorkerName: 'FOSqMSS01',
        ServiceName: 'FOSqMSS01_GetList',
        Operation: 'Q',
    },
    queryCondition: {
        WorkerName: 'FOSqMSS01',
        ServiceName: 'FOSqMSS01_GetList',
        Operation: 'Q',
    },
    confirmCreateAlert: {
        WorkerName: 'FOSxMSS01',
        ServiceName: 'FOSxMSS01_ManagementList',
        Operation: 'I',
    },
    confirmDeleteAlert: {
        WorkerName: 'FOSxMSS01',
        ServiceName: 'FOSxMSS01_ManagementList',
        Operation: 'D',
    },
    stopAlert: {
        WorkerName: 'FOSxMSS01',
        ServiceName: 'FOSxMSS01_ManagementList',
        Operation: 'U',
    },
    reOpenAlert: {
        WorkerName: 'FOSxMSS01',
        ServiceName: 'FOSxMSS01_ManagementList',
        Operation: 'U',
    },
}

const AlertManageLayout = ({ navigation, route }) => {
    const { styles, authFlag } = useContext(StoreContext)
    if (!authFlag) {
        navigation.navigate(Screens.SIGN_IN)
        return <NotAuthView />
    }
    // ----------------
    const { t } = useTranslation()
    const { params = {} } = route
    const [refreshing, setRefreshing] = useState(false)
    const [activeStep, setActiveStep] = useState(0)

    const [listCondition, setListCondition] = useState([])
    const [listAlert, setListAlert] = useState([])

    const [isOpenModal, setIsOpenModal] = useState(false)
    const [selectedDelete, setSelectedDelete] = useState({})
    const [loadingConfirm, setLoadingConfirm] = useLoading(false)

    useEffect(() => {
        queryCondition()
        getListAlertConfig()
    }, [])

    // ----------------------------------------
    const onRefresh = () => {
        setRefreshing(true)
        getListAlertConfig()
        wait(300).then(() => setRefreshing(false))
    }

    //-----------------------------------------
    const getListAlertConfig = () => {
        const inputParams = ['01', '', '']
        sendRequest(ServiceInfo.getListAlertConfig, inputParams, handleGetListAlertConfig)
    }

    const handleGetListAlertConfig = (reqInfoMap, message) => {
        // console.log('handleGetListAlertConfig', message)
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {}

            setListAlert(jsondata)
        }
    }

    // ------------------------------------------------
    const queryCondition = () => {
        const inputParams = ['03']
        sendRequest(ServiceInfo.queryCondition, inputParams, handleQueryCondition)
    }

    const handleQueryCondition = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {}
            const convertedList = jsondata.map((item) => {
                return {
                    value: item.c0 + '|' + item.c1,
                    label: item.c2,
                    data: item,
                }
            })
            setListCondition(convertedList)
        }
    }
    const onSelectDeleteAlert = (item) => {
        setSelectedDelete(item)
        setIsOpenModal(true)
    }

    const onDeleteAlert = (item) => {
        setLoadingConfirm(true)
        // console.log('Delete', item);
        const inputParams = ['03', item.c0, item.c1]
        sendRequest(ServiceInfo.confirmCreateAlert, inputParams, handleDeleteAlert)
    }
    const onStopAlert = (item) => {
        // console.log('onStopAlert', item)
        const inputParams = ['04', item.c0, item.c1]
        sendRequest(ServiceInfo.stopAlert, inputParams, handleDeleteAlert)
    }
    const onReopenAlert = (item) => {
        // console.log('onReopenAlert', item)
        const inputParams = ['05', item.c0, item.c1]
        sendRequest(ServiceInfo.reOpenAlert, inputParams, handleDeleteAlert)
    }
    const handleDeleteAlert = (reqInfoMap, message) => {
        setLoadingConfirm(false)
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {}
            onRefresh()
        }
    }

    const ViewAlertEmpty = () => {
        return (
            <>
                <EmptyView />
                <View style={[UI.ButtonAdd, { backgroundColor: styles.PRIMARY }]}>
                    <TouchableOpacity onPress={() => navigation.navigate(Screens.DETAIL_ALERT_CONFIG_SCREEN, { data: {}, isCreateNewAlert: true, onRefresh })}>
                        <Text style={{ color: '#fff', fontWeight: fontWeights.bold }}>{t('tap_to_add')}</Text>
                    </TouchableOpacity>
                </View>
            </>
        )
    }

    const translateKeyStatus = (key) => {
        if (key === '1') return t('running')
        if (key === '2') return t('notice_sent')
        if (key === '3') return t('expired')
        if (key === '4') return t('stop')
        if (key === '9') return t('err')
        return ''
    }
    const getColorStatus = (key) => {
        if (key === '1') return styles.UP__COLOR
        if (key === '2') return styles.UP__COLOR
        if (key === '3') return styles.DOWN__COLOR
        if (key === '4') return styles.REF__COLOR
        if (key === '9') return styles.DOWN__COLOR
        return styles.REF__COLOR
    }

    return (
        <Container style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft
                leftButtonLink={() => navigation.goBack()}
                navigation={navigation}
                title={t('my_alerts')}
                titleAlgin="flex-start"
                transparent
            />
            <Content
                refreshControl={<RefreshControl refreshing={refreshing} tintColor={styles.PRIMARY__CONTENT__COLOR} onRefresh={onRefresh} />}
                style={{ backgroundColor: styles.PRIMARY__BG__COLOR, flex: 1 }}
            >
                <Tabs locked page={activeStep} renderTabBar={() => <View />} style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
                    <Tab heading={<View />} style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
                        <View>
                            {/* <RowTitleGroup text={t('common_alert_list')} style={{ marginTop: 0, paddingTop: 0 }} /> */}
                            <FlatList
                                data={listAlert}
                                keyExtractor={(item, index) => index.toString()}
                                ListEmptyComponent={ViewAlertEmpty}
                                renderItem={({ item }) => {
                                    return (
                                        <AlertRowView
                                            alertName={item.c4}
                                            alertNote={generateNote(item.c13, listCondition)}
                                            item={item}
                                            onDeleteAlert={() => onSelectDeleteAlert(item)}
                                            onPress={() => navigation.navigate(Screens.DETAIL_ALERT_CONFIG_SCREEN, { data: item, onRefresh })}
                                            onReopenAlert={() => onReopenAlert(item)}
                                            onStopAlert={() => onStopAlert(item)}
                                        />
                                    )
                                }}
                                style={{ marginBottom: dm.vertical(32) }}
                            />
                        </View>
                    </Tab>
                    <Tab heading={<View />} style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
                        <View>
                            <RowTitleGroup style={{ marginTop: 0, paddingTop: 0 }} text={t('common_alert_list')} />
                        </View>
                    </Tab>
                </Tabs>
            </Content>
            <Fab
                active={false}
                containerStyle={{ marginBottom: 32, marginRight: 8, justifyContent: 'center', alignItems: 'center' }}
                direction="up"
                position="bottomRight"
                style={{ backgroundColor: styles.PRIMARY }}
            >
                <TouchableOpacity
                    style={{ justifyContent: 'center', alignItems: 'center', width: '100%', height: '100%' }}
                    onPress={() => {
                        navigation.navigate(Screens.DETAIL_ALERT_CONFIG_SCREEN, { data: {}, isCreateNewAlert: true, onRefresh })
                    }}
                >
                    <Icon name="plus" style={{ color: '#fff', fontSize: 32, paddingRight: 0 }} type="Feather" />
                </TouchableOpacity>
            </Fab>
            {isOpenModal && (
                <Modal
                    isVisible={isOpenModal}
                    useNativeDriver={true}
                    onBackButtonPress={() => setIsOpenModal(false)}
                    onBackdropPress={() => setIsOpenModal(false)}
                >
                    <ModalContent
                        iconComponent={
                            <Svg fill="none" height={32} viewBox="0 0 32 32" width={32} xmlns="http://www.w3.org/2000/svg">
                                <Path
                                    d="M7.148 12.624l2.237 17.007a1 1 0 00.992.869h11.246a1 1 0 00.991-.87l1.728-13.13.658-5H8.272l-1.124 1.124z"
                                    fill="#EB5C55"
                                />
                                <Path
                                    d="M15 15.5v11a1 1 0 102 0v-11a1 1 0 10-2 0zM11 15.5v11a1 1 0 102 0v-11a1 1 0 10-2 0zM19 15.5v11a1 1 0 102 0v-11a1 1 0 10-2 0z"
                                    fill="#F2F8FF"
                                />
                                <Path
                                    d="M15 8.5l2 1h2.5l-1-2.5-2-.5-1.5 2zM24 5l-2.5.5v1l.5 2 4-.5-1.5-2-.5-1zM15.086 1.858a1 1 0 00-1.414 0L2.358 13.172a1 1 0 000 1.414L3.772 16 16.5 3.272l-1.414-1.414z"
                                    fill="#EB5C55"
                                />
                                <Path
                                    d="M22.614 29.63l.196-1.486c-6.417-2.253-10.844-8.531-10.448-15.652l.054-.992H8.272l-1.124 1.124 2.237 17.007a1 1 0 00.992.869h11.246a1 1 0 00.991-.87z"
                                    fill="#303030"
                                    opacity={0.12}
                                />
                                <Path
                                    d="M13.515 4.486L2.886 15.114l.886.886L16.5 3.272l-1.414-1.414a1 1 0 00-1.414 0l-.157.157a1.747 1.747 0 010 2.47zM24.5 6L24 5l-.909.182.41.818L25 8l-3.031.379.03.121 4-.5-1.5-2zM17.5 7.5l.8 2h1.2l-1-2.5-2-.5-.474.631L17.5 7.5z"
                                    fill="#303030"
                                    opacity={0.12}
                                />
                                <Path
                                    d="M5.186 10.343l-1.06-1.06a1.502 1.502 0 010-2.122L7.66 3.625a1.501 1.501 0 012.122 0l1.06 1.061-.707.707-1.06-1.06a.501.501 0 00-.708 0L4.833 7.867a.501.501 0 000 .707l1.06 1.061-.707.707zM22 1h1v1h-1V1zM27.01 4.896l-.609-.792a5.83 5.83 0 014.697-1.095l-.196.981a4.836 4.836 0 00-3.891.906zM28.5 6h1v1h-1V6zM25 3.5h-1C24 2.122 25.122 1 26.5 1v1c-.827 0-1.5.673-1.5 1.5z"
                                    fill="#EB5C55"
                                />
                            </Svg>
                        }
                        title={t('delete_alert')}
                        type="cancel"
                    >
                        <RowDataModal textLeft={t('short_symbol')} textRight={selectedDelete.c4} />
                        <RowDataModal
                            rightColor={getColorStatus(selectedDelete.c11)}
                            textLeft={t('state_handle')}
                            textRight={translateKeyStatus(selectedDelete.c11)}
                        />
                        <RowDataModal last textLeft={t('label_condition')} />
                        <View
                            style={{
                                paddingVertical: dm.vertical(8),
                                marginHorizontal: dm.moderate(16),
                                flexDirection: 'row',
                                borderBottomColor: '#444c575d', // styles.DIVIDER__MODAL__COLOR,
                                borderBottomWidth: 0,
                            }}
                        >
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fs.small }}>{generateNote(selectedDelete.c13, listCondition)}</Text>
                        </View>

                        <ButtonCustom
                            text={t('common_Delete')}
                            type="confirm"
                            onPress={() => {
                                onDeleteAlert(selectedDelete)
                                setIsOpenModal(false)
                            }}
                        />

                        <ButtonCustom last text={t('common_back')} type="back" onPress={() => setIsOpenModal(false)} />
                    </ModalContent>
                </Modal>
            )}
            {loadingConfirm && <ModalLoading content={t('common_processing')} visible={loadingConfirm} />}
        </Container>
    )
}

export default AlertManageLayout

const UI = StyleSheet.create({
    ButtonAdd: {
        alignItems: 'center',
        alignSelf: 'center',
        borderRadius: 100,
        justifyContent: 'center',
        marginHorizontal: dm.moderate(16),
        marginVertical: 16,
        minWidth: dm.WIDTH * 0.4,
        paddingHorizontal: 16,
        paddingVertical: 8,
    },
})
