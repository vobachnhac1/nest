import React, { useContext } from 'react'
import { useTranslation } from 'react-i18next'
import moment from 'moment'
import { Container, Content } from 'native-base'

import HeaderComponent from '../../components/header'
import { RowData } from '../../components/trading-component'
import { preventCompanyRender } from '../../hoc'
import { StoreContext } from '../../store'
import { StoreTrading } from '../../store-trading'
import { FormatNumber } from '../../utils'

// Khai báo component
export default function HistoryProfitLossDetail({ navigation, route }) {
    const { styles } = useContext(StoreContext)
    const { userInfo } = useContext(StoreTrading)

    const { t } = useTranslation()
    const { params = {} } = route
    const { data = {}, onRefresh = () => null } = params

    // Start define all bussiness state
    // End define form bussiness state
    // -------------------------------------------   Dùng useEffect get các dữ liệu cần thiết còn thiếu

    // -------------------------------------------   Viết các hàm để set lại bussiness form state. Nên viết đúng một chuẩn duy nhất để dễ control

    const getColor = (value) => {
        if (value > 0) return styles.UP__COLOR
        if (value < 0) return styles.DOWN__COLOR
        return styles.PRIMARY__CONTENT__COLOR
    }
    return (
        <Container style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft
                navigation={navigation}
                title={t('portfolio_info_detail')}
                titleAlgin="flex-start"
                transparent
            />
            <Content>
                <RowData textLeft={t('short_symbol')} textRight={data.c3} />
                <RowData textLeft={t('calculator_date')} textRight={moment(data.c0, 'DDMMYYYY').format('DD/MM/YYYY')} />
                <RowData dataSub={[data.c1, data.c2]} textLeft={t('acnt_no')} />
                <RowData textLeft={t('buy_average_price')} textRight={FormatNumber(Number(data.c21))} />
                <RowData textLeft={t('buy_average_value')} textRight={FormatNumber(Number(data.c22))} />
                {/* ------ */}
                <RowData
                    rightColor={getColor(Number(data.c23))}
                    textLeft={t('profit_loss_ratio')}
                    textRight={
                        Number(data.c23) === 0
                            ? `0%`
                            : Number(data.c23) > 0
                            ? `+${FormatNumber(Number(data.c23), 3, 1)}%`
                            : `${FormatNumber(Number(data.c23) * -1, 3, 1)}%`
                    }
                />
                <RowData
                    rightColor={getColor(Number(data.c23))}
                    textLeft={t('profit_loss_value')}
                    textRight={
                        Number(data.c23) === 0
                            ? Number(data.c15) > 0
                                ? FormatNumber(Number(data.c15), 0)
                                : FormatNumber(Number(data.c15) * -1, 0)
                            : Number(data.c15) > 0
                            ? `+${FormatNumber(Number(data.c15), 0)}`
                            : `-${FormatNumber(Number(data.c15) * -1, 0)}`
                    }
                />
                <RowData textLeft={t('own_qty')} textRight={FormatNumber(data.c4)} />
                <RowData textLeft={t('increase_quantity')} textRight={FormatNumber(data.c5)} />
                <RowData textLeft={t('value_of_capital')} textRight={FormatNumber(data.c6)} />
                <RowData textLeft={t('decrease_quantity')} textRight={FormatNumber(data.c7)} />
                <RowData textLeft={t('value_of_cash_right')} textRight={FormatNumber(data.c8)} />
                {preventCompanyRender(['028']) ? <RowData textLeft={t('quantity_of_stock_right')} textRight={FormatNumber(data.c9)} /> : null}
                <RowData textLeft={t('accumulated_capital_value_excluding_rights')} textRight={FormatNumber(data.c10)} />
                {preventCompanyRender(['028']) ? <RowData textLeft={t('value_of_stock_right')} textRight={FormatNumber(data.c11)} /> : null}
                <RowData textLeft={t('quantity_of_current_stock')} textRight={FormatNumber(data.c12)} />
                <RowData textLeft={t('market_price')} textRight={FormatNumber(data.c13)} />
                <RowData textLeft={t('market_value')} textRight={FormatNumber(data.c14)} />
                <RowData textLeft={t('previous_transaction_date')} textRight={FormatNumber(data.c16)} />
                <RowData textLeft={t('selling_value_on_the_property_value')} textRight={FormatNumber(data.c17)} />
                <RowData rightColor={getColor(Number(data.c23))} textLeft={t('profit_loss_value_sell_on_day')} textRight={FormatNumber(data.c18)} />
                <RowData rightColor={getColor(Number(data.c23))} textLeft={t('profit_loss_value_buy_on_day')} textRight={FormatNumber(data.c19)} />
                <RowData last rightColor={getColor(Number(data.c23))} textLeft={t('total_profit_loss_value_on_day')} textRight={FormatNumber(data.c20)} />
            </Content>
        </Container>
    )
}
