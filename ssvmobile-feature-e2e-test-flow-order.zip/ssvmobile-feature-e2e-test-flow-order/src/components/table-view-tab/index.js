import React, { useCallback, useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { FlatList, View } from 'react-native'
import { Header } from 'react-native/Libraries/NewAppScreen'
import { SafeAreaView } from 'react-native-safe-area-context'
import { Col, Icon, ListItem, Row } from 'native-base'

import { Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { fontSizes } from '../../styles'
import { glb_sv, Screens, socket_sv } from '../../utils'
// import ModalAddStock2FavList from '../modal-add-stock-fav'
import HeaderComponent from '../header'

const ListHisTransfer = [
    {
        id: '1133',
        status: 'pending',
        name: 'Lê Yến Vy',
        value: '10.000.000',
        account: '888c000354.00',
    },
    {
        id: '11223',
        status: 'approve',
        name: 'Lê Yến Vy',
        value: '10.000.000',
        account: '888c000354.00',
    },
    {
        id: '11323',
        status: 'close',
        name: 'Lê Yến Vy',
        value: '10.000.000',
        account: '888c000354.00',
    },
    {
        id: '111',
        status: 'close',
        name: 'Lê Yến Vy',
        value: '10.000.000',
        account: '888c000354.00',
    },
    {
        id: '1144',
        status: 'close',
        name: 'Lê Yến Vy',
        value: '10.000.000',
        account: '888c000354.00',
    },
]

export default function TableViewTab({ navigation, route }) {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()
    const { params = {} } = route

    const [seach, setSearch] = useState('')
    const [listSelections, setListSelections] = useState([])

    useEffect(() => {
        setListSelections(params?.data)
    }, [])

    const getDetailRow = (rowData) => {
        params.cb(rowData)
    }

    const TableObtion = [
        { headerTitle: 'acnt_no', dataKey: 'c4', flexCol: 4, onSelectCell: getDetailRow, fontSize: 'verySmall', textAlign: 'center' },
        { headerTitle: 'bank_transaction_amount', dataKey: 'c2', flexCol: 3, onSelectCell: getDetailRow, fontSize: 'verySmall', textAlign: 'right' },
        { headerTitle: 'order_status', dataKey: 'c11', flexCol: 3, onSelectCell: getDetailRow, fontSize: 'verySmall', textAlign: 'right' },
    ]

    const ItemSelect = ({ item }) => {
        return (
            <ListItem style={{ borderBottomColor: styles.DIVIDER__COLOR, marginLeft: 0 }} underlayColor="transparent">
                <Row>
                    {TableObtion.map((col, index) => (
                        <Col key={index} style={{ flex: col.flexCol }} onPress={() => col.onSelectCell(item)}>
                            {item.c21 === 'N' && <Icon name="checkcircleo" style={{ color: styles.UP__COLOR }} type="AntDesign" />}
                            {item.c21 === 'Y' && <Icon name="closecircleo" style={{ color: styles.DOWN__COLOR }} type="AntDesign" />}
                            {item.c21 === 'P' && <Icon name="exclamationcircleo" style={{ color: styles.REF__COLOR }} type="AntDesign" />}
                            <Text style={{ fontSize: fontSizes[col.fontSize], textAlign: col.textAlign }}>{item[col.dataKey]}</Text>
                        </Col>
                    ))}
                </Row>
            </ListItem>
        )
    }

    const ListEmpty = () => {
        return (
            <View style={{ justifyContent: 'center', flex: 1, margin: 10 }}>
                <Text style={{ textAlign: 'center', color: styles.PRIMARY__CONTENT__COLOR }}>No Matching results.</Text>
            </View>
        )
    }

    const HeaderFlatList = () => {
        return (
            <ListItem style={{ borderBottomColor: styles.DIVIDER__COLOR, marginLeft: 0 }} underlayColor="transparent">
                <Row>
                    {TableObtion.map((col, index) => (
                        <Col key={index} style={{ flex: col.flexCol }}>
                            <Text style={{}}>{t(col.headerTitle)}</Text>
                        </Col>
                    ))}
                </Row>
            </ListItem>
        )
    }

    return (
        <View
            style={{
                flex: 1,
                backgroundColor: styles.PRIMARY__BG__COLOR,
            }}
        >
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft
                navigation={navigation}
                title={t('common_Detail')}
                titleAlgin="flex-start"
            />
            <SafeAreaView style={{ flex: 1 }}>
                {listSelections.length === 0 && seach.length === 0 ? (
                    <View>
                        <Text style={{ color: styles.HEADER__CONTENT__COLOR }}>Không có lựa chọn</Text>
                    </View>
                ) : (
                    <>
                        <HeaderFlatList />
                        <FlatList
                            data={listSelections}
                            keyboardShouldPersistTaps="always"
                            keyExtractor={(item) => item.c11}
                            ListEmptyComponent={ListEmpty}
                            renderItem={ItemSelect}
                            style={{ marginBottom: 10 }}
                        />
                    </>
                )}
            </SafeAreaView>
            {/* 
            <ModalAddStock2FavList
                styles={styles}
                isModalVisible={isModalVisible}
                setModal={setModal}
                navigation={navigation}
                selectStock={selectStock}
            /> */}
        </View>
    )
}
