import React, { memo, useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { ActivityIndicator, FlatList, View } from 'react-native'
import moment from 'moment'

import { Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { glb_sv, reqFunct, Screens, sendRequest } from '../../utils'
import { ColTableData, EmptyView, RowTableData } from '../trading-component'

const ServiceInfo = {
    GET_RIGHTS_LIST: {
        reqFunct: reqFunct.GET_RIGHTS_LIST,
        WorkerName: 'FOSqRights',
        ServiceName: 'FOSqRights_OnlineRightsInfo_1',
        ClientSentTime: '0',
        Operation: 'Q',
    },
}

const EventInfo = ({ type, navigation }) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()

    const [loading, setLoading] = useState(true)
    const [data, setData] = useState([])
    const newsList = useRef([])

    const colSpan = [1, 1]

    useEffect(() => {
        newsList.current = []
        const inputParams = [type, '%']
        sendRequest(ServiceInfo.GET_RIGHTS_LIST, inputParams, handleGetListRightRegister)
    }, [])

    const handleTimeout = () => {
        newsList.current = []
        setLoading(false)
    }

    const handleGetListRightRegister = (reqInfoMap, message) => {
        setLoading(false)
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata = []
            try {
                if (message.Data) {
                    jsondata = JSON.parse(glb_sv.filterStrBfParse(message.Data))
                }
            } catch (err) {
                console.error('getNewsResultProc error', err)
                return
            }

            newsList.current = newsList.current.concat(jsondata)
            if (Number(message.Packet) <= 0) {
                setData(newsList.current)
            }
        }
    }

    const rightsRenderItem = ({ item }) => {
        return (
            <View style={{ paddingStart: 8, paddingEnd: 8 }}>
                <RowTableData onPress={() => navigation.navigate(Screens.DETAI_RIGHT, { data: item, stockData: { value: item.c1, label: ' - ' } })}>
                    <ColTableData colSpan={colSpan[0]} text={item.c33} text2={item.c31} />

                    <ColTableData colSpan={colSpan[1]} text={moment(item.c29, 'DDMMYYYY').format('DD/MM/YYYY')} textAlign="right" />
                </RowTableData>
            </View>
        )
    }

    return (
        <View
            style={{
                backgroundColor: styles.PRIMARY__BG__COLOR,
                flex: 1,
            }}
        >
            {loading ? (
                <View style={{ height: 200, justifyContent: 'center', alignItems: 'center' }}>
                    <ActivityIndicator />
                </View>
            ) : data.length ? (
                <FlatList
                    data={data}
                    keyExtractor={(item, index) => String(index)}
                    ListEmptyComponent={EmptyView}
                    renderItem={rightsRenderItem}
                    scrollEnabled={false}
                />
            ) : (
                <Text style={{ color: styles.SECOND__CONTENT__COLOR }}>{t('common_NoDataFound')}</Text>
            )}
        </View>
    )
}

export default memo(EventInfo)
