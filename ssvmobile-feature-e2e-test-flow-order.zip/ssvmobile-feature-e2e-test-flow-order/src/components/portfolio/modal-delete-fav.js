import React, { memo } from 'react'
import { useTranslation } from 'react-i18next'
import { StyleSheet, View } from 'react-native'
import Modal from 'react-native-modal'
import { Button, Toast } from 'native-base'

import { Text } from '../../basic-components'
import { dimensions, fontSizes, fontWeights, IconSvg } from '../../styles'
import { eventList, glb_sv, reqFunct, sendRequest } from '../../utils'
import { delFavList } from './favorite-func/favorite.action'

const ServiceInfo = {
    REMOVE_FAV_LIST: {
        reqFunct: reqFunct.REMOVE_FAV_LIST,
        WorkerName: 'FOSxID01',
        ServiceName: 'FOSxID01_FavoritesMgt',
        ClientSentTime: '0',
        Operation: 'I',
    },
}

const ModalDeleteFav = ({ isModalVisible, setModal, styles }) => {
    const { t } = useTranslation()

    const deleteFavListName = () => {
        if (glb_sv.authFlag) {
            const InputParams = ['FAV_REMOVE', glb_sv.activeList.c1]
            sendRequest(ServiceInfo.REMOVE_FAV_LIST, InputParams, handleDeleteFavListName, true, handleStockFavTimeout)
        } else {
            delFavList(glb_sv.activeList.c1)
            hideModal()
        }
    }

    const handleStockFavTimeout = () => {
        // Toast.show({
        //     text: t('request_hanlde_not_success_try_again'),
        //     type: 'warning',
        //     position: 'bottom',
        // })
    }

    const handleDeleteFavListName = (reqInfoMap, message) => {
        // if (Number(message['Result']) === 0) {
        //     if (message.Code === '010012') {
        //         Toast.show({
        //             text: t('request_hanlde_not_success_try_again'),
        //             type: 'warning',
        //             position: 'bottom',
        //         })
        //     } else {
        //         Toast.show({
        //             text: message.Message,
        //             type: 'warning',
        //             position: 'bottom',
        //         })
        //     }
        //     return;
        // } else {
        //     const { inputParam } = reqInfoMap
        //     glb_sv.allListFav = glb_sv.allListFav.filter(x => x.c1 !== inputParam[1])
        //     const newActiveList = glb_sv.allListFav[0]
        //     glb_sv.activeList = newActiveList ? { ...newActiveList } : { ListStock: [] };
        //     glb_sv.commonEvent.next({ type: eventList.CHANGE_LIST_ACTIVE })
        // }
        // hideModal();

        delFavList(glb_sv.activeList.c1)
        hideModal()
    }

    const hideModal = () => setModal(false)

    return (
        <Modal
            isVisible={isModalVisible}
            style={UI.modalBottom}
            swipeDirection={['down']}
            onBackButtonPress={hideModal}
            onBackdropPress={hideModal}
            onSwipeComplete={hideModal}
        >
            <View
                style={{
                    backgroundColor: styles.PRIMARY__BG__COLOR,
                    padding: 32,
                    paddingBottom: 64,
                    borderTopLeftRadius: 12,
                    borderTopRightRadius: 12,
                    justifyContent: 'center',
                    alignItems: 'center',
                }}
            >
                <IconSvg.DeleteIcon />
                <Text style={{ ...UI.title, color: styles.PRIMARY__CONTENT__COLOR }}>{t('remove_a_favorites')}</Text>

                <Text style={{ ...UI.note, color: styles.PRIMARY__CONTENT__COLOR }}>{t('delete_fav_note')}</Text>

                <Button
                    style={{ backgroundColor: styles.ERROR__COLOR, width: 172, height: 32, justifyContent: 'center', alignSelf: 'center' }}
                    transparent
                    onPress={deleteFavListName}
                >
                    <Text style={{ color: '#FFF', fontSize: fontSizes.small }}>{t('common_Ok')}</Text>
                </Button>
                <Button style={{ width: 172, height: 32, justifyContent: 'center', alignSelf: 'center' }} transparent onPress={hideModal}>
                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.verySmall, opacity: 0.34 }}>{t('common_Cancel')}</Text>
                </Button>
            </View>
        </Modal>
    )
}

const UI = StyleSheet.create({
    modalBottom: {
        justifyContent: 'flex-end',
        margin: 0,
    },
    note: {
        fontSize: fontSizes.small,
        marginBottom: dimensions.vertical(32),
    },
    title: {
        fontSize: fontSizes.xmedium,
        fontWeight: fontWeights.semiBold,
        marginBottom: dimensions.vertical(16),
        marginTop: dimensions.vertical(32),
    },
})

export default memo(ModalDeleteFav)
