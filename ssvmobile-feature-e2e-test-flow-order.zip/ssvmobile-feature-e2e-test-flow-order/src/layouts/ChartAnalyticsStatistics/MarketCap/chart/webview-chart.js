import React, { Component, createRef } from 'react'
import { Platform, StyleSheet } from 'react-native'
import deviceInfoModule from 'react-native-device-info'
import { getStatusBarHeight } from 'react-native-status-bar-height'
import WebView from 'react-native-webview'
import { dimensions } from '@mts-styles/index'

const source = Platform.select({
    ios: require('../../../../basic-components/custom-chart/index.html'),
    android: { uri: 'file:///android_asset/index.html' },
})

const isTable = deviceInfoModule.isTablet()
const hasNotch = deviceInfoModule.hasNotch()
const IOS = Platform.OS === 'ios' ? true : false

// export default memo(WebviewChart)
export default class WebviewChart extends Component {
    constructor(props) {
        super(props)
        this.chartRef = createRef()

        this.state = {
            webviewKey: new Date().getTime(),
        }
        this.height = this.props.height
    }

    componentWillReceiveProps(nextProps) {
        this.chartRef &&
            this.chartRef.current.injectJavaScript(`
            window.DataMarketCap = ${nextProps.dataChart};
            if (window.eventMarket) {
                window.eventMarket.next({ type: 'highchart-marketcap' })
            }
            true;
        `)
    }

    shouldComponentUpdate(nextProps, nextState) {
        if (nextState.webviewKey !== this.state.webviewKey) {
            return true
        }
        return false
    }
    reload = () => {
        this.setState({
            webviewKey: this.state.webviewKey + 1,
        })
    }
    getHeight = () => {
        return dimensions.HIEGHT - this.height - (isTable ? 90 : IOS && hasNotch ? 70 : 50) - getStatusBarHeight() - 5
    }
    render() {
        return (
            <WebView
                allowUniversalAccessFromFileURLs={true}
                androidLayerType="hardware"
                domStorageEnabled={true}
                source={source}
                // source={{
                //     uri: 'http://192.168.1.13:3000' || 'http://localhost:3000/',
                // }}
                injectedJavaScriptBeforeContentLoaded={`
                    new Date().toLocaleString();
                    window.theme = '${this.props.theme}';
                    window.chartName = 'market_cap';
                    window.DataMarketCap = [];
                `}
                javaScriptEnabled
                key={this.state.webviewKey}
                originWhitelist={['*']}
                ref={this.chartRef}
                onContentProcessDidTerminate={this.reload}
                scrollEnabled={false}
                // style={UI.webView}
                style={[UI.webView, { maxHeight: this.getHeight() }]}
            />
        )
    }
}

const UI = StyleSheet.create({
    webView: {
        backgroundColor: 'transparent',
        flex: 1,
    },
})
