/* eslint-disable no-restricted-syntax */
import React, { useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { ActivityIndicator, FlatList, InteractionManager, Pressable, RefreshControl, StyleSheet, View } from 'react-native'
import Modal from 'react-native-modal'
import DateTimePickerModal from 'react-native-modal-datetime-picker'
import Svg, { ClipPath, Defs, G, Path } from 'react-native-svg'
import ToastGlobal from 'react-native-toast-message'
import moment from 'moment'
import { Col, Container, Content, Row } from 'native-base'

import IconCalendar from '../../../assets/images/common/calendar.svg'
import { CustomFloatInput } from '../../../basic-components'
import Account from '../../../components/account'
import HeaderComponent from '../../../components/header'
import ModalLoading from '../../../components/modal-loading'
import {
    ButtonCustom,
    ColTableData,
    ModalBottomContent,
    ModalBottomRowSelect,
    ModalContent,
    RowData,
    RowDataModal,
    RowTableData,
    RowTitleGroup,
} from '../../../components/trading-component'
import EmptyView from '../../../components/trading-component/empty-view'
import HeaderList from '../../../components/trading-component/header-list'
import { useAlertModal, useAlertModalCommonCode, useModalOtpWhenErr, useUpdateEffect } from '../../../hoc'
import { StoreContext } from '../../../store'
import { StoreTrading } from '../../../store-trading'
import { dimensions as dm, fontSizes as fs, fontWeights as fw, IconSvg } from '../../../styles'
import { eventList, glb_sv, reqFunct, Screens, sendRequest, wait } from '../../../utils'
import FormatNumber from '../../../utils/formatNumber/FormatNumber'

// Khai báo ServiceInfo (nếu có)
const ServiceInfo = {
    GET_CASH_CAN_LENDING: {
        reqFunct: reqFunct.GET_CASH_CAN_LENDING, // Lấy số tiền có thể ứng
        WorkerName: 'FOSqPIA',
        ServiceName: 'FOSqPIA_1302_3',
        Operation: 'Q',
    },
    GET_LENDING_FEE: {
        reqFunct: reqFunct.GET_LENDING_FEE, // Lấy phí ứng tiền
        WorkerName: 'FOSqPIA',
        ServiceName: 'FOSqPIA_1302_8',
        Operation: 'Q',
    },
    REQ_NEW_LENDING: {
        reqFunct: reqFunct.REQ_NEW_LENDING, // Yêu cầu ứng tiền
        WorkerName: 'FOSxPIA',
        ServiceName: 'FOSxPIA_1302_1',
        Operation: 'I',
    },
    GET_HIS_ADVANCE_LENDING: {
        reqFunct: reqFunct.GET_HIS_ADVANCE_LENDING, // Yêu cầu ứng tiền
        WorkerName: 'FOSqPIA',
        ServiceName: 'FOSqPIA_1302_1',
        Operation: 'Q',
    },
}
const initErrCtrl = [
    {
        error: false,
        message: 'input_pia_value',
    },
]
// Khai báo component
const AdvanceLendingLayout = ({ navigation }) => {
    const { styles } = useContext(StoreContext)
    const { userInfo } = useContext(StoreTrading)

    const { t } = useTranslation()
    // All orther state
    const [isOpenModal, setIsOpenModal] = useState(false)
    const [refreshing, setRefreshing] = React.useState(false)
    const [errCtrl, setErrCtrl] = useState(initErrCtrl)

    // Start define all bussiness state
    const [canLendingAmount, setCanLendingAmount] = useState({}) // Object
    const [amoutFee, setAmoutFee] = useState(0)
    const [dataLastLending, setDataLastLending] = useState([])
    const [lendingAmount, setLendingAmount] = useState('')

    const [isOpenFilterGroup, setIsOpenFilterGroup] = useState(false)
    const [filterOption, setFilterOption] = useState({
        fromDt: moment(glb_sv.objShareGlb.workDate).subtract(1, 'months').toDate(),
        toDt: moment(glb_sv.objShareGlb.workDate).toDate(),
        contractType: '0',
    })
    const [loadingConfirm, setLoadingConfirm] = useState(false)
    const [loadingButton, setLoadingButton] = useState(false)

    const feeMax = useRef(0)
    // End define form bussiness state
    // -------------------------------------------   Dùng useEffect get các dữ liệu cần thiết còn thiếu
    useEffect(() => {
        getCashCanLending()

        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.LOGIN_SUCCESS) {
                // reCall service FOSq
                getCashCanLending()
            }
            if (msg.type === eventList.NOTIFY_SERVER) {
                const message = msg.data
                if (message.MsgTp?.includes('PIA_')) {
                    getCashCanLending()
                }
            }
        })

        return () => {
            commonEvent.unsubscribe()
        }
    }, [userInfo.sub_curr])

    useEffect(() => {
        getHisAdvanceLending()
    }, [filterOption])

    useUpdateEffect(() => _validateValue(), [lendingAmount])

    // -------------------------------------------   Viết các hàm để set lại bussiness form state. Nên viết đúng một chuẩn duy nhất để dễ control

    const switchStep = {
        submit: () => confirmLending(),
        onFinish: () => _checkValueBfSend(),
    }

    const hideModal = () => {
        setIsOpenModal(false)
    }
    const _resetInput = () => {
        onRefresh()
    }

    const _checkValueBfSend = (isAuthen) => {
        hideModal()
        if (Number(lendingAmount) <= 0 || !lendingAmount) {
            ToastGlobal.show({
                type: 'warning',
                text2: t('input_pia_value'),
            })
            return
        }
        if (!isAuthen) {
            navigation.navigate(Screens.OTP_MODAL, {
                transactionOTP: true,
                otp_Type: Number(glb_sv.objShareGlb.userInfo.c6),
                functCallback: _checkValueBfSend,
            })
            return
        }
        getLendingFee()
    }

    const _validateValue = (inputIndex) => {
        const newErrCtrl = [...initErrCtrl]
        if (inputIndex === 0) newErrCtrl[0].error = Number(lendingAmount) <= 0 || !lendingAmount
        if (!inputIndex && inputIndex !== 0) {
            newErrCtrl[0].error = Number(lendingAmount) <= 0 || !lendingAmount
        }
        setErrCtrl(newErrCtrl)
    }

    const onRefresh = React.useCallback(() => {
        setRefreshing(true)
        getCashCanLending()
        wait(300).then(() => setRefreshing(false))
    }, [])

    // -------------------------------------------   Khai báo các hàm gửi (request) lên server
    const getCashCanLending = () => {
        setCanLendingAmount({ c8: '0', c10: '0', c11: '0' })

        if (!userInfo.actn_curr) {
            ToastGlobal.show({
                type: 'warning',
                text2: t('warning_account_is_empty'),
            })
            return
        }

        const inputParams = ['', userInfo.actn_curr, userInfo.sub_curr]
        sendRequest(ServiceInfo.GET_CASH_CAN_LENDING, inputParams, handleGetCashCanLending)
    }

    const handleGetCashCanLending = (reqInfoMap, message) => {
        console.log('handleGetCashCanLending message: ', message)
        let tempArr = []
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata
            try {
                if (!message.Data) return
                jsondata = JSON.parse(message.Data)
                tempArr = tempArr.concat(jsondata)
            } catch (err) {
                jsondata = []
            }

            if (Number(message.Packet) <= 0) {
                let totalC3 = 0,
                    totalC9 = 0
                tempArr.forEach((element) => {
                    totalC3 += Number(element.c3)
                    totalC9 += Number(element.c9)
                })
                const lendingObj = jsondata[0]
                lendingObj.c3 = totalC3
                lendingObj.c9 = totalC9
                feeMax.current = totalC9
                // setAmoutFee(totalC9)
                setCanLendingAmount(jsondata[0])
            }
        }

        getHisAdvanceLending()
    }

    const getLendingFee = (value) => {
        if (!userInfo.actn_curr) {
            ToastGlobal.show({
                type: 'warning',
                text2: t('warning_account_is_empty'),
            })
            return
        }
        // setLoadingConfirm
        const inputParams = [' ', userInfo.actn_curr, userInfo.sub_curr, value || String(lendingAmount)]
        sendRequest(ServiceInfo.GET_LENDING_FEE, inputParams, handleGetLendingFee, true, getLendingFeeTimeout)
        setLoadingButton(true)
    }

    const getLendingFeeTimeout = () => {
        setLoadingButton(false)
        setAmoutFee(feeMax.current * (lendingAmount / canLendingAmount?.c10) || feeMax.current)
        setIsOpenModal(true)
    }

    const handleGetLendingFee = (reqInfoMap, message) => {
        setLoadingButton(false)
        // -- process after get result --
        if (Number(message.Result) === 0) {
            setAmoutFee(feeMax.current * (lendingAmount / canLendingAmount?.c10) || feeMax.current)
            setIsOpenModal(true)
            return
        } else {
            let jsondata
            try {
                jsondata = JSON.parse(message.Data)
                setAmoutFee(jsondata[0].c0)
                setIsOpenModal(true)
            } catch (err) {}
        }
    }

    const getHisAdvanceLending = () => {
        if (!userInfo.actn_curr) {
            ToastGlobal.show({
                type: 'warning',
                text2: t('warning_account_is_empty'),
            })
            return
        }

        const inputParams = [
            userInfo.actn_curr,
            userInfo.sub_curr,
            String(filterOption.contractType),
            moment(filterOption.fromDt).format('YYYYMMDD'),
            moment(filterOption.toDt).format('YYYYMMDD'),
            '',
        ]
        sendRequest(ServiceInfo.GET_HIS_ADVANCE_LENDING, inputParams, handlegetHisAdvanceLending)
    }

    const fullAdvancePayment = (isAuthen) => {
        setLendingAmount(canLendingAmount?.c10)

        if (!isAuthen) {
            navigation.navigate(Screens.OTP_MODAL, {
                transactionOTP: true,
                otp_Type: Number(glb_sv.objShareGlb.userInfo.c6),
                functCallback: fullAdvancePayment,
            })
            return
        }
        if (canLendingAmount) {
            getLendingFee(canLendingAmount?.c10)
        }
    }

    const confirmLending = () => {
        hideModal()
        InteractionManager.runAfterInteractions(() => {
            const inputParams = [' ', ' ', ' ', userInfo.actn_curr, userInfo.sub_curr, ' ', ' ', ' ', String(lendingAmount)]
            sendRequest(ServiceInfo.REQ_NEW_LENDING, inputParams, handleConfirmLending)
            setLoadingConfirm(true)
        })
    }

    // ----------------------------------------------------

    const handlegetHisAdvanceLending = (reqInfoMap, message) => {
        // -- process after get result --
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata
            try {
                jsondata = JSON.parse(message.Data)
            } catch (err) {
                jsondata = []
            }
            if (Number(message.Packet) <= 0) {
                setDataLastLending(jsondata)
            }
        }
    }

    const handleConfirmLending = (reqInfoMap, message) => {
        setIsOpenModal(false)
        setLoadingConfirm(false)
        _resetInput()
        // -- process after get result --
        if (Number(message.Result) === 0) {
            const { hasAlertCommonCode } = useAlertModalCommonCode(message, {})
            const { hasAlertErrOtp } = useModalOtpWhenErr(message, { continueVerify: !hasAlertCommonCode, callback: () => setIsOpenModal((prev) => true) })
            useAlertModal(message, { continueVerify: !hasAlertErrOtp })
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {}
            ToastGlobal.show({
                type: 'success',
                text2: message.Message,
            })
        }
    }
    // --------------------------------------------
    const getColor = (status) => {
        if (status === 'N') return styles.REF__COLOR
        if (status === 'R' || status === 'D') return styles.DOWN__COLOR
        if (status === 'Y') return styles.UP__COLOR
    }
    const ViewLastLending = ({ item }) => {
        return (
            <>
                <RowTableData
                    key={item.label}
                    type="table"
                    onPress={() => navigation.navigate(Screens.DETAIL_ADVANCE_LENDING, { data: item, onRefresh: onRefresh })}
                >
                    <ColTableData text={moment(item.c3, 'DDMMYYYY').format('DD/MM/YYYY')} />
                    <ColTableData text={FormatNumber(item?.c7)} textAlign="center" />
                    <ColTableData colorText={getColor(item.c12)} text={t(item?.c17)} textAlign="right" />
                </RowTableData>
            </>
        )
    }

    return (
        <Container>
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft
                navigation={navigation}
                title={t('request_cash_in_advance')}
                titleAlgin="flex-start"
                transparent
            />
            <Content
                refreshControl={
                    <RefreshControl
                        refreshing={refreshing}
                        onRefresh={onRefresh}
                        // title={t('pull_refresh')}
                        // titleColor={styles.PRIMARY__CONTENT__COLOR}
                        tintColor={styles.PRIMARY__CONTENT__COLOR}
                    />
                }
                style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}
            >
                <View>
                    <Account navigation={navigation} />
                    <RowData
                        rightColor={styles.PRIMARY__CONTENT__COLOR}
                        textLeft={t('total_sell')}
                        textRight={FormatNumber(Number(canLendingAmount?.c3))}
                        type="bold"
                    />
                    <RowData
                        rightColor={styles.PRIMARY__CONTENT__COLOR}
                        textLeft={t('cash_lending_available')}
                        textRight={FormatNumber(Number(canLendingAmount?.c10) + Number(canLendingAmount?.c11))}
                        type="bold"
                    />
                    <RowData
                        rightColor={styles.REF__COLOR}
                        textLeft={t('total_pia_amount_wait_approve')}
                        textRight={FormatNumber(canLendingAmount?.c11)}
                        type="bold"
                    />
                    <Pressable onPress={() => canLendingAmount?.c10 && fullAdvancePayment()}>
                        <RowData
                            pointerEvents="none"
                            rightColor={styles.PRIMARY}
                            textLeft={t('total_pia_amount_wait_remain')}
                            textRight={FormatNumber(canLendingAmount?.c10)}
                            type="bold"
                        />
                    </Pressable>
                    <RowData
                        last
                        rightColor={styles.PRIMARY__CONTENT__COLOR}
                        textLeft={t('advance_debt_fee')}
                        textRight={FormatNumber(canLendingAmount?.c9)}
                        type="bold"
                    />
                    <View style={UI.RowInput}>
                        <CustomFloatInput
                            animationDuration={100}
                            errCtrl={t(errCtrl[0])}
                            keyboardType="numeric"
                            label={t('cash_of_PIA')}
                            placeholderTextColor={styles.PLACEHODLER__COLOR}
                            value={FormatNumber(lendingAmount) === '0' ? '' : FormatNumber(lendingAmount)}
                            onChangeText={(amount) => setLendingAmount(glb_sv.filterNumber(amount))}
                        />
                    </View>

                    <ButtonCustom isLoading={loadingButton} text={t('common_button_confirm')} type="confirm" onPress={() => switchStep.onFinish()} />
                    <RowTitleGroup
                        hasDivider
                        rightComponent={
                            <Svg
                                fill="none"
                                height={36}
                                viewBox="0 0 36 36"
                                width={36}
                                xmlns="http://www.w3.org/2000/svg"
                                onPress={() => setIsOpenFilterGroup(!isOpenFilterGroup)}
                            >
                                <Path
                                    clipRule="evenodd"
                                    d="M0 18C0 8.059 8.059 0 18 0s18 8.059 18 18-8.059 18-18 18S0 27.941 0 18z"
                                    fill="#F8F8F8"
                                    fillRule="evenodd"
                                />
                                <Path
                                    d="M26.438 14.514H9.563a.938.938 0 010-1.875h16.874a.937.937 0 110 1.875zm-3.125 4.375H12.688a.938.938 0 010-1.875h10.624a.937.937 0 110 1.875zm-3.75 4.375h-3.125a.938.938 0 010-1.875h3.125a.937.937 0 110 1.875z"
                                    fill="#24253D"
                                />
                            </Svg>
                        }
                        text={t('pia_history')}
                    />
                    <FilterGroup
                        filterOption={filterOption}
                        isOpenFilterGroup={isOpenFilterGroup}
                        setFilterOption={setFilterOption}
                        setIsOpenFilterGroup={setIsOpenFilterGroup}
                    />
                    <HeaderList typeHeader="ADVANCE_LENDING" />
                    <FlatList
                        data={dataLastLending}
                        keyExtractor={(item, index) => index.toString()}
                        ListEmptyComponent={EmptyView}
                        renderItem={ViewLastLending}
                        scrollEnabled={false}
                        style={{ marginBottom: dm.vertical(32), paddingHorizontal: dm.moderate(16) }}
                    />
                </View>
            </Content>
            {/* **************************************** Modal submit ******************************************/}
            {isOpenModal && (
                <Modal isVisible={isOpenModal} useNativeDriver={true} onBackButtonPress={hideModal} onBackdropPress={hideModal}>
                    <ModalContent
                        iconComponent={
                            <Svg fill="none" height={32} viewBox="0 0 33 32" width={33} xmlns="http://www.w3.org/2000/svg">
                                <G clipPath="url(#prefix__clip0)" fill="#2ECC71">
                                    <Path d="M28.604 19.64l-3.547 4.638a3.75 3.75 0 01-2.979 1.472h-6.584a.938.938 0 010-1.875h5.707c1.226 0 2.254-1.004 2.23-2.23a2.188 2.188 0 00-2.187-2.145h-6.562a5.43 5.43 0 00-6.92-.504l-.705.504v10.625H23.36a5.625 5.625 0 004.731-2.583l3.659-5.692c.2-.31.306-.671.306-1.04 0-1.84-2.336-2.631-3.454-1.17zM4.244 17.625H.994a.937.937 0 00-.937.938v12.5c0 .517.42.937.937.937h3.25c.518 0 .938-.42.938-.938v-12.5a.937.937 0 00-.938-.937zM17.95 5.181a.93.93 0 00-.332.56c-.05.265.014.511.162.627.051.04.109.08.17.12V5.181z" />
                                    <Path d="M18.62 15.625c4.307 0 7.812-3.505 7.812-7.813C26.432 3.505 22.927 0 18.619 0s-7.812 3.505-7.812 7.813c0 4.307 3.504 7.812 7.812 7.812zm-2.366-5.258a.625.625 0 01.865-.181c.338.22.55.316.832.356v-2.64a4.612 4.612 0 01-.942-.55c-.519-.407-.756-1.113-.618-1.842.15-.795.703-1.428 1.444-1.65a3.54 3.54 0 01.116-.034v-.389a.625.625 0 011.25 0v.32c.607.106 1.036.405 1.244.643a.625.625 0 01-.94.825.86.86 0 00-.304-.18v2.02l.33.119c1.1.388 1.71 1.405 1.521 2.53-.147.875-.813 1.762-1.851 2.026v.447a.625.625 0 01-1.25 0V11.8c-.505-.044-.923-.18-1.516-.568a.625.625 0 01-.18-.865z" />
                                    <Path d="M19.82 9.508c.04-.244.058-.826-.619-1.111v2.008c.352-.202.562-.558.619-.897z" />
                                </G>
                                <Defs>
                                    <ClipPath id="prefix__clip0">
                                        <Path d="M0 0h32v32H0z" fill="#fff" transform="translate(.057)" />
                                    </ClipPath>
                                </Defs>
                            </Svg>
                        }
                        title={t('common_confirm')}
                        type="confirm"
                    >
                        <RowDataModal dataSub={[userInfo.actn_curr, userInfo.sub_curr]} textLeft={t('acnt_no')} textRight={userInfo.actn_curr} />
                        <RowDataModal textLeft={t('amount_drawal')} textRight={FormatNumber(lendingAmount)} />
                        <RowDataModal
                            textLeft={t('total_fee')}
                            // textRight={FormatNumber(amoutFee * (lendingAmount / canLendingAmount?.c10)) || FormatNumber(amoutFee)}
                            textRight={FormatNumber(amoutFee)}
                        />
                        <ButtonCustom text={t('common_button_confirm')} type="confirm" onPress={() => switchStep.submit()} />
                        <ButtonCustom last text={t('common_Cancel')} type="back" onPress={hideModal} />
                    </ModalContent>
                </Modal>
            )}
            {/* **************************************** Modal Filter ******************************************/}
            {loadingConfirm && <ModalLoading content={t('common_processing')} visible={loadingConfirm} />}
        </Container>
    )
}

export default AdvanceLendingLayout

const FilterGroup = ({ isOpenFilterGroup, setIsOpenFilterGroup, filterOption, setFilterOption }) => {
    const { styles, theme, language } = useContext(StoreContext)
    const { t } = useTranslation()

    const [isFocus, setIsFocus] = useState({
        from: false,
        to: false,
        contractTypeOpen: false,
    })

    const onFinish = () => {
        setIsFocus({
            from: false,
            to: false,
            contractTypeOpen: false,
        })
    }
    const contractTypeList = [
        { index: 0, value: '0', label: t('all_contract_status') },
        { index: 1, value: '1', label: t('all_contract_not_expire') },
        { index: 2, value: '2', label: t('all_contract_need_repay') },
    ]

    const onSelectContractType = (item) => {
        setFilterOption({ ...filterOption, contractType: item.value })
        setTimeout(() => onFinish(), 300)
    }

    return (
        <>
            {isOpenFilterGroup && (
                <View style={UI.GroupFilter}>
                    <Row>
                        <Col size={12}>
                            <Pressable onPress={() => setIsFocus({ ...isFocus, from: true })}>
                                <View pointerEvents="none" style={UI.RowFilter}>
                                    <CustomFloatInput
                                        label={t('common_from_date')}
                                        rightComponent={
                                            <IconCalendar fill={styles.PRIMARY__CONTENT__COLOR} style={{ marginVertical: dm.vertical(20), marginRight: 5 }} />
                                        }
                                        staticLabel
                                        value={moment(filterOption.fromDt).format('DD/MM/YYYY')}
                                    />
                                </View>
                            </Pressable>
                        </Col>
                        <Col size={12}>
                            <Pressable onPress={() => setIsFocus({ ...isFocus, to: true })}>
                                <View pointerEvents="none" style={UI.RowFilter}>
                                    <CustomFloatInput
                                        label={t('common_to_date')}
                                        rightComponent={
                                            <IconCalendar fill={styles.PRIMARY__CONTENT__COLOR} style={{ marginVertical: dm.vertical(20), marginRight: 5 }} />
                                        }
                                        staticLabel
                                        value={moment(filterOption.toDt).format('DD/MM/YYYY')}
                                    />
                                </View>
                            </Pressable>
                        </Col>
                    </Row>
                    <Pressable onPress={() => setIsFocus({ ...isFocus, contractTypeOpen: !isFocus.contractTypeOpen })}>
                        <View pointerEvents="none" style={UI.RowFilter}>
                            <CustomFloatInput
                                label={t('contract_type')}
                                staticLabel
                                value={t(contractTypeList.filter((o) => o.value === filterOption.contractType)?.pop()?.label)}
                            />
                        </View>
                    </Pressable>
                </View>
            )}
            <DateTimePickerModal
                cancelTextIOS={t('common_Cancel')}
                confirmTextIOS={t('common_Ok')}
                date={filterOption.fromDt}
                headerTextIOS=""
                isDarkModeEnabled={theme.includes('DARK')}
                isVisible={isFocus.from}
                locale={language === 'VI' ? 'vi_VN' : 'en_US'}
                mode="date"
                onCancel={onFinish}
                onConfirm={(value) => {
                    onFinish()
                    setFilterOption({ ...filterOption, fromDt: value })
                }}
            />

            <DateTimePickerModal
                cancelTextIOS={t('common_Cancel')}
                confirmTextIOS={t('common_Ok')}
                date={filterOption.toDt}
                headerTextIOS=""
                isDarkModeEnabled={theme.includes('DARK')}
                isVisible={isFocus.to}
                locale={language === 'VI' ? 'vi_VN' : 'en_US'}
                mode="date"
                onCancel={onFinish}
                onConfirm={(value) => {
                    onFinish()
                    setFilterOption({ ...filterOption, toDt: value })
                }}
            />
            {isFocus.contractTypeOpen && (
                <Modal
                    hideModalContentWhileAnimating={true}
                    isVisible={isFocus.contractTypeOpen}
                    style={UI.bottomModal}
                    useNativeDriver={true}
                    onBackButtonPress={() => onFinish()}
                    onBackdropPress={() => onFinish()}
                >
                    <ModalBottomContent title={t('contract_type')}>
                        {contractTypeList.map((item, index) => (
                            <ModalBottomRowSelect
                                checked={filterOption.contractType === item.value}
                                key={index}
                                text={t(item.label)}
                                onPress={() => onSelectContractType(item)}
                            />
                        ))}
                    </ModalBottomContent>
                </Modal>
            )}
        </>
    )
}

const UI = StyleSheet.create({
    Button: {
        alignItems: 'center',
        borderRadius: 8,
        height: dm.moderate(28),
        justifyContent: 'center',
        width: dm.moderate(28),
    },
    GroupFilter: {
        flex: 1,
        marginHorizontal: dm.moderate(8),
        marginVertical: dm.vertical(4),
    },
    Row: {
        flex: 1,
        justifyContent: 'center',
        marginHorizontal: dm.moderate(16),
        paddingBottom: dm.vertical(16),
        paddingTop: dm.vertical(16),
    },
    RowFilter: {
        marginHorizontal: dm.moderate(8),
        marginVertical: dm.vertical(8),
    },
    RowInput: {
        marginHorizontal: dm.moderate(16),
        marginVertical: dm.vertical(16),
    },
    Row_Modal: {
        height: dm.vertical(24),
        marginVertical: dm.vertical(16),
    },
    Row_view: {
        flex: 1,
        paddingBottom: dm.vertical(8),
        paddingTop: dm.vertical(8),
    },
    bottomModal: {
        justifyContent: 'flex-end',
        margin: 0,
    },
    current_cash: {
        fontSize: fs.medium,
        fontWeight: fw.extraBold,
    },
    divider: {
        height: 1,
        width: '90%',
    },
    margin_top_row: {
        marginBottom: dm.moderate(24),
        marginHorizontal: dm.moderate(16),
        marginTop: dm.moderate(16),
    },
    modalContent: {
        backgroundColor: 'white',
        borderColor: 'rgba(0, 0, 0, 0.1)',
        borderTopLeftRadius: 5,
        borderTopRightRadius: 5,
        paddingBottom: 40,
    },
})
