import React, { Component, createRef } from 'react'
import { Dimensions, Platform, StyleSheet } from 'react-native'
import WebView from 'react-native-webview'

const changeData = (DATA_LINE, DATA_VOLUME, typeTime) => `
  if (areaSeries) areaSeries.setData(${JSON.stringify(DATA_LINE)});
  if (volumeSeries) volumeSeries.setData(${JSON.stringify(DATA_VOLUME)});
  if (chartIntra) chart.timeScale().fitContent();
`

const changeTheme = (theme) => `
  chart.applyOptions({
    layout: ${theme.includes('DARK')} ? {
      backgroundColor: 'transparent',
      textColor: '#d1d4dc',
    } : {
        backgroundColor: 'transparent',
      },
    grid: ${theme.includes('DARK')} ? {
      vertLines: {
        color: 'rgba(42, 46, 57, 0.6)',
      },
      horzLines: {
        color: 'rgba(42, 46, 57, 0.6)',
      },
    } : {
        vertLines: {
          color: '#d5d1c699',
        },
        horzLines: {
          color: '#d5d1c699',
        },
      },

  });
`

const source = Platform.select({
    ios: require('./light-chart.html'),
    android: { uri: 'file:///android_asset/light-chart.html' },
})

export default class LightChart extends Component {
    static defaultProps = {
        onChange: () => {},
        initScript: '',
        data: [],
    }

    constructor(props) {
        super(props)
        this.chart = createRef()
        this.state = {
            deviceWidth: Dimensions.get('window').width,
            deviceHeight: Dimensions.get('window').height,
        }
    }

    handleDimensionsUpdate = () => {
        // Here we update the device dimensions in the state if the layout changed
        // (triggering a render)
        const deviceWidth = Dimensions.get('window').width
        const deviceHeight = Dimensions.get('window').height
        if (deviceWidth !== this.state.deviceWidth || deviceHeight !== this.state.deviceHeight) {
            this.setState({ deviceWidth, deviceHeight }, this.repaint)
        }
    }

    componentWillReceiveProps(nextProps) {
        const { DATA_LINE, theme } = this.props
        if (DATA_LINE !== nextProps.DATA_LINE) {
            this.update(nextProps.DATA_LINE, nextProps.DATA_VOLUME, nextProps.typeTime)
        }
        if (theme !== nextProps.theme) {
            this.chart.current && this.chart.current.injectJavaScript(changeTheme(nextProps.theme))
        }
    }

    update = (DATA_LINE, DATA_VOLUME, typeTime) => {
        this.chart.current && this.chart.current.injectJavaScript(changeData(DATA_LINE, DATA_VOLUME, typeTime))
    }

    onMessage = (event) => {
        const {
            nativeEvent: { data },
        } = event
        const { onLoadMore } = this.props
        const tooltip = JSON.parse(data)
        onLoadMore && onLoadMore(tooltip)
    }

    repaint = () => {
        this.setState(
            {
                repaint: true,
            },
            () => {
                this.setState({ repaint: false })
            },
        )
    }

    render() {
        const { data, onChange, initScript, ...props } = this.props

        return (
            <WebView
                androidHardwareAccelerationDisabled
                androidLayerType="software"
                injectedJavaScript={initScript}
                javaScriptEnabled
                originWhitelist={['*']}
                ref={this.chart}
                scrollEnabled={false}
                source={source}
                style={styles.webView}
                onMessage={this.onMessage}
                {...props}
            />
        )
    }
}

const styles = StyleSheet.create({
    webView: {
        backgroundColor: 'transparent',
        flex: 1,
    },
})
