import React, { memo, useContext, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { ScrollView, StyleSheet, Text, View } from 'react-native'
import Svg, { Circle, ClipPath, Defs, G, Path } from 'react-native-svg'
import { Button, Col, Row } from 'native-base'

import { ModalSelector } from '../../basic-components'
import { StoreContext } from '../../store'
import { StoreTrading } from '../../store-trading'
import { dimensions as dm, fontSizes } from '../../styles'
import { glb_sv } from '../../utils'

const Account = () => {
    const { styles } = useContext(StoreContext)
    const { userInfo, setUserInfo } = useContext(StoreTrading)
    const { t } = useTranslation()

    const [visibleModalAct, setVisibleModalAct] = useState(false)

    const changeSubAct = (item) => {
        if (item === userInfo.sub_curr) return
        setUserInfo({ ...userInfo, sub_curr: item })
        glb_sv.userInfoAccount = { ...userInfo, sub_curr: item }
    }

    const changeActMain = (item) => {
        const js_acntInfo = glb_sv.objShareGlb.acntNoInfo
        const sub_list = []
        js_acntInfo.forEach((e) => {
            if (e.AcntNo === item.AcntNo) sub_list.push(e.SubNo)
        })
        setUserInfo({
            ...userInfo,
            actn_curr: item.AcntNo,
            sub_curr: sub_list[0],
            actn_name: item.actn_name,
            sub_list,
        })
        glb_sv.userInfoAccount = {
            ...userInfo,
            actn_curr: item.AcntNo,
            sub_curr: sub_list[0],
            actn_name: item.actn_name,
            sub_list,
        }
    }

    const IconSelectAccount = (props) => {
        return (
            <Svg fill="none" height={14} viewBox="0 0 14 14" width={14} xmlns="http://www.w3.org/2000/svg" {...props}>
                <G clipPath="url(#prefix__clip0)" opacity={0.6}>
                    <Circle cx={7} cy={7} fill="#24253D" opacity={0.2} r={7} />
                    <Path d="M5.834 4.666l2.545 2.545-2.545 2.546" stroke="#24253D" strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.313} />
                </G>
                <Defs>
                    <ClipPath id="prefix__clip0">
                        <Path d="M0 0h14v14H0z" fill="#fff" />
                    </ClipPath>
                </Defs>
            </Svg>
        )
    }

    const initValue = userInfo.actn_list.find((e) => e.AcntNo === userInfo.actn_curr)
        ? userInfo.actn_list.find((e) => e.AcntNo === userInfo.actn_curr).label
        : ''
    return (
        <View style={UI.view_accnt}>
            <Row style={UI.name_act}>
                <Col size={3} />
                <Col size={18} style={{ justifyContent: 'center', alignItems: 'center' }}>
                    <Text
                        numberOfLines={1}
                        style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal }}
                        onPress={() => (userInfo.actn_list.length > 1 ? setVisibleModalAct(false) : null)}
                    >
                        {userInfo.actn_curr}
                    </Text>
                    <Text
                        numberOfLines={1}
                        style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal }}
                        onPress={() => (userInfo.actn_list.length > 1 ? setVisibleModalAct(false) : null)}
                    >
                        ({userInfo.actn_name})
                    </Text>
                </Col>
                <Col size={3}>{userInfo.actn_list.length > 1 && <IconSelectAccount onPress={() => setVisibleModalAct(true)} />}</Col>
            </Row>
            <Row style={UI.list_sub}>
                <ScrollView horizontal>
                    {userInfo.sub_list.map((item) => (
                        <Button
                            key={item}
                            style={{
                                backgroundColor: item === userInfo.sub_curr ? styles.PRIMARY : styles.BUTTON__SECONDARY,
                                marginHorizontal: dm.moderate(4),
                                height: dm.vertical(45),
                                width: dm.vertical(45),
                                alignContent: 'center',
                                justifyContent: 'center',
                                marginVertical: dm.vertical(4),
                                borderRadius: 8,
                            }}
                            onPress={() => changeSubAct(item)}
                        >
                            <Text
                                style={{
                                    color: item === userInfo.sub_curr ? 'white' : styles.PRIMARY__CONTENT__COLOR,
                                    fontSize: fontSizes.normal,
                                    paddingHorizontal: dm.moderate(5),
                                }}
                            >
                                {item}
                            </Text>
                        </Button>
                    ))}
                </ScrollView>
            </Row>
            <ModalSelector
                accessible={true}
                cancelText={t('common_Cancel')}
                data={userInfo.actn_list}
                initValue={initValue}
                selectedItemTextStyle={{ color: styles.PRIMARY }}
                supportedOrientations={['portrait']}
                visible={visibleModalAct}
                onChange={(option) => changeActMain(option)}
                onModalClose={() => (userInfo.actn_list.length > 1 ? setVisibleModalAct(false) : null)}
            />
        </View>
    )
}

export default memo(Account)

const UI = StyleSheet.create({
    icon_name_act: {
        flexDirection: 'row',
        paddingHorizontal: 8,
        paddingVertical: 5,
    },
    list_sub: {
        alignItems: 'center',
        flexDirection: 'column',
        flex: 1,
        justifyContent: 'center',
        paddingTop: 8,
        paddingVertical: 5,
    },
    name_act: {
        alignItems: 'center',
        flex: 1,
        justifyContent: 'center',
        paddingTop: 8,
        paddingVertical: 5,
    },
    view_accnt: {
        alignItems: 'center',
        flex: 1,
        justifyContent: 'center',
    },
})
