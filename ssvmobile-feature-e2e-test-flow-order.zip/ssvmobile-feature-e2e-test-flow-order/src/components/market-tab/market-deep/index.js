import React, { memo, useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Pressable, StyleSheet, Text, View } from 'react-native'
import ModalController from '@mts-components/appModal/modalControlller'
import { VictoryAxis, VictoryBar, VictoryChart } from 'victory-native'

import { StoreContext } from '../../../store'
import { dimensions, fontSizes, IconSvg } from '../../../styles'
import { WIDTH } from '../../../styles/helper/dimensions'
import { eventList, glb_sv, Screens, subcribeFunct } from '../../../utils'

const MarketDeep = ({ code, navigation, showName }) => {
    const { t } = useTranslation()
    const { styles } = useContext(StoreContext)
    const [data, setData] = useState([])
    const [sum, setSum] = useState(0)
    const [widthRow, setWidthRow] = useState({
        widthDown: 0,
        widthRef: 0,
        widthUp: 0,
    })
    const [decliners, setDecliners] = useState(0)
    const [advancers, setAdvancers] = useState(0)

    useEffect(() => {
        subcribeFunct(null, null, 'SUB', ['MKT_INC_DEC'], [code])
        const eventMarket = glb_sv.eventMarket.subscribe((msg) => {
            if (msg.type === eventList.MKT_INC_DEC && code === msg.msgKey) {
                const array = [
                    {
                        x: '-7%<=',
                        y: msg.data.L5,
                    },
                    {
                        x: '-7-5%',
                        y: msg.data.L4,
                    },
                    {
                        x: '-5-3%',
                        y: msg.data.L3,
                    },
                    {
                        x: '-3-1%',
                        y: msg.data.L2,
                    },
                    {
                        x: '-1-0%',
                        y: msg.data.L1,
                    },
                    {
                        x: '0%',
                        y: msg.data.L0,
                    },
                    {
                        x: '0-1%',
                        y: msg.data.H1,
                    },
                    {
                        x: '1-3%',
                        y: msg.data.H2,
                    },
                    {
                        x: '3-5%',
                        y: msg.data.H3,
                    },
                    {
                        x: '5-7%',
                        y: msg.data.H4,
                    },
                    {
                        x: '>=7%',
                        y: msg.data.H5,
                    },
                ]
                const total =
                    msg.data.H1 +
                    msg.data.H2 +
                    msg.data.H3 +
                    msg.data.H4 +
                    msg.data.H5 +
                    msg.data.L0 +
                    msg.data.L1 +
                    msg.data.L2 +
                    msg.data.L3 +
                    msg.data.L4 +
                    msg.data.L5

                setSum(total)
                setData(array)
                setDecliners(msg.data.L1 + msg.data.L2 + msg.data.L3 + msg.data.L4 + msg.data.L5)
                setAdvancers(msg.data.H1 + msg.data.H2 + msg.data.H3 + msg.data.H4 + msg.data.H5)
                const totalWidth = WIDTH - dimensions.moderate(6) * 2
                if (total) {
                    setWidthRow({
                        widthDown: ((msg.data.L1 + msg.data.L2 + msg.data.L3 + msg.data.L4 + msg.data.L5) / total) * totalWidth,
                        widthRef: (msg.data.L0 / total) * totalWidth,
                        widthUp: ((msg.data.H1 + msg.data.H2 + msg.data.H3 + msg.data.H4 + msg.data.H5) / total) * totalWidth,
                    })
                } else {
                    setWidthRow({
                        widthDown: 0,
                        widthRef: totalWidth,
                        widthUp: 0,
                    })
                }
            }
        })

        return () => {
            eventMarket.unsubscribe()
            subcribeFunct(null, null, 'UNSUB', ['MKT_INC_DEC'], [code])
        }
    }, [code])

    const openInfo = () => {
        // navigation.navigate(Screens.ALERT_MODAL, {
        //     // icon: <IconSvg.ErrorIcon color={styles.INFO__COLOR} />,
        //     title: t('market_deep'),
        //     content: t('market_deep_info'),
        //     typeColor: styles.INFO__COLOR,
        // })
        ModalController.showModal({
            title: t('market_deep'),
            content: t('market_deep_info'),
            typeColor: styles.INFO__COLOR,
            isBackdropClose: true,
        })
    }

    return (
        <View>
            <View style={{ flexDirection: 'row', paddingHorizontal: dimensions.moderate(12) }}>
                <Text style={{ color: !showName ? styles.PRIMARY__CONTENT__COLOR : styles.PRIMARY, fontSize: fontSizes.medium, fontWeight: '600' }}>
                    {t('market_deep')} {!showName ? '' : code === 'HSXIndex' ? 'HSX' : code === 'HNXIndex' ? 'HNX' : code === 'HNXUpcomIndex' ? 'UPC' : ''}
                </Text>
                <Pressable hitSlop={12} style={{ paddingTop: 2 }} onPress={openInfo}>
                    <IconSvg.InfoIcon color={styles.PRIMARY__CONTENT__COLOR} />
                </Pressable>
                <View style={UI.total}>
                    <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small }}>
                        {t('common_total')} {sum}
                    </Text>
                </View>
            </View>

            <VictoryChart
                height={230}
                padding={{
                    top: 30,
                    bottom: 20,
                    right: 20,
                    left: 20,
                }}
            >
                <VictoryAxis
                    style={{
                        tickLabels: { fontSize: 10, padding: 0, fontWeight: '500', fill: styles.PRIMARY__CONTENT__COLOR },
                        axis: { stroke: 'transparent' },
                    }}
                />
                <VictoryBar
                    alignment="middle"
                    barRatio={1}
                    cornerRadius={2}
                    data={data}
                    labels={({ datum }) => {
                        return datum.y
                    }}
                    style={{
                        data: {
                            fill: ({ datum }) => {
                                return datum._x === 6 ? styles.REF__COLOR : datum._x < 6 ? styles.DOWN__COLOR : styles.UP__COLOR
                            },
                        },
                        labels: {
                            fill: ({ datum }) => {
                                return datum._x === 6 ? styles.REF__COLOR : datum._x < 6 ? styles.DOWN__COLOR : styles.UP__COLOR
                            },
                        },
                    }}
                />
            </VictoryChart>

            <View style={{ height: 3, flexDirection: 'row', paddingHorizontal: dimensions.moderate(6) }}>
                <View style={{ backgroundColor: styles.DOWN__COLOR, width: widthRow.widthDown }} />
                <View style={{ backgroundColor: styles.REF__COLOR, width: widthRow.widthRef }} />
                <View style={{ backgroundColor: styles.UP__COLOR, width: widthRow.widthUp }} />
            </View>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: dimensions.moderate(6) }}>
                <Text style={{ color: styles.DOWN__COLOR, fontSize: fontSizes.verySmall }}>
                    {t('decliners')}: {decliners}
                </Text>
                <Text style={{ color: styles.UP__COLOR, fontSize: fontSizes.verySmall }}>
                    {t('advancers')}: {advancers}
                </Text>
            </View>
        </View>
    )
}

const UI = StyleSheet.create({
    total: { position: 'absolute', right: 8, top: 20 },
})

export default memo(MarketDeep)
