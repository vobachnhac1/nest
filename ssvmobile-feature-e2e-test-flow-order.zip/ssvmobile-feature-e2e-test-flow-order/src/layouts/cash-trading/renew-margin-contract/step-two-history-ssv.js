import React, { useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { StyleSheet, View } from 'react-native'
import moment from 'moment'

import { ButtonCustom, RowData } from '../../../components/trading-component'
import { StoreContext } from '../../../store'
import { StoreTrading } from '../../../store-trading'
import { dimensions as dm } from '../../../styles'
import FormatNumber from '../../../utils/formatNumber/FormatNumber'

// Khai báo ServiceInfo (nếu có)

// Khai báo component
const StepTwo = ({ switchStep, contactHistory, cancelContractHistBfSend }) => {
    const { t } = useTranslation()
    const { styles } = useContext(StoreContext)

    const getColor = (status) => {
        if (status === 'N') return styles.wait_to_match_color
        if (status === 'R' || status === 'D') return styles.reject_color
        if (status === 'Y') return styles.UP__COLOR
    }

    return (
        <View>
            <View style={{ flex: 1, marginRight: dm.halfIndent }}>
                <RowData textLeft={t('contract_num')} textRight={contactHistory.c2} />

                <RowData textLeft={t('loan_amount')} textRight={FormatNumber(contactHistory.c3, 0, 0)} />

                <RowData textLeft={t('loan_current')} textRight={FormatNumber(contactHistory.c4, 0, 0)} />

                <RowData textLeft={t('interest_in_time')} textRight={FormatNumber(contactHistory.c5, 0, 0)} />

                <RowData textLeft={t('interest_penalty')} textRight={FormatNumber(contactHistory.c7, 0, 0)} />
                <RowData textLeft={t('end_date')} textRight={contactHistory.c8.trim() ? moment(contactHistory.c8, 'DDMMYYYY').format('DD/MM/YYYY') : ''} />
                <RowData textLeft={t('working_date')} textRight={contactHistory.c9.trim() ? moment(contactHistory.c9, 'DDMMYYYY').format('DD/MM/YYYY') : ''} />
                <RowData rightColor={getColor(contactHistory.c10)} textLeft={t('approve_status')} textRight={contactHistory.c11} />
                <RowData
                    textLeft={t('approve_time')}
                    textRight={contactHistory.c12.trim() ? moment(contactHistory.c12, 'DDMMYYYY').format('DD/MM/YYYY') : ''}
                />
                <RowData textLeft={t('reason_extension')} textRight={contactHistory.c13} />
                <RowData textLeft={t('reason_reject')} textRight={contactHistory.c14} />

                <ButtonCustom
                    color={styles.ERROR__COLOR}
                    disabled={contactHistory.c10 !== 'N'}
                    text={t('common_Cancel')}
                    type="confirm"
                    onPress={cancelContractHistBfSend}
                />
                <ButtonCustom last text={t('common_back')} type="back" onPress={() => switchStep.prev()} />
            </View>
        </View>
    )
}
const UI = StyleSheet.create({
    Badge_Sub: {
        alignItems: 'center',
        borderRadius: 4,
        height: dm.moderate(20),
        justifyContent: 'center',
        marginLeft: 4,
        width: dm.moderate(20),
    },
    Button: {
        alignItems: 'center',
        borderRadius: 4,
        height: dm.moderate(20),
        justifyContent: 'center',
        width: dm.moderate(20),
    },
    GroupInput: {
        marginVertical: dm.halfVerticalIndent,
        paddingHorizontal: dm.halfIndent,
    },
    RowInput: {
        marginLeft: dm.moderate(8),
        marginVertical: dm.vertical(8),
    },
})
export default StepTwo
