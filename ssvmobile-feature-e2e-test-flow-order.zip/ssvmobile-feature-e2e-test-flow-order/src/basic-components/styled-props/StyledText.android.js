import styled from 'styled-components/native'

import { fontSizes } from '../../styles'

const StyledText = styled.Text`
    color: ${(props) => props.color || ''};
    font-size: ${(props) => props.fontSize || fontSizes.normal}px;
    font-weight: ${(props) => props.fontWeight || '400'};
    font-family: ${(props) => getFontWeight(props.fontWeight)};
    /* padding: ${(props) => props.padding || 0}px;
    padding-right: ${(props) => props.paddingRight || 0}px;
    padding-left: ${(props) => props.paddingLeft || 0}px;
    padding-top: ${(props) => props.paddingTop || 0}px;
    padding-bottom: ${(props) => props.paddingBottom || 0}px;
    margin: ${(props) => props.margin || 0}px;
    margin-right: ${(props) => props.marginRight || 0}px;
    margin-left: ${(props) => props.marginLeft || 0}px;
    margin-top: ${(props) => props.marginTop || 0}px;
    margin-bottom: ${(props) => props.marginBottom || 0}px; */
`

function getFontWeight(wei) {
    if (['100', '200', '300'].includes(wei)) return 'OpenSans-Light'
    if (['500', '600'].includes(wei)) return 'OpenSans-SemiBold'
    if (['700', '800', '900'].includes(wei)) return 'OpenSans-ExtraBold'
    return 'OpenSans-Regular'
}

export default StyledText
