import React, { useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { FlatList, View } from 'react-native'
import ToastGlobal from 'react-native-toast-message'

import Account from '../../../components/account'
import { ButtonCustom, ColTableData, RowData, RowTableData, RowTitleGroup } from '../../../components/trading-component'
import EmptyView from '../../../components/trading-component/empty-view'
import HeaderList from '../../../components/trading-component/header-list'
import { StoreContext } from '../../../store'
import { StoreTrading } from '../../../store-trading'
import { dimensions as dm } from '../../../styles'
import { eventList, glb_sv, reqFunct, Screens, sendRequest } from '../../../utils'
import FormatNumber from '../../../utils/formatNumber/FormatNumber'

// Khai báo ServiceInfo (nếu có)
const ServiceInfo = {
    GET_CURRENT_CASH_BY_SUB: {
        reqFunct: reqFunct.GET_CURRENT_CASH_BY_SUB, //Lấy "Số dư hiện tại"
        WorkerName: 'FOSqCash',
        ServiceName: 'FOSqCash_0201_2',
        ClientSentTime: '0',
        Operation: 'Q',
        // TestInput: ['1', userInfo.actn_curr, '00']
    },
    GET_HIS_PAY_ON_ACCOUT_BY_SUB: {
        reqFunct: reqFunct.GET_HIS_PAY_ON_ACCOUT_BY_SUB, // Lấy DS giao dịch gần nhất theo theo sub
        WorkerName: 'FOSqCash',
        ServiceName: 'FOSqCash_0201_1',
        ClientSentTime: '0',
        Operation: 'Q',
        // TestInput: ["2", "888c000354", "00"]
    },
    GET_HIS_PAY_ON_ACCOUT_BY_ACT: {
        reqFunct: reqFunct.GET_HIS_PAY_ON_ACCOUT_BY_ACT, // Lịch sử giao dịch nộp tiền theo tài khoản
        WorkerName: 'FOSqCash',
        ServiceName: 'FOSqCash_0201_1',
        ClientSentTime: '0',
        Operation: 'Q',
        // TestInput: ["2", "888c000354", "%"]
    },
}

// Khai báo component
const StepOne = ({ navigation, currentSubCash, setCurrentSubCash, switchStep, refreshing, setRefreshing, onRefresh }) => {
    const { styles } = useContext(StoreContext)
    const { userInfo } = useContext(StoreTrading)
    const { t } = useTranslation()
    const colSpan = [3, 3, 4]

    // -------------------------------------------   Khai báo các state nội bộ component

    const [dataLastTransfer, setDataLastTransfer] = useState([])
    const [dataLastTranferAllSub, setDataLastTranferAllSub] = useState([])
    // -------------------------------------------   Dùng useEffect get các dữ liệu cần thiết còn thiếu
    useEffect(() => {
        // Prepare data
        getCurrentCashBySub() // Lấy số dư hiện tại
        // getHisPayOnAccountBySub()   // Lấy lịch sử chuyển tiền
    }, [userInfo.sub_curr, userInfo.actn_curr])

    useEffect(() => {
        getHisPayOnAccountByAct() // Lấy tất cả lịch sử chuyển tiền

        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.LOGIN_SUCCESS) {
                // reCall service FOSq
                getCurrentCashBySub()
                getHisPayOnAccountByAct()
            }
        })

        return () => {
            commonEvent.unsubscribe()
        }
    }, [])

    useEffect(() => {
        if (refreshing) {
            getCurrentCashBySub()
            getHisPayOnAccountByAct()
        }
    }, [refreshing])
    // -------------------------------------------   Viết các hàm để set lại bussiness form state. Nên viết đúng một chuẩn duy nhất để dễ control

    // -------------------------------------------   Khai báo các hàm gửi (request) lên server
    const getCurrentCashBySub = () => {
        if (!userInfo.actn_curr) {
            ToastGlobal.show({
                type: 'warning',
                text2: t('warning_account_is_empty'),
            })
            return
        }

        const inputParams = ['1', userInfo.actn_curr, userInfo.sub_curr]
        sendRequest(ServiceInfo.GET_CURRENT_CASH_BY_SUB, inputParams, handleGetCurrentCashBySub)
    }

    const getHisPayOnAccountBySub = () => {
        if (!userInfo.actn_curr) {
            ToastGlobal.show({
                type: 'warning',
                text2: t('warning_account_is_empty'),
            })
            return
        }

        const inputParams = ['2', userInfo.actn_curr, userInfo.sub_curr]
        sendRequest(ServiceInfo.GET_HIS_PAY_ON_ACCOUT_BY_SUB, inputParams, handleGetHisPayOnAccountBySub)
    }

    const getHisPayOnAccountByAct = () => {
        if (!userInfo.actn_curr) {
            ToastGlobal.show({
                type: 'warning',
                text2: t('warning_account_is_empty'),
            })
            return
        }

        const inputParams = ['2', userInfo.actn_curr, '%']
        sendRequest(ServiceInfo.GET_HIS_PAY_ON_ACCOUT_BY_ACT, inputParams, handleGetHisPayOnAccountByAct)
    }
    // -------------------------------------------   Khai báo các hàm nhận (handle respone) dữ liệu từ server

    // -------------------------------------------   Khai báo các hàm nhận (handle respone) dữ liệu từ server
    const handleGetCurrentCashBySub = (reqInfoMap, message) => {
        // -- process after get result --
        if (Number(message.Result) === 0) {
            console.warn('false handleGetCurrentCashBySub', reqInfoMap, message.Data, message.Message)
            setCurrentSubCash({})
            return
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {}
            setCurrentSubCash(jsondata[0])
        }
    }
    // -----------------------------------------
    const handleGetHisPayOnAccountBySub = (reqInfoMap, message) => {
        // -- process after get result --
        if (Number(message.Result) === 0) {
            console.warn('false handleGetHisPayOnAccountBySub', reqInfoMap, message.Data, message.Message)
            return
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {}
            // console.log(jsondata);
            setDataLastTransfer(jsondata)
        }
    }
    //---------------------------------------------
    const handleGetHisPayOnAccountByAct = (reqInfoMap, message) => {
        // -- process after get result --
        if (Number(message.Result) === 0) {
            console.warn('false handleGetHisPayOnAccountByAct', reqInfoMap, message.Data, message.Message)
            return
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {}
            // console.log('result handleGetHisPayOnAccountByAct', jsondata);
            setDataLastTranferAllSub(jsondata)
        }
    }
    // --------------------------------------------
    const getColor = (status) => {
        if (status === 'N') return styles.REF__COLOR
        if (status === 'R' || status === 'D') return styles.DOWN__COLOR
        if (status === 'Y') return styles.UP__COLOR
    }
    const getColorSub = (sub) => {
        const listColor = [styles.UP__COLOR, styles.REF__COLOR, styles.DOWN__COLOR]
        return listColor[Number(sub)] || styles.REF__COLOR
    }

    const ViewLastTransfer = ({ item }) => {
        return (
            <>
                <RowTableData
                    key={item.label}
                    type="table"
                    onPress={() => navigation.navigate(Screens.DETAIL_HIS_PAYMENT_ON_ACCOUNT, { data: item, onRefresh: onRefresh })}
                >
                    <ColTableData colorSub={getColorSub(item.c3)} colSpan={colSpan[0]} dataSub={[item.c2, item.c3]} text2={item.c4} />
                    <ColTableData colSpan={colSpan[1]} text={FormatNumber(item.c11)} textAlign="right" />
                    <ColTableData colorText={getColor(item.c21)} colSpan={colSpan[1]} text={t(item.c27)} textAlign="right" />
                </RowTableData>
            </>
        )
    }
    return (
        <View>
            <Account navigation={navigation} />
            <RowData last rightColor={styles.PRIMARY} textLeft={t('cash_amount')} textRight={FormatNumber(Number(currentSubCash.c4), 0)} type="info" />
            <ButtonCustom
                text={t('continue')}
                type="confirm"
                onPress={() => {
                    if (!userInfo.actn_curr) {
                        ToastGlobal.show({
                            type: 'warning',
                            text2: t('warning_account_is_empty'),
                        })
                        return
                    }

                    switchStep.next()
                }}
            />
            <RowTitleGroup hasDivider text={t('title_payment_notice_history')} />
            <HeaderList colSpan={colSpan} typeHeader="DEPOSIT_HISTORY" />
            <FlatList
                data={dataLastTranferAllSub}
                keyExtractor={(item, index) => index.toString()}
                ListEmptyComponent={EmptyView}
                renderItem={ViewLastTransfer}
                style={{ marginBottom: dm.vertical(32), paddingHorizontal: dm.moderate(16) }}
            />
        </View>
    )
}

export default StepOne
