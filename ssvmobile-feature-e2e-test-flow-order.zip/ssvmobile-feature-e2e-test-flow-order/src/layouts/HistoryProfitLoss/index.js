import React, { memo, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Keyboard, Pressable, RefreshControl, SectionList, StyleSheet, TouchableOpacity, View } from 'react-native'
import Modal from 'react-native-modal'
import DateTimePickerModal from 'react-native-modal-datetime-picker'
import { isArray } from 'lodash'
import moment from 'moment'
import { Container } from 'native-base'

import { enhance, Text, TextInput } from '../../basic-components'
import Account from '../../components/account'
import HeaderComponent from '../../components/header'
import { ColTableData, ModalBottomContent, ModalBottomRowSelect, RowTableData } from '../../components/trading-component'
import ErrorView from '../../hoc/error-loading/error-view'
import { StoreContext } from '../../store'
import { StoreTrading } from '../../store-trading'
import { dimensions, dimensions as dm, fontSizes, fontSizes as fs, fontWeights as fw, IconSvg } from '../../styles'
import { FormatNumber, glb_sv, reqFunct, Screens, sendRequest } from '../../utils'

const ServiceInfo = {
    PORTFOLIO_MANAGEMENT: {
        reqFunct: reqFunct.PORTFOLIO_MANAGEMENT,
        WorkerName: 'FOSqAsset',
        ServiceName: 'FOSqAsset_1801_2',
        Operation: 'Q',
    },
    PORTFOLIO_MANAGEMENT_DETAIL: {
        reqFunct: reqFunct.PORTFOLIO_MANAGEMENT_DETAIL,
        WorkerName: 'FOSqAsset',
        ServiceName: 'FOSqAsset_1801_2',
        Operation: 'Q',
    },
}

const colSpan = [3, 3, 3, 3]

function HistoryProfitLoss({ navigation }) {
    const { styles } = useContext(StoreContext)
    const { userInfo } = useContext(StoreTrading)

    const { t } = useTranslation()

    const [refreshing, setRefreshing] = useState(false)

    const [errorData, setErrorData] = useState(false)
    const [checkIcon, setCheckIcon] = useState(false)
    const [dataSource, setDataSource] = useState([])
    const [errorViews, setErrorViews] = useState(false)

    const fromDtRef = useRef(null)
    const toDtRef = useRef(null)
    const tempList = useRef([])
    const [isAllSub, setAllSub] = useState(false)

    // --------------
    const [objTotal, setObjTotal] = useState({
        buy_avg_value: 0,
        profit_loss_value: 0,
        increase_quantity: 0,
        decrease_quantity: 0,
        cash_from_right: 0,
        quantity_of_stock_right: 0,
        value_of_stock_right: 0,
        market_value: 0,
        profit_loss_value_sell_on_day: 0,
        profit_loss_value_buy_on_day: 0,
        total_profit_loss_value_on_day: 0,
    })
    // -----------------------------------------------------
    const [fromDt, setFromDt] = useState(moment(glb_sv.objShareGlb.workDate).subtract(30, 'day').toDate())
    const [toDt, setToDt] = useState(moment(glb_sv.objShareGlb.workDate).toDate())
    const [filterOption, setFilterOption] = useState({
        stock: '',
        order_tp: 'all',
        side: 'all',
    })

    useEffect(() => {
        getPortfolioManagement(fromDt, toDt)
    }, [userInfo, fromDt, toDt, isAllSub])

    const changeAllSub = useCallback((value) => {
        setAllSub(value)
    }, [])

    const changeSub = useCallback((value) => {
        setAllSub(false)
    }, [])
    const getPortfolioManagement = (startDate, endDate, stock) => {
        setCheckIcon(true)
        const { actn_curr, sub_curr } = userInfo
        const InputParams = [
            '1',
            moment(startDate).format('YYYYMMDD'),
            moment(endDate).format('YYYYMMDD'),
            actn_curr,
            isAllSub ? '%' : sub_curr,
            stock ? stock : '%',
        ]
        sendRequest(ServiceInfo.PORTFOLIO_MANAGEMENT, InputParams, getPortfolioManagementResult, true, getPortfolioManagementTimeout)
        setObjTotal({
            buy_avg_value: 0,
            profit_loss_value: 0,
            increase_quantity: 0,
            decrease_quantity: 0,
            cash_from_right: 0,
            quantity_of_stock_right: 0,
            value_of_stock_right: 0,
            market_value: 0,
            profit_loss_value_sell_on_day: 0,
            profit_loss_value_buy_on_day: 0,
            total_profit_loss_value_on_day: 0,
        })
        setDataSource([])
        setErrorViews(false)
        tempList.current = []
    }

    const getPortfolioManagementResult = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            setCheckIcon(false)
            if (message.Code !== '080128') {
                glb_sv.showAlert({
                    title: t('common_notify'),
                    content: message.Message,
                    type: 'warn',
                })
            }
            return
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {
                console.log('getPortfolioManagementResult', err)
            }

            if (Number(message.Packet) <= 0) {
                tempList.current = [...jsondata]
                tempList.current.forEach((e) => {
                    e.c4 = Number(e.c4)
                    e.c5 = Number(e.c5)
                    e.c6 = Number(e.c6)
                    e.c7 = Number(e.c7)
                    e.c8 = Number(e.c8)
                    e.c9 = Number(e.c9)
                    e.c10 = Number(e.c10)
                    e.c11 = Number(e.c11)
                    e.c12 = Number(e.c12)
                    e.c13 = Number(e.c13)
                    e.c14 = Number(e.c14)
                    e.c15 = Number(e.c15)
                    e.c16 = Number(e.c16)
                    e.c17 = Number(e.c17)
                    e.c18 = Number(e.c18)
                    e.c19 = Number(e.c19)
                    e.c20 = Number(e.c20)
                    e.c21 = Number(e.c21)
                    e.c22 = Number(e.c22)
                    e.c23 = Number(e.c23)
                })

                const buy_avg_value = tempList.current.reduce(function (a, b) {
                    return a + Number(b.c22)
                }, 0)
                const profit_loss_value = tempList.current.reduce(function (a, b) {
                    return a + Number(b.c15)
                }, 0)
                const increase_quantity = tempList.current.reduce(function (a, b) {
                    return a + Number(b.c5)
                }, 0)
                const decrease_quantity = tempList.current.reduce(function (a, b) {
                    return a + Number(b.c7)
                }, 0)
                const cash_from_right = tempList.current.reduce(function (a, b) {
                    return a + Number(b.c8)
                }, 0)
                const quantity_of_stock_right = tempList.current.reduce(function (a, b) {
                    return a + Number(b.c9)
                }, 0)
                const value_of_stock_right = tempList.current.reduce(function (a, b) {
                    return a + Number(b.c11)
                }, 0)
                const market_value = tempList.current.reduce(function (a, b) {
                    return a + Number(b.c14)
                }, 0)
                const profit_loss_value_sell_on_day = tempList.current.reduce(function (a, b) {
                    return a + Number(b.c18)
                }, 0)
                const profit_loss_value_buy_on_day = tempList.current.reduce(function (a, b) {
                    return a + Number(b.c19)
                }, 0)
                const total_profit_loss_value_on_day = tempList.current.reduce(function (a, b) {
                    return a + Number(b.c20)
                }, 0)

                setCheckIcon(false)
                setObjTotal({
                    buy_avg_value,
                    profit_loss_value,
                    increase_quantity,
                    decrease_quantity,
                    cash_from_right,
                    quantity_of_stock_right,
                    value_of_stock_right,
                    market_value,
                    profit_loss_value_sell_on_day,
                    profit_loss_value_buy_on_day,
                    total_profit_loss_value_on_day,
                })
                // -----------
                const result = tempList.current.reduce(function (accumulator, currentValue, currentIndex, array) {
                    const obj = accumulator.find((e) => e.title === currentValue.c0)
                    if (obj) {
                        obj.data.push(currentValue)
                    } else {
                        accumulator.push({
                            title: currentValue.c0,
                            data: [currentValue],
                        })
                    }
                    return accumulator
                }, [])
                setDataSource(result)
            } else {
                setCheckIcon(false)
            }
        }
    }
    const getPortfolioManagementTimeout = () => {
        setCheckIcon(false)
        setErrorViews(true)
    }

    const changeOrderDetail = (item) => {
        navigation.navigate(Screens.HISTORY_PROFIT_LOSS_DETAIL, { data: item })
    }

    const renderItem = useCallback(({ item }) => {
        return <RowItem changeOrderDetail={() => changeOrderDetail(item)} item={item} styles={styles} t={t} />
    })

    const onRefresh = useCallback(() => {
        getPortfolioManagement(fromDt, toDt)
    }, [userInfo, toDt, fromDt])

    const handleFilterOption = (value) => {
        filterData(value.stock)
    }

    const filterData = (stk) => {
        let data = tempList.current.slice() || []
        if (stk && isArray(data)) {
            data = data.filter((e) => e.c3.includes(stk) || stk.includes(e.c3))
        }
        const result = data.reduce(function (accumulator, currentValue, currentIndex, array) {
            const obj = accumulator.find((e) => e.title === currentValue.c0)
            if (obj) {
                obj.data.push(currentValue)
            } else {
                accumulator.push({
                    title: currentValue.c0,
                    data: [currentValue],
                })
            }
            return accumulator
        }, [])
        setDataSource(result)
    }

    const hideKeyboard = useCallback(() => {
        Keyboard.dismiss()
    }, [])

    const textSectionHeaderStyle = useMemo(
        () => enhance([{ color: styles.PRIMARY, fontSize: fs.medium, backgroundColor: styles.PRIMARY__BG__COLOR, paddingVertical: 5, fontWeight: fw.bold }]),
        [],
    )

    const CellContentUI = {
        fontWeight: fw.bold,
        fontSize: fontSizes.verySmall,
        textAlign: 'right',
        color: styles.HEADER__CONTENT__COLOR,
    }

    const HeaderListAssetsStock = () => {
        return (
            <>
                <View style={{ flexDirection: 'row', paddingHorizontal: dimensions.moderate(16), marginTop: dimensions.vertical(8) }}>
                    <View style={{ flex: colSpan[0] }}>
                        <TouchableOpacity onPress={null}>
                            <View style={UI.HeaderColInside}>
                                <View>
                                    <Text style={[CellContentUI, { textAlign: 'left' }]}>{t('stock_symbol_short')}</Text>
                                    <Text style={[CellContentUI, { textAlign: 'left' }]}>{t('common_amount')}</Text>
                                </View>
                            </View>
                        </TouchableOpacity>
                    </View>
                    <View style={{ flex: colSpan[1] }}>
                        <TouchableOpacity onPress={null}>
                            <View style={[UI.HeaderColInside, { justifyContent: 'flex-end' }]}>
                                <View>
                                    <Text style={[CellContentUI]}>{t('cost')}</Text>
                                    <Text style={[CellContentUI]}>{t('present_price')}</Text>
                                </View>
                            </View>
                        </TouchableOpacity>
                    </View>
                    <View style={{ flex: colSpan[2] }}>
                        <TouchableOpacity onPress={null}>
                            <View style={[UI.HeaderColInside, { justifyContent: 'flex-end' }]}>
                                <View>
                                    <Text style={[CellContentUI]}>{t('increase_quantity')}</Text>
                                    <Text style={[CellContentUI]}>{t('decrease_quantity')}</Text>
                                </View>
                            </View>
                        </TouchableOpacity>
                    </View>

                    <View style={{ flex: colSpan[3] }}>
                        <TouchableOpacity onPress={null}>
                            <View style={[UI.HeaderColInside, { justifyContent: 'flex-end' }]}>
                                <View>
                                    <Text style={[CellContentUI]}>{t('cal_profit_loss')}</Text>
                                    <Text
                                        style={[
                                            CellContentUI,
                                            // { color: activeSortKeyRef.current?.includes('c18|') ? styles.PRIMARY : styles.HEADER__CONTENT__COLOR },
                                        ]}
                                    >
                                        %{t('cal_profit_loss')}
                                    </Text>
                                </View>
                            </View>
                        </TouchableOpacity>
                    </View>
                </View>
            </>
        )
    }
    return (
        <Container>
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft
                navigation={navigation}
                title={t('history_profit_loss')}
                titleAlgin="flex-start"
                transparent
            />

            <View style={{ flex: 1, backgroundColor: styles.PRIMARY__BG__COLOR }}>
                <View style={{ flexDirection: 'row', paddingHorizontal: dm.moderate(16) }}>
                    {userInfo.sub_list.length < 2 ? (
                        <Account navigation={navigation} noPadding={true} />
                    ) : (
                        <Account changeAll={changeAllSub} changeSub={changeSub} isAll={isAllSub} navigation={navigation} noPadding={true} showSubAll={true} />
                    )}
                </View>
                <FilterGroup
                    filterOption={filterOption}
                    fromDt={fromDt}
                    handleFilterOption={handleFilterOption}
                    setFilterOption={setFilterOption}
                    setFromDt={(item) => {
                        fromDtRef.current = item
                        setFromDt(item)
                    }}
                    setToDt={(item) => {
                        toDtRef.current = item
                        setToDt(item)
                    }}
                    toDt={toDt}
                />
                <Pressable onPress={hideKeyboard}>
                    <HeaderListAssetsStock />
                </Pressable>
                <View style={{ flex: 1 }}>
                    {/* {console.log('dataSource', dataSource[0])} */}
                    {errorData ? (
                        <ErrorView getData={getPortfolioManagement} />
                    ) : (
                        <SectionList
                            keyExtractor={(item, index) => index.toString()}
                            refreshControl={<RefreshControl refreshing={refreshing} tintColor={styles.PRIMARY__CONTENT__COLOR} onRefresh={onRefresh} />}
                            renderItem={renderItem}
                            renderSectionHeader={({ section: { title } }) => (
                                <Text style={textSectionHeaderStyle}>{moment(title, 'DDMMYYYY').format('DD/MM/YYYY')}</Text>
                            )}
                            sections={dataSource}
                            showsVerticalScrollIndicator={false}
                            style={{ paddingHorizontal: dm.moderate(16) }}
                        />
                    )}
                </View>
            </View>
        </Container>
    )
}
/*
    c9 - Avg match price
*/
const RowItem = memo(({ changeOrderDetail, colorC11, item, styles }) => {
    const getColor = (value) => {
        if (value > 0) return styles.UP__COLOR
        if (value < 0) return styles.DOWN__COLOR
        return styles.PRIMARY__CONTENT__COLOR
    }
    return (
        <RowTableData type="table" onPress={changeOrderDetail}>
            <ColTableData colSpan={colSpan[0]} text={item.c3} text2={item.c4} />
            <ColTableData colSpan={colSpan[1]} text={FormatNumber(item.c6)} text2={FormatNumber(item.c22)} textAlign="right" />
            <ColTableData colSpan={colSpan[2]} text={FormatNumber(item.c5)} text2={FormatNumber(item.c7)} textAlign="right" />
            <ColTableData
                colorText={getColor(Number(item.c23))}
                colorText2={getColor(Number(item.c23))}
                colSpan={colSpan[3]}
                text={
                    Number(item.c23) === 0
                        ? Number(item.c15) > 0
                            ? FormatNumber(Number(item.c15), 0)
                            : FormatNumber(Number(item.c15) * -1, 0)
                        : Number(item.c15) > 0
                        ? `+${FormatNumber(Number(item.c15), 0)}`
                        : `-${FormatNumber(Number(item.c15) * -1, 0)}`
                }
                text2={
                    Number(item.c23) === 0
                        ? `0%`
                        : Number(item.c23) > 0
                        ? `+${FormatNumber(Number(item.c23), 3, 1)}%`
                        : `${FormatNumber(Number(item.c23) * -1, 3, 1)}%`
                }
                textAlign="right"
            />
        </RowTableData>
    )
})

export default HistoryProfitLoss

const FilterGroupMemo = ({ filterOption, setFilterOption, fromDt, toDt, setToDt, setFromDt, handleFilterOption }) => {
    const { styles, theme, language } = useContext(StoreContext)
    const { t } = useTranslation()

    const [isFocus, setIsFocus] = useState({
        from: false,
        to: false,
        stock: false,
        order_tp: false,
        side: false,
    })

    const onFinish = () => {
        setIsFocus({
            from: false,
            to: false,
            stock: false,
            order_tp: false,
            side: false,
        })
    }
    const SideList = [
        { index: 0, label: t('common_all'), value: 'all' },
        { index: 1, label: t('priceboard_buy'), value: 'buy' },
        { index: 2, label: t('priceboard_sell'), value: 'sell' },
    ]
    const OrderTypeList = [
        { index: 0, label: t('common_all'), value: 'all' },
        { index: 1, label: t('wait_to_match'), value: 'wait_match' },
        { index: 2, label: t('hist_ord_dt_matched'), value: 'ord_match' },
        { index: 3, label: t('wait_to_process'), value: 'wait_process' },
        { index: 4, label: t('confirm_cancel'), value: 'confirm_cancel' },
    ]

    const handleSearchStock = (value) => {
        setFilterOption({ ...filterOption, stock: value.toUpperCase() })
        handleFilterOption({ ...filterOption, stock: value.toUpperCase() })
    }

    const onSelectOrderType = (item) => {
        setFilterOption({ ...filterOption, order_tp: item.value })
        onFinish()
        handleFilterOption({ ...filterOption, order_tp: item.value })
    }
    const onSelectSide = (item) => {
        setFilterOption({ ...filterOption, side: item.value })
        onFinish()
        handleFilterOption({ ...filterOption, side: item.value })
    }

    return (
        <>
            <View style={UI.GroupFilter}>
                <View style={{ flexDirection: 'row', marginTop: dimensions.vertical(8), justifyContent: 'space-between' }}>
                    <TouchableOpacity
                        style={{
                            flex: 1,
                            justifyContent: 'flex-start',
                            borderRadius: 8,
                            backgroundColor: styles.BUTTON__THIRD,
                            padding: dimensions.moderate(6),
                            flexDirection: 'row',
                            alignItems: 'center',
                        }}
                        onPress={() => setIsFocus({ ...isFocus, from: true })}
                    >
                        <View style={{ marginRight: dimensions.moderate(20), flex: 1 }}>
                            <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.verySmall }}>
                                {t('common_from_date')}
                                {'  '}
                            </Text>
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.verySmall }}>{moment(fromDt).format('DD/MM/YYYY')}</Text>
                        </View>
                        <IconSvg.DateIcon color={styles.PRIMARY__CONTENT__COLOR} />
                    </TouchableOpacity>
                    <View style={{ width: dimensions.moderate(16) }} />
                    <TouchableOpacity
                        style={{
                            flex: 1,
                            justifyContent: 'flex-start',
                            borderRadius: 8,
                            backgroundColor: styles.BUTTON__THIRD,
                            padding: dimensions.moderate(6),
                            flexDirection: 'row',
                            alignItems: 'center',
                        }}
                        onPress={() => setIsFocus({ ...isFocus, to: true })}
                    >
                        <View style={{ marginRight: dimensions.moderate(20), flex: 1 }}>
                            <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.verySmall }}>
                                {t('common_to_date')}
                                {'  '}
                            </Text>
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.verySmall }}>{moment(toDt).format('DD/MM/YYYY')}</Text>
                        </View>
                        <IconSvg.DateIcon color={styles.PRIMARY__CONTENT__COLOR} />
                    </TouchableOpacity>
                </View>

                <View style={{ flexDirection: 'row', marginVertical: dimensions.vertical(4) }}>
                    <View
                        style={{
                            flex: 1,
                            justifyContent: 'flex-start',
                            borderRadius: 8,
                            backgroundColor: styles.BUTTON__THIRD,
                            padding: dimensions.moderate(6),
                            flexDirection: 'row',
                            alignItems: 'center',
                        }}
                    >
                        <View style={{ marginRight: dimensions.moderate(20), flex: 1 }}>
                            <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.verySmall, padding: 0 }}>{t('input_symbol')}</Text>
                            <TextInput
                                autoCapitalize="characters"
                                style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.verySmall }}
                                value={filterOption.stock}
                                onChangeText={(value) => handleSearchStock(value)}
                            />
                        </View>
                    </View>
                    {/* <View style={{ width: 4 }} />
                    <TouchableOpacity
                        onPress={() => setIsFocus({ ...isFocus, order_tp: !isFocus.order_tp })}
                        style={{
                            flex: 1,
                            justifyContent: 'flex-start',
                            borderRadius: 8,
                            backgroundColor: styles.BUTTON__THIRD,
                            padding: dimensions.moderate(6),
                            flexDirection: 'row',
                            alignItems: 'center',
                        }}>
                        <View style={{ marginRight: dimensions.moderate(20), flex: 1 }}>
                            <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.verySmall, padding: 0 }}>{t('order_tp')}</Text>
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.verySmall }}>
                                {OrderTypeList.find((e) => e.value === filterOption.order_tp)?.label}
                            </Text>
                        </View>
                    </TouchableOpacity>
                    <View style={{ width: 4 }} /> */}
                    {/* <TouchableOpacity
                        onPress={() => setIsFocus({ ...isFocus, side: !isFocus.side })}
                        style={{
                            flex: 1,
                            justifyContent: 'flex-start',
                            borderRadius: 8,
                            backgroundColor: styles.BUTTON__THIRD,
                            padding: dimensions.moderate(6),
                            flexDirection: 'row',
                            alignItems: 'center',
                        }}>
                        <View style={{ marginRight: dimensions.moderate(20), flex: 1 }}>
                            <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.verySmall, padding: 0 }}>
                                {t('priceboard_buy') + '/' + t('priceboard_sell')}
                            </Text>
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.verySmall }}>
                                {SideList.find((e) => e.value === filterOption.side)?.label}
                            </Text>
                        </View>
                    </TouchableOpacity> */}
                </View>
            </View>
            {isFocus.from ? (
                <DateTimePickerModal
                    cancelTextIOS={t('common_Cancel')}
                    confirmTextIOS={t('common_Ok')}
                    date={fromDt}
                    headerTextIOS=""
                    isDarkModeEnabled={theme.includes('DARK')}
                    isVisible={isFocus.from}
                    locale={language === 'VI' ? 'vi_VN' : 'en_US'}
                    mode="date"
                    textColor={styles.PRIMARY__CONTENT__COLOR}
                    onCancel={onFinish}
                    onConfirm={(value) => {
                        onFinish()
                        setFromDt(value)
                    }}
                />
            ) : null}

            {isFocus.to ? (
                <DateTimePickerModal
                    cancelTextIOS={t('common_Cancel')}
                    confirmTextIOS={t('common_Ok')}
                    date={toDt}
                    headerTextIOS=""
                    isDarkModeEnabled={theme.includes('DARK')}
                    isVisible={isFocus.to}
                    locale={language === 'VI' ? 'vi_VN' : 'en_US'}
                    mode="date"
                    textColor={styles.PRIMARY__CONTENT__COLOR}
                    onCancel={onFinish}
                    onConfirm={(value) => {
                        onFinish()
                        setToDt(value)
                    }}
                />
            ) : null}

            {isFocus.order_tp ? (
                <Modal
                    hideModalContentWhileAnimating={true}
                    isVisible={isFocus.order_tp}
                    style={UI.bottomModal}
                    useNativeDriver={true}
                    onBackButtonPress={onFinish}
                    onBackdropPress={onFinish}
                >
                    <ModalBottomContent title={t('order_tp')}>
                        {OrderTypeList.map((item) => (
                            <ModalBottomRowSelect
                                checked={filterOption.order_tp === item.value}
                                key={String(Math.random())}
                                text={t(item.label)}
                                onPress={() => onSelectOrderType(item)}
                            />
                        ))}
                    </ModalBottomContent>
                </Modal>
            ) : null}

            {isFocus.side ? (
                <Modal
                    hideModalContentWhileAnimating={true}
                    isVisible={isFocus.side}
                    style={UI.bottomModal}
                    useNativeDriver={true}
                    onBackButtonPress={onFinish}
                    onBackdropPress={onFinish}
                >
                    <ModalBottomContent title={t('side')}>
                        {SideList.map((item) => (
                            <ModalBottomRowSelect
                                checked={filterOption.side === item.value}
                                key={String(Math.random())}
                                text={t(item.label)}
                                onPress={() => onSelectSide(item)}
                            />
                        ))}
                    </ModalBottomContent>
                </Modal>
            ) : null}
        </>
    )
}

const FilterGroup = memo(FilterGroupMemo)

const UI = StyleSheet.create({
    GroupFilter: {
        marginHorizontal: dm.moderate(16),
    },
    RowFilter: {
        marginHorizontal: dm.moderate(8),
        marginVertical: dm.vertical(4),
    },
    backRightBtn: {
        alignItems: 'flex-end',
        bottom: 0,
        flex: 1,
        justifyContent: 'center',
        paddingRight: 17,
        position: 'absolute',
        top: 0,
        width: 75,
    },
    backRightBtnLeft: {
        right: 75,
    },
    backRightBtnRight: {
        borderBottomRightRadius: 5,
        borderTopRightRadius: 5,
        right: 0,
    },
    bottomModal: {
        justifyContent: 'flex-end',
        margin: 0,
    },
    divider: {
        height: 1,
        width: '90%',
    },
    margin_top_row: {
        marginBottom: dm.moderate(4),
        marginHorizontal: dm.moderate(16),
    },
    modalContent: {
        backgroundColor: 'white',
        borderColor: 'rgba(0, 0, 0, 0.1)',
        borderTopLeftRadius: 5,
        borderTopRightRadius: 5,
        paddingBottom: 40,
        paddingHorizontal: 10,
        paddingVertical: 20,
    },
    rowBack: {
        alignItems: 'center',
        borderRadius: 5,
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
        margin: 5,
        marginBottom: 5,
        paddingLeft: 15,
    },
    trash: {
        height: 25,
        marginRight: 7,
        width: 25,
    },
})
