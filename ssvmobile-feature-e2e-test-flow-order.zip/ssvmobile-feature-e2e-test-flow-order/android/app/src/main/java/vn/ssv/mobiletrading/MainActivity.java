package vn.ssv.mobiletrading;

import com.facebook.react.ReactActivity;

import android.content.res.Configuration;


import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.widget.Toast;
import android.view.WindowManager;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import com.facebook.react.ReactActivity;

public class MainActivity extends ReactActivity {

   @Override
   public void onConfigurationChanged(Configuration newConfig) {
       super.onConfigurationChanged(newConfig);
       Intent intent = new Intent("onConfigurationChanged");
       intent.putExtra("newConfig", newConfig);
       this.sendBroadcast(intent);
   }
  /**
   * Returns the name of the main component registered from JavaScript. This is used to schedule
   * rendering of the component.
   */
  @Override
  protected String getMainComponentName() {
    return "SSVMobile";
  }

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(null); // fix crash
    getWindow().setFlags(
      WindowManager.LayoutParams.FLAG_SECURE,
      WindowManager.LayoutParams.FLAG_SECURE
    );
  }

  @Override
  public void onWindowFocusChanged(boolean hasFocus) {
    super.onWindowFocusChanged(hasFocus);
    if (hasFocus) {
      // allow screenshots when activity is focused
      getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
    } else {
      // hide information (blank view) on app switcher
      getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
    }
  }
}
