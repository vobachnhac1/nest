// @flow weak

// import React from 'react';
import PropTypes from 'prop-types'

const FBigNumber = (value, { fractionSize = 0, empty = 1, key = 'short', translateFunc, unit = '', fixTo = '' }) => {
    if (value === 777777710000) return 'ATO'
    if (value === 777777720000) return 'ATC'
    if (!value || value === '0' || value === ' ' || isNaN(value)) {
        if (key === 'dash') return '---'
        if (empty === 1 && value === null) {
            return '---' // !!! {Dung} Test lại
        } else if (fractionSize === 0) return '0'
        else if (fractionSize === 1) return '0.0'
        else if (fractionSize === 2) return '0.00'
        else if (fractionSize === 3) return '0.000'
        return '0'
    }
    const DECIMAL_SEPARATOR = '.'
    const THOUSANDS_SEPARATOR = ','
    const precision = 10 ** (fractionSize || 1)
    const valueRound = Math.round(Number(value) * precision) / precision
    let [integer, fraction = ''] = (valueRound || '').toString().split('.')
    fraction = fractionSize > 0 ? DECIMAL_SEPARATOR + (fraction + '000000').substring(0, fractionSize) : ''
    // integer = (Number(integer) * 10).toString();
    integer = integer.replace(/\B(?=(\d{3})+(?!\d))/g, THOUSANDS_SEPARATOR)

    if (key === 'input_plcord') {
        if (integer.substr(0, integer.length) + fraction === '.00') return ''
        else return integer.substr(0, integer.length) + fraction
    }
    if (key === 'short' && fixTo === '') {
        if (Math.abs(value) < 999) return value
        let newValue = value,
            valueUnit = ''
        if (Math.abs(value) >= 10 ** 3) {
            newValue = value / 10 ** 3
            valueUnit = translateFunc ? translateFunc('unit_thousand') + unit : ' K'
        }
        if (Math.abs(value) > 10 ** 6) {
            valueUnit = translateFunc ? translateFunc('unit_millions') + unit : ' M'
            newValue = value / 10 ** 6
        }
        if (Math.abs(value) > 10 ** 9) {
            valueUnit = translateFunc ? translateFunc('unit_billions') + unit : ' B'
            newValue = value / 10 ** 9
        }
        if (Math.abs(value) > 10 ** 12) {
            valueUnit = translateFunc ? translateFunc('unit_trilions') + unit : ' T'
            newValue = value / 10 ** 12
        }
        let [integerS, fractionS = ''] = (newValue || '').toString().split('.')
        fractionS = DECIMAL_SEPARATOR + (fractionS + '000000').substring(0, 2)
        integerS = integerS.replace(/\B(?=(\d{3})+(?!\d))/g, THOUSANDS_SEPARATOR)
        return integerS.substr(0, integerS.length) + fractionS + valueUnit
    } else {
        let newValue = value,
            valueUnit = ''
        if (fixTo === 'K') {
            newValue = value / 10 ** 3
            valueUnit = translateFunc ? translateFunc('unit_thousand') + unit : ' K'
        }
        if (fixTo === 'M') {
            valueUnit = translateFunc ? translateFunc('unit_millions') + unit : ' M'
            newValue = value / 10 ** 6
        }
        if (fixTo === 'B') {
            valueUnit = translateFunc ? translateFunc('unit_billions') + unit : ' B'
            newValue = value / 10 ** 9
        }
        if (fixTo === 'T') {
            valueUnit = translateFunc ? translateFunc('unit_trilions') + unit : ' T'
            newValue = value / 10 ** 12
        }
        if (key === 'no_unit') {
            valueUnit = ''
        }
        let [integerS, fractionS = ''] = (newValue || '').toString().split('.')
        fractionS = DECIMAL_SEPARATOR + (fractionS + '000000').substring(0, 2)
        integerS = integerS.replace(/\B(?=(\d{3})+(?!\d))/g, THOUSANDS_SEPARATOR)
        return integerS.substr(0, integerS.length) + fractionS + valueUnit
    }
}

FBigNumber.propTypes = {
    value: PropTypes.any,
    fractionSize: PropTypes.number,
    empty: PropTypes.number,
    key: PropTypes.string,
}

FBigNumber.defaultProps = {
    fractionSize: 0,
    empty: 1,
}
export default FBigNumber
