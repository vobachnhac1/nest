describe('Example', () => {
    beforeAll(async () => {
        await device.launchApp()
    })
    it('should tap on a button', async () => {
        await element(by.id('ButtonID')).tap()
    })
})
