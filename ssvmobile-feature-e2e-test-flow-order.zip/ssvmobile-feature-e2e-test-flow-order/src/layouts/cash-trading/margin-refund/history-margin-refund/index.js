import React, { useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { FlatList, Pressable, RefreshControl, StyleSheet, View } from 'react-native'
import Modal from 'react-native-modal'
import DateTimePickerModal from 'react-native-modal-datetime-picker'
import Svg, { Path } from 'react-native-svg'
import ToastGlobal from 'react-native-toast-message'
import moment from 'moment'
import { Col, Container, Content, Row } from 'native-base'

import IconCalendar from '../../../../assets/images/common/calendar.svg'
import { CustomFloatInput } from '../../../../basic-components'
import Account from '../../../../components/account'
import HeaderComponent from '../../../../components/header'
import { ColTableData, ModalBottomContent, ModalBottomRowSelect, RowTableData, RowTitleGroup } from '../../../../components/trading-component'
import EmptyView from '../../../../components/trading-component/empty-view'
import HeaderList from '../../../../components/trading-component/header-list'
import { StoreContext } from '../../../../store'
import { StoreTrading } from '../../../../store-trading'
import { dimensions as dm, fontSizes as fs, fontWeights as fw } from '../../../../styles'
import { eventList, glb_sv, reqFunct, Screens, sendRequest, wait } from '../../../../utils'
import FormatNumber from '../../../../utils/formatNumber/FormatNumber'

// Khai báo ServiceInfo (nếu có)
const ServiceInfo = {
    GET_CUR_MARG_CONT_LIST: {
        reqFunct: reqFunct.GET_CUR_MARG_CONT_LIST,
        WorkerName: 'FOSqMargin',
        ServiceName: 'FOSqMargin_1402_1',
        ClientSentTime: '0',
        Operation: 'Q',
        // InVal: ['OTSRPY', this.actn_curr, this.sub_curr, '6', '%', '0', 'z', '']
    },

    GET_HIS_MARG_LIST: {
        reqFunct: reqFunct.GET_HIS_MARG_LIST,
        WorkerName: 'FOSqMargin',
        ServiceName: 'FOSqMargin_1402_2',
        ClientSentTime: '0',
        Operation: 'Q',
        // InVal: ['OTSHIS', this.actn_curr, this.sub_curr, ctr_type, ctr_status, start_dt, end_dt],
    },
}
// Khai báo component
const HistoryRefund = ({ navigation, route }) => {
    const { params = {} } = route
    const { contractInfo } = params

    const TAG = 'HistoryRefund'

    const { styles } = useContext(StoreContext)
    const { userInfo, setUserInfo } = useContext(StoreTrading)

    const { t } = useTranslation()
    // All orther state
    const [isOpenFilterGroup, setIsOpenFilterGroup] = useState(false)
    const [refreshing, setRefreshing] = React.useState(false)

    // Start define all bussiness state
    const [listHisMarginContract, setListHisMarginContract] = useState([])

    const [filterOption, setFilterOption] = useState({
        fromDt: moment(glb_sv.objShareGlb.workDate).subtract(3, 'months').toDate(),
        toDt: moment(glb_sv.objShareGlb.workDate).toDate(),
        contractType: '%',
        contractStatus: '%',
    })

    const flag = true
    useEffect(() => {
        const dataSub = glb_sv.objShareGlb.acntNoInfo.find((e) => e.AcntNo + e.SubNo === userInfo.actn_curr + userInfo.sub_curr)
        if (dataSub) {
            if (!dataSub.MarginYN) {
                if (userInfo.sub_list.includes('01')) {
                    setUserInfo({
                        ...userInfo,
                        sub_curr: '01',
                    })
                    glb_sv.userInfo.sub_curr = '01'
                    glb_sv.userInfoAccount = {
                        ...userInfo,
                        sub_curr: '01',
                    }
                }
            }
        }
    }, [flag])

    useEffect(() => {
        getListHisMarginContract()

        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.LOGIN_SUCCESS) {
                getListHisMarginContract()
            }
        })

        return () => {
            commonEvent.unsubscribe()
        }
    }, [userInfo.sub_curr])

    useEffect(() => {
        getListHisMarginContract()
    }, [filterOption])

    const onRefresh = React.useCallback(() => {
        setRefreshing(true)
        getListHisMarginContract()
        wait(300).then(() => setRefreshing(false))
    }, [])

    // const getListCurrentMarginContractList = () => {
    //     if (!userInfo.actn_curr) {
    //         ToastGlobal.show({
    //             type: 'warning',
    //             text2: t('warning_account_is_empty'),
    //         })
    //         return
    //     }

    //     console.log(TAG, 'getListCurrentMarginContractList userInfo: ', userInfo.actn_curr + '.' + userInfo.sub_curr)
    //     const inputParams = ['OTSRPY', userInfo.actn_curr, userInfo.sub_curr, '6', '%', '0', 'z', ''];
    //     sendRequest(ServiceInfo.GET_CUR_MARG_CONT_LIST, inputParams, handleGetListCurrentMarginContractList)
    // }

    const getListHisMarginContract = () => {
        setListHisMarginContract([])
        if (!userInfo.actn_curr) {
            ToastGlobal.show({
                type: 'warning',
                text2: t('warning_account_is_empty'),
            })
            return
        }

        const inputParams = ['OTSDTL', contractInfo?.c0]
        sendRequest(ServiceInfo.GET_HIS_MARG_LIST, inputParams, handleGetListHisMarginContract)
    }

    // const handleGetListCurrentMarginContractList = (reqInfoMap, message) => {
    //     if (Number(message['Result']) === 0) {
    //         ToastGlobal.show({
    //             text2: message['Message'], //t('pass_confirm_not_correct'),
    //             type: 'warning',
    //         })
    //         return;
    //     }
    //     else {
    //         let jsondata;
    //         try {
    //             jsondata = JSON.parse(message['Data']);
    //         } catch (err) {
    //             // glb_sv.logMessage(err);
    //             jsondata = [];
    //         }
    //         if (Number(message['Packet']) <= 0) {
    //             setListCurMarginContract(jsondata)
    //             getListHisMarginContract()
    //         }
    //     }
    // }

    const handleGetListHisMarginContract = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            ToastGlobal.show({
                text2: message.Message,
                type: 'warning',
            })
            return
        } else {
            let jsondata
            try {
                jsondata = JSON.parse(message.Data)
            } catch (err) {
                jsondata = []
            }
            if (Number(message.Packet) <= 0) {
                setListHisMarginContract(jsondata)
            }
        }
    }

    const getColor = (status) => {
        if (status === 'N') return styles.REF__COLOR
        if (status === 'R' || status === 'D') return styles.DOWN__COLOR
        if (status === 'Y') return styles.UP__COLOR
    }

    const RowInfoContract = ({ item }) => {
        return (
            <>
                <RowTableData
                    key={item.label}
                    type="table"
                    // onPress={() => navigation.navigate(Screens.DETAIL_MARGIN_REFUND, { data: item, onRefresh: onRefresh, onReFreshContract: () => { getListHisMarginContract() } })}
                >
                    <ColTableData text={moment(item.c4, 'DDMMYYYY').format('DD/MM/YYYY')} />
                    <ColTableData text={FormatNumber(item.c11, 0)} textAlign="center" />
                    <ColTableData text={FormatNumber(item.c6, 0)} textAlign="right" />
                </RowTableData>
            </>
        )
    }

    return (
        <Container>
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft
                navigation={navigation}
                title={t('history_repay')}
                titleAlgin="flex-start"
                transparent
            />
            <Content
                refreshControl={
                    <RefreshControl
                        refreshing={refreshing}
                        onRefresh={onRefresh} // title={t('pull_refresh')}
                        // titleColor={styles.PRIMARY__CONTENT__COLOR}
                        tintColor={styles.PRIMARY__CONTENT__COLOR}
                    />
                }
                style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}
            >
                <View>
                    {/* <Account navigation={navigation} /> */}

                    <RowTitleGroup
                        // hasDivider
                        text={t('history_repay') + ' (' + contractInfo?.c0 + ')'}
                        // iconRight={
                        //     <Svg
                        //         onPress={() => setIsOpenFilterGroup(!isOpenFilterGroup)}
                        //         width={36}
                        //         height={36}
                        //         viewBox="0 0 36 36"
                        //         fill="none"
                        //         xmlns="http://www.w3.org/2000/svg">
                        //         <Path
                        //             fillRule="evenodd"
                        //             clipRule="evenodd"
                        //             d="M0 18C0 8.059 8.059 0 18 0s18 8.059 18 18-8.059 18-18 18S0 27.941 0 18z"
                        //             fill="#F8F8F8"
                        //         />
                        //         <Path
                        //             d="M26.438 14.514H9.563a.938.938 0 010-1.875h16.874a.937.937 0 110 1.875zm-3.125 4.375H12.688a.938.938 0 010-1.875h10.624a.937.937 0 110 1.875zm-3.75 4.375h-3.125a.938.938 0 010-1.875h3.125a.937.937 0 110 1.875z"
                        //             fill="#24253D"
                        //         />
                        //     </Svg>
                        // }
                    />

                    {/* <FilterGroup
                        isOpenFilterGroup={isOpenFilterGroup}
                        setIsOpenFilterGroup={setIsOpenFilterGroup}
                        filterOption={filterOption}
                        setFilterOption={setFilterOption}
                    /> */}

                    <HeaderList typeHeader="HIS_REPAY_MARGIN_PER_CONTRACT" />

                    <FlatList
                        data={listHisMarginContract}
                        keyExtractor={(item, index) => index.toString()}
                        ListEmptyComponent={EmptyView}
                        renderItem={RowInfoContract}
                        style={{ marginBottom: dm.vertical(32), paddingHorizontal: dm.moderate(16) }}
                    />
                </View>
            </Content>
        </Container>
    )
}

export default HistoryRefund

const FilterGroup = ({ isOpenFilterGroup, setIsOpenFilterGroup, filterOption, setFilterOption }) => {
    const { styles, theme, language } = useContext(StoreContext)
    const { t } = useTranslation()

    const [isFocus, setIsFocus] = useState({
        from: false,
        to: false,
        contractTypeOpen: false,
        contractStatusOpen: false,
    })

    const onFinish = () => {
        console.log('onFinish')
        setIsFocus({
            from: false,
            to: false,
            contractTypeOpen: false,
            contractStatusOpen: false,
        })
    }
    const contractTypeList = [
        { index: 0, value: '%', label: t('all_contract_status') },
        { index: 1, value: '1', label: t('all_contract_not_expire') },
        { index: 2, value: '2', label: t('all_contract_need_repay') },
    ]
    const contractStatusList = [
        { index: 0, value: '%', label: t('common_all') },
        { index: 1, value: 'A', label: t('contract_repay_all') },
        { index: 2, value: 'C', label: t('contract_abort') },
        { index: 3, value: 'N', label: t('contract_not_repay') },
        { index: 4, value: 'P', label: t('contract_pay_apart') },
    ]
    const onSelectContractType = (item) => {
        setFilterOption({ ...filterOption, contractType: item.value })
        setTimeout(() => onFinish(), 300)
    }

    const onSelectContractStatus = (item) => {
        setFilterOption({ ...filterOption, contractStatus: item.value })
        setTimeout(() => onFinish(), 300)
    }

    return (
        <>
            {isOpenFilterGroup && (
                <View style={UI.GroupFilter}>
                    <Row>
                        <Col size={12}>
                            <Pressable onPress={() => setIsFocus({ ...isFocus, from: true })}>
                                <View pointerEvents="none" style={UI.RowFilter}>
                                    <CustomFloatInput
                                        label={t('common_from_date')}
                                        rightComponent={
                                            <IconCalendar fill={styles.PRIMARY__CONTENT__COLOR} style={{ marginVertical: dm.vertical(20), marginRight: 5 }} />
                                        }
                                        staticLabel
                                        value={moment(filterOption.fromDt).format('DD/MM/YYYY')}
                                    />
                                </View>
                            </Pressable>
                        </Col>
                        <Col size={12}>
                            <Pressable onPress={() => setIsFocus({ ...isFocus, to: true })}>
                                <View pointerEvents="none" style={UI.RowFilter}>
                                    <CustomFloatInput
                                        label={t('common_to_date')}
                                        rightComponent={
                                            <IconCalendar fill={styles.PRIMARY__CONTENT__COLOR} style={{ marginVertical: dm.vertical(20), marginRight: 5 }} />
                                        }
                                        staticLabel
                                        value={moment(filterOption.toDt).format('DD/MM/YYYY')}
                                    />
                                </View>
                            </Pressable>
                        </Col>
                    </Row>
                    <Pressable onPress={() => setIsFocus({ ...isFocus, contractTypeOpen: !isFocus.contractTypeOpen })}>
                        <View pointerEvents="none" style={UI.RowFilter}>
                            <CustomFloatInput
                                label={t('contract_type')}
                                staticLabel
                                value={t(contractTypeList.filter((o) => o.value === filterOption.contractType)?.pop()?.label)}
                            />
                        </View>
                    </Pressable>
                    <Pressable onPress={() => setIsFocus({ ...isFocus, contractStatusOpen: !isFocus.contractStatusOpen })}>
                        <View pointerEvents="none" style={UI.RowFilter}>
                            <CustomFloatInput
                                label={t('contract_status')}
                                staticLabel
                                value={t(contractStatusList.filter((o) => o.value === filterOption.contractStatus)?.pop()?.label)}
                            />
                        </View>
                    </Pressable>
                </View>
            )}
            <DateTimePickerModal
                cancelTextIOS={t('common_Cancel')}
                confirmTextIOS={t('common_Ok')}
                date={filterOption.fromDt}
                headerTextIOS=""
                isDarkModeEnabled={theme.includes('DARK')}
                isVisible={isFocus.from}
                locale={language === 'VI' ? 'vi_VN' : 'en_US'}
                mode="date"
                onCancel={onFinish}
                onConfirm={(value) => {
                    onFinish()
                    setFilterOption({ ...filterOption, fromDt: value })
                }}
            />

            <DateTimePickerModal
                cancelTextIOS={t('common_Cancel')}
                confirmTextIOS={t('common_Ok')}
                date={filterOption.toDt}
                headerTextIOS=""
                isDarkModeEnabled={theme.includes('DARK')}
                isVisible={isFocus.to}
                locale={language === 'VI' ? 'vi_VN' : 'en_US'}
                mode="date"
                onCancel={onFinish}
                onConfirm={(value) => {
                    onFinish()
                    setFilterOption({ ...filterOption, toDt: value })
                }}
            />

            {isFocus.contractTypeOpen && (
                <Modal
                    hideModalContentWhileAnimating={true}
                    isVisible={isFocus.contractTypeOpen}
                    style={UI.bottomModal}
                    useNativeDriver={true}
                    onBackButtonPress={() => onFinish()}
                    onBackdropPress={() => onFinish()}
                >
                    <ModalBottomContent title={t('contract_type')}>
                        {contractTypeList.map((item) => (
                            <ModalBottomRowSelect
                                checked={filterOption.contractType === item.value}
                                text={t(item.label)}
                                onPress={() => onSelectContractType(item)}
                            />
                        ))}
                    </ModalBottomContent>
                </Modal>
            )}

            {isFocus.contractStatusOpen && (
                <Modal
                    hideModalContentWhileAnimating={true}
                    isVisible={isFocus.contractStatusOpen}
                    style={UI.bottomModal}
                    useNativeDriver={true}
                    onBackButtonPress={() => onFinish()}
                    onBackdropPress={() => onFinish()}
                >
                    <ModalBottomContent title={t('order_status')}>
                        {contractStatusList.map((item, index) => (
                            <ModalBottomRowSelect
                                checked={filterOption.contractStatus === item.value}
                                key={index}
                                text={t(item.label)}
                                onPress={() => onSelectContractStatus(item)}
                            />
                        ))}
                    </ModalBottomContent>
                </Modal>
            )}
        </>
    )
}

const UI = StyleSheet.create({
    Button: {
        alignItems: 'center',
        borderRadius: 8,
        height: dm.moderate(28),
        justifyContent: 'center',
        width: dm.moderate(28),
    },
    GroupFilter: {
        flex: 1,
        marginHorizontal: dm.moderate(8),
        marginVertical: dm.vertical(4),
    },
    Row: {
        flex: 1,
        justifyContent: 'center',
        marginHorizontal: dm.moderate(16),
        paddingBottom: dm.vertical(16),
        paddingTop: dm.vertical(16),
    },
    RowFilter: {
        marginHorizontal: dm.moderate(8),
        marginVertical: dm.vertical(8),
    },
    RowInput: {
        marginHorizontal: dm.moderate(16),
        marginVertical: dm.vertical(16),
    },
    Row_Modal: {
        height: dm.vertical(24),
        marginVertical: dm.vertical(16),
    },
    Row_view: {
        flex: 1,
        paddingBottom: dm.vertical(8),
        paddingTop: dm.vertical(8),
    },
    bottomModal: {
        justifyContent: 'flex-end',
        margin: 0,
    },
    current_cash: {
        fontSize: fs.medium,
        fontWeight: fw.extraBold,
    },
    divider: {
        height: 1,
        width: '90%',
    },
    margin_top_row: {
        marginBottom: dm.moderate(24),
        marginHorizontal: dm.moderate(16),
        marginTop: dm.moderate(16),
    },
    modalContent: {
        backgroundColor: 'white',
        borderColor: 'rgba(0, 0, 0, 0.1)',
        borderTopLeftRadius: 5,
        borderTopRightRadius: 5,
        paddingBottom: 40,
    },
})
