import React, { memo, useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { InteractionManager, Keyboard, KeyboardAvoidingView, Pressable, TouchableOpacity, TouchableWithoutFeedback, View } from 'react-native'
import FingerprintScanner from 'react-native-fingerprint-scanner'
import getUniqueIdDevice from '@mts-utils/getUniqueIdDevice'
import moment from 'moment'
import { Button } from 'native-base'
import SyncStorage from 'sync-storage'

import { Text, TextInput } from '../../basic-components'
import { allowCompanyRender, useUpdateEffect } from '../../hoc'
import ModalAuthen from '../../layouts/login/modal-authen'
import { StoreContext } from '../../store'
import { dimensions, fontSizes, fontWeights, IconSvg } from '../../styles'
import { IOS } from '../../styles/helper/dimensions'
import { dataCryption, eventList, glb_sv, reqFunct, Screens, sendRequest, STORE_KEY } from '../../utils'

const ServiceInfo = {
    GET_OTP_NUMBER: {
        reqFunct: reqFunct.GET_OTP_NUMBER,
        WorkerName: 'FOSxID01',
        ServiceName: 'FOSxID01_OTPManagement',
        Operation: 'I',
        ClientSentTime: '0',
    },
    SEND_OTP_FUNCTION: {
        reqFunct: reqFunct.SEND_OTP_FUNCTION,
        WorkerName: 'FOSxID01',
        ServiceName: 'FOSxID01_OTPManagement',
        Operation: 'U',
        ClientSentTime: '0',
    },
    GET_NEW_OTP: {
        reqFunct: reqFunct.GET_NEW_OTP,
        WorkerName: 'FOSxID01',
        ServiceName: 'FOSxID01_OTPManagement',
        ClientSentTime: '0',
        Operation: 'I',
    },
}

function OtpModal({ navigation, route }) {
    const { msg, time, type, otp_Type, isLogin, functCallback, isHideBack, isShowModalConfirmOrder } = route.params

    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()

    const [code, setCode] = useState('')
    const [timeOTP, setTimeOTP] = useState(time || 0)
    const [msgOTP, setMsgOTP] = useState(glb_sv.configInfo.application_style.show_get_iotp && glb_sv.objShareGlb.userInfo.c20 === 'Y' ? ' ' : msg || '')
    const [typeOTP, setTypeOTP] = useState(type || 'OTP')

    const [errors, setError] = useState('')

    const timeOTPRef = useRef(time || 0)
    const getOtpNumberFlag = useRef(false)
    const otpInput = useRef(null)
    const sendOTPFlag = useRef(false)

    const timeAuthenOtp = useRef({
        timeGetOTP: moment(),
        numberOTP: 0,
    })
    const timeoutTimingOTP = useRef(null)

    const timeoutGetiOTP = useRef(null)

    const [modalAuthen, setModalAuthen] = useState(false)
    const authenFlag = useRef(false)
    const [biometric, setBiometric] = useState('')
    const [isAuthenBiometric, setIsAuthenBiometric] = useState(false)
    const [typeGetOtp, setTypeGetOtp] = useState('iotp')
    const typeGetOtpRef = useRef('iotp')

    useEffect(() => {
        if (time) {
            timeOTPRef.current = time
            timeAuthenOtp.current = {
                timeGetOTP: moment(),
                numberOTP: time,
            }
            timingOTP()
            InteractionManager.runAfterInteractions(() => {
                if (otpInput.current) otpInput.current.focus()
            })
        } else if (otp_Type !== 3 && glb_sv.objShareGlb.userInfo.c20 === 'N') getOtpNumber()
        else Keyboard.dismiss()

        detectFingerprintAvailable()

        return () => {
            if (timeoutTimingOTP.current) clearTimeout(timeoutTimingOTP.current)
        }
    }, [])

    const sendOTP = (value) => {
        setError('')
        if (sendOTPFlag.current) return
        if (!timeOTP) return
        const check = value || code
        if (!check) return
        Keyboard.dismiss()
        sendOTPFlag.current = true
        console.log('sendOTP', check)
        const password = dataCryption.encryptString(check.trim())
        const InputParams = ['check_otp', password + '']
        sendRequest(ServiceInfo.SEND_OTP_FUNCTION, InputParams, sendOTPProc, true, sendOTPTimeout)
    }

    const sendOTPTimeout = () => {
        sendOTPFlag.current = false
    }

    const sendOTPProc = (reqInfoMap, message) => {
        console.log('🚀 ~ file: index.js ~ line 112 ~ sendOTPProc ~ message', message)
        sendOTPFlag.current = false
        if (Number(message.Result) === 0) {
            const errmsg = message.Message
            setError(errmsg)
            if (message.Code === '010013') {
                getOtpNumber(true)
            }
        } else {
            glb_sv.objShareGlb.sessionInfo.Otp = reqInfoMap.inputParam[1]
            navigation.pop()
            if (isLogin) {
                if (isHideBack) navigation.replace(Screens.HOME)
                else navigation.pop()
            }
            if (functCallback) {
                InteractionManager.runAfterInteractions(() => {
                    setTimeout(() => {
                        functCallback(true)
                    }, 0)
                })
            }
            if (isShowModalConfirmOrder) {
                setTimeout(() => {
                    glb_sv.commonEvent.next({ type: eventList.SHOW_MODAL_CONFIRM_ORDER })
                }, 500)
                // if (allowCompanyRender(['888', '081'])) {
                //     setTimeout(() => {
                //         glb_sv.commonEvent.next({ type: eventList.SHOW_MODAL_CONFIRM_ORDER })
                //     }, 500)
                // } else {
                //     if (glb_sv.objShareGlb.userInfo.c6 !== '5') {
                //         if (!glb_sv.configInfo.application_style.is_iotp_off) {
                //             if (!applicationSettings.app_settings?.iotp_modal_dont_ask_again) {
                //                 // Nếu user đã check iotp_modal_dont_ask_again thì skip
                //                 // Nếu chưa check thì show alert đăng kí iOTP
                //                 InteractionManager.runAfterInteractions(() => {
                //                     navigation.navigate(Screens.ALERT_MODAL, {
                //                         icon: <IconSvg.ErrorIcon color={styles.PRIMARY} />,
                //                         title: t('common_notify'),
                //                         content: t(t('notify_user_register_iotp')),
                //                         footerComponent: <ComponentCheckDontAskIOTPAgain />,
                //                         typeColor: styles.PRIMARY,
                //                         showCancel: true,
                //                         linkCallback: () => navigation.navigate(Screens.ACTIVE_OTP),
                //                     })
                //                 })
                //             }
                //         }
                //     }
                // }
            }
        }
    }

    const getOtpNumber = (type) => {
        if (!type) setError('')
        if (glb_sv.configInfo.application_style.show_get_iotp && glb_sv.objShareGlb.userInfo.c20 === 'Y' && typeGetOtpRef.current === 'iotp') {
            if (!authenFlag.current) {
                // setModalAuthen(true);
                if (isAuthenBiometric) handleShowBiometric()
                else setModalAuthen(true)
                return
            }
            if (isAuthenBiometric) handleShowBiometric()
            else setModalAuthen(true)
            return
        }
        Keyboard.dismiss()
        if (getOtpNumberFlag.current) return
        getOtpNumberFlag.current = true
        const InputParams = [typeGetOtpRef.current === 'iotp' ? 'manual_otp' : 'sms_otp']
        sendRequest(ServiceInfo.GET_OTP_NUMBER, InputParams, getOtpNumberProc, true, getOtpNumberTimeout)
    }

    const getOtpNumberTimeout = () => {
        getOtpNumberFlag.current = false
    }

    const getOtpNumberProc = (reqInfoMap, message) => {
        // console.log("getOtpNumberProc -> message", message)
        getOtpNumberFlag.current = false
        if (Number(message.Result) === 2) {
            return
        } else {
            let dataInfo
            if (!message.Data) return
            try {
                dataInfo = JSON.parse(message.Data)[0]
                const expTimeOtp = Number(dataInfo.c2) || 60
                let reqOtpMessage = 'OTP'
                if (Number(dataInfo.c1) === 2) {
                    //-- dạng thẻ ma trận
                    reqOtpMessage = 'OTP ' + dataInfo.c3
                }
                setMsgOTP(message.Message)
                setTimeOTP(expTimeOtp)
                timeOTPRef.current = expTimeOtp
                setTypeOTP(reqOtpMessage)
                timeAuthenOtp.current = {
                    timeGetOTP: moment(),
                    numberOTP: expTimeOtp,
                }
                timingOTP()
                if (otpInput.current) otpInput.current.focus()
            } catch (err) {
                console.log('getOtpNumberProc Lỗi parse json: ' + err)
            }
        }
    }

    const timingOTP = () => {
        if (timeOTPRef.current > 0) {
            if (timeoutTimingOTP.current) clearTimeout(timeoutTimingOTP.current)
            timeoutTimingOTP.current = setTimeout(() => {
                const remainTimeOTP = Math.max(0, timeAuthenOtp.current.numberOTP - Math.round((moment() - timeAuthenOtp.current.timeGetOTP) / 1000))
                timeOTPRef.current = remainTimeOTP
                setTimeOTP(remainTimeOTP)
                timingOTP()
            }, 1000)
        }
    }

    const handleDismiss = () => {
        if (isShowModalConfirmOrder) {
            setTimeout(() => {
                glb_sv.commonEvent.next({ type: eventList.SHOW_MODAL_CONFIRM_ORDER })
            }, 500)
            // if (allowCompanyRender(['888', '081'])) {
            //     setTimeout(() => {
            //         glb_sv.commonEvent.next({ type: eventList.SHOW_MODAL_CONFIRM_ORDER })
            //     }, 500)
            // } else {
            //     if (glb_sv.objShareGlb.userInfo.c6 !== '5') {
            //         if (!glb_sv.configInfo.application_style.is_iotp_off) {
            //             if (!applicationSettings.app_settings?.iotp_modal_dont_ask_again) {
            //                 // Nếu user đã check iotp_modal_dont_ask_again thì skip
            //                 // Nếu chưa check thì show alert đăng kí iOTP
            //                 InteractionManager.runAfterInteractions(() => {
            //                     navigation.navigate(Screens.ALERT_MODAL, {
            //                         icon: <IconSvg.ErrorIcon color={styles.PRIMARY} />,
            //                         title: t('common_notify'),
            //                         content: t(t('notify_user_register_iotp')),
            //                         footerComponent: <ComponentCheckDontAskIOTPAgain />,
            //                         typeColor: styles.PRIMARY,
            //                         showCancel: true,
            //                         linkCallback: () => navigation.navigate(Screens.ACTIVE_OTP),
            //                     })
            //                 })
            //             }
            //         }
            //     }
            // }
        }

        navigation.pop()
        if (isLogin) {
            if (isHideBack) navigation.replace(Screens.HOME)
            else navigation.pop()
        }
    }

    const handleGetNewOTP = () => {
        const InputParams = ['new_otp', getUniqueIdDevice()]
        sendRequest(ServiceInfo.GET_NEW_OTP, InputParams, handleGetNewOTPResult, true, handleGetNewOTPResultTimeout)
    }

    const handleGetNewOTPResultTimeout = () => {
        setError(t('request_hanlde_not_success_try_again'))
    }

    const handleGetNewOTPResult = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            if (message.Code === '010012') {
                if (timeoutGetiOTP.current) clearTimeout(timeoutGetiOTP.current)
                timeoutGetiOTP.current = setTimeout(() => {
                    handleGetNewOTP()
                }, 500)
            } else {
                setError(message.Message)
            }
        } else {
            let datajson
            try {
                datajson = message.Data ? JSON.parse(message.Data)[0] : {}
            } catch (err) {
                console.log('handleRegisterResult', err)
                return
            }
            setTimeOTP(datajson.c0)
            timeOTPRef.current = datajson.c0
            timeAuthenOtp.current = {
                numberOTP: datajson.c0,
                timeGetOTP: moment(),
            }
            timingOTP()

            setCode(dataCryption.decryptString(datajson.c1))
        }
    }

    const hideAuthen = () => {
        setModalAuthen(false)
    }

    const authenSuccess = () => {
        setModalAuthen(false)
        authenFlag.current = true
        handleGetNewOTP()
    }

    const handleShowBiometric = (value) => {
        FingerprintScanner.release()
        glb_sv.commonEvent.next({ type: eventList.AUTHEN_BIOMETRIC, isShow: true })
        FingerprintScanner.authenticate({ description: t('fingerprint_setting'), cancelButton: t('common_Cancel'), fallbackEnabled: false })
            .then((res) => {
                glb_sv.commonEvent.next({ type: eventList.AUTHEN_BIOMETRIC, isShow: false })
                authenFlag.current = true
                handleGetNewOTP()
                setModalAuthen(false)
                setIsAuthenBiometric(true)
            })
            .catch((err) => {
                console.log('err', err)
                setModalAuthen(true)
                glb_sv.commonEvent.next({ type: eventList.AUTHEN_BIOMETRIC, isShow: false })
            })
    }

    const detectFingerprintAvailable = () => {
        FingerprintScanner.isSensorAvailable()
            .then((type) => {
                setBiometric(type)
                const IsAuthenBiometricStore = SyncStorage.get(STORE_KEY.AUTHEN_BIOMETRIC)
                if (IsAuthenBiometricStore) {
                    setIsAuthenBiometric(true)
                }
            })
            .catch((error) => {
                console.log('detectFingerprintAvailable -> error', error)
            })
    }

    const handleChangeTypeOtp = (value) => {
        if (typeGetOtpRef.current === value) return
        setTypeGetOtp(value)
        typeGetOtpRef.current = value
        setMsgOTP('')
        setTimeOTP(0)
        timeOTPRef.current = 0
        setTypeOTP('OTP')
        timeAuthenOtp.current = {
            timeGetOTP: moment(),
            numberOTP: 0,
        }
        setError('')
        setCode('')
        if (timeoutTimingOTP.current) clearTimeout(timeoutTimingOTP.current)
        // getOtpNumber()
    }

    if (!timeOTP) {
        return <></>
    }
    return (
        <TouchableWithoutFeedback>
            <KeyboardAvoidingView
                behavior={IOS ? 'padding' : ''}
                style={{
                    flex: 1,
                    backgroundColor: 'transparent',
                    alignItems: 'center',
                    justifyContent: 'center',
                    shadowColor: styles.SECOND__CONTENT__COLOR,
                    shadowOffset: {
                        width: 0,
                        height: 0,
                    },
                    shadowOpacity: 0.48,
                    shadowRadius: 11.95,
                    elevation: 18,
                }}
            >
                <View
                    style={{
                        backgroundColor: styles.PRIMARY__BG__COLOR,
                        paddingTop: dimensions.vertical(32),
                        paddingHorizontal: dimensions.moderate(28),
                        paddingBottom: dimensions.vertical(12),
                        marginHorizontal: dimensions.moderate(28),
                        borderRadius: 12,
                        justifyContent: 'center',
                        alignItems: 'center',
                    }}
                >
                    <IconSvg.ClockIcon color={styles.REF__COLOR} />

                    <Text
                        style={{
                            marginTop: dimensions.vertical(32),
                            marginBottom: dimensions.vertical(16),
                            fontSize: fontSizes.xmedium,
                            color: styles.PRIMARY__CONTENT__COLOR,
                            fontWeight: fontWeights.semiBold,
                            textAlign: 'center',
                        }}
                    >
                        {otp_Type === 4 ? t('title_static_otp') : t('enter_authen_otp')}
                    </Text>

                    <Text
                        style={{
                            fontSize: fontSizes.verySmall,
                            color: styles.ERROR__COLOR,
                            marginBottom: dimensions.vertical(0),
                            opacity: errors ? 1 : 0,
                            marginTop: dimensions.vertical(0),
                        }}
                    >
                        {errors}
                    </Text>

                    <Text
                        style={{
                            fontSize: fontSizes.small,
                            color: styles.PRIMARY__CONTENT__COLOR,
                            marginTop: dimensions.vertical(16),
                            marginBottom: dimensions.moderate(16),
                            opacity: 0.64,
                            textAlign: 'center',
                        }}
                    >
                        {/* {otp_Type === 3 && timeOTP === 0 ? t('note_get_otp_authen_login') :
                            (msgOTP || t('otp_sent_to_email_sms'))} */}
                        {msgOTP || t('otp_sent_to_email_sms')}
                    </Text>

                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                        <Text
                            style={{
                                fontSize: fontSizes.normal,
                                fontWeight: fontWeights.medium,
                                color: styles.PRIMARY__CONTENT__COLOR,
                            }}
                        >
                            {typeOTP}
                        </Text>
                        <View
                            style={{
                                backgroundColor: styles.INPUT__BG__LOGIN,
                                borderRadius: 20,
                                width: 230,
                                height: 40,
                                justifyContent: 'center',
                                flexDirection: 'row',
                                marginLeft: 8,
                                marginBottom: 16,
                            }}
                        >
                            <TextInput
                                autoFocus
                                editable={!!timeOTP}
                                keyboardType={otp_Type === 4 ? 'default' : 'number-pad'}
                                maxLength={6}
                                ref={otpInput}
                                secureTextEntry
                                style={{
                                    letterSpacing: 16,
                                    fontSize: fontSizes.medium,
                                    fontWeight: fontWeights.semiBold,
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                    textAlign: 'center',
                                    flex: 1,
                                }}
                                textContentType="oneTimeCode"
                                value={code}
                                onChangeText={(value) => {
                                    setError('')
                                    setCode(value)
                                    if (value.length === 6) {
                                        sendOTP(value)
                                    }
                                }}
                            />
                        </View>
                    </View>

                    {/* Đối với IVS ẩn CountDown thời gian OTP đối với loại OTP Tĩnh */}
                    {allowCompanyRender(['061']) && otp_Type === 4 ? (
                        <></>
                    ) : (
                        <Text
                            style={{
                                fontSize: fontSizes.verySmall,
                                color: styles.SECOND__CONTENT__COLOR,
                                marginBottom: dimensions.vertical(6),
                                opacity: timeOTP ? 1 : 0,
                                marginTop: dimensions.vertical(16),
                            }}
                        >
                            {t('otp_timeout_after')}{' '}
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR }}>
                                {timeOTP} {t('second')}
                            </Text>
                        </Text>
                    )}

                    {glb_sv.configInfo.application_style.is_show_SMS_OTP_Modal && glb_sv.objShareGlb.userInfo.c6 === '5' ? (
                        <View style={{ flexDirection: 'row', justifyContent: 'space-evenly', marginBottom: dimensions.vertical(16) }}>
                            <Pressable
                                hitSlop={10}
                                style={{ flexDirection: 'row', alignItems: 'center', marginHorizontal: dimensions.moderate(16) }}
                                onPress={() => handleChangeTypeOtp('iotp')}
                            >
                                <IconSvg.CheckboxIcon
                                    active={typeGetOtp === 'iotp'}
                                    colorActive={styles.PRIMARY}
                                    colorunActive={styles.PRIMARY__CONTENT__COLOR}
                                />
                                <Text
                                    style={{
                                        fontSize: fontSizes.small,
                                        color: styles.PRIMARY__CONTENT__COLOR,
                                        marginLeft: dimensions.moderate(8),
                                        marginRight: 24,
                                    }}
                                >
                                    iOTP
                                </Text>
                            </Pressable>
                            <Pressable
                                hitSlop={10}
                                style={{ flexDirection: 'row', alignItems: 'center', marginHorizontal: dimensions.moderate(16) }}
                                onPress={() => handleChangeTypeOtp('sms')}
                            >
                                <IconSvg.CheckboxIcon
                                    active={typeGetOtp === 'sms'}
                                    colorActive={styles.PRIMARY}
                                    colorunActive={styles.PRIMARY__CONTENT__COLOR}
                                />
                                <Text
                                    style={{
                                        fontSize: fontSizes.small,
                                        color: styles.PRIMARY__CONTENT__COLOR,
                                        marginLeft: dimensions.moderate(8),
                                        marginRight: 24,
                                    }}
                                >
                                    SMS OTP
                                </Text>
                            </Pressable>
                        </View>
                    ) : null}

                    <View>
                        <Button
                            style={{
                                width: dimensions.moderate(172),
                                backgroundColor: code.length > 3 || !timeOTP ? styles.PRIMARY : styles.PRIMARY + '4d',
                                justifyContent: 'center',
                                borderRadius: 8,
                            }}
                            transparent
                            onPress={() => (timeOTP ? sendOTP(code) : getOtpNumber())}
                        >
                            <Text style={{ color: code.length > 3 || !timeOTP ? '#FFF' : styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.normal }}>
                                {timeOTP
                                    ? t('title_authen_otp')
                                    : glb_sv.configInfo.application_style.show_get_iotp && glb_sv.objShareGlb.userInfo.c20 === 'Y' && typeGetOtp === 'iotp'
                                        ? t('get_iotp_number')
                                        : t('get_otp_number')}
                            </Text>
                        </Button>
                        <Button style={{ width: dimensions.moderate(172), justifyContent: 'center' }} transparent onPress={handleDismiss}>
                            <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.normal }}>{t('common_Cancel')}</Text>
                        </Button>
                    </View>

                    {modalAuthen ? (
                        <ModalAuthen
                            authenSuccess={authenSuccess}
                            biometric={biometric}
                            handleShowBiometric={handleShowBiometric}
                            hideAuthen={hideAuthen}
                            isAuthenBiometric={isAuthenBiometric}
                            visible={modalAuthen}
                        />
                    ) : null}
                </View>
            </KeyboardAvoidingView>
        </TouchableWithoutFeedback>
    )
}

const ComponentCheckDontAskIOTPAgain = () => {
    const { styles, applicationSettings, setApplicationSettings } = useContext(StoreContext)
    const { t } = useTranslation()

    const [isCheck, setIsCheck] = useState(applicationSettings?.app_settings?.iotp_modal_dont_ask_again)

    useUpdateEffect(() => {
        setApplicationSettings((prevConfig) => {
            const newConfig = { ...prevConfig }
            newConfig.app_settings.iotp_modal_dont_ask_again = isCheck
            return newConfig
        })
    }, [isCheck])

    const onChangeCheckDontAskAgain = () => {
        // glb_sv.commonEvent.next({ type: eventList.CANCEL_AND_CLOSE_ALERT_MODAL })
        setIsCheck(!applicationSettings?.app_settings?.iotp_modal_dont_ask_again)
    }

    return (
        <View
            style={{
                marginBottom: 16,
                flexDirection: 'row',
                alignItems: 'flex-start',
                borderRadius: 12,
                marginHorizontal: dimensions.moderate(16),
            }}
        >
            <TouchableOpacity
                activeOpacity={0.9}
                style={{ flexDirection: 'row', alignItems: 'center', marginTop: dimensions.vertical(16) }}
                onPress={onChangeCheckDontAskAgain}
            >
                <View style={{ paddingTop: 2 }}>
                    <IconSvg.CheckboxIcon active={isCheck} colorActive={styles.PRIMARY} colorunActive={styles.PRIMARY__CONTENT__COLOR} />
                </View>
                <Text
                    style={{
                        fontSize: fontSizes.small,
                        color: styles.PRIMARY__CONTENT__COLOR,
                        marginLeft: dimensions.moderate(8),
                        marginRight: 16,
                    }}
                >
                    {t('dont_ask_me_again')}
                </Text>
            </TouchableOpacity>
        </View>
    )
}

export default memo(OtpModal)
