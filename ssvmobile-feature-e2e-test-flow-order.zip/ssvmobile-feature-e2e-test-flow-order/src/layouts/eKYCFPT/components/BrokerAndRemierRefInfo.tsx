import React, { useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { ActivityIndicator, InteractionManager, StyleSheet, TextInput, TouchableOpacity, View } from 'react-native'
import ToastGlobal from 'react-native-toast-message'
import AntDesign from 'react-native-vector-icons/AntDesign'

import IconRightArrow from '../../../assets/images/common/ic_arrow_right.svg'
import { Text } from '../../../basic-components'
import ModalSelection from '../../../components/list-selections'
import { RowTitleGroup } from '../../../components/trading-component'
import useLoading from '../../../hoc/useLoading'
import { StoreContext } from '../../../store'
import { dimensions as dm, fontSizes as fs } from '../../../styles'
import { glb_sv, reqFunct, sendRequest } from '../../../utils'
import { configUIEkyc } from '../config'

const ServiceInfo: IServiceInfo = {
    GET_BROKER_REMISIER_LIST: {
        reqFunct: reqFunct.GET_BROKER_REMISIER_LIST,
        WorkerName: 'FOSqID02',
        ServiceName: 'FOSqID02_HOSUserInformation',
        Operation: 'Q',
    },
}
interface IBrokerRefInfoProps {
    onChangeBrokerRefInfo: (callbackData: { refCode: string; refName: string; data: any }) => void
    inputType: 'select' | 'input'
    hasDivider?: boolean
}

export const BrokerAndRemierRefInfo = ({ inputType, onChangeBrokerRefInfo = () => null, hasDivider = true }: IBrokerRefInfoProps) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()
    const [referrerCode, setReferrerCode] = useState('')
    const [referrerName, setReferrerName] = useState('')
    const [brokerRemisierList, setBrokerRemisierList] = useState<any[]>([])
    const [checking, setChecking] = useLoading(false)
    const [selectedBroker, setSelectedBroker] = useState<{ value: string; label: string; data: IServiceResponeData }>({
        value: '',
        label: '',
        data: {},
    })
    const [infoSelection, setInfoSelection] = useState<{
        type: string
        callback: (item?: any) => any
    }>({
        type: '',
        callback: () => {},
    })
    // -----------------------
    const [isOpenModalSelect, setIsOpenModalSelect] = useState(false)
    useEffect(() => {
        // Nếu là type select thì gọi service lấy danh sách luôn
        if (inputType === 'select' && isOpenModalSelect) {
            getBrokerList()
        }
    }, [inputType, isOpenModalSelect])

    //------------------------
    const timeOutCheckName = useRef<any>(null)
    useEffect(() => {
        setReferrerName('')
        setChecking(true)
        if (timeOutCheckName.current) {
            clearTimeout(timeOutCheckName.current)
        }
        timeOutCheckName.current = setTimeout(() => {
            setChecking(false)
            checkNameByReferrerCode()
        }, 1000)
    }, [referrerCode])

    useEffect(() => {
        // console.log('selectedBroker', selectedBroker)
        if (inputType === 'select') {
            onChangeBrokerRefInfo({
                refCode: selectedBroker.value,
                refName: selectedBroker.data?.c1 || '',
                data: selectedBroker?.data || {},
            })
        } else {
            onChangeBrokerRefInfo({
                refCode: referrerCode,
                refName: referrerName,
                data: selectedBroker?.data || {},
            })
        }
    }, [referrerCode, referrerName, selectedBroker])

    const getBrokerList = () => {
        // console.log('getBrokerList', brokerList, glb_sv.brokerRemisierList.length)
        if (!glb_sv.brokerRemisierList.length) {
            const inval = ['brk_rem']
            sendRequest(ServiceInfo.GET_BROKER_REMISIER_LIST, inval, onGetBrokerListResult)
        } else {
            setBrokerRemisierList(glb_sv.brokerRemisierList || [])
        }
    }

    const onGetBrokerListResult = (reqInfoMap, message) => {
        // setLoading(false)

        if (Number(message.Result) === 0) {
            ToastGlobal.show({
                text2: message.Message,
                type: 'warning',
            })
            return
        } else {
            let tempDataList = []
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {
                jsondata = []
            }
            tempDataList = tempDataList.concat(jsondata)

            if (Number(message.Packet) <= 0) {
                glb_sv.brokerRemisierList = tempDataList
                InteractionManager.runAfterInteractions(() => {
                    setBrokerRemisierList(tempDataList)
                })
            }
        }
    }

    const checkNameByReferrerCode = () => {
        // const matchBroker = brokerRemisierList.filter((item) => item.c2 === '1').find((item) => item.c0 === referrerCode)
        // Check cả broker + remiser
        const matchBrokerOrRemiser = brokerRemisierList.find((item) => item.c0 === referrerCode)
        setReferrerName(matchBrokerOrRemiser?.c1)
        setSelectedBroker({ value: '', label: '', data: matchBrokerOrRemiser })
    }
    // ---------------------------
    const onPressSelect = () => {
        setInfoSelection({ type: 'NORMAL_SELECT', callback: onSelect })
        setIsOpenModalSelect(true)
    }

    // -----
    const onSelect = (item) => {
        setSelectedBroker(item)
    }

    // Lấy cả broker[1] + remiser[2]
    const brokerRemisierListConvert = brokerRemisierList
        // .filter((item) => item.c2 === '1')
        .map((item) => {
            return {
                label: item.c1 + ` (${item.c0})`,
                value: item.c0,
                data: item,
            }
        })

    return (
        <>
            {/* {inputType === 'input' ? <RowTitleGroup hasDivider={hasDivider} text={t<string>('broker_staff')} /> : null} */}
            {inputType === 'input' ? (
                <>
                    <View style={[UI.row, { alignItems: 'center' }, { display: 'flex' }]}>
                        <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fs.small, flex: 4 }}>{t<string>('id_staff')}</Text>
                        <View
                            style={{
                                flex: 5,
                                backgroundColor: styles.INPUT__BG,
                                paddingHorizontal: 10,
                                paddingVertical: 8,
                                borderRadius: 4,
                            }}
                        >
                            <TextInput
                                autoCapitalize="none"
                                placeholder={t<string>('common_code_staff')}
                                placeholderTextColor={styles.PLACEHODLER__COLOR}
                                returnKeyType="next"
                                style={{
                                    fontSize: fs.small,
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                    textAlignVertical: 'center',
                                }}
                                value={referrerCode}
                                onChangeText={(value) => {
                                    setReferrerCode(value)
                                }}
                                onFocus={getBrokerList}
                            />
                        </View>
                    </View>
                    <View style={[UI.row, { alignItems: 'center' }, { display: 'flex' }]}>
                        <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fs.small, flex: 4 }}>{t<string>('full_name_staff')}</Text>
                        <View
                            style={{
                                flex: 5,
                                backgroundColor: styles.INPUT__BG,
                                paddingHorizontal: 10,
                                paddingVertical: 8,
                                borderRadius: 4,
                            }}
                        >
                            <TextInput
                                autoCapitalize="none"
                                editable={false}
                                placeholder={t<string>('')}
                                placeholderTextColor={styles.PLACEHODLER__COLOR}
                                returnKeyType="done"
                                style={{
                                    fontSize: fs.small,
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                    textAlignVertical: 'center',
                                }}
                                value={referrerName}
                                onChangeText={(value) => {
                                    setReferrerName(value)
                                }}
                            />
                            {checking ? (
                                <View style={{ position: 'absolute', right: 16, top: 6 }}>
                                    <ActivityIndicator color={styles.PRIMARY__CONTENT__COLOR} />
                                </View>
                            ) : null}
                        </View>
                    </View>
                </>
            ) : null}

            {inputType === 'select' ? (
                <TouchableOpacity onPress={onPressSelect}>
                    <View style={[UI.GroupInputSelect]}>
                        <View style={{ flex: 4 }}>
                            <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fs.small, textAlignVertical: 'center' }}>
                                {t<string>('broker_staff')}
                            </Text>
                        </View>
                        <View style={{ flex: 5, flexDirection: 'row', justifyContent: 'flex-end' }}>
                            <Text numberOfLines={1} style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fs.small, width: '90%' }}>
                                {configUIEkyc.is_show_brk_rem_id && selectedBroker.data ? `${selectedBroker.data?.c0 || ''} - ` : ''}
                                {selectedBroker.data?.c1}
                            </Text>
                            {selectedBroker.label ? (
                                <TouchableOpacity onPress={() => setSelectedBroker({ value: '', label: '', data: {} })}>
                                    <AntDesign color={styles.ICON__PRIMARY} name="closecircleo" size={20} style={{ marginHorizontal: dm.moderate(5) }} />
                                </TouchableOpacity>
                            ) : (
                                <IconRightArrow style={{ color: styles.ICON__PRIMARY }} />
                            )}
                        </View>
                    </View>
                </TouchableOpacity>
            ) : null}

            {inputType === 'select' ? (
                <ModalSelection
                    actionType={infoSelection.type}
                    getSelectValue={infoSelection.callback}
                    isOpen={isOpenModalSelect}
                    listSelectionsProps={brokerRemisierListConvert}
                    setIsOpen={setIsOpenModalSelect}
                />
            ) : null}
        </>
    )
}

const UI = StyleSheet.create({
    BlankSpace: {
        height: 10,
        width: dm.moderate(40),
    },
    ButtonDelete: {
        alignItems: 'center',
        height: '100%',
        justifyContent: 'center',
        position: 'absolute',
        right: 0,
    },
    GroupInput: {
        marginVertical: dm.halfVerticalIndent,
        paddingHorizontal: dm.halfIndent,
    },
    GroupInputSelect: {
        flexDirection: 'row',
        marginHorizontal: dm.moderate(16),
        marginVertical: dm.halfVerticalIndent,
    },
    RowInput: {
        marginLeft: dm.moderate(8),
        marginVertical: dm.vertical(8),
    },
    modal: {
        justifyContent: 'flex-end',
        margin: 0,
    },
    row: {
        alignItems: 'center',
        borderRadius: 12,
        flexDirection: 'row',
        marginHorizontal: dm.moderate(16),
        marginTop: dm.vertical(12),
    },
})
