import React, { useCallback, useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { FlatList, TextInput, View } from 'react-native'
import Modal from 'react-native-modal'
import { SafeAreaView } from 'react-native-safe-area-context'
// import { fontWeights, dimensions, fontSizes } from '../../styles';
import ToastGlobal from 'react-native-toast-message'
import AntDesign from 'react-native-vector-icons/AntDesign'
import { Body, Button, Col, Icon, ListItem, Row } from 'native-base'

import { Text } from '../../basic-components'
import EmptyView from '../../components/trading-component/empty-view'
import { StoreContext } from '../../store'
import { dimensions as dm, fontSizes as fs, fontWeights } from '../../styles'
import { glb_sv, reqFunct, sendRequest } from '../../utils'

export default function BrokerRemisierSelection({ navigation, route, isOpen, actionType, getSelectValue, setIsOpen }) {
    const TAG = 'BrokerRemisierSelection'

    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()
    const [seach, setSearch] = useState('')
    const [checkType, setCheckType] = useState('')
    const [originalDataList, setOriginalDataList] = useState([])
    const [listSelections, setListSelections] = useState([])
    const timeOutSearch = useRef(null)
    // const [isModalOpen, setIsModalOpen] = useState(false);

    useEffect(() => {
        const brokerRemisierList = glb_sv.brokerRemisierList
        if (brokerRemisierList.length == 0) {
            getBrokerList()
        } else {
            showBrokerRemisierFilteredData()
        }
    }, [actionType])

    const ServiceInfo = {
        GET_BROKER_REMISIER_LIST: {
            reqFunct: reqFunct.GET_BROKER_REMISIER_LIST,
            WorkerName: 'FOSqID02',
            ServiceName: 'FOSqID02_HOSUserInformation',
            ClientSentTime: '0',
            Operation: 'Q',
        },
    }

    const getBrokerList = () => {
        glb_sv.brokerRemisierList = []

        const inval = ['brk_rem']
        sendRequest(ServiceInfo.GET_BROKER_REMISIER_LIST, inval, onGetBrokerListResult, true)
    }

    const onGetBrokerListResult = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            ToastGlobal.show({
                text2: message.Message,
                type: 'warning',
            })

            return
        } else {
            let tempDataList = []
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {
                jsondata = []
            }
            tempDataList = tempDataList.concat(jsondata)

            if (Number(message.Packet) <= 0) {
                glb_sv.brokerRemisierList = tempDataList
                showBrokerRemisierFilteredData()
            }
        }
    }

    const showBrokerRemisierFilteredData = () => {
        if (actionType === 'PICK_BROKER') {
            const brokerList = glb_sv.brokerRemisierList.filter((item) => {
                return item.c2 === '1'
            })
            console.log('BrokerList: ', brokerList)
            const glbBrokerList = brokerList.map((item) => {
                const label = item.c1
                const value = item
                return { label, value }
            })

            setListSelections(glbBrokerList)
            setOriginalDataList(glbBrokerList)
        } else if (actionType === 'PICK_REMISIER') {
            const remisierList = glb_sv.brokerRemisierList.filter((item) => {
                return item.c2 === '2'
            })
            console.log('RemisierList: ', remisierList)

            const glbRemisierList = remisierList.map((item) => {
                const label = item.c1
                const value = item
                return { label, value }
            })
            setListSelections(glbRemisierList)
            setOriginalDataList(glbRemisierList)
        }
    }

    const onValueSearchChanged = (name) => {
        setSearch(name)
        if (name == '') {
            timeOutSearch.current = setTimeout(() => {
                setListSelections(originalDataList)
            }, 300)
            return
        }

        if (timeOutSearch.current) clearTimeout(timeOutSearch.current)

        timeOutSearch.current = setTimeout(() => {
            const newList = listSelections
                .filter((o) => o.label.toLowerCase().includes(name.toLowerCase()))
                .sort(function (a, b) {
                    if (a.label > b.label) return -1
                    if (a.label < b.label) return 1
                    return 0
                })
            setListSelections(newList)
        }, 300)
    }

    const ItemSelect = ({ item }) => {
        return (
            <ListItem
                activeOpacity={0.6}
                style={{
                    borderBottomColor: styles.DIVIDER__COLOR,
                    height: dm.vertical(55),
                }}
                underlayColor="transparent"
                onPress={() => {
                    onSelect(item)
                    setCheckType(item.value.c0)
                    setIsOpen(false)
                }}
            >
                <Body style={{ flexDirection: 'column', justifyContent: 'flex-start' }}>
                    <Row>
                        <Col size={24}>
                            <Text
                                style={{
                                    color: checkType == item.value.c0 && actionType === 'PICK_RIGHT_TYPE' ? styles.PRIMARY : styles.PRIMARY__CONTENT__COLOR,
                                    fontWeight: fontWeights.medium,
                                }}
                            >
                                {item.label}
                            </Text>
                        </Col>
                        <Col size={2} style={{ alignItems: 'flex-end' }}>
                            {checkType == item.value.c0 && actionType === 'PICK_RIGHT_TYPE' ? (
                                <Icon name="check" style={{ color: styles.PRIMARY }} type="AntDesign" />
                            ) : (
                                <Text />
                            )}
                        </Col>
                    </Row>
                </Body>
            </ListItem>
        )
    }

    const resetData = () => {
        setSearch('')
        setListSelections(originalDataList)
    }

    const onSelect = useCallback(
        (selection) => {
            getSelectValue(selection)
            resetData()
        },
        [actionType],
    )

    const dismiss = () => {
        setIsOpen(false)
    }

    return (
        <Modal
            animationIn="slideInUp"
            animationOut="slideOutDown"
            hideModalContentWhileAnimating={true}
            // animationIn="slideInLeft"
            // animationOut="slideOutLeft"
            isVisible={isOpen}
            style={{
                margin: 0,
            }}
            useNativeDriver={true}
        >
            <View
                style={{
                    flex: 1,
                    backgroundColor: styles.PRIMARY__BG__COLOR,
                }}
            >
                <SafeAreaView style={{ flex: 1 }}>
                    <View
                        style={{
                            flexDirection: 'row',
                            height: dm.vertical(40),
                            paddingHorizontal: dm.moderate(16),
                            marginTop: dm.vertical(16),
                            marginBottom: dm.vertical(8),
                        }}
                    >
                        {actionType === 'PICK_RIGHT_TYPE' ? (
                            <View
                                style={{
                                    flexDirection: 'row',
                                    flex: 1,
                                }}
                            >
                                <Text style={{ fontSize: fs.big, fontWeight: fontWeights.semiBold, color: styles.PRIMARY__CONTENT__COLOR }}>
                                    Danh sách loại quyền
                                </Text>
                            </View>
                        ) : (
                            <View
                                style={{
                                    backgroundColor: styles.HEADER__BG__COLOR,
                                    flexDirection: 'row',
                                    flex: 1,
                                    borderRadius: 50,
                                }}
                            >
                                <AntDesign
                                    color={styles.PLACEHODLER__COLOR}
                                    name="search1"
                                    size={20}
                                    style={{
                                        paddingVertical: dm.moderate(8),
                                        paddingLeft: dm.moderate(8),
                                    }}
                                />

                                <TextInput
                                    autoCapitalize="none"
                                    placeholder={t('search')}
                                    placeholderTextColor={styles.PLACEHODLER__COLOR}
                                    style={{
                                        color: styles.PRIMARY__CONTENT__COLOR,
                                        fontSize: fs.small,
                                        padding: 0,
                                        paddingHorizontal: 5,
                                        flex: 1,
                                    }}
                                    value={seach}
                                    onChangeText={(search) => onValueSearchChanged(search)}
                                />
                                {seach ? (
                                    <AntDesign
                                        color={styles.PLACEHODLER__COLOR}
                                        name="closecircle"
                                        size={20}
                                        style={{ paddingVertical: 7, paddingHorizontal: 5 }}
                                        onPress={resetData}
                                    />
                                ) : null}
                            </View>
                        )}
                        <Button
                            style={{
                                justifyContent: 'center',
                                alignSelf: 'center',
                                paddingHorizontal: dm.moderate(24),
                            }}
                            transparent
                            onPress={() => {
                                setIsOpen(false)
                                resetData()
                            }}
                        >
                            <Text
                                style={{
                                    color: styles.BUTTON__TEXT__ACTIVE,
                                    fontSize: fs.medium,
                                }}
                            >
                                {t('common_Cancel')}
                            </Text>
                        </Button>
                    </View>

                    {originalDataList.length === 0 ? (
                        <EmptyView
                            isShowReload={true}
                            refreshFunction={() => {
                                getBrokerList()
                            }}
                        />
                    ) : (
                        <FlatList
                            data={listSelections}
                            keyboardShouldPersistTaps="always"
                            keyExtractor={(item) => item.label}
                            renderItem={ItemSelect}
                            style={{ marginBottom: 20 }}
                        />
                    )}
                </SafeAreaView>
            </View>
        </Modal>
    )
}
