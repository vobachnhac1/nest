import React, { useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { ImageBackground, StyleSheet, View } from 'react-native'
import StepIndicator from 'react-native-step-indicator'
import Svg, { Circle, Path } from 'react-native-svg'

// @ts-expect-error
import IconRight from '../../../../assets/images/gif/arrow-right.gif'
import { StoreContext } from '../../../../store'
import { dimensions as dm } from '../../../../styles'

export const GuideIconAnimation = ({ progress = 0, zIndex }: { progress: 0 | 1 | 2 | 3 | 4 | number; zIndex: number }) => {
    const { styles, theme, language } = useContext(StoreContext)
    const { t } = useTranslation()

    return (
        <View style={[UI.row, { zIndex }]}>
            {progress === 0 ? <ImageBackground source={IconRight} style={{ width: 60, height: 50 }} /> : null}
            {progress === 1 ? <ImageBackground source={IconRight} style={{ width: 60, height: 50, transform: [{ rotate: '180deg' }] }} /> : null}
            {progress === 2 || progress === 3 ? (
                <>
                    <ImageBackground source={IconRight} style={{ width: 60, height: 50 }} />
                    <ImageBackground source={IconRight} style={{ width: 60, height: 50, transform: [{ rotate: '180deg' }] }} />
                </>
            ) : null}
        </View>
    )
}
const UI = StyleSheet.create({
    circle_style: {
        alignSelf: 'center',
        borderRadius: 50,
        height: 14,
        marginHorizontal: 3,
        width: 14,
    },
    row: {
        alignItems: 'center',
        flexDirection: 'row',
        height: 32,
        justifyContent: 'center',
        marginBottom: 16,
        marginTop: 20,
        padding: dm.moderate(16),
    },
})
