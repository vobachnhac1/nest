import { ColorSchemeName } from 'react-native'

export const useColorScheme = (): NonNullable<ColorSchemeName> => {
    return 'dark'
}
