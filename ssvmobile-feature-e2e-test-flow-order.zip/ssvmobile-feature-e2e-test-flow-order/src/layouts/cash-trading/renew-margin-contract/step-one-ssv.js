import React, { useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { FlatList, TouchableOpacity, View } from 'react-native'
import DateTimePickerModal from 'react-native-modal-datetime-picker'
import ToastGlobal from 'react-native-toast-message'
import moment from 'moment'
import { Row } from 'native-base'

import { Text } from '../../../basic-components'
import Account from '../../../components/account'
import { ColTableData, RowTableData, RowTitleGroup } from '../../../components/trading-component'
import EmptyView from '../../../components/trading-component/empty-view'
import HeaderList from '../../../components/trading-component/header-list'
import { StoreContext } from '../../../store'
import { StoreTrading } from '../../../store-trading'
import { dimensions, dimensions as dm, fontSizes, fontSizes as fs, IconSvg } from '../../../styles'
import { eventList, glb_sv, reqFunct, sendRequest } from '../../../utils'
import FormatNumber from '../../../utils/formatNumber/FormatNumber'

// Khai báo ServiceInfo (nếu có)
const ServiceInfo = {
    GET_LIST_CONTRACT_RENEW: {
        reqFunct: reqFunct.GET_LIST_CONTRACT_RENEW,
        WorkerName: 'FOSqMargin',
        ServiceName: 'FOSqMargin_Online_1404',
        ClientSentTime: '0',
        Operation: 'Q',
        // TestInput: ['1', userInfo.actn_curr, '00']
    },
    GET_HIS_PAY_ON_ACCOUT_BY_SUB: {
        reqFunct: reqFunct.GET_HIS_PAY_ON_ACCOUT_BY_SUB,
        WorkerName: 'FOSqCash',
        ServiceName: 'FOSqCash_0201_1',
        ClientSentTime: '0',
        Operation: 'Q',
        // TestInput: ["2", "888c000354", "00"]
    },
    GET_HIS_PAY_ON_ACCOUT_BY_ACT: {
        reqFunct: reqFunct.GET_HIS_PAY_ON_ACCOUT_BY_ACT,
        WorkerName: 'FOSqCash',
        ServiceName: 'FOSqCash_0201_1',
        ClientSentTime: '0',
        Operation: 'Q',
        // TestInput: ["2", "888c000354", "%"]
    },
    GET_HIST_CONTRACT_RENEW: {
        reqFunct: reqFunct.GET_HIST_CONTRACT_RENEW, // Lịch sử yêu cầu gia hạn
        WorkerName: 'FOSqCommon',
        ServiceName: 'FOSqCommon_MarginInfo',
        ClientSentTime: '0',
        Operation: 'Q',
    },
}

// Khai báo component
const StepOne = ({ setContractSelect, switchStep, navigation, refreshing, setContractHistory, setHistory, route }) => {
    const { theme, styles, language } = useContext(StoreContext)
    const { userInfo } = useContext(StoreTrading)

    const { t } = useTranslation()

    const [listContractRenew, setListContractRenew] = useState([])
    const [listHistoryContractRenew, setListHistoryContractRenew] = useState([])

    const [defaultCondition, setDefaultCondition] = useState({
        fromDt: moment(glb_sv.objShareGlb.workDate).subtract(1, 'months').toDate(),
        toDt: moment(glb_sv.objShareGlb.workDate).toDate(),
        type: '0',
    })

    const [isDatePickerFrom, setisDatePickerFrom] = useState(false)
    const [isDatePickerTo, setisDatePickerTo] = useState(false)

    const colSpan = [1, 1, 1]

    useEffect(() => {
        // Prepare data
        getListContractRenew() // Lấy danh sách hợp đồng gia hạn

        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.LOGIN_SUCCESS) {
                // reCall service FOSq
                getListContractRenew()
            }
        })

        return () => {
            commonEvent.unsubscribe()
        }
    }, [userInfo.sub_curr, refreshing])

    useEffect(() => {
        getHistContractRenew()
    }, [userInfo, defaultCondition, refreshing])

    useEffect(() => {
        // --- Navigate từ các màn hình khác tới
        if (route?.params?.data) {
            listContractRenew.forEach((contract) => {
                if (contract.c0 === route?.params?.data?.c0) {
                    setContractSelect(contract)
                    switchStep.next()
                }
            })
        }
    }, [listContractRenew])

    const getListContractRenew = () => {
        setListContractRenew([])
        if (!userInfo.actn_curr) {
            ToastGlobal.show({
                type: 'warning',
                text2: t('warning_account_is_empty'),
            })
            return
        }

        const inputParams = [userInfo.actn_curr, userInfo.sub_curr]
        sendRequest(ServiceInfo.GET_LIST_CONTRACT_RENEW, inputParams, handleGetListContractRenew)
    }

    // -------------------------------------------   Khai báo các hàm nhận (handle respone) dữ liệu từ server
    const handleGetListContractRenew = (reqInfoMap, message) => {
        console.log('handleGetListContractRenew -> message', message)
        // -- process after get result --
        if (Number(message.Result) === 0) {
            setListContractRenew([])
            ToastGlobal.show({
                type: 'warning',
                text2: message.Message,
            })
            return
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {}
            setListContractRenew(jsondata)
        }
    }

    const getHistContractRenew = () => {
        const inputParams = [
            '01',
            userInfo.actn_curr,
            userInfo.sub_curr,
            moment(defaultCondition.fromDt).format('YYYYMMDD'),
            moment(defaultCondition.toDt).format('YYYYMMDD'),
        ]
        sendRequest(ServiceInfo.GET_HIST_CONTRACT_RENEW, inputParams, handleGetListHistContractRenew)
        setListHistoryContractRenew([])
    }

    const handleGetListHistContractRenew = (reqInfoMap, message) => {
        // -- process after get result --
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
                console.log('handleGetListHistContractRenew -> jsondata', jsondata)
                setListHistoryContractRenew(jsondata)
            } catch (err) {
                return
            }
        }
    }

    const getColor = (status) => {
        if (status === 'N') return styles.wait_to_match_color
        if (status === 'R' || status === 'D') return styles.reject_color
        if (status === 'Y') return styles.UP__COLOR
    }

    const ViewLastTransfer = ({ item, index }) => {
        return (
            <RowTableData
                key={index}
                type="table"
                onPress={() => {
                    if (!userInfo.actn_curr) {
                        ToastGlobal.show({
                            type: 'warning',
                            text2: t('warning_account_is_empty'),
                        })
                        return
                    }
                    setHistory(false)
                    setContractSelect(item)
                    switchStep.next()
                }}
            >
                <ColTableData colSpan={colSpan[0]} text={moment(item.c3, 'DDMMYYYY').format('DD/MM/YYYY')} />

                <ColTableData colSpan={colSpan[1]} text={moment(item.c4, 'DDMMYYYY').format('DD/MM/YYYY')} textAlign="center" />

                <ColTableData colSpan={colSpan[2]} text={FormatNumber(item.c28, 0, 0)} textAlign="right" />
            </RowTableData>
        )
    }

    const ViewItemHistory = ({ item, index }) => {
        return (
            <RowTableData
                key={index}
                type="table"
                onPress={() => {
                    setHistory(true)
                    setContractHistory(item)
                    switchStep.next()
                }}
            >
                <ColTableData colSpan={colSpan[0]} text={FormatNumber(item.c3)} />

                <ColTableData colSpan={colSpan[1]} text={FormatNumber(item.c4)} textAlign="center" />

                <ColTableData colorText={getColor(item.c10)} colSpan={colSpan[2]} text={item.c11} textAlign="right" />
            </RowTableData>
        )
    }

    const hideDatePicker = () => {
        setisDatePickerFrom(false)
        setisDatePickerTo(false)
    }

    return (
        <View>
            <Account navigation={navigation} />

            <RowTitleGroup hasDivider text={t('select_contract')} />
            <HeaderList colSpan={colSpan} typeHeader="RENEW_MARGIN_CONTRACT" />
            <FlatList
                data={listContractRenew}
                keyExtractor={(item, index) => String(index)}
                ListEmptyComponent={EmptyView}
                renderItem={ViewLastTransfer}
                scrollEnabled={false}
                style={{ marginBottom: dm.vertical(32), paddingHorizontal: dm.moderate(16) }}
            />

            <RowTitleGroup hasDivider text={t('extension_margin_history')} />
            <Row style={{ marginTop: dimensions.vertical(8), paddingHorizontal: dm.moderate(16), justifyContent: 'space-between' }}>
                <TouchableOpacity
                    style={{
                        justifyContent: 'flex-start',
                        borderRadius: 8,
                        backgroundColor: styles.BUTTON__THIRD,
                        padding: dimensions.moderate(8),
                        flexDirection: 'row',
                        alignItems: 'center',
                    }}
                    onPress={() => setisDatePickerFrom(true)}
                >
                    <View style={{ marginRight: dimensions.moderate(20) }}>
                        <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.normal }}>
                            {t('common_from_date')}
                            {'  '}
                        </Text>
                        <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal }}>
                            {moment(defaultCondition.fromDt).format('DD/MM/YYYY')}
                        </Text>
                    </View>
                    <IconSvg.DateIcon color={styles.PRIMARY__CONTENT__COLOR} />
                </TouchableOpacity>
                <View style={{ width: dimensions.moderate(16) }} />
                <TouchableOpacity
                    style={{
                        justifyContent: 'flex-start',
                        borderRadius: 8,
                        backgroundColor: styles.BUTTON__THIRD,
                        padding: dimensions.moderate(8),
                        flexDirection: 'row',
                        alignItems: 'center',
                    }}
                    onPress={() => setisDatePickerTo(true)}
                >
                    <View style={{ marginRight: dimensions.moderate(20) }}>
                        <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.normal }}>
                            {t('common_to_date')}
                            {'  '}
                        </Text>
                        <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal }}>
                            {moment(defaultCondition.toDt).format('DD/MM/YYYY')}
                        </Text>
                    </View>
                    <IconSvg.DateIcon color={styles.PRIMARY__CONTENT__COLOR} />
                </TouchableOpacity>
            </Row>
            <HeaderList colSpan={colSpan} typeHeader="HISTORY_MARGIN_EXTENSION" />
            <FlatList
                data={listHistoryContractRenew}
                keyExtractor={(item, index) => String(index)}
                ListEmptyComponent={EmptyView}
                renderItem={ViewItemHistory}
                scrollEnabled={false}
                style={{ marginBottom: dm.vertical(32), paddingHorizontal: dm.moderate(16) }}
            />

            {isDatePickerFrom && (
                <DateTimePickerModal
                    cancelTextIOS={t('common_Cancel')}
                    confirmTextIOS={t('common_Ok')}
                    date={defaultCondition.fromDt}
                    headerTextIOS=""
                    isDarkModeEnabled={theme.includes('DARK')}
                    isVisible={isDatePickerFrom}
                    locale={language === 'VI' ? 'vi_VN' : 'en_US'}
                    mode="date"
                    onCancel={hideDatePicker}
                    onConfirm={(value) => {
                        setisDatePickerFrom(false)
                        setDefaultCondition((prev) => ({ ...prev, fromDt: value }))
                    }}
                />
            )}

            {isDatePickerTo && (
                <DateTimePickerModal
                    cancelTextIOS={t('common_Cancel')}
                    confirmTextIOS={t('common_Ok')}
                    date={defaultCondition.toDt}
                    headerTextIOS=""
                    isDarkModeEnabled={theme.includes('DARK')}
                    isVisible={isDatePickerTo}
                    locale={language === 'VI' ? 'vi_VN' : 'en_US'}
                    mode="date"
                    onCancel={hideDatePicker}
                    onConfirm={(value) => {
                        setisDatePickerTo(false)
                        setDefaultCondition((prev) => ({ ...prev, toDt: value }))
                    }}
                />
            )}
        </View>
    )
}

export default StepOne
