import React, { useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { StyleSheet, Switch, TouchableOpacity, View } from 'react-native'

import { Text } from '../../../basic-components'
import { CustomSwitch } from '../../../components/trading-component'
import { StoreContext } from '../../../store'
import { dimensions as dm, fontSizes as fs, fontWeights as fw, IconSvg } from '../../../styles'

interface IBrokerageServicesCheckRowProps {
    defaultCheckBrokerageServices: boolean
    setCheckBrokerageServices: (isAutoPIA: boolean) => void
}

export const BrokerageServicesCheckRow = ({ setCheckBrokerageServices = () => null, defaultCheckBrokerageServices }: IBrokerageServicesCheckRowProps) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()

    const [isCheckBrokerageServices, setIsCheckBrokerageServices] = useState(defaultCheckBrokerageServices || false)

    useEffect(() => {
        setCheckBrokerageServices(isCheckBrokerageServices)
    }, [isCheckBrokerageServices])

    const options = useRef([
        { label: t('even_lot'), value: false },
        { label: t('odd_lot'), value: true },
    ])

    return (
        <View style={UI.row}>
            <TouchableOpacity
                activeOpacity={0.9}
                style={{ flexDirection: 'row', alignItems: 'center', marginTop: dm.vertical(16), flex: 1, justifyContent: 'space-between' }}
                onPress={() => setIsCheckBrokerageServices((value) => !value)}
            >
                {/* <View style={{ paddingTop: 2 }}>
					<IconSvg.CheckboxIcon
						active={isCheckBrokerageServices}
						colorActive={styles.PRIMARY}
						colorunActive={styles.PRIMARY__CONTENT__COLOR}
					/>
				</View> */}
                <Text
                    style={{
                        fontSize: fs.small,
                        color: styles.PRIMARY__CONTENT__COLOR,
                        marginLeft: dm.moderate(8),
                        marginRight: 16,
                    }}
                >
                    {t<string>('brokerage_services')}
                </Text>
                <View>
                    {/* <Switch value={isCheckBrokerageServices} onChange={() => setIsCheckBrokerageServices(value => !value)} /> */}
                    <CustomSwitch
                        buttonPadding={3}
                        startOnLeft={isCheckBrokerageServices}
                        switchBackgroundColor={styles.SECOND__CONTENT__COLOR}
                        onSwitch={() => setIsCheckBrokerageServices(true)}
                        onSwitchBackgroundColor={styles.PRIMARY}
                        onSwitchReverse={() => setIsCheckBrokerageServices(false)}
                    />
                </View>
            </TouchableOpacity>
        </View>
    )
}

const UI = StyleSheet.create({
    row: {
        alignItems: 'center',
        borderRadius: 12,
        flexDirection: 'row',
        marginHorizontal: dm.moderate(16),
    },
})
