import React, { useContext } from 'react'
import { TFunction, useTranslation } from 'react-i18next'
import { ActivityIndicator, StyleSheet, Text, TouchableOpacity } from 'react-native'
import { fontSizes as fs } from '@mts-styles/index'
import { Col, Icon, Row } from 'native-base'

import { StoreContext } from '../../../../store'

const getStatusAndColor = ({
    cancelStatus,
    styles,
    t,
    customerSignStatus,
    rejectStatus,
}: {
    cancelStatus: 'Y' | 'N'
    styles: any
    t: TFunction
    customerSignStatus: 'Y' | 'N'
    rejectStatus: 'Y' | 'N'
}) => {
    const color = styles.WARN__COLOR
    const status = t('econtract_item_need_signed')
    if (rejectStatus === 'Y')
        return {
            color: styles.ERROR__COLOR,
            status: t('econtract_item_reject'),
        }
    if (cancelStatus === 'Y')
        return {
            color: styles.ERROR__COLOR,
            status: t('econtract_item_cancel'),
        }
    if (customerSignStatus === 'Y')
        return {
            color: styles.SUCCESS__COLOR,
            status: t('econtract_item_signed'),
        }
    return { color, status }
}

export const EContractItem = ({ item, onPressSign, onPressView, onPressDownload, colSpan, isDownloadFile }) => {
    const { c3: contractName, c4: customerSignStatus, c5: SSVSignStatus, c12: linkFilePDF, c14: cancelStatus, c15: rejectStatus } = item
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()

    const { status, color } = getStatusAndColor({ cancelStatus, styles, t, customerSignStatus, rejectStatus })

    const checkShowBtn = customerSignStatus === 'Y' || cancelStatus === 'Y'

    return (
        <Row style={[UI.container, { borderColor: styles.DIVIDER__COLOR, borderBottomWidth: 1, paddingBottom: 8, alignItems: 'center' }]}>
            <Col size={colSpan[0]} style={{ marginLeft: 8 }}>
                <Text style={[UI.textValue, { color: styles.SECOND__CONTENT__COLOR }]}>{contractName}</Text>
            </Col>
            <Col size={colSpan[1]} style={{ marginLeft: 8 }}>
                <Text style={[UI.textValue, { color: color }]}>{status}</Text>
            </Col>
            {rejectStatus === 'Y' || (SSVSignStatus === 'N' && customerSignStatus === 'Y') ? (
                <Col size={colSpan[2]} style={UI.RowAction} />
            ) : (
                <Col size={colSpan[2]} style={UI.RowAction}>
                    {linkFilePDF ? (
                        <TouchableOpacity style={[UI.btnDownloadFile, { backgroundColor: styles.PRIMARY }]} onPress={onPressDownload}>
                            {isDownloadFile ? (
                                <ActivityIndicator color={styles.SECOND__CONTENT__COLOR} />
                            ) : (
                                <Icon name="download" style={[UI.iconDownload, { color: styles.PRIMARY__CONTENT__COLOR }]} type="Feather" />
                            )}
                        </TouchableOpacity>
                    ) : null}
                    {checkShowBtn ? (
                        <TouchableOpacity style={[[UI.btn, { backgroundColor: styles.PRIMARY }]]} onPress={onPressView}>
                            <Text style={[UI.bthText, { color: styles.WHITE__COLOR }]}>{t<string>('econtract_view')}</Text>
                        </TouchableOpacity>
                    ) : (
                        <TouchableOpacity style={[[UI.btn, { backgroundColor: styles.PRIMARY }]]} onPress={onPressSign}>
                            <Text style={[UI.bthText, { color: styles.WHITE__COLOR }]}>{t<string>('econtract_sign')}</Text>
                        </TouchableOpacity>
                    )}
                </Col>
            )}
        </Row>
    )
}

const UI = StyleSheet.create({
    RowAction: { flexDirection: 'row', justifyContent: 'flex-end', marginLeft: 8 },
    bthText: { fontSize: fs.small },
    btn: {
        alignItems: 'flex-end',
        borderRadius: 8,
        height: 25,
        justifyContent: 'center',
        paddingHorizontal: 5,
    },
    btnDownloadFile: {
        alignItems: 'center',
        borderRadius: 5,
        height: 25,
        justifyContent: 'center',
        marginRight: 10,
        width: 25,
    },
    container: { flex: 1, flexDirection: 'row', marginTop: 10, paddingBottom: 12 },
    iconDownload: { fontSize: 15 },
    textValue: { fontSize: fs.small },
})
