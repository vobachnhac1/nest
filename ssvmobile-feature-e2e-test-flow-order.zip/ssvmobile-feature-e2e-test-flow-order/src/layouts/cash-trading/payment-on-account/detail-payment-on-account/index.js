import React, { useContext, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { InteractionManager } from 'react-native'
import Modal from 'react-native-modal'
import Svg, { Path } from 'react-native-svg'
import ToastGlobal from 'react-native-toast-message'
import moment from 'moment'
import { Container, Content } from 'native-base'

import HeaderComponent from '../../../../components/header'
import ModalLoading from '../../../../components/modal-loading'
import { ButtonCustom, ModalContent, RowData, RowDataModal } from '../../../../components/trading-component'
import { useAlertModal, useAlertModalCommonCode, useModalOtpWhenErr } from '../../../../hoc'
import { StoreContext } from '../../../../store'
import { FormatNumber, glb_sv, reqFunct, sendRequest } from '../../../../utils'

// Khai báo ServiceInfo (nếu có)
const ServiceInfo = {
    CANCEL_TRAN_MONEY: {
        reqFunct: reqFunct.CANCEL_TRAN_MONEY, // Hủy giao dịch thông báo nộp tiền
        WorkerName: 'FOSxCash',
        ServiceName: 'FOSxCash_0201_1',
        Operation: 'D',
        AprStat: 'D',
        AprSeq: '', //aprSeq,
        MakerDt: '', //aprDt,
    },
}

// Khai báo component
export default function DetailPaymentOnAccount({ navigation, route }) {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()
    const { params = {} } = route
    const { data = {}, onRefresh = () => null } = params
    const [isOpenModal, setIsOpenModal] = useState(false)
    const [loadingConfirm, setLoadingConfirm] = useState(false)

    // Start define all bussiness state
    // End define form bussiness state
    // -------------------------------------------   Dùng useEffect get các dữ liệu cần thiết còn thiếu

    // -------------------------------------------   Viết các hàm để set lại bussiness form state. Nên viết đúng một chuẩn duy nhất để dễ control

    // -------------------------------------------   Khai báo các hàm gửi (request) lên server
    const onCancelTranMoney = () => {
        InteractionManager.runAfterInteractions(() => {
            if (!glb_sv.checkOtp(navigation, () => setIsOpenModal(true))) return
            ServiceInfo.CANCEL_TRAN_MONEY.AprSeq = data.c26 || ''
            ServiceInfo.CANCEL_TRAN_MONEY.MakerDt = moment(data.c25, 'DDMMYYYY').format('YYYYMMDD') || ''

            const formatTimeTransfer = moment(data.c0, 'DDMMYYYY').format('YYYYMMDD')
            const inputParams = [formatTimeTransfer, data.c1]
            sendRequest(ServiceInfo.CANCEL_TRAN_MONEY, inputParams, handleOnCancelTranMoney)
            setLoadingConfirm(true)
        })
    }
    // -------------------------------------------   Khai báo các hàm gửi (request) và nhận (handle respone) dữ liệu từ server
    const handleOnCancelTranMoney = (reqInfoMap, message) => {
        setLoadingConfirm(false)
        // -- process after get result --
        if (Number(message.Result) === 0) {
            const { hasAlertCommonCode } = useAlertModalCommonCode(message, {})
            const { hasAlertErrOtp } = useModalOtpWhenErr(message, { continueVerify: !hasAlertCommonCode, callback: () => setIsOpenModal((prev) => true) })
            useAlertModal(message, { continueVerify: !hasAlertErrOtp })
        } else {
            ToastGlobal.show({
                type: 'success',
                text2: message.Message, //t('pass_confirm_not_correct'),
            })
            // _reloadDataListTransFer()
            onRefresh()
        }
    }
    const getColor = (status) => {
        if (status === 'N') return styles.REF__COLOR
        if (status === 'R' || status === 'D') return styles.DOWN__COLOR
        if (status === 'Y') return styles.UP__COLOR
    }

    return (
        <Container style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft
                navigation={navigation}
                title={t('sb_orderHis_dt_vise')}
                titleAlgin="flex-start"
                transparent
            />
            <Content>
                <RowData textLeft={t('working_date')} textRight={data.c0.trim() === '' ? '' : moment(data.c0, 'DDMMYYYY').format('DD/MM/YYYY')} />
                <RowData dataSub={[data.c2, data.c3]} textLeft={t('acnt_no')} textRight2={data.c4} />
                <RowData textLeft={t('amount_drawal')} textRight={FormatNumber(data.c11)} />
                <RowData last rightColor={getColor(data.c21)} textLeft={t('progress_status')} textRight={data.c27} />
                <ButtonCustom
                    text={t('common_Cancel')}
                    visible={data.c21 === 'N'} // Có thể hủy
                    onPress={() => setIsOpenModal(true)}
                />
            </Content>
            {/* Modal */}
            {isOpenModal && (
                <Modal
                    isVisible={isOpenModal}
                    useNativeDriver={true}
                    onBackButtonPress={() => setIsOpenModal(false)}
                    onBackdropPress={() => setIsOpenModal(false)}
                >
                    <ModalContent
                        iconComponent={
                            <Svg fill="none" height={48} viewBox="0 0 32 32" width={48} xmlns="http://www.w3.org/2000/svg">
                                <Path
                                    d="M7.148 12.624l2.237 17.007a1 1 0 00.992.869h11.246a1 1 0 00.991-.87l1.728-13.13.658-5H8.272l-1.124 1.124z"
                                    fill={styles.SELL__BG}
                                />
                                <Path
                                    d="M15 15.5v11a1 1 0 102 0v-11a1 1 0 10-2 0zM11 15.5v11a1 1 0 102 0v-11a1 1 0 10-2 0zM19 15.5v11a1 1 0 102 0v-11a1 1 0 10-2 0z"
                                    fill="#F2F8FF"
                                />
                                <Path
                                    d="M15 8.5l2 1h2.5l-1-2.5-2-.5-1.5 2zM24 5l-2.5.5v1l.5 2 4-.5-1.5-2-.5-1zM15.086 1.858a1 1 0 00-1.414 0L2.358 13.172a1 1 0 000 1.414L3.772 16 16.5 3.272l-1.414-1.414z"
                                    fill={styles.SELL__BG}
                                />
                                <Path
                                    d="M22.614 29.63l.196-1.486c-6.417-2.253-10.844-8.531-10.448-15.652l.054-.992H8.272l-1.124 1.124 2.237 17.007a1 1 0 00.992.869h11.246a1 1 0 00.991-.87z"
                                    fill="#303030"
                                    opacity={0.12}
                                />
                                <Path
                                    d="M13.515 4.486L2.886 15.114l.886.886L16.5 3.272l-1.414-1.414a1 1 0 00-1.414 0l-.157.157a1.747 1.747 0 010 2.47zM24.5 6L24 5l-.909.182.41.818L25 8l-3.031.379.03.121 4-.5-1.5-2zM17.5 7.5l.8 2h1.2l-1-2.5-2-.5-.474.631L17.5 7.5z"
                                    fill="#303030"
                                    opacity={0.12}
                                />
                                <Path
                                    d="M5.186 10.343l-1.06-1.06a1.502 1.502 0 010-2.122L7.66 3.625a1.501 1.501 0 012.122 0l1.06 1.061-.707.707-1.06-1.06a.501.501 0 00-.708 0L4.833 7.867a.501.501 0 000 .707l1.06 1.061-.707.707zM22 1h1v1h-1V1zM27.01 4.896l-.609-.792a5.83 5.83 0 014.697-1.095l-.196.981a4.836 4.836 0 00-3.891.906zM28.5 6h1v1h-1V6zM25 3.5h-1C24 2.122 25.122 1 26.5 1v1c-.827 0-1.5.673-1.5 1.5z"
                                    fill={styles.SELL__BG}
                                />
                            </Svg>
                        }
                        title={t('confirm_cancel')}
                        type="cancel"
                    >
                        <RowDataModal dataSub={[data.c16, data.c3]} textLeft={t('acnt_no')} textRight={data.c16} />
                        <RowDataModal textLeft={t('working_date')} textRight={moment(data.c0, 'DDMMYYYY').format('DD/MM/YYYY')} />
                        <RowDataModal last textLeft={t('transfer_amount')} textRight={FormatNumber(data.c11)} />
                        <ButtonCustom
                            text={t('common_button_confirm')}
                            type="confirm"
                            onPress={() => {
                                onCancelTranMoney()
                                setIsOpenModal(false)
                                navigation.goBack()
                            }}
                        />
                        <ButtonCustom last text={t('common_Cancel')} type="back" onPress={() => setIsOpenModal(false)} />
                    </ModalContent>
                </Modal>
            )}
            {loadingConfirm && <ModalLoading content={t('common_processing')} visible={loadingConfirm} />}
        </Container>
    )
}
