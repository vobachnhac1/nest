import React, { Component, ReactNode } from 'react'

import { PortalContext } from './portalContext'
import Toast, { ToastType } from './toast'

export class PortalProvider extends Component {
    state = {
        gates: {},
    }

    render() {
        return (
            <PortalContext.Provider
                value={{
                    gates: this.state.gates,
                    teleport: this.teleport,
                    showToast: this.showToast,
                }}
            >
                {this.props.children}
            </PortalContext.Provider>
        )
    }

    teleport = (gateName, element) => {
        this.setState((prevState) => ({
            gates: { ...prevState.gates, [gateName]: element },
        }))
    }

    showToast = (message = '...', color = 'blue') => {
        this.teleport('toaster', <Toast color={color}>{message}</Toast>)
    }
}
