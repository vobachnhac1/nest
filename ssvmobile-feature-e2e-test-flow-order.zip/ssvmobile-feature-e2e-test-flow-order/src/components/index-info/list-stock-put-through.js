import React, { memo, useCallback, useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { FlatList, StyleSheet, View } from 'react-native'
import moment from 'moment'

import { Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { dimensions, fontSizes, fontWeights } from '../../styles'
import { eventList, FormatNumber, glb_sv, subcribeFunctStream } from '../../utils'

function getColor(value, obj, styles) {
    if (value === 777777710000 || value === 777777720000) return styles.PRIMARY__CONTENT__COLOR
    if (value > 0 && value > obj.FL && value < obj.RF) return styles.DOWN__COLOR
    else if (value > 0 && value < obj.CE && value > obj.RF) return styles.UP__COLOR
    else if (value === obj.RF) return styles.REF__COLOR
    else if (value >= obj.CE) return styles.CEIL__COLOR
    else if (value <= obj.FL) return styles.FLOOR__COLOR
}

const StockItem = memo(({ item, styles, onChangeStkInfo }) => {
    return (
        <View style={[UI.HeaderTop_view, { borderBottomColor: styles.DIVIDER__COLOR }]} onPress={() => onChangeStkInfo(item)}>
            <View style={{ flex: 1 }}>
                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.smallest, fontWeight: fontWeights.medium }}>{item.S}</Text>
            </View>
            <View style={{ flex: 1, paddingLeft: 3 }}>
                <Text style={{ color: getColor(item.MP, item, styles), fontSize: fontSizes.verySmall, fontWeight: fontWeights.medium, textAlign: 'right' }}>
                    {FormatNumber(item.MP)}
                </Text>
            </View>
            <View style={{ flex: 1, paddingLeft: 3 }}>
                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.verySmall, fontWeight: fontWeights.medium, textAlign: 'right' }}>
                    {FormatNumber(item.PVOL, 0, 1)}
                </Text>
            </View>
            <View style={{ flex: 1, paddingLeft: 3 }}>
                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.verySmall, fontWeight: fontWeights.medium, textAlign: 'right' }}>
                    {FormatNumber(item.PVAL, 0, 1, 'short')}
                </Text>
            </View>
            <View style={{ flex: 1, paddingLeft: 3 }}>
                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.verySmall, fontWeight: fontWeights.medium, textAlign: 'right' }}>
                    {FormatNumber(item.PTVAL, 0, 1, 'short')}
                </Text>
            </View>
            <View style={{ flex: 1, paddingLeft: 3 }}>
                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.verySmall, fontWeight: fontWeights.medium, textAlign: 'right' }}>
                    {moment(item.T, 'YYYYMMDD-HH:mm:ss').format('HH:mm:ss')}
                </Text>
            </View>
        </View>
    )
}, compareStockItem)

function compareStockItem(prev, next) {
    if (
        prev.item.t31 === next.item.t31 &&
        prev.item.t137 === next.item.t137 &&
        prev.item.t391 === next.item.t391 &&
        prev.item.t31_incr_per === next.item.t31_incr_per
    )
        return true
    return false
}

function getExchange(code) {
    if (code === 'HSXIndex') return 'HSX'
    if (code === 'HNXIndex') return 'HNX'
    return 'UPC'
}

function sortTime(a, b) {
    if (a.T > b.T) return -1
    if (a.T < b.T) return 1
    return 0
}

function ListStockPT({ indexCode, onChangeStkInfo, maxList, type }) {
    const { styles } = useContext(StoreContext)
    const [list, setList] = useState([])
    const { t } = useTranslation()

    useEffect(() => {
        subcribeFunctStream('SUB', ['PT_BOARD'], [getExchange(indexCode)])
        const eventMarket = glb_sv.eventMarket.subscribe((msg) => {
            if (msg.type === eventList.MKT_PT) {
                setList(msg.data)
            }
        })
        return () => {
            eventMarket.unsubscribe()
        }
    }, [])

    const renderHeader = useCallback(() => {
        return <HeaderTopPT styles={styles} t={t} />
    }, [])

    const RenderItem = useCallback(({ item }) => {
        return <StockItem item={item} styles={styles} onChangeStkInfo={onChangeStkInfo} />
    })

    return (
        <FlatList
            data={list.sort(sortTime)}
            keyExtractor={(item) => item.S}
            ListEmptyComponent={
                <View style={{ height: 200, justifyContent: 'center', alignItems: 'center' }}>
                    <Text style={{ color: styles.SECOND__CONTENT__COLOR }}>{t('common_NoDataFound')}</Text>
                </View>
            }
            ListHeaderComponent={renderHeader}
            renderItem={RenderItem}
            scrollEnabled={false}
            style={{ paddingHorizontal: dimensions.moderate(8), backgroundColor: styles.PRIMARY__BG__COLOR, paddingTop: dimensions.vertical(5) }}
        />
    )
}

const UI = StyleSheet.create({
    HeaderTop_view: {
        borderBottomWidth: 1,
        flexDirection: 'row',
        paddingVertical: dimensions.vertical(16),
    },
})

const HeaderTopPT = memo(
    ({ styles, t }) => {
        return (
            <View style={[UI.HeaderTop_view, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                <View style={{ flex: 1 }}>
                    <Text style={{ color: styles.HEADER__CONTENT__COLOR, fontSize: fontSizes.tiny, fontWeight: fontWeights.medium }}>
                        {t('stock_symbol_short')}
                    </Text>
                </View>
                <View style={{ flex: 1, paddingLeft: 3 }}>
                    <Text style={{ color: styles.HEADER__CONTENT__COLOR, fontSize: fontSizes.tiny, fontWeight: fontWeights.medium, textAlign: 'right' }}>
                        {t('price')}
                    </Text>
                </View>
                <View style={{ flex: 1, paddingLeft: 3 }}>
                    <Text style={{ color: styles.HEADER__CONTENT__COLOR, fontSize: fontSizes.tiny, fontWeight: fontWeights.medium, textAlign: 'right' }}>
                        {t('priceboard_qty')}
                    </Text>
                </View>
                <View style={{ flex: 1, paddingLeft: 3 }}>
                    <Text style={{ color: styles.HEADER__CONTENT__COLOR, fontSize: fontSizes.tiny, fontWeight: fontWeights.medium, textAlign: 'right' }}>
                        {t('value')}
                    </Text>
                </View>
                <View style={{ flex: 1, paddingLeft: 3 }}>
                    <Text style={{ color: styles.HEADER__CONTENT__COLOR, fontSize: fontSizes.tiny, fontWeight: fontWeights.medium, textAlign: 'right' }}>
                        {t('cumulative_value_short')}
                    </Text>
                </View>
                <View style={{ flex: 1, paddingLeft: 3 }}>
                    <Text style={{ color: styles.HEADER__CONTENT__COLOR, fontSize: fontSizes.tiny, fontWeight: fontWeights.medium, textAlign: 'right' }}>
                        {t('time')}
                    </Text>
                </View>
            </View>
        )
    },
    () => true,
)

export default memo(ListStockPT, () => true)
