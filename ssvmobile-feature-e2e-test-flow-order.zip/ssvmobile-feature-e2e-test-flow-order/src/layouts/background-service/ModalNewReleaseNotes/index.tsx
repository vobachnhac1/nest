import React, { useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { View } from 'react-native'
import Modal from 'react-native-modal'
import Svg, { Defs, G, LinearGradient, Path, Stop } from 'react-native-svg'
import { ButtonCustom, ModalByView, ModalContent } from '@mts-components/trading-component'
import useSafeModalState from '@mts-hooks/useSafeModalState'
import { dimensions as dm, fontSizes as fs } from '@mts-styles/index'
import { eventList, glb_sv, STORE_KEY } from '@mts-utils/index'
import SyncStorage from 'sync-storage'

import release_notes_081 from '../../../assets/release_notes/081_release_notes.json'
import { Text } from '../../../basic-components'
import { GLOBAL_MODAL_KEY } from '../../../hoc/useSafeModalState/index'
import { StoreContext } from '../../../store'
import { StoreTrading } from '../../../store-trading'

const RELEASE_NOTES = {
    default: release_notes_081,
    '081': release_notes_081,
}

const ModalNewReleaseNotes = () => {
    const { styles, language, activeCode } = useContext(StoreContext)
    const { userInfo } = useContext(StoreTrading)
    const { t } = useTranslation()
    // All orther state
    const [isOpenModal, setIsOpenModal] = useSafeModalState(GLOBAL_MODAL_KEY.ModalNewReleaseNotes)
    const [releaseNotesInfo, setReleaseNotesInfo] = useState(RELEASE_NOTES[activeCode] || RELEASE_NOTES.default || [])
    const onConfirmViewReleaseNotesRef = useRef(() => null)

    useEffect(() => {
        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.OPEN_NEW_RELEASE_NOTES_INFO_MODAL) {
                const currentVersionID = glb_sv.buildNumber
                const lastVersionID = SyncStorage.get(STORE_KEY.VERSION_ID)
                if (typeof msg.onConfirmViewReleaseNotes === 'function') {
                    onConfirmViewReleaseNotesRef.current = msg.onConfirmViewReleaseNotes
                }
                if (currentVersionID !== lastVersionID && releaseNotesInfo[language?.toLocaleLowerCase()]?.length !== 0) {
                    setIsOpenModal(true)
                } else {
                    onConfirmViewReleaseNotesRef.current()
                }
            }
        })
        return () => {
            commonEvent.unsubscribe()
        }
    }, [])

    const hideModal = () => {
        setIsOpenModal(false)
        SyncStorage.set(STORE_KEY.VERSION_ID, glb_sv.buildNumber)
        onConfirmViewReleaseNotesRef.current()
    }
    const getReleaseNotesListByLang = () => {
        return releaseNotesInfo[language?.toLocaleLowerCase()] || releaseNotesInfo.en || []
    }

    if (!isOpenModal) return null

    return (
        <ModalByView isVisible={isOpenModal} useNativeDriver={true} onBackButtonPress={hideModal} onBackdropPress={hideModal}>
            <ModalContent title={t('title_new_updates')} type="confirm">
                <View style={{ justifyContent: 'center', alignItems: 'center', flexDirection: 'row' }}>
                    <IconListNewFeature />
                </View>
                {getReleaseNotesListByLang().map((note, index) => {
                    return (
                        <View key={String(index)} style={{ flexDirection: 'row', paddingHorizontal: dm.moderate(16), paddingTop: dm.vertical(16) }}>
                            <View style={{ alignItems: 'center', flex: 1 }}>
                                <Svg height={22} viewBox="0 0 48 48" width={22}>
                                    <Defs>
                                        {/* @ts-expect-error */}
                                        <LinearGradient gradientUnits="userSpaceOnUse" id="prefix__a" x1={24.175} x2={24.175} y1={10.204} y2={39}>
                                            <Stop offset={0.278} stopColor="#65e04d" />
                                            <Stop offset={0.458} stopColor="#5cd740" />
                                            <Stop offset={0.79} stopColor="#44c11d" />
                                            <Stop offset={1} stopColor="#33b004" />
                                        </LinearGradient>
                                    </Defs>
                                    <Path
                                        d="M21 39a3.952 3.952 0 01-2.535-.906L4.838 26.376a1.509 1.509 0 01-.183-2.087l3.164-3.873a1.5 1.5 0 012.145-.185L20.6 29.465l17.1-18.771a1.5 1.5 0 012.109-.11l3.728 3.346a1.5 1.5 0 01.11 2.124L23.98 37.673A4.038 4.038 0 0121 39z"
                                        data-name="check cross mark"
                                        fill="url(#prefix__a)"
                                    />
                                </Svg>
                            </View>
                            <View style={{ flex: 5, justifyContent: 'center' }}>
                                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fs.small }}>{note}</Text>
                            </View>
                        </View>
                    )
                })}

                <ButtonCustom text={t('common_Ok')} type="confirm" onPress={hideModal} />
                <View style={{ height: 8 }} />
            </ModalContent>
        </ModalByView>
    )
}

export default ModalNewReleaseNotes

const IconListNewFeature = () => {
    return (
        <Svg height={64} viewBox="0 0 40 40" width={64}>
            <Path d="M1.5 35.5V8.55h37v20.189L28.843 35.5z" fill="#fff" />
            <Path d="M38 9.05v19.429L28.685 35H2V9.05h36m1-1H1V36h28l10-7V8.05z" fill="#788b9c" />
            <Path d="M1.5 8.5v-2c0-1.103.897-2 2-2h33c1.103 0 2 .897 2 2v2h-37z" fill="#c8d1db" />
            <Path d="M36.5 5c.827 0 1.5.673 1.5 1.5V8H2V6.5C2 5.673 2.673 5 3.5 5h33m0-1h-33A2.5 2.5 0 001 6.5V9h38V6.5A2.5 2.5 0 0036.5 4z" fill="#66798f" />
            <Path d="M7 16.5h3m3 0h20m-26 4h3m3 0h20m-26 4h3m-3 4h3" fill="none" stroke="#788b9c" strokeMiterlimit={10} />
            <Path d="M21.318 28H13v1h8.807zm3.425-4H13v1h11.568z" fill="#788b9c" />
            <Path d="M22.91 35H28v1h-4.708zM38 30.425l1-1.647v-2.88l-1-.558z" fill="#d6e3ed" />
            <Path
                d="M29.045 37.318l-2.828.401-.493-2.814-2.525-1.339L24.454 31l-1.255-2.566 2.525-1.339.493-2.814 2.828.401 2.053-1.987 2.053 1.987 2.828-.401.494 2.814 2.523 1.339L37.741 31l1.255 2.566-2.523 1.339-.494 2.814-2.828-.401-2.053 1.987z"
                fill="#ffeea3"
            />
            <Path
                d="M31.098 23.391l1.53 1.48.351.34.484-.068 2.107-.298.368 2.096.084.482.432.229 1.88.997-.935 1.912-.214.439.215.439.935 1.912-1.88.997-.432.229-.084.482-.368 2.096-2.107-.298-.484-.068-.351.34-1.53 1.48-1.53-1.48-.351-.34-.484.068-2.107.298-.368-2.096-.084-.481-.432-.229-1.88-.997.935-1.912.213-.44-.215-.439-.935-1.912 1.88-.997.432-.229.084-.481.368-2.096 2.107.298.484.068.351-.34 1.531-1.481m0-1.391l-2.225 2.152-3.065-.434-.535 3.049-2.735 1.451L23.898 31l-1.359 2.781 2.735 1.451.535 3.049 3.065-.434L31.098 40l2.225-2.152 3.065.434.535-3.049 2.735-1.451L38.298 31l1.359-2.781-2.735-1.451-.535-3.049-3.065.434L31.098 22z"
                fill="#ba9b48"
            />
        </Svg>
    )
}
