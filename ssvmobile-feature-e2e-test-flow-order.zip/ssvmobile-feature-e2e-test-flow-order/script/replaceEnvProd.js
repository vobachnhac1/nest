const { replaceEnvFile, replaceFolder, replaceImge } = require('./replaceEnvFile')

replaceEnvFile('.env.prod', '.env')

replaceEnvFile('fastlane/.env.prod', 'fastlane/.env')

replaceEnvFile('android/app/google-services-prod.json', 'android/app/google-services.json')

replaceEnvFile('ios/SSVMobile/GoogleService-Info-prod.plist', 'ios/SSVMobile/GoogleService-Info.plist')
replaceEnvFile('ios/SSVMobile/Info-prod.plist', 'ios/SSVMobile/Info.plist')

replaceFolder('ios/SSVMobile/Images.xcassets/AppIconProd.appiconset', 'ios/SSVMobile/Images.xcassets/AppIcon.appiconset')

replaceImge('android/app/src/main/res/drawable/ic_launcher_prod.png', 'android/app/src/main/res/drawable/ic_launcher.png')

console.log('replace production env success')
