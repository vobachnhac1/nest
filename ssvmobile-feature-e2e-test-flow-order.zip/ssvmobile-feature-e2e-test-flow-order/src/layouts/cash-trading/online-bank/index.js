import React, { useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { FlatList, Pressable, RefreshControl, StyleSheet, View } from 'react-native'
import Modal from 'react-native-modal'
import Svg, { Path } from 'react-native-svg'
import ToastGlobal from 'react-native-toast-message'
import moment from 'moment'
import { Container, Content, Row } from 'native-base'

import IconBack from '../../../assets/images/common/ic_arrow_right.svg'
import { CustomFloatInput } from '../../../basic-components'
import Account from '../../../components/account'
import HeaderComponent from '../../../components/header'
import ModalLoading from '../../../components/modal-loading'
import {
    ButtonCustom,
    ColTableData,
    EmptyView,
    HeaderList,
    ModalBottomContent,
    ModalBottomRowSelect,
    ModalContent,
    RowData,
    RowDataModal,
    RowTableData,
    RowTitleGroup,
} from '../../../components/trading-component'
import { useAlertModal, useAlertModalCommonCode, useModalOtpWhenErr, useUpdateEffect } from '../../../hoc'
import { StoreContext } from '../../../store'
import { StoreTrading } from '../../../store-trading'
import { dimensions as dm, fontSizes as fs, fontWeights as fw } from '../../../styles'
import { eventList, FormatNumber, glb_sv, reqFunct, Screens, sendRequest, wait } from '../../../utils'

// Khai báo ServiceInfo (nếu có)
const ServiceInfo = {
    GET_CURRENT_CASH_COM_STOCK: {
        reqFunct: reqFunct.GET_CURRENT_CASH_COM_STOCK,
        WorkerName: 'FOSqCashBIDV',
        ServiceName: 'FOSqCash_0201_6',
        Operation: 'Q',
    },
    GET_BANK_LINKED_ACCOUNT_LIST: {
        reqFunct: reqFunct.GET_BANK_LINKED_ACCOUNT_LIST,
        WorkerName: 'FOSqAccount',
        ServiceName: 'FOSqAccount_Common',
        Operation: 'Q',
    },
    GET_MONEY_IN_BANK: {
        reqFunct: reqFunct.GET_MONEY_IN_BANK,
        WorkerName: 'FOSqCashBIDV',
        ServiceName: 'FOSqCash_0201_6',
        Operation: 'Q',
    },
    GET_HISTORY_ONLINE_BANKING: {
        reqFunct: reqFunct.GET_HISTORY_ONLINE_BANKING,
        WorkerName: 'FOSqCashBIDV',
        ServiceName: 'FOSqCash_0201_6',
        Operation: 'Q',
    },
    SEND_CONFIRM: {
        reqFunct: reqFunct.SEND_CONFIRM,
        WorkerName: 'FOSxCashBIDV',
        ServiceName: 'FOSxCash_0201_6',
        Operation: 'Q',
    },
}

const TypeTransaction = [
    {
        index: 0,
        value: '1',
        label: 'deposit_to_stock_account',
    },
    {
        index: 1,
        value: '2',
        label: 'deposit_withdraw_with_bank_account',
    },
]

const initErrCtrl = [
    {
        error: false,
        message: 'connect_acc_warning',
    },
    {
        error: false,
        message: 'warning_cash_input',
    },
]

// Khai báo component
const OnlineBank = ({ navigation }) => {
    const { styles } = useContext(StoreContext)
    const { userInfo } = useContext(StoreTrading)

    const { t } = useTranslation()
    // All orther state
    const [activeStep, setActiveStep] = useState(0)
    const [isOpenModal, setIsOpenModal] = useState(false)
    const [refreshing, setRefreshing] = React.useState(false)

    // Start define all bussiness state

    const [amountTransaction, setAmountTransaction] = useState('')

    const [currentCashComStk, setCurrentCashComStock] = useState({})

    // const [dropSelect, setDropSelect] = useState(false)

    const [isOpenModalSelection, setIsOpenModalSelection] = useState(false)
    const [visibleTypeTranstation, setVisibleTypeTranstation] = useState(false)
    const [typeTransactionSelect, setTypeTransactionSelect] = useState(TypeTransaction[0])
    const [listLinkAcntBank, setListLinkAcntBank] = useState([])
    const [acntSelect, setAcntSelect] = useState({})
    const [errCtrl, setErrCtrl] = useState(initErrCtrl)
    const [listHistoryTransaction, setListHistoryTransaction] = useState([])
    const [bankCashInfo, setBankCashInfo] = useState({})
    const [loadingConfirm, setLoadingConfirm] = useState(false)

    useUpdateEffect(() => _validateValue(0), [acntSelect])
    useUpdateEffect(() => _validateValue(1), [amountTransaction])

    // End define form bussiness state
    // -------------------------------------------   Dùng useEffect get các dữ liệu cần thiết còn thiếu
    useEffect(() => {
        // Prepare data
        getCurrentCashComStock()
        getBankLinkAcntList()
        getHistoryOnlineBanking()

        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.LOGIN_SUCCESS) {
                // reCall service FOSq
                getCurrentCashComStock()
                getBankLinkAcntList()
                getHistoryOnlineBanking()
            }
        })

        return () => {
            commonEvent.unsubscribe()
        }
    }, [userInfo.sub_curr])

    useEffect(() => {
        getMoneyInBank()
    }, [acntSelect])
    // -------------------------------------------   Viết các hàm để set lại bussiness form state. Nên viết đúng một chuẩn duy nhất để dễ control
    const onRefresh = React.useCallback(() => {
        setRefreshing(true)
        getBankLinkAcntList()
        getCurrentCashComStock()
        wait(300).then(() => setRefreshing(false))
    }, [])

    const switchStep = {
        goTo: (step) => setActiveStep(step),
        next: () => setActiveStep(activeStep + 1),
        prev: () => setActiveStep(activeStep - 1),
        submit: () => confirmTranferCash(),
        onFinish: () => _checkValueBfSend(),
        getCurrent: () => {
            return activeStep
        },
    }

    const hideModal = () => {
        setIsOpenModal(false)
    }

    const _onClickBackButton = () => {
        if (activeStep > 0) switchStep.prev()
        if (activeStep === 0) navigation.goBack()
    }

    const _checkValueBfSend = () => {
        _validateValue()
        if (errCtrl.filter((item) => item.error === true).length === 0) {
            //----------------
            const isAuthenOTP = glb_sv.checkOtp(navigation, () => {
                setTimeout(() => {
                    setIsOpenModal((prev) => true)
                }, 100)
            })
            if (isAuthenOTP) {
                setIsOpenModal(true)
            }
            //---------------
        }
        return
    }

    const _validateValue = (inputIndex) => {
        const newErrCtrl = [...initErrCtrl]

        if (inputIndex === 0) newErrCtrl[0].error = !acntSelect.value
        if (inputIndex === 1) newErrCtrl[1].error = Number(amountTransaction) <= 0 || !amountTransaction
        if (!inputIndex && inputIndex !== 0) {
            newErrCtrl[0].error = !acntSelect?.value
            newErrCtrl[1].error = Number(amountTransaction) <= 0
        }
        setErrCtrl(newErrCtrl)
    }

    // -------------------------------------------   Khai báo các hàm gửi (request) lên server
    const getCurrentCashComStock = () => {
        setCurrentCashComStock({})
        const inputParams = ['1', userInfo.actn_curr, userInfo.sub_curr]
        sendRequest(ServiceInfo.GET_CURRENT_CASH_COM_STOCK, inputParams, handleCurrentCashComStock)
    }

    const getBankLinkAcntList = () => {
        setListLinkAcntBank([])
        setAcntSelect({})
        const inputParams = ['09', userInfo.actn_curr, userInfo.sub_curr]
        sendRequest(ServiceInfo.GET_BANK_LINKED_ACCOUNT_LIST, inputParams, handleBankLinkAcntList)
    }

    const getMoneyInBank = () => {
        setBankCashInfo({})
        const bankAcnt = acntSelect?.data?.c0
        if (bankAcnt === null || bankAcnt === undefined) {
            return
        }
        const inputParams = ['3', userInfo.actn_curr, userInfo.sub_curr, bankAcnt]
        sendRequest(ServiceInfo.GET_MONEY_IN_BANK, inputParams, handleMoneyInBank)
    }

    const getHistoryOnlineBanking = () => {
        setListHistoryTransaction([])
        const inputParams = ['2', userInfo.actn_curr, userInfo.sub_curr]
        sendRequest(ServiceInfo.GET_HISTORY_ONLINE_BANKING, inputParams, handleHistoryOnlineBanking)
    }

    const confirmTranferCash = () => {
        if (typeTransactionSelect.value === '1') {
            ServiceInfo.SEND_CONFIRM.Operation = 'I'
        } else {
            ServiceInfo.SEND_CONFIRM.Operation = 'U'
        }
        const bankAcnt = acntSelect?.data || {}
        const inputParams = [userInfo.actn_curr, userInfo.sub_curr, bankAcnt.c2, bankAcnt.c0, String(amountTransaction), '', '']
        sendRequest(ServiceInfo.SEND_CONFIRM, inputParams, handleConfirmTransfrer)
        setLoadingConfirm(true)
    }

    // -------------------------------------------   Khai báo các hàm gửi (request) và nhận (handle respone) dữ liệu từ server
    const handleCurrentCashComStock = (reqInfoMap, message) => {
        // console.log('handleCurrentCashComStock', reqInfoMap, message);
        // -- process after get result --
        if (Number(message.Result) === 0) {
            ToastGlobal.show({
                type: 'warning',
                text2: message.Message,
            })
            return
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {}
            setCurrentCashComStock(jsondata[0])
        }
    }

    const handleMoneyInBank = (reqInfoMap, message) => {
        // console.log('handleMoneyInBank', reqInfoMap, message);
        if (Number(message.Result) === 0) {
            ToastGlobal.show({
                type: 'warning',
                text2: message.Message,
            })
            return
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {}
            setBankCashInfo(jsondata[0])
        }
    }

    const handleBankLinkAcntList = (reqInfoMap, message) => {
        // console.log('handleBankLinkAcntList', reqInfoMap, message);
        if (Number(message.Result) === 0) {
            ToastGlobal.show({
                type: 'warning',
                text2: message.Message,
            })
            return
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {}
            const linkActBankConvert = jsondata.map((actInfo, index) => ({ index, value: actInfo.c0 + actInfo.c2, label: actInfo.c4, data: actInfo }))
            setListLinkAcntBank(linkActBankConvert)
            if (linkActBankConvert.length === 1) setAcntSelect(linkActBankConvert[0])
        }
    }

    const handleHistoryOnlineBanking = (reqInfoMap, message) => {
        // console.log('handleHistoryOnlineBanking', reqInfoMap, message);
        if (Number(message.Result) === 0) {
            ToastGlobal.show({
                type: 'warning',
                text2: message.Message,
            })
            return
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {}
            setListHistoryTransaction(jsondata)
        }
    }
    const handleConfirmTransfrer = (reqInfoMap, message) => {
        // console.log('handleConfirmTransfrer', reqInfoMap, message)
        hideModal()
        setLoadingConfirm(false)
        if (Number(message.Result) === 0) {
            const { hasAlertCommonCode } = useAlertModalCommonCode(message, {})
            const { hasAlertErrOtp } = useModalOtpWhenErr(message, { continueVerify: !hasAlertCommonCode, callback: () => setIsOpenModal((prev) => true) })
            useAlertModal(message, { continueVerify: !hasAlertErrOtp })
            return
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {}
            getCurrentCashComStock()
            getHistoryOnlineBanking()
            ToastGlobal.show({
                type: 'success',
                text2: message.Message,
            })
        }
    }

    const onPressAmountTrans = (amount) => {
        setAmountTransaction(amount)
    }

    const getColor = (status) => {
        if (status === 'N') return styles.REF__COLOR
        if (status === 'R' || status === 'D') return styles.DOWN__COLOR
        if (status === 'Y') return styles.UP__COLOR
    }
    const historyTransaction = ({ item, index }) => {
        return (
            <RowTableData
                key={String(index)}
                onPress={() =>
                    navigation.navigate(Screens.DETAIL_ONLINE_BANKING, {
                        data: item,
                    })
                }
            >
                <ColTableData colSpan={4} text={item.c2} text2={FormatNumber(item.c8)} />
                <ColTableData colSpan={2} text={moment(item.c0, 'DDMMYYYY').format('DD/MM/YYYY')} textAlign="right" />
                <ColTableData colorText={getColor(item.c15)} colSpan={2} text={t(item.c20)} textAlign="right" />
            </RowTableData>
        )
    }

    const onSelectTypeTransaction = (item) => {
        setTypeTransactionSelect(item)
        setVisibleTypeTranstation(false)
    }

    const onSelectAcntLinkBank = (item) => {
        setAcntSelect(item)
        setIsOpenModalSelection(false)
    }

    return (
        <Container>
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft
                leftButtonLink={_onClickBackButton}
                navigation={navigation}
                title={t('bank_online')}
                titleAlgin="flex-start"
                transparent
            />
            <Content
                refreshControl={
                    <RefreshControl
                        refreshing={refreshing}
                        onRefresh={onRefresh} // title={t('pull_refresh')}
                        // titleColor={styles.PRIMARY__CONTENT__COLOR}
                        tintColor={styles.PRIMARY__CONTENT__COLOR}
                    />
                }
                style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}
            >
                <Account navigation={navigation} />
                <View>
                    <View style={[UI.GroupInput, { borderColor: styles.PRIMARY__BORDER__COLOR }]}>
                        <Pressable
                            onPress={() => {
                                setIsOpenModalSelection(true)
                            }}
                        >
                            <View pointerEvents="none" style={UI.RowInput}>
                                <CustomFloatInput
                                    animationDuration={300}
                                    editable={false}
                                    errCtrl={t(errCtrl[0])}
                                    label={t('connect_acc')}
                                    rightComponent={<IconBack style={{ color: styles.ICON__PRIMARY, marginVertical: 20, marginRight: 8 }} />}
                                    value={acntSelect?.label}
                                />
                            </View>
                        </Pressable>
                    </View>
                    <View style={[UI.GroupInput, { borderColor: styles.PRIMARY__BORDER__COLOR }]}>
                        <Pressable
                            onPress={() => {
                                console.log('Hello')
                                setVisibleTypeTranstation(true)
                            }}
                        >
                            <View pointerEvents="none" style={{ ...UI.RowInput, position: 'relative' }}>
                                <CustomFloatInput
                                    editable={false}
                                    label={t('transaction_type')}
                                    rightComponent={<IconBack style={{ color: styles.ICON__PRIMARY, marginVertical: 20, marginRight: 8 }} />}
                                    staticLabel
                                    value={t(typeTransactionSelect.label)}
                                />
                            </View>
                        </Pressable>
                    </View>

                    <View style={{ flex: 1, marginRight: dm.halfIndent, position: 'relative' }}>
                        {/* {
                                dropSelect && <View style={{
                                    width: '96%', height: 100, marginHorizontal: dm.indent, backgroundColor: styles.SECOND__BG__COLOR, position: 'absolute', bottom: 0, top: 0, borderRadius: 8, zIndex: 999, shadowColor: "blue", elevation: 5,
                                    shadowOffset: {
                                        width: 0,
                                        height: 2,
                                    },
                                    shadowOpacity: 0.25,
                                    shadowRadius: 3.84,
                                }}
                                >
                                    <RadioButton.Group onValueChange={newValue => { setValue(newValue); setDropSelect(!dropSelect) }} value={value}>
                                        {
                                            TypeTransaction.map(item => (
                                                <View style={{ flex: 1, flexDirection: 'row', alignSelf: 'flex-start', alignItems: 'center' }}>
                                                    <RadioButton value={item.value} />
                                                    <Text onPress={() => { setValue(item.value); setDropSelect(!dropSelect) }} style={{ color: styles.PRIMARY__CONTENT__COLOR }}>{item.label}</Text>
                                                </View>
                                            ))
                                        }
                                    </RadioButton.Group>
                                </View>
                            } */}
                        <RowTitleGroup hasDivider text={t('bank_acc')} />

                        <RowData textLeft={t('current_money_amount')} textRight={FormatNumber(bankCashInfo.c0, 0, 0)} />

                        <RowData last textLeft={t('cash_available')} textRight={FormatNumber(bankCashInfo.c1, 0, 0)} />

                        <RowTitleGroup hasDivider text={t('securities_company')} />

                        <RowData textLeft={t('current_money_amount')} textRight={FormatNumber(currentCashComStk.c3)} />

                        <RowData last textLeft={t('cash_available')} textRight={FormatNumber(currentCashComStk.c4)} />

                        <View style={UI.RowInput}>
                            <CustomFloatInput
                                animationDuration={100}
                                errCtrl={t(errCtrl[1])}
                                keyboardType="number-pad"
                                label={t('transc_amount_cash')}
                                placeholderTextColor={styles.PLACEHODLER__COLOR}
                                value={FormatNumber(amountTransaction) === '0' ? '' : FormatNumber(amountTransaction)}
                                onChangeText={(amount) => onPressAmountTrans(glb_sv.filterNumber(amount))}
                            />
                        </View>

                        <ButtonCustom text={t('common_confirm')} type="confirm" onPress={() => switchStep.onFinish()} />
                    </View>
                </View>
                <RowTitleGroup hasDivider text={t('hitory_transaction')} />
                <HeaderList colSpan={[4, 2, 2]} typeHeader="HIS_ONLINE_BANK" />
                <Row>
                    <FlatList
                        data={listHistoryTransaction}
                        keyExtractor={(item, index) => index.toString()}
                        ListEmptyComponent={EmptyView}
                        renderItem={historyTransaction}
                        style={{
                            marginBottom: dm.vertical(32),
                            paddingHorizontal: dm.moderate(16),
                        }}
                    />
                </Row>
            </Content>
            {/* **************************************** Modal submit ******************************************/}
            {visibleTypeTranstation && (
                <Modal
                    hideModalContentWhileAnimating={true}
                    isVisible={visibleTypeTranstation}
                    style={UI.bottomModal}
                    useNativeDriver={true}
                    onBackButtonPress={() => setVisibleTypeTranstation(false)}
                    onBackdropPress={() => setVisibleTypeTranstation(false)}
                >
                    <ModalBottomContent title={t('transaction_type')}>
                        {TypeTransaction.map((item, index) => (
                            <ModalBottomRowSelect
                                checked={typeTransactionSelect.value === item.value}
                                key={index}
                                text={t(item.label)}
                                onPress={() => onSelectTypeTransaction(item)}
                            />
                        ))}
                    </ModalBottomContent>
                </Modal>
            )}

            {isOpenModalSelection && (
                <Modal
                    hideModalContentWhileAnimating={true}
                    isVisible={isOpenModalSelection}
                    style={UI.bottomModal}
                    useNativeDriver={true}
                    onBackButtonPress={() => setIsOpenModalSelection(false)}
                    onBackdropPress={() => setIsOpenModalSelection(false)}
                >
                    <ModalBottomContent title={t('connect_acc')}>
                        {listLinkAcntBank.map((item, index) => (
                            <ModalBottomRowSelect
                                checked={acntSelect.value === item.value}
                                key={index}
                                text={t(item.label)}
                                onPress={() => onSelectAcntLinkBank(item)}
                            />
                        ))}
                    </ModalBottomContent>
                </Modal>
            )}

            {isOpenModal && (
                <Modal isVisible={isOpenModal} useNativeDriver={true} onBackButtonPress={hideModal} onBackdropPress={hideModal}>
                    <ModalContent
                        iconComponent={
                            <Svg fill="none" height="32" viewBox="0 0 33 32" width="33" xmlns="http://www.w3.org/2000/svg">
                                <Path
                                    d="M30.0566 13.5H2.05664C1.92403 13.5 1.79686 13.5527 1.70309 13.6464C1.60932 13.7402 1.55664 13.8674 1.55664 14V31C1.55664 31.1326 1.60932 31.2598 1.70309 31.3536C1.79686 31.4473 1.92403 31.5 2.05664 31.5H30.0566C30.1892 31.5 30.3164 31.4473 30.4102 31.3536C30.504 31.2598 30.5566 31.1326 30.5566 31V14C30.5566 13.8674 30.504 13.7402 30.4102 13.6464C30.3164 13.5527 30.1892 13.5 30.0566 13.5ZM29.5566 30.5H2.55664V14.5H29.5566V30.5Z"
                                    fill="#2ECC71"
                                />
                                <Path
                                    clip-rule="evenodd"
                                    d="M13.8344 25.8239C14.4922 26.2634 15.2655 26.498 16.0566 26.498C17.1171 26.4968 18.1339 26.075 18.8837 25.3251C19.6336 24.5753 20.0554 23.5585 20.0566 22.498C20.0566 21.7069 19.822 20.9336 19.3825 20.2758C18.943 19.618 18.3183 19.1053 17.5874 18.8025C16.8565 18.4998 16.0522 18.4206 15.2763 18.5749C14.5004 18.7292 13.7876 19.1102 13.2282 19.6696C12.6688 20.229 12.2878 20.9418 12.1335 21.7177C11.9792 22.4936 12.0584 23.2979 12.3611 24.0288C12.6639 24.7597 13.1766 25.3844 13.8344 25.8239ZM17.5567 23.998V22.498C17.5567 22.3654 17.504 22.2383 17.4102 22.1445C17.3165 22.0507 17.1893 21.998 17.0567 21.998H15.5567V21.498H17.0567C17.1893 21.498 17.3165 21.4454 17.4102 21.3516C17.504 21.2578 17.5567 21.1307 17.5567 20.998C17.5567 20.8654 17.504 20.7383 17.4102 20.6445C17.3165 20.5507 17.1893 20.498 17.0567 20.498H16.5567C16.5567 20.3654 16.504 20.2383 16.4102 20.1445C16.3165 20.0507 16.1893 19.998 16.0567 19.998C15.9241 19.998 15.7969 20.0507 15.7031 20.1445C15.6094 20.2383 15.5567 20.3654 15.5567 20.498H15.0567C14.9241 20.498 14.7969 20.5507 14.7031 20.6445C14.6094 20.7383 14.5567 20.8654 14.5567 20.998V22.498C14.5567 22.6307 14.6094 22.7578 14.7031 22.8516C14.7969 22.9454 14.9241 22.998 15.0567 22.998H16.5567V23.498H15.0567C14.9241 23.498 14.7969 23.5507 14.7031 23.6445C14.6094 23.7383 14.5567 23.8654 14.5567 23.998C14.5567 24.1307 14.6094 24.2578 14.7031 24.3516C14.7969 24.4454 14.9241 24.498 15.0567 24.498H15.5567C15.5567 24.6307 15.6094 24.7578 15.7031 24.8516C15.7969 24.9454 15.9241 24.998 16.0567 24.998C16.1893 24.998 16.3165 24.9454 16.4102 24.8516C16.504 24.7578 16.5567 24.6307 16.5567 24.498H17.0567C17.1893 24.498 17.3165 24.4454 17.4102 24.3516C17.504 24.2578 17.5567 24.1307 17.5567 23.998Z"
                                    fill="#2ECC71"
                                    fill-rule="evenodd"
                                />
                                <Path
                                    clip-rule="evenodd"
                                    d="M26.7896 17.2651C27.2583 17.7338 27.8938 17.9974 28.5566 17.998C28.6892 17.998 28.8164 18.0507 28.9102 18.1445C29.004 18.2383 29.0566 18.3654 29.0566 18.498V26.498C29.0566 26.6307 29.004 26.7578 28.9102 26.8516C28.8164 26.9454 28.6892 26.998 28.5566 26.998C27.8938 26.9987 27.2583 27.2623 26.7896 27.731C26.3209 28.1997 26.0573 28.8352 26.0566 29.498C26.0566 29.6307 26.004 29.7578 25.9102 29.8516C25.8164 29.9454 25.6892 29.998 25.5566 29.998H6.55664C6.42403 29.998 6.29686 29.9454 6.20309 29.8516C6.10932 29.7578 6.05664 29.6307 6.05664 29.498C6.05598 28.8352 5.79237 28.1997 5.32368 27.731C4.85498 27.2623 4.21948 26.9987 3.55664 26.998C3.42403 26.998 3.29686 26.9454 3.20309 26.8516C3.10932 26.7578 3.05664 26.6307 3.05664 26.498V18.498C3.05664 18.3654 3.10932 18.2383 3.20309 18.1445C3.29686 18.0507 3.42403 17.998 3.55664 17.998C4.21948 17.9974 4.85498 17.7338 5.32368 17.2651C5.79237 16.7964 6.05598 16.1609 6.05664 15.498C6.05664 15.3654 6.10932 15.2383 6.20309 15.1445C6.29686 15.0507 6.42403 14.998 6.55664 14.998H25.5566C25.6892 14.998 25.8164 15.0507 25.9102 15.1445C26.004 15.2383 26.0566 15.3654 26.0566 15.498C26.0573 16.1609 26.3209 16.7964 26.7896 17.2651ZM13.2788 18.3407C14.101 17.7913 15.0677 17.498 16.0566 17.498C17.3822 17.4996 18.6531 18.0269 19.5905 18.9642C20.5278 19.9016 21.0551 21.1724 21.0566 22.498C21.0566 23.4869 20.7634 24.4536 20.214 25.2759C19.6646 26.0981 18.8837 26.739 17.9701 27.1174C17.0564 27.4959 16.0511 27.5949 15.0812 27.402C14.1113 27.209 13.2204 26.7328 12.5211 26.0336C11.8218 25.3343 11.3456 24.4434 11.1527 23.4735C10.9598 22.5036 11.0588 21.4983 11.4372 20.5846C11.8157 19.671 12.4565 18.8901 13.2788 18.3407Z"
                                    fill="#2ECC71"
                                    fill-rule="evenodd"
                                />
                                <Path
                                    d="M11.0567 5.49897H13.0567V0.998974C13.0567 0.866365 13.1094 0.739188 13.2031 0.64542C13.2969 0.551652 13.4241 0.498974 13.5567 0.498974H18.5567C18.6893 0.498974 18.8165 0.551652 18.9102 0.64542C19.004 0.739188 19.0567 0.866365 19.0567 0.998974V5.49897H21.0567C21.1517 5.49897 21.2448 5.52604 21.325 5.57704C21.4052 5.62803 21.4692 5.70083 21.5095 5.7869C21.5498 5.87296 21.5648 5.96874 21.5526 6.063C21.5404 6.15725 21.5017 6.24609 21.4408 6.3191L16.4408 12.3191C16.3939 12.3754 16.3352 12.4207 16.2688 12.4518C16.2024 12.4829 16.13 12.499 16.0567 12.499C15.9834 12.499 15.911 12.4829 15.8446 12.4518C15.7782 12.4207 15.7195 12.3754 15.6726 12.3191L10.6726 6.3191C10.6117 6.24609 10.5729 6.15725 10.5608 6.063C10.5486 5.96874 10.5635 5.87296 10.6038 5.7869C10.6442 5.70083 10.7082 5.62803 10.7884 5.57704C10.8686 5.52604 10.9616 5.49897 11.0567 5.49897ZM16.0567 11.2177L19.9892 6.49897H18.5567C18.4241 6.49897 18.2969 6.44629 18.2031 6.35253C18.1094 6.25876 18.0567 6.13158 18.0567 5.99897V1.49897H14.0567V5.99897C14.0567 6.13158 14.004 6.25876 13.9102 6.35253C13.8165 6.44629 13.6893 6.49897 13.5567 6.49897H12.1242L16.0567 11.2177Z"
                                    fill="#2ECC71"
                                />
                                <Path
                                    d="M16.0567 11.2177L19.9892 6.49897H18.5567C18.4241 6.49897 18.2969 6.44629 18.2031 6.35253C18.1094 6.25876 18.0567 6.13158 18.0567 5.99897V1.49897H14.0567V5.99897C14.0567 6.13158 14.004 6.25876 13.9102 6.35253C13.8165 6.44629 13.6893 6.49897 13.5567 6.49897H12.1242L16.0567 11.2177Z"
                                    fill="#2ECC71"
                                />
                                <Path
                                    d="M4.55665 7.99949H5.55666V5.49949C5.55666 5.36688 5.60933 5.2397 5.7031 5.14593C5.79687 5.05217 5.92405 4.99949 6.05666 4.99949H8.05666C8.18927 4.99949 8.31644 5.05217 8.41021 5.14593C8.50398 5.2397 8.55666 5.36688 8.55666 5.49949V7.99949H9.55666C9.64853 7.99949 9.73863 8.0248 9.81705 8.07264C9.89548 8.12048 9.95922 8.18901 10.0013 8.2707C10.0433 8.35239 10.062 8.44408 10.0554 8.53571C10.0487 8.62733 10.0169 8.71536 9.96353 8.79012L7.46353 12.2901C7.41727 12.3549 7.35622 12.4077 7.28545 12.4441C7.21469 12.4805 7.13625 12.4995 7.05666 12.4995C6.97707 12.4995 6.89863 12.4805 6.82786 12.4441C6.75709 12.4077 6.69604 12.3549 6.64978 12.2901L4.14978 8.79012C4.09638 8.71536 4.06461 8.62733 4.05795 8.53571C4.0513 8.44408 4.07002 8.35239 4.11206 8.2707C4.1541 8.18901 4.21783 8.12048 4.29626 8.07264C4.37469 8.0248 4.46478 7.99949 4.55665 7.99949ZM7.05666 11.1392L8.58503 8.99949H8.05666C7.92405 8.99949 7.79687 8.94681 7.7031 8.85304C7.60934 8.75928 7.55666 8.6321 7.55666 8.49949V5.99949H6.55666V8.49949C6.55666 8.6321 6.50398 8.75928 6.41021 8.85304C6.31644 8.94681 6.18926 8.99949 6.05666 8.99949H5.52828L7.05666 11.1392Z"
                                    fill="#2ECC71"
                                />
                                <Path
                                    d="M7.05666 11.1392L8.58503 8.99949H8.05666C7.92405 8.99949 7.79687 8.94681 7.7031 8.85304C7.60934 8.75928 7.55666 8.6321 7.55666 8.49949V5.99949H6.55666V8.49949C6.55666 8.6321 6.50398 8.75928 6.41021 8.85304C6.31644 8.94681 6.18926 8.99949 6.05666 8.99949H5.52828L7.05666 11.1392Z"
                                    fill="#2ECC71"
                                />
                                <Path
                                    d="M22.5567 7.99949H23.5567V5.49949C23.5567 5.36688 23.6093 5.2397 23.7031 5.14593C23.7969 5.05217 23.924 4.99949 24.0567 4.99949H26.0567C26.1893 4.99949 26.3164 5.05217 26.4102 5.14593C26.504 5.2397 26.5567 5.36688 26.5567 5.49949V7.99949H27.5567C27.6485 7.99949 27.7386 8.0248 27.8171 8.07264C27.8955 8.12048 27.9592 8.18901 28.0013 8.2707C28.0433 8.35239 28.062 8.44408 28.0554 8.53571C28.0487 8.62733 28.0169 8.71536 27.9635 8.79012L25.4635 12.2901C25.4173 12.3549 25.3562 12.4077 25.2855 12.4441C25.2147 12.4805 25.1362 12.4995 25.0567 12.4995C24.9771 12.4995 24.8986 12.4805 24.8279 12.4441C24.7571 12.4077 24.696 12.3549 24.6498 12.2901L22.1498 8.79012C22.0964 8.71536 22.0646 8.62733 22.058 8.53571C22.0513 8.44408 22.07 8.35239 22.1121 8.2707C22.1541 8.18901 22.2178 8.12048 22.2963 8.07264C22.3747 8.0248 22.4648 7.99949 22.5567 7.99949ZM25.0567 11.1392L26.585 8.99949H26.0567C25.924 8.99949 25.7969 8.94681 25.7031 8.85304C25.6093 8.75928 25.5567 8.6321 25.5567 8.49949V5.99949H24.5567V8.49949C24.5567 8.6321 24.504 8.75928 24.4102 8.85304C24.3164 8.94681 24.1893 8.99949 24.0567 8.99949H23.5283L25.0567 11.1392Z"
                                    fill="#2ECC71"
                                />
                                <Path
                                    d="M25.0567 11.1392L26.585 8.99949H26.0567C25.924 8.99949 25.7969 8.94681 25.7031 8.85304C25.6093 8.75928 25.5567 8.6321 25.5567 8.49949V5.99949H24.5567V8.49949C24.5567 8.6321 24.504 8.75928 24.4102 8.85304C24.3164 8.94681 24.1893 8.99949 24.0567 8.99949H23.5283L25.0567 11.1392Z"
                                    fill="#2ECC71"
                                />
                            </Svg>
                        }
                        title={t('trading_confirm')}
                        type="confirm"
                    >
                        <RowDataModal dataSub={[userInfo.actn_curr, userInfo.sub_curr]} textLeft={t('trans_sub_account')} />

                        <RowDataModal textLeft={t('transaction_type')} textRight={t(typeTransactionSelect?.label)} />
                        <RowDataModal textLeft={t('bank_account')} textRight={acntSelect.label} />
                        <RowDataModal textLeft={t('bank_transaction_amount')} textRight={FormatNumber(amountTransaction)} />

                        <ButtonCustom text={t('common_button_confirm')} type="confirm" onPress={switchStep.submit} />
                        <ButtonCustom last text={'common_Cancel'} type="back" onPress={hideModal} />
                    </ModalContent>
                </Modal>
            )}
            {loadingConfirm && <ModalLoading content={t('common_processing')} visible={loadingConfirm} />}
        </Container>
    )
}

export default OnlineBank

const UI = StyleSheet.create({
    Button: {
        alignItems: 'center',
        borderRadius: 8,
        height: dm.moderate(28),
        justifyContent: 'center',
        width: dm.moderate(28),
    },
    ErrorBorder: {
        borderColor: '#EB5C55',
        borderWidth: 1,
    },
    ErrorStyle: {
        color: '#EB5C55',
        fontSize: fs.smallest,
        fontStyle: 'italic',
        fontWeight: fw.light,
    },
    GroupInput: {
        // marginVertical: dm.halfVerticalIndent,
        paddingRight: dm.halfIndent,
    },
    RowInput: {
        marginLeft: dm.moderate(8),
        marginVertical: dm.vertical(8),
    },
    Row_Modal: {
        height: dm.vertical(24),
        marginVertical: dm.vertical(16),
    },
    bottomModal: {
        justifyContent: 'flex-end',
        margin: 0,
    },
    margin_top_row: {
        marginBottom: dm.moderate(24),
        marginHorizontal: dm.moderate(16),
        marginTop: dm.moderate(16),
    },
    page: {
        flex: 1,
        flexDirection: 'column',
    },
    stepIndicator: {
        marginBottom: dm.vertical(8),
        marginTop: dm.vertical(24),
    },
})
