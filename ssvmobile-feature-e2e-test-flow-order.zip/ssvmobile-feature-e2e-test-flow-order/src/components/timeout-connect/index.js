import React, { useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { Container, Content, Icon, Left, List, ListItem, Right, View } from 'native-base'
import SyncStorage from 'sync-storage'

import { Text } from '../../basic-components'
import HeaderComponent from '../../components/header'
import { StoreContext } from '../../store'
import { dimensions, fontSizes } from '../../styles'
import { glb_sv } from '../../utils'
import STORE_KEY from '../../utils/constant/store_key'

export default function TimeoutConnectStack({ navigation }) {
    const { timeoutConnect, setTimeoutConnect, styles } = useContext(StoreContext)
    const { t } = useTranslation()

    const changeTimeoutConnect = (key) => {
        if (timeoutConnect === key) return
        setTimeoutConnect(key)
        SyncStorage.set(STORE_KEY.TIMEOUT_CONNECT, key)
        glb_sv.timeoutConnect = key
        navigation.goBack()
    }

    return (
        <Container
            style={{
                backgroundColor: styles.PRIMARY__BG__COLOR,
            }}
        >
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft
                navigation={navigation}
                title={t('auto_logout')}
                titleAlgin="flex-start"
                transparent
            />
            <Content>
                <List>
                    <Text
                        style={{
                            color: styles.SECOND__CONTENT__COLOR,
                            fontSize: fontSizes.normal,
                            textAlign: 'center',
                            paddingHorizontal: dimensions.indent * 2,
                        }}
                    >
                        {t('note_auto_logout')}
                    </Text>

                    <ListItem
                        activeOpacity={0.6}
                        noBorder
                        selected={timeoutConnect === 'timeout_1m' ? true : false}
                        underlayColor="transparent"
                        onPress={() => changeTimeoutConnect('timeout_1m')}
                    >
                        <Left>
                            <Text
                                style={{
                                    fontSize: fontSizes.normal,
                                    color: timeoutConnect === 'timeout_1m' ? styles.PRIMARY : styles.PRIMARY__CONTENT__COLOR,
                                }}
                            >
                                {t('timeout_1m')}
                            </Text>
                        </Left>
                        <Right>{timeoutConnect === 'timeout_1m' ? <Icon name="check" style={{ color: styles.PRIMARY }} type="AntDesign" /> : null}</Right>
                    </ListItem>
                    <View style={{ borderBottomColor: styles.DIVIDER__COLOR, borderBottomWidth: 1 }} />

                    <ListItem
                        activeOpacity={0.6}
                        noBorder
                        selected={timeoutConnect === 'timeout_30m' ? true : false}
                        underlayColor="transparent"
                        onPress={() => changeTimeoutConnect('timeout_30m')}
                    >
                        <Left>
                            <Text
                                style={{
                                    fontSize: fontSizes.normal,
                                    color: timeoutConnect === 'timeout_30m' ? styles.PRIMARY : styles.PRIMARY__CONTENT__COLOR,
                                }}
                            >
                                {t('timeout_30m')}
                            </Text>
                        </Left>
                        <Right>{timeoutConnect === 'timeout_30m' ? <Icon name="check" style={{ color: styles.PRIMARY }} type="AntDesign" /> : null}</Right>
                    </ListItem>
                    <View style={{ borderBottomColor: styles.DIVIDER__COLOR, borderBottomWidth: 1 }} />

                    <ListItem
                        activeOpacity={0.6}
                        noBorder
                        selected={timeoutConnect === 'timeout_1h' ? true : false}
                        underlayColor="transparent"
                        onPress={() => changeTimeoutConnect('timeout_1h')}
                    >
                        <Left>
                            <Text
                                style={{
                                    fontSize: fontSizes.normal,
                                    color: timeoutConnect === 'timeout_1h' ? styles.PRIMARY : styles.PRIMARY__CONTENT__COLOR,
                                }}
                            >
                                {t('timeout_1h')}
                            </Text>
                        </Left>
                        <Right>{timeoutConnect === 'timeout_1h' ? <Icon name="check" style={{ color: styles.PRIMARY }} type="AntDesign" /> : null}</Right>
                    </ListItem>
                    <View style={{ borderBottomColor: styles.DIVIDER__COLOR, borderBottomWidth: 1 }} />

                    <ListItem
                        activeOpacity={0.6}
                        noBorder
                        selected={timeoutConnect === 'timeout_2h' ? true : false}
                        underlayColor="transparent"
                        onPress={() => changeTimeoutConnect('timeout_2h')}
                    >
                        <Left>
                            <Text
                                style={{
                                    fontSize: fontSizes.normal,
                                    color: timeoutConnect === 'timeout_2h' ? styles.PRIMARY : styles.PRIMARY__CONTENT__COLOR,
                                }}
                            >
                                {t('timeout_2h')}
                            </Text>
                        </Left>
                        <Right>{timeoutConnect === 'timeout_2h' ? <Icon name="check" style={{ color: styles.PRIMARY }} type="AntDesign" /> : null}</Right>
                    </ListItem>
                    <View style={{ borderBottomColor: styles.DIVIDER__COLOR, borderBottomWidth: 1 }} />

                    <ListItem
                        activeOpacity={0.6}
                        noBorder
                        selected={timeoutConnect === 'timeout_4h' ? true : false}
                        underlayColor="transparent"
                        onPress={() => changeTimeoutConnect('timeout_4h')}
                    >
                        <Left>
                            <Text
                                style={{
                                    fontSize: fontSizes.normal,
                                    color: timeoutConnect === 'timeout_4h' ? styles.PRIMARY : styles.PRIMARY__CONTENT__COLOR,
                                }}
                            >
                                {t('timeout_4h')}
                            </Text>
                        </Left>
                        <Right>{timeoutConnect === 'timeout_4h' ? <Icon name="check" style={{ color: styles.PRIMARY }} type="AntDesign" /> : null}</Right>
                    </ListItem>
                    <View style={{ borderBottomColor: styles.DIVIDER__COLOR, borderBottomWidth: 1 }} />

                    <ListItem
                        activeOpacity={0.6}
                        noBorder
                        selected={timeoutConnect === 'timeout_8h' ? true : false}
                        underlayColor="transparent"
                        onPress={() => changeTimeoutConnect('timeout_8h')}
                    >
                        <Left>
                            <Text
                                style={{
                                    fontSize: fontSizes.normal,
                                    color: timeoutConnect === 'timeout_8h' ? styles.PRIMARY : styles.PRIMARY__CONTENT__COLOR,
                                }}
                            >
                                {t('timeout_8h')}
                            </Text>
                        </Left>
                        <Right>{timeoutConnect === 'timeout_8h' ? <Icon name="check" style={{ color: styles.PRIMARY }} type="AntDesign" /> : null}</Right>
                    </ListItem>
                    <View style={{ borderBottomColor: styles.DIVIDER__COLOR, borderBottomWidth: 1 }} />

                    <ListItem
                        activeOpacity={0.6}
                        noBorder
                        selected={timeoutConnect === 'timeout_outday' ? true : false}
                        underlayColor="transparent"
                        onPress={() => changeTimeoutConnect('timeout_outday')}
                    >
                        <Left>
                            <Text
                                style={{
                                    fontSize: fontSizes.normal,
                                    color: timeoutConnect === 'timeout_outday' ? styles.PRIMARY : styles.PRIMARY__CONTENT__COLOR,
                                }}
                            >
                                {t('timeout_outday')}
                            </Text>
                        </Left>
                        <Right>{timeoutConnect === 'timeout_outday' ? <Icon name="check" style={{ color: styles.PRIMARY }} type="AntDesign" /> : null}</Right>
                    </ListItem>
                </List>
            </Content>
        </Container>
    )
}
