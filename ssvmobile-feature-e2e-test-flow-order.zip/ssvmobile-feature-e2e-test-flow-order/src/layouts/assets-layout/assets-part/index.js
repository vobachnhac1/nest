import React, { memo, useContext, useEffect, useMemo, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { ActivityIndicator, FlatList, InteractionManager, Pressable, SafeAreaView, StyleSheet, TouchableOpacity } from 'react-native'
import Svg, { Path } from 'react-native-svg'
import { orderBy } from 'lodash'
import { Col, Row, Text, View } from 'native-base'

import Chart from '../../../assets/images/common/chart.svg'
import List from '../../../assets/images/common/list.svg'
import Refresh from '../../../assets/images/common/refresh.svg'
import { EmptyView, RowTitleGroup } from '../../../components/trading-component'
import EmptyAccountView from '../../../components/trading-component/empty-account-view'
import ErrorView from '../../../components/trading-component/error-view'
import { preventCompanyRender } from '../../../hoc'
import { StoreContext } from '../../../store'
import { dimensions, fontSizes, fontWeights, IconSvg } from '../../../styles'
import { FormatNumber, glb_sv, Screens } from '../../../utils'
import AssetPieChartOwn from '../AssetPieChartOwn'
import ChartDemoF2 from '../chart-assests'
import { RowAssetsStock } from '../components/RowAssetsStock'

const AssetPart = ({
    navigation,
    assetInfo,
    updateChart,
    isLoading,
    isTimeout,
    dataStock,
    setDataStock,
    dataPieChart,
    objTotal,
    refreshStockOwn,
    userInfo,
    tempList,
}) => {
    const { t } = useTranslation()
    const { styles } = useContext(StoreContext)
    const [dataChart, setDataChart] = useState([])
    const [isShow, setIsShow] = useState(false)
    // New config sort
    const SORT_CONFIG = {
        column01: ['c2|desc', 'c2|asc', 'c25|desc', 'c25|asc'], // Sort mã CK và số lượng
        column02: ['c17|desc', 'c17|asc'], // Sort giá vốn
        column03: ['c18|desc', 'c18|asc'], // Sort Vốn
        column04: ['c19|desc', 'c19|asc'], // Sort giá trị lãi lỗ
    }
    const activeSortColumnRef = useRef('')
    const activeSortKeyRef = useRef('')
    // --------------
    useEffect(() => {
        activeSortColumnRef.current = ''
        activeSortKeyRef.current = ''
    }, [userInfo])

    // --------------
    const DEFAULT_DATA_CHART = [
        {
            x: t('title_cash'),
            y: [0, 30],
            color: styles.DIVIDER__COLOR,
            hideLabel: true,
        },
        {
            x: t('stock'),
            y: [30, 70],
            color: styles.DIVIDER__COLOR,
            hideLabel: true,
        },
        {
            x: t('sb_assetsMng'),
            y: [0, 100],
            color: styles.DIVIDER__COLOR,
            hideLabel: true,
        },
        {
            x: t('total_debt'),
            y: [80, 100],
            color: styles.DIVIDER__COLOR,
            hideLabel: true,
        },
        {
            x: t('net_assets'),
            y: [0, 90],
            color: styles.DIVIDER__COLOR,
            hideLabel: true,
        },
    ]

    useEffect(() => {
        InteractionManager.runAfterInteractions(() => {
            if (assetInfo.c23) {
                setDataChart([
                    {
                        x: t('title_cash'),
                        y: [0, Number(assetInfo.c23) === 0 ? 0 : Math.round((Number(assetInfo.c39) / Number(assetInfo.c23)) * 10000) / 100],
                        color: styles.REF__COLOR,
                    },
                    {
                        x: t('stock'),
                        y: [
                            Number(assetInfo.c23) === 0 ? 0 : Math.round((Number(assetInfo.c39) / Number(assetInfo.c23)) * 10000) / 100,
                            Number(assetInfo.c23) === 0 ? 0 : 100,
                        ],
                        color: '#AFAAFF',
                    },
                    {
                        x: t('sb_assetsMng'),
                        y: [0, Number(assetInfo.c23) === 0 ? 0 : 100],
                        color: '#92EB7E',
                    },
                    {
                        x: t('total_debt'),
                        y: [
                            Number(assetInfo.c23) === 0 ? 0 : Math.round((Number(assetInfo.c24) / Number(assetInfo.c23)) * 10000) / 100,
                            Number(assetInfo.c23) === 0 ? 0 : 100,
                        ],
                        color: '#FF3300',
                    },
                    {
                        x: t('net_assets'),
                        y: [0, Number(assetInfo.c23) === 0 ? 0 : Math.round((Number(assetInfo.c24) / Number(assetInfo.c23)) * 10000) / 100],
                        color: '#5B9BD5',
                    },
                ])
            } else {
                setDataChart((prev) => DEFAULT_DATA_CHART)
            }
        })
    }, [assetInfo])

    const CellContentUI = {
        fontWeight: fontWeights.bold,
        fontSize: fontSizes.verySmall,
        textAlign: 'right',
        color: styles.HEADER__CONTENT__COLOR,
    }

    // ---------
    const sortAssets = (column) => {
        activeSortColumnRef.current = column
        // ---------------------
        const sortList = SORT_CONFIG[column] || []
        const activeKey = activeSortKeyRef.current
        const indexActive = sortList.findIndex((key) => key === activeKey)
        const nextActiveKey = sortList[(indexActive + 1) % sortList.length]
        activeSortKeyRef.current = nextActiveKey
        // console.log('sortAssets', activeSortColumnRef.current, activeSortKeyRef.current)
        // -------------
        if (nextActiveKey) {
            const [sortKey, typeSort] = nextActiveKey.split('|')
            const afterSort = orderBy(dataStock, [sortKey], [typeSort])
            tempList.current = afterSort
            setDataStock(afterSort)
        } else {
            tempList.current = dataStock
            setDataStock(dataStock)
        }
    }

    const TimeoutView = isTimeout && userInfo.actn_curr ? <ErrorView refresh={refreshStockOwn} /> : null

    const filterSoldStock = (list = []) => {
        if (!preventCompanyRender(['081'])) {
            // Remove các mã đã bán hết
            return list.filter((x) => x.c4 !== 0 || x.c25 + x.c14 !== 0)
        } else {
            return list
        }
    }

    const HeaderListAssetsStock = () => {
        return (
            <>
                <RowTitleGroup hasDivider text={t('stk_own_list')} type="group" />
                <View style={{ flexDirection: 'row', paddingHorizontal: dimensions.moderate(4) }}>
                    <View style={{ flex: 2 }}>
                        <TouchableOpacity onPress={() => sortAssets('column01')}>
                            <View style={UI.HeaderColInside}>
                                <View>
                                    <Text
                                        style={{
                                            fontWeight: fontWeights.bold,
                                            fontSize: fontSizes.verySmall,
                                            textAlign: 'left',
                                            color: activeSortKeyRef.current?.includes('c2|') ? styles.PRIMARY : styles.HEADER__CONTENT__COLOR,
                                            flex: 1.2,
                                        }}
                                    >
                                        {t('stock_symbol_short')}
                                    </Text>
                                    <Text
                                        style={[
                                            CellContentUI,
                                            { color: activeSortKeyRef.current?.includes('c25|') ? styles.PRIMARY : styles.HEADER__CONTENT__COLOR },
                                        ]}
                                    >
                                        {t('common_amount')}
                                    </Text>
                                </View>
                                <View style={{ paddingLeft: 0 }}>
                                    <Svg height={13} viewBox="0 0 12 13" width={12}>
                                        <Path
                                            d="M2.519 7.734l2.84 3.315a.488.488 0 00.74 0l2.84-3.315a.488.488 0 00-.37-.804h-5.68a.487.487 0 00-.37.804z"
                                            fill={
                                                activeSortColumnRef.current === 'column01' && activeSortKeyRef.current?.includes('desc')
                                                    ? styles.PRIMARY
                                                    : styles.ICON__UN__ACTIVE
                                            }
                                        />
                                        <Path
                                            d="M2.519 4.784l2.84-3.314a.488.488 0 01.74 0l2.84 3.314a.488.488 0 01-.37.805h-5.68a.487.487 0 01-.37-.805z"
                                            fill={
                                                activeSortColumnRef.current === 'column01' && activeSortKeyRef.current?.includes('asc')
                                                    ? styles.PRIMARY
                                                    : styles.ICON__UN__ACTIVE
                                            }
                                        />
                                    </Svg>
                                </View>
                            </View>
                        </TouchableOpacity>
                    </View>
                    <View style={{ flex: 3 }}>
                        <TouchableOpacity onPress={() => sortAssets('column02')}>
                            <View style={[UI.HeaderColInside, { justifyContent: 'flex-end' }]}>
                                <View>
                                    <Text
                                        style={[
                                            CellContentUI,
                                            { color: activeSortKeyRef.current?.includes('c17|') ? styles.PRIMARY : styles.HEADER__CONTENT__COLOR },
                                        ]}
                                    >
                                        {t('cost_price')}
                                    </Text>
                                    <Text style={CellContentUI}>{t('present_price')}</Text>
                                </View>
                                <View style={{ paddingLeft: 2 }}>
                                    <Svg height={13} viewBox="0 0 12 13" width={12}>
                                        <Path
                                            d="M2.519 7.734l2.84 3.315a.488.488 0 00.74 0l2.84-3.315a.488.488 0 00-.37-.804h-5.68a.487.487 0 00-.37.804z"
                                            fill={
                                                activeSortColumnRef.current === 'column02' && activeSortKeyRef.current?.includes('desc')
                                                    ? styles.PRIMARY
                                                    : styles.ICON__UN__ACTIVE
                                            }
                                        />
                                        <Path
                                            d="M2.519 4.784l2.84-3.314a.488.488 0 01.74 0l2.84 3.314a.488.488 0 01-.37.805h-5.68a.487.487 0 01-.37-.805z"
                                            fill={
                                                activeSortColumnRef.current === 'column02' && activeSortKeyRef.current?.includes('asc')
                                                    ? styles.PRIMARY
                                                    : styles.ICON__UN__ACTIVE
                                            }
                                        />
                                    </Svg>
                                </View>
                            </View>
                        </TouchableOpacity>
                    </View>

                    <View style={{ flex: 4 }}>
                        <TouchableOpacity onPress={() => sortAssets('column03')}>
                            <View style={[UI.HeaderColInside, { justifyContent: 'flex-end' }]}>
                                <View>
                                    <Text
                                        style={[
                                            CellContentUI,
                                            { color: activeSortKeyRef.current?.includes('c18|') ? styles.PRIMARY : styles.HEADER__CONTENT__COLOR },
                                        ]}
                                    >
                                        {t('cost')}
                                    </Text>
                                    <Text
                                        style={[
                                            CellContentUI,
                                            // { color: activeSortKeyRef.current?.includes('c18|') ? styles.PRIMARY : styles.HEADER__CONTENT__COLOR },
                                        ]}
                                    >
                                        {t('present_values')}
                                    </Text>
                                </View>
                                <View style={{ paddingLeft: 2 }}>
                                    <Svg height={13} viewBox="0 0 12 13" width={12}>
                                        <Path
                                            d="M2.519 7.734l2.84 3.315a.488.488 0 00.74 0l2.84-3.315a.488.488 0 00-.37-.804h-5.68a.487.487 0 00-.37.804z"
                                            fill={
                                                activeSortColumnRef.current === 'column03' && activeSortKeyRef.current?.includes('desc')
                                                    ? styles.PRIMARY
                                                    : styles.ICON__UN__ACTIVE
                                            }
                                        />
                                        <Path
                                            d="M2.519 4.784l2.84-3.314a.488.488 0 01.74 0l2.84 3.314a.488.488 0 01-.37.805h-5.68a.487.487 0 01-.37-.805z"
                                            fill={
                                                activeSortColumnRef.current === 'column03' && activeSortKeyRef.current?.includes('asc')
                                                    ? styles.PRIMARY
                                                    : styles.ICON__UN__ACTIVE
                                            }
                                        />
                                    </Svg>
                                </View>
                            </View>
                        </TouchableOpacity>
                    </View>
                    <View style={{ flex: 3 }}>
                        <TouchableOpacity onPress={() => sortAssets('column04')}>
                            <View style={[UI.HeaderColInside, { justifyContent: 'flex-end' }]}>
                                <View>
                                    <Text
                                        style={[
                                            CellContentUI,
                                            { color: activeSortKeyRef.current?.includes('c19|') ? styles.PRIMARY : styles.HEADER__CONTENT__COLOR },
                                        ]}
                                    >
                                        {t('common_profit')}
                                    </Text>

                                    <Text style={CellContentUI}>{t('profit_ratio')}</Text>
                                </View>
                                <View style={{ paddingLeft: 2 }}>
                                    <Svg height={13} viewBox="0 0 12 13" width={12}>
                                        <Path
                                            d="M2.519 7.734l2.84 3.315a.488.488 0 00.74 0l2.84-3.315a.488.488 0 00-.37-.804h-5.68a.487.487 0 00-.37.804z"
                                            fill={
                                                activeSortColumnRef.current === 'column04' && activeSortKeyRef.current?.includes('desc')
                                                    ? styles.PRIMARY
                                                    : styles.ICON__UN__ACTIVE
                                            }
                                        />
                                        <Path
                                            d="M2.519 4.784l2.84-3.314a.488.488 0 01.74 0l2.84 3.314a.488.488 0 01-.37.805h-5.68a.487.487 0 01-.37-.805z"
                                            fill={
                                                activeSortColumnRef.current === 'column04' && activeSortKeyRef.current?.includes('asc')
                                                    ? styles.PRIMARY
                                                    : styles.ICON__UN__ACTIVE
                                            }
                                        />
                                    </Svg>
                                </View>
                            </View>
                        </TouchableOpacity>
                    </View>
                </View>
            </>
        )
    }

    const navigateHistoryProfitLoss = () => {
        navigation.navigate(Screens.HISTORY_PROFIT_LOSS, {})
    }

    return (
        <>
            <View style={{ backgroundColor: styles.PRIMARY__BG__COLOR, flex: 1 }}>
                <View style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
                    <ChartDemoF2
                        dataChart={dataChart}
                        dataChartDefault={DEFAULT_DATA_CHART}
                        isLoadingChart={isLoading}
                        isVisibleChart={dataChart.length && updateChart}
                        timeoutView={TimeoutView}
                    />
                    <View>
                        <View style={{ paddingHorizontal: dimensions.moderate(4) }}>
                            <Row>
                                <Col size={12} style={{ display: 'flex' }}>
                                    <View style={{ flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center' }}>
                                        <Text
                                            style={{
                                                backgroundColor: styles.REF__COLOR,
                                                width: dimensions.moderate(6),
                                                height: dimensions.moderate(20),
                                            }}
                                        />
                                        <Text style={{ marginLeft: dimensions.moderate(4), color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small }}>
                                            {t('title_cash')}
                                        </Text>
                                        {/* <Text style={{ marginLeft: dimensions.moderate(5) }} onPress={(e) => { setIsOpenModalDetail(true); setTypeDetail('1') }}>
                                        <Info fill={styles.SECOND__CONTENT__COLOR} />
                                    </Text> */}
                                    </View>
                                </Col>
                                <Col size={12}>
                                    <Text style={{ textAlign: 'right', color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small }}>
                                        {assetInfo?.c39 ? FormatNumber(assetInfo.c39) : '---'}
                                    </Text>
                                </Col>
                            </Row>
                        </View>
                        <View style={{ padding: dimensions.moderate(4) }}>
                            <Row>
                                <Col size={12} style={{ display: 'flex' }}>
                                    <View style={{ flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center' }}>
                                        <Text style={{ backgroundColor: '#AFAAFF', width: dimensions.moderate(6), height: dimensions.moderate(20) }} />
                                        <Text style={{ marginLeft: dimensions.moderate(5), color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small }}>
                                            {t('stock_title')}
                                        </Text>
                                    </View>
                                </Col>
                                <Col size={12}>
                                    <Text style={{ textAlign: 'right', color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small }}>
                                        {assetInfo?.c40 ? FormatNumber(assetInfo.c40) : '---'}
                                    </Text>
                                </Col>
                            </Row>
                        </View>
                        <View style={{ padding: dimensions.moderate(4) }}>
                            <Row>
                                <Col size={12} style={{ display: 'flex' }}>
                                    <View style={{ flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center' }}>
                                        <Text style={{ backgroundColor: '#92EB7E', width: dimensions.moderate(6), height: dimensions.moderate(20) }} />
                                        <Text style={{ marginLeft: dimensions.moderate(4), color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small }}>
                                            {t('total_assets')}
                                        </Text>
                                    </View>
                                </Col>
                                <Col size={12}>
                                    <Text style={{ textAlign: 'right', color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small }}>
                                        {assetInfo?.c23 ? FormatNumber(assetInfo.c23) : '---'}
                                    </Text>
                                </Col>
                            </Row>
                        </View>
                        <View style={{ padding: dimensions.moderate(4) }}>
                            <Row>
                                <Col size={12} style={{ display: 'flex' }}>
                                    <View style={{ flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center' }}>
                                        <Text style={{ backgroundColor: '#FF3300', width: dimensions.moderate(6), height: dimensions.moderate(20) }} />
                                        <Text style={{ marginLeft: dimensions.moderate(4), color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small }}>
                                            {t('common_debt')}
                                        </Text>
                                    </View>
                                </Col>
                                <Col size={12}>
                                    <Text style={{ textAlign: 'right', color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small }}>
                                        {Number(assetInfo.c37) + Number(assetInfo.c13) + Number(assetInfo.c15) + Number(assetInfo.c17)
                                            ? FormatNumber(Number(assetInfo.c37) + Number(assetInfo.c13) + Number(assetInfo.c15) + Number(assetInfo.c17))
                                            : ''}
                                    </Text>
                                </Col>
                            </Row>
                        </View>
                        <View style={{ padding: dimensions.moderate(4) }}>
                            <Row>
                                <Col size={12} style={{ display: 'flex' }}>
                                    <View style={{ flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center' }}>
                                        <Text style={{ backgroundColor: '#5B9BD5', width: dimensions.moderate(6), height: dimensions.moderate(20) }} />
                                        <Text style={{ marginLeft: dimensions.moderate(4), color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small }}>
                                            {t('net_assets')}
                                        </Text>
                                    </View>
                                </Col>
                                <Col size={12}>
                                    <Text style={{ textAlign: 'right', color: styles.PRIMARY, fontWeight: fontWeights.bold, fontSize: fontSizes.small }}>
                                        {assetInfo?.c24 ? FormatNumber(assetInfo.c24) : '---'}
                                    </Text>
                                </Col>
                            </Row>
                        </View>
                    </View>
                </View>
                <View style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
                    <RowTitleGroup
                        hasDivider
                        iconLeft={
                            <View style={{ flex: 1, justifyContent: 'flex-start', alignItems: 'flex-start' }}>
                                {glb_sv.configInfo.application_style.is_profit_loss_screen_on ? (
                                    <TouchableOpacity onPress={navigateHistoryProfitLoss}>
                                        <IconSvg.InfoIcon color={styles.PRIMARY__CONTENT__COLOR} height={20} width={20} />
                                    </TouchableOpacity>
                                ) : null}
                            </View>
                        }
                        rightComponent={
                            <>
                                <View style={{ display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end' }}>
                                    <TouchableOpacity onPress={() => setIsShow(!isShow)}>
                                        {!isShow ? (
                                            <Chart fill={styles.PRIMARY__CONTENT__COLOR} height={24} width={24} />
                                        ) : (
                                            <List fill={styles.PRIMARY__CONTENT__COLOR} height={22} width={22} />
                                        )}
                                    </TouchableOpacity>
                                    <TouchableOpacity onPress={refreshStockOwn}>
                                        <Refresh fill={styles.PRIMARY__CONTENT__COLOR} height={24} style={{ marginLeft: dimensions.moderate(8) }} width={24} />
                                    </TouchableOpacity>
                                </View>
                            </>
                        }
                        text={t('stock_assets_short')}
                        type="group"
                    />
                    {isTimeout ? userInfo.actn_curr ? <ErrorView refresh={refreshStockOwn} /> : <EmptyAccountView /> : null}
                    <View style={{ padding: dimensions.moderate(4) }}>
                        <Row>
                            <Col size={12} style={{ display: 'flex' }}>
                                <View style={{ flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center' }}>
                                    <Text
                                        style={{
                                            marginLeft: dimensions.moderate(4),
                                            color: styles.PRIMARY__CONTENT__COLOR,
                                            fontSize: fontSizes.small,
                                        }}
                                    >
                                        {t('cost')}
                                    </Text>
                                </View>
                            </Col>
                            <Col size={12}>
                                <Text style={{ textAlign: 'right', color: styles.REF__COLOR, fontSize: fontSizes.small }}>
                                    {FormatNumber(objTotal.avg_buy_values)}
                                </Text>
                            </Col>
                        </Row>
                    </View>
                    <View style={{ padding: dimensions.moderate(4) }}>
                        <Row>
                            <Col size={12} style={{ display: 'flex' }}>
                                <View style={{ flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center' }}>
                                    <Text
                                        style={{
                                            marginLeft: dimensions.moderate(4),
                                            color: styles.PRIMARY__CONTENT__COLOR,
                                            fontSize: fontSizes.small,
                                        }}
                                    >
                                        {t('value')}
                                    </Text>
                                </View>
                            </Col>
                            <Col size={12}>
                                <Text
                                    style={{
                                        textAlign: 'right',
                                        color: objTotal.present_values > objTotal.avg_buy_values ? styles.UP__COLOR : styles.DOWN__COLOR,
                                        fontSize: fontSizes.small,
                                    }}
                                >
                                    {FormatNumber(objTotal.present_values)}
                                </Text>
                            </Col>
                        </Row>
                    </View>
                </View>
                {!isShow ? <HeaderListAssetsStock /> : null}
                {isLoading
                    ? !isTimeout && (
                          <View style={{ paddingVertical: dimensions.moderate(50) }}>
                              <ActivityIndicator color="#494949" size={30} />
                          </View>
                      )
                    : null}
                {!isLoading && !isTimeout && isShow ? (
                    <View>
                        <AssetPieChartOwn data={dataPieChart} />
                    </View>
                ) : null}
                {!isLoading && !isTimeout && !isShow ? (
                    <View>
                        <SafeAreaView style={{ flex: 1 }}>
                            <FlatList
                                data={filterSoldStock(dataStock)}
                                keyboardShouldPersistTaps="always"
                                keyExtractor={(item, index) => index.toString()}
                                ListEmptyComponent={EmptyView}
                                style={{ marginBottom: 10 }}
                                removeClippedSubviews={true} // https://reactnative.dev/docs/optimizing-flatlist-configuration#removeclippedsubviews
                                // extraData={dataStock}
                                renderItem={({ item }) => <RowAssetsStock item={item} />}
                            />
                        </SafeAreaView>
                    </View>
                ) : null}
            </View>
        </>
    )
}

const UI = StyleSheet.create({
    HeaderColInside: {
        alignItems: 'center',
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'flex-start',
    },
    TextButtonUI: { color: 'white', fontSize: fontSizes.small, fontWeight: fontWeights.bold },
    TextProfitUI: {
        flex: 3,
        fontSize: fontSizes.verySmall,
        fontWeight: fontWeights.bold,
        textAlign: 'right',
    },
    container: {
        backgroundColor: 'red',
        height: 300,
        justifyContent: 'center',
    },
    renderContentRow2: { alignItems: 'center', display: 'flex', flexDirection: 'row', justifyContent: 'space-between' },
    renderContentWrap: { display: 'flex', flexDirection: 'row', justifyContent: 'space-between', marginVertical: dimensions.moderate(5) },
})

export default memo(AssetPart)
