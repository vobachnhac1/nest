import { useEffect } from 'react'
import { InteractionManager } from 'react-native'

const useMount = (func) => useEffect(() => func(), [])

// You can create a custom interaction/animation and add
// support for InteractionManager
const useCustomInteraction = (timeLocked = 300) => {
    useMount(() => {
        const handle = InteractionManager.createInteractionHandle()

        setTimeout(() => InteractionManager.clearInteractionHandle(handle), timeLocked)

        return () => InteractionManager.clearInteractionHandle(handle)
    })
}

export default useCustomInteraction
