import React from 'react'

import { PortalContext } from './portalContext'

export const PortalConsumer = ({ gateName, children }) => (
    <PortalContext.Consumer>
        {(value) => (
            <>
                {value.gates[gateName]}
                {children && children(value.teleport)}
            </>
        )}
    </PortalContext.Consumer>
)
