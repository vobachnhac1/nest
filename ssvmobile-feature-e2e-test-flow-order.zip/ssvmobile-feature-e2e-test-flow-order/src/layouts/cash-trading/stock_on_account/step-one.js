import React, { useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { FlatList, Keyboard, StyleSheet, View } from 'react-native'
import { TouchableOpacity } from 'react-native-gesture-handler'
import Svg, { Circle, Path } from 'react-native-svg'
import ToastGlobal from 'react-native-toast-message'
import {} from 'native-base'

import Account from '../../../components/account'
import { ColTableData, RowTableData, RowTitleGroup, StockInfoRowView } from '../../../components/trading-component'
import HeaderList from '../../../components/trading-component/header-list'
import { StoreContext } from '../../../store'
import { StoreTrading } from '../../../store-trading'
import { dimensions as dm, fontSizes as fs } from '../../../styles'
import { eventList, FormatNumber, glb_sv, reqFunct, Screens, sendRequest } from '../../../utils'

// Khai báo ServiceInfo (nếu có)
const ServiceInfo = {
    KEY_GET_STOCK_LIST: {
        reqFunct: reqFunct.KEY_GET_STOCK_LIST, //Lấy "Số dư hiện tại"
        WorkerName: 'FOSqStock',
        ServiceName: 'FOSqStock_0302_6',
        ClientSentTime: '0',
        Operation: 'Q',
        // TestInput: ['1', userInfo.actn_curr, '00']
    },
    KEY_GET_HISTORY: {
        reqFunct: reqFunct.KEY_GET_HISTORY, //Lấy "Số dư hiện tại"
        WorkerName: 'FOSqStock',
        ServiceName: 'FOSqStock_0302_6',
        ClientSentTime: '0',
        Operation: 'Q',
    },
    GET_HIS_PAY_ON_ACCOUT_BY_SUB: {
        reqFunct: reqFunct.GET_HIS_PAY_ON_ACCOUT_BY_SUB, // Lấy DS giao dịch gần nhất theo theo sub
        WorkerName: 'FOSqCash',
        ServiceName: 'FOSqCash_0201_1',
        ClientSentTime: '0',
        Operation: 'Q',
        // TestInput: ["2", "888c000354", "00"]
    },
    GET_HIS_PAY_ON_ACCOUT_BY_ACT: {
        reqFunct: reqFunct.GET_HIS_PAY_ON_ACCOUT_BY_ACT, // Lịch sử giao dịch nộp tiền theo tài khoản
        WorkerName: 'FOSqCash',
        ServiceName: 'FOSqCash_0201_1',
        ClientSentTime: '0',
        Operation: 'Q',
        // TestInput: ["2", "888c000354", "%"]
    },
}

// Khai báo component
const StepOne = ({
    navigation,
    setDataSubCurrTransfer,
    // setResetReceived,
    // resetReceived,
    switchStep,
    setAmountMove,
    setSub_curr2,
    setStkList,
    stkList,
    refreshing,
    checkChangeData,
    onRefresh,
}) => {
    const { styles } = useContext(StoreContext)
    const { userInfo } = useContext(StoreTrading)

    const { t } = useTranslation()
    const colSpan = [3, 3, 4]
    // -------------------------------------------   Khai báo các state nội bộ component

    const [dataListStockCode, setDataListStockCode] = useState([])
    const [dataListHisTransaction, setDataListHisTransaction] = useState([])
    // -------------------------------------------   Dùng useEffect get các dữ liệu cần thiết còn thiếu
    useEffect(() => {
        // Prepare data
        // getCurrentCashBySub(); // Lấy số dư hiện tại
        // getHisPayOnAccountBySub()   // Lấy lịch sử chuyển tiền
        const convert = {}
        glb_sv.mrk_stklist.map((item) => {
            convert[item.t55] = item.U9
        })
        setStkList(convert)
        getListStockCode()

        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.LOGIN_SUCCESS) {
                // reCall service FOSq
                getHisTransaction()
                getListStockCode()
            }
        })

        return () => {
            commonEvent.unsubscribe()
        }
    }, [userInfo.sub_curr])
    useEffect(() => {
        getHisTransaction() // Lấy tất cả lịch sử giao dịch tiền
        getListStockCode()
    }, [glb_sv.checkLoadHistory, checkChangeData])
    useEffect(() => {
        if (refreshing) {
            getHisTransaction()
            getListStockCode()
        }
    }, [refreshing])

    // -------------------------------------------   Viết các hàm để set lại bussiness form state. Nên viết đúng một chuẩn duy nhất để dễ control

    // -------------------------------------------   Khai báo các hàm gửi (request) lên server
    const getListStockCode = () => {
        if (!userInfo.actn_curr) {
            ToastGlobal.show({
                type: 'warning',
                text2: t('warning_account_is_empty'),
            })
            return
        }

        const inputParams = ['1', userInfo.actn_curr, userInfo.sub_curr, '%']
        sendRequest(ServiceInfo.KEY_GET_STOCK_LIST, inputParams, handleGetListStockCode)
    }

    const getHisTransaction = () => {
        const inputParams = ['2', userInfo.actn_curr, '%', '%']
        sendRequest(ServiceInfo.KEY_GET_HISTORY, inputParams, handleGetHisgetHisTransaction)
    }
    // -------------------------------------------   Khai báo các hàm nhận (handle respone) dữ liệu từ server

    // -------------------------------------------   Khai báo các hàm nhận (handle respone) dữ liệu từ server
    const handleGetListStockCode = (reqInfoMap, message) => {
        // -- process after get result --
        if (Number(message.Result) === 0) {
            // console.warn(
            //   'false handleGetListStockCode',
            //   reqInfoMap,
            //   message['Data'],
            //   message['Message'],
            // );
            ToastGlobal.show({
                type: 'warning',
                text2: message.Message,
            })
            setDataListStockCode([])
            return
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {}
            if (Number(message.Packet) <= 0) {
                filterDataListStock(jsondata)
            }
        }
    }
    const filterDataListStock = (data = []) => {
        const result = data.map((item, index) => {
            return item
        })
        setDataListStockCode(result)
    }
    // -----------------------------------------
    const handleGetHisgetHisTransaction = (reqInfoMap, message) => {
        // -- process after get result --
        if (Number(message.Result) === 0) {
            console.warn('false handleGetHisgetHisTransaction', reqInfoMap, message.Data, message.Message)
            return
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {
                console.log(err)
            }

            if (Number(message.Packet) <= 0) {
                // let data = histHisTransaction.current.slice();
                filterDataHisTransaction(jsondata)
            }
        }
    }
    const filterDataHisTransaction = (data = []) => {
        const result = data.map((item, index) => {
            return item
        })
        setDataListHisTransaction(result)
    }
    //---------------------------------------------
    // --------------------------------------------
    const getColor = (status) => {
        if (status === 'N') return styles.REF__COLOR
        if (status === 'R' || status === 'D') return styles.DOWN__COLOR
        if (status === 'Y') return styles.UP__COLOR
    }
    const getColorSub = (sub) => {
        const listColor = [styles.UP__COLOR, styles.REF__COLOR, styles.DOWN__COLOR]
        return listColor[Number(sub)] || styles.REF__COLOR
    }
    const ViewListHisTransaction = ({ item }) => {
        return (
            <>
                <RowTableData
                    key={item.c8}
                    type="table"
                    onPress={() =>
                        navigation.navigate(Screens.DETAIL_STOCK_ON_ACCOUNT, {
                            data: item,
                            onRefresh: onRefresh,
                        })
                    }
                >
                    <ColTableData colSpan={colSpan[1]} text={item.c4} textAlign="center" />
                    <ColTableData colSpan={colSpan[1]} text={item.c6} textAlign="center" />
                    <ColTableData colSpan={colSpan[1]} text={item.c8} textAlign="center" />
                    <ColTableData colSpan={colSpan[1]} text={FormatNumber(item.c9)} textAlign="center" />
                    <ColTableData colorText={getColor(item.c23)} colSpan={colSpan[1]} text={t(item.c29)} textAlign="center" />
                </RowTableData>
            </>
        )
    }

    const IconSelect = (props) => {
        return (
            <TouchableOpacity
                style={{
                    flex: 1,
                    width: dm.moderate(40),
                    justifyContent: 'center',
                    alignItems: 'center',
                }}
                {...props}
            >
                <Svg fill="none" height="32" viewBox="0 0 32 32" width="32" xmlns="http://www.w3.org/2000/svg">
                    <Circle cx="16" cy="16" fill="#2ECC71" opacity="0.1" r="16" />
                    <Path
                        d="M12.8398 24.75C13.5302 24.75 14.0898 24.1904 14.0898 23.5C14.0898 22.8096 13.5302 22.25 12.8398 22.25C12.1495 22.25 11.5898 22.8096 11.5898 23.5C11.5898 24.1904 12.1495 24.75 12.8398 24.75Z"
                        fill="#2ECC71"
                    />
                    <Path
                        d="M21.5898 24.75C22.2802 24.75 22.8398 24.1904 22.8398 23.5C22.8398 22.8096 22.2802 22.25 21.5898 22.25C20.8995 22.25 20.3398 22.8096 20.3398 23.5C20.3398 24.1904 20.8995 24.75 21.5898 24.75Z"
                        fill="#2ECC71"
                    />
                    <Path
                        clip-rule="evenodd"
                        d="M17.2148 14.4375C18.7681 14.4375 20.0273 13.1783 20.0273 11.625C20.0273 10.0717 18.7681 8.8125 17.2148 8.8125C15.6615 8.8125 14.4023 10.0717 14.4023 11.625C14.4023 13.1783 15.6615 14.4375 17.2148 14.4375ZM17.2148 15.375C19.2859 15.375 20.9648 13.6961 20.9648 11.625C20.9648 9.55393 19.2859 7.875 17.2148 7.875C15.1438 7.875 13.4648 9.55393 13.4648 11.625C13.4648 13.6961 15.1438 15.375 17.2148 15.375Z"
                        fill="#2ECC71"
                        fill-rule="evenodd"
                    />
                    <Path
                        clip-rule="evenodd"
                        d="M23.4848 11.7147C23.6102 11.7741 23.7208 11.8606 23.8086 11.968C23.8968 12.0752 23.96 12.2006 23.9938 12.3353C24.0276 12.4699 24.031 12.6104 24.0039 12.7465L22.8789 18.3715C22.8359 18.5839 22.7207 18.775 22.553 18.9123C22.3853 19.0496 22.1753 19.1247 21.9586 19.125H12.5188L12.7391 20.375H22.2148C22.3806 20.375 22.5396 20.4408 22.6568 20.5581C22.774 20.6753 22.8398 20.8342 22.8398 21C22.8398 21.1658 22.774 21.3247 22.6568 21.4419C22.5396 21.5592 22.3806 21.625 22.2148 21.625H12.2148C12.0679 21.625 11.9256 21.5733 11.813 21.4788C11.7005 21.3844 11.6248 21.2533 11.5992 21.1086L9.81563 11H7.83984C7.67408 11 7.51511 10.9342 7.3979 10.8169C7.28069 10.6997 7.21484 10.5408 7.21484 10.375C7.21484 10.2092 7.28069 10.0503 7.3979 9.93306C7.51511 9.81585 7.67408 9.75 7.83984 9.75H10.3398C10.4868 9.74997 10.6291 9.80172 10.7416 9.89616C10.8542 9.9906 10.9299 10.1217 10.9555 10.2664L11.1949 11.625H14.4023C14.4023 13.1783 15.6615 14.4375 17.2148 14.4375C18.7681 14.4375 20.0273 13.1783 20.0273 11.625H23.0836C23.2223 11.6248 23.3594 11.6554 23.4848 11.7147Z"
                        fill="#2ECC71"
                        fill-rule="evenodd"
                    />
                    <Path d="M15.3398 11.625H19.0898" stroke="#2ECC71" stroke-linecap="round" />
                    <Path d="M17.2148 13.5V9.75" stroke="#2ECC71" stroke-linecap="round" />
                </Svg>
            </TouchableOpacity>
        )
    }

    return (
        <View style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
            <RowTitleGroup text={t('trans_sub_account')} />
            <Account navigation={navigation} />
            {dataListStockCode.length > 0 ? <RowTitleGroup hasDivider text={t('stock_list_short')} /> : null}
            {dataListStockCode.map((item, index) => {
                return (
                    <StockInfoRowView
                        iconRight={<IconSelect />}
                        qty={FormatNumber(item.c6)}
                        qtyNote={t('stock_available') + ' '}
                        stockName={stkList[item.c4]}
                        stockSymbol={item.c4}
                        key={String(Math.random())}
                        // type="buy"
                        onPress={() => {
                            setDataSubCurrTransfer({
                                dataActn_curr: userInfo.actn_curr,
                                dataSub_curr: userInfo.sub_curr,
                                stockAmount: item.c6,
                                codeCk: item.c4,
                                nameCk: item.nameCK,
                            })
                            let defaultSub2 = userInfo.sub_list[0] === userInfo.sub_curr ? userInfo.sub_list[1] : userInfo.sub_list[0]
                            setSub_curr2(defaultSub2)
                            setAmountMove('')
                            switchStep.next()
                            Keyboard.dismiss()
                        }}
                    />
                )
            })}
            <RowTitleGroup hasDivider text={t('transaction_history')} />
            <HeaderList typeHeader="TRANSACTION_HISTORY" />
            <FlatList
                data={dataListHisTransaction}
                keyExtractor={(item, index) => index.toString()}
                renderItem={ViewListHisTransaction}
                style={{
                    marginBottom: dm.vertical(32),
                    paddingHorizontal: dm.moderate(16),
                }}
            />
        </View>
    )
}

export default StepOne

const UI = StyleSheet.create({
    Button: {
        alignItems: 'center',
        borderRadius: 4,
        height: dm.moderate(16),
        justifyContent: 'center',
        marginLeft: 4,
        width: dm.moderate(16),
    },
    GroupInput: {
        marginVertical: dm.halfVerticalIndent,
        paddingHorizontal: dm.halfIndent,
    },
    RowInput: {
        marginLeft: dm.moderate(8),
        marginVertical: dm.vertical(8),
    },
    Row_view: {
        flex: 1,
        paddingBottom: dm.vertical(8),
        paddingTop: dm.vertical(8),
    },
    current_cash: {
        fontSize: fs.medium,
    },
    flex1: {
        flex: 1,
    },
    margin_top_row: {
        marginBottom: dm.moderate(24),
        marginHorizontal: dm.moderate(16),
        marginTop: dm.moderate(16),
    },
    name_act: {
        flex: 4,
        flexDirection: 'row',
        paddingTop: dm.halfVerticalIndent,
        paddingVertical: 5,
    },
    view_lasttransfer: {
        borderRadius: 8,
        height: dm.halfVerticalIndent * 8,
        marginHorizontal: dm.halfIndent,
        paddingHorizontal: dm.halfVerticalIndent,
        width: dm.indent * 9,
    },
})
