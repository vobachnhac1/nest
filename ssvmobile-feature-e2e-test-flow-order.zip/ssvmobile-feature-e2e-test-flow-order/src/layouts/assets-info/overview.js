import React, { memo, useContext, useEffect, useMemo, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import {
    ActivityIndicator,
    FlatList,
    InteractionManager,
    Platform,
    RefreshControl,
    SafeAreaView,
    ScrollView,
    StyleSheet,
    TouchableOpacity,
    View,
} from 'react-native'
import Svg, { Path } from 'react-native-svg'
import { orderBy } from 'lodash'
import throttle from 'lodash/throttle'
import uniq from 'lodash/uniq'

import { Text } from '../../basic-components'
import { EmptyView, RowTitleGroup } from '../../components/trading-component'
import ErrorView from '../../components/trading-component/error-view'
import { allowCompanyRender, preventCompanyRender, useCustomInteraction } from '../../hoc'
import { StoreContext } from '../../store'
import { StoreTrading } from '../../store-trading'
import { dimensions, fontSizes, fontWeights } from '../../styles'
import { eventList, FormatNumber, glb_sv, reqFunct, sendRequest, subcribeFunct } from '../../utils'
import { RowAssetsStock } from '../assets-layout/components/RowAssetsStock'

const ServiceInfo = {
    GET_ASSETS_TOTAL_INFO: {
        reqFunct: reqFunct.GET_ASSETS_TOTAL_INFO,
        WorkerName: 'FOSqAsset',
        ServiceName: 'FOSqAsset_1801_1',
        Operation: 'Q',
        ClientSentTime: '0',
    },
    GET_ASSETS_STOCK_LIST: {
        reqFunct: reqFunct.GET_ASSETS_STOCK_LIST + 'ASSETS_OVERVIEW',
        WorkerName: 'FOSqAsset',
        ServiceName: 'FOSqAsset_1801_1',
        Operation: 'Q',
        ClientSentTime: '0',
    },
}

const DEFAUT_THROTTLE_TIME = Platform.select({ ios: 1000, android: 2000, default: 2000 })

function OverviewInfo({ navigation, isActive }) {
    useCustomInteraction()

    const { styles } = useContext(StoreContext)
    const { userInfo } = useContext(StoreTrading)

    const { t } = useTranslation()

    const [data, setData] = useState({})
    const [dataStock, setDataStock] = useState([])
    const tempList = useRef([])

    const [refreshing, setRefresh] = useState(false)
    const timeoutRefresh = useRef(null)
    const mounted = useRef(true)
    const [totalValue, setTotalValue] = useState(0)
    const [totalValueRatio, setTotalValueRatio] = useState(0)
    const isHideGuaranteeAndMargin = glb_sv.activeCode === '023'

    const subStockList = useRef([])
    const timeoutSub = useRef(null)

    // State for table stock own
    // New config sort
    const SORT_CONFIG = {
        column01: ['c2|desc', 'c2|asc', 'c25|desc', 'c25|asc'], // Sort mã CK và số lượng
        column02: ['c17|desc', 'c17|asc'], // Sort giá vốn
        column03: ['c18|desc', 'c18|asc'], // Sort Vốn
        column04: ['c19|desc', 'c19|asc'], // Sort giá trị lãi lỗ
    }
    const activeSortColumnRef = useRef('')
    const activeSortKeyRef = useRef('')
    // --------------
    useEffect(() => {
        activeSortColumnRef.current = ''
        activeSortKeyRef.current = ''
    }, [userInfo])

    const [statusSellStkList, setStatus] = useState('')

    const throttled = useRef(
        throttle(
            () => {
                tempList.current.forEach((item, index) => {
                    const stockInfo = glb_sv.StockMarket[item.c2] || { t31: item.c15 }
                    item.c17 = Number(item.c17)
                    item.c25 = Number(item.c25)
                    item.c15 = stockInfo.t31 || item.c15
                    // ------------------------------
                    // IVS: Giá trị TB = Giá vốn * Tổng (không bao gồm SL quyền)
                    const AVG_values = allowCompanyRender(['061']) ? Number(item.c25) : Number(item.c25) + Number(item.c14)

                    item.c18 = item.c17 * AVG_values
                    // IVS: Giá trị TT = Giá TT * Tổng (không bao gồm SL quyền)
                    item.c16 = item.c15 * AVG_values
                    // ------------------------------
                    item.c19 = (item.c15 - item.c17) * AVG_values
                    item.c20 = item.c17 == 0 ? 100 : Math.round(((item.c15 - item.c17) / item.c17) * 10000) / 100
                    item.t31_incr_per = stockInfo.t31_incr_per || 0
                    // console.log('t31_incr_per', stockInfo.t31_incr_per)
                })

                const avg_buy_values = tempList.current.reduce(function (a, b) {
                    return a + Number(b.c18)
                }, 0)
                const total = tempList.current.reduce(function (a, b) {
                    return a + Number(b.c19)
                }, 0)

                setTotalValue(total)
                setTotalValueRatio(!avg_buy_values ? 0 : Math.round((total / avg_buy_values) * 10000) / 100)
                setDataStock(tempList.current)
            },
            DEFAUT_THROTTLE_TIME,
            { trailing: true },
        ),
    )

    useEffect(() => {
        const eventMarket = glb_sv.eventMarket.subscribe((msg) => {
            if (msg.type === eventList.SUB_STOCK && msg.message === 'SI') {
                throttled.current()
            } else if (msg.type === eventList.RECONNECT_MARKET) {
                if (subStockList.current.length) {
                    InteractionManager.runAfterInteractions(() => {
                        subcribeFunct(null, null, 'SUB', ['MDDS|SI'], subStockList.current)
                    })
                }
            }
        })

        return () => {
            eventMarket.unsubscribe()
            throttled.current.cancel()
            if (subStockList.current.length) {
                InteractionManager.runAfterInteractions(() => {
                    subcribeFunct(null, null, 'UNSUB', ['MDDS|SI'], subStockList.current)
                })
            }
        }
    }, [])

    useEffect(() => {
        mounted.current = true
        if (isActive) {
            if (timeoutRefresh.current) clearTimeout(timeoutRefresh.current)
            timeoutRefresh.current = setTimeout(() => {
                setRefresh(true)
                getAssetsTotalInfo()
            }, 100)
        }

        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.LOGIN_SUCCESS) {
                if (isActive) {
                    if (timeoutRefresh.current) clearTimeout(timeoutRefresh.current)
                    timeoutRefresh.current = setTimeout(() => {
                        getAssetsTotalInfo()
                    }, 100)
                }
            }
        })

        return () => {
            mounted.current = false
            commonEvent.unsubscribe()
        }
    }, [userInfo, isActive])

    const getAssetsTotalInfo = () => {
        const { actn_curr, sub_curr } = userInfo
        if (!actn_curr || !sub_curr) {
            // [broker] - Nếu không có tài khoản sub thì không gửi request
            return
        }
        // ---------
        if (!mounted.current) return
        const InputParams = ['01', actn_curr, sub_curr]
        sendRequest(ServiceInfo.GET_ASSETS_TOTAL_INFO, InputParams, getAssetsTotalInfoResult, true, getAssetsTotalInfoTimeout, '', 0, 'equal_service')
        setData({})
    }

    const getAssetsTotalInfoTimeout = () => {
        setRefresh(false)
        getAssetsStockList()
    }

    const getAssetsTotalInfoResult = (reqInfoMap, message) => {
        if (!mounted.current) return
        setRefresh(false)
        getAssetsStockList()
        if (Number(message.Result) === 0) {
            return
        } else {
            try {
                const jsondata = message.Data ? JSON.parse(message.Data)[0] : {}
                setData(jsondata)
            } catch (err) {}
        }
    }

    const getAssetsStockList = () => {
        const { actn_curr, sub_curr } = userInfo
        if (!actn_curr || !sub_curr) {
            // [broker] - Nếu không có tài khoản sub thì không gửi request
            return
        }
        // ---------
        if (!mounted.current) return
        const InputParams = ['02', actn_curr, sub_curr]
        sendRequest(ServiceInfo.GET_ASSETS_STOCK_LIST, InputParams, getAssetsStockListResult, true, getAssetsStockListTimeout)
        tempList.current = []
        setDataStock([])
        setStatus('loading')
    }

    const getAssetsStockListTimeout = () => {
        setRefresh(false)
        setStatus('error')
    }

    const getAssetsStockListResult = (reqInfoMap, message) => {
        // console.log("getAssetsStockListResult -> message", message)
        if (!mounted.current) return
        setStatus('done')
        setRefresh(false)
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {
                console.log('getAssetsStockListResult', err)
                return
            }
            tempList.current = tempList.current.concat(jsondata)
            if (Number(message.Packet) <= 0) {
                // Convert data for sort
                tempList.current.forEach((item, index) => {
                    item._c25 = Number(item.c25)
                    item._c16 = Number(item.c16)
                    item._c19 = Number(item.c19)
                })

                setDataStock([...tempList.current])

                const avg_buy_values = tempList.current.reduce(function (a, b) {
                    return a + Number(b.c18)
                }, 0)
                const total = tempList.current.reduce(function (a, b) {
                    return a + Number(b.c19)
                }, 0)

                setTotalValue(total)
                setTotalValueRatio(!avg_buy_values ? 0 : Math.round((total / avg_buy_values) * 10000) / 100)

                const list_stock = uniq(tempList.current.map((e) => e.c2))
                if (subStockList.current.length) {
                    subcribeFunct(null, null, 'UNSUB', ['MDDS|SI'], subStockList.current)
                }
                subStockList.current = list_stock
                if (subStockList.current.length) {
                    timeoutSub.current = setTimeout(() => {
                        subcribeFunct(null, null, 'SUB', ['MDDS|SI'], subStockList.current)
                    }, 1000)
                    setTimeout(() => {
                        throttled.current()
                    }, 4000)
                }
            }
        }
    }

    const onRefresh = () => {
        if (refreshing) return
        if (!mounted.current) return
        setRefresh(true)
        if (timeoutRefresh.current) clearTimeout(timeoutRefresh.current)
        timeoutRefresh.current = setTimeout(() => {
            getAssetsTotalInfo()
        }, 100)
    }

    // -------
    const CellContentUI = {
        fontWeight: fontWeights.bold,
        fontSize: fontSizes.verySmall,
        textAlign: 'right',
        color: styles.HEADER__CONTENT__COLOR,
    }
    // ---------
    const sortAssets = (column) => {
        activeSortColumnRef.current = column
        // ---------------------
        const sortList = SORT_CONFIG[column] || []
        const activeKey = activeSortKeyRef.current
        const indexActive = sortList.findIndex((key) => key === activeKey)
        const nextActiveKey = sortList[(indexActive + 1) % sortList.length]
        activeSortKeyRef.current = nextActiveKey
        // console.log('sortAssets', activeSortColumnRef.current, activeSortKeyRef.current)
        // -------------
        if (nextActiveKey) {
            const [sortKey, typeSort] = nextActiveKey.split('|')
            const afterSort = orderBy(dataStock, [sortKey], [typeSort])
            tempList.current = afterSort
            setDataStock(afterSort)
        } else {
            tempList.current = dataStock
            setDataStock(dataStock)
        }
    }
    // -------
    const HeaderListAssetsStock = () => {
        return (
            <>
                <RowTitleGroup hasDivider text={t('stk_own_list')} type="group" />
                <View style={{ flexDirection: 'row', paddingHorizontal: dimensions.moderate(4) }}>
                    <View style={{ flex: 2 }}>
                        <TouchableOpacity onPress={() => sortAssets('column01')}>
                            <View style={UI.HeaderColInside}>
                                <View>
                                    <Text
                                        style={{
                                            fontWeight: fontWeights.bold,
                                            fontSize: fontSizes.verySmall,
                                            textAlign: 'left',
                                            color: activeSortKeyRef.current?.includes('c2|') ? styles.PRIMARY : styles.HEADER__CONTENT__COLOR,
                                            flex: 1.2,
                                        }}
                                    >
                                        {t('stock_symbol_short')}
                                    </Text>
                                    <Text
                                        style={[
                                            CellContentUI,
                                            { color: activeSortKeyRef.current?.includes('c25|') ? styles.PRIMARY : styles.HEADER__CONTENT__COLOR },
                                        ]}
                                    >
                                        {t('common_amount')}
                                    </Text>
                                </View>
                                <View style={{ paddingLeft: 0 }}>
                                    <Svg height={13} viewBox="0 0 12 13" width={12}>
                                        <Path
                                            d="M2.519 7.734l2.84 3.315a.488.488 0 00.74 0l2.84-3.315a.488.488 0 00-.37-.804h-5.68a.487.487 0 00-.37.804z"
                                            fill={
                                                activeSortColumnRef.current === 'column01' && activeSortKeyRef.current?.includes('desc')
                                                    ? styles.PRIMARY
                                                    : styles.ICON__UN__ACTIVE
                                            }
                                        />
                                        <Path
                                            d="M2.519 4.784l2.84-3.314a.488.488 0 01.74 0l2.84 3.314a.488.488 0 01-.37.805h-5.68a.487.487 0 01-.37-.805z"
                                            fill={
                                                activeSortColumnRef.current === 'column01' && activeSortKeyRef.current?.includes('asc')
                                                    ? styles.PRIMARY
                                                    : styles.ICON__UN__ACTIVE
                                            }
                                        />
                                    </Svg>
                                </View>
                            </View>
                        </TouchableOpacity>
                    </View>
                    <View style={{ flex: 3 }}>
                        <TouchableOpacity onPress={() => sortAssets('column02')}>
                            <View style={[UI.HeaderColInside, { justifyContent: 'flex-end' }]}>
                                <View>
                                    <Text
                                        style={[
                                            CellContentUI,
                                            { color: activeSortKeyRef.current?.includes('c17|') ? styles.PRIMARY : styles.HEADER__CONTENT__COLOR },
                                        ]}
                                    >
                                        {t('cost_price')}
                                    </Text>
                                    <Text style={CellContentUI}>{t('present_price')}</Text>
                                </View>
                                <View style={{ paddingLeft: 2 }}>
                                    <Svg height={13} viewBox="0 0 12 13" width={12}>
                                        <Path
                                            d="M2.519 7.734l2.84 3.315a.488.488 0 00.74 0l2.84-3.315a.488.488 0 00-.37-.804h-5.68a.487.487 0 00-.37.804z"
                                            fill={
                                                activeSortColumnRef.current === 'column02' && activeSortKeyRef.current?.includes('desc')
                                                    ? styles.PRIMARY
                                                    : styles.ICON__UN__ACTIVE
                                            }
                                        />
                                        <Path
                                            d="M2.519 4.784l2.84-3.314a.488.488 0 01.74 0l2.84 3.314a.488.488 0 01-.37.805h-5.68a.487.487 0 01-.37-.805z"
                                            fill={
                                                activeSortColumnRef.current === 'column02' && activeSortKeyRef.current?.includes('asc')
                                                    ? styles.PRIMARY
                                                    : styles.ICON__UN__ACTIVE
                                            }
                                        />
                                    </Svg>
                                </View>
                            </View>
                        </TouchableOpacity>
                    </View>

                    <View style={{ flex: 4 }}>
                        <TouchableOpacity onPress={() => sortAssets('column03')}>
                            <View style={[UI.HeaderColInside, { justifyContent: 'flex-end' }]}>
                                <View>
                                    <Text
                                        style={[
                                            CellContentUI,
                                            { color: activeSortKeyRef.current?.includes('c18|') ? styles.PRIMARY : styles.HEADER__CONTENT__COLOR },
                                        ]}
                                    >
                                        {t('cost')}
                                    </Text>
                                    <Text
                                        style={[
                                            CellContentUI,
                                            // { color: activeSortKeyRef.current?.includes('c18|') ? styles.PRIMARY : styles.HEADER__CONTENT__COLOR },
                                        ]}
                                    >
                                        {t('present_values')}
                                    </Text>
                                </View>
                                <View style={{ paddingLeft: 2 }}>
                                    <Svg height={13} viewBox="0 0 12 13" width={12}>
                                        <Path
                                            d="M2.519 7.734l2.84 3.315a.488.488 0 00.74 0l2.84-3.315a.488.488 0 00-.37-.804h-5.68a.487.487 0 00-.37.804z"
                                            fill={
                                                activeSortColumnRef.current === 'column03' && activeSortKeyRef.current?.includes('desc')
                                                    ? styles.PRIMARY
                                                    : styles.ICON__UN__ACTIVE
                                            }
                                        />
                                        <Path
                                            d="M2.519 4.784l2.84-3.314a.488.488 0 01.74 0l2.84 3.314a.488.488 0 01-.37.805h-5.68a.487.487 0 01-.37-.805z"
                                            fill={
                                                activeSortColumnRef.current === 'column03' && activeSortKeyRef.current?.includes('asc')
                                                    ? styles.PRIMARY
                                                    : styles.ICON__UN__ACTIVE
                                            }
                                        />
                                    </Svg>
                                </View>
                            </View>
                        </TouchableOpacity>
                    </View>
                    <View style={{ flex: 3 }}>
                        <TouchableOpacity onPress={() => sortAssets('column04')}>
                            <View style={[UI.HeaderColInside, { justifyContent: 'flex-end' }]}>
                                <View>
                                    <Text
                                        style={[
                                            CellContentUI,
                                            { color: activeSortKeyRef.current?.includes('c19|') ? styles.PRIMARY : styles.HEADER__CONTENT__COLOR },
                                        ]}
                                    >
                                        {t('common_profit')}
                                    </Text>

                                    <Text style={CellContentUI}>{t('profit_ratio')}</Text>
                                </View>
                                <View style={{ paddingLeft: 2 }}>
                                    <Svg height={13} viewBox="0 0 12 13" width={12}>
                                        <Path
                                            d="M2.519 7.734l2.84 3.315a.488.488 0 00.74 0l2.84-3.315a.488.488 0 00-.37-.804h-5.68a.487.487 0 00-.37.804z"
                                            fill={
                                                activeSortColumnRef.current === 'column04' && activeSortKeyRef.current?.includes('desc')
                                                    ? styles.PRIMARY
                                                    : styles.ICON__UN__ACTIVE
                                            }
                                        />
                                        <Path
                                            d="M2.519 4.784l2.84-3.314a.488.488 0 01.74 0l2.84 3.314a.488.488 0 01-.37.805h-5.68a.487.487 0 01-.37-.805z"
                                            fill={
                                                activeSortColumnRef.current === 'column04' && activeSortKeyRef.current?.includes('asc')
                                                    ? styles.PRIMARY
                                                    : styles.ICON__UN__ACTIVE
                                            }
                                        />
                                    </Svg>
                                </View>
                            </View>
                        </TouchableOpacity>
                    </View>
                </View>
            </>
        )
    }

    const filterSoldStock = (list = []) => {
        if (!preventCompanyRender(['081'])) {
            // Remove các mã đã bán hết
            return list.filter((x) => x.c4 !== 0 || x.c25 + x.c14 !== 0)
        } else {
            return list
        }
    }

    return (
        <>
            <ScrollView
                refreshControl={
                    <RefreshControl
                        refreshing={refreshing}
                        onRefresh={onRefresh}
                        // title={t('pull_refresh')}
                        // titleColor={styles.PRIMARY__CONTENT__COLOR}
                        tintColor={styles.PRIMARY__CONTENT__COLOR}
                    />
                }
                showsVerticalScrollIndicator={false}
                style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}
            >
                <RowTitleGroup text={t('cash_assets')} type="group" />

                <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                    <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('cash_available')}</Text>
                    <Text style={{ color: styles.PRIMARY, fontSize: fontSizes.small, fontWeight: fontWeights.bold, flex: 1, textAlign: 'right' }}>
                        {FormatNumber(data.c5, 0)}
                    </Text>
                </View>

                <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                    <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('cash_in_custody')}</Text>
                    <Text
                        style={{
                            color: styles.PRIMARY__CONTENT__COLOR,
                            fontSize: fontSizes.small,
                            fontWeight: fontWeights.medium,
                            flex: 1,
                            textAlign: 'right',
                        }}
                    >
                        {FormatNumber(data.c3, 0)}
                    </Text>
                </View>
                <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                    <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('amount_blockade')}</Text>
                    <Text
                        style={{
                            color: styles.PRIMARY__CONTENT__COLOR,
                            fontSize: fontSizes.small,
                            fontWeight: fontWeights.medium,
                            flex: 1,
                            textAlign: 'right',
                        }}
                    >
                        {`${FormatNumber(data.c4) !== '0' ? '-' : ''} ${FormatNumber(data.c4)}`}
                    </Text>
                </View>

                <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                    <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('cash_sale_available')}</Text>
                    <Text
                        style={{
                            color: styles.PRIMARY__CONTENT__COLOR,
                            fontSize: fontSizes.small,
                            fontWeight: fontWeights.medium,
                            flex: 1,
                            textAlign: 'right',
                        }}
                    >
                        {FormatNumber(data.c8, 0)}
                    </Text>
                </View>

                {isHideGuaranteeAndMargin ? null : (
                    <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                        <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('guarantee_cash_use')}</Text>
                        <Text
                            style={{
                                color: styles.PRIMARY__CONTENT__COLOR,
                                fontSize: fontSizes.small,
                                fontWeight: fontWeights.medium,
                                flex: 1,
                                textAlign: 'right',
                            }}
                        >
                            {FormatNumber(data.c7, 0)}
                        </Text>
                    </View>
                )}

                <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                    <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('market_value')}</Text>
                    <Text
                        style={{
                            color: styles.PRIMARY__CONTENT__COLOR,
                            fontSize: fontSizes.small,
                            fontWeight: fontWeights.medium,
                            flex: 1,
                            textAlign: 'right',
                        }}
                    >
                        {FormatNumber(data.c10, 0)}
                    </Text>
                </View>

                <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                    <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('advance_debt')}</Text>
                    <Text
                        style={{
                            color: styles.PRIMARY__CONTENT__COLOR,
                            fontSize: fontSizes.small,
                            fontWeight: fontWeights.medium,
                            flex: 1,
                            textAlign: 'right',
                        }}
                    >
                        {FormatNumber(data.c18, 0)}
                    </Text>
                </View>

                {isHideGuaranteeAndMargin ? null : (
                    <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                        <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('current_marin_loan')}</Text>
                        <Text
                            style={{
                                color: styles.PRIMARY__CONTENT__COLOR,
                                fontSize: fontSizes.small,
                                fontWeight: fontWeights.medium,
                                flex: 1,
                                textAlign: 'right',
                            }}
                        >
                            {FormatNumber(data.c16, 0)}
                        </Text>
                    </View>
                )}

                <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                    <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('cash_right_wait')}</Text>
                    <Text
                        style={{
                            color: styles.PRIMARY__CONTENT__COLOR,
                            fontSize: fontSizes.small,
                            fontWeight: fontWeights.medium,
                            flex: 1,
                            textAlign: 'right',
                        }}
                    >
                        {FormatNumber(data.c9, 0)}
                    </Text>
                </View>

                <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                    <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('buying_waitting_stock_of_right')}</Text>
                    <Text
                        style={{
                            color: styles.PRIMARY__CONTENT__COLOR,
                            fontSize: fontSizes.small,
                            fontWeight: fontWeights.medium,
                            flex: 1,
                            textAlign: 'right',
                        }}
                    >
                        {FormatNumber(data.c11, 0)}
                    </Text>
                </View>

                <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                    <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('total_assets_temporary')}</Text>
                    <Text
                        style={{
                            color: styles.PRIMARY__CONTENT__COLOR,
                            fontSize: fontSizes.small,
                            fontWeight: fontWeights.medium,
                            flex: 1,
                            textAlign: 'right',
                        }}
                    >
                        {FormatNumber(data.c23, 0)}
                    </Text>
                </View>

                <View style={[UI.row, { borderBottomWidth: 0, borderBottomColor: styles.DIVIDER__COLOR }]}>
                    <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('net_assets')}</Text>
                    <Text
                        style={{
                            color: styles.PRIMARY__CONTENT__COLOR,
                            fontSize: fontSizes.small,
                            fontWeight: fontWeights.medium,
                            flex: 1,
                            textAlign: 'right',
                        }}
                    >
                        {FormatNumber(data.c24, 0)}
                    </Text>
                </View>

                <HeaderListAssetsStock />

                {statusSellStkList === 'loading' ? (
                    <View style={{ height: 100, justifyContent: 'center' }}>
                        <ActivityIndicator color={styles.PRIMARY__CONTENT__COLOR} size={30} />
                    </View>
                ) : null}
                {statusSellStkList === 'error' ? <ErrorView refresh={getAssetsStockList} /> : null}
                {statusSellStkList === 'done' ? (
                    <FlatList
                        data={dataStock}
                        keyboardShouldPersistTaps="always"
                        keyExtractor={(item, index) => index.toString()}
                        ListEmptyComponent={EmptyView}
                        renderItem={({ item }) => <RowAssetsStock item={item} />}
                        style={{ marginBottom: 10 }}
                        removeClippedSubviews={true} // https://reactnative.dev/docs/optimizing-flatlist-configuration#removeclippedsubviews
                        // extraData={dataStock}
                        scrollEnabled={false}
                    />
                ) : null}
            </ScrollView>
            <View style={{ backgroundColor: styles.PRIMARY__BG__COLOR, marginTop: -1 }}>
                <View
                    style={[
                        UI.view_total,
                        {
                            borderColor: totalValue >= 0 ? styles.UP__COLOR : styles.DOWN__COLOR,
                            backgroundColor: totalValue >= 0 ? styles.UP__COLOR + '1a' : styles.DOWN__COLOR + '1a',
                        },
                    ]}
                >
                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                        <Text
                            style={{
                                fontSize: fontSizes.small,
                                fontWeight: fontWeights.bold,
                                color: styles.PRIMARY__CONTENT__COLOR,
                                marginLeft: dimensions.moderate(4),
                            }}
                        >
                            {t('total_value_profit_loss')}
                        </Text>
                    </View>

                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                        <Text
                            style={{
                                color: totalValue >= 0 ? styles.UP__COLOR : styles.DOWN__COLOR,
                                fontSize: fontSizes.small,
                                fontWeight: fontWeights.medium,
                                textAlign: 'right',
                            }}
                        >
                            {FormatNumber(totalValue)}
                        </Text>

                        <Text
                            style={{
                                color: totalValue >= 0 ? styles.UP__COLOR : styles.DOWN__COLOR,
                                fontSize: fontSizes.verySmall,
                                opacity: 0.65,
                                textAlign: 'right',
                            }}
                        >
                            {' ('}
                            {FormatNumber(totalValueRatio, 2)}
                            {'%)'}
                        </Text>
                    </View>
                </View>
            </View>
        </>
    )
}

export default memo(OverviewInfo)

const UI = StyleSheet.create({
    HeaderColInside: {
        alignItems: 'center',
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'flex-start',
    },
    TextButtonUI: { color: 'white', fontSize: fontSizes.small, fontWeight: fontWeights.bold },
    TextProfitUI: {
        flex: 3,
        fontSize: fontSizes.verySmall,
        fontWeight: fontWeights.bold,
        textAlign: 'right',
    },
    container: {
        backgroundColor: 'red',
        height: 300,
        justifyContent: 'center',
    },
    renderContentRow2: { alignItems: 'center', display: 'flex', flexDirection: 'row', justifyContent: 'space-between' },
    renderContentWrap: { display: 'flex', flexDirection: 'row', justifyContent: 'space-between', marginVertical: dimensions.moderate(5) },
    row: {
        borderBottomWidth: 1,
        flexDirection: 'row',
        paddingHorizontal: dimensions.vertical(8),
        paddingVertical: dimensions.vertical(8),
    },
    text_body: {
        flex: 1,
        fontSize: fontSizes.tiny,
        fontWeight: fontWeights.medium,
        paddingRight: 3,
        textAlign: 'right',
    },
    text_body_smallest: {
        flex: 1,
        fontSize: fontSizes.tiny,
        fontWeight: fontWeights.medium,
        paddingRight: 3,
        textAlign: 'right',
    },
    text_header: {
        flex: 1,
        fontSize: fontSizes.verySmall,
        fontWeight: fontWeights.bold,
        paddingRight: 3,
        textAlign: 'right',
    },
    view_total: {
        borderRadius: 8,
        borderWidth: 0.5,
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginHorizontal: dimensions.moderate(8),
        marginVertical: 8,
        padding: dimensions.moderate(10),
    },
})
