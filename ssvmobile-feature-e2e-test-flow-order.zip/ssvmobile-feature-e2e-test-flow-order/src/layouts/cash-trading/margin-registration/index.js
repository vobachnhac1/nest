import React, { useCallback, useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { FlatList, RefreshControl, StyleSheet, Text, View } from 'react-native'
import RenderHTML from 'react-native-render-html'
import ToastGlobal from 'react-native-toast-message'
import ModalController from '@mts-components/appModal/modalControlller'
import moment from 'moment'
import { Container } from 'native-base'

import HeaderComponent from '../../../components/header'
import { ButtonCustom, RowTitleGroup } from '../../../components/trading-component'
import EmptyView from '../../../components/trading-component/empty-view'
import HeaderList from '../../../components/trading-component/header-list'
import { StoreContext } from '../../../store'
import { StoreTrading } from '../../../store-trading'
import { dimensions as dm, fontSizes, fontWeights, IconSvg } from '../../../styles'
import { reqFunct, Screens, wait } from '../../../utils'
import sendRequest from '../../../utils/sendRequest'
import { MarginItem } from './components/MarginItem'

const INPUT_DATE_FORMAT = 'YYYYMMDD'
// Khai báo ServiceInfo (nếu có)
const ServiceInfo = {
    APPLY_MARGIN_SERVICE: {
        reqFunct: reqFunct.APPLY_MARGIN_SERVICE,
        WorkerName: 'FOSxAccount01',
        ServiceName: 'FOSxAccount01_RegMargin_Online_Cus',
        Operation: 'I',
        ClientSentTime: '0',
    },
    GET_LIST_REGISTER_MARGIN: {
        reqFunct: reqFunct.GET_LIST_REGISTER_MARGIN,
        WorkerName: 'FOSqCommon',
        ServiceName: 'FOSqCommon_QueryEContract',
        Operation: 'Q',
    },
}

// Khai báo component
const MarginRegistration = ({ navigation }) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()
    const colSpan = [1, 3, 2]
    const [refreshing, setRefreshing] = useState(false)
    const [isDisable, setIsDisable] = useState(false)
    const [listEContract, setListEContract] = useState([])
    const { userInfo } = useContext(StoreTrading)

    useEffect(() => {
        getListEContract()
    }, [])

    const sendContact = () => {
        const inputParams = [userInfo.actn_curr]
        sendRequest(ServiceInfo.APPLY_MARGIN_SERVICE, inputParams, handleSendContactResult, true, handleSendContactTimeout)
    }

    const confirmSendApplyMargin = () => {
        navigation.navigate(Screens.OTP_MODAL, {
            hasOTP: false,
            functCallback: sendContact,
        })
    }

    const getListEContract = () => {
        const fromDate = moment().subtract(10, 'years').format(INPUT_DATE_FORMAT)
        const toDate = moment().format(INPUT_DATE_FORMAT)
        const InputParams = [fromDate, toDate, '2']
        setListEContract([])
        sendRequest(ServiceInfo.GET_LIST_REGISTER_MARGIN, InputParams, (_, message) => {
            if (Number(message.Result === 0)) {
                return
            } else {
                let jsonData
                if (!message.Data) return
                try {
                    jsonData = JSON.parse(message.Data)

                    /// Case 4 #1407: Customer finish EKYC and signed Opening E-contract
                    /// and SIGNED Margin E-contract
                    if (jsonData.some((e) => e.c4 === 'Y')) {
                        setIsDisable(true)
                    } else {
                        setIsDisable(false)
                    }

                    setListEContract(jsonData)
                } catch (err) {
                    ToastGlobal.show({
                        text2: message.Message,
                        type: 'warning',
                    })
                    return
                }
            }
        })
    }

    const ApplyMarginSuccessContent = () => {
        const escapeHtml = (text) => {
            return text
                .replace(/&amp;/g, '&')
                .replace(/&lt;/g, '<')
                .replace(/&gt;/g, '>')
                .replace(/&quot/g, '"')
                .replace(/&#039;/g, "'")
        }
        const tagsStyles = {
            strong: {
                color: styles.PRIMARY,
            },
        }

        return (
            <RenderHTML
                baseStyle={{
                    fontSize: fontSizes.normal,
                    color: styles.PRIMARY__CONTENT__COLOR,
                    overflow: 'visible',
                    textAlign: 'justify',
                    marginLeft: 8,
                    marginRight: 8,
                    marginBottom: 16,
                }}
                source={{
                    html: escapeHtml(t('apply_margin_success')),
                }}
                tagsStyles={tagsStyles}
            />
        )
    }

    const handleSendContactResult = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            if (message.Code === '010611') {
                // navigation.navigate(Screens.ALERT_MODAL, {
                // icon: <IconSvg.ErrorIcon color={styles.PRIMARY} />,
                // title: t('common_notify'),
                // typeColor: styles.PRIMARY,
                // middleComponent: <ApplyMarginSuccessContent />,
                // })
                ModalController.showModal({
                    icon: <IconSvg.ErrorIcon color={styles.PRIMARY} />,
                    title: t('common_notify'),
                    typeColor: styles.PRIMARY,
                    middleComponent: <ApplyMarginSuccessContent />,
                })
            } else {
                // navigation.navigate(Screens.ALERT_MODAL, {
                //     icon: <IconSvg.ErrorIcon color={styles.PRIMARY} />,
                //     title: t('common_notify'),
                //     typeColor: styles.PRIMARY,
                //     content: message.Message,
                // })
                ModalController.showModal({
                    icon: <IconSvg.ErrorIcon color={styles.PRIMARY} />,
                    title: t('common_notify'),
                    typeColor: styles.PRIMARY,
                    content: message.Message,
                })
            }
        } else {
            if (Number(message.Packet) <= 0) {
                // navigation.navigate(Screens.ALERT_MODAL, {
                // icon: <IconSvg.ErrorIcon color={styles.PRIMARY} />,
                // title: t('common_notify'),
                // typeColor: styles.PRIMARY,
                // middleComponent: <ApplyMarginSuccessContent />,
                // linkCallback: getListEContract,
                // })
                ModalController.showModal({
                    icon: <IconSvg.ErrorIcon color={styles.PRIMARY} />,
                    title: t('common_notify'),
                    typeColor: styles.PRIMARY,
                    middleComponent: <ApplyMarginSuccessContent />,
                    linkCallback: () => {
                        getListEContract()
                    },
                })
            }
        }
    }

    const handleSendContactTimeout = (e) => {
        ToastGlobal.show({
            text2: t('margin_service_error'),
            type: 'warning',
        })
    }

    const onRefresh = useCallback(() => {
        setRefreshing(true)
        wait(300).then(() => setRefreshing(false))
    }, [])

    return (
        <Container>
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft
                navigation={navigation}
                title={t('apply_margin_service')}
                titleAlgin="flex-start"
                transparent
            />
            <View style={{ backgroundColor: styles.PRIMARY__BG__COLOR, flex: 1 }}>
                <View style={{ marginLeft: dm.moderate(16), marginRight: dm.moderate(16) }}>
                    <Text
                        style={{
                            fontSize: fontSizes.small,
                            fontWeight: fontWeights.bold,
                            color: styles.PRIMARY,
                        }}
                    >
                        {t('apply_margin_header_1')}
                    </Text>

                    <Text style={UI.guidance_style({ fontSizes, dm, styles })}>1. {t('apply_margin_note_1')}</Text>

                    <Text style={UI.guidance_style({ fontSizes, dm, styles })}>2. {t('apply_margin_note_2')}</Text>

                    <Text
                        style={{
                            marginTop: dm.moderate(16),
                            fontSize: fontSizes.small,
                            fontWeight: fontWeights.bold,
                            color: styles.PRIMARY,
                        }}
                    >
                        {t('apply_margin_header_2')}
                    </Text>

                    <View style={{ flexDirection: 'row', marginVertical: dm.moderate(2), marginLeft: dm.moderate(10) }}>
                        <View style={[UI.circle_style, { backgroundColor: styles.PRIMARY }]} />
                        <Text style={UI.guidance_style({ fontSizes, dm, styles })}>{t('apply_margin_description_1')}</Text>
                    </View>

                    <View style={{ flexDirection: 'row', marginVertical: dm.moderate(2), marginLeft: dm.moderate(10) }}>
                        <View style={[UI.circle_style, { backgroundColor: styles.PRIMARY }]} />
                        <Text style={UI.guidance_style({ fontSizes, dm, styles })}>{t('apply_margin_description_2')}</Text>
                    </View>

                    <View style={{ flexDirection: 'row', marginVertical: dm.moderate(2), marginLeft: dm.moderate(10) }}>
                        <View style={[UI.circle_style, { backgroundColor: styles.PRIMARY }]} />
                        <Text style={UI.guidance_style({ fontSizes, dm, styles })}>{t('apply_margin_description_3')}</Text>
                    </View>
                </View>

                <ButtonCustom disabled={isDisable} text={t('apply_margin_service')} type={'confirm'} onPress={confirmSendApplyMargin} />
                <RowTitleGroup hasDivider text={t('registration_status')} />

                <HeaderList colSpan={colSpan} typeHeader="MARGIN_STATUS_LIST" />
                <FlatList
                    data={listEContract}
                    keyExtractor={(item, index) => String(index)}
                    ListEmptyComponent={EmptyView}
                    refreshControl={<RefreshControl refreshing={refreshing} tintColor={styles.PRIMARY__CONTENT__COLOR} onRefresh={onRefresh} />}
                    renderItem={({ item, index }) => <MarginItem colSpan={colSpan} index={index} item={item} />}
                    style={{
                        flexGrow: 1,
                        marginBottom: dm.vertical(32),
                        paddingHorizontal: dm.moderate(16),
                    }}
                />
            </View>
        </Container>
    )
}

const UI = StyleSheet.create({
    circle_style: {
        alignSelf: 'center',
        borderRadius: 7 / 2,
        height: 7,
        marginRight: 10,
        width: 7,
    },
    guidance_style: ({ fontSizes, dm, styles }) => ({
        fontSize: fontSizes.small,
        color: styles.PRIMARY__CONTENT__COLOR,
        marginTop: dm.moderate(4),
    }),
})

export default MarginRegistration
