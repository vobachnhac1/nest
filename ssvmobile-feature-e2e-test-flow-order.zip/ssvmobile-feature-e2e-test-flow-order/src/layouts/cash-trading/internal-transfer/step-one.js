import React, { useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { FlatList, View } from 'react-native'
import ToastGlobal from 'react-native-toast-message'

import Account from '../../../components/account'
import { ButtonCustom, ColTableData, RowData, RowTableData, RowTitleGroup } from '../../../components/trading-component'
import EmptyView from '../../../components/trading-component/empty-view'
import HeaderList from '../../../components/trading-component/header-list'
import { StoreContext } from '../../../store'
import { StoreTrading } from '../../../store-trading'
import { dimensions as dm } from '../../../styles'
import { eventList, glb_sv, reqFunct, Screens, sendRequest } from '../../../utils'
import FormatNumber from '../../../utils/formatNumber/FormatNumber'

// Khai báo ServiceInfo (nếu có)
const ServiceInfo = {
    GET_CURRENT_CASH_AVAILABLE: {
        reqFunct: reqFunct.GET_CURRENT_CASH_AVAILABLE, //Lấy "Số dư hiện tại có thể chuyển"
        WorkerName: 'FOSqCash',
        ServiceName: 'FOSqCash_0201_3',
        ClientSentTime: '0',
        Operation: 'Q',
        // InVal: ['1', this.actn_curr, this.sub_curr],
    },
    GET_HIS_INTRERNAL_TRANSFER: {
        reqFunct: reqFunct.GET_HIS_INTRERNAL_TRANSFER, // Lấy DS chuyển nội bộ gần nhất
        WorkerName: 'FOSqCash',
        ServiceName: 'FOSqCash_0201_3',
        ClientSentTime: '0',
        Operation: 'Q',
        // InVal: ['3', this.actn_curr, this.sub_curr],
    },
}

// Khai báo component
const StepOne = ({ navigation, cashAvailable, setCashAvailable, switchStep, refreshing, onRefresh }) => {
    const { styles } = useContext(StoreContext)
    const { userInfo } = useContext(StoreTrading)

    const { t } = useTranslation()
    // -------------------------------------------   Khai báo các state nội bộ component

    const [dataLastTranfer, setDataLastTranfers] = useState([])

    const activeCodeArr = ['081']
    // -------------------------------------------   Dùng useEffect get các dữ liệu cần thiết còn thiếu
    useEffect(() => {
        // Prepare data
        getCashAvailable() // Lấy số dư có thể chuyển
        getHisTransfers() // Lấy tất cả lịch sử chuyển tiền nội bộ

        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.LOGIN_SUCCESS) {
                // reCall service FOSq
                getCashAvailable() // Lấy số dư có thể chuyển
                getHisTransfers() // Lấy tất cả lịch sử chuyển tiền nội bộ
            }
        })

        return () => {
            commonEvent.unsubscribe()
        }
    }, [userInfo.sub_curr])

    useEffect(() => {
        if (refreshing) {
            getCashAvailable() // Lấy số dư có thể chuyển
            getHisTransfers() // Lấy tất cả lịch sử chuyển tiền nội bộ
        }
    }, [refreshing])
    // -------------------------------------------   Viết các hàm để set lại bussiness form state. Nên viết đúng một chuẩn duy nhất để dễ control

    // -------------------------------------------   Khai báo các hàm gửi (request) lên server
    const getCashAvailable = () => {
        if (!userInfo.actn_curr) {
            ToastGlobal.show({
                type: 'warning',
                text2: t('warning_account_is_empty'),
            })
            return
        }

        const inputParams = ['1', userInfo.actn_curr, userInfo.sub_curr]
        sendRequest(ServiceInfo.GET_CURRENT_CASH_AVAILABLE, inputParams, handleGetCashAvailable)
    }
    const getHisTransfers = () => {
        if (!userInfo.actn_curr) {
            ToastGlobal.show({
                type: 'warning',
                text2: t('warning_account_is_empty'),
            })
            return
        }

        const inputParams = ['3', userInfo.actn_curr, userInfo.sub_curr]
        sendRequest(ServiceInfo.GET_HIS_INTRERNAL_TRANSFER, inputParams, handleGetHisTransfers)
    }

    // -------------------------------------------   Khai báo các hàm nhận (handle respone) dữ liệu từ server

    // -------------------------------------------   Khai báo các hàm nhận (handle respone) dữ liệu từ server
    const handleGetCashAvailable = (reqInfoMap, message) => {
        console.log('handleGetCashAvailable -> message', message)
        // -- process after get result --
        if (Number(message.Result) === 0) {
            console.warn('false handleGetCashAvailable', reqInfoMap, message.Data, message.Message)
            setCashAvailable({})
            return
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {}
            setCashAvailable(jsondata[0])
        }
    }

    //---------------------------------------------
    const handleGetHisTransfers = (reqInfoMap, message) => {
        console.log('handleGetHisTransfers -> message', message)
        // -- process after get result --
        if (Number(message.Result) === 0) {
            console.warn('false handleGetHisTransfers', reqInfoMap, message.Data, message.Message)
            return
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {}
            // console.log('result handleGetHisTransfers', jsondata);
            setDataLastTranfers(jsondata)
        }
    }
    // --------------------------------------------
    const getColor = (status) => {
        if (status === 'N') return styles.REF__COLOR
        if (status === 'R' || status === 'D') return styles.DOWN__COLOR
        if (status === 'Y') return styles.UP__COLOR
    }

    const ViewHisTransfer = ({ item }) => {
        return (
            <>
                <RowTableData
                    key={item.label}
                    type="table"
                    onPress={() => navigation.navigate(Screens.DETAIL_INTERNAL_TRANSFER, { data: item, onRefresh: onRefresh })}
                >
                    <ColTableData text={activeCodeArr.includes(glb_sv.activeCode) ? item.c5 : item.c11 + '.' + item.c5} />
                    <ColTableData text={activeCodeArr.includes(glb_sv.activeCode) ? item.c6 : item.c26 + '.' + item.c6} textAlign="center" />
                    <ColTableData text={FormatNumber(item.c7)} textAlign="center" />
                    <ColTableData colorText={getColor(item.c15)} text={item.c21} textAlign="right" />
                </RowTableData>
            </>
        )
    }
    return (
        <View>
            <RowTitleGroup text={t('trans_sub_account')} />
            <Account navigation={navigation} />
            <RowData last rightColor={styles.PRIMARY} textLeft={t('cash_amount')} textRight={FormatNumber(Number(cashAvailable?.c4), 0)} type="info" />
            <ButtonCustom
                text={t('continue')}
                type="confirm"
                onPress={() => {
                    if (!userInfo.actn_curr) {
                        ToastGlobal.show({
                            type: 'warning',
                            text2: t('warning_account_is_empty'),
                        })
                        return
                    }
                    switchStep.next()
                }}
            />
            <RowTitleGroup hasDivider text={t('hitory_transaction')} />
            <HeaderList typeHeader="INTERNAL_TRANSFER" />
            <FlatList
                data={dataLastTranfer}
                keyExtractor={(item, index) => index.toString()}
                ListEmptyComponent={EmptyView}
                renderItem={ViewHisTransfer}
                style={{ marginBottom: dm.vertical(32), paddingHorizontal: dm.moderate(16) }}
            />
        </View>
    )
}

export default StepOne
