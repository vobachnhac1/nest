import React, { useContext, useEffect, useMemo, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { RefreshControl, StyleSheet, TouchableOpacity, View } from 'react-native'
import { getStatusBarHeight } from 'react-native-iphone-x-helper'
import { Container, Content, Fab, Icon, ScrollableTab, Tab, Tabs } from 'native-base'

import HeaderComponent from '../../../components/header'
import { useLoading } from '../../../hoc'
import { StoreContext } from '../../../store'
import ListBankAccountInfo from './ListBankAccountInfo'
import RegisterBankAccountInfo from './RegisterBankAccountInfo'

const ServiceInfo = {}

export default function UpdateBankInfo({ navigation, route }) {
    const { userData }: { userData: any } = route.params

    const { styles, setAuth, applicationSettings } = useContext(StoreContext)
    const { t } = useTranslation()
    const [currentTab, setCurrentTab] = useState(0)
    const [refreshing, setRefreshing] = useLoading(false)

    // ----------------------------------------
    const onRefresh = () => {
        setRefreshing(true)
        setRefreshing(false)
    }

    const onTabChange = (tab) => {
        const tabIndex = tab.i
        setCurrentTab(tabIndex)
    }

    const StyleContainer = useMemo(
        () =>
            StyleSheet.flatten([
                {
                    backgroundColor: styles.PRIMARY__BG__COLOR,
                    flex: 1,
                },
            ]),
        [styles],
    )

    const StyleUnderline = useMemo(
        () =>
            StyleSheet.flatten([
                { backgroundColor: applicationSettings.application_style.tab_style === '2.0' ? 'transparent' : styles.PRIMARY, borderRadius: 2, height: 2 },
            ]),
        [styles],
    )

    const StyleTabBar = useMemo(
        () => StyleSheet.flatten([{ backgroundColor: styles.PRIMARY__BG__COLOR, borderColor: styles.DIVIDER__COLOR, height: 30 }]),
        [styles],
    )

    const StyleBgPrimary = { backgroundColor: styles.PRIMARY__BG__COLOR }
    const StyleBgPrimaryActive = useMemo(
        () =>
            StyleSheet.flatten([
                applicationSettings.application_style.tab_style === '2.0'
                    ? { backgroundColor: styles.ACTIVE__TAB__HIGHLIGHT__BG, borderTopRightRadius: 6, borderTopLeftRadius: 6, marginLeft: 2 }
                    : { backgroundColor: styles.PRIMARY__BG__COLOR },
            ]),
        [styles],
    )
    const StyleTextPrimary = useMemo(
        () => StyleSheet.flatten([{ color: applicationSettings.application_style.tab_style === '2.0' ? '#fff' : styles.PRIMARY }]),
        [styles],
    )

    const StyleTextSecond = useMemo(() => StyleSheet.flatten([{ color: styles.SECOND__CONTENT__COLOR }]), [styles])

    return (
        // @ts-expect-error
        <Container
            style={{
                backgroundColor: styles.PRIMARY__BG__COLOR,
            }}
        >
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft
                leftButtonLink={() => {
                    if (currentTab > 0) {
                        setCurrentTab(0)
                    } else {
                        navigation.goBack()
                    }
                }}
                navigation={navigation}
                title={t(currentTab === 0 ? 'list_bank_account' : 'bank_account_registration')}
                titleAlgin="flex-start"
                transparent
            />
            <Content
                refreshControl={<RefreshControl refreshing={refreshing} tintColor={styles.PRIMARY__CONTENT__COLOR} onRefresh={onRefresh} />}
                style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}
            >
                {/* @ts-expect-error */}
                <Tabs
                    page={currentTab}
                    renderTabBar={() => <View />} //<ScrollableTab backgroundColor={styles.PRIMARY__BG__COLOR} style={StyleTabBar} underlineStyle={StyleUnderline} />}
                    style={[UI.margin_top_zero]}
                    onChangeTab={(e) => onTabChange(e)}
                >
                    {/* @ts-expect-error */}
                    <Tab
                        activeTabStyle={StyleBgPrimaryActive}
                        activeTextStyle={StyleTextPrimary}
                        heading={t('list_bank_account')}
                        tabStyle={StyleBgPrimary}
                        textStyle={StyleTextSecond}
                    >
                        <ListBankAccountInfo navigation={navigation} refreshing={refreshing} setCurrentTab={setCurrentTab} onRefresh={onRefresh} />
                        {/* <RegisterBankAccountInfo userData={userData} /> */}
                    </Tab>
                    {/* @ts-expect-error */}
                    <Tab
                        activeTabStyle={StyleBgPrimaryActive}
                        activeTextStyle={StyleTextPrimary}
                        heading={t('bank_account_registration')}
                        tabStyle={StyleBgPrimary}
                        textStyle={StyleTextSecond}
                    >
                        <RegisterBankAccountInfo
                            navigation={navigation}
                            refreshing={refreshing}
                            setCurrentTab={setCurrentTab}
                            userData={userData}
                            onRefresh={onRefresh}
                        />
                    </Tab>
                </Tabs>
            </Content>
            {currentTab === 0 ? (
                // @ts-expect-error
                <Fab
                    active={false}
                    containerStyle={{ marginBottom: 32, marginRight: 8, justifyContent: 'center', alignItems: 'center' }}
                    direction="up"
                    position="bottomRight"
                    style={{ backgroundColor: styles.PRIMARY }}
                >
                    <TouchableOpacity
                        style={{ justifyContent: 'center', alignItems: 'center', width: '100%', height: '100%' }}
                        onPress={() => setCurrentTab(1)}
                    >
                        <Icon name="plus" style={{ color: '#fff', fontSize: 32, paddingRight: 0 }} type="Feather" />
                    </TouchableOpacity>
                </Fab>
            ) : null}
        </Container>
    )
}

const UI = StyleSheet.create({
    marginTopStatusbar: { marginTop: getStatusBarHeight() },
    margin_top_zero: { marginTop: 0 },
})
