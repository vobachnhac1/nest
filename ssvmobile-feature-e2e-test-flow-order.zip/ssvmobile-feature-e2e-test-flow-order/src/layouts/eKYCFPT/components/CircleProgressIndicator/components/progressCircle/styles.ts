import { StyleSheet } from 'react-native'

const styles = StyleSheet.create({
    svg: { transform: [{ rotateZ: '270deg' }] },
})

export default styles
