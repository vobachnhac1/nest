import React, { useContext, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { StyleSheet, View } from 'react-native'
import Modal from 'react-native-modal'
import { Button, Input, Item, Label } from 'native-base'

import { Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { dimensions, fontSizes, fontWeights, IconSvg } from '../../styles'
import { eventList, glb_sv, reqFunct, sendRequest } from '../../utils'
import { saveNewFavList } from './favorite-func/favorite.action'

const ServiceInfo = {
    ADD_NEW_FAV_LIST: {
        reqFunct: reqFunct.ADD_NEW_FAV_LIST,
        WorkerName: 'FOSxID01',
        ServiceName: 'FOSxID01_FavoritesMgt',
        ClientSentTime: '0',
        Operation: 'I',
    },
}

export default ({ isModalVisible, setModal, isOddlot }) => {
    const { t } = useTranslation()
    const { styles } = useContext(StoreContext)
    const [nameFav, setNameFav] = useState('')

    const [error, setError] = useState('')

    const changeNameFav = () => {
        if (!nameFav) {
            return
        }
        if (nameFav === glb_sv.activeList.c2) {
            hideModal()
            return
        }
        if (glb_sv.authFlag) {
            const InputParams = ['FAV_ADD', nameFav, isOddlot ? '1' : '0']
            sendRequest(ServiceInfo.ADD_NEW_FAV_LIST, InputParams, handleAddNewListFav, true, handleStockFavTimeout)
            setError('')
        } else {
            saveNewFavList(nameFav, isOddlot)
            hideModal()
        }
    }

    const handleStockFavTimeout = () => {
        setError(t('request_hanlde_not_success_try_again'))
    }

    const handleAddNewListFav = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            if (message.Code === '010012') {
                setError(t('request_hanlde_not_success_try_again'))
            } else if (message.Code === '010025') {
                // The category is exist >>> Re-get fav list
                glb_sv.commonEvent.next({ type: eventList.GET_FAV })
                hideModal()
            } else {
                setError(message.Message)
            }
            return
        } else {
            const dataObj = JSON.parse(message.Data)

            glb_sv.allListFav.push({
                c1: dataObj[0].c0,
                c2: nameFav,
                type: 'watchlist',
                ListStock: [],
                isOddlot,
            })

            const listFixed = glb_sv.allListFav.filter((item) => item.type === 'fixed')
            glb_sv.allListFav = glb_sv.allListFav.filter((item) => item.type !== 'fixed').concat(listFixed)

            if (glb_sv.configInfo.application_style.default_style === '2.0') {
                glb_sv.commonEvent.next({ type: eventList.CHANGE_LIST_FAV })
            } else {
                glb_sv.activeList = {
                    c1: dataObj[0].c0,
                    c2: nameFav,
                    type: 'watchlist',
                    ListStock: [],
                    isOddlot,
                }
                glb_sv.commonEvent.next({ type: eventList.CHANGE_LIST_ACTIVE })
            }
        }
        hideModal()
    }

    const hideModal = () => setModal(false)

    return (
        <Modal
            avoidKeyboard
            hideModalContentWhileAnimating={true}
            isVisible={isModalVisible}
            style={UI.modal}
            swipeDirection={['down']}
            onBackButtonPress={hideModal}
            onBackdropPress={hideModal}
            onSwipeComplete={() => setModal(false)}
        >
            <View
                style={{
                    backgroundColor: styles.PRIMARY__BG__COLOR,
                    paddingVertical: dimensions.vertical(24),
                    paddingHorizontal: dimensions.moderate(12),
                    marginHorizontal: dimensions.moderate(14),
                    borderRadius: 12,
                    justifyContent: 'flex-start',
                    alignItems: 'center',
                }}
            >
                <IconSvg.EditIcon color={styles.PRIMARY} />
                <Text style={{ ...UI.title, color: styles.PRIMARY__CONTENT__COLOR }}>
                    {t('add_new_favorites')} ({isOddlot ? t('odd_lot') : t('even_lot')})
                </Text>

                <Item error={!nameFav} stackedLabel style={{ width: '100%', borderBottomColor: styles.BOTTOM__MODAL__COLOR }} underline={false}>
                    <Label style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small, opacity: 0.34 }}>{t('watchlist_name')}</Label>
                    <Input
                        autoFocus
                        onChangeText={(value) => {
                            setNameFav(value)
                            setError('')
                        }}
                        // maxLength={50}
                        style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.medium }}
                        value={nameFav}
                    />
                </Item>
                {glb_sv.allListFav.some((e) => e.c2 === nameFav) ? (
                    <Text
                        style={{
                            color: styles.ERROR__COLOR,
                            fontSize: fontSizes.verySmall,
                            paddingHorizontal: dimensions.indent,
                            paddingTop: dimensions.halfIndent,
                        }}
                    >
                        {t('error_watchlist_name')}
                    </Text>
                ) : (
                    <Text> </Text>
                )}
                <Text
                    style={{
                        color: styles.ERROR__COLOR,
                        fontSize: fontSizes.verySmall,
                        paddingHorizontal: dimensions.indent,
                        paddingTop: dimensions.halfIndent,
                    }}
                >
                    {error}
                </Text>

                <View style={{ flexDirection: 'row', justifyContent: 'flex-end', marginTop: dimensions.vertical(24) }}>
                    <View style={{ flex: 2 }} />
                    <Button style={{ flex: 1, justifyContent: 'center', alignSelf: 'center' }} transparent onPress={hideModal}>
                        <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.verySmall, opacity: 0.34 }}>{t('common_Cancel')}</Text>
                    </Button>
                    <Button
                        disabled={glb_sv.allListFav.some((e) => e.c2 === nameFav)}
                        style={{
                            backgroundColor: glb_sv.allListFav.some((e) => e.c2 === nameFav) ? styles.PRIMARY + '80' : styles.PRIMARY,
                            flex: 1,
                            justifyContent: 'center',
                            alignSelf: 'center',
                            borderRadius: 8,
                        }}
                        onPress={changeNameFav}
                    >
                        <Text style={{ color: '#FFF', fontSize: fontSizes.small }}>{t('add')}</Text>
                    </Button>
                </View>
            </View>
        </Modal>
    )
}

const UI = StyleSheet.create({
    note: {
        fontSize: fontSizes.small,
        marginBottom: dimensions.vertical(32),
    },
    title: {
        fontSize: fontSizes.xmedium,
        fontWeight: fontWeights.semiBold,
        marginBottom: dimensions.vertical(27),
        marginTop: dimensions.vertical(32),
    },
})
