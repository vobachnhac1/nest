import 'antd/dist/antd.css'
import 'moment/locale/vi'

import React, { PureComponent } from 'react'
import { DatePicker } from 'antd'
import Highcharts from 'highcharts'
import HighchartsStock from 'highcharts/highstock'
import moment from 'moment'

import FormatNumber from '../../formatNumber/FormatNumber'

const PROFIT_LOSS_DOWN = '#FF6973'
const PROFIT_LOSS_UP = '#4CB593'

export default class MyPerformanceChart extends PureComponent {
    constructor(props) {
        super(props)
        this.state = {
            tab: '1',
            fromdt: moment(window.workDate, 'YYYYMMDD').startOf('month'),
            todt: moment(window.workDate, 'YYYYMMDD'),
            dataTableAssetsFull: window.dataAssetWeightFull || [],
        }
        document.body.classList.add(window.theme)
    }

    componentDidMount() {
        this.chart_assets_weight_full = Highcharts.chart('chart_assets_weight_full', {
            time: {
                useUTC: false,
            },
            chart: {
                type: 'column',
            },
            title: {
                text: '',
            },
            credits: {
                enabled: false,
            },
            xAxis: {
                labels: {
                    formatter: function () {
                        return moment(this.value).format('DD/MM')
                    },
                },
                type: 'datetime',
            },
            yAxis: [
                {
                    title: {
                        text: '',
                    },
                    stackLabels: {
                        enabled: false,
                    },
                },
                // {
                //     opposite: true,
                //     linkedTo: 0,
                //     title: {
                //         text: '',
                //     },
                //     stackLabels: {
                //         enabled: false,
                //     },
                // },
            ],
            legend: {
                enabled: true,
                itemStyle: {
                    color: window.PRIMARY__CONTENT__COLOR,
                },
            },
            plotOptions: {
                column: {
                    stacking: 'normal',
                },
            },
            series: [
                {
                    name: window.title_assets,
                    data: [],
                    stack: 'assets',
                    color: 'blue',
                },
                {
                    name: window.title_cash,
                    data: [],
                    stack: 'assets',
                    color: PROFIT_LOSS_UP,
                },
                {
                    name: window.title_debt,
                    data: [],
                    stack: 'assets',
                    color: PROFIT_LOSS_DOWN,
                },
            ],
        })

        this.eventMarket = window.eventMarket.subscribe((msg) => {
            if (msg.type === 'highchart-render' && msg.value === 'dataAssetWeightFull') {
                console.log('dataAssetWeightFull dataAssetWeightFull', window.dataAssetWeightFull)
                requestAnimationFrame(() => {
                    // Chart tỉ trọng tài sản theo tháng
                    this.chart_assets_weight_full.series[0].setData(
                        window.dataAssetWeightFull.map((e) => {
                            return {
                                x: moment(e.c0, 'YYYYMMDD').valueOf(),
                                y: Number(e.c1),
                                color: 'blue',
                                stroke: 'blue',
                            }
                        }),
                    )
                    this.chart_assets_weight_full.series[1].setData(
                        window.dataAssetWeightFull.map((e) => {
                            return {
                                x: moment(e.c0, 'YYYYMMDD').valueOf(),
                                y: Number(e.c2),
                                color: PROFIT_LOSS_UP,
                            }
                        }),
                    )
                    this.chart_assets_weight_full.series[2].setData(
                        window.dataAssetWeightFull.map((e) => {
                            return {
                                x: moment(e.c0, 'YYYYMMDD').valueOf(),
                                y: -Number(e.c3),
                                color: PROFIT_LOSS_DOWN,
                            }
                        }),
                    )
                    this.chart_assets_weight_full.reflow()
                    // Render lại table:
                    this.setState({ dataTableAssetsFull: window.dataAssetWeightFull })
                })
            }
        })
        requestAnimationFrame(() => {
            // Chart tỉ trọng tài sản theo tháng
            this.chart_assets_weight_full.series[0].setData(
                window.dataAssetWeightFull.map((e) => {
                    return {
                        x: moment(e.c0, 'YYYYMMDD').valueOf(),
                        y: Number(e.c1),
                        color: 'blue',
                        stroke: 'blue',
                    }
                }),
            )
            this.chart_assets_weight_full.series[1].setData(
                window.dataAssetWeightFull.map((e) => {
                    return {
                        x: moment(e.c0, 'YYYYMMDD').valueOf(),
                        y: Number(e.c2),
                        color: PROFIT_LOSS_UP,
                    }
                }),
            )
            this.chart_assets_weight_full.series[2].setData(
                window.dataAssetWeightFull.map((e) => {
                    return {
                        x: moment(e.c0, 'YYYYMMDD').valueOf(),
                        y: -Number(e.c3),
                        color: PROFIT_LOSS_DOWN,
                    }
                }),
            )
            this.chart_assets_weight_full.reflow()
        })
    }

    componentWillUnmount() {
        this.eventMarket.unsubscribe()
    }

    render() {
        return (
            <div className="flex flex-direction-column h-100" style={{ color: window.PRIMARY__CONTENT__COLOR, backgroundColor: window.PRIMARY__BG__COLOR }}>
                <div className="flex flex-direction-column">
                    {/* <div className="flex" style={{ alignItems: 'center', marginLeft: 12 }}>
                        <DatePicker
                            // locale='zh_CN'
                            format="MM-YYYY"
                            onChange={(val) => {
                                this.setState({ fromdt: val })
                                window.ReactNativeWebView &&
                                    window.ReactNativeWebView.postMessage(
                                        JSON.stringify({
                                            fromdt: val.format('YYYYMM'),
                                            todt: this.state.todt.format('YYYYMM'),
                                            type: 'assets_weight_by_month',
                                        }),
                                    )
                            }}
                            value={this.state.fromdt}
                            max={moment(window.workDate, 'YYYYMM')}
                            showToday={false}
                            disabledDate={disabledDate}
                            inputReadOnly={true}
                            picker="month"
                        />
                        ~
                        <DatePicker
                            // locale='vi_VN'
                            format="MM-YYYY"
                            onChange={(val) => {
                                this.setState({ todt: val })
                                window.ReactNativeWebView &&
                                    window.ReactNativeWebView.postMessage(
                                        JSON.stringify({
                                            todt: val.format('YYYYMM'),
                                            fromdt: this.state.fromdt.format('YYYYMM'),
                                            type: 'assets_weight_by_month',
                                        }),
                                    )
                            }}
                            value={this.state.todt}
                            max={moment(window.workDate, 'YYYYMM')}
                            showToday={false}
                            disabledDate={disabledDate}
                            inputReadOnly={true}
                            picker="month"
                        />
                    </div>
                    <table style={{ margin: 8 }}>
                        <thead className="ant-table-thead"></thead>
                        <tbody className="ant-table-tbody"></tbody>
                        <tr>
                            <th style={{ border: `1px solid ${window.DIVIDER__COLOR}`, padding: 4, textAlign: 'left', color: window.PRIMARY__CONTENT__COLOR }}>
                                Thời gian
                            </th>
                            {this.state.dataTableAssetsFull.map((col) => {
                                return (
                                    <td
                                        className="ant-table-cell"
                                        style={{ border: `1px solid ${window.DIVIDER__COLOR}`, padding: 4, color: window.PRIMARY__CONTENT__COLOR }}>
                                        {moment(col.c0, 'YYYYMM').format('MM-YYYY')}
                                    </td>
                                )
                            })}
                        </tr>
                        <tr>
                            <th style={{ border: `1px solid ${window.DIVIDER__COLOR}`, padding: 4, textAlign: 'left', color: window.PRIMARY__CONTENT__COLOR }}>
                                Nest Assets
                            </th>
                            {this.state.dataTableAssetsFull.map((col) => {
                                return (
                                    <td
                                        className="ant-table-cell"
                                        style={{ border: `1px solid ${window.DIVIDER__COLOR}`, padding: 4, color: window.PRIMARY__CONTENT__COLOR }}>
                                        {col.c4}
                                    </td>
                                )
                            })}
                        </tr>
                        <tr>
                            <th style={{ border: `1px solid ${window.DIVIDER__COLOR}`, padding: 4, textAlign: 'left', color: window.PRIMARY__CONTENT__COLOR }}>
                                Stock
                            </th>
                            {this.state.dataTableAssetsFull.map((col) => {
                                return (
                                    <td
                                        className="ant-table-cell"
                                        style={{ border: `1px solid ${window.DIVIDER__COLOR}`, padding: 4, color: window.PRIMARY__CONTENT__COLOR }}>
                                        {col.c1}
                                    </td>
                                )
                            })}
                        </tr>
                        <tr>
                            <th style={{ border: `1px solid ${window.DIVIDER__COLOR}`, padding: 4, textAlign: 'left', color: window.PRIMARY__CONTENT__COLOR }}>
                                Cash
                            </th>
                            {this.state.dataTableAssetsFull.map((col) => {
                                return (
                                    <td
                                        className="ant-table-cell"
                                        style={{ border: `1px solid ${window.DIVIDER__COLOR}`, padding: 4, color: window.PRIMARY__CONTENT__COLOR }}>
                                        {col.c2}
                                    </td>
                                )
                            })}
                        </tr>
                        <tr>
                            <th style={{ border: `1px solid ${window.DIVIDER__COLOR}`, padding: 4, textAlign: 'left', color: window.PRIMARY__CONTENT__COLOR }}>
                                Debt
                            </th>
                            {this.state.dataTableAssetsFull.map((col) => {
                                return (
                                    <td
                                        className="ant-table-cell"
                                        style={{ border: `1px solid ${window.DIVIDER__COLOR}`, padding: 4, color: window.PRIMARY__CONTENT__COLOR }}>
                                        {col.c3}
                                    </td>
                                )
                            })}
                        </tr>
                    </table> */}
                    <div id="chart_assets_weight_full" style={{ height: 250 }} />
                </div>
            </div>
        )
    }
}
