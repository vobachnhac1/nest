export interface AppModalProps {
    t?: string
    styles?: any
    handleConfirm?: () => void
    handleCancel?: () => void
    linkCallback?: () => void
    onCallBack?: () => void
    cancelCallBack?: () => void
    isBackdropClose?: boolean
    middleComponent?: React.ReactNode
    notTouch?: boolean
    icon?: React.ReactNode
    title?: string
    colorTitle?: string
    typeColor?: string
    footerComponent?: React.ReactNode
    showCancel?: boolean
    content?: string
    titleOK?: string
    isVisible?: boolean
}
