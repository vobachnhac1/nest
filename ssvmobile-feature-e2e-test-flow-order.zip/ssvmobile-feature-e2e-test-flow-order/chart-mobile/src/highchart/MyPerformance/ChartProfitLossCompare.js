import 'antd/dist/antd.css'
import 'moment/locale/vi'

import React, { PureComponent } from 'react'
import { DatePicker } from 'antd'
import Highcharts from 'highcharts'
import HighchartsStock from 'highcharts/highstock'
import moment from 'moment'

import FormatNumber from '../../formatNumber/FormatNumber'

const PROFIT_LOSS_DOWN = '#FF6973'
const PROFIT_LOSS_UP = '#4CB593'

export default class MyPerformanceChart extends PureComponent {
    constructor(props) {
        super(props)
        this.state = {
            tab: '1',
            fromdt: moment(window.workDate, 'YYYYMMDD').subtract(12, 'months'),
            todt: moment(window.workDate, 'YYYYMMDD'),
            dataTableAssetsFull: window.dataAssetWeightFull || [],
        }
        document.body.classList.add(window.theme)
    }

    componentDidMount() {
        this.chart_profit_loss_index_tab1 = HighchartsStock.stockChart('chart_profit_loss_index_tab1', {
            title: {
                text: '',
            },
            scrollbar: {
                enabled: false,
            },
            navigator: {
                enabled: false,
            },
            credits: {
                enabled: false,
            },
            plotOptions: {
                series: {
                    turboThreshold: 100000,
                },
            },
            series: [
                {
                    name: window.cal_profit_loss,
                    data: [],
                    tooltip: {
                        // valueDecimals: 2,
                    },
                },
            ],
        })

        this.chart_profit_loss_index_tab2 = HighchartsStock.stockChart('chart_profit_loss_index_tab2', {
            title: {
                text: '',
            },
            scrollbar: {
                enabled: false,
            },
            navigator: {
                enabled: false,
            },
            credits: {
                enabled: false,
            },
            yAxis: {
                gridLineDashStyle: 'Solid',
            },
            plotOptions: {
                series: {
                    turboThreshold: 100000,
                },
            },
            legend: {
                enabled: true,
                itemStyle: {
                    color: window.PRIMARY__CONTENT__COLOR,
                },
            },

            series: [
                {
                    name: window.profit_or_loss_ratio,
                    data: [],
                    tooltip: {
                        valueDecimals: 2,
                        valueSuffix: ' %',
                    },
                    lineColor: window.PRIMARY,
                },
                {
                    name: window.ratio_index + ' VNI',
                    data: [],
                    tooltip: {
                        valueDecimals: 2,
                        valueSuffix: ' %',
                    },
                    lineColor: window.REF__COLOR,
                    dashStyle: 'Solid',
                },
            ],
        })

        this.eventMarket = window.eventMarket.subscribe((msg) => {
            if (msg.type === 'highchart-render' && msg.value === 'dataProfitLossIndex') {
                requestAnimationFrame(() => {
                    this.chart_profit_loss_index_tab1.series[0].setData(
                        window.dataProfitLossIndex.map((e) => {
                            return [moment(e.c0, 'YYYYMMDD').valueOf(), Number(e.c1)]
                        }),
                    )

                    this.chart_profit_loss_index_tab1.reflow()
                })
            }

            if (msg.type === 'highchart-render' && msg.value === 'dataRatioIndex') {
                requestAnimationFrame(() => {
                    this.chart_profit_loss_index_tab2.series[0].setData(
                        window.dataProfitLossIndex.map((e) => {
                            return [moment(e.c0, 'YYYYMMDD').valueOf(), Number(e.c2)]
                        }),
                    )
                    this.chart_profit_loss_index_tab2.series[1].setData(
                        window.dataRatioIndex.map((e) => {
                            return [moment(e.c0, 'YYYYMMDD').valueOf(), Number(e.c1)]
                        }),
                    )
                })
            }
        })
        requestAnimationFrame(() => {
            // Chart Hiệu suất đầu tư
            this.chart_profit_loss_index_tab2.series[0].setData(
                window.dataProfitLossIndex.map((e) => {
                    return [moment(e.c0, 'YYYYMMDD').valueOf(), Number(e.c2)]
                }),
            )
            this.chart_profit_loss_index_tab2.series[1].setData(
                window.dataRatioIndex.map((e) => {
                    return [moment(e.c0, 'YYYYMMDD').valueOf(), Number(e.c1)]
                }),
            )
        })
    }

    componentWillUnmount() {
        this.eventMarket.unsubscribe()
    }

    changeTab = (tab) => {
        this.setState({ tab })
        if (tab === '1') {
            setTimeout(() => {
                requestAnimationFrame(() => {
                    this.chart_profit_loss_index_tab1.reflow()
                })
            }, 100)
        } else {
            setTimeout(() => {
                requestAnimationFrame(() => {
                    this.chart_profit_loss_index_tab2.reflow()
                })
            }, 100)
        }
    }

    render() {
        const disabledFromDate = moment(window.workDate, 'YYYYMMDD')
        const disabledDate = (current) => {
            const tooEff = disabledFromDate.diff(current, 'days') < 0
            return tooEff
        }
        return (
            <div className="flex flex-direction-column h-100" style={{ color: window.PRIMARY__CONTENT__COLOR, backgroundColor: window.PRIMARY__BG__COLOR }}>
                <div className="flex flex-direction-column">
                    <div className="flex" style={{ marginLeft: 12, paddingTop: 12 }}>
                        <div
                            className="flex"
                            style={{
                                display: 'flex',
                                position: 'relative',
                                borderRadius: 8,
                                marginRight: 4,
                                backgroundColor: window.BUTTON__SECONDARY,
                                borderWidth: 1,
                                borderColor: this.state.tab === '1' ? window.PRIMARY : window.ICON__PRIMARY,
                                borderStyle: 'solid',
                                maxWidth: 200,
                                minWidth: 150,
                                justifyContent: 'center',
                                fontWeight: this.state.tab === '1' ? '600' : '400',
                            }}
                            onClick={() => this.changeTab('1')}
                        >
                            {this.state.tab === '1' ? (
                                <div
                                    style={{
                                        backgroundColor: window.PRIMARY,
                                        width: 8,
                                        height: 8,
                                        borderRadius: 4,
                                        top: 4,
                                        left: 4,
                                        position: 'absolute',
                                    }}
                                />
                            ) : null}
                            <div
                                style={{
                                    display: 'flex',
                                    padding: 8,
                                    flexDirection: 'row',
                                    justifyContent: 'center',
                                    alignItems: 'center',
                                    textAlign: 'center',
                                    color: this.state.tab === '1' ? window.PRIMARY : window.PRIMARY__CONTENT__COLOR,
                                }}
                            >
                                {window.absolute_efficiency}
                            </div>
                        </div>
                        <div
                            className="flex"
                            style={{
                                display: 'flex',
                                position: 'relative',
                                borderRadius: 8,
                                marginRight: 4,
                                backgroundColor: window.BUTTON__SECONDARY,
                                borderWidth: 1,
                                borderColor: this.state.tab === '2' ? window.PRIMARY : window.ICON__PRIMARY,
                                borderStyle: 'solid',
                                maxWidth: 200,
                                minWidth: 170,
                                justifyContent: 'center',
                                fontWeight: this.state.tab === '2' ? '600' : '400',
                            }}
                            onClick={() => this.changeTab('2')}
                        >
                            {this.state.tab === '2' ? (
                                <div
                                    style={{
                                        backgroundColor: window.PRIMARY,
                                        width: 8,
                                        height: 8,
                                        borderRadius: 4,
                                        top: 4,
                                        left: 4,
                                        position: 'absolute',
                                    }}
                                />
                            ) : null}
                            <div
                                style={{
                                    display: 'flex',
                                    padding: 8,
                                    flexDirection: 'row',
                                    justifyContent: 'center',
                                    alignItems: 'center',
                                    textAlign: 'center',
                                    color: this.state.tab === '2' ? window.PRIMARY : window.PRIMARY__CONTENT__COLOR,
                                }}
                            >
                                {window.compare_vnindex}
                            </div>
                        </div>
                    </div>

                    <div id="chart_profit_loss_index_tab1" style={{ height: 250, display: this.state.tab === '1' ? '' : 'none' }} />
                    <div id="chart_profit_loss_index_tab2" style={{ height: 250, display: this.state.tab === '2' ? '' : 'none' }} />
                </div>
            </div>
        )
    }
}
