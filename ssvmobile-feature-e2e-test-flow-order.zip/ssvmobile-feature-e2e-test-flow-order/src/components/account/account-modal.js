import React, { memo, useContext } from 'react'
import { StyleSheet, View } from 'react-native'

import { Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { StoreTrading } from '../../store-trading'
import { dimensions, fontSizes } from '../../styles'

const AccountModal = ({ actn_curr, sub_curr, actn_name }) => {
    const { styles } = useContext(StoreContext)
    const { userInfo = {} } = useContext(StoreTrading)

    return (
        <View style={UI.Row_Modal}>
            <View style={{ flex: 1 }}>
                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small }}>{actn_curr || userInfo.actn_curr}</Text>
                {actn_curr ? null : (
                    <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.verySmall }}>
                        {actn_curr ? actn_name || '' : userInfo.actn_name}
                    </Text>
                )}
            </View>
            <View style={{ flex: 1 }}>
                <View style={{ ...UI.Button, backgroundColor: styles.PRIMARY }}>
                    <Text style={{ color: '#fff', fontSize: fontSizes.small }}>{sub_curr || userInfo.sub_curr}</Text>
                </View>
            </View>
        </View>
    )
}

export default memo(AccountModal)

const UI = StyleSheet.create({
    Button: {
        alignItems: 'center',
        borderRadius: 8,
        height: dimensions.vertical(32),
        justifyContent: 'center',
        width: dimensions.moderate(32),
    },
    Row_Modal: {
        alignItems: 'center',
        flexDirection: 'row',
        height: dimensions.moderate(18),
        marginVertical: dimensions.vertical(16),
    },
})
