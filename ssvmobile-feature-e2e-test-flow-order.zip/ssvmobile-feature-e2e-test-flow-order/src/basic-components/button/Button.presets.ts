import { StyleSheet } from 'react-native'

export const stylesView = StyleSheet.create({
    link: {
        alignItems: 'flex-start',
        borderRadius: 4,
        justifyContent: 'center',
        paddingHorizontal: 0,
        paddingVertical: 0,
    },
    primary: {
        alignItems: 'center',
        backgroundColor: '#ebf2f1',
        borderRadius: 4,
        justifyContent: 'center',
        paddingHorizontal: 8,
        paddingVertical: 8,
    },
})

export const stylesText = StyleSheet.create({
    link: {
        color: 'rgb(28, 28, 30)',
        fontSize: 9,
        paddingHorizontal: 0,
        paddingVertical: 0,
    },
    primary: {
        color: '#FFFFFF',
        fontSize: 9,
        paddingHorizontal: 8,
    },
})
export type ButtonPresetNames = keyof typeof stylesView
