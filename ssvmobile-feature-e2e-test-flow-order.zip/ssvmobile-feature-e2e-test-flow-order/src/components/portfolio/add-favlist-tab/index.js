import React, { useContext, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Container, Form, Icon, Input, Item, Toast, View } from 'native-base'

import { Text } from '../../../basic-components'
import { StoreContext } from '../../../store'
import { dimensions, fontSizes } from '../../../styles'
import { UIbasic, UIcomponent } from '../../../styles/appUI'
import { eventList, glb_sv, reqFunct } from '../../../utils'
import sendRequest from '../../../utils/sendRequest'
import HeaderComponent from '../../header'
import { editFavListName, saveNewFavList } from '../favorite-func/favorite.action'

export default function AddNewFavList({ navigation, route }) {
    const { actionType, oldName, id } = route.params
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()
    const [nameList, setNameList] = useState(actionType === 'ADD_FAV_LIST' ? '' : oldName + '1')
    const nameListRef = useRef(null)

    const ServiceInfo = {
        AddNewFavList: {
            reqFunct: reqFunct.ADD_NEW_FAV_LIST,
            WorkerName: 'FOSxID01',
            ServiceName: 'FOSxID01_FavoritesMgt',
            ClientSentTime: '0',
            Operation: 'I',
        },
        EditFavList: {
            reqFunct: reqFunct.EDIT_NAME_FAV_LIST,
            WorkerName: 'FOSxID01',
            ServiceName: 'FOSxID01_FavoritesMgt',
            ClientSentTime: '0',
            Operation: 'U',
        },
    }

    const handleAddNewListFav = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            if (message.Code === '010012') {
                Toast.show({
                    text: t('request_hanlde_not_success_try_again'),
                    type: 'warning',
                    position: 'bottom',
                })
            } else {
                Toast.show({
                    text: message.Message,
                    type: 'warning',
                    position: 'bottom',
                })
            }
            return
        } else {
            const dataObj = JSON.parse(message.Data)

            glb_sv.allListFav.push({
                c1: dataObj[0].c0,
                c2: nameList,
                ListStock: [],
            })
            glb_sv.activeList = {
                c1: dataObj[0].c0,
                c2: nameList,
                ListStock: [],
            }
            glb_sv.commonEvent.next({ type: eventList.CHANGE_LIST_ACTIVE })
        }
    }

    const addFavList = () => {
        if (!nameList) return
        if (glb_sv.allListFav.some((e) => e.c2 === nameList)) return
        if (glb_sv.authFlag) {
            const InputParams = ['FAV_ADD', nameList]
            sendRequest(ServiceInfo.AddNewFavList, InputParams, handleAddNewListFav, true, handleStockFavTimeout)
        } else {
            saveNewFavList(nameList)
        }
        navigation.pop()
    }

    const handleStockFavTimeout = () => {
        Toast.show({
            text: t('request_hanlde_not_success_try_again'),
            type: 'warning',
            position: 'bottom',
        })
    }

    const editFavListNamee = () => {
        if (!nameList) return
        if (glb_sv.allListFav.some((e) => e.c2 === nameList)) return
        if (glb_sv.authFlag) {
            const InputParams = ['FAV_MOD', id, nameList]
            sendRequest(ServiceInfo.EditFavList, InputParams, handleEditListFav, true, handleStockFavTimeout)
        } else {
            editFavListName(nameList, id)
        }
        navigation.pop()
    }

    const handleEditListFav = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            if (message.Code === '010012') {
                Toast.show({
                    text: t('request_hanlde_not_success_try_again'),
                    type: 'warning',
                    position: 'bottom',
                })
            } else {
                Toast.show({
                    text: message.Message,
                    type: 'warning',
                    position: 'bottom',
                })
            }
            return
        } else {
            const current = glb_sv.allListFav.find((x) => x.c1 === id)
            current.c2 = nameList
            if (glb_sv.activeList.c1 === current.c1) {
                glb_sv.activeList.c2 = nameList
                glb_sv.commonEvent.next({ type: eventList.CHANGE_LIST_ACTIVE })
            } else glb_sv.commonEvent.next({ type: eventList.CHANGE_LIST_FAV })
        }
    }

    const changeName = (value) => {
        setNameList(value)
    }

    return (
        <Container style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
            <HeaderComponent
                colorRightText={
                    actionType === 'ADD_FAV_LIST'
                        ? nameList && !glb_sv.allListFav.some((e) => e.c2 === nameList)
                            ? styles.PRIMARY
                            : styles.BUTTON__PRIMARY__DISABLED
                        : nameList
                        ? styles.PRIMARY
                        : styles.BUTTON__PRIMARY__DISABLED
                }
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft
                isShowRight
                navigation={navigation}
                rightButtonLink={() => (actionType === 'ADD_FAV_LIST' ? addFavList() : editFavListNamee())}
                rightText={t('save')}
                title={actionType === 'ADD_FAV_LIST' ? t('create_watchlist') : t('modify_nm_of_fav')}
                titleAlgin="flex-start"
                transparent
            />
            <Form style={UIcomponent.Form}>
                <Item last style={{ borderBottomColor: styles.DIVIDER__COLOR }}>
                    <Input
                        maxLength={24}
                        placeholder={t('watchlist_name')}
                        placeholderTextColor={styles.PLACEHODLER__COLOR}
                        ref={nameListRef}
                        style={{
                            fontSize: fontSizes.medium,
                            color: styles.PRIMARY__CONTENT__COLOR,
                        }}
                        value={nameList}
                        onChangeText={(value) => changeName(value)}
                    />
                    {nameList.length > 4 ? (
                        <Icon name="closecircle" style={{ color: styles.SECOND__CONTENT__COLOR }} type="AntDesign" onPress={() => setNameList('')} />
                    ) : null}
                </Item>
                <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                    {glb_sv.allListFav.some((e) => e.c2 === nameList) ? (
                        <Text
                            style={{
                                color: styles.ERROR__COLOR,
                                fontSize: fontSizes.verySmall,
                                paddingHorizontal: dimensions.indent,
                                paddingTop: dimensions.halfIndent,
                            }}
                        >
                            {t('error_watchlist_name')}
                        </Text>
                    ) : (
                        <Text> </Text>
                    )}
                    <Text
                        style={{
                            color: styles.SECOND__CONTENT__COLOR,
                            fontSize: fontSizes.smallest,
                            paddingHorizontal: dimensions.indent,
                            paddingTop: 2,
                            textAlign: 'right',
                        }}
                    >
                        {nameList.length}/24
                    </Text>
                </View>
            </Form>
        </Container>
    )
}
