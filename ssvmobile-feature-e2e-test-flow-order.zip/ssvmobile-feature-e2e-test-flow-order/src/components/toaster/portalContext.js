import React, { createContext, ReactNode } from 'react'

export const PortalContext = createContext({
    gates: {},
    teleport: () => {},
    showToast: () => {},
})
