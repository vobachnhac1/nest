import React, { useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { StyleSheet, View } from 'react-native'
import Modal from 'react-native-modal'
import { Button, Input, Item, Label } from 'native-base'

import { Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { dimensions, fontSizes, fontWeights, IconSvg } from '../../styles'
import { eventList, glb_sv, reqFunct, sendRequest } from '../../utils'
import { editFavListName } from './favorite-func/favorite.action'

const ServiceInfo = {
    EDIT_NAME_FAV_LIST: {
        reqFunct: reqFunct.EDIT_NAME_FAV_LIST,
        WorkerName: 'FOSxID01',
        ServiceName: 'FOSxID01_FavoritesMgt',
        ClientSentTime: '0',
        Operation: 'U',
    },
}

export default ({ isModalVisible, setModal }) => {
    const { t } = useTranslation()
    const { styles } = useContext(StoreContext)
    const [nameFav, setNameFav] = useState('')

    const [error, setError] = useState('')

    useEffect(() => {
        setNameFav('')
    }, [isModalVisible])

    const changeNameFav = () => {
        if (!nameFav) {
            return
        }
        if (nameFav === glb_sv.activeList.c2) {
            hideModal()
            return
        }
        if (glb_sv.authFlag) {
            const InputParams = ['FAV_MOD', glb_sv.activeList.c1, nameFav]
            sendRequest(ServiceInfo.EDIT_NAME_FAV_LIST, InputParams, handleChangeNameFav, true, handleStockFavTimeout)
            setError('')
        } else {
            editFavListName(nameFav, glb_sv.activeList.c1)
            hideModal()
            setNameFav('')
            setError('')
        }
    }

    const handleStockFavTimeout = () => {
        setError(t('request_hanlde_not_success_try_again'))
    }

    const handleChangeNameFav = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            if (message.Code === '010012') {
                setError(t('request_hanlde_not_success_try_again'))
            } else {
                setError(message.Message)
            }
            return
        } else {
            setNameFav('')

            const current = glb_sv.allListFav.find((x) => x.c1 === glb_sv.activeList.c1)
            current.c2 = nameFav
            if (glb_sv.configInfo.application_style.default_style === '2.0') {
                glb_sv.commonEvent.next({ type: eventList.CHANGE_LIST_FAV })
            } else {
                if (glb_sv.activeList.c1 === current.c1) {
                    glb_sv.activeList.c2 = nameFav
                    glb_sv.commonEvent.next({ type: eventList.CHANGE_LIST_ACTIVE })
                } else glb_sv.commonEvent.next({ type: eventList.CHANGE_LIST_FAV })
            }
        }
        hideModal()
    }

    const hideModal = () => setModal(false)

    return (
        <Modal avoidKeyboard hideModalContentWhileAnimating={true} isVisible={isModalVisible} onBackButtonPress={hideModal} onBackdropPress={hideModal}>
            <View
                style={{
                    backgroundColor: styles.PRIMARY__BG__COLOR,
                    paddingVertical: dimensions.vertical(24),
                    paddingHorizontal: dimensions.moderate(12),
                    marginHorizontal: dimensions.moderate(14),
                    borderRadius: 12,
                    justifyContent: 'center',
                    alignItems: 'center',
                }}
            >
                <IconSvg.EditIcon color={styles.PRIMARY} />
                <Text style={{ ...UI.title, color: styles.PRIMARY__CONTENT__COLOR }}>{t('modify_nm_of_fav')}</Text>

                <Item error={!nameFav} stackedLabel style={{ width: '100%', borderBottomColor: styles.BOTTOM__MODAL__COLOR }} underline={false}>
                    <Label style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small, opacity: 0.34 }}>{t('watchlist_name')}</Label>
                    <Input
                        autoFocus
                        style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.medium }}
                        value={nameFav}
                        // maxLength={50}
                        onChangeText={(value) => {
                            setNameFav(value)
                            setError('')
                        }}
                    />
                </Item>

                {glb_sv.allListFav.some((e) => e.c2 === nameFav) ? (
                    <Text
                        style={{
                            color: styles.ERROR__COLOR,
                            fontSize: fontSizes.verySmall,
                            paddingHorizontal: dimensions.indent,
                            paddingTop: dimensions.halfIndent,
                        }}
                    >
                        {t('error_watchlist_name')}
                    </Text>
                ) : (
                    <Text> </Text>
                )}

                <Text
                    style={{
                        color: styles.ERROR__COLOR,
                        fontSize: fontSizes.verySmall,
                        paddingHorizontal: dimensions.indent,
                        paddingTop: dimensions.halfIndent,
                    }}
                >
                    {error}
                </Text>

                <View style={{ flexDirection: 'row', justifyContent: 'flex-end', marginTop: dimensions.vertical(24) }}>
                    <View style={{ flex: 2 }} />
                    <Button style={{ flex: 1, justifyContent: 'center', alignSelf: 'center' }} transparent onPress={hideModal}>
                        <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.verySmall, opacity: 0.34 }}>{t('common_Cancel')}</Text>
                    </Button>
                    <Button
                        disabled={glb_sv.allListFav.some((e) => e.c2 === nameFav)}
                        style={{
                            backgroundColor: glb_sv.allListFav.some((e) => e.c2 === nameFav) ? styles.PRIMARY + '80' : styles.PRIMARY,
                            flex: 1,
                            justifyContent: 'center',
                            alignSelf: 'center',
                            borderRadius: 8,
                        }}
                        onPress={changeNameFav}
                    >
                        <Text style={{ color: '#FFF', fontSize: fontSizes.small }}>{t('save')}</Text>
                    </Button>
                </View>
            </View>
        </Modal>
    )
}

const UI = StyleSheet.create({
    note: {
        fontSize: fontSizes.small,
        marginBottom: dimensions.vertical(32),
    },
    title: {
        fontSize: fontSizes.xmedium,
        fontWeight: fontWeights.semiBold,
        marginBottom: dimensions.vertical(27),
        marginTop: dimensions.vertical(32),
    },
})
