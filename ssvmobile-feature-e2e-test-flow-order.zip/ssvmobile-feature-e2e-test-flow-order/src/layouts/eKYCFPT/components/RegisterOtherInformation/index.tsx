import React, { useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Pressable, StyleSheet, TextInput, TouchableOpacity, View } from 'react-native'
import Modal from 'react-native-modal'
import { Col, Row } from 'native-base'

import ArrowRight from '../../../../assets/images/common/ic_arrow_right.svg'
import { CustomFloatInput, Text } from '../../../../basic-components'
import ModalBottomContent from '../../../../components/trading-component/common/modal-bottom-content'
import ModalBottomRowSelect from '../../../../components/trading-component/common/modal-bottom-row-select'
import { StoreContext } from '../../../../store'
import { dimensions, fontSizes, fontWeights, IconSvg } from '../../../../styles'

interface IRegisterOtherInfomationProps {
    onChangeOtherInformation: (data: {
        investment_purpose: { label: string; value: string }
        yearly_revenue: { label: string; value: string }
        risk_level: { label: string; value: string }
        investment_experiment: { label: string; value: string }
        investment_knowledge: { label: string; value: string }
        has_account_in_other: boolean
        list_account_in_other: { account_number: string; securities_name: string }[]
        isInsider: boolean
        isRelateCustHolder: boolean
        // listInsider: string;
    }) => void
}

const listInvestmentPurpose = [
    { label: 'ekyc_investment_purpose_01', value: '0' }, // Dài hạn
    { label: 'ekyc_investment_purpose_02', value: '1' }, // Trung hạn
    { label: 'ekyc_investment_purpose_03', value: '2' }, // Ngắn hạn
]
const listYearlyRevenue = [
    { label: 'ekyc_yearly_revenue_01', value: '0' }, // <100 triệu VND
    { label: 'ekyc_yearly_revenue_02', value: '1' }, // 100-200 triệu VND
    { label: 'ekyc_yearly_revenue_03', value: '2' }, // 200-500 triệu VND
    { label: 'ekyc_yearly_revenue_04', value: '3' }, // >500 triệu VND
]
const listRiskLevel = [
    { label: 'ekyc_risk_level_01', value: '0' }, // Thấp
    { label: 'ekyc_risk_level_02', value: '1' }, // Trung bình
    { label: 'ekyc_risk_level_03', value: '2' }, // Cao
]
const listInvestmentExperient = [
    { label: 'ekyc_investment_experiment_01', value: '0' }, // Cổ phiếu
    { label: 'ekyc_investment_experiment_02', value: '1' }, // Trái phiếu
    { label: 'ekyc_investment_experiment_03', value: '2' }, // Tín phiếu kho bạc
    { label: 'ekyc_investment_experiment_04', value: '3' }, // Bất động sản
    { label: 'ekyc_investment_experiment_05', value: '4' }, // Chứng khoán khác
    { label: 'ekyc_investment_experiment_06', value: '5' }, // Chưa có
]
const listInvestmentKnowLedge = [
    { label: 'ekyc_investment_knowledge_01', value: '0' }, // Rất tốt
    { label: 'ekyc_investment_knowledge_02', value: '1' }, // Tốt
    { label: 'ekyc_investment_knowledge_03', value: '2' }, // Trung bình
    { label: 'ekyc_investment_knowledge_04', value: '3' }, // Còn hạn chế
]

export const RegisterOtherInfomation = ({ onChangeOtherInformation }: IRegisterOtherInfomationProps) => {
    const { t } = useTranslation()
    const { styles } = useContext(StoreContext)
    const [expandRegisterOtherInfomation, setExpandRegisterOtherInfomation] = useState(true)
    //
    const [modalSelect, setModalSelect] = useState(false)
    const [listSelect, setListSelect] = useState<{ label: string; value: string }[]>([])
    const [typeSelect, setTypeSelect] = useState<
        'investment_purpose' | 'yearly_revenue' | 'risk_level' | 'investment_experiment' | 'investment_knowledge' | ''
    >('')
    //
    const [investment_purpose, setInvestment_purpose] = useState<{ label: string; value: string }>(listInvestmentPurpose[0])
    const [yearly_revenue, setYearly_revenue] = useState<{ label: string; value: string }>(listYearlyRevenue[2])
    const [risk_level, setRisk_level] = useState<{ label: string; value: string }>(listRiskLevel[0])
    const [investment_experiment, setInvestment_experiment] = useState<{ label: string; value: string }>(listInvestmentExperient[0])
    const [investment_knowledge, setInvestment_knowledge] = useState<{ label: string; value: string }>(listInvestmentKnowLedge[1])
    const [hasOtherAccount, setHasOtherAccount] = useState(true)
    const [isRelateCustHolder, setIsRelateCustHolder] = useState(false)
    const [isRelatedInsider, setisRelatedInsider] = useState(false)

    // const [listCompany, setListCompany] = useState([{ account: '', nameCompany: '' }]);
    const [companyAccount, setCompanyAccount] = useState('')
    const [companyName, setCompanyName] = useState('')

    const onSelect = (item) => {
        switch (typeSelect) {
            case 'investment_purpose':
                setInvestment_purpose(item)
                break
            case 'yearly_revenue':
                setYearly_revenue(item)
                break
            case 'risk_level':
                setRisk_level(item)
                break
            case 'investment_experiment':
                setInvestment_experiment(item)
                break
            case 'investment_knowledge':
                setInvestment_knowledge(item)
                break
            default:
                break
        }
    }

    useEffect(() => {
        const info = {
            investment_purpose,
            yearly_revenue,
            risk_level,
            investment_experiment,
            investment_knowledge,
            has_account_in_other: hasOtherAccount,
            list_account_in_other: hasOtherAccount ? [{ account_number: companyAccount, securities_name: companyName }] : [],
            isInsider: isRelatedInsider,
            isRelateCustHolder,
        }
        onChangeOtherInformation(info)
    }, [
        investment_purpose,
        yearly_revenue,
        risk_level,
        investment_experiment,
        investment_knowledge,
        hasOtherAccount,
        isRelateCustHolder,
        isRelatedInsider,
        companyAccount,
        companyName,
    ])

    return (
        <>
            {expandRegisterOtherInfomation ? (
                <>
                    <View>
                        <Text
                            style={{
                                fontSize: fontSizes.small,
                                fontStyle: 'italic',
                                color: styles.WARN__COLOR,
                                marginLeft: dimensions.moderate(32),
                            }}
                        >
                            {t<string>('select_suitable_answers')}
                        </Text>
                    </View>
                    <Pressable
                        onPress={() => {
                            setTypeSelect('investment_purpose')
                            setListSelect(listInvestmentPurpose)
                            setModalSelect(true)
                        }}
                    >
                        <View style={[UI.RowInput]}>
                            <CustomFloatInput
                                animationDuration={100}
                                ellipsizeMode="end"
                                isSelectInput
                                label={t('investment_purpose')}
                                numberOfLines={1}
                                rightComponent={
                                    <TouchableOpacity
                                        style={{ paddingVertical: 8 }}
                                        onPress={() => {
                                            setTypeSelect('investment_purpose')
                                            setListSelect(listInvestmentPurpose)
                                            setModalSelect(true)
                                        }}
                                    >
                                        <ArrowRight
                                            style={{ color: styles.PRIMARY__CONTENT__COLOR, marginVertical: dimensions.vertical(22), marginRight: 10 }}
                                        />
                                    </TouchableOpacity>
                                }
                                value={t(investment_purpose?.label)}
                            />
                        </View>
                    </Pressable>
                    <Pressable
                        onPress={() => {
                            setTypeSelect('yearly_revenue')
                            setListSelect(listYearlyRevenue)
                            setModalSelect(true)
                        }}
                    >
                        <View style={[UI.RowInput]}>
                            <CustomFloatInput
                                animationDuration={100}
                                ellipsizeMode="end"
                                isSelectInput
                                label={t('yearly_revenue')}
                                numberOfLines={1}
                                rightComponent={
                                    <TouchableOpacity
                                        style={{ paddingVertical: 8 }}
                                        onPress={() => {
                                            setTypeSelect('yearly_revenue')
                                            setListSelect(listYearlyRevenue)
                                            setModalSelect(true)
                                        }}
                                    >
                                        <ArrowRight
                                            style={{ color: styles.PRIMARY__CONTENT__COLOR, marginVertical: dimensions.vertical(22), marginRight: 10 }}
                                        />
                                    </TouchableOpacity>
                                }
                                value={t(yearly_revenue?.label)}
                            />
                        </View>
                    </Pressable>
                    <Pressable
                        onPress={() => {
                            setTypeSelect('risk_level')
                            setListSelect(listRiskLevel)
                            setModalSelect(true)
                        }}
                    >
                        <View style={[UI.RowInput]}>
                            <CustomFloatInput
                                animationDuration={100}
                                ellipsizeMode="end"
                                isSelectInput
                                label={t('risk_level')}
                                numberOfLines={1}
                                rightComponent={
                                    <TouchableOpacity
                                        style={{ paddingVertical: 8 }}
                                        onPress={() => {
                                            setTypeSelect('risk_level')
                                            setListSelect(listRiskLevel)
                                            setModalSelect(true)
                                        }}
                                    >
                                        <ArrowRight
                                            style={{ color: styles.PRIMARY__CONTENT__COLOR, marginVertical: dimensions.vertical(22), marginRight: 10 }}
                                        />
                                    </TouchableOpacity>
                                }
                                value={t(risk_level?.label)}
                            />
                        </View>
                    </Pressable>
                    <Pressable
                        onPress={() => {
                            setTypeSelect('investment_experiment')
                            setListSelect(listInvestmentExperient)
                            setModalSelect(true)
                        }}
                    >
                        <View style={[UI.RowInput]}>
                            <CustomFloatInput
                                animationDuration={100}
                                ellipsizeMode="end"
                                isSelectInput
                                label={t('investment_experiment')}
                                numberOfLines={1}
                                rightComponent={
                                    <TouchableOpacity
                                        style={{ paddingVertical: 8 }}
                                        onPress={() => {
                                            setTypeSelect('investment_experiment')
                                            setListSelect(listInvestmentExperient)
                                            setModalSelect(true)
                                        }}
                                    >
                                        <ArrowRight
                                            style={{ color: styles.PRIMARY__CONTENT__COLOR, marginVertical: dimensions.vertical(22), marginRight: 10 }}
                                        />
                                    </TouchableOpacity>
                                }
                                value={t(investment_experiment?.label)}
                            />
                        </View>
                    </Pressable>
                    <Pressable
                        onPress={() => {
                            setTypeSelect('investment_knowledge')
                            setListSelect(listInvestmentKnowLedge)
                            setModalSelect(true)
                        }}
                    >
                        <View style={[UI.RowInput]}>
                            <CustomFloatInput
                                animationDuration={100}
                                ellipsizeMode="end"
                                isSelectInput
                                label={t('investment_knowledge')}
                                numberOfLines={1}
                                rightComponent={
                                    <TouchableOpacity
                                        style={{ paddingVertical: 8 }}
                                        onPress={() => {
                                            setTypeSelect('investment_knowledge')
                                            setListSelect(listInvestmentKnowLedge)
                                            setModalSelect(true)
                                        }}
                                    >
                                        <ArrowRight
                                            style={{ color: styles.PRIMARY__CONTENT__COLOR, marginVertical: dimensions.vertical(22), marginRight: 10 }}
                                        />
                                    </TouchableOpacity>
                                }
                                value={t(investment_knowledge?.label)}
                            />
                        </View>
                    </Pressable>
                    <View style={UI.row}>
                        <TouchableOpacity
                            activeOpacity={0.9}
                            style={{ flexDirection: 'row', alignItems: 'center', marginTop: dimensions.vertical(16) }}
                            onPress={() => {
                                // setHasOtherAccount((value) => !value)
                                // setCompanyAccount('')
                                // setCompanyName('')
                            }}
                        >
                            {/* <View style={{ paddingTop: 2 }}>
                                <IconSvg.CheckboxIcon active={hasOtherAccount} colorActive={styles.PRIMARY} colorunActive={styles.PRIMARY__CONTENT__COLOR} />
                            </View> */}
                            <Text
                                style={{
                                    fontSize: fontSizes.small,
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                    marginLeft: dimensions.moderate(8),
                                    marginRight: 16,
                                }}
                            >
                                {t<string>('ekyc_field_additional_01')}
                            </Text>
                        </TouchableOpacity>
                    </View>
                    {hasOtherAccount ? (
                        <>
                            {/* {listCompany.map(() => {
								return ( */}
                            <Row style={[UI.RowWrap, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                                <View style={{ flex: 20 }}>
                                    <View style={{ flexDirection: 'row', marginTop: 8 }}>
                                        <View style={[UI.LabelInput]}>
                                            <Text
                                                style={{
                                                    fontWeight: fontWeights.bold,
                                                    fontSize: fontSizes.small,
                                                    color: styles.SECOND__CONTENT__COLOR,
                                                    textAlign: 'right',
                                                }}
                                            >
                                                {t<string>('account_number')}:
                                            </Text>
                                        </View>
                                        <View style={[UI.InputValue, { backgroundColor: styles.INPUT__BG }]}>
                                            <TextInput
                                                style={{
                                                    fontSize: fontSizes.small,
                                                    color: styles.PRIMARY__CONTENT__COLOR,
                                                    textAlignVertical: 'center',
                                                    textAlign: 'right',
                                                }}
                                                value={companyAccount}
                                                onChangeText={(value) => {
                                                    setCompanyAccount(value)
                                                }}
                                                placeholderTextColor={styles.SECOND__CONTENT__COLOR}
                                                // placeholder={t('account_number')}
                                                returnKeyType="done"
                                            />
                                        </View>
                                        {/* <View style={{ justifyContent: 'center', alignItems: 'flex-end', paddingLeft: 8 }}>
													<TouchableOpacity onPress={deleteRowCom}>
														<Svg width={20} height={20} fill='none' xmlns='http://www.w3.org/2000/svg'>
															<Path
																d='M10 1.875C5.52 1.875 1.875 5.52 1.875 10S5.52 18.125 10 18.125 18.125 14.48 18.125 10 14.48 1.875 10 1.875zm3.125 8.75h-6.25a.625.625 0 110-1.25h6.25a.625.625 0 110 1.25z'
																fill='#EB5C55'
															/>
														</Svg>
													</TouchableOpacity>
												</View> */}
                                    </View>
                                </View>
                            </Row>
                            <Row style={[UI.RowWrap, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                                <View style={{ flex: 20 }}>
                                    <View style={{ flexDirection: 'row', marginTop: 8 }}>
                                        <View style={[UI.LabelInput]}>
                                            <Text
                                                style={{
                                                    fontWeight: fontWeights.bold,
                                                    fontSize: fontSizes.small,
                                                    color: styles.SECOND__CONTENT__COLOR,
                                                    textAlign: 'right',
                                                }}
                                            >
                                                {t<string>('comp_full_name')}:
                                            </Text>
                                        </View>
                                        <View style={[UI.InputValue, { backgroundColor: styles.INPUT__BG }]}>
                                            <TextInput
                                                style={{
                                                    fontSize: fontSizes.small,
                                                    color: styles.PRIMARY__CONTENT__COLOR,
                                                    textAlignVertical: 'center',
                                                    textAlign: 'right',
                                                }}
                                                value={companyName}
                                                onChangeText={(value) => {
                                                    setCompanyName(value)
                                                }}
                                                placeholderTextColor={styles.SECOND__CONTENT__COLOR}
                                                // placeholder={t('comp_full_name')}
                                                returnKeyType="done"
                                            />
                                        </View>
                                        {/* <View style={{ justifyContent: 'center', alignItems: 'flex-end', paddingLeft: 8 }}>
													<TouchableOpacity onPress={deleteRowCom}>
														<Svg width={20} height={20} fill='none' xmlns='http://www.w3.org/2000/svg'>
															<Path
																d='M10 1.875C5.52 1.875 1.875 5.52 1.875 10S5.52 18.125 10 18.125 18.125 14.48 18.125 10 14.48 1.875 10 1.875zm3.125 8.75h-6.25a.625.625 0 110-1.25h6.25a.625.625 0 110 1.25z'
																fill='#EB5C55'
															/>
														</Svg>
													</TouchableOpacity>
												</View> */}
                                    </View>
                                </View>
                            </Row>
                            {/* );
							})} */}
                        </>
                    ) : null}
                    <View style={UI.row}>
                        <TouchableOpacity
                            activeOpacity={0.9}
                            style={{ flexDirection: 'row', alignItems: 'center', marginTop: dimensions.vertical(16) }}
                            onPress={() => setIsRelateCustHolder((value) => !value)}
                        >
                            <View style={{ paddingTop: 2 }}>
                                <IconSvg.CheckboxIcon active={isRelateCustHolder} colorActive={styles.PRIMARY} colorunActive={styles.PRIMARY__CONTENT__COLOR} />
                            </View>
                            <Text
                                style={{
                                    fontSize: fontSizes.small,
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                    marginLeft: dimensions.moderate(8),
                                    marginRight: 16,
                                }}
                            >
                                {t<string>('ekyc_field_additional_02')}
                            </Text>
                        </TouchableOpacity>
                    </View>

                    <View style={UI.row}>
                        <TouchableOpacity
                            activeOpacity={0.9}
                            style={{ flexDirection: 'row', alignItems: 'center', marginTop: dimensions.vertical(16) }}
                            onPress={() => setisRelatedInsider((value) => !value)}
                        >
                            <View style={{ paddingTop: 2 }}>
                                <IconSvg.CheckboxIcon active={isRelatedInsider} colorActive={styles.PRIMARY} colorunActive={styles.PRIMARY__CONTENT__COLOR} />
                            </View>
                            <Text
                                style={{
                                    fontSize: fontSizes.small,
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                    marginLeft: dimensions.moderate(8),
                                    marginRight: 16,
                                }}
                            >
                                {t<string>('ekyc_field_additional_03')}
                            </Text>
                        </TouchableOpacity>
                    </View>
                </>
            ) : null}

            {modalSelect ? (
                <Modal
                    isVisible={modalSelect}
                    style={UI.modal}
                    useNativeDriver={true}
                    onBackButtonPress={() => setModalSelect(false)}
                    onBackdropPress={() => setModalSelect(false)}
                >
                    <View
                        style={{
                            backgroundColor: styles.PRIMARY__BG__COLOR,
                            justifyContent: 'flex-start',
                            borderTopLeftRadius: 12,
                            borderTopRightRadius: 12,
                        }}
                    >
                        <ModalBottomContent title={t(typeSelect)}>
                            {listSelect.map((item, index) => (
                                <ModalBottomRowSelect
                                    text={t(item.label) || ''}
                                    onPress={() => {
                                        onSelect(item)
                                        setModalSelect(false)
                                    }}
                                    key={item.value}
                                    // checked={investment_purpose.value === item.value}
                                />
                            ))}
                        </ModalBottomContent>
                    </View>
                </Modal>
            ) : null}
        </>
    )
}

const UI = StyleSheet.create({
    BlankSpace: {
        height: 10,
        width: dimensions.moderate(40),
    },
    ButtonDelete: {
        alignItems: 'center',
        height: '100%',
        justifyContent: 'center',
        position: 'absolute',
        right: 0,
    },
    InputValue: {
        borderRadius: 4,
        flex: 5,
        paddingHorizontal: 10,
        paddingVertical: 8,
    },
    LabelInput: { borderRadius: 4, flex: 4, marginRight: 8, paddingVertical: 8 },
    RowInput: {
        marginHorizontal: dimensions.moderate(16),
        marginTop: dimensions.vertical(16),
    },
    RowWrap: {
        borderRadius: 8,
        marginHorizontal: dimensions.moderate(16),
        paddingVertical: dimensions.moderate(4),
    },
    modal: {
        justifyContent: 'flex-end',
        margin: 0,
    },
    row: {
        alignItems: 'center',
        borderRadius: 12,
        flexDirection: 'row',
        marginHorizontal: dimensions.moderate(16),
    },
})
