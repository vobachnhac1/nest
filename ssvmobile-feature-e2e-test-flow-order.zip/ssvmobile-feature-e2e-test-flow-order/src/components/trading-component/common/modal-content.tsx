import React, { useContext } from 'react'
import { View } from 'react-native'

import { Text } from '../../../basic-components'
import { StoreContext } from '../../../store'
import { dimensions as dm, fontSizes as fs, fontWeights as fw } from '../../../styles'

interface IModalContent {
    children?: any
    title?: string
    title2?: string
    type?: 'confirm' | 'notify'
    iconComponent?: any
    isBottom?: boolean
}

const ModalContent = ({
    children,
    title = '', // Nội dung modal
    title2,
    type = 'confirm', // type của title - confirm|notify
    iconComponent,
    isBottom,
}: IModalContent) => {
    const { styles } = useContext(StoreContext)

    const getColorTitleModal = (type) => {
        if (type === 'confirm') return styles.PRIMARY
        if (type === 'notify') return styles.PRIMARY__CONTENT__COLOR
        return styles.SELL__BG
    }

    return (
        <View
            style={{
                backgroundColor: styles.HEADER__BG__COLOR,
                paddingVertical: dm.verticalIndent,
                marginHorizontal: isBottom ? 0 : dm.moderate(16),
                justifyContent: 'flex-start',
                borderRadius: 16,
            }}
        >
            <View
                style={{
                    flex: 1,
                    justifyContent: 'center',
                    alignSelf: 'center',
                    paddingVertical: iconComponent ? dm.vertical(32) : dm.vertical(8),
                    textAlign: 'center',
                }}
            >
                {iconComponent}
            </View>
            {title ? (
                <Text
                    style={{
                        textAlign: 'center',
                        marginVertical: dm.halfIndent,
                        marginHorizontal: dm.moderate(16),
                        fontSize: fs.xmedium,
                        color: getColorTitleModal(type),
                        fontWeight: type === 'notify' ? fw.normal : fw.bold,
                        paddingBottom: dm.vertical(8),
                    }}
                >
                    {title}
                </Text>
            ) : null}
            {title2 ? (
                <Text
                    style={{
                        textAlign: 'center',
                        marginVertical: dm.halfIndent,
                        marginHorizontal: dm.moderate(16),
                        fontSize: fs.normal,
                        fontWeight: fw.bold,
                        paddingBottom: dm.vertical(16),
                        color: styles.PRIMARY__CONTENT__COLOR,
                    }}
                >
                    {title2}
                </Text>
            ) : null}
            {children}
        </View>
    )
}

export default ModalContent
