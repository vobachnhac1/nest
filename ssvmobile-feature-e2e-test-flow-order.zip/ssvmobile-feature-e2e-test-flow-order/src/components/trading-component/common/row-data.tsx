import React, { useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { StyleSheet, View } from 'react-native'
import { Col, Right, Row } from 'native-base'

import { Text } from '../../../basic-components'
import { StoreContext } from '../../../store'
import { dimensions as dm, fontSizes as fs, fontWeights as fw } from '../../../styles'

interface IRowData {
    textLeft?: string
    textLeft2?: string
    textRight?: string
    textRight2?: string
    rightComponent?: any
    dataSub?: string[]
    rightColor?: string
    type?: 'detail' | 'highlight' | undefined
    last?: boolean
    hideSub?: boolean
}

const RowData = ({
    textLeft, // Nội dung Bên trái
    textLeft2, // Nội dung phụ bên trái
    textRight, // Nội dung bên phải
    textRight2, // Nội dung phụ bên phải
    rightComponent,
    dataSub = [], // Nội dung sub
    rightColor, // Color bên phải
    type = 'detail', // type của Row
    last, // có phải là button cuối cùng của list button hay không
    hideSub = false, // Ẩn tiểu khoản
    ...props
}: IRowData) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()
    return (
        <Row
            style={{
                paddingTop: dm.vertical(12),
                paddingBottom: dm.vertical(12),
                marginHorizontal: dm.moderate(16),
                borderBottomColor: styles.DIVIDER__COLOR,
                borderBottomWidth: last ? 0 : 1,
            }}
        >
            <Col style={{ justifyContent: 'center' }}>
                <Text
                    style={{
                        color: styles.SECOND__CONTENT__COLOR,
                        fontSize: type === 'detail' ? fs.normal : fs.medium,
                    }}
                >
                    {textLeft}
                    {textLeft2 ? <Text style={{ fontSize: fs.small, color: styles.SECOND__CONTENT__COLOR, textAlign: 'right' }}>{textLeft2}</Text> : null}
                </Text>
            </Col>
            {/* @ts-expect-error */}
            <Right>
                {textRight ? (
                    <Text
                        style={{
                            fontSize: type === 'detail' ? fs.normal : fs.medium,
                            color: rightColor ? rightColor : styles.PRIMARY__CONTENT__COLOR,
                            fontWeight: type === 'detail' ? fw.normal : fw.bold,
                            textDecorationLine: type === 'highlight' ? 'underline' : 'none',
                            textAlign: 'right',
                        }}
                    >
                        {textRight}
                    </Text>
                ) : null}
                {dataSub[0] ? (
                    <View style={{ flex: 1, flexDirection: 'row' }}>
                        <Text
                            style={{
                                fontSize: fs.normal,
                                fontWeight: fw.semiBold,
                                color: styles.PRIMARY__CONTENT__COLOR,
                            }}
                        >
                            {dataSub[0]}
                        </Text>
                        {!hideSub ? (
                            <View style={{ ...UI.Badge_Sub, backgroundColor: styles.PRIMARY }}>
                                <Text style={{ color: '#fff', fontSize: fs.verySmall, fontWeight: fw.bold }}>{dataSub[1]}</Text>
                            </View>
                        ) : null}
                    </View>
                ) : null}
                {textRight2 ? <Text style={{ fontSize: fs.small, color: styles.SECOND__CONTENT__COLOR, textAlign: 'right' }}>{textRight2}</Text> : null}
                {rightComponent}
            </Right>
        </Row>
    )
}

export default RowData

const UI = StyleSheet.create({
    Badge_Sub: {
        alignItems: 'center',
        borderRadius: 4,
        height: dm.moderate(20),
        justifyContent: 'center',
        marginLeft: 4,
        width: dm.moderate(20),
    },
})
