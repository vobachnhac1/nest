import { glb_sv, reqFunct, Screens, socket_sv } from '../../utils'

/**
 * Là một function. Return true or false
 * @param {Array} arrAllow    Array các công ty cho phép hiển thị
 * @returns {Boolean}         True went active Company have permission to access this Page|Tab|Scree|Component
 */
const allowCompanyRender = (arrAllow = []) => {
    const activeCode = glb_sv.activeCode // TODO : remove code when get full source to local branch
    return arrAllow.includes(activeCode)
}

export default allowCompanyRender
