import React from 'react'
import { Subject } from 'rxjs'

// --- End chart performance
import HighChartAssetsPieChart from './AssetsPieChart'
import ChartF2 from './chart-f2'
import ForeignerTradeChart from './highchart/foreigner-trade'
import ChartMarketCap from './highchart/market-cap'
import ChartMarketLiquidity from './highchart/market-liquidity'
// Chart Performance
import AssetsWeight from './highchart/MyPerformance/AssetsWeight'
import ChartProfitLossColumn from './highchart/MyPerformance/ChartProfitLossColumn'
import ChartProfitLossCompare from './highchart/MyPerformance/ChartProfitLossCompare'
import ChartProfitLossCalculation from './highchart/ProfitLossCalculation/index'
import LightChart from './light-chart'
import LightChartMonth from './light-chart/light-chart-month'

class App extends React.Component {
    constructor(props) {
        super(props)
        window.eventMarket = new Subject()
        if (!window.theme) window.theme = 'LIGHT'
        if (!window.dataLightChart) window.dataLightChart = []
    }

    render() {
        if (window.chartName === 'foreigner_trade') return <ForeignerTradeChart />
        // Chart Performance
        if (window.chartName === 'my_performance_assets_weight') return <AssetsWeight />
        if (window.chartName === 'my_performance_profit_loss_column') return <ChartProfitLossColumn />
        if (window.chartName === 'my_performance_profit_loss_compare') return <ChartProfitLossCompare />
        if (window.chartName === 'ProfitLossCalculation') return <ChartProfitLossCalculation />
        // --- End chart performance
        if (window.isMarket) return <ChartF2 />
        if (window.isChartMonth) return <LightChartMonth />
        if (window.chartName === 'market_cap') return <ChartMarketCap />
        if (window.chartName === 'market_liquity') return <ChartMarketLiquidity />
        if (window.chartName === 'AssetPieChartOwn') return <HighChartAssetsPieChart />
        if (window.chartName === 'LightChart_Intraday_StockInfo') return <LightChart />

        // eslint-disable-next-line no-undef
        return <div style={{ color: 'red', textAlign: 'center' }}>{t('error_loading_chart')}</div>
        // return <LightChart />
    }
}
export default App
