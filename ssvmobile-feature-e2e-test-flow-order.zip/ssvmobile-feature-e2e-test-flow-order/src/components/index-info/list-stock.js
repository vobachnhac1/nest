import React, { memo, useCallback, useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { FlatList, InteractionManager, StyleSheet, View } from 'react-native'
import Svg, { Path } from 'react-native-svg'
import throttle from 'lodash/throttle'
import { Button, Row } from 'native-base'

import { Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { dimensions, fontSizes, fontWeights } from '../../styles'
import { eventList, FormatNumber, glb_sv } from '../../utils'
import HeaderTop from '../market-tab/TopMarket/HeaderTop'

const StockItem = memo(({ item, styles, onChangeStkInfo }) => {
    return (
        <Row style={styless.HeaderTop_view} onPress={() => onChangeStkInfo(item)}>
            <View style={{ flex: 1 }}>
                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.verySmall, fontWeight: fontWeights.medium }}>{item.t55}</Text>
            </View>
            <View style={{ flex: 1 }}>
                {item.t31 ? (
                    <Text
                        style={{
                            color: glb_sv.getColor(item.t31, item, styles),
                            fontSize: fontSizes.verySmall,
                            fontWeight: fontWeights.medium,
                            textAlign: 'right',
                        }}
                    >
                        {item.t31_incr_per > 0 ? '+' : ''}
                        {FormatNumber(item.t31_incr_per, 2)}%
                    </Text>
                ) : null}
            </View>
            <View style={{ flex: 1 }}>
                <Text
                    style={{
                        color: glb_sv.getColor(item.t260, item, styles),
                        fontSize: fontSizes.verySmall,
                        fontWeight: fontWeights.medium,
                        textAlign: 'right',
                    }}
                >
                    {FormatNumber(item.t137, 0, 1)}
                </Text>
            </View>
            <View style={{ flex: 1 }}>
                <Text
                    style={{
                        color: glb_sv.getColor(item.t31, item, styles),
                        fontSize: fontSizes.verySmall,
                        fontWeight: fontWeights.medium,
                        textAlign: 'right',
                    }}
                >
                    {FormatNumber(item.t31 || item.t260, 0, 1)}
                </Text>
            </View>
            <View style={{ flex: 1 }}>
                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.verySmall, fontWeight: fontWeights.medium, textAlign: 'right' }}>
                    {FormatNumber(item.t391, 0, 1, 'short')}
                </Text>
            </View>
        </Row>
    )
}, compareStockItem)

function compareStockItem(prev, next) {
    if (
        prev.item.t31 === next.item.t31 &&
        prev.item.t260 === next.item.t260 &&
        prev.item.t137 === next.item.t137 &&
        prev.item.t391 === next.item.t391 &&
        prev.item.t31_incr_per === next.item.t31_incr_per
    )
        return true
    return false
}

const RenderSeparator = memo(
    ({ styles }) => {
        return (
            <View
                style={{
                    height: 1,
                    backgroundColor: styles.DIVIDER__COLOR,
                }}
            />
        )
    },
    () => true,
)

const FooterComponent = memo(
    ({ showAllStk, type }) => {
        const { styles } = useContext(StoreContext)
        const { t } = useTranslation()
        return (
            <Row style={{ paddingVertical: 10, justifyContent: 'center' }}>
                <Button style={{ width: 150, justifyContent: 'center' }} transparent onPress={() => showAllStk(type)}>
                    <Text style={{ color: styles.PRIMARY, fontSize: fontSizes.verySmall, fontWeight: fontWeights.medium }}>{t('view_all')}</Text>
                    <ChevoletIcon color={styles.PRIMARY} />
                </Button>
            </Row>
        )
    },
    () => true,
)

function ListStock({ listStock, showAllStk, onChangeStkInfo, maxList, type }) {
    const { styles } = useContext(StoreContext)
    const [list, setList] = useState([])
    const { t } = useTranslation()

    const throttled = useRef(
        throttle(
            () => {
                const newList = listStock.map((e) => {
                    return glb_sv.StockMarket[e.t55] ? { ...glb_sv.StockMarket[e.t55] } : { t55: e.t55, U9: '', t31: 0, t31_incr_per: 0 }
                })
                setList(newList)
            },
            500,
            { trailing: true },
        ),
    )

    useEffect(() => {
        const eventMarket = glb_sv.eventMarket.subscribe((msg) => {
            if (msg.type === eventList.SUB_STOCK && msg.message === 'SI' && msg.isUpdateWatchlistMobile) {
                throttled.current()
            }
        })
        InteractionManager.runAfterInteractions(() => throttled.current())
        return () => {
            eventMarket.unsubscribe()
            throttled.current.cancel()
        }
    }, [])

    const renderHeader = useCallback(() => {
        return <HeaderTop activeOtp="1D" type="TOP_PRI_UP" />
    }, [])

    const renderSep = useCallback(() => {
        return <RenderSeparator styles={styles} />
    }, [])

    const renderItem = useCallback(({ item }) => {
        return <StockItem item={item} styles={styles} onChangeStkInfo={onChangeStkInfo} />
    })

    return (
        <FlatList
            data={list}
            ItemSeparatorComponent={renderSep}
            keyExtractor={(item, index) => item?.t55 || index.toString()}
            ListEmptyComponent={
                <View style={{ height: 200, justifyContent: 'center', alignItems: 'center' }}>
                    <Text style={{ color: styles.SECOND__CONTENT__COLOR }}>{t('common_NoDataFound')}</Text>
                </View>
            }
            ListFooterComponent={maxList > 30 && list.length ? <FooterComponent showAllStk={showAllStk} type={type} /> : null}
            ListHeaderComponent={renderHeader}
            renderItem={renderItem}
            scrollEnabled={false}
            style={{ paddingHorizontal: dimensions.moderate(16), backgroundColor: styles.PRIMARY__BG__COLOR, paddingTop: dimensions.vertical(5) }}
        />
    )
}

const styless = StyleSheet.create({
    HeaderTop_view: {
        paddingVertical: 5,
    },
})

function ChevoletIcon({ color }) {
    return (
        <Svg height={16} viewBox="0 0 16 16" width={16}>
            <Path d="M5.75 3.5l4.5 4.5-4.5 4.5" stroke={color} strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.2} />
        </Svg>
    )
}

export default memo(ListStock)
