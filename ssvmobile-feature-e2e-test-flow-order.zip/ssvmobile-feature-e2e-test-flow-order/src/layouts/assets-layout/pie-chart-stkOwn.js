import React, { memo } from 'react'
import { Platform, View } from 'react-native'
import { WebView } from 'react-native-webview'

import Chart from '../../components/f2-chart'
import { StoreContext } from '../../store'
import { dimensions } from '../../styles'
import { glb_sv } from '../../utils'

const IOS = Platform.OS === 'ios' ? true : false

const PieChart = ({ data }) => {
    const { styles } = React.useContext(StoreContext)
    if (data.length) {
        return (
            <View style={{ paddingLeft: 5, minWidth: (dimensions.WIDTH - dimensions.moderate(16)) / 2 }}>
                <View style={{ height: (dimensions.HIEGHT - dimensions.moderate(360)) / 2, backgroundColor: styles.PRIMARY__BG__COLOR }}>
                    <Chart data={data} initScript={IOS ? chartAssetIOS(data) : chartAssetAndroid(data)} webView={WebView} />
                </View>
                <View style={{ height: 20 }} />
            </View>
        )
    }
    return <View />
}

export default memo(PieChart)

const chartAssetAndroid = (data) => `
setTimeout(() => {
const chart = new F2.Chart({
  id: 'chart',
});
chart.source(${JSON.stringify(data)});
chart.coord('polar', {
  transposed: true,
  innerRadius: 0.4,
  radius: 1
});
chart.axis(false);
chart.legend({
  position: 'bottom',
  align: 'center'
});
chart.tooltip(false);
// 配置文本饼图
chart.pieLabel({
  sidePadding: 75,
  label1: function label1(data) {
    return {
      text: data.memo,
      fill: '#808080'
    };
  },
});
chart.interval()
  .position('const*ratio')
  .color('memo', [ '#1890FF', '#13C2C2', '#2FC25B', '#FACC14', '#F04864', '#8543E0', '#3436C7', '#223273' ])
  .adjust('stack');
chart.render();
window.chart = chart
},1000);
true;
`

const chartAssetIOS = (data) => `
setTimeout(() => {
const chart = new F2.Chart({
  id: 'chart',
  pixelRatio: window.devicePixelRatio,
});
chart.source(${JSON.stringify(data)});
chart.coord('polar', {
  transposed: true,
  innerRadius: 0.4,
  radius: 0.75
});
chart.axis(false);
chart.legend({
  position: 'bottom',
  align: 'center'
});
chart.tooltip(false);
// 配置文本饼图
chart.pieLabel({
  sidePadding: 75,
  label1: function label1(data) {
    return {
      text: data.memo,
      fill: '#808080'
    };
  },
});
chart.interval()
  .position('const*ratio')
  .color('memo', [ '#1890FF', '#13C2C2', '#2FC25B', '#FACC14', '#F04864', '#8543E0', '#3436C7', '#223273' ])
  .adjust('stack');
chart.render();
window.chart = chart
},1000);
true;
`
