import React from 'react'
import { Animated, Easing, PanResponder, StyleSheet, View } from 'react-native'

import { Text } from '../../basic-components'
import { fontSizes } from '../../styles'
import { WIDTH } from '../../styles/helper/dimensions'
import { PortalContext } from './portalContext'

const ToastType = {
    Info: 'info',
    Error: 'error',
    Success: 'success',
}
export { ToastType }

class Toast extends React.PureComponent {
    static contextType = PortalContext
    constructor(props) {
        super(props)

        // this.panResponder = PanResponder.create({
        //     onMoveShouldSetPanResponderCapture: () => {
        //         this.onTouch()
        //         return true
        //     },
        //     onPanResponderMove: () => false,
        //     onPanResponderRelease: (event, { dy }) => {
        //         if (dy < 0) {
        //             this.endAnimation()
        //         }
        //     },
        // })

        this.state = {
            animationXY: new Animated.ValueXY({ x: 0, y: -200 }),
            animationOpacity: new Animated.Value(0),
            swipe: false,
        }
    }

    componentDidMount() {
        this.onShow()
    }

    componentWillUnmount() {}

    onShow = () => {
        this.startAnimation()

        this.timer = setTimeout(() => {
            if (!this.state.swipe) {
                this.endAnimation()
            }
        }, 5000)
    }

    // onTouch = () => {
    //     if (this.timer) {
    //         clearTimeout(this.timer)
    //     }
    //     this.setState({ swipe: true })
    // }

    startAnimation = () => {
        const { animationXY, animationOpacity } = this.state

        Animated.parallel([
            Animated.timing(animationXY, {
                toValue: { x: 0, y: 0 },
                useNativeDriver: true,
                easing: Easing.bezier(0.175, 0.885, 0.32, 1.125),
                duration: 400,
            }),
            Animated.timing(animationOpacity, {
                toValue: 1,
                useNativeDriver: true,
                duration: 400,
            }),
        ]).start()
    }

    endAnimation = () => {
        const { animationXY, animationOpacity } = this.state

        Animated.parallel([
            Animated.timing(animationXY, {
                toValue: { x: 0, y: -200 },
                useNativeDriver: true,
                duration: 400,
            }),
            Animated.timing(animationOpacity, {
                toValue: 0,
                useNativeDriver: true,
                duration: 200,
            }),
        ]).start(() => {
            this.setState({ swipe: false })
            // We should clean up our toaster after the animation has ended
            this.context.teleport('toaster', null)
        })
    }

    render() {
        const { children, color } = this.props
        const { animationXY, animationOpacity } = this.state

        // let toastContainerStyle = {}
        // let toastTextStyle = {}

        // switch (type) {
        //     case ToastType.Info:
        //         toastContainerStyle = styles.infoContainer
        //         toastTextStyle = styles.infoText
        //         break
        //     case ToastType.Error:
        //         toastContainerStyle = styles.errorContainer
        //         toastTextStyle = styles.errorText
        //         break
        //     case ToastType.Success:
        //         toastContainerStyle = styles.successContainer
        //         toastTextStyle = styles.successText
        //         break
        //     default:
        //         break
        // }

        const animatedStyle = {
            opacity: animationOpacity,
            transform: [{ translateY: animationXY.y }, { translateX: animationXY.x }],
        }

        return (
            <View style={styles.containerToaster}>
                <Animated.View {...this.panResponder?.panHandlers} style={[styles.container, animatedStyle]}>
                    <View style={StyleSheet.flatten([styles.contentContainer, { backgroundColor: color }])}>
                        <Text style={styles.text}>{children}</Text>
                    </View>
                </Animated.View>
            </View>
        )
    }
}

export default Toast

const styles = StyleSheet.create({
    container: {
        alignItems: 'center',
        flex: 1,
        justifyContent: 'center',
        marginBottom: 12,
        marginHorizontal: 0,
    },
    containerToaster: {
        elevation: 100,
        flex: 1,
        height: 'auto',
        justifyContent: 'center',
        left: 0,
        position: 'absolute',
        width: '100%',
        zIndex: 100000,
    },
    contentContainer: {
        alignItems: 'center',
        borderRadius: 5,
        elevation: 8,
        flexDirection: 'row',
        minHeight: 100,
        paddingHorizontal: 5,
        paddingTop: 30,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.16,
        shadowRadius: 8,
        width: WIDTH,
    },
    errorContainer: {
        backgroundColor: 'red',
    },
    errorText: {
        color: 'white',
    },
    infoContainer: {
        backgroundColor: 'skyblue',
    },
    infoText: {
        color: 'white',
    },
    successContainer: {
        backgroundColor: 'green',
    },
    successText: {
        color: 'white',
    },
    text: {
        color: 'white',
        flex: 1,
        fontSize: fontSizes.normal,
        marginHorizontal: 8,
        paddingVertical: 8,
    },
})
