import React, { useCallback, useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { FlatList, StyleSheet, TextInput, View } from 'react-native'
import { TouchableOpacity } from 'react-native-gesture-handler'
import Modal from 'react-native-modal'
import { SafeAreaView } from 'react-native-safe-area-context'
import AntDesign from 'react-native-vector-icons/AntDesign'
import { Body, Button, Col, Icon, ListItem, Row } from 'native-base'

import { Text } from '../../basic-components'
import { ButtonCustom } from '../../components/trading-component'
import { allowCompanyRender } from '../../hoc'
import { StoreContext } from '../../store'
import { dimensions as dm, fontSizes as fs, fontWeights } from '../../styles'
import { glb_sv } from '../../utils'
// import { fontWeights, dimensions, fontSizes } from '../../styles';

interface IListSelectionProps {
    isOpen: boolean
    actionType:
        | 'NORMAL_SELECT'
        | 'PICK_BANK_EKYC'
        | 'PICK_SUB_BANK_EKYC'
        | 'PICK_BANK_TRANSFER'
        | 'PICK_BANK_RECEIVE'
        | 'PICK_ACCOUNT_RECEIVE'
        | 'PICK_WITHDRAWAL_ACCOUNT_RECEIVE'
        | 'PICK_RIGHT_TYPE'
        | string
    getSelectValue: (data?: IItemSelect) => void
    listSelectionsProps: IItemSelect[]
    setIsOpen: React.Dispatch<React.SetStateAction<boolean>>
    callBackOtherFunction: () => void
}
interface IItemSelect {
    label: string
    value: string
    data: IServiceResponeData | any
}
export default function ListSelection({
    isOpen,
    actionType,
    getSelectValue,
    listSelectionsProps,
    setIsOpen,
    callBackOtherFunction = () => null,
}: IListSelectionProps) {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()
    const [seach, setSearch] = useState('')
    const [checkType, setCheckType] = useState('')
    const [originalDataList, setOriginalDataList] = useState<IItemSelect[]>([])
    const [listSelections, setListSelections] = useState<IItemSelect[]>([])
    const timeOutSearch = useRef<any>(null)
    // const [isModalOpen, setIsModalOpen] = useState(false);
    useEffect(() => {
        if (actionType === 'PICK_BANK_TRANSFER') {
            const listBank = glb_sv.ListBankTrans
            setListSelections(listBank)
            setOriginalDataList(listBank)
        } else if (actionType === 'PICK_BANK_RECEIVE') {
            const listBankReceive = glb_sv.ListBankReceive
            setListSelections(listBankReceive)
            setOriginalDataList(listBankReceive)
        } else if (actionType === 'PICK_ACCOUNT_RECEIVE') {
            const listBankReceive = glb_sv.ListBankReceive
            setListSelections(listBankReceive)
            setOriginalDataList(listBankReceive)
        } else if (actionType === 'PICK_WITHDRAWAL_ACCOUNT_RECEIVE') {
            const listBankReceive = glb_sv.withdrawalBankList
            setListSelections(listBankReceive)
            setOriginalDataList(listBankReceive)
        } else if (actionType === 'PICK_RIGHT_TYPE') {
            const listRightType = glb_sv.ListRightType
            setListSelections(listRightType)
            setOriginalDataList(listRightType)
        } else if (actionType === 'PICK_BANK_EKYC' || actionType === 'PICK_SUB_BANK_EKYC' || actionType === 'NORMAL_SELECT') {
            setSearch('')
            setListSelections(listSelectionsProps)
            setOriginalDataList(listSelectionsProps)
        }
    }, [actionType, listSelectionsProps])

    const lengthSearch = useRef(0)
    const onSearch = (name) => {
        setSearch(name)

        if (timeOutSearch.current) clearTimeout(timeOutSearch.current)
        timeOutSearch.current = setTimeout(() => {
            if (name === '') {
                setListSelections(originalDataList)
                return
            }

            const searchLowerCase = name.toLowerCase() || ''

            const dataSearch = lengthSearch.current > name.length ? originalDataList : listSelections
            const newList = dataSearch.filter((o) => {
                // return new RegExp(searchLowerCase).test(o.label.toLowerCase())
                return o.label.toLowerCase().indexOf(searchLowerCase) !== -1 // Fastest ???
                // return o.label.toLowerCase().includes(searchLowerCase) // Fastest ???
            })
            // .sort(function (a, b) {
            //     if (a.label > b.label) return -1
            //     if (a.label < b.label) return 1
            //     return 0
            // })

            setListSelections((prev) => {
                return newList
            })
            lengthSearch.current = name.length
        }, 500)
    }

    const ItemSelect = ({ item }) => {
        const onClickSelectAnItem = () => {
            onSelect(item)
            setCheckType(item.value?.c0)
            setIsOpen(false)
        }
        return (
            <ListItem
                activeOpacity={0.6}
                style={{
                    borderBottomColor: styles.DIVIDER__COLOR,
                    height: dm.vertical(55),
                }}
                underlayColor="transparent"
                onPress={onClickSelectAnItem}
            >
                <Body style={UI.bodyRow}>
                    <Row>
                        <Col size={24}>
                            <Text
                                style={{
                                    color: checkType == item.value?.c0 && actionType === 'PICK_RIGHT_TYPE' ? styles.PRIMARY : styles.PRIMARY__CONTENT__COLOR,
                                    fontWeight: fontWeights.medium,
                                }}
                            >
                                {item.label}
                            </Text>
                        </Col>
                        <Col size={2} style={UI.colIcon}>
                            {checkType == item.value?.c0 && actionType === 'PICK_RIGHT_TYPE' ? (
                                <Icon name="check" style={{ color: styles.PRIMARY }} type="AntDesign" />
                            ) : (
                                <Text />
                            )}
                        </Col>
                    </Row>
                </Body>
            </ListItem>
        )
    }

    const resetData = () => {
        setSearch('')
        setListSelections(originalDataList)
        if ([].length === 0 && '') console.log('asdf')
    }

    const ListEmpty = () => {
        return (
            <View style={{ justifyContent: 'center', flex: 1, margin: 10 }}>
                <Text style={{ textAlign: 'center', color: styles.PRIMARY__CONTENT__COLOR }}>{t<string>('no_match_result')}</Text>
            </View>
        )
    }
    const onSelect = useCallback(
        (selection) => {
            if (actionType === 'PICK_BANK_TRANSFER') {
                getSelectValue(selection)
            } else if (actionType === 'PICK_BANK_RECEIVE') {
                getSelectValue(selection)
            } else if (actionType === 'PICK_ACCOUNT_RECEIVE') {
                getSelectValue(selection)
            } else if (actionType === 'PICK_RIGHT_TYPE') {
                getSelectValue(selection)
            } else if (actionType === 'PICK_WITHDRAWAL_ACCOUNT_RECEIVE') {
                getSelectValue(selection)
            } else if (actionType === 'PICK_BANK_EKYC' || actionType === 'PICK_SUB_BANK_EKYC' || actionType === 'NORMAL_SELECT') {
                getSelectValue(selection)
            }
        },
        [actionType, getSelectValue],
    )

    const dismiss = () => {
        setIsOpen(false)
    }

    return (
        <Modal
            animationIn="slideInUp"
            animationOut="slideOutDown"
            hideModalContentWhileAnimating={true}
            // animationIn="slideInLeft"
            // animationOut="slideOutLeft"
            isVisible={isOpen}
            style={UI.modal}
            useNativeDriver={true}
        >
            <View
                style={{
                    flex: 1,
                    backgroundColor: styles.PRIMARY__BG__COLOR,
                }}
            >
                <SafeAreaView style={{ flex: 1 }}>
                    <View style={UI.container}>
                        {actionType === 'PICK_RIGHT_TYPE' ? (
                            <View
                                style={{
                                    flexDirection: 'row',
                                    flex: 1,
                                }}
                            >
                                <Text style={{ fontSize: fs.big, fontWeight: fontWeights.semiBold, color: styles.PRIMARY__CONTENT__COLOR }}>
                                    {t<string>('list_right_type')}
                                </Text>
                            </View>
                        ) : (
                            <View
                                style={{
                                    backgroundColor: styles.HEADER__BG__COLOR,
                                    flexDirection: 'row',
                                    flex: 1,
                                    borderRadius: 50,
                                }}
                            >
                                <AntDesign
                                    color={styles.PLACEHODLER__COLOR}
                                    name="search1"
                                    size={20}
                                    style={{
                                        paddingVertical: dm.moderate(8),
                                        paddingLeft: dm.moderate(8),
                                    }}
                                />
                                <TextInput
                                    placeholder={t('search')}
                                    placeholderTextColor={styles.PLACEHODLER__COLOR}
                                    style={{
                                        color: styles.PRIMARY__CONTENT__COLOR,
                                        fontSize: fs.small,
                                        padding: 0,
                                        paddingHorizontal: 5,
                                        flex: 1,
                                    }}
                                    value={seach}
                                    // autoCapitalize="characters"
                                    onChangeText={onSearch}
                                />
                                {/* <View style={{ justifyContent: 'center' }}>
                                    <Text style={{ textAlignVertical: 'center', color: styles.PRIMARY }}>({listSelections.length})</Text>
                                </View> */}
                                {seach ? (
                                    <AntDesign
                                        color={styles.PLACEHODLER__COLOR}
                                        name="closecircle"
                                        size={20}
                                        style={{ paddingVertical: 7, paddingHorizontal: 5 }}
                                        onPress={resetData}
                                    />
                                ) : null}
                            </View>
                        )}
                        <Button
                            style={{
                                justifyContent: 'center',
                                alignSelf: 'center',
                                paddingHorizontal: dm.moderate(24),
                            }}
                            transparent
                            onPress={() => setIsOpen(false)}
                        >
                            <Text
                                style={{
                                    color: styles.BUTTON__TEXT__ACTIVE,
                                    fontSize: fs.medium,
                                }}
                            >
                                {t<string>('common_Cancel')}
                            </Text>
                        </Button>
                    </View>

                    {/* {listSelections.length === 0 ? (
                        <View>
                            <Text style={{ color: styles.HEADER__CONTENT__COLOR }}>Không có lựa chọn</Text>
                        </View>
                    ) : ( */}
                    <FlatList
                        data={listSelections}
                        keyboardShouldPersistTaps="always"
                        keyExtractor={(item, index) => String(index)}
                        ListEmptyComponent={ListEmpty}
                        ListFooterComponent={() => {
                            if (allowCompanyRender(['081', '888']) && actionType === 'PICK_WITHDRAWAL_ACCOUNT_RECEIVE') {
                                // return (
                                //     <View style={[UI.ButtonAdd, { backgroundColor: styles.PRIMARY }]}>
                                //         <TouchableOpacity
                                //             onPress={callBackOtherFunction}>
                                //             <Text style={{ color: '#fff', fontWeight: fontWeights.bold }}>{t('other_bank_with_same_account_name')}</Text>
                                //         </TouchableOpacity>
                                //     </View>
                                // )
                                return <ButtonCustom text={t('other_bank_with_same_account_name')} onPress={callBackOtherFunction} />
                            } else return null
                        }}
                        renderItem={ItemSelect}
                        style={{ marginBottom: 20 }}
                    />
                    {/* )} */}
                </SafeAreaView>
            </View>
        </Modal>
    )
}

const UI = StyleSheet.create({
    ButtonAdd: {
        alignItems: 'center',
        alignSelf: 'center',
        borderRadius: 100,
        justifyContent: 'center',
        marginHorizontal: dm.moderate(16),
        marginVertical: 16,
        minWidth: dm.WIDTH * 0.4,
        paddingHorizontal: 16,
        paddingVertical: 8,
    },
    bodyRow: { flexDirection: 'column', justifyContent: 'flex-start' },
    colIcon: { alignItems: 'flex-end' },
    container: {
        flexDirection: 'row',
        height: dm.vertical(40),
        marginBottom: dm.vertical(8),
        marginTop: dm.vertical(16),
        paddingHorizontal: dm.moderate(16),
    },
    modal: {
        margin: 0,
    },
})
