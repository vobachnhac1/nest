import React, { useMemo } from 'react'
import Animated from 'react-native-reanimated'
import Svg, { Circle, G } from 'react-native-svg'

import useCircleValues from '../../hooks/useCircleValues'
import type { ProgressCircleProps } from '../../types'
import COLORS from '../../utils/colors'
import CircleGradient from '../circleGradient'
import DashedCircle from '../dashedCircle'
import styles from './styles'

const AnimatedCircle = Animated.createAnimatedComponent(Circle)

const ProgressCircle: React.FC<ProgressCircleProps> = ({
    circleBackgroundColor = COLORS.TRANSPARENT,
    radius = 60,
    strokeLinecap = 'round',
    activeStrokeColor = COLORS.GREEN,
    activeStrokeSecondaryColor = null,
    activeStrokeWidth = 10,
    inActiveStrokeColor = COLORS.BLACK_30,
    inActiveStrokeWidth = 10,
    inActiveStrokeOpacity = 1,
    dashedStrokeConfig,
    animatedCircleProps,
}: ProgressCircleProps) => {
    const viewBox = useMemo(() => radius + Math.max(activeStrokeWidth, inActiveStrokeWidth), [radius, activeStrokeWidth, inActiveStrokeWidth])
    const { inactiveCircleRadius, activeCircleRadius, circleCircumference } = useCircleValues({
        radius,
        activeStrokeWidth,
        inActiveStrokeWidth,
    })

    const maskId = useMemo(
        () => (dashedStrokeConfig && dashedStrokeConfig?.count > 0 && dashedStrokeConfig?.width > 0 ? 'url(#dashed-circle)' : undefined),
        [dashedStrokeConfig],
    )

    const strokeColor = useMemo(() => (activeStrokeSecondaryColor ? 'url(#grad)' : activeStrokeColor), [activeStrokeSecondaryColor, activeStrokeColor])

    return (
        <Svg height={radius * 2} style={styles.svg} viewBox={`0 0 ${viewBox * 2} ${viewBox * 2}`} width={radius * 2}>
            <CircleGradient activeStrokeColor={activeStrokeColor} activeStrokeSecondaryColor={activeStrokeSecondaryColor} />
            <DashedCircle
                activeCircleRadius={activeCircleRadius}
                activeStrokeWidth={activeStrokeWidth}
                circleCircumference={circleCircumference}
                dashedStrokeConfig={dashedStrokeConfig}
                inactiveCircleRadius={inactiveCircleRadius}
                inActiveStrokeWidth={inActiveStrokeWidth}
            />
            <G mask={maskId}>
                <Circle
                    cx="50%"
                    cy="50%"
                    fill={circleBackgroundColor}
                    r={inactiveCircleRadius}
                    stroke={inActiveStrokeColor}
                    strokeOpacity={inActiveStrokeOpacity}
                    strokeWidth={inActiveStrokeWidth}
                />
                <AnimatedCircle
                    animatedProps={animatedCircleProps}
                    cx="50%"
                    cy="50%"
                    fill={COLORS.TRANSPARENT}
                    r={activeCircleRadius}
                    stroke={strokeColor}
                    strokeDasharray={circleCircumference}
                    strokeLinecap={strokeLinecap}
                    strokeWidth={activeStrokeWidth}
                />
            </G>
        </Svg>
    )
}

export default ProgressCircle
