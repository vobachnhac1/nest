import IconCalendar from './iconCalendar'

export { IconCalendar }
