import React, { useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Pressable, StyleSheet, View } from 'react-native'
import Modal from 'react-native-modal'
import ToastGlobal from 'react-native-toast-message'

import ArrowRight from '../../../assets/images/common/ic_arrow_right.svg'
import { CustomFloatInput } from '../../../basic-components'
import { ButtonCustom, ModalBottomContent, ModalBottomRowSelect, RowData, RowTitleGroup } from '../../../components/trading-component'
import { useUpdateEffect } from '../../../hoc'
import { StoreContext } from '../../../store'
import { StoreTrading } from '../../../store-trading'
import { dimensions as dm, fontSizes as fs } from '../../../styles'
import { eventList, glb_sv, reqFunct, sendRequest } from '../../../utils'
import FormatNumber from '../../../utils/formatNumber/FormatNumber'

// Khai báo ServiceInfo (nếu có)
const ServiceInfo = {
    GET_LIST_AVAILABLE_TRAN: {
        reqFunct: reqFunct.GET_LIST_AVAILABLE_TRAN, // Lấy danh sách có thể chuyển
        WorkerName: 'FOSqCash',
        ServiceName: 'FOSqCash_Common',
        ClientSentTime: '0',
        Operation: 'Q',
        // InVal: ['09', this.actn_curr, this.sub_curr],
    },
}
// Khai báo component
const StepTwo = ({ cashAvailable, amoutTransfer, setAmoutTransfer, objSubReceive, setObjSubReceive, switchStep, errCtrl, _validateValue }) => {
    const { t } = useTranslation()
    const { styles } = useContext(StoreContext)
    const { userInfo } = useContext(StoreTrading)

    const [isOpenModalSelection, setIsOpenModalSelection] = useState(false)
    const [listCanTransfer, setListCanTransfer] = useState([])

    // -------------------------------------------   Dùng useEffect get các dữ liệu cần thiết còn thiếu
    useEffect(() => {
        getListCanTransfer() // Lấy danh sách có thể chuyển

        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.LOGIN_SUCCESS) {
                // reCall service FOSq
                getListCanTransfer()
            }
        })

        return () => {
            commonEvent.unsubscribe()
        }
    }, [userInfo.sub_curr, userInfo.actn_curr])

    useUpdateEffect(() => {
        _validateValue(0)
    }, [objSubReceive])
    useUpdateEffect(() => {
        _validateValue(1)
    }, [amoutTransfer])

    // -------------------------------------------   Viết các hàm để set lại bussiness form state. Nên viết đúng một chuẩn duy nhất để dễ control

    // -------------------------------------------   Khai báo các hàm gửi (request) lên server
    const getListCanTransfer = () => {
        const inputParams = ['09', userInfo.actn_curr, userInfo.sub_curr]
        sendRequest(ServiceInfo.GET_LIST_AVAILABLE_TRAN, inputParams, handleGetListCanTransfer)
    }
    // -------------------------------------------   Khai báo các hàm nhận (handle respone) dữ liệu từ server
    // -----------------------------------------
    const handleGetListCanTransfer = (reqInfoMap, message) => {
        // -- process after get result --
        if (Number(message.Result) === 0) {
            console.warn('false handleGetHisPayOnAccountBySub', reqInfoMap, message.Data, message.Message)
            ToastGlobal.show({
                type: 'warning',
                text2: message.Message,
            })
            return
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {}
            // console.log(jsondata);
            setListCanTransfer(jsondata)
            setObjSubReceive(jsondata[0] || {})
        }
    }
    const hideModal = () => {
        setIsOpenModalSelection(!isOpenModalSelection)
    }

    const onSelectActReceive = (item) => {
        setObjSubReceive(item)
        hideModal()
    }

    const onChangeAmount = (amount) => {
        setAmoutTransfer(glb_sv.filterNumber(amount))
    }

    const cashAmountRowOnPress = () => {
        console.log('cashAvailableRowOnPress')
        if (cashAvailable) {
            setAmoutTransfer(cashAvailable?.c4)
        }
    }

    const cashAvailableRowOnPress = () => {
        console.log('cashAvailableRowOnPress')
        if (cashAvailable) {
            setAmoutTransfer(cashAvailable?.c5)
        }
    }

    return (
        <View>
            <Pressable onPress={cashAmountRowOnPress}>
                <RowData
                    rightColor={styles.PRIMARY__CONTENT__COLOR}
                    textLeft={t('cash_amount')}
                    textRight={FormatNumber(Number(cashAvailable?.c4), 0)}
                    type="info"
                />
            </Pressable>

            <Pressable onPress={cashAvailableRowOnPress}>
                <RowData last rightColor={styles.PRIMARY} textLeft={t('cash_available')} textRight={FormatNumber(Number(cashAvailable?.c5), 0)} type="info" />
            </Pressable>

            <View style={{ flex: 1, marginRight: dm.halfIndent }}>
                <View style={[UI.GroupInput, { borderColor: styles.PRIMARY__BORDER__COLOR }]}>
                    <RowTitleGroup text={t('receive_sub_account')} type="group" />
                    <Pressable onPress={hideModal}>
                        <View pointerEvents="none" style={UI.RowInput}>
                            <CustomFloatInput
                                animationDuration={100}
                                errCtrl={t(errCtrl[0])}
                                label={t('receive_sub_account')}
                                rightComponent={
                                    <ArrowRight style={{ color: styles.PRIMARY__CONTENT__COLOR, marginVertical: dm.vertical(22), marginRight: 10 }} />
                                }
                                value={objSubReceive?.c2}
                            />
                        </View>
                    </Pressable>
                    <RowTitleGroup text={t('transc_amount_cash')} type="group" />
                    <View style={UI.RowInput}>
                        <CustomFloatInput
                            animationDuration={100}
                            errCtrl={t(errCtrl[1])}
                            keyboardType="number-pad"
                            label={t('transfer_amount')}
                            placeholderTextColor={styles.PLACEHODLER__COLOR}
                            value={FormatNumber(amoutTransfer, '0') === '0' ? '' : FormatNumber(amoutTransfer, '0')}
                            onChangeText={(amount) => onChangeAmount(amount)}
                        />
                    </View>
                </View>
                <ButtonCustom text={t('common_confirm')} type="confirm" onPress={() => switchStep.onFinish()} />
                <ButtonCustom last text={t('common_back')} type="back" onPress={() => switchStep.prev()} />
            </View>
            {isOpenModalSelection && (
                <Modal
                    hideModalContentWhileAnimating={true}
                    isVisible={isOpenModalSelection}
                    style={UI.bottomModal}
                    useNativeDriver={true}
                    onBackButtonPress={() => hideModal()}
                    onBackdropPress={() => hideModal()}
                >
                    <ModalBottomContent title={t('choose_account')}>
                        {listCanTransfer.map((item, index) => (
                            <ModalBottomRowSelect checked={objSubReceive.c2 === item.c2} key={index} text={item.c2} onPress={() => onSelectActReceive(item)} />
                        ))}
                    </ModalBottomContent>
                </Modal>
            )}
        </View>
    )
}
const UI = StyleSheet.create({
    GroupInput: {
        marginVertical: dm.halfVerticalIndent,
        paddingHorizontal: dm.halfIndent,
    },
    RowInput: {
        marginLeft: dm.moderate(8),
        marginVertical: dm.vertical(8),
    },
    bottomModal: {
        justifyContent: 'flex-end',
        margin: 0,
    },
})
export default StepTwo
