import React, { useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { ActivityIndicator, FlatList, Pressable, StyleSheet, TextInput, View } from 'react-native'
import Modal from 'react-native-modal'
import AntDesign from 'react-native-vector-icons/AntDesign'
import { isEmpty } from 'lodash'
import { Body, Container, Content, ListItem, Text } from 'native-base'

import IconArrDown from '../../assets/images/common/ic_arrow_down.svg'
import { CustomFloatInput } from '../../basic-components'
import { ModalBottomContent, ModalBottomRowSelect } from '../../components/trading-component'
import EmptyView from '../../components/trading-component/empty-view'
import { useAlertModal, useLoading } from '../../hoc'
import { StoreContext } from '../../store'
import { dimensions as dm, fontSizes, fontWeights } from '../../styles'
import { glb_sv, reqFunct, sendRequest } from '../../utils'
import HeaderComponent from '../header'

const ServiceInfo = {
    GET_USER_LIST_BY_USER_ID: {
        reqFunct: reqFunct.GET_USER_LIST_BY_USER_ID,
        WorkerName: 'FOSqAccount01',
        ServiceName: 'FOSqAccount01_OnlineLogin_2',
        Operation: 'Q',
        ClientSentTime: '0',
    },
    GET_USER_LIST_BY_PHONE_OR_EMAIL: {
        reqFunct: reqFunct.GET_USER_LIST_BY_PHONE_OR_EMAIL,
        WorkerName: 'FOSqAccount01',
        ServiceName: 'FOSqAccount01_OnlineLogin_2',
        Operation: 'Q',
        ClientSentTime: '0',
    },
}

const searchingFilterList = [
    { index: 0, value: '0', label: 'acc_number_full' },
    { index: 1, value: '1', label: 'email_or_phone_card_id' },
]

const AccountSearchScreen = ({ navigation, route }) => {
    const TAG = 'AccountSearchScreen'

    const { activeCode, styles, language } = useContext(StoreContext)
    const { t } = useTranslation()
    const [userDataList, setUserDataList] = useState({})
    const [dataList, setDataList] = useState([])
    const { params = {} } = route
    const { updateInfo } = params

    const [prefixValue, setPrefixValue] = useState(activeCode + 'c')
    const [suffixValue, setSuffixValue] = useState('')

    const [personalValue, setPersonalValue] = useState('')

    const isSearchRef = useRef(null)
    const searchInputRef = useRef(null)
    const inputChangeRef = useRef(null)

    const [searchByUserID, setSearchByUserID] = useState(true)
    const [modalVisible, setModalVisible] = useState(false)
    const [currentSearchOption, setCurrentSearchOption] = useState(searchingFilterList[0].value)
    const [currentSearchLabel, setCurrentSearchLabel] = useState(searchingFilterList[0].label)
    const [searching, setSearching] = useLoading(false)

    const onSearchTypeChanged = (dataFilter = currentSearchOption, datalabelGD = currentSearchLabel) => {
        setCurrentSearchOption(dataFilter)
        setCurrentSearchLabel(datalabelGD)
        // getOrderList(null, null, dataFilter);
        setTimeout(() => {
            setModalVisible(false)
        }, 250)

        if (dataFilter == 0) {
            setSearchByUserID(true)
        } else {
            setSearchByUserID(false)
        }
    }

    useEffect(() => {
        return () => {
            isSearchRef.current = null
            inputChangeRef.current = null
            searchInputRef.current = null
        }
    }, [])

    useEffect(() => {
        loadRecentSearch()
    }, [glb_sv.recentSearchAccount])

    const loadRecentSearch = () => {
        if (glb_sv.recentSearchAccount.length > 0) {
            isSearchRef.current = true
            setUserDataList(glb_sv.recentSearchAccount)
        }
    }

    const onPrefixTextChange = (value) => {
        clearTimeout(inputChangeRef.current)
        const prefixVal = value.trim()
        if (prefixVal.length >= 4) {
            if (suffixValue.trim().length == 0) {
                loadRecentSearch()
                return
            } else {
                const act = prefixVal + suffixModify(suffixValue)
                getUserListByUserID(act)
            }
        } else {
            loadRecentSearch()
        }
    }

    const onSuffixTextChange = (value) => {
        clearTimeout(inputChangeRef.current)
        const suffixVal = value.trim()
        if (prefixValue.length >= 4) {
            if (suffixVal.trim().length == 0) {
                loadRecentSearch()
                return
            } else {
                const act = prefixValue + suffixModify(suffixVal)
                getUserListByUserID(act)
            }
        } else {
            loadRecentSearch()
        }
    }

    /*
        searchValue là dữ liệu đầu vào đã được xử lý 
        - 1 là Null/Empty
        - 2 là đầy đủ 10 ký tự (VD: 888c000350)
    */
    const getUserListByUserID = (searchValue) => {
        clearTimeout(inputChangeRef.current)
        if (!searchValue) {
            loadRecentSearch()
            return
        }

        if (glb_sv.recentSearchAccount.length > 0 && glb_sv.recentSearchAccount.some((item) => item.actn_curr === searchValue)) {
            const res = glb_sv.recentSearchAccount.filter((item) => item.actn_curr === searchValue)
            isSearchRef.current = false
            setUserDataList(res[0])
            return
        }

        const inputParams = [searchValue.toUpperCase()]
        sendRequest(ServiceInfo.GET_USER_LIST_BY_USER_ID, inputParams, handleGetUserList)
        setSearching(true)
    }

    const getUserListByPersonalInfo = (searchValue) => {
        setSearching(false)
        clearTimeout(inputChangeRef.current)
        if (!searchValue) {
            loadRecentSearch()
            return
        }

        if (glb_sv.recentSearchAccount.length > 0 && glb_sv.recentSearchAccount.some((item) => item.actn_curr === searchValue)) {
            const res = glb_sv.recentSearchAccount.filter((item) => item.actn_curr === searchValue)
            isSearchRef.current = false
            setUserDataList(res[0])
            return
        }

        const inputParams = [searchValue.toUpperCase()]
        // sendRequest(ServiceInfo.GET_USER_LIST_BY_PHONE_OR_EMAIL, inputParams, handleGetUserList)
    }

    const suffixModify = (suffixValue) => {
        let act = ''
        if (suffixValue.trim().length === 1) {
            act = '00000' + suffixValue.trim()
        } else if (suffixValue.trim().length === 2) {
            act = '0000' + suffixValue.trim()
        } else if (suffixValue.trim().length === 3) {
            act = '000' + suffixValue.trim()
        } else if (suffixValue.trim().length === 4) {
            act = '00' + suffixValue.trim()
        } else if (suffixValue.trim().length === 5) {
            act = '0' + suffixValue.trim()
        } else if (suffixValue.trim().length === 6) {
            act = suffixValue.trim()
        }
        return act
    }

    const handleGetUserList = (reqInfoMap, message) => {
        console.log('message', message)
        setSearching(false)
        if (Number(message.Result) === 0) {
            useAlertModal(message, { continueVerify: true })
            return
        } else {
            let dataArr = []
            try {
                const resData = message.Data
                dataArr = resData === '' ? [] : JSON.parse(resData)
            } catch (error) {
                console.log('error', error)
                return
            }

            if (dataArr.length) {
                setDataList(dataArr)
                const acc_broker = {
                    actn_curr: dataArr[0]?.c0,
                    actn_list: [
                        {
                            AcntNo: dataArr[0]?.c0,
                            actn_name: dataArr[0]?.c2,
                            key: dataArr[0]?.c0,
                            label: `${dataArr[0]?.c0} (${dataArr[0]?.c2})`,
                        },
                    ],
                    actn_name: dataArr[0]?.c2,
                    sub_curr: '00',
                    sub_list: dataArr.map((item) => item.c1).sort((a, b) => Number(a) - Number(b)),
                }
                setUserDataList(acc_broker)
            } else {
                setUserDataList(null)
            }
        }
    }

    const UserItem = ({ item }) => {
        return (
            <ListItem
                activeOpacity={0.6}
                style={{ borderBottomColor: styles.PRIMARY__BG__COLOR }}
                underlayColor="transparent"
                onPress={() => {
                    updateInfo(item, dataList)
                    navigation.pop()
                }}
            >
                <Body style={UI.body_stock}>
                    <Text
                        style={{
                            color: styles.PRIMARY__CONTENT__COLOR,
                            fontWeight: fontWeights.medium,
                        }}
                    >
                        <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal }}>{item.actn_curr}</Text>
                        <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal }}> - </Text>
                        <Text
                            style={{
                                color: styles.PRIMARY__CONTENT__COLOR,
                                fontSize: fontSizes.normal,
                            }}
                        >
                            {item.actn_name}
                        </Text>
                    </Text>
                </Body>
            </ListItem>
        )
    }

    return (
        <Container
            style={{
                backgroundColor: styles.PRIMARY__BG__COLOR,
            }}
        >
            <HeaderComponent colorTitle={styles.PRIMARY__CONTENT__COLOR} isShowLeft navigation={navigation} title={t('search')} titleAlgin="flex-start" />
            <Content>
                <Pressable
                    onPress={() => {
                        setModalVisible(true)
                    }}
                >
                    <View pointerEvents="none" style={UI.RowFilter}>
                        <CustomFloatInput
                            editable={false}
                            label={t('search_with')}
                            rightComponent={<IconArrDown style={{ color: styles.PRIMARY__CONTENT__COLOR, marginVertical: dm.vertical(20), marginRight: 5 }} />}
                            staticLabel
                            value={t(`${currentSearchLabel}`)}
                        />
                    </View>
                </Pressable>

                {/* View search with user ID */}
                <View
                    display={searchByUserID ? 'flex' : 'none'}
                    style={{
                        flexDirection: 'row',
                        paddingHorizontal: 16,
                    }}
                >
                    <View
                        style={{
                            backgroundColor: styles.HEADER__BG__COLOR,
                            flexDirection: 'row',
                            flex: 1,
                            borderRadius: 5,
                            paddingHorizontal: 8,
                            paddingVertical: 2,
                        }}
                    >
                        <AntDesign color={styles.PLACEHODLER__COLOR} name="search1" size={20} style={{ paddingVertical: 7, paddingLeft: 5 }} />

                        <TextInput
                            maxLength={4}
                            placeholder={glb_sv.activeCode + 'c'}
                            placeholderTextColor={styles.PLACEHODLER__COLOR}
                            ref={searchInputRef}
                            style={{
                                color: styles.PRIMARY__CONTENT__COLOR,
                                fontSize: fontSizes.small,
                                padding: 0,
                                paddingHorizontal: 5,
                                flex: 0.15,
                            }}
                            value={prefixValue}
                            onChangeText={(value) => {
                                isSearchRef.current = false
                                clearTimeout(inputChangeRef.current)
                                setPrefixValue(value.trim())
                                inputChangeRef.current = setTimeout(() => onPrefixTextChange(value.trim()), 1000)
                            }}
                        />

                        <Text style={{ fontWeight: fontWeights.bold, color: styles.HEADER__CONTENT__COLOR, alignSelf: 'center' }}> - </Text>

                        <TextInput
                            keyboardType="numeric"
                            maxLength={6}
                            placeholder={t('choose_account_trading')}
                            placeholderTextColor={styles.PLACEHODLER__COLOR}
                            ref={searchInputRef}
                            style={{
                                color: styles.PRIMARY__CONTENT__COLOR,
                                fontSize: fontSizes.small,
                                padding: 0,
                                paddingHorizontal: 5,
                                flex: 1,
                            }}
                            value={suffixValue}
                            onChangeText={(value) => {
                                setSearching(true)
                                isSearchRef.current = false
                                clearTimeout(inputChangeRef.current)
                                setSuffixValue(value.trim())
                                inputChangeRef.current = setTimeout(() => onSuffixTextChange(value.trim()), 1000)
                            }}
                        />
                        <View style={{ justifyContent: 'center', alignItems: 'center' }}>
                            {searching ? <ActivityIndicator color={styles.PRIMARY__CONTENT__COLOR} /> : null}
                        </View>
                    </View>
                </View>

                {/* View search with phone/email/National ID */}
                <View
                    display={searchByUserID ? 'none' : 'flex'}
                    style={{
                        flexDirection: 'row',
                        paddingHorizontal: 16,
                    }}
                >
                    <View
                        style={{
                            backgroundColor: styles.HEADER__BG__COLOR,
                            flexDirection: 'row',
                            flex: 1,
                            borderRadius: 5,
                            paddingHorizontal: 8,
                            paddingVertical: 2,
                        }}
                    >
                        <AntDesign color={styles.PLACEHODLER__COLOR} name="search1" size={20} style={{ paddingVertical: 7, paddingLeft: 5 }} />
                        <TextInput
                            placeholder={t('login_id_title')}
                            placeholderTextColor={styles.PLACEHODLER__COLOR}
                            ref={searchInputRef}
                            style={{
                                color: styles.PRIMARY__CONTENT__COLOR,
                                fontSize: fontSizes.small,
                                padding: 0,
                                paddingHorizontal: 5,
                                flex: 1,
                            }}
                            value={personalValue}
                            onChangeText={(value) => {
                                isSearchRef.current = false
                                clearTimeout(inputChangeRef.current)
                                setPersonalValue(value.trim())
                                inputChangeRef.current = setTimeout(() => getUserListByPersonalInfo(value.trim()), 1000)
                            }}
                        />
                    </View>
                </View>

                {isSearchRef.current && glb_sv.recentSearchAccount.length > 0 ? (
                    <View style={{ marginTop: 10 }}>
                        <Text
                            style={{
                                color: styles.HEADER__CONTENT__COLOR,
                                paddingHorizontal: 16,
                            }}
                        >
                            {t('search_recent')}
                        </Text>
                        <FlatList
                            data={glb_sv.recentSearchAccount}
                            keyboardShouldPersistTaps="always"
                            keyExtractor={(item, index) => index.toString()}
                            ListEmptyComponent={EmptyView}
                            renderItem={UserItem}
                            style={{ marginBottom: 10 }}
                        />
                    </View>
                ) : (
                    <View>
                        <FlatList
                            data={isEmpty(userDataList) ? [] : [userDataList]}
                            keyboardShouldPersistTaps="always"
                            keyExtractor={(item, index) => index.toString()}
                            ListEmptyComponent={EmptyView}
                            renderItem={UserItem}
                            style={{ marginBottom: 10 }}
                        />
                    </View>
                )}

                <View style={{ ...UI.container }}>
                    <Modal
                        hideModalContentWhileAnimating={true}
                        isVisible={modalVisible}
                        style={UI.bottomModal}
                        useNativeDriver={true}
                        onBackButtonPress={() => setModalVisible(false)}
                        onBackdropPress={() => setModalVisible(false)}
                    >
                        <ModalBottomContent title={t('search_with')}>
                            {searchingFilterList.map((item, index) => (
                                <ModalBottomRowSelect
                                    checked={currentSearchOption === item.value}
                                    key={index}
                                    text={t(item.label)}
                                    onPress={() => onSearchTypeChanged(item.value, item.label)}
                                />
                            ))}
                        </ModalBottomContent>
                    </Modal>
                </View>
            </Content>
        </Container>
    )
}

const UI = StyleSheet.create({
    Button: {
        alignItems: 'center',
        borderRadius: 8,
        height: dm.moderate(28),
        justifyContent: 'center',
        width: dm.moderate(28),
    },
    GroupInput: {
        marginVertical: dm.moderate(4),
        paddingHorizontal: dm.halfIndent,
    },
    RowFilter: {
        marginHorizontal: dm.moderate(8),
        marginVertical: dm.vertical(8),
    },
    Row_Modal: {
        height: dm.vertical(24),
        marginVertical: dm.vertical(16),
    },
    body_stock: {
        flexDirection: 'column',
        flex: 2,
        justifyContent: 'flex-start',
    },
    bottomModal: {
        justifyContent: 'flex-end',
        margin: 0,
    },
    container: {
        alignItems: 'center',
        flex: 1,
        justifyContent: 'center',
    },
    margin_top_row: {
        marginBottom: dm.moderate(24),
        marginHorizontal: dm.moderate(16),
        marginTop: dm.moderate(16),
    },
    modalContent: {
        backgroundColor: 'white',
        borderColor: 'rgba(0, 0, 0, 0.1)',
        borderTopLeftRadius: 5,
        borderTopRightRadius: 5,
        paddingBottom: 40,
    },
    page: {
        flex: 1,
        flexDirection: 'column',
    },
    right_stock: {
        alignItems: 'flex-end',
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'center',
        paddingRight: 0,
    },
    stepIndicator: {
        marginBottom: dm.vertical(8),
        marginTop: dm.vertical(24),
    },
})

export default AccountSearchScreen
