import React, { memo, useMemo } from 'react'
import { Platform, StyleSheet, TextInput } from 'react-native'

import { enhance } from './index'

const IOS = Platform.OS === 'ios' ? true : false

const TextInputCustom = React.forwardRef(({ style, ...props }, ref) => {
    const wrapStyle = useMemo(
        () =>
            enhance([
                style,
                IOS
                    ? {}
                    : style
                    ? {
                          fontFamily: getFontWeight(style.fontWeight),
                      }
                    : UI.font,
            ]),
        [style],
    )
    return <TextInput style={wrapStyle} {...props} ref={ref} />
})

export default TextInputCustom

const UI = StyleSheet.create({
    font: {
        fontFamily: 'OpenSans-Regular',
    },
})

function getFontWeight(wei) {
    if (['100', '200', '300'].includes(wei)) return 'OpenSans-Light'
    if (['500', '600'].includes(wei)) return 'OpenSans-SemiBold'
    if (['700', '800', '900'].includes(wei)) return 'OpenSans-ExtraBold'
    return 'OpenSans-Regular'
}
