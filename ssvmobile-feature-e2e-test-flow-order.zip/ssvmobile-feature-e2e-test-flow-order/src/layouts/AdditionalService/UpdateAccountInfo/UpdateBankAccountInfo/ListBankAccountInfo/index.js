import React, { useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { FlatList, StyleSheet, TouchableOpacity, View } from 'react-native'
import Modal from 'react-native-modal'
import Svg, { Path } from 'react-native-svg'
import ToastGlobal from 'react-native-toast-message'
import moment from 'moment'
import { Fab, Icon } from 'native-base'

import ModalLoading from '../../../../../components/modal-loading'
import { ButtonCustom, EmptyView, ModalContent, RowDataModal, RowTitleGroup } from '../../../../../components/trading-component'
import { useAlertModal, useAlertModalCommonCode, useLoading, useModalOtpWhenErr } from '../../../../../hoc'
import { StoreContext } from '../../../../../store'
import { StoreTrading } from '../../../../../store-trading'
import { dimensions } from '../../../../../styles'
import { glb_sv, reqFunct, sendRequest } from '../../../../../utils'
import { RowBankInfo } from '../../components/RowBankInfo'

const ServiceInfo = {
    QUERY_LIST_BANK_ACCOUNT: {
        reqFunct: reqFunct.QUERY_LIST_BANK_ACCOUNT,
        WorkerName: 'FOSqCash',
        ServiceName: 'FOSqCash_0202_2',
        Operation: 'Q',
        ClientSentTime: '0',
    },
    DELETE_BANK_INFO: {
        reqFunct: reqFunct.DELETE_BANK_INFO,
        WorkerName: 'FOSxCash',
        ServiceName: 'FOSxCash_0202_2',
        Operation: 'U',
        ClientSentTime: '0',
    },
}

const ListBankAccountInfo = ({ setCurrentTab, refreshing, setEditData = () => null }) => {
    const { t } = useTranslation()
    const { styles } = useContext(StoreContext)
    const { userInfo } = useContext(StoreTrading)

    const [modalDeleteBankInfo, setModalDeleteBankInfo] = useState(false)
    const [loadingConfirm, setLoadingConfirm] = useLoading(false)
    const [refreshFlag, setRefreshFlag] = useState(false)
    const [dataSource, setDataSource] = useState([])

    const [modalData, setModalData] = useState({})
    const [shouldShowModal, setShouldShowModal] = useState(false)
    const [modalDetailBankInfo, setModalDetailBankInfo] = useState(false)

    useEffect(() => {
        queryListBankAccount()

        return () => {}
    }, [userInfo.actn_curr])

    useEffect(() => {
        if (refreshing) {
            queryListBankAccount()
        }
    }, [refreshing])

    const queryListBankAccount = () => {
        if (!userInfo || !userInfo.actn_curr) return
        const inputParams = [userInfo.actn_curr]
        setRefreshFlag(true)
        setDataSource([])
        // @ts-ignore
        sendRequest(ServiceInfo.QUERY_LIST_BANK_ACCOUNT, inputParams, handleQueryListBankAccountResult, true, handleQueryListBankAccountTimeout)
    }

    const handleQueryListBankAccountResult = (reqInfoMap, message) => {
        // console.log('handleQueryListBankAccountResult: ', reqInfoMap, message)
        if (Number(message.Result) === 0) {
            setRefreshFlag(false)
            // ToastGlobal.show({
            //     text2: message['Message'],
            //     type: 'warning',
            // })
            return
        } else {
            let jsondata
            try {
                jsondata = JSON.parse(message.Data)
            } catch (error) {
                jsondata = []
            }
            if (Number(message.Packet) <= 0) {
                setRefreshFlag(false)
                setDataSource(jsondata)
            }
        }
    }

    const handleQueryListBankAccountTimeout = () => {
        ToastGlobal.show({
            text2: t('common_cant_connect_server'),
            type: 'warning',
        })
        setRefreshFlag(false)
        setDataSource([])
    }

    const onConfirmDeleteBankAccount = () => {
        setModalDeleteBankInfo(false)
        const inputParams = [
            modalData.c0, // Account
            modalData.c2, // Mã NH
            modalData.c4, // Số TK
            modalData.c5, // Tên chủ TK
            'N', // Trạng thái hoạt động
            modalData.c2, // Mã ngân hàng + Chi nhánh cũ
            modalData.c4, // Tài khoản NH cũ
            '1', // Kênh GD chuyển tiền
            '', // Ngày bắt đầu hiệu lực
            '', // Ngày hết hiệu lực
        ]
        sendRequest(ServiceInfo.DELETE_BANK_INFO, inputParams, handleDeleteBankResult, true, handleDeleteBankTimeout)
        setLoadingConfirm(true)
    }

    const handleDeleteBankResult = (reqInfoMap, message) => {
        setLoadingConfirm(false)

        if (Number(message.Result) === 0) {
            // @ts-expect-error
            const { hasAlertCommonCode } = useAlertModalCommonCode(message, {})
            const { hasAlertErrOtp } = useModalOtpWhenErr(message, {
                continueVerify: !hasAlertCommonCode,
                callback: () => setModalDeleteBankInfo(true),
            })
            // @ts-expect-error
            useAlertModal(message, { continueVerify: !hasAlertErrOtp })
            return
        } else {
            ToastGlobal.show({
                text2: message.Message,
                type: 'success',
            })
            setShouldShowModal(false)
            setModalData({})
        }
    }

    const handleDeleteBankTimeout = () => {
        ToastGlobal.show({
            text2: t('common_cant_connect_server'),
            type: 'warning',
        })
    }
    const onEditBankInfo = (item) => {
        setEditData(item)
    }
    const onDeleteBankAccount = (item) => {
        setModalData(item)
        setModalDeleteBankInfo(true)
    }
    const onPressDetailBankInfo = (item) => {
        setModalData(item)
        setModalDetailBankInfo(true)
    }
    const hideModal = () => {
        setModalDeleteBankInfo(false)
        setModalDetailBankInfo(false)
    }

    return (
        <View style={{ backgroundColor: styles.PRIMARY__BG__COLOR, flex: 1 }}>
            {/* <RowTitleGroup text={t('list_bank_account')} style={{ paddingBottom: 8 }} /> */}
            <View>
                <FlatList
                    data={dataSource}
                    keyExtractor={(item, index) => index.toString()}
                    ListEmptyComponent={EmptyView}
                    renderItem={({ item }) => {
                        return (
                            <RowBankInfo
                                onPress={() => onPressDetailBankInfo(item)}
                                // @ts-expect-error
                                bankName={item.c3}
                                // @ts-expect-error
                                bankAccountNumber={item.c4}
                                item={item}
                                iconRight={null}
                                onDeleteBankInfo={onDeleteBankAccount}
                                onEditBankInfo={onEditBankInfo}
                                setModalData={setModalData}
                            />
                        )
                    }}
                    keyboardShouldPersistTaps="always"
                    // style={{ marginBottom: 10 }}
                />
            </View>
            {/* <ButtonCustom text={t('create_new')} onPress={() => setCurrentTab(1)} /> */}

            {/* <Button
                block
                onPress={resetPassword}
                transparent
                disabled={!validateState()}
                style={{ backgroundColor: validateState() ? styles.PRIMARY : styles.PRIMARY + '4d', marginTop: 20, borderRadius: 8 }}>
                <Text style={{ fontSize: fontSizes.normal, color: validateState() ? '#FFF' : styles.SECOND__CONTENT__COLOR }}>
                    {t('login_reset_password')}
                </Text>
            </Button> */}

            {modalDeleteBankInfo ? (
                <Modal isVisible={modalDeleteBankInfo} useNativeDriver={true} onBackButtonPress={hideModal} onBackdropPress={hideModal}>
                    <ModalContent
                        iconComponent={
                            <Svg fill="none" height="32" viewBox="0 0 33 32" width="33">
                                <Path
                                    d="M7.53452 6.48793L20.2914 3.00584L19.6158 1.64032C19.1738 0.752727 18.0958 0.386191 17.2082 0.82819L5.78809 6.48793H7.53452Z"
                                    fill="#2ECC71"
                                />
                                <Path
                                    d="M24.2509 3.10547C24.0928 3.10547 23.9346 3.12703 23.7765 3.17015L20.7796 3.98946L11.627 6.48693H22.0157H26.5435L25.9829 4.43146C25.7673 3.63012 25.0414 3.10547 24.2509 3.10547Z"
                                    fill="#2ECC71"
                                />
                                <Path
                                    d="M28.4164 7.74609H28.0068H27.4498H26.8928H22.6417H7.02082H4.97253H3.24766H2.92784H1.85698C1.28921 7.74609 0.782525 8.00842 0.451924 8.42167C0.300998 8.61212 0.186006 8.83133 0.121323 9.07209C0.081795 9.22302 0.0566406 9.38113 0.0566406 9.54284V9.75845V11.8067V29.5622C0.0566406 30.554 0.861582 31.3589 1.85338 31.3589H28.4128C29.4047 31.3589 30.2096 30.554 30.2096 29.5622V24.5492H19.5477C17.8624 24.5492 16.4932 23.1801 16.4932 21.4948V19.849V19.292V18.735V17.4988C16.4932 16.6723 16.8238 15.9213 17.3593 15.3715C17.8336 14.8828 18.4697 14.5522 19.1812 14.4695C19.2998 14.4552 19.4219 14.4479 19.5441 14.4479H28.7147H29.2717H29.8287H30.2096V9.54284C30.2132 8.55103 29.4082 7.74609 28.4164 7.74609Z"
                                    fill="#2ECC71"
                                />
                                <Path
                                    d="M31.47 16.1641C31.2903 15.9988 31.0783 15.873 30.8411 15.7903C30.6578 15.7293 30.4638 15.6934 30.259 15.6934H30.2123H30.1763H29.6193H27.6106H19.5468C18.5549 15.6934 17.75 16.4983 17.75 17.4901V18.3848V18.9418V19.4988V21.4896C17.75 22.4814 18.5549 23.2864 19.5468 23.2864H30.2123H30.259C30.4638 23.2864 30.6578 23.2504 30.8411 23.1893C31.0783 23.1103 31.2903 22.9809 31.47 22.8156C31.8293 22.4886 32.0557 22.0143 32.0557 21.4897V17.4901C32.0557 16.9654 31.8293 16.491 31.47 16.1641ZM23.2984 19.8474C23.2984 20.3433 22.8959 20.7458 22.4 20.7458H21.8035C21.3076 20.7458 20.9051 20.3433 20.9051 19.8474V19.2509C20.9051 18.9634 21.0381 18.7082 21.2501 18.5465C21.4046 18.4279 21.5951 18.3525 21.8035 18.3525H21.9544H22.4C22.8959 18.3525 23.2984 18.7549 23.2984 19.2509V19.8474Z"
                                    fill="#2ECC71"
                                />
                            </Svg>
                        }
                        title={t('common_confirmDelete')}
                        type="confirm"
                    >
                        <RowDataModal textLeft={t('bank_cd')} textRight={modalData.c3} />
                        <RowDataModal textLeft={t('enter_acc_number_full')} textRight={modalData.c4} />
                        <RowDataModal last textLeft={t('account_holder')} textRight={modalData.c5} />
                        {/* <RowDataModal textLeft={t('branch_manage')} textRight={modalData.c7} /> */}
                        {/* <RowDataModal
                            textLeft={t('register_time')}
                            // @ts-expect-error
                            textRight={!!modalData.c22 && !!modalData.c22.trim() && moment(modalData.c22, 'DDMMYYYYHHmmss').format('DD/MM/YYYY')}
                            last
                        /> */}
                        <ButtonCustom text={t('common_button_confirm')} type="cancel" onPress={onConfirmDeleteBankAccount} />
                        <ButtonCustom last text={'common_Cancel'} type="back" onPress={hideModal} />
                    </ModalContent>
                </Modal>
            ) : null}
            {modalDetailBankInfo ? (
                <Modal isVisible={modalDetailBankInfo} useNativeDriver={true} onBackButtonPress={hideModal} onBackdropPress={hideModal}>
                    <ModalContent
                        iconComponent={
                            <Svg fill="none" height="32" viewBox="0 0 33 32" width="33">
                                <Path
                                    d="M7.53452 6.48793L20.2914 3.00584L19.6158 1.64032C19.1738 0.752727 18.0958 0.386191 17.2082 0.82819L5.78809 6.48793H7.53452Z"
                                    fill="#2ECC71"
                                />
                                <Path
                                    d="M24.2509 3.10547C24.0928 3.10547 23.9346 3.12703 23.7765 3.17015L20.7796 3.98946L11.627 6.48693H22.0157H26.5435L25.9829 4.43146C25.7673 3.63012 25.0414 3.10547 24.2509 3.10547Z"
                                    fill="#2ECC71"
                                />
                                <Path
                                    d="M28.4164 7.74609H28.0068H27.4498H26.8928H22.6417H7.02082H4.97253H3.24766H2.92784H1.85698C1.28921 7.74609 0.782525 8.00842 0.451924 8.42167C0.300998 8.61212 0.186006 8.83133 0.121323 9.07209C0.081795 9.22302 0.0566406 9.38113 0.0566406 9.54284V9.75845V11.8067V29.5622C0.0566406 30.554 0.861582 31.3589 1.85338 31.3589H28.4128C29.4047 31.3589 30.2096 30.554 30.2096 29.5622V24.5492H19.5477C17.8624 24.5492 16.4932 23.1801 16.4932 21.4948V19.849V19.292V18.735V17.4988C16.4932 16.6723 16.8238 15.9213 17.3593 15.3715C17.8336 14.8828 18.4697 14.5522 19.1812 14.4695C19.2998 14.4552 19.4219 14.4479 19.5441 14.4479H28.7147H29.2717H29.8287H30.2096V9.54284C30.2132 8.55103 29.4082 7.74609 28.4164 7.74609Z"
                                    fill="#2ECC71"
                                />
                                <Path
                                    d="M31.47 16.1641C31.2903 15.9988 31.0783 15.873 30.8411 15.7903C30.6578 15.7293 30.4638 15.6934 30.259 15.6934H30.2123H30.1763H29.6193H27.6106H19.5468C18.5549 15.6934 17.75 16.4983 17.75 17.4901V18.3848V18.9418V19.4988V21.4896C17.75 22.4814 18.5549 23.2864 19.5468 23.2864H30.2123H30.259C30.4638 23.2864 30.6578 23.2504 30.8411 23.1893C31.0783 23.1103 31.2903 22.9809 31.47 22.8156C31.8293 22.4886 32.0557 22.0143 32.0557 21.4897V17.4901C32.0557 16.9654 31.8293 16.491 31.47 16.1641ZM23.2984 19.8474C23.2984 20.3433 22.8959 20.7458 22.4 20.7458H21.8035C21.3076 20.7458 20.9051 20.3433 20.9051 19.8474V19.2509C20.9051 18.9634 21.0381 18.7082 21.2501 18.5465C21.4046 18.4279 21.5951 18.3525 21.8035 18.3525H21.9544H22.4C22.8959 18.3525 23.2984 18.7549 23.2984 19.2509V19.8474Z"
                                    fill="#2ECC71"
                                />
                            </Svg>
                        }
                        title={t('info')}
                        type="confirm"
                    >
                        <RowDataModal textLeft={t('bank_cd')} textRight={modalData.c3} />
                        <RowDataModal textLeft={t('enter_acc_number_full')} textRight={modalData.c4} />
                        <RowDataModal textLeft={t('account_holder')} textRight={modalData.c5} />
                        <RowDataModal last textLeft={t('order_status')} textRight={modalData.c6 === 'Y' ? t('online_status') : t('offline_status')} />
                        {/* <RowDataModal textLeft={t('branch_manage')} textRight={modalData.c7} last/> */}
                        {/* <RowDataModal
                            textLeft={t('register_time')}
                            // @ts-expect-error
                            textRight={!!modalData.c22 && !!modalData.c22.trim() && moment(modalData.c22, 'DDMMYYYYHHmmss').format('DD/MM/YYYY')}
                            last
                        /> */}
                        <ButtonCustom text={'common_Ok'} type="confirm" onPress={hideModal} />
                    </ModalContent>
                </Modal>
            ) : null}
            {loadingConfirm ? <ModalLoading content={t('common_processing')} visible={loadingConfirm} /> : null}
        </View>
    )
}

const UI = StyleSheet.create({
    RowInput: {
        marginVertical: dimensions.vertical(8),
    },
    row: {
        alignItems: 'center',
        borderRadius: 12,
        flexDirection: 'row',
        marginHorizontal: dimensions.moderate(16),
        marginTop: dimensions.vertical(12),
    },
    viewInput: {
        borderRadius: 8,
        borderWidth: 0.6,
        paddingHorizontal: dimensions.moderate(16),
        paddingVertical: dimensions.vertical(8),
    },
})

export default ListBankAccountInfo
