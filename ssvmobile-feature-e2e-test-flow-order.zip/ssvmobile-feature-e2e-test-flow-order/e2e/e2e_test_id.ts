const e2e_testing_id: {} = {
    dash_board: {
        service_tab: 'service_tab',
    },
    settings_screen: {
        login_button: 'login_button',
    },
    login_screen: {
        input_user_id: 'input_user_id',
        input_password: 'input_password',
        login_button: 'login_button',
    },
}
export default e2e_testing_id
