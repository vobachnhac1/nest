import React from 'react'
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native'
import Modal from 'react-native-modal'
import AntDesign from 'react-native-vector-icons/AntDesign'
import { KeyboardAwareScrollView } from '@codler/react-native-keyboard-aware-scroll-view'
import ModalLoading from '@mts-components/modal-loading'
import { ModalBottomContent, ModalBottomRowSelect, RowTitleGroup } from '@mts-components/trading-component'
import { HIEGHT } from '@mts-styles/helper/dimensions'
import { dimensions, fontSizes, fontWeights } from '@mts-styles/index'
import IconRightArrow from 'src/assets/images/common/ic_arrow_right.svg' //'../../assets/images/common/ic_arrow_right.svg'

import { BrokerAndRemierRefInfo } from '../../components/BrokerAndRemierRefInfo'
import EkycButton from '../../components/EkycButton'
import { ReferrerInfoGroup } from '../../components/ReferrerInfoGroup'
import { configUIEkyc } from '../../config'
import ModalConfirmAndReviewInfo from '../ModalConfirmAndReviewInfo'

export const AdditionInfoStep2 = ({
    styles,
    checkBeforeNextStep,
    isShowReviewModal,
    loadingRegister,
    setIsShowReviewModal,
    switchStep,
    setLoadingRegister,
    t,
    onChangeBrokerOrRemierRefInfo,
    institutionalList,
    getInstituation,
    setVisibleInstitutional,
    institutional,
    setInstitutional,
    setReferrerCode,
    setReferrerName,
    onChangeReferrerInfo,
    visibleInstitutional,
    loading,
}) => {
    return (
        <View style={UI.styleContainer(styles)}>
            <KeyboardAwareScrollView enableOnAndroid={false} extraScrollHeight={100}>
                <View>
                    <Text style={{ textAlign: 'center', color: styles.PRIMARY, fontSize: fontSizes.xmedium, fontWeight: fontWeights.bold }}>
                        {t('extend_service_title_2').toUpperCase()}
                    </Text>
                    <View
                        style={{
                            paddingHorizontal: 8,
                            paddingVertical: 8,
                            borderRadius: 4,
                        }}
                    >
                        <Text style={{ textAlign: 'center', fontSize: fontSizes.verySmall, color: 'orange' }}>{t<string>('extend_service_note_2')}</Text>
                    </View>
                    <RowTitleGroup text={t('Register_Account_Management_Officer')} />
                    <>
                        {configUIEkyc.is_show_broker ? (
                            <BrokerAndRemierRefInfo
                                hasDivider={false}
                                inputType={configUIEkyc.broker_remisier_style}
                                onChangeBrokerRefInfo={onChangeBrokerOrRemierRefInfo}
                            />
                        ) : null}
                    </>
                    {configUIEkyc.is_show_additional_information_group_header ? (
                        <>
                            <RowTitleGroup text={t('referral_info')} />
                            <TouchableOpacity
                                onPress={() => {
                                    if (!institutionalList.length) {
                                        getInstituation()
                                    }
                                    setVisibleInstitutional(true)
                                }}
                            >
                                <View
                                    style={[
                                        UI.row,
                                        {
                                            paddingVertical: 8,
                                            borderRadius: 4,
                                        },
                                    ]}
                                >
                                    <View style={{ flex: 4 }}>
                                        <Text
                                            style={{
                                                color: styles.SECOND__CONTENT__COLOR,
                                                fontSize: fontSizes.small,
                                                flex: 4,
                                                textAlignVertical: 'center',
                                            }}
                                        >
                                            {t('institutional')}
                                        </Text>
                                    </View>
                                    <View style={{ width: 5 }} />
                                    <View style={{ flex: 5, flexDirection: 'row', justifyContent: 'flex-end' }}>
                                        <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small }}>
                                            {institutional ? institutionalList.find((e) => e.c0 === institutional)?.c1 : ''}
                                        </Text>
                                        {institutional ? (
                                            <TouchableOpacity
                                                onPress={() => {
                                                    setInstitutional('')
                                                    setReferrerCode('')
                                                    setReferrerName('')
                                                }}
                                            >
                                                <AntDesign
                                                    color={styles.ICON__PRIMARY}
                                                    name="closecircleo"
                                                    size={20}
                                                    style={{ marginHorizontal: dimensions.moderate(5) }}
                                                />
                                            </TouchableOpacity>
                                        ) : (
                                            <IconRightArrow style={{ color: styles.ICON__PRIMARY }} />
                                        )}
                                    </View>
                                </View>
                            </TouchableOpacity>
                            {configUIEkyc.refInfo && institutional !== '06' ? (
                                <ReferrerInfoGroup
                                    institutional={institutional}
                                    showRefCodeInput={configUIEkyc.refInfo_showRefCode}
                                    showRefNameInput={configUIEkyc.refInfo_showRefName}
                                    onChangeReferrerInfo={onChangeReferrerInfo}
                                />
                            ) : null}
                        </>
                    ) : null}
                </View>
            </KeyboardAwareScrollView>
            <View style={{ flexDirection: 'row', paddingHorizontal: 16, paddingBottom: 24 }}>
                <EkycButton
                    customStyle={{ flex: 1, marginEnd: 16 }}
                    text={t('common_button_previous')}
                    onPress={() => switchStep.prev({ step: 3, subStep: 0 })}
                />
                <EkycButton
                    customStyle={{ flex: 1 }}
                    isLoading={loading || loadingRegister}
                    text={t('common_button_next')}
                    onPress={() => checkBeforeNextStep(() => setIsShowReviewModal(true))}
                />
            </View>
            {loadingRegister ? (
                <ModalLoading content={t('common_processing')} maxVisibleLoading={60000} setLoading={setLoadingRegister} visible={loadingRegister} />
            ) : null}
            <ModalConfirmAndReviewInfo
                isShowReviewModal={isShowReviewModal}
                loadingRegister={loadingRegister}
                setIsShowReviewModal={setIsShowReviewModal}
                setLoadingRegister={setLoadingRegister}
                switchStep={switchStep}
            />
            {visibleInstitutional ? (
                <Modal
                    hideModalContentWhileAnimating
                    isVisible={visibleInstitutional}
                    style={UI.modal}
                    useNativeDriver={true}
                    onBackButtonPress={() => setVisibleInstitutional(false)}
                    onBackdropPress={() => setVisibleInstitutional(false)}
                >
                    <View
                        style={{
                            backgroundColor: styles.PRIMARY__BG__COLOR,
                            justifyContent: 'flex-start',
                            borderTopLeftRadius: 12,
                            borderTopRightRadius: 12,
                        }}
                    >
                        <ModalBottomContent title={t('institutional')}>
                            {institutionalList.map((item, index) => (
                                <ModalBottomRowSelect
                                    checked={institutional === item.c0}
                                    key={item.c0}
                                    text={item.c1 || ''}
                                    onPress={() => {
                                        setInstitutional(item.c0 || '')
                                        setVisibleInstitutional(false)
                                        // scrollViewRef.current?.scrollToEnd({ animated: true })
                                        // if (item.c0 === '2' || item.c0 === '6') {
                                        //     getBrokerList()
                                        // }
                                    }}
                                />
                            ))}
                        </ModalBottomContent>
                    </View>
                </Modal>
            ) : null}
        </View>
    )
}

const UI = StyleSheet.create({
    modal: {
        justifyContent: 'flex-end',
        margin: 0,
    },
    row: {
        alignItems: 'center',
        borderRadius: 12,
        flexDirection: 'row',
        marginHorizontal: dimensions.moderate(16),
        marginTop: dimensions.vertical(12),
    },
    rowNote: {
        alignItems: 'center',
        borderRadius: 12,
        flexDirection: 'row',
        marginHorizontal: dimensions.moderate(8),
        marginTop: dimensions.vertical(12),
    },
    styleContainer: (styles) => ({
        backgroundColor: styles.PRIMARY__BG__COLOR,
        flex: 1,
    }),
})
