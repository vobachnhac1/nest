import React, { useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Pressable, StyleSheet, Text, TouchableOpacity, TouchableWithoutFeedback, View } from 'react-native'
import AntDesign from 'react-native-vector-icons/AntDesign'
import { CustomFloatInput } from '@mts-basic-components/index'
import { dimensions, fontSizes } from '@mts-styles/index'
import { reqFunct, sendRequest } from '@mts-utils/index'
import { Col } from 'native-base'

import ArrowRight from '../../../../assets/images/common/ic_arrow_right.svg'
import ModalSelection from '../../../../components/list-selections'
import { StoreContext } from '../../../../store'

interface IInputJobInfoProps {
    onChangedJobInfo: (occupation?: IItemSelect, position?: IItemSelect) => void
}

interface IItemSelect {
    label: string
    value: string
    data: IServiceResponeData | any
}

const ServiceInfo: IServiceInfo = {
    GET_JOB_INFO: {
        reqFunct: reqFunct.GET_JOB_INFO,
        ServiceName: 'FOSqAccount_Common',
        WorkerName: 'FOSqAccount',
        Operation: 'Q',
    },
}

export const InputJobInfo = ({ onChangedJobInfo }: IInputJobInfoProps) => {
    const { t } = useTranslation()
    const { styles } = useContext(StoreContext)

    const [occupation, setOccupation] = useState<IItemSelect | undefined>({ label: '', value: '', data: {} })
    const [position, setPosition] = useState<IItemSelect | undefined>({ label: '', value: '', data: {} })

    const [listOccupation, setListOccupation] = useState<IItemSelect[]>([])
    const [listPosition, setListPosition] = useState<IItemSelect[]>([])
    const [isOpenModalSelect, setIsOpenModalSelect] = useState(false)
    const [listSelection, setListSelection] = useState<IItemSelect[]>([])

    const [infoSelection, setInfoSelection] = useState<{
        type: string
        callback: (item?: IItemSelect) => void
    }>({
        type: '',
        callback: () => {},
    })

    useEffect(() => {
        getOccupationData()
        getPositionData()
    }, [])

    useEffect(() => {
        onChangedJobInfo(occupation, position)
    }, [occupation, position])

    const getOccupationData = () => {
        setListOccupation([])
        const InputParams = ['29']
        sendRequest(ServiceInfo.GET_JOB_INFO, InputParams, handleDataOccupation)
    }

    function handleDataOccupation(reqInfoMap: any, message: IServiceRespone): void {
        if (Number(message.Result) === 0) {
        } else {
            let jsonData: IServiceResponeData[] = []
            try {
                jsonData = message.Data ? JSON.parse(message.Data) : []
                const dataSelect = jsonData.map((item) => ({ label: item.c1, value: item.c0, data: item }))
                // @ts-expect-error
                setListOccupation(dataSelect)
            } catch (err) {
                return
            }
        }
    }

    const getPositionData = () => {
        setListPosition([])
        const InputParams = ['30']
        sendRequest(ServiceInfo.GET_JOB_INFO, InputParams, handleDataPosition)
    }

    function handleDataPosition(reqInfoMap: any, message: IServiceRespone): void {
        if (Number(message.Result) === 0) {
        } else {
            let jsonData: IServiceResponeData[] = []
            try {
                jsonData = message.Data ? JSON.parse(message.Data) : []
                const dataSelect = jsonData.map((item) => ({ label: item.c1, value: item.c0, data: item }))

                // @ts-expect-error
                setListPosition(dataSelect)
            } catch (err) {
                return
            }
        }
    }

    const onPressSelectOccupation = () => {
        setListSelection(listOccupation)
        setInfoSelection({ type: 'NORMAL_SELECT', callback: setOccupation })
        setIsOpenModalSelect(true)
    }

    const onPressSelectPosition = () => {
        setListSelection(listPosition)
        setInfoSelection({ type: 'NORMAL_SELECT', callback: setPosition })
        setIsOpenModalSelect(true)
    }

    return (
        <>
            <View style={{ flexDirection: 'row', flex: 1, paddingHorizontal: 16, marginTop: 16 }}>
                <Col size={12}>
                    <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small, flex: 4, textAlignVertical: 'center' }}>
                        {t('common_job')}
                        <Text style={{ color: 'red' }}>*</Text>
                    </Text>
                    <Pressable onPress={onPressSelectOccupation}>
                        <View style={UI.RowInput}>
                            <CustomFloatInput
                                animationDuration={100}
                                ellipsizeMode="end"
                                isSelectInput
                                label={t('common_job')}
                                numberOfLines={1}
                                rightComponent={
                                    occupation?.label ? (
                                        <View style={UI.BlankSpace} />
                                    ) : (
                                        <TouchableOpacity style={{ paddingVertical: 8 }} onPress={() => {}}>
                                            <ArrowRight style={{ color: styles.PRIMARY__CONTENT__COLOR, marginRight: 10 }} />
                                        </TouchableOpacity>
                                    )
                                }
                                value={occupation?.label}
                            />
                            <View style={UI.ButtonDelete}>
                                {occupation?.label ? (
                                    <TouchableWithoutFeedback>
                                        <TouchableOpacity
                                            style={{ paddingHorizontal: 8, paddingVertical: 8 }}
                                            onPress={() => {
                                                setOccupation({ label: '', value: '', data: {} })
                                            }}
                                        >
                                            <AntDesign
                                                color={styles.ICON__PRIMARY}
                                                name="closecircleo"
                                                size={20}
                                                style={{ marginHorizontal: dimensions.moderate(5) }}
                                            />
                                        </TouchableOpacity>
                                    </TouchableWithoutFeedback>
                                ) : null}
                            </View>
                        </View>
                    </Pressable>
                </Col>
                <View style={{ width: 8 }} />
                <Col size={12}>
                    <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small, flex: 4, textAlignVertical: 'center' }}>
                        {t('common_job_position')}
                        <Text style={{ color: 'red' }}>*</Text>
                    </Text>
                    <Pressable onPress={onPressSelectPosition}>
                        <View style={UI.RowInput}>
                            <CustomFloatInput
                                animationDuration={100}
                                ellipsizeMode="end"
                                isSelectInput
                                label={t('common_job_position')}
                                numberOfLines={1}
                                rightComponent={
                                    position?.label ? (
                                        <View style={UI.BlankSpace} />
                                    ) : (
                                        <TouchableOpacity style={{ paddingVertical: 8 }} onPress={() => {}}>
                                            <ArrowRight style={{ color: styles.PRIMARY__CONTENT__COLOR, marginRight: 10 }} />
                                        </TouchableOpacity>
                                    )
                                }
                                value={position?.label}
                            />
                            <View style={UI.ButtonDelete}>
                                {position?.label ? (
                                    <TouchableWithoutFeedback>
                                        <TouchableOpacity
                                            style={{ paddingHorizontal: 8, paddingVertical: 8 }}
                                            onPress={() => {
                                                setPosition({ label: '', value: '', data: {} })
                                            }}
                                        >
                                            <AntDesign
                                                color={styles.ICON__PRIMARY}
                                                name="closecircleo"
                                                size={20}
                                                style={{ marginHorizontal: dimensions.moderate(5) }}
                                            />
                                        </TouchableOpacity>
                                    </TouchableWithoutFeedback>
                                ) : null}
                            </View>
                        </View>
                    </Pressable>
                </Col>
            </View>
            <ModalSelection
                actionType={infoSelection.type}
                callBackOtherFunction={function (): void {
                    throw new Error('Function not implemented.')
                }}
                getSelectValue={infoSelection.callback}
                isOpen={isOpenModalSelect}
                listSelectionsProps={listSelection}
                setIsOpen={setIsOpenModalSelect}
            />
        </>
    )
}

const UI = StyleSheet.create({
    BlankSpace: {
        height: 10,
        width: dimensions.moderate(40),
    },
    ButtonDelete: {
        alignItems: 'center',
        height: '100%',
        justifyContent: 'center',
        position: 'absolute',
        right: 0,
    },
    RowEditAbleStyle: {
        borderRadius: 4,
        flex: 5,
        fontSize: fontSizes.small,
        padding: 0,
        paddingHorizontal: 5,
        paddingVertical: 8,
        textAlignVertical: 'top',
    },
    RowInput: {
        // marginHorizontal: dimensions.moderate(16),
        flex: 1,
        marginVertical: dimensions.vertical(8),
    },
    column: {
        alignItems: 'flex-start',
        borderRadius: 12,
        flexDirection: 'column',
        marginHorizontal: dimensions.moderate(16),
        marginTop: dimensions.vertical(6),
        paddingVertical: 2,
    },
})
