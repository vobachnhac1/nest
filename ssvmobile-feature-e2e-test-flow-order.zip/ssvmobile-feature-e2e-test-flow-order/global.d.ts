declare global {
    declare module '*.svg' {
        import React from 'react'
        import { SvgProps } from 'react-native-svg'

        const content: React.FC<SvgProps>
        export default content
    }
    declare module '*.png' {
        const value: import('react-native').ImageSourcePropType
        export default value
    }
    /**
     * Now declare things that go in the global namespace,
     * or augment existing declarations in the global namespace.

     */
    interface ISserviceInfo {
        reqFunct: string // Phải dùng nếu không rất dễ lỗi
        WorkerName: string
        ServiceName: string
        Operation: 'Q' | 'I' | 'U' | 'D'
        /**
         * @deprecated Không dùng ClientSentTime nữa - không cần thiêt
         */
        ClientSentTime?: '0'
        AprStat?: any
        AprSeq?: any
        MakerDt?: any
        TimeOut?: any
    }
    interface IServiceInfo {
        [key: string]: ISserviceInfo
    }
    interface IServiceRespone {
        Message: string
        Data: string | ''
        Result: 0 | 1 | -1
        Code: string
    }
    interface IServiceResponeData {
        c0?: string
        c1?: string
        c2?: string
        c3?: string
        c4?: string
        c5?: string
        c6?: string
        c7?: string
        c8?: string
        c9?: string
        c10?: string
        c11?: string
        c12?: string
        c13?: string
        c14?: string
        c15?: string
        c16?: string
        c18?: string
        c19?: string
        c20?: string
        c21?: string
        c22?: string
        c23?: string
        c24?: string
        c25?: string
        c26?: string
        c27?: string
        c28?: string
        c29?: string
        c30?: string
        c31?: string
        c32?: string
        c33?: string
        c34?: string
        c35?: string
        c36?: string
        c37?: string
        c38?: string
        c39?: string
        c40?: string
        c41?: string
        c42?: string
        c43?: string
        c44?: string
        c45?: string
        c46?: string
        c47?: string
        c48?: string
        c49?: string
        c50?: string
    }

    interface ICommonEventRx {
        type: string
    }
}
export {}
