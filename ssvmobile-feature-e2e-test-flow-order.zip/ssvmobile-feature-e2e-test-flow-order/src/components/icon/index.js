import React from 'react'

const IconCustomer = ({ name, ...rest }) => {
    const ImportedIconRef = React.useRef(null)
    const [loading, setLoading] = React.useState(false)

    React.useEffect(() => {
        setLoading(true)
        const importIcon = async () => {
            try {
                ImportedIconRef.current = (await import(`../../assets/images/common/${name}.svg`)).ReactComponent
            } catch (err) {
                // Your own error handling logic, throwing error for the sake of
                // simplicity
                throw err
            } finally {
                setLoading(false)
            }
        }
        importIcon()
    }, [name])

    if (!loading && ImportedIconRef.current) {
        const { current: ImportedIcon } = ImportedIconRef
        return <ImportedIcon {...rest} />
    }

    return null
}

export default IconCustomer
