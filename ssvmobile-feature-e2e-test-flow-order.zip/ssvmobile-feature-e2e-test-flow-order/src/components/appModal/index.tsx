import React, { forwardRef, memo, useContext, useEffect, useImperativeHandle, useLayoutEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { InteractionManager, KeyboardAvoidingView, StyleSheet, View } from 'react-native'
import Modal from 'react-native-modal'
import { COLORS } from '@mts-styles/colors'
import { Button } from 'native-base'

import { Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { dimensions, fontSizes, fontWeights } from '../../styles'
import ModalController, { CustomModalRef } from './modalControlller'
import { AppModalProps } from './type'

const AppModal: React.FC<AppModalProps> = () => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()

    const [modalVisible, setModalVisible] = useState(false)
    const [modalProps, setModalProps] = useState({})

    const modalRef = useRef<CustomModalRef>()

    useLayoutEffect(() => {
        ModalController.setModalRef(modalRef)
    }, [])

    const {
        title,
        icon,
        middleComponent,
        typeColor,
        footerComponent,
        titleOK,
        notTouch,
        colorTitle,
        showCancel,
        content,
        isBackdropClose = true,
        linkCallback,
        cancelCallBack,
        onCallBack,
        titleCancel = false,
    } = modalProps

    const showModal = (props) => {
        setModalVisible(true)
        setModalProps(props)
    }

    const handleCancel = () => {
        setModalVisible(false)
        if (cancelCallBack) {
            cancelCallBack()
        } else if (!showCancel && linkCallback) {
            linkCallback()
        } else if (typeof onCallBack === 'function') {
            onCallBack()
        }
    }

    const handleConfirm = () => {
        setModalVisible(false)

        if (typeof linkCallback === 'function') {
            linkCallback()
        } else if (typeof onCallBack === 'function') {
            onCallBack()
        }
    }

    useImperativeHandle(
        modalRef,
        () => ({
            show: (props) => {
                showModal(props)
            },
            hide: () => {
                handleCancel()
            },
        }),
        [],
    )

    if (modalVisible === false) {
        return null
    }

    return (
        <Modal isVisible={modalVisible} useNativeDriver={true} {...(isBackdropClose ? { onBackdropPress: () => handleCancel() } : null)}>
            <View style={[UI.AlertWrapper, { shadowColor: typeColor || styles.PRIMARY__BG__COLOR }]}>
                <KeyboardAvoidingView behavior="padding">
                    <View
                        style={[
                            UI.AlertView,
                            {
                                backgroundColor: styles.PRIMARY__BG__COLOR,
                                paddingBottom: footerComponent ? dimensions.vertical(16) : dimensions.vertical(32),
                            },
                        ]}
                    >
                        {icon}
                        {title ? (
                            <Text style={[UI.AlertTextTitle, { color: colorTitle || styles.PRIMARY__CONTENT__COLOR }]} onPress={notTouch}>
                                {title}
                            </Text>
                        ) : (
                            <View style={{ height: dimensions.vertical(16) }} />
                        )}
                        <Text
                            style={[
                                UI.AlertTextContent,
                                {
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                    marginBottom: dimensions.moderate(middleComponent ? 0 : 32),
                                },
                            ]}
                        >
                            {content}
                        </Text>
                        {middleComponent ? middleComponent : null}
                        <View>
                            <Button block style={{ backgroundColor: styles.PRIMARY, width: dimensions.moderate(200) }} transparent onPress={handleConfirm}>
                                <Text style={UI.textOK}>{titleOK || t('common_Ok').toLocaleUpperCase()}</Text>
                            </Button>
                        </View>
                        {showCancel ? (
                            <View>
                                <Button block style={{ width: dimensions.moderate(200) }} transparent onPress={handleCancel}>
                                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal, opacity: 0.34 }}>
                                        {titleCancel || t('common_Cancel').toLocaleUpperCase()}
                                    </Text>
                                </Button>
                            </View>
                        ) : null}
                        <View style={{ width: '100%' }}>{footerComponent ? footerComponent : null}</View>
                    </View>
                </KeyboardAvoidingView>
            </View>
        </Modal>
    )
}

export default forwardRef(AppModal)

const UI = StyleSheet.create({
    AlertTextContent: {
        fontSize: fontSizes.small,
        opacity: 0.64,
        textAlign: 'center',
    },
    AlertTextTitle: {
        fontSize: fontSizes.xmedium,
        fontWeight: fontWeights.semiBold,
        marginBottom: dimensions.vertical(16),
        marginTop: dimensions.vertical(32),
        textAlign: 'center',
    },
    AlertView: {
        alignItems: 'center',
        borderRadius: 12,
        justifyContent: 'center',
        marginHorizontal: dimensions.moderate(18),
        paddingHorizontal: dimensions.moderate(28),
        paddingTop: dimensions.vertical(32),
    },
    AlertWrapper: {
        alignItems: 'center',
        elevation: 18,
        justifyContent: 'center',
        shadowOffset: {
            width: 0,
            height: 0,
        },
        shadowOpacity: 0.48,
        shadowRadius: 11.95,
    },
    textOK: { color: COLORS.WHITE, fontSize: fontSizes.normal },
})
