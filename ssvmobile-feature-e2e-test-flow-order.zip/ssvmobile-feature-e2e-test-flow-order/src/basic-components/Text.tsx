import React, { memo, useMemo } from 'react'
import { Platform, StyleSheet, Text, TextProps } from 'react-native'

import { enhance } from './index'

const IOS = Platform.OS === 'ios' ? true : false

const TextCustom = memo(({ style, ...props }: TextProps) => {
    const wrapStyle = useMemo(
        () =>
            enhance([
                style,
                IOS
                    ? {}
                    : style
                    ? {
                          // @ts-expect-error
                          fontFamily: getFontWeight(style.fontWeight),
                      }
                    : UI.font,
            ]),
        [style],
    )
    return <Text style={wrapStyle} {...props} />
})

export default TextCustom

const UI = StyleSheet.create({
    font: {
        fontFamily: 'OpenSans-Regular',
    },
})

function getFontWeight(wei) {
    if (['100', '200', '300'].includes(wei)) return 'OpenSans-Light'
    if (['500', '600'].includes(wei)) return 'OpenSans-SemiBold'
    if (['700', '800', '900'].includes(wei)) return 'OpenSans-ExtraBold'
    return 'OpenSans-Regular'
}
