import React, { useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { ActivityIndicator, Image, InteractionManager, StyleSheet, TouchableOpacity, View } from 'react-native'
import Modal from 'react-native-modal'
import Svg, { Circle, Path } from 'react-native-svg'
import ToastGlobal from 'react-native-toast-message'
import { Button, Container, Content } from 'native-base'
import { default as SyncStorage, default as syncStorage } from 'sync-storage'

import ICON_OTP_SECURITY from '../../../assets/images/common/ic_otp_security.png'
import { Text, TextInput } from '../../../basic-components'
import HeaderComponent from '../../../components/header'
import {
    ButtonCustom,
    ErrorView,
    ModalBottomContent,
    ModalBottomRowSelect,
    ModalContent,
    RowDataModal,
    RowTitleGroup,
} from '../../../components/trading-component'
import { useAlertModal, useAlertModalCommonCode, useLoading, useModalOtpWhenErr, useUpdateEffect } from '../../../hoc'
import ModalOtpInput from '../../../layouts/login/modal-authen-otp-acc-holder'
import { StoreContext } from '../../../store'
import { StoreTrading } from '../../../store-trading'
import { dimensions, fontSizes, fontWeights, IconSvg } from '../../../styles'
import { dataCryption, eventList, glb_sv, reqFunct, Screens, sendRequest, STORE_KEY } from '../../../utils'

const ServiceInfo = {
    LIST_OTP_TYPE: {
        reqFunct: reqFunct.LIST_OTP_TYPE,
        WorkerName: 'FOSqID01',
        ServiceName: 'FOSqID01_OTPManagement',
        Operation: 'Q',
    },
    CHANGE_OTP_TYPE: {
        reqFunct: reqFunct.CHANGE_OTP_TYPE,
        WorkerName: 'FOSxID01',
        ServiceName: 'FOSxID01_Management',
        Operation: 'I',
    },
}

function ChangeOTPTypeScreen({ navigation, route }) {
    const { functCallback, fromScreen } = route.params
    const { styles, language } = useContext(StoreContext)
    const { userInfo } = useContext(StoreTrading)

    const { t } = useTranslation()

    const [loading, setLoading] = useLoading(false)
    const [listOtpType, setListOtpType] = useState([])

    const [isModalSelect, setIsModalSelect] = useState(false)

    const [selectedOtpType, setSelectedOtpType] = useState({})

    const [isModalConfirm, setIsModalConfirm] = useState(false)
    const [isModalConfirmSelectIOtpType, setIsModalConfirmSelectIOtpType] = useState(false)

    // ---- OTP
    const [timeOTP, setTimeOTP] = useState(60)
    const [otpMessage, setOtpMessage] = useState('')
    const [visibleModalAuthen, setVisibleModalAuthen] = useState(false)
    // const [otpCode, setOtpCode] = useState('')

    useEffect(() => {
        getListOtpType()
    }, [])
    useEffect(() => {
        if (listOtpType.length) {
            const firstItem = listOtpType[0] || {}
            const currentSelectedOtpType = listOtpType.find((item) => item?.c0 === firstItem?.c2) || { c1: firstItem.c3 }
            setSelectedOtpType(currentSelectedOtpType)
        }
    }, [listOtpType])

    const getListOtpType = () => {
        const InputParams = ['chgotp']
        sendRequest(ServiceInfo.LIST_OTP_TYPE, InputParams, getListOtpTypeResult)
    }

    const getListOtpTypeResult = (reqInfoMap, message) => {
        console.log('getListOtpTypeResult -> message', message)
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata
            if (!message.Data) return
            try {
                jsondata = JSON.parse(message.Data)
                setListOtpType(jsondata)
            } catch (err) {
                console.log('getLoginSessionHistoryResult -> err', err)
                return
            }
        }
    }

    const changeListOtpType = (otp) => {
        console.log('changeListOtpType', otp ? dataCryption.encryptString(otp) : '')
        const InputParams = ['chgotp', selectedOtpType?.c0, otp ? dataCryption.encryptString(otp) : '']
        sendRequest(ServiceInfo.CHANGE_OTP_TYPE, InputParams, changeListOtpTypeResult)
        setLoading(true)
        // setOtpCode('')
    }

    const changeListOtpTypeResult = (reqInfoMap, message) => {
        setLoading(false)
        setIsModalConfirm(false)
        console.log('changeListOtpTypeResult -> message', message)
        if (Number(message.Result) === 0) {
            if (message.Code === '010021') {
                // sendUpdateInfosRequest('123456')
                try {
                    const jsondata = message.Data ? JSON.parse(message.Data) : []
                    if (jsondata) {
                        const time = jsondata[0].c1
                        setTimeOTP(Number(time))
                    }
                    setTimeout(() => {
                        setVisibleModalAuthen(true)
                    }, 0)
                } catch (err) {
                    console.log(err)
                }
                return
            }
            // --------
            const { hasAlertCommonCode } = useAlertModalCommonCode(message, {})
            const { hasAlertErrOtp } = useModalOtpWhenErr(message, { continueVerify: !hasAlertCommonCode, callback: () => setIsModalConfirm(true) })
            useAlertModal(message, { continueVerify: !hasAlertErrOtp })
            return
        } else {
            glb_sv.objShareGlb.userInfo.c6 = reqInfoMap.inputParam[1]
            if (reqInfoMap.inputParam[1] === '5') {
                if (glb_sv.configInfo.application_style.show_get_iotp) {
                    glb_sv.objShareGlb.userInfo.c20 = 'Y'
                    glb_sv.objShareGlb.userInfo.c13 = 'Y'
                } else {
                    glb_sv.objShareGlb.userInfo.c13 = 'N'
                }
            } else {
                glb_sv.objShareGlb.userInfo.c20 = 'N'
                if (glb_sv.configInfo.application_style.show_get_iotp) {
                    glb_sv.objShareGlb.userInfo.c13 = 'Y'
                } else {
                    glb_sv.objShareGlb.userInfo.c13 = 'N'
                }
            }
            ToastGlobal.show({
                text2: message.Message,
                type: 'success',
            })

            if (functCallback) {
                console.log('ChangeOTPTypeScreen functCallback is NOT NULL')
                InteractionManager.runAfterInteractions(() => {
                    setTimeout(() => {
                        functCallback()
                    }, 0)
                })
            } else {
                console.log('ChangeOTPTypeScreen functCallback is NULL')
            }
            navigation.goBack()
            // getListOtpType()
        }
    }
    const onFinish = () => {
        setIsModalSelect(false)
    }

    const otpAuthenCallBack = (otpCode) => {
        console.log('otpAuthenCallBack otpCode: ', otpCode)
        // setOtpCode(otpCode)
        changeListOtpType(otpCode)
    }

    // console.log('listOtpType', listOtpType)
    return (
        <Container>
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft={true}
                navigation={navigation}
                title={t('change_otp_type')}
                titleAlgin="flex-start"
            />
            <Content keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false} style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
                <View style={{ justifyContent: 'center', alignItems: 'center', marginBottom: 50, marginTop: 24 }}>
                    <Image source={ICON_OTP_SECURITY} style={{ width: 200, height: 200 }} />
                </View>
                <RowTitleGroup text={t('select_new_otp_type')} />
                <View style={{ paddingHorizontal: dimensions.moderate(16), paddingTop: dimensions.vertical(16) }}>
                    <TouchableOpacity
                        style={[
                            UI.viewInput,
                            { borderColor: styles.INPUT__BG__LOGIN, backgroundColor: styles.INPUT__BG__LOGIN, marginBottom: dimensions.vertical(12) },
                        ]}
                        onPress={() => setIsModalSelect(true)}
                    >
                        <Text style={{ fontSize: fontSizes.small, color: styles.SECOND__CONTENT__COLOR, flex: 1, textAlignVertical: 'center' }}>
                            {t('otp_type')}
                        </Text>
                        <Text
                            numberOfLines={1}
                            style={{
                                fontSize: fontSizes.medium,
                                padding: 0,
                                color: styles.PRIMARY__CONTENT__COLOR,
                                flex: 2,
                                textAlignVertical: 'center',
                            }}
                        >
                            {selectedOtpType?.c1}
                        </Text>
                        <IconSvg.ChevoletDownIcon color={styles.PRIMARY__CONTENT__COLOR} />
                    </TouchableOpacity>
                </View>
                <View>
                    <ButtonCustom
                        text={t('update_otp_type')}
                        onPress={() => {
                            if (selectedOtpType.c0 === '5') {
                                // Nếu là iOTP thì hỏi user có muốn kích hoạt iotp không và navigate lại màn hình iotp
                                setIsModalConfirmSelectIOtpType(true)
                                return
                            }
                            // -----------
                            if (!selectedOtpType.c0 || selectedOtpType?.c3 === selectedOtpType?.c1) {
                                ToastGlobal.show({
                                    text2: t('otp_type_is_required'),
                                    type: 'warning',
                                })
                                return
                            }
                            setTimeOTP(0)
                            setVisibleModalAuthen()
                            // if (!glb_sv.checkOtp(navigation, () => setIsModalConfirm(true))) return
                            setIsModalConfirm(true)
                        }}
                    />
                </View>
            </Content>

            {isModalSelect ? (
                <Modal
                    hideModalContentWhileAnimating={true}
                    isVisible={isModalSelect}
                    style={UI.bottomModal}
                    useNativeDriver={true}
                    onBackButtonPress={onFinish}
                    onBackdropPress={onFinish}
                >
                    <ModalBottomContent title={t('otp_type')}>
                        {listOtpType.map((item) => (
                            <ModalBottomRowSelect
                                checked={selectedOtpType.c0 === item.c0}
                                key={String(Math.random())}
                                text={t(item.c1)}
                                onPress={() => {
                                    setIsModalSelect(false)
                                    setSelectedOtpType(item)
                                }}
                            />
                        ))}
                    </ModalBottomContent>
                </Modal>
            ) : null}
            {isModalConfirm ? (
                <Modal
                    isVisible={isModalConfirm}
                    useNativeDriver={true}
                    onBackButtonPress={() => setIsModalConfirm(false)}
                    onBackdropPress={() => setIsModalConfirm(false)}
                >
                    <ModalContent
                        iconComponent={
                            <Svg fill="none" height={32} viewBox="0 0 33 32" width={33} xmlns="http://www.w3.org/2000/svg">
                                <Path d="M4.60667 0.125L0.185547 4.54612H4.60667V0.125Z" fill="#2ECC71" />
                                <Path
                                    d="M32.0524 6.73597L30.7266 5.41016L28.4714 7.66541C28.1902 7.65647 27.9062 7.75797 27.6921 7.97209L26.5059 9.15834L28.3042 10.9567L29.4905 9.77041C29.6897 9.57128 29.7993 9.30653 29.7993 9.02497C29.7993 9.01347 29.798 9.00216 29.7976 8.99072L32.0524 6.73597Z"
                                    fill="#2ECC71"
                                />
                                <Path d="M14.1348 21.5254L25.1749 10.4853L26.973 12.2834L15.9329 23.3235L14.1348 21.5254Z" fill="#2ECC71" />
                                <Path d="M12.9429 22.9844L11.8164 25.6474L14.4795 24.521L12.9429 22.9844Z" fill="#2ECC71" />
                                <Path
                                    d="M9.9738 28.4621L8.37836 26.867L6.95511 28.2903H3.04811V26.4153H6.17848L8.37836 24.2153L9.79023 25.6272L11.552 21.4621L14.3313 18.6829H4.15786V16.8079H16.2063L18.3147 14.6995H4.15786V12.8245H20.1897L24.3016 8.71262V0H6.48073V6.42019H0.0605469V32H24.3015V17.6126L16.0021 25.9122L9.9738 28.4621ZM6.96242 8.84106H17.3998V10.7161H6.96242V8.84106Z"
                                    fill="#2ECC71"
                                />
                            </Svg>
                        }
                        title={t('confirm_change_otp_type')}
                    >
                        {/* <RowDataModal textLeft={t('acnt_no')} dataSub={[userInfo.actn_curr, userInfo.sub_curr]} /> */}
                        <RowDataModal textLeft={t('current_otp_type')} textRight={selectedOtpType?.c3} />
                        <RowDataModal last textLeft={t('new_otp_type')} textRight={selectedOtpType?.c1} />

                        <ButtonCustom text={t('common_button_confirm')} type="confirm" onPress={() => changeListOtpType('')} />
                        <ButtonCustom last text={'common_Cancel'} type="back" onPress={() => setIsModalConfirm(false)} />
                    </ModalContent>
                </Modal>
            ) : null}
            {isModalConfirmSelectIOtpType ? (
                <Modal
                    isVisible={isModalConfirmSelectIOtpType}
                    useNativeDriver={true}
                    onBackButtonPress={() => setIsModalConfirmSelectIOtpType(false)}
                    onBackdropPress={() => setIsModalConfirmSelectIOtpType(false)}
                >
                    <ModalContent
                        iconComponent={
                            <Svg fill="none" height={32} viewBox="0 0 33 32" width={33} xmlns="http://www.w3.org/2000/svg">
                                <Path d="M4.60667 0.125L0.185547 4.54612H4.60667V0.125Z" fill="#2ECC71" />
                                <Path
                                    d="M32.0524 6.73597L30.7266 5.41016L28.4714 7.66541C28.1902 7.65647 27.9062 7.75797 27.6921 7.97209L26.5059 9.15834L28.3042 10.9567L29.4905 9.77041C29.6897 9.57128 29.7993 9.30653 29.7993 9.02497C29.7993 9.01347 29.798 9.00216 29.7976 8.99072L32.0524 6.73597Z"
                                    fill="#2ECC71"
                                />
                                <Path d="M14.1348 21.5254L25.1749 10.4853L26.973 12.2834L15.9329 23.3235L14.1348 21.5254Z" fill="#2ECC71" />
                                <Path d="M12.9429 22.9844L11.8164 25.6474L14.4795 24.521L12.9429 22.9844Z" fill="#2ECC71" />
                                <Path
                                    d="M9.9738 28.4621L8.37836 26.867L6.95511 28.2903H3.04811V26.4153H6.17848L8.37836 24.2153L9.79023 25.6272L11.552 21.4621L14.3313 18.6829H4.15786V16.8079H16.2063L18.3147 14.6995H4.15786V12.8245H20.1897L24.3016 8.71262V0H6.48073V6.42019H0.0605469V32H24.3015V17.6126L16.0021 25.9122L9.9738 28.4621ZM6.96242 8.84106H17.3998V10.7161H6.96242V8.84106Z"
                                    fill="#2ECC71"
                                />
                            </Svg>
                        }
                        title={t('confirm_change_otp_type')}
                    >
                        <View style={{ justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingHorizontal: dimensions.moderate(16) }}>
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal, textAlign: 'center' }}>
                                {t('warn_change_to_iotp_type')}
                            </Text>
                        </View>
                        <ButtonCustom
                            text={t('common_button_confirm')}
                            type="confirm"
                            onPress={() => {
                                if (fromScreen === Screens.SETTINGS) {
                                    navigation.replace(Screens.ACTIVE_OTP, {})
                                } else {
                                    navigation.navigate(Screens.ACTIVE_OTP, {})
                                }
                            }}
                        />
                        <ButtonCustom last text={'common_Cancel'} type="back" onPress={() => setIsModalConfirmSelectIOtpType(false)} />
                    </ModalContent>
                </Modal>
            ) : null}
            {timeOTP ? (
                <ModalOtpInput
                    callbackAfterConfirm={otpAuthenCallBack}
                    message={otpMessage}
                    navigation
                    setVisible={setVisibleModalAuthen}
                    time={timeOTP}
                    visible={visibleModalAuthen}
                />
            ) : null}
        </Container>
    )
}

const UI = StyleSheet.create({
    bottomModal: {
        justifyContent: 'flex-end',
        margin: 0,
    },
    viewInput: {
        borderRadius: 8,
        borderWidth: 1,
        flexDirection: 'row',
        paddingHorizontal: dimensions.moderate(16),
        paddingVertical: dimensions.vertical(12),
    },
})

export default ChangeOTPTypeScreen
