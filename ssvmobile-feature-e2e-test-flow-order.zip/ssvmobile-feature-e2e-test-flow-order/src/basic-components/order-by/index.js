import React, { memo, useContext, useMemo } from 'react'
import { StyleSheet, TouchableOpacity } from 'react-native'
import Svg, { Path } from 'react-native-svg'

import { StoreContext } from '../../store'
import { fontSizes, fontWeights } from '../../styles'
import Text from '../Text'

const OrderByComponent = ({ status, title, sortType, changeTypeSort, notSort, isPriceboard, itemAlign, notShowActive }) => {
    const { styles } = useContext(StoreContext)

    const TextOrder = useMemo(
        () =>
            StyleSheet.flatten([
                {
                    color: status ? styles.PRIMARY : styles.FIFTH__CONTENT__COLOR,
                    fontSize: isPriceboard ? fontSizes.tiny : fontSizes.small,
                    fontWeight: fontWeights.medium,
                },
            ]),
        [styles, isPriceboard, status],
    )

    return (
        <TouchableOpacity
            disabled={notSort}
            style={[UI.view, itemAlign ? { justifyContent: itemAlign } : {}]}
            onPress={() => changeTypeSort && changeTypeSort(sortType)}
        >
            <Text style={TextOrder}>{title}</Text>
            {notSort || (notShowActive && !status) ? null : (
                <Svg height={13} viewBox="0 0 12 13" width={12}>
                    <Path
                        d="M2.519 7.734l2.84 3.315a.488.488 0 00.74 0l2.84-3.315a.488.488 0 00-.37-.804h-5.68a.487.487 0 00-.37.804z"
                        fill={status === 'desc' ? styles.PRIMARY : styles.ICON__UN__ACTIVE}
                    />
                    <Path
                        d="M2.519 4.784l2.84-3.314a.488.488 0 01.74 0l2.84 3.314a.488.488 0 01-.37.805h-5.68a.487.487 0 01-.37-.805z"
                        fill={status === 'asc' ? styles.PRIMARY : styles.ICON__UN__ACTIVE}
                    />
                </Svg>
            )}
        </TouchableOpacity>
    )
}

const UI = StyleSheet.create({
    view: {
        alignItems: 'center',
        flex: 1,
        flexDirection: 'row',
    },
})

export default memo(OrderByComponent)
