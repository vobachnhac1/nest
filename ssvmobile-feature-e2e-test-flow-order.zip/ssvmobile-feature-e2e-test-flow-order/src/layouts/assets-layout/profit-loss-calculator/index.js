import React, { memo, useContext, useEffect, useMemo, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { RefreshControl, StyleSheet, View } from 'react-native'
import { ScrollView, TouchableOpacity } from 'react-native-gesture-handler'
import Modal from 'react-native-modal'
import DateTimePickerModal from 'react-native-modal-datetime-picker'
import MonthSelectorCalendar from 'react-native-month-selector'
import { ActivityIndicator } from 'react-native-paper'
import ToastGlobal from 'react-native-toast-message'
import Entypo from 'react-native-vector-icons/Entypo'
import moment from 'moment'
import { Text } from 'native-base'

import { ModalBottomContent, RowTitleGroup, WarningOrInfo } from '../../../components/trading-component'
import { useLoading } from '../../../hoc'
import { StoreContext } from '../../../store'
import { StoreTrading } from '../../../store-trading'
import { dimensions, dimensions as dm, fontSizes, fontSizes as fs, fontWeights, IconSvg } from '../../../styles'
import { glb_sv, reqFunct, sendRequest } from '../../../utils'
import FormatNumber from '../../../utils/formatNumber/FormatNumber'
import ChartWebview from './ChartWebView/webview'

// Khai báo ServiceInfo (nếu có)
const ServiceInfo = {
    EXPECTED_PROFIT_AMOUNT: {
        reqFunct: reqFunct.EXPECTED_PROFIT_AMOUNT,
        WorkerName: 'FOSqAsset',
        ServiceName: 'FOSqAsset_1801_5',
        Operation: 'Q',
    },
    EXPECTED_PROFIT_RATIO: {
        reqFunct: reqFunct.EXPECTED_PROFIT_RATIO,
        WorkerName: 'FOSqAsset',
        ServiceName: 'FOSqAsset_1801_5',
        Operation: 'Q',
    },
    EXPECTED_PROFIT_FULL: {
        reqFunct: reqFunct.EXPECTED_PROFIT_FULL,
        WorkerName: 'FOSqAsset',
        ServiceName: 'FOSqAsset_1801_5',
        Operation: 'Q',
    },
}

// Khai báo component
const ProfitLossCalculator = ({ navigation, isAllSub }) => {
    const { styles, theme, language } = useContext(StoreContext)
    const { userInfo } = useContext(StoreTrading)

    const { t } = useTranslation()

    const [fromDt, setFromDt] = useState(moment(glb_sv.objShareGlb.workDate).startOf('months').toDate())
    const [toDt, setToDt] = useState(moment(glb_sv.objShareGlb.workDate).endOf('months').toDate())
    const [isDatePickerFrom, setisDatePickerFrom] = useState(false)
    const [isDatePickerTo, setisDatePickerTo] = useState(false)

    const [isLoadingFull, setIsLoadingFull] = useLoading(false)
    const [profitAmountLoading, setProfitAmountLoading] = useLoading(false)
    const [profitRatioLoading, setProfitRatioLoading] = useLoading(false)

    const [expectedProfitAmountObj, setExpectedProfitAmountObj] = useState({})
    const [expectedProfitRatio, setExpectedProfitRatio] = useState([])
    const [expectedProfitFull, setExpectedProfitFull] = useState([])
    const [expectedProfitFullObj, setExpectedProfitFullObj] = useState({ DATA_AMOUNT: [], DATA_RATIO: [], DATA_CATEGORY: [] })

    useEffect(() => {
        getExpectedProfitRatio()
        getExpectedProfitFull()
        getExpectedProfitAmount()

        return () => {}
    }, [isAllSub, userInfo.actn_curr, userInfo.sub_curr])

    useEffect(() => {
        getExpectedProfitAmount()

        return () => {
            // second
        }
    }, [fromDt, toDt])

    const getExpectedProfitAmount = () => {
        const { actn_curr, sub_curr } = userInfo
        if (!actn_curr) return
        const inputParams = ['01', actn_curr, isAllSub ? '%' : sub_curr, moment(fromDt).format('YYYYMM'), moment(toDt).format('YYYYMM')]
        setProfitAmountLoading(true)
        setExpectedProfitAmountObj({})
        sendRequest(ServiceInfo.EXPECTED_PROFIT_AMOUNT, inputParams, getExpectedProfitAmountResult, true, getExpectedProfitAmountTimeout)
    }

    const getExpectedProfitAmountResult = (reqInfoMap, message) => {
        // console.log('getExpectedProfitAmountResult: ', reqInfoMap, message)
        if (Number(message.Result) === 0) {
            ToastGlobal.show({
                type: 'warning',
                text2: message.Message,
            })
            setProfitAmountLoading(false)
            return
        } else {
            let jsondata = []
            try {
                jsondata = JSON.parse(message.Data)
            } catch (err) {
                console.warn('getExpectedProfitAmountResult: ', err)
            }
            if (Number(message.Packet) <= 0) {
                setProfitAmountLoading(false)
                // console.log('getExpectedProfitAmountResult: ', jsondata[0])
                setExpectedProfitAmountObj(jsondata[0])
            }
        }
    }

    const getExpectedProfitAmountTimeout = (e) => {
        setExpectedProfitAmountObj({})
        setProfitAmountLoading(false)
        // notification.warning({
        //     message: t('common_InfoMessage'),
        //     description: t('request_did_not_receive_a_response_from_the_server'),
        //     duration: 3,
        // })
    }

    const getExpectedProfitRatio = () => {
        const { actn_curr, sub_curr } = userInfo
        if (!actn_curr) return
        const inputParams = ['02', actn_curr, isAllSub ? '%' : sub_curr]
        setExpectedProfitRatio([])
        setProfitRatioLoading(true)
        sendRequest(ServiceInfo.EXPECTED_PROFIT_RATIO, inputParams, getExpectedProfitRatioResult, true, getExpectedProfitRatioTimeout)
    }

    const getExpectedProfitRatioResult = (reqInfoMap, message) => {
        // console.log('getExpectedProfitRatioResult: ', reqInfoMap, message)
        if (Number(message.Result) === 0) {
            ToastGlobal.show({
                type: 'warning',
                text2: message.Message,
            })
            setProfitRatioLoading(false)
            return
        } else {
            let jsondata = []
            try {
                jsondata = JSON.parse(message.Data)
            } catch (err) {
                console.warn('getExpectedProfitRatioResult: ', err)
            }
            if (Number(message.Packet) <= 0) {
                setProfitRatioLoading(false)
                // console.log('getExpectedProfitRatioResult: ', jsondata)
                setExpectedProfitRatio(jsondata)
            }
        }
    }

    const getExpectedProfitRatioTimeout = (e) => {
        setExpectedProfitRatio([])
        setProfitRatioLoading(false)
        // notification.warning({
        //     message: t('common_InfoMessage'),
        //     description: t('request_did_not_receive_a_response_from_the_server'),
        //     duration: 3,
        // })
    }

    const getExpectedProfitFull = () => {
        const { actn_curr, sub_curr } = userInfo
        if (!actn_curr) return
        const inputParams = ['03', actn_curr, isAllSub ? '%' : sub_curr]
        // setExpectedProfitFull([])
        setExpectedProfitFullObj({ DATA_AMOUNT: [], DATA_RATIO: [], DATA_CATEGORY: [] })
        setIsLoadingFull(true)
        sendRequest(ServiceInfo.EXPECTED_PROFIT_FULL, inputParams, getExpectedProfitFullResult, true, getExpectedProfitFullTimeout)
    }

    const getExpectedProfitFullResult = (reqInfoMap, message) => {
        // console.log('getExpectedProfitFullResult: ', reqInfoMap, message)
        if (Number(message.Result) === 0) {
            ToastGlobal.show({
                type: 'warning',
                text2: message.Message,
            })
            setIsLoadingFull(false)
            return
        } else {
            let jsondata = []
            try {
                jsondata = JSON.parse(message.Data)
            } catch (err) {
                console.warn('getExpectedProfitFullResult: ', err)
            }
            if (Number(message.Packet) <= 0) {
                setIsLoadingFull(false)
                const DATA_RATIO = jsondata.map((item) => {
                    return {
                        y: Number.parseFloat(item.c0),
                        color: styles.REF__COLOR,
                    }
                })
                const DATA_AMOUNT = jsondata.map((item) => {
                    return {
                        y: Number(item.c1),
                        color: Number(item.c1) >= 0 ? styles.UP__COLOR : styles.DOWN__COLOR,
                    }
                })
                const DATA_CATEGORY = jsondata.map((x) => `${moment(x.c2, 'YYYYMMDD').format('DD/MM/YY')} - ${moment(x.c3, 'YYYYMMDD').format('DD/MM/YY')}`)
                // setExpectedProfitFull(jsondata)
                setExpectedProfitFullObj({ DATA_AMOUNT, DATA_RATIO, DATA_CATEGORY })
            }
        }
    }

    const getExpectedProfitFullTimeout = (e) => {
        // setExpectedProfitFull([])
        setExpectedProfitFullObj({ DATA_AMOUNT: [], DATA_RATIO: [], DATA_CATEGORY: [] })
        setIsLoadingFull(false)
        // notification.warning({
        //     message: t('common_InfoMessage'),
        //     description: t('request_did_not_receive_a_response_from_the_server'),
        //     duration: 3,
        // })
    }

    const hideDatePicker = () => {
        setisDatePickerFrom(false)
        setisDatePickerTo(false)
    }

    const StyleContainer = {
        backgroundColor: styles.PRIMARY__BG__COLOR,
        flex: 1,
    }

    const onRefresh = () => {
        getExpectedProfitRatio()
        getExpectedProfitFull()
        getExpectedProfitAmount()
    }

    return (
        <ScrollView
            refreshControl={<RefreshControl refreshing={isLoadingFull} tintColor={styles.PRIMARY__CONTENT__COLOR} onRefresh={onRefresh} />}
            style={StyleContainer}
        >
            <View style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
                <View style={{ flexDirection: 'row', marginTop: dm.vertical(8), paddingHorizontal: dm.moderate(16), justifyContent: 'space-between' }}>
                    <TouchableOpacity
                        style={{
                            justifyContent: 'flex-start',
                            borderRadius: 8,
                            backgroundColor: styles.BUTTON__THIRD,
                            padding: dm.moderate(8),
                            flexDirection: 'row',
                            alignItems: 'center',
                        }}
                        onPress={() => setisDatePickerFrom(true)}
                    >
                        <View style={{ marginRight: dm.moderate(20) }}>
                            <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fs.normal }}>
                                {t('common_from_month')}
                                {'  '}
                            </Text>
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fs.normal }}>{moment(fromDt).format('MM/YYYY')}</Text>
                        </View>
                        <IconSvg.DateIcon color={styles.PRIMARY__CONTENT__COLOR} />
                    </TouchableOpacity>
                    <View style={{ width: dm.moderate(16) }} />
                    <TouchableOpacity
                        style={{
                            justifyContent: 'flex-start',
                            borderRadius: 8,
                            backgroundColor: styles.BUTTON__THIRD,
                            padding: dm.moderate(8),
                            flexDirection: 'row',
                            alignItems: 'center',
                        }}
                        onPress={() => setisDatePickerTo(true)}
                    >
                        <View style={{ marginRight: dm.moderate(20) }}>
                            <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fs.normal }}>
                                {t('common_to_month')}
                                {'  '}
                            </Text>
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fs.normal }}>{moment(toDt).format('MM/YYYY')}</Text>
                        </View>
                        <IconSvg.DateIcon color={styles.PRIMARY__CONTENT__COLOR} />
                    </TouchableOpacity>
                </View>

                <WarningOrInfo rowStyle={{ marginTop: 10 }} text={t('note_profit_lost_calc')} />

                <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                    <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('period_of_calculation')}</Text>
                    <Text
                        style={{
                            color: styles.PRIMARY__CONTENT__COLOR,
                            fontSize: fontSizes.small,
                            fontWeight: fontWeights.bold,
                            flex: 1,
                            textAlign: 'right',
                        }}
                    >
                        {`${moment(expectedProfitAmountObj?.c7, 'DDMMYYYY').format('DD/MM/YYYY')} - ${moment(expectedProfitAmountObj?.c8, 'DDMMYYYY').format(
                            'DD/MM/YYYY',
                        )}`}
                    </Text>
                </View>
                <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                    <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('expected_profit_amount')}</Text>
                    <Text
                        style={{
                            color:
                                Number(expectedProfitAmountObj?.c0) < 0
                                    ? styles.DOWN__COLOR
                                    : Number(expectedProfitAmountObj?.c0) > 0
                                    ? styles.UP__COLOR
                                    : styles.PRIMARY__CONTENT__COLOR,
                            fontSize: fontSizes.small,
                            fontWeight: fontWeights.bold,
                            flex: 1,
                            textAlign: 'right',
                        }}
                    >
                        {FormatNumber(expectedProfitAmountObj?.c0)}
                    </Text>
                </View>
                <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                    <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('expected_profit_ratio')}</Text>
                    <Text
                        style={{
                            color:
                                Number(expectedProfitAmountObj?.c0) < 0
                                    ? styles.DOWN__COLOR
                                    : Number(expectedProfitAmountObj?.c0) > 0
                                    ? styles.UP__COLOR
                                    : styles.PRIMARY__CONTENT__COLOR,
                            fontSize: fontSizes.small,
                            fontWeight: fontWeights.bold,
                            flex: 1,
                            textAlign: 'right',
                        }}
                    >
                        {expectedProfitAmountObj?.c1}%
                    </Text>
                </View>

                <RowTitleGroup text={t('summary_of_asset_changes_in_period')} type="group" />
                <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                    <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('initial_equity')}</Text>
                    <Text
                        style={{
                            color: styles.PRIMARY__CONTENT__COLOR,
                            fontSize: fontSizes.small,
                            fontWeight: fontWeights.bold,
                            flex: 1,
                            textAlign: 'right',
                        }}
                    >
                        {FormatNumber(expectedProfitAmountObj?.c2)}
                    </Text>
                </View>
                <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                    <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('end_equity')}</Text>
                    <Text
                        style={{
                            color: styles.PRIMARY__CONTENT__COLOR,
                            fontSize: fontSizes.small,
                            fontWeight: fontWeights.bold,
                            flex: 1,
                            textAlign: 'right',
                        }}
                    >
                        {FormatNumber(expectedProfitAmountObj?.c3)}
                    </Text>
                </View>
                <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                    <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('deposit')}</Text>
                    <Text
                        style={{
                            color: styles.PRIMARY__CONTENT__COLOR,
                            fontSize: fontSizes.small,
                            fontWeight: fontWeights.bold,
                            flex: 1,
                            textAlign: 'right',
                        }}
                    >
                        {FormatNumber(expectedProfitAmountObj?.c4)}
                    </Text>
                </View>
                <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                    <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('withdraw')}</Text>
                    <Text
                        style={{
                            color: styles.PRIMARY__CONTENT__COLOR,
                            fontSize: fontSizes.small,
                            fontWeight: fontWeights.bold,
                            flex: 1,
                            textAlign: 'right',
                        }}
                    >
                        {FormatNumber(expectedProfitAmountObj?.c5)}
                    </Text>
                </View>
                <View style={[UI.row, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                    <Text style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('average_investment_amount')}</Text>
                    <Text
                        style={{
                            color: styles.PRIMARY__CONTENT__COLOR,
                            fontSize: fontSizes.small,
                            fontWeight: fontWeights.bold,
                            flex: 1,
                            textAlign: 'right',
                        }}
                    >
                        {FormatNumber(expectedProfitAmountObj?.c6)}
                    </Text>
                </View>

                <RowTitleGroup text={t('summary_of_profit_ratio_and_profit_amount')} type="group" />
                <View style={[UI.rowCenter, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                    <View style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1, justifyContent: 'center' }}>
                        <Text style={{ color: styles.FIFTH__CONTENT__COLOR }}>{t('number_month', { number: '1' })}</Text>
                    </View>
                    <View style={{ flex: 1 }}>
                        <View>
                            <Text
                                style={{
                                    color:
                                        Number(expectedProfitRatio?.[0]?.c1) < 0
                                            ? styles.DOWN__COLOR
                                            : Number(expectedProfitRatio?.[0]?.c1) > 0
                                            ? styles.UP__COLOR
                                            : styles.PRIMARY__CONTENT__COLOR,
                                    fontSize: fontSizes.verySmall,
                                    textAlign: 'right',
                                }}
                            >
                                {FormatNumber(Number(expectedProfitRatio?.[0]?.c0), 2, 1)}%
                            </Text>
                            <Text
                                style={{
                                    color:
                                        Number(expectedProfitRatio?.[0]?.c1) < 0
                                            ? styles.DOWN__COLOR
                                            : Number(expectedProfitRatio?.[0]?.c1) > 0
                                            ? styles.UP__COLOR
                                            : styles.PRIMARY__CONTENT__COLOR,
                                    fontSize: fontSizes.verySmall,
                                    textAlign: 'right',
                                }}
                            >
                                {FormatNumber(expectedProfitRatio?.[0]?.c1)}
                            </Text>
                        </View>
                    </View>
                </View>
                <View style={[UI.rowCenter, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                    <View style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1, justifyContent: 'center' }}>
                        <Text style={{ color: styles.FIFTH__CONTENT__COLOR }}>{t('number_month', { number: '3' })}</Text>
                    </View>
                    <View style={{ flex: 1 }}>
                        <View>
                            <Text
                                style={{
                                    color:
                                        Number(expectedProfitRatio?.[1]?.c1) < 0
                                            ? styles.DOWN__COLOR
                                            : Number(expectedProfitRatio?.[1]?.c1) > 0
                                            ? styles.UP__COLOR
                                            : styles.PRIMARY__CONTENT__COLOR,
                                    fontSize: fontSizes.verySmall,
                                    textAlign: 'right',
                                }}
                            >
                                {FormatNumber(Number(expectedProfitRatio?.[1]?.c0), 2, 1)}%
                            </Text>
                            <Text
                                style={{
                                    color:
                                        Number(expectedProfitRatio?.[1]?.c1) < 0
                                            ? styles.DOWN__COLOR
                                            : Number(expectedProfitRatio?.[1]?.c1) > 0
                                            ? styles.UP__COLOR
                                            : styles.PRIMARY__CONTENT__COLOR,
                                    fontSize: fontSizes.verySmall,
                                    textAlign: 'right',
                                }}
                            >
                                {FormatNumber(expectedProfitRatio?.[1]?.c1)}
                            </Text>
                        </View>
                    </View>
                </View>
                <View style={[UI.rowCenter, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                    <View style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1, justifyContent: 'center' }}>
                        <Text style={{ color: styles.FIFTH__CONTENT__COLOR }}>{t('number_month', { number: '6' })}</Text>
                    </View>
                    <View style={{ flex: 1 }}>
                        <View>
                            <Text
                                style={{
                                    color:
                                        Number(expectedProfitRatio?.[2]?.c1) < 0
                                            ? styles.DOWN__COLOR
                                            : Number(expectedProfitRatio?.[2]?.c1) > 0
                                            ? styles.UP__COLOR
                                            : styles.PRIMARY__CONTENT__COLOR,
                                    fontSize: fontSizes.verySmall,
                                    textAlign: 'right',
                                }}
                            >
                                {FormatNumber(Number(expectedProfitRatio?.[2]?.c0), 2, 1)}%
                            </Text>
                            <Text
                                style={{
                                    color:
                                        Number(expectedProfitRatio?.[2]?.c1) < 0
                                            ? styles.DOWN__COLOR
                                            : Number(expectedProfitRatio?.[2]?.c1) > 0
                                            ? styles.UP__COLOR
                                            : styles.PRIMARY__CONTENT__COLOR,
                                    fontSize: fontSizes.verySmall,
                                    textAlign: 'right',
                                }}
                            >
                                {FormatNumber(expectedProfitRatio?.[2]?.c1)}
                            </Text>
                        </View>
                    </View>
                </View>
                <View style={[UI.rowCenter, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                    <View style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1, justifyContent: 'center' }}>
                        <Text style={{ color: styles.FIFTH__CONTENT__COLOR }}>{t('number_month', { number: '9' })}</Text>
                    </View>
                    <View style={{ flex: 1 }}>
                        <View>
                            <Text
                                style={{
                                    color:
                                        Number(expectedProfitRatio?.[3]?.c1) < 0
                                            ? styles.DOWN__COLOR
                                            : Number(expectedProfitRatio?.[3]?.c1) > 0
                                            ? styles.UP__COLOR
                                            : styles.PRIMARY__CONTENT__COLOR,
                                    fontSize: fontSizes.verySmall,
                                    textAlign: 'right',
                                }}
                            >
                                {FormatNumber(Number(expectedProfitRatio?.[3]?.c0), 2, 1)}%
                            </Text>
                            <Text
                                style={{
                                    color:
                                        Number(expectedProfitRatio?.[3]?.c1) < 0
                                            ? styles.DOWN__COLOR
                                            : Number(expectedProfitRatio?.[3]?.c1) > 0
                                            ? styles.UP__COLOR
                                            : styles.PRIMARY__CONTENT__COLOR,
                                    fontSize: fontSizes.verySmall,
                                    textAlign: 'right',
                                }}
                            >
                                {FormatNumber(expectedProfitRatio?.[3]?.c1)}
                            </Text>
                        </View>
                    </View>
                </View>
                <View style={[UI.rowCenter, { borderBottomColor: styles.DIVIDER__COLOR }]}>
                    <View style={{ color: styles.FIFTH__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1, justifyContent: 'center' }}>
                        <Text style={{ color: styles.FIFTH__CONTENT__COLOR }}>{t('number_month', { number: '12' })}</Text>
                    </View>
                    <View style={{ flex: 1 }}>
                        <View>
                            <Text
                                style={{
                                    color:
                                        Number(expectedProfitRatio?.[4]?.c1) < 0
                                            ? styles.DOWN__COLOR
                                            : Number(expectedProfitRatio?.[4]?.c1) > 0
                                            ? styles.UP__COLOR
                                            : styles.PRIMARY__CONTENT__COLOR,
                                    fontSize: fontSizes.verySmall,
                                    textAlign: 'right',
                                }}
                            >
                                {FormatNumber(Number(expectedProfitRatio?.[4]?.c0), 2, 1)}%
                            </Text>
                            <Text
                                style={{
                                    color:
                                        Number(expectedProfitRatio?.[4]?.c1) < 0
                                            ? styles.DOWN__COLOR
                                            : Number(expectedProfitRatio?.[4]?.c1) > 0
                                            ? styles.UP__COLOR
                                            : styles.PRIMARY__CONTENT__COLOR,
                                    fontSize: fontSizes.verySmall,
                                    textAlign: 'right',
                                }}
                            >
                                {FormatNumber(expectedProfitRatio?.[4]?.c1)}
                            </Text>
                        </View>
                    </View>
                </View>

                <RowTitleGroup text={t('chart_profit_loss_calculator_by_every_month')} type="group" />
                <View style={{ height: 550 }}>
                    {isLoadingFull ? (
                        <View style={{ alignItems: 'center', justifyContent: 'center' }}>
                            <ActivityIndicator color={styles.PRIMARY} />
                        </View>
                    ) : null}
                    <ChartWebview
                        DATA_AMOUNT={expectedProfitFullObj.DATA_AMOUNT}
                        DATA_CATEGORY={expectedProfitFullObj.DATA_CATEGORY}
                        DATA_RATIO={expectedProfitFullObj.DATA_RATIO}
                        styles={styles}
                        t={t}
                        theme={theme}
                    />
                </View>

                {isDatePickerFrom ? (
                    <Modal
                        hideModalContentWhileAnimating={true}
                        isVisible={isDatePickerFrom}
                        style={UI.bottomModal}
                        useNativeDriver={true}
                        onBackButtonPress={() => setisDatePickerFrom(false)}
                        onBackdropPress={() => setisDatePickerFrom(false)}
                    >
                        <ModalBottomContent title={t('common_from_month')}>
                            <MonthSelectorCalendar
                                containerStyle={[{ backgroundColor: styles.HEADER__BG__COLOR, marginTop: -8 }]}
                                currentDate={moment(fromDt)}
                                currentMonthTextStyle={{ color: styles.PRIMARY, fontSize: fontSizes.medium, fontWeight: fontWeights.bold }}
                                initialView={moment(fromDt)}
                                maxDate={moment(toDt)}
                                monthDisabledStyle={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.medium }}
                                monthTextStyle={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.medium }}
                                nextIcon={<Entypo color={styles.SECOND__CONTENT__COLOR} name="chevron-right" size={28} />}
                                prevIcon={<Entypo color={styles.SECOND__CONTENT__COLOR} name="chevron-left" size={28} />}
                                selectedBackgroundColor={styles.HEADER__BG__COLOR}
                                selectedDate={moment(fromDt)}
                                selectedMonthTextStyle={{ color: styles.PRIMARY, fontSize: fontSizes.medium, fontWeight: fontWeights.bold }}
                                seperatorColor={styles.DIVIDER__COLOR}
                                yearTextStyle={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.medium, fontWeight: fontWeights.bold }}
                                onMonthTapped={(date) => {
                                    setisDatePickerFrom(false)
                                    setFromDt(date)
                                }}
                            />
                        </ModalBottomContent>
                    </Modal>
                ) : null}
                {isDatePickerTo ? (
                    <Modal
                        hideModalContentWhileAnimating={true}
                        isVisible={isDatePickerTo}
                        style={UI.bottomModal}
                        useNativeDriver={true}
                        onBackButtonPress={() => setisDatePickerTo(false)}
                        onBackdropPress={() => setisDatePickerTo(false)}
                    >
                        <ModalBottomContent title={t('common_to_month')}>
                            <MonthSelectorCalendar
                                containerStyle={[{ backgroundColor: styles.HEADER__BG__COLOR, marginTop: -8 }]}
                                currentDate={moment(toDt)}
                                currentMonthTextStyle={{ color: styles.PRIMARY, fontSize: fontSizes.medium, fontWeight: fontWeights.bold }}
                                initialView={moment(toDt)}
                                maxDate={moment(glb_sv.objShareGlb.workDate, 'YYYYMMDD')}
                                minDate={moment(fromDt)}
                                monthDisabledStyle={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.medium }}
                                monthTextStyle={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.medium }}
                                nextIcon={<Entypo color={styles.SECOND__CONTENT__COLOR} name="chevron-right" size={28} />}
                                prevIcon={<Entypo color={styles.SECOND__CONTENT__COLOR} name="chevron-left" size={28} />}
                                selectedBackgroundColor={styles.HEADER__BG__COLOR}
                                selectedDate={moment(toDt)}
                                selectedMonthTextStyle={{ color: styles.PRIMARY, fontSize: fontSizes.medium, fontWeight: fontWeights.bold }}
                                seperatorColor={styles.DIVIDER__COLOR}
                                yearTextStyle={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.medium, fontWeight: fontWeights.bold }}
                                onMonthTapped={(date) => {
                                    setisDatePickerTo(false)
                                    setToDt(date)
                                }}
                            />
                        </ModalBottomContent>
                    </Modal>
                ) : null}

                {/* {isDatePickerFrom && <DateTimePickerModal
                isVisible={isDatePickerFrom}
                mode="date"
                onCancel={hideDatePicker}
                headerTextIOS=''
                cancelTextIOS={t('common_Cancel')}
                confirmTextIOS={t('common_Ok')}
                isDarkModeEnabled={theme.includes('DARK')}
                date={fromDt}
                locale={language === 'VI' ? "vi_VN" : 'en_US'}
                onConfirm={value => {
                    setisDatePickerFrom(false);
                    setFromDt(value);
                    // setIsEditConfig(true)
                }}
            />}


            {isDatePickerTo && <DateTimePickerModal
                isVisible={isDatePickerTo}
                mode="date"
                onCancel={hideDatePicker}
                headerTextIOS=''
                cancelTextIOS={t('common_Cancel')}
                confirmTextIOS={t('common_Ok')}
                isDarkModeEnabled={theme.includes('DARK')}
                date={toDt}
                locale={language === 'VI' ? "vi_VN" : 'en_US'}
                onConfirm={value => {
                    setisDatePickerTo(false);
                    setToDt(value);
                    // setIsEditConfig(true)
                }}
            />} */}
            </View>
        </ScrollView>
    )
}

const UI = StyleSheet.create({
    bottomModal: {
        justifyContent: 'flex-end',
        margin: 0,
    },
    row: {
        borderBottomWidth: 1,
        flexDirection: 'row',
        marginHorizontal: dimensions.moderate(16),
        paddingVertical: dimensions.vertical(9),
    },
    rowCenter: {
        borderBottomWidth: 1,
        display: 'flex',
        flexDirection: 'row',
        marginHorizontal: dimensions.moderate(16),
        paddingVertical: dimensions.vertical(9),
    },
})

export default memo(ProfitLossCalculator)
