import React, { memo, useContext, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { StyleSheet, TouchableOpacity, View } from 'react-native'

import { Text } from '../../../basic-components'
import { allowCompanyRender } from '../../../hoc'
import { StoreContext } from '../../../store'
import { dimensions, fontSizes } from '../../../styles'
import { FormatNumber } from '../../../utils'
import { RowExpandStock } from './RowExpandStock'

const getColor = (value, styles) => {
    if (value > 0) return styles.UP__COLOR
    if (value < 0) return styles.DOWN__COLOR
    if (value === 0) return styles.REF__COLOR
    return styles.PRIMARY__CONTENT__COLOR
}

const getColorMarketPrice = (marketPrice, ce, fl, t31_incr_per, styles) => {
    if (marketPrice >= ce) return styles.CEIL__COLOR
    if (marketPrice <= fl) return styles.FLOOR__COLOR
    if (t31_incr_per > 0) return styles.UP__COLOR
    if (t31_incr_per < 0) return styles.DOWN__COLOR
    if (t31_incr_per == 0) return styles.REF__COLOR
    return styles.PRIMARY__CONTENT__COLOR
}

export const RowAssetsStock = ({ item }) => {
    const { styles } = useContext(StoreContext)
    const [expand, setExpand] = useState(false)

    return (
        <>
            <TouchableOpacity onPress={() => setExpand((prev) => !prev)}>
                <View
                    style={[
                        {
                            borderBottomColor: styles.DIVIDER__COLOR,
                        },
                        UI.Row,
                    ]}
                >
                    <View style={{ justifyContent: 'flex-start', flex: 1.2 }}>
                        <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.verySmall }}>{item.c2}</Text>
                        <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.verySmall }}>
                            {allowCompanyRender(['061']) ? FormatNumber(Number(item.c25)) : FormatNumber(Number(item.c25) + Number(item.c14))}
                        </Text>
                    </View>

                    <View style={{ justifyContent: 'center', alignItems: 'flex-end', flex: 3 }}>
                        <Text style={[UI.Text, { color: styles.PRIMARY__CONTENT__COLOR }]}>{FormatNumber(item.c17)}</Text>
                        <Text
                            style={[UI.Text, { color: getColorMarketPrice(item.c15, Number(item.c21), Number(item.c22), Number(item.t31_incr_per), styles) }]}
                        >
                            {FormatNumber(item.c15)}
                        </Text>
                    </View>

                    <View style={{ justifyContent: 'center', alignItems: 'flex-end', flex: 4 }}>
                        <Text style={[UI.Text, { color: styles.PRIMARY__CONTENT__COLOR }]}>{FormatNumber(item.c18)}</Text>
                        <Text style={[UI.Text, { color: styles.SECOND__CONTENT__COLOR }]}>{FormatNumber(item.c16)}</Text>
                    </View>

                    <View style={{ justifyContent: 'center', alignItems: 'flex-end', flex: 3 }}>
                        <Text style={[UI.Text, { color: getColor(Number(item.c19), styles) }]}>
                            {Number(item.c19) > 0 ? '' : ''}
                            {FormatNumber(item.c19)}
                        </Text>
                        <Text style={[UI.Text, { color: getColor(Number(item.c19), styles) }]}>
                            {Number(item.c19) > 0 ? '' : ''}
                            {Math.round(item.c20 * 100) / 100}%
                        </Text>
                    </View>
                </View>
            </TouchableOpacity>
            {expand ? <RowExpandStock section={item} /> : null}
        </>
    )
}
// export const RowAssetsStock = memo(RowAssetsStockMemo, areEqual)
// ----------
function areEqual(prevProps, nextProps) {
    // console.log('prevProps', prevProps, nextProps)
    console.log('change >>>>>> c20', prevProps.item?.c20, nextProps.item?.c20)
    return false
    if (prevProps.item?.c2 !== nextProps.item?.c2) {
        console.log('change >>>>>> c2', prevProps.item?.c2, nextProps.item?.c2)
        return false
    } else if (prevProps.item?.c25 !== nextProps.item?.c25) {
        console.log('change >>>>>> c25', prevProps.item?.c25, nextProps.item?.c25)
        return false
    } else if (prevProps.item?.c14 !== nextProps.item?.c14) {
        console.log('change >>>>>> c14', prevProps.item?.c14, nextProps.item?.c14)
        return false
    } else if (prevProps.item?.c17 !== nextProps.item?.c17) {
        console.log('change >>>>>> c17', prevProps.item?.c17, nextProps.item?.c17)
        return false
    } else if (prevProps.item?.c15 !== nextProps.item?.c15) {
        console.log('change >>>>>> c15', prevProps.item?.c15, nextProps.item?.c15)
        return false
    } else if (prevProps.item?.c18 !== nextProps.item?.c18) {
        console.log('change >>>>>> c18', prevProps.item?.c18, nextProps.item?.c18)
        return false
    } else if (prevProps.item?.c16 !== nextProps.item?.c16) {
        console.log('change >>>>>> c16', prevProps.item?.c16, nextProps.item?.c16)
        return false
    } else if (prevProps.item?.c19 !== nextProps.item?.c19) {
        console.log('change >>>>>> c19', prevProps.item?.c19, nextProps.item?.c19)
        return false
    } else if (prevProps.item?.c20 !== nextProps.item?.c20) {
        console.log('change >>>>>> c20', prevProps.item?.c20, nextProps.item?.c20)
        return false
    } else {
        console.log('true ???')
        return true
    }
}

const UI = StyleSheet.create({
    Row: {
        borderBottomWidth: 1,
        display: 'flex',
        flexDirection: 'row',
        marginHorizontal: dimensions.moderate(4),
        paddingVertical: dimensions.moderate(4),
    },
    Text: {
        fontSize: fontSizes.verySmall,
        textAlign: 'right',
    },
})
