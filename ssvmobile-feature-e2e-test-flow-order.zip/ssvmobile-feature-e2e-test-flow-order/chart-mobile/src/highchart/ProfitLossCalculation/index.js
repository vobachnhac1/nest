import 'antd/dist/antd.css'
import 'moment/locale/vi'

import React, { PureComponent } from 'react'
import Highcharts from 'highcharts'
import moment from 'moment'

import FormatNumber from '../../formatNumber/FormatNumber'

export default class HighChartsProfitLoss extends PureComponent {
    constructor(props) {
        super(props)
        this.state = {
            DATA_CATEGORY: window.DATA_CATEGORY || [],
            DATA_AMOUNT: window.DATA_AMOUNT || [],
            DATA_RATIO: window.DATA_RATIO || [],
        }
        document.body.classList.add(window.theme)
    }

    componentDidMount() {
        this.chartProfitLoss = Highcharts.chart('chart_profit_loss', {
            title: {
                text: '',
            },
            subtitle: {
                text: '',
            },
            credits: {
                enabled: false,
            },
            xAxis: [
                {
                    categories: this.state.DATA_CATEGORY,
                    reversed: true,
                    crosshair: true,
                },
            ],
            yAxis: [
                {
                    // Giá trị
                    labels: {
                        style: {
                            color: window.UP__COLOR,
                        },
                    },
                    title: {
                        text: '',
                        style: {
                            color: window.UP__COLOR,
                        },
                    },
                },
                {
                    // Tỷ lệ
                    title: {
                        text: '',
                        style: {
                            color: window.REF__COLOR,
                        },
                    },
                    labels: {
                        formatter: function () {
                            return `${FormatNumber(this.value, 2, 1)}%`
                        },
                        style: {
                            color: window.REF__COLOR,
                        },
                    },
                    opposite: true,
                },
            ],
            legend: {
                enabled: true,
                itemStyle: {
                    color: window.PRIMARY__CONTENT__COLOR,
                },
            },
            tooltip: {
                shared: true,
            },
            series: [
                {
                    name: window.value_of_profit_achieved_by_month,
                    type: 'column',
                    yAxis: 0,
                    data: [],
                    color: window.UP__COLOR,
                },
                {
                    name: window.ratio_of_profit_achieved_by_month,
                    type: 'spline',
                    data: [],
                    color: window.REF__COLOR,
                    yAxis: 1,
                    tooltip: {
                        valueSuffix: '%',
                    },
                },
            ],
        })

        this.eventMarket = window.eventMarket.subscribe((msg) => {
            if (msg.type === 'highchart-render' && msg.value === 'dataChartProfitLoss') {
                requestAnimationFrame(() => {
                    const categories = window.DATA_CATEGORY
                    this.chartProfitLoss.xAxis[0].setCategories(categories)
                    this.chartProfitLoss.series[0].setData(window.DATA_AMOUNT)
                    this.chartProfitLoss.series[1].setData(window.DATA_RATIO)
                })
                this.chartProfitLoss.reflow()
            }
        })
    }

    componentWillUnmount() {
        this.eventMarket.unsubscribe()
    }

    render() {
        return (
            <div className="flex flex-direction-column h-100" style={{ color: window.PRIMARY__CONTENT__COLOR, backgroundColor: window.PRIMARY__BG__COLOR }}>
                <div className="flex flex-direction-column">
                    <div id="chart_profit_loss" style={{ height: 350 }} />
                </div>
            </div>
        )
    }
}
