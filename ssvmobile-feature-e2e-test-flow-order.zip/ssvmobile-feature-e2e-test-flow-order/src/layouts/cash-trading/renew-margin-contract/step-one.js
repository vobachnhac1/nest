import React, { useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { FlatList, View } from 'react-native'
import ToastGlobal from 'react-native-toast-message'
import moment from 'moment'

import Account from '../../../components/account'
import { ColTableData, RowTableData, RowTitleGroup } from '../../../components/trading-component'
import EmptyView from '../../../components/trading-component/empty-view'
import HeaderList from '../../../components/trading-component/header-list'
import { StoreTrading } from '../../../store-trading'
import { dimensions as dm, fontSizes as fs } from '../../../styles'
import { eventList, glb_sv, reqFunct, sendRequest } from '../../../utils'
import FormatNumber from '../../../utils/formatNumber/FormatNumber'

// Khai báo ServiceInfo (nếu có)
const ServiceInfo = {
    GET_LIST_CONTRACT_RENEW: {
        reqFunct: reqFunct.GET_LIST_CONTRACT_RENEW,
        WorkerName: 'FOSqMargin',
        ServiceName: 'FOSqMargin_Online_1404',
        Operation: 'Q',
    },
    GET_HIS_PAY_ON_ACCOUT_BY_SUB: {
        reqFunct: reqFunct.GET_HIS_PAY_ON_ACCOUT_BY_SUB,
        WorkerName: 'FOSqCash',
        ServiceName: 'FOSqCash_0201_1',
        Operation: 'Q',
    },
    GET_HIS_PAY_ON_ACCOUT_BY_ACT: {
        reqFunct: reqFunct.GET_HIS_PAY_ON_ACCOUT_BY_ACT,
        WorkerName: 'FOSqCash',
        ServiceName: 'FOSqCash_0201_1',
        Operation: 'Q',
    },
}

// Khai báo component
const StepOne = ({ setContractSelect, switchStep, navigation, refreshing }) => {
    const { userInfo } = useContext(StoreTrading)

    const { t } = useTranslation()

    const [listContractRenew, setListContractRenew] = useState([])

    const colSpan = [1, 1, 1]

    useEffect(() => {
        // Prepare data
        getListContractRenew() // Lấy danh sách hợp đồng gia hạn

        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.LOGIN_SUCCESS) {
                // reCall service FOSq
                getListContractRenew()
            }
        })

        return () => {
            commonEvent.unsubscribe()
        }
    }, [userInfo.sub_curr])
    useEffect(() => {
        if (refreshing) getListContractRenew()
    }, [refreshing])

    // -------------------------------------------   Viết các hàm để set lại bussiness form state. Nên viết đúng một chuẩn duy nhất để dễ control

    // -------------------------------------------   Khai báo các hàm gửi (request) lên server
    const getListContractRenew = () => {
        setListContractRenew([])
        if (!userInfo.actn_curr) {
            ToastGlobal.show({
                type: 'warning',
                text2: t('warning_account_is_empty'),
            })
            return
        }

        const inputParams = [userInfo.actn_curr, userInfo.sub_curr]
        sendRequest(ServiceInfo.GET_LIST_CONTRACT_RENEW, inputParams, handleGetListContractRenew)
    }

    // -------------------------------------------   Khai báo các hàm nhận (handle respone) dữ liệu từ server
    const handleGetListContractRenew = (reqInfoMap, message) => {
        // -- process after get result --
        if (Number(message.Result) === 0) {
            setListContractRenew([])
            ToastGlobal.show({
                type: 'warning',
                text2: message.Message,
            })
            return
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {}
            setListContractRenew(jsondata)
        }
    }

    const ViewLastTransfer = ({ item, index }) => {
        return (
            <RowTableData
                key={index}
                type="table"
                onPress={() => {
                    if (!userInfo.actn_curr) {
                        ToastGlobal.show({
                            type: 'warning',
                            text2: t('warning_account_is_empty'),
                        })
                        return
                    }
                    setContractSelect(item)
                    switchStep.next()
                }}
            >
                <ColTableData colSpan={colSpan[0]} text={moment(item.c3, 'DDMMYYYY').format('DD/MM/YYYY')} />

                <ColTableData colSpan={colSpan[1]} text={moment(item.c4, 'DDMMYYYY').format('DD/MM/YYYY')} textAlign="center" />

                <ColTableData colSpan={colSpan[2]} text={FormatNumber(item.c28, 0, 0)} textAlign="right" />
            </RowTableData>
        )
    }
    return (
        <View>
            <Account navigation={navigation} />

            <RowTitleGroup hasDivider text={t('select_contract')} />
            <HeaderList colSpan={colSpan} typeHeader="RENEW_MARGIN_CONTRACT" />
            <FlatList
                data={listContractRenew}
                keyExtractor={(item, index) => String(index)}
                ListEmptyComponent={EmptyView}
                renderItem={ViewLastTransfer}
                style={{ marginBottom: dm.vertical(32), paddingHorizontal: dm.moderate(16) }}
            />
        </View>
    )
}

export default StepOne
