import React, { memo } from 'react'
import { Image, StyleSheet, View } from 'react-native'
import { Body, Row } from 'native-base'

import CheckMark from '../../assets/images/common/checkmark.svg'
import { dimensions } from '../../styles'
import { eventList, glb_sv, IMAGE, reqFunct, sendRequest, STORE_KEY } from '../../utils'

const AvatarImage = ({ avatar, width = 100, height = 100, resizeMode, resizeMethod, style = {}, isBigger, noTick }) => {
    const avatarUrl = avatar || glb_sv.imageAvatarUrl || glb_sv.userInfo.avatar || ''
    // require('../../assets/images/common/ic_avatar_default.png')
    const getAvatarFromAssets = () => {
        if (glb_sv.configInfo.avatar_default_url) {
            const path = '../../' + glb_sv.configInfo.avatar_default_url
            return require('../../assets/images/avatar/ssv_user_default.png')
        } else {
            return require('../../assets/images/common/ic_avatar_default.png')
        }
    }

    return (
        <View style={{ ...UI.RowInput, ...style }}>
            <Row>
                <Body style={{ position: 'relative' }}>
                    <View style={{ height: height, width: width }}>
                        {avatarUrl ? (
                            <Image
                                resizeMethod={resizeMethod}
                                resizeMode={resizeMode}
                                source={{ uri: avatarUrl }}
                                style={{
                                    height,
                                    width,
                                    // flex: 1,
                                    borderRadius: 100,
                                }}
                            />
                        ) : (
                            <Image
                                resizeMethod={resizeMethod}
                                resizeMode={resizeMode}
                                source={getAvatarFromAssets()}
                                style={{
                                    height,
                                    width,
                                    // flex: 1,
                                    borderRadius: 100,
                                }}
                            />
                        )}
                        {!noTick ? (
                            <CheckMark height={isBigger ? 30 : 20} style={{ position: 'absolute', bottom: -2, right: -5 }} width={isBigger ? 30 : 20} />
                        ) : null}
                    </View>
                </Body>
            </Row>
        </View>
    )
}

const UI = StyleSheet.create({
    RowInput: {
        borderRadius: 12,
        marginBottom: dimensions.vertical(8),
        marginHorizontal: dimensions.moderate(10),
    },
})

export default memo(AvatarImage)
