import { COLORS } from '@mts-styles/colors'

import { useCustomTheme } from '../theme'

export const useThemeColors = () => {
    const customTheme = useCustomTheme()

    const activeTheme = customTheme.theme

    return {
        theme: customTheme.theme,
        isDark: customTheme.isDark || activeTheme === 'dark',
        colors: COLORS[activeTheme],
    }
}
