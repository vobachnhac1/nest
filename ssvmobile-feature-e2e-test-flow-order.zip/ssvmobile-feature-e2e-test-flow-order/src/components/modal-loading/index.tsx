import React, { memo, useContext, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { ActivityIndicator, StyleSheet, View } from 'react-native'
import Modal from 'react-native-modal'
import ToastGlobal from 'react-native-toast-message'

import { Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { dimensions, fontSizes } from '../../styles'

interface IModalLoading {
    visible: boolean
    content: string
    showTimeoutMessage?: boolean
    maxVisibleLoading?: number
    setLoading: (loadingState: boolean) => void
}

const MAX_VISIBLE_LOADING_TIME = 20000
// ---------------------------
const ModalLoading = ({
    visible,
    content,
    showTimeoutMessage = true,
    maxVisibleLoading = MAX_VISIBLE_LOADING_TIME,
    setLoading = (loadingState = false) => null,
}: IModalLoading) => {
    const [isVisible, setIsVisible] = useState(false)
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()
    // --------------
    useEffect(() => {
        setIsVisible(visible)
        const maxVisible = setTimeout(() => {
            setIsVisible(false)
            setLoading(false)
            if (showTimeoutMessage) {
                ToastGlobal.show({
                    text2: t('processing_failed_please_check_and_try_again'),
                    type: 'warning',
                })
            }
        }, maxVisibleLoading)

        return () => {
            clearTimeout(maxVisible)
        }
    }, [visible])
    //---------------
    return (
        <Modal hideModalContentWhileAnimating={true} isVisible={isVisible} useNativeDriver={true}>
            <View style={[UI.View, { backgroundColor: styles.HEADER__BG__COLOR }]}>
                <ActivityIndicator color={styles.PRIMARY} />
                <Text style={[UI.Text, { color: styles.PRIMARY__CONTENT__COLOR }]}>{content}</Text>
            </View>
        </Modal>
    )
}

export default memo(ModalLoading)

const UI = StyleSheet.create({
    Text: {
        fontSize: fontSizes.medium,
        paddingLeft: dimensions.moderate(8),
    },
    View: {
        borderColor: 'rgba(0, 0, 0, 0.1)',
        borderRadius: 4,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        paddingHorizontal: dimensions.moderate(24),
        paddingVertical: dimensions.moderate(24),
    },
})
