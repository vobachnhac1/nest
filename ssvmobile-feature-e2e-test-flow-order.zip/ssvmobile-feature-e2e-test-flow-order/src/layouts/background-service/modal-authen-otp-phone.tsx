import React, { memo, useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { ActivityIndicator, InteractionManager, Keyboard, NativeModules, Platform, Pressable, StyleSheet, View } from 'react-native'
import Modal from 'react-native-modal'
import AntDesign from 'react-native-vector-icons/AntDesign'
import useSafeModalState, { GLOBAL_MODAL_KEY } from '@mts-hooks/useSafeModalState'
import moment from 'moment'
import { Button, Icon } from 'native-base'

import { Text, TextInput } from '../../basic-components'
import { StoreContext } from '../../store'
import { dimensions, fontSizes, fontWeights, IconSvg } from '../../styles'
import { IOS } from '../../styles/helper/dimensions'
import { dataCryption, eventList, glb_sv, reqFunct, sendRequest, socket_sv, STORE_KEY } from '../../utils'

const ServiceInfo: { [key: string]: ISserviceInfo } = {
    CHECK_PHONE_OTP: {
        reqFunct: reqFunct.CHECK_PHONE_OTP,
        WorkerName: 'FOSxID01',
        ServiceName: 'FOSxID01_Management',
        ClientSentTime: '0',
        Operation: 'I',
    },
    SEND_OTP_FUNCTION: {
        reqFunct: reqFunct.SEND_OTP_FUNCTION,
        WorkerName: 'FOSxID01',
        ServiceName: 'FOSxID01_OTPManagement',
        Operation: 'U',
        ClientSentTime: '0',
    },
}

function ModalAuthenOTP() {
    const { t } = useTranslation()
    const { styles, masterModalState } = useContext(StoreContext)

    const [code, setCode] = useState('')
    const [timeOTP, setTimeOTP] = useState(0)
    const timeOTPRef = useRef<any>(0)

    const [phone, setPhone] = useState<string>('')

    const flag_sendAuthenOTP = useRef<any>(null)

    const otpRef = useRef<any>(null)

    const timeoutTimingOTP = useRef<any>(null)

    const [error, setError] = useState('')

    const [loading, setLoading] = useState(false)
    const [visible, setVisible] = useSafeModalState(GLOBAL_MODAL_KEY.ModalAuthenOTP)

    const [isShowOtp, setShowOTP] = useState(false)

    useEffect(() => {
        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.CHECK_PHONE_OTP) {
                checkPhone()
            }
        })
        return () => {
            commonEvent.unsubscribe()
            if (timeoutTimingOTP.current) clearTimeout(timeoutTimingOTP.current)
        }
    }, [])

    const checkPhone = () => {
        const InputParams = ['chkphone', phone.length > 9 ? phone : '']
        sendRequest(ServiceInfo.CHECK_PHONE_OTP, InputParams, checkPhoneResult, true, checkPhoneTimeout)
        setError('')
    }

    const checkPhoneTimeout = () => {
        console.log('checkPhoneTimeout')
    }

    const checkPhoneResult = (reqInfoMap, message) => {
        console.log('checkPhoneResult -> message', message)
        setVisible(true)
        if (Number(message.Result) === 0) {
            setError(message.Message)
        } else {
            let jsondata: IServiceResponeData = {}
            try {
                if (message.Data) {
                    jsondata = JSON.parse(message.Data)[0]
                }
            } catch (err) {
                console.error('resendAuthenOTPResult error', err)
                return
            }
            if (jsondata.c0) {
                setPhone(jsondata.c0)
                setTimeOTP(Number(jsondata.c1))
                setCode('')
                timeOTPRef.current = Number(jsondata.c1)
                glb_sv.timeAuthenOtp = {
                    timeGetOTP: moment(),
                    numberOTP: timeOTPRef.current,
                }
                timingOTP()
                otpRef.current?.focus()
                setShowOTP(true)
            }
        }
    }

    const timingOTP = () => {
        if (timeOTPRef.current > 0) {
            if (timeoutTimingOTP.current) clearTimeout(timeoutTimingOTP.current)
            timeoutTimingOTP.current = setTimeout(() => {
                // @ts-expect-error
                const remainTimeOTP = Math.max(0, glb_sv.timeAuthenOtp.numberOTP - Math.round((moment() - glb_sv.timeAuthenOtp.timeGetOTP) / 1000))
                timeOTPRef.current = remainTimeOTP
                setTimeOTP(remainTimeOTP)
                timingOTP()
            }, 1000)
        }
    }

    const sendAuthenOTP = (value) => {
        if (flag_sendAuthenOTP.current) return
        const codeEncryt = dataCryption.encryptString(value || code)
        const InputParams = ['confirm_phone', codeEncryt]
        sendRequest(ServiceInfo.SEND_OTP_FUNCTION, InputParams, sendAuthenOTPResult, true, sendAuthenOTPResultTimeout)
        flag_sendAuthenOTP.current = true
        setLoading(true)
    }

    const sendAuthenOTPResultTimeout = () => {
        console.log('sendAuthenOTPResultTimeout')
        flag_sendAuthenOTP.current = false
        setLoading(false)
    }

    const sendAuthenOTPResult = (reqInfoMap, message) => {
        console.log('sendAuthenOTPResult -> message', message)
        flag_sendAuthenOTP.current = false
        setLoading(false)
        if (Number(message.Result) === 0) {
            setError(message.Message)
            otpRef.current && otpRef.current.focus()
            if (message.Code === '010013') {
                if (timeoutTimingOTP.current) clearTimeout(timeoutTimingOTP.current)
                setTimeOTP(0)
                timeOTPRef.current = 0
            }
        } else {
            if (timeoutTimingOTP.current) clearTimeout(timeoutTimingOTP.current)
            setVisible(false)
            Keyboard.dismiss()
            InteractionManager.runAfterInteractions(() => {
                setTimeout(() => {
                    // @ts-expect-error
                    glb_sv.openEkyc(IOS, NativeModules, glb_sv.navigation, styles, true)
                }, 200)
            })
        }
    }

    const validateInput = () => {
        if (!code) return false
        if (!phone || phone.length < 10) return false
        if (!timeOTP) return false
        return true
    }

    const hideModal = () => {
        if (timeoutTimingOTP.current) clearTimeout(timeoutTimingOTP.current)
        setVisible(false)
        setPhone('')
        setShowOTP(false)
        return
    }

    if (!visible) return null

    return (
        <Modal
            isVisible={visible}
            useNativeDriver={true}
            avoidKeyboard
            // onBackdropPress={hideModal}
            onBackButtonPress={hideModal}>
            <View
                style={{
                    backgroundColor: styles.PRIMARY__BG__COLOR,
                    paddingHorizontal: dimensions.moderate(16),
                    paddingTop: dimensions.vertical(16),
                    paddingBottom: dimensions.vertical(12),
                    justifyContent: 'center',
                    alignItems: 'center',
                    borderRadius: 12,
                    borderColor: 'rgba(0, 0, 0, 0.1)',
                }}
            >
                <IconSvg.CodeIcon />
                <Text
                    style={{
                        fontSize: fontSizes.xmedium,
                        color: styles.PRIMARY__CONTENT__COLOR,
                        marginTop: dimensions.vertical(16),
                        marginBottom: dimensions.vertical(16),
                    }}
                >
                    {t<string>('title_authen_phone')}
                </Text>

                <Text style={{ fontSize: fontSizes.verySmall, color: styles.ERROR__COLOR }}>{error}</Text>

                <View style={[UI.row, { backgroundColor: styles.INPUT__BG__LOGIN, paddingVertical: dimensions.vertical(12) }]}>
                    <TextInput
                        // @ts-expect-error
                        autoCapitalize="none"
                        keyboardType="number-pad"
                        maxLength={10}
                        placeholder={t('enter_phone_register')}
                        placeholderTextColor={styles.SECOND__CONTENT__COLOR}
                        returnKeyType="next"
                        style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal, flex: 1 }}
                        textContentType="telephoneNumber"
                        value={phone}
                        onChangeText={(value) => {
                            setPhone(value.trim())
                            setError('')
                            setTimeOTP(0)
                            setCode('')
                            timeOTPRef.current = 0
                            if (timeoutTimingOTP.current) clearTimeout(timeoutTimingOTP.current)
                            setShowOTP(false)
                        }}
                        onSubmitEditing={() => otpRef.current && otpRef.current.focus()}
                    />
                    <Pressable
                        hitSlop={20}
                        onPress={() => {
                            setPhone('')
                            setTimeOTP(0)
                            setCode('')
                            setError('')
                            setShowOTP(false)
                            timeOTPRef.current = 0
                            if (timeoutTimingOTP.current) clearTimeout(timeoutTimingOTP.current)
                        }}
                    >
                        <AntDesign color={styles.PRIMARY__CONTENT__COLOR} name="closecircle" size={16} />
                    </Pressable>
                </View>

                <View style={[UI.row, { backgroundColor: styles.INPUT__BG__LOGIN, paddingVertical: dimensions.vertical(12), opacity: isShowOtp ? 1 : 0 }]}>
                    <TextInput
                        // @ts-expect-error
                        autoFocus={timeOTP > 0}
                        editable={timeOTP > 0}
                        keyboardType="number-pad"
                        maxLength={6}
                        placeholder={t('otp_text_placeholder')}
                        placeholderTextColor={styles.SECOND__CONTENT__COLOR}
                        ref={otpRef}
                        secureTextEntry
                        style={{ ...UI.codeInput, color: styles.PRIMARY__CONTENT__COLOR, padding: 0 }}
                        textContentType="oneTimeCode"
                        value={code}
                        onChangeText={(value) => {
                            setCode(value)
                            setError('')
                            if (value.length === 6) {
                                sendAuthenOTP(value)
                            }
                        }}
                        onSubmitEditing={sendAuthenOTP}
                    />
                    <View style={{ position: 'absolute', top: dimensions.vertical(16), right: dimensions.halfIndent }}>
                        <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.normal, padding: 0 }}>{timeOTP}s</Text>
                    </View>
                </View>

                <Text
                    style={{
                        fontSize: fontSizes.normal,
                        fontWeight: '700',
                        color: styles.PRIMARY,
                        textAlign: 'center',
                        paddingVertical: 12,
                        opacity: timeOTP ? 0 : phone.length > 9 ? 1 : 0,
                    }}
                    onPress={checkPhone}
                >
                    {t<string>('send_code_otp')}
                </Text>

                <Button
                    disabled={!validateInput()}
                    style={{ backgroundColor: !validateInput() ? styles.PRIMARY + '4d' : styles.PRIMARY, borderRadius: 8 }}
                    transparent
                    block
                    // @ts-expect-error
                    onPress={sendAuthenOTP}
                >
                    {loading ? (
                        <View style={{ flexDirection: 'row' }}>
                            <ActivityIndicator color={'#FFF'} />
                            <Text style={{ color: '#FFF', fontSize: fontSizes.medium, fontWeight: fontWeights.medium }}>...</Text>
                        </View>
                    ) : (
                        <Text
                            style={{
                                color: !validateInput() ? styles.SECOND__CONTENT__COLOR : '#FFF',
                                fontSize: fontSizes.medium,
                                fontWeight: fontWeights.medium,
                            }}
                        >
                            {t<string>('authen')}
                        </Text>
                    )}
                </Button>

                <Button block transparent onPress={hideModal}>
                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.medium, opacity: 0.34 }}>{t<string>('common_Cancel')}</Text>
                </Button>
            </View>
        </Modal>
    )
}
export default memo(ModalAuthenOTP)

const UI = StyleSheet.create({
    codeInput: {
        flex: 1,
        fontSize: fontSizes.normal,
        fontWeight: fontWeights.bold,
    },
    row: {
        borderRadius: 200,
        flexDirection: 'row',
        marginTop: 10,
        paddingHorizontal: dimensions.halfIndent,
    },
    tab: {
        fontSize: fontSizes.small,
        fontWeight: fontWeights.medium,
        marginLeft: 0,
        marginRight: 0,
    },
})

function validateEmailRegex(email) {
    const re =
        /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    return re.test(String(email).toLowerCase())
}
