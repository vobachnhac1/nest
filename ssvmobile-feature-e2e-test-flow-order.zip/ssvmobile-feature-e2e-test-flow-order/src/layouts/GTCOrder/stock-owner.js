import React, { memo, useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { View } from 'react-native'
import { Content, Row } from 'native-base'

import { Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { dimensions } from '../../styles'
import { FormatNumber } from '../../utils'

function StockOwner({ sellStkList, changeStock }) {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()

    const StockItem = ({ item }) => {
        return (
            <View style={{ paddingVertical: dimensions.halfIndent }}>
                <Row
                    style={{ borderBottomColor: styles.DIVIDER__COLOR, justifyContent: 'space-between', flexDirection: 'row' }}
                    onPress={() => changeStock(item.c0, 'sell')}
                >
                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, flex: 0.7 }}>{item.c0}</Text>
                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, textAlign: 'right', flex: 1 }}>{FormatNumber(item.c3, 0, 0)}</Text>
                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, textAlign: 'right', flex: 1 }}>{FormatNumber(item.c8, 0, 1)}</Text>
                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, textAlign: 'right', flex: 1 }}>{FormatNumber(item.c2, 0, 1)}</Text>
                </Row>
            </View>
        )
    }

    return (
        <Content scrollEnabled={false} style={{ paddingHorizontal: dimensions.halfIndent, backgroundColor: styles.PRIMARY__BG__COLOR }}>
            <Row style={{ justifyContent: 'space-between', marginHorizontal: 0, borderBottomWidth: 0, paddingVertical: dimensions.halfIndent / 2 }}>
                <Text style={{ color: styles.HEADER__CONTENT__COLOR, flex: 0.7 }}>{t('stock_symbol_short')}</Text>
                <Text style={{ color: styles.HEADER__CONTENT__COLOR, flex: 1, textAlign: 'right' }}>{t('sell_able_quantity')}</Text>
                <Text style={{ color: styles.HEADER__CONTENT__COLOR, flex: 1, textAlign: 'right' }}>{t('qty_custody')}</Text>
                <Text style={{ color: styles.HEADER__CONTENT__COLOR, flex: 1, textAlign: 'right' }}>{t('qty_owner')}</Text>
            </Row>
            {sellStkList.map((item) => (
                <StockItem item={item} key={item.c0} />
            ))}
        </Content>
    )
}

export default memo(StockOwner, areEqual)

function areEqual(prev, next) {
    if (prev.sellStkList === next.sellStkList) return true
    return false
}
