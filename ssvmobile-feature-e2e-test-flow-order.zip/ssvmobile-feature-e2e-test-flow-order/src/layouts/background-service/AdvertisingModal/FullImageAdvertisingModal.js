// import React, { memo, useContext, useEffect, useState } from 'react'
// import { ActivityIndicator, StyleSheet, View, ImageBackground } from 'react-native'
// import Modal from 'react-native-modal'
// import { Text } from '../../../basic-components'
// import { StoreContext } from '../../../store'
// import { dimensions, fontSizes, IconSvg } from '../../../styles'
// import ToastGlobal from 'react-native-toast-message'
// import { useTranslation } from 'react-i18next'
// import Icon from 'react-native-vector-icons/MaterialIcons'
// import { TouchableOpacity } from 'react-native-gesture-handler'

// // ---------------------------
// const FullImageAdvertisingModal = ({ visible, content, callbackOnClose, callbackOnClick }) => {
//     const [isVisible, setIsVisible] = useState(false)
//     const { styles } = useContext(StoreContext)
//     const { t } = useTranslation()
//     const [checkBoxDontAskAgain, setCheckBoxDontAskAgain] = useState(false)

//     // --------------
//     useEffect(() => {}, [])
//     const onClose = () => {
//         setIsVisible(false)
//         if (typeof callbackOnClose === 'function') {
//             callbackOnClose()
//         }
//     }
//     const backgroundImageLink =
//         'https://video.fsgn8-2.fna.fbcdn.net/v/t1.6435-9/143246888_3660982480624389_380826607096838152_n.jpg?_nc_cat=105&ccb=1-7&_nc_sid=730e14&_nc_ohc=2GDPpqUZeLEAX_flJ5q&_nc_ht=video.fsgn8-2.fna&oh=00_AT-IdIFYKc1WJT_oSE4XT-Kffl0lhvC4ZzbruGLInXDFCg&oe=62D01E17'

//     //---------------
//     return (
//         <Modal isVisible={isVisible} useNativeDriver={true} hideModalContentWhileAnimating={true} style={UI.modal}>
//             <View style={[UI.View, { backgroundColor: styles.HEADER__BG__COLOR }]}>
//                 <ImageBackground source={{ uri: backgroundImageLink }} resizeMode="cover" style={UI.imageBackground}></ImageBackground>
//                 <View style={[UI.circleClose, { borderColor: styles.ICON__PRIMARY, backgroundColor: styles.HEADER__BG__COLOR }]}>
//                     <TouchableOpacity onPress={onClose}>
//                         <Icon name="close" size={16} color={styles.ICON__PRIMARY} />
//                     </TouchableOpacity>
//                 </View>
//                 <View style={[UI.dontAskAgain, { backgroundColor: styles.HEADER__BG__COLOR }]}>
//                     <View>
//                         <IconSvg.CheckboxIcon active={checkBoxDontAskAgain} colorActive={styles.PRIMARY} colorunActive={styles.PRIMARY__CONTENT__COLOR} />
//                     </View>
//                     <View>
//                         <TouchableOpacity onPress={() => setCheckBoxDontAskAgain(!checkBoxDontAskAgain)}>
//                             <Text
//                                 style={{
//                                     fontSize: fontSizes.small,
//                                     color: styles.PRIMARY__CONTENT__COLOR,
//                                     marginLeft: dimensions.moderate(8),
//                                     marginRight: 16,
//                                 }}>
//                                 {t('dont_show_again')}
//                             </Text>
//                         </TouchableOpacity>
//                     </View>
//                 </View>
//             </View>
//         </Modal>
//     )
// }

// export default memo(FullImageAdvertisingModal)

// const UI = StyleSheet.create({
//     View: {
//         justifyContent: 'flex-start',
//         flexDirection: 'row',
//         borderRadius: 8,
//         borderColor: 'rgba(0, 0, 0, 0.1)',
//         aspectRatio: 0.618,
//         position: 'relative',
//         shadowColor: '#fff',
//         shadowOffset: { width: 6, height: 6 },
//         shadowOpacity: 0.5,
//         shadowRadius: 5,
//         elevation: 20,
//     },
//     Text: {
//         fontSize: fontSizes.medium,
//         paddingLeft: dimensions.moderate(8),
//     },
//     modal: {
//         margin: dimensions.moderate(32),
//     },
//     circleClose: {
//         borderWidth: 1,
//         padding: 2,
//         borderRadius: 40,
//         position: 'absolute',
//         top: -8,
//         right: -8,
//     },
//     imageBackground: {
//         flex: 1,
//         justifyContent: 'center',
//         borderRadius: 8,
//         overflow: 'hidden',
//     },
//     dontAskAgain: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', position: 'absolute', bottom: 8, left: 8, zIndex: 5000, borderRadius: 4, padding: 2 },
// })
