import React, { PureComponent } from 'react'
import { Animated, InteractionManager, StyleSheet } from 'react-native'
import { RectButton, Swipeable } from 'react-native-gesture-handler'
import Icon from 'react-native-vector-icons/MaterialIcons'

const AnimatedIcon = Animated.createAnimatedComponent(Icon)

export default class GmailStyleSwipeableRow extends PureComponent {
    renderRightActions = (progress, dragX) => {
        return (
            <RectButton style={styles.rightAction} onPress={this.close}>
                <AnimatedIcon color="#fff" name="delete-forever" size={30} style={[styles.actionIcon]} />
            </RectButton>
        )
    }
    updateRef = (ref) => {
        this._swipeableRow = ref
    }
    close = () => {
        this._swipeableRow && this._swipeableRow.close()
    }

    onSwipeableRightOpen = () => {
        this.props.onRemoveStock(this.props.t55)
        setTimeout(() => {
            this.close()
        }, 1000)
    }

    render() {
        const { children } = this.props
        return (
            <Swipeable
                containerStyle={{
                    marginVertical: 10,
                }}
                friction={1}
                ref={this.updateRef}
                renderRightActions={this.renderRightActions}
                rightThreshold={80}
                onSwipeableRightOpen={this.onSwipeableRightOpen}
            >
                {children}
            </Swipeable>
        )
    }
}

const styles = StyleSheet.create({
    actionIcon: {
        marginHorizontal: 10,
        width: 30,
    },
    rightAction: {
        alignItems: 'center',
        backgroundColor: '#dd2c00',
        flexDirection: 'row',
        flex: 1,
        justifyContent: 'flex-end',
    },
})
