import React from 'react'
import { StyleSheet, Text, View } from 'react-native'
import { KeyboardAwareScrollView } from '@codler/react-native-keyboard-aware-scroll-view'
import EkycButton from '@mts-layouts/eKYCFPT/components/EkycButton'
import { RegisterOtherInfomation } from '@mts-layouts/eKYCFPT/components/RegisterOtherInformation'
import { fontSizes, fontWeights } from '@mts-styles/index'

export const AdditionInfoStep1 = ({ styles, onChangeOtherInformation, loadingRegister, switchStep, t, loading }) => {
    return (
        <View style={UI.styleContainer(styles)}>
            <KeyboardAwareScrollView enableOnAndroid={false} extraScrollHeight={100}>
                <View>
                    <Text style={{ textAlign: 'center', color: styles.PRIMARY, fontSize: fontSizes.xmedium, fontWeight: fontWeights.bold }}>
                        {t('extend_service_title_1').toUpperCase()}
                    </Text>
                    <RegisterOtherInfomation onChangeOtherInformation={onChangeOtherInformation} />
                </View>
            </KeyboardAwareScrollView>
            <View style={{ flexDirection: 'row', paddingHorizontal: 16, marginBottom: 24 }}>
                <EkycButton
                    customStyle={{ flex: 1, marginEnd: 16 }}
                    text={t('common_button_previous')}
                    onPress={() => switchStep.prev({ step: 2, subStep: 3 })}
                />
                <EkycButton
                    customStyle={{ flex: 1 }}
                    isLoading={loading || loadingRegister}
                    text={t('common_button_next')}
                    onPress={() => switchStep.next({ step: 3, subStep: 1 })}
                />
            </View>
        </View>
    )
}

const UI = StyleSheet.create({
    styleContainer: (styles) => ({
        backgroundColor: styles.PRIMARY__BG__COLOR,
        flex: 1,
    }),
})
