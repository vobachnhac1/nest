import React, { memo, useContext, useEffect, useRef } from 'react'
import { useTranslation } from 'react-i18next'
import { StyleSheet, View } from 'react-native'

import { StoreContext } from '../../../store'
import { dimensions } from '../../../styles'
import { eventList, glb_sv, subcribeFunct } from '../../../utils'
import ChartForeignerTrade from './webview'

const getKeyExchange = (value) => {
    if (value.includes('HNXUpcomIndex')) {
        return 'UPC'
    } else if (value.includes('HNX')) {
        return 'HNX'
    } else {
        return 'HSX'
    }
}

function ForeignerTrade({ active, height }) {
    const { theme } = useContext(StoreContext)
    const { t } = useTranslation()
    const isSub = useRef(true)

    useEffect(() => {
        let exchange = 'HSX'
        if (active.includes('HNXUpcomIndex')) {
            exchange = 'UPC'
            subcribeFunct(null, null, 'SUB', ['FRG_BUY_UP', 'FRG_SELL_UP'], [exchange])
        } else if (active.includes('HNX')) {
            exchange = 'HNX'
            subcribeFunct(null, null, 'SUB', ['FRG_BUY_UP', 'FRG_SELL_UP'], [exchange])
        } else {
            exchange = 'HSX'
            subcribeFunct(null, null, 'SUB', ['FRG_BUY_UP', 'FRG_SELL_UP'], [exchange])
        }

        const eventMarket = glb_sv.eventMarket.subscribe((msg) => {
            if (msg.type === eventList.FOCUS_MARKET) {
                if (msg.value === true && !isSub.current) {
                    isSub.current = true
                    if (active.includes('HNXUpcomIndex')) {
                        subcribeFunct(null, null, 'SUB', ['FRG_BUY_UP', 'FRG_SELL_UP'], [exchange])
                    } else if (active.includes('HNX')) {
                        subcribeFunct(null, null, 'SUB', ['FRG_BUY_UP', 'FRG_SELL_UP'], [exchange])
                    } else {
                        subcribeFunct(null, null, 'SUB', ['FRG_BUY_UP', 'FRG_SELL_UP'], [exchange])
                    }
                }
                if (msg.value === false && isSub.current) {
                    isSub.current = false
                    if (active.includes('HNXUpcomIndex')) {
                        subcribeFunct(null, null, 'UNSUB', ['FRG_BUY_UP', 'FRG_SELL_UP'], [exchange])
                    } else if (active.includes('HNX')) {
                        subcribeFunct(null, null, 'UNSUB', ['FRG_BUY_UP', 'FRG_SELL_UP'], [exchange])
                    } else {
                        subcribeFunct(null, null, 'UNSUB', ['FRG_BUY_UP', 'FRG_SELL_UP'], [exchange])
                    }
                }
            }
        })

        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.REQ_GET_MKT_INF_FIRST) {
                isSub.current = true
                if (active.includes('HNXUpcomIndex')) {
                    subcribeFunct(null, null, 'SUB', ['FRG_BUY_UP', 'FRG_SELL_UP'], [exchange])
                } else if (active.includes('HNX')) {
                    subcribeFunct(null, null, 'SUB', ['FRG_BUY_UP', 'FRG_SELL_UP'], [exchange])
                } else {
                    subcribeFunct(null, null, 'SUB', ['FRG_BUY_UP', 'FRG_SELL_UP'], [exchange])
                }
            }
        })

        return () => {
            eventMarket.unsubscribe()
            commonEvent.unsubscribe()
            subcribeFunct(null, null, 'UNSUB', ['FRG_BUY_UP', 'FRG_SELL_UP'], [exchange])
        }
    }, [active])

    const exchangeState = getKeyExchange(active)

    return (
        <View style={UI.view}>
            <ChartForeignerTrade exchange={exchangeState} height={height} t={t} theme={theme} />
        </View>
    )
}

const UI = StyleSheet.create({
    view: {
        height: dimensions.IOS ? dimensions.HIEGHT - 230 : dimensions.HIEGHT - 170,
        width: dimensions.WIDTH,
    },
})

export default memo(ForeignerTrade)
