import React, { Component, createRef } from 'react'
import { Platform, StyleSheet } from 'react-native'
import WebView from 'react-native-webview'

import { glb_sv } from '../../../../utils'

const source = Platform.select({
    ios: require('../../../../basic-components/custom-chart/index.html'),
    android: { uri: 'file:///android_asset/index.html' },
})

// export default memo(WebviewChart)
export default class WebviewChart extends Component {
    constructor(props) {
        super(props)

        this.chartRef = createRef()

        this.state = {
            webviewKey: new Date().getTime(),
        }
    }

    componentDidMount() {
        if (this.chartRef) {
            this.chartRef.current.injectJavaScript(`
            window.DataLiquity = ${this.props.dataChart};
            setTimeout(() => {
                if (window.eventMarket) {
                    window.eventMarket.next({ type: 'highchart-liquity' })
                    window.title_liquidity_trading_value = '${this.props.t('title_liquidity_trading_value')} ${this.props.exchangeTitle}';
                    window.avg_5days_trading_value = '${this.props.t('avg_5days_trading_value')}  ${this.props.exchangeTitle}';
                    window.common_daily = '${this.props.t('common_daily')}  ${this.props.exchangeTitle}';
                }
            }, 300);
            true;
        `)
            this.chartRef.current.injectJavaScript(`
            window.DataLiquity5day = ${this.props.dataChartAvg5day};
            setTimeout(() => {
                if (window.eventMarket) {
                    window.eventMarket.next({ type: 'highchart-liquity-avg-5days' })
                    window.title_liquidity_trading_value = '${this.props.t('title_liquidity_trading_value')} ${this.props.exchangeTitle}';
                    window.avg_5days_trading_value = '${this.props.t('avg_5days_trading_value')}  ${this.props.exchangeTitle}';
                    window.common_daily = '${this.props.t('common_daily')}  ${this.props.exchangeTitle}';

                }
            }, 500);
            true;
        `)
            // if ( this.props.t) {
            this.chartRef.current &&
                this.chartRef.current.injectJavaScript(`
                    window.hist_ord_dt_time = '${this.props.t('hist_ord_dt_time')}';
                    window.title_liquidity_trading_value = '${this.props.t('title_liquidity_trading_value')} ${this.props.exchangeTitle}';
                    window.avg_5days_trading_value = '${this.props.t('avg_5days_trading_value')}  ${this.props.exchangeTitle}';
                    window.common_daily = '${this.props.t('common_daily')}  ${this.props.exchangeTitle}';
                    window.unit_billions = '${this.props.t('unit_billions')}';
                if (window.eventMarket) {
                    window.eventMarket.next({ type: 'change-language' })
                }
                true;
            `)
            // }
        }
    }

    componentWillReceiveProps(nextProps) {
        if (this.chartRef) {
            this.chartRef.current.injectJavaScript(`
            window.DataLiquity = ${nextProps.dataChart};
            setTimeout(() => {
                if (window.eventMarket) {
                    window.eventMarket.next({ type: 'highchart-liquity' })
                    window.title_liquidity_trading_value = '${this.props.t('title_liquidity_trading_value')} ${this.props.exchangeTitle}';
                    window.avg_5days_trading_value = '${this.props.t('avg_5days_trading_value')}  ${this.props.exchangeTitle}';
                    window.common_daily = '${this.props.t('common_daily')}  ${this.props.exchangeTitle}';
                }
            }, 300);
            true;
        `)
            this.chartRef.current.injectJavaScript(`
            window.DataLiquity5day = ${nextProps.dataChartAvg5day};
            setTimeout(() => {
                if (window.eventMarket) {
                    window.eventMarket.next({ type: 'highchart-liquity-avg-5days' })
                    window.title_liquidity_trading_value = '${this.props.t('title_liquidity_trading_value')} ${this.props.exchangeTitle}';
                    window.avg_5days_trading_value = '${this.props.t('avg_5days_trading_value')}  ${this.props.exchangeTitle}';
                    window.common_daily = '${this.props.t('common_daily')}  ${this.props.exchangeTitle}';

                }
            }, 500);
            true;
        `)
            if (nextProps.t !== this.props.t) {
                this.chartRef.current &&
                    this.chartRef.current.injectJavaScript(`
                    window.hist_ord_dt_time = '${this.props.t('hist_ord_dt_time')}';
                    window.title_liquidity_trading_value = '${this.props.t('title_liquidity_trading_value')} ${this.props.exchangeTitle}';
                    window.avg_5days_trading_value = '${this.props.t('avg_5days_trading_value')}  ${this.props.exchangeTitle}';
                    window.common_daily = '${this.props.t('common_daily')}  ${this.props.exchangeTitle}';
                    window.unit_billions = '${this.props.t('unit_billions')}';
                if (window.eventMarket) {
                    window.eventMarket.next({ type: 'change-language' })
                }
                true;
            `)
            }
        }
    }

    shouldComponentUpdate(nextProps, nextState) {
        if (nextState.webviewKey !== this.state.webviewKey) {
            return true
        }
        return false
    }
    reload = () => {
        this.setState({
            webviewKey: this.state.webviewKey + 1,
        })
    }

    render() {
        return (
            <WebView
                allowUniversalAccessFromFileURLs={true}
                androidLayerType="hardware"
                domStorageEnabled={true}
                injectedJavaScriptBeforeContentLoaded={`
                    new Date().toLocaleString();
                    window.theme = '${this.props.theme}';
                    window.colorsTheme = ${this.props.colorsTheme};
                    window.chartName = 'market_liquity';
                    window.DataLiquity = [];
                    window.timeServer = ${glb_sv.timeServer};
                    
                    window.title_liquidity_trading_value = '${this.props.t('title_liquidity_trading_value')}';
                    window.avg_5days_trading_value = '${this.props.t('avg_5days_trading_value')}';
                    window.hist_ord_dt_time = '${this.props.t('hist_ord_dt_time')}';
                    window.common_daily = '${this.props.t('common_daily')}';
                    window.unit_billions = '${this.props.t('unit_billions')}';
                `}
                source={source}
                // source={{
                //     uri: 'http://192.168.1.6:3000' || 'http://localhost:3000/',
                // }}
                javaScriptEnabled
                key={this.state.webviewKey}
                originWhitelist={['*']}
                ref={this.chartRef}
                scrollEnabled={false}
                style={UI.webView}
                onContentProcessDidTerminate={this.reload}
            />
        )
    }
}
// window.colorsTheme = ${this.props.colorsTheme};

const UI = StyleSheet.create({
    webView: {
        backgroundColor: 'transparent',
        flex: 1,
    },
})
