import React, { memo, useEffect, useRef, useState } from 'react'
import { InteractionManager } from 'react-native'
import { Defs, LinearGradient, Stop } from 'react-native-svg'
import maxBy from 'lodash/maxBy'
import minBy from 'lodash/minBy'
import moment from 'moment'
import { VictoryArea, VictoryAxis, VictoryChart, VictoryLine } from 'victory-native'

import { useCustomInteraction } from '../../../hoc'
import { eventList, glb_sv } from '../../../utils'

const initData = [
    {
        x: 1601370904,
        y: 1,
        y0: 0,
    },
    {
        x: 1601370964,
        y: 1,
        y0: 0,
    },
]

function SparklinesChart({ stockCode, width, height, styles }) {
    useCustomInteraction()
    const [configData, setConfigData] = useState({
        chartData: [], // initData
        colorChart: styles.REF__COLOR,
        refLineData: [],
    })

    const dataIntraday = useRef([])
    const lastData = useRef(null)
    const mounted = useRef(true)
    const [isRender, setIsRender] = useState(false)
    const firstLoad = useRef(true)

    useEffect(() => {
        const eventMarket = glb_sv.eventMarket.subscribe((msg) => {
            if (msg.type === eventList.GET_DATA_EP_CHART_DONE && msg.msgKey === stockCode) {
                const data = glb_sv.StockMarket[stockCode] ? glb_sv.StockMarket[stockCode].arrMinutes : []
                if (!data.length) return

                if (dataIntraday.current && dataIntraday.current.length < 300 && dataIntraday.current.length >= data.length) return

                dataIntraday.current = [...data]
                lastData.current = data[data.length - 1]
                if (glb_sv.StockMarket[stockCode].t260 === 0) return
                convert2chartVictory([...dataIntraday.current], mounted.current, setConfigData, styles)
            }
            if (msg.type === eventList.REQ_AFTER_SUB_INFO) {
                if (msg.value.includes(stockCode)) {
                    convert2chartVictory([...dataIntraday.current], mounted.current, setConfigData, styles)
                }
            }
            if (msg.type === eventList.MKT_INTRADAY && msg.S === stockCode) {
                if (lastData.current && lastData.current.T === msg.T) {
                    return
                }
                const value = {
                    ...msg,
                    time: moment(glb_sv.timeServer + '-' + msg.T, 'YYYYMMDD-HH:mm:ss').valueOf(),
                }
                lastData.current = { ...value }
                dataIntraday.current.push({
                    ...value,
                })
                InteractionManager.runAfterInteractions(() => {
                    convert2chartVictory([...dataIntraday.current], mounted.current, setConfigData, styles)
                })
            }
            if (msg.type === eventList.RESET_DATA) {
                lastData.current = null
                dataIntraday.current = []
                convert2chartVictory([], mounted.current, setConfigData, styles)
            }
        })
        const data = glb_sv.StockMarket[stockCode] ? glb_sv.StockMarket[stockCode].arrMinutes : []
        if (data.length) {
            dataIntraday.current = [...data]
            lastData.current = data[data.length - 1]
            convert2chartVictory([...dataIntraday.current], mounted.current, setConfigData, styles)
        }

        return () => {
            mounted.current = false
            eventMarket.unsubscribe()
        }
    }, [styles])

    const getColorChart = (lastItem, style) => {
        if (!lastItem) return style.REF__COLOR
        const glb_stock_data = glb_sv.StockMarket[stockCode]
        if (!glb_stock_data) return style.REF__COLOR
        const { t31 } = glb_sv.StockMarket[stockCode]
        return glb_sv.getColor(t31, glb_stock_data, style)
    }

    const convert2chartVictory = (arr, isMounted, setData, style) => {
        'worklet'
        const victoryDataChart = []
        const config = {}
        // set data cho chart
        const minValue =
            minBy(arr, function (o) {
                return o.C
            }) || {}
        const maxValue =
            maxBy(arr, function (o) {
                return o.C
            }) || {}

        let value_y0 = minValue.C - (maxValue.C - minValue.C) / 4
        if (minValue.C === maxValue.C) value_y0 = minValue.C * 0.95
        for (let index = 0; index < arr.length; index++) {
            victoryDataChart.push({
                x: arr[index].time,
                y: arr[index].C,
                y0: value_y0,
            })
        }
        // ----------------

        const { t260 = 0 } = glb_sv.StockMarket[stockCode] || {}
        // ----------------

        if (victoryDataChart.length <= 1) {
            if (victoryDataChart.length === 1) {
                config.chartData = [...victoryDataChart, { ...victoryDataChart[0], x: victoryDataChart[0].x + 1000 }]
                config.refLineData = [
                    { x: victoryDataChart[0].x, y: t260 },
                    { x: victoryDataChart[0].x + 1000, y: t260 },
                ]
                config.colorChart = getColorChart(arr[0], style)
            } else {
                config.chartData = [] // initData
                config.refLineData = []
            }
            InteractionManager.runAfterInteractions(() => {
                if (mounted.current)
                    setData({
                        ...config,
                    })
            })
            setTimeout(() => {
                if (firstLoad.current) {
                    firstLoad.current = false
                    return
                }
                if (mounted.current) {
                    setIsRender(true)
                }
            }, 1000)
            return
        } else {
            config.chartData = victoryDataChart
        }
        // set màu cho chart
        const tempt = [...arr]
        const lastItem = tempt.pop()
        const firstItem = tempt.shift()
        const colorCharts = getColorChart(lastItem, style)
        config.colorChart = colorCharts
        // set basic info cho chart

        const firstTime = firstItem.time
        const lastTime = lastItem.time

        config.refLineData = [
            { x: firstTime, y: t260 },
            { x: lastTime, y: t260 },
        ]
        InteractionManager.runAfterInteractions(() => {
            if (mounted.current)
                setData({
                    ...config,
                })
        })
        if (mounted.current) {
            setIsRender(true)
        }
    }

    return (
        <>
            {isRender ? (
                <VictoryChart height={height || 40} padding={0} width={width || 85}>
                    <VictoryAxis
                        style={{
                            axis: { stroke: 'transparent' },
                            ticks: { stroke: 'transparent' },
                            tickLabels: { fill: 'transparent' },
                        }}
                    />
                    <Defs>
                        <LinearGradient id="gradientStroke" x1="0%" x2="0%" y1="0%" y2="100%">
                            <Stop offset="0%" stopColor={configData.colorChart || styles.REF__COLOR} stopOpacity="0.2" />
                            <Stop offset="100%" stopColor={configData.colorChart || styles.REF__COLOR} stopOpacity="0" />
                        </LinearGradient>
                    </Defs>

                    <VictoryArea
                        data={configData.chartData || []}
                        style={{
                            data: {
                                fill: 'url(#gradientStroke)',
                                stroke: `${configData.colorChart || styles.REF__COLOR}`,
                                strokeWidth: 1,
                            },
                        }}
                    />
                    <VictoryLine
                        data={configData.refLineData}
                        style={{
                            data: { stroke: styles.HEADER__CONTENT__COLOR, strokeWidth: 0.5, strokeDasharray: '3,5' },
                        }}
                    />
                </VictoryChart>
            ) : null}
        </>
    )
}

export default memo(SparklinesChart)
