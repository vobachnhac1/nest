const { spawn, exec } = require('child_process')
const fs = require('fs')
const { name } = require('../../package.json')

const _changeConfig = (typeApp, appVersion, buildNumber) => {
    /**
     * 1. Đổi seccode
     * 2. Đổi môi trường build
     */

    fs.readFile('./src/assets/config.ts', 'utf8', (err, configRawText) => {
        const regexCompany = /activeCode = (Company.(.*)|'[0-9][0-9][0-9]')/g
        // --------------
        console.log('>>>>>> APP_VERSION:', appVersion)
        console.log('>>>>>> APP_BUILD_NUMBER:', buildNumber)

        if (typeApp === 'uat') {
            const regexSeccode = /ENV = '(CONFIG_PRODUCTION|CONFIG_TEST)'/g
            const regexVersion = /APP_VERSION = ('\d{1,3}\.\d{1,3}\.\d{1,3}')/g
            const regexBuildNumber = /APP_BUILD_NUMBER = ('\d{8,8}\.\d{4,4}')/g
            const newConfigContent = configRawText
                .replace(regexSeccode, `ENV = 'CONFIG_TEST'`)
                .replace(regexCompany, `activeCode = '081'`)
                .replace(regexVersion, `APP_VERSION = '3.99.10'`)
                .replace(regexBuildNumber, `APP_BUILD_NUMBER = '${buildNumber}'`)
            fs.writeFileSync('./src/assets/config.ts', newConfigContent)
            console.log('>>>>>> Môi trường build: CONFIG_TEST')
        } else if (typeApp === 'p' || typeApp === 'prod') {
            const regexSeccode = /ENV = '(CONFIG_PRODUCTION|CONFIG_TEST)'/g
            const regexVersion = /APP_VERSION = ('\d{1,3}\.\d{1,3}\.\d{1,3}')/g
            const regexBuildNumber = /APP_BUILD_NUMBER = ('\d{8,8}\.\d{4,4}')/g
            const newConfigContent = configRawText
                .replace(regexSeccode, `ENV = 'CONFIG_PRODUCTION'`)
                .replace(regexCompany, `activeCode = '081'`)
                .replace(regexVersion, `APP_VERSION = '${appVersion}'`)
                .replace(regexBuildNumber, `APP_BUILD_NUMBER = '${buildNumber}'`)
            fs.writeFileSync('./src/assets/config.ts', newConfigContent)
            console.log('>>>>>> Môi trường build: CONFIG_PRODUCTION')
        }
    })

    return
}

const _changeVersionPackageJson = (appVersion) => {
    console.log('>>>>>> [Change] appVersion for PackageJson: ', appVersion)
    fs.readFile('./package.json', 'utf8', (err, configRawText) => {
        const versionRegex = /"version": ("\d{1,3}\.\d{1,3}\.\d{1,3}"),/g
        const newConfigContent = configRawText.replace(versionRegex, `"version": "${appVersion}",`)
        fs.writeFileSync('./package.json', newConfigContent)
    })

    console.log('>>>>>> [Done] appVersion for PackageJson: ', appVersion)
    return
}
const _changeAndroidConfig = (appVersion) => {
    console.log('>>>>>> [Change] appVersion for Android: ', appVersion)
    fs.readFile('./android/app/build.gradle', 'utf8', (err, configRawText) => {
        const versionRegex = /versionName ("\d{1,3}\.\d{1,3}\.\d{1,3}")/g
        const newConfigContent = configRawText.replace(versionRegex, `versionName "${appVersion}"`)
        fs.writeFileSync('./android/app/build.gradle', newConfigContent)
    })
    console.log('>>>>>> [Done] appVersion for Android: ', appVersion)
    return
}
const _changeIOSConfig = (appVersion) => {
    console.log('>>>>>> [Change] appVersion for IOS: ', name, appVersion)
    fs.readFile(`./ios/${name}.xcodeproj/project.pbxproj`, 'utf8', (err, configRawText) => {
        const versionRegex = /MARKETING_VERSION = (\d{1,3}\.\d{1,3}\.\d{1,3})/g
        const newConfigContent = configRawText.replace(versionRegex, `MARKETING_VERSION = ${appVersion}`)
        fs.writeFileSync(`./ios/${name}.xcodeproj/project.pbxproj`, newConfigContent)
    })
    console.log('>>>>>> [Done] appVersion for IOS: ', name, appVersion)
    return
}

module.exports = {
    _changeConfig,
    _changeVersionPackageJson,
    _changeAndroidConfig,
    _changeIOSConfig,
}
