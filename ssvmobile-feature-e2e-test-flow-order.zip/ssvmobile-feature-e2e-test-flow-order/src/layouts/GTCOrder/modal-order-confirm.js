import React, { memo, useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { View } from 'react-native'
import Modal from 'react-native-modal'

import { Text, TextInput } from '../../basic-components'
import { ButtonCustom, ModalContent, RowDataModal } from '../../components/trading-component'
import { StoreContext } from '../../store'
import { StoreTrading } from '../../store-trading'
import { dimensions, fontSizes, IconSvg } from '../../styles'
import { FormatNumber, glb_sv } from '../../utils'

function ModalOrderConfirm({
    modalOrderCfm,
    confirmOrder,
    sellbuy_tp,
    orderTp,
    nameSessionTp,
    from_dt,
    to_dt,
    price,
    qty,
    stockCode,
    passTrading,
    setPassTrading,
    isGTCOrder,
}) {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()
    const { userInfo } = useContext(StoreTrading)

    const translateOrderTp = (value) => {
        if (value === '01') {
            return 'LO'
        } else if (value === '02') {
            return 'MP'
        } else if (value === '03') {
            return 'ATO'
        } else if (value === '04') {
            return 'ATC'
        } else if (value === '06') {
            return 'MOK'
        } else if (value === '07') {
            return 'MAK'
        } else if (value === '08') {
            return 'MTL'
        } else if (value === '15') {
            return 'PLO'
        }
    }

    return (
        <Modal isVisible={modalOrderCfm} useNativeDriver={true} onBackButtonPress={() => confirmOrder('N')} onBackdropPress={() => confirmOrder('N')}>
            <ModalContent
                iconComponent={<IconSvg.CartIcon color={sellbuy_tp === 'buy' ? styles.UP__COLOR : styles.DOWN__COLOR} />}
                title={
                    !isGTCOrder
                        ? sellbuy_tp === 'buy'
                            ? t('screen_confirm_advOrder_order_buy')
                            : t('screen_confirm_advOrder_order_sell')
                        : sellbuy_tp === 'buy'
                        ? t('screen_confirm_gtc_order_buy')
                        : t('screen_confirm_gtc_order_sell')
                }
                type={sellbuy_tp === 'buy' ? 'confirm' : 'sell'}
            >
                <RowDataModal dataSub={[userInfo.actn_curr, userInfo.sub_curr]} textLeft={t('acnt_no')} />
                <RowDataModal textLeft={t('short_symbol')} textRight={stockCode} />
                <RowDataModal textLeft={t('order_tp')} textRight={translateOrderTp(orderTp)} />
                <RowDataModal textLeft={t('qty')} textRight={FormatNumber(qty)} />
                {orderTp === '01' ? (
                    <RowDataModal textLeft={t('price')} textRight={orderTp === '01' ? FormatNumber(price) : translateOrderTp(orderTp)} />
                ) : null}
                {orderTp === '01' ? <RowDataModal textLeft={t('trading_amt')} textRight={FormatNumber(price * qty)} /> : null}
                <RowDataModal textLeft={t('effect_date')} textRight={from_dt} />
                <RowDataModal last textLeft={t('expire_date')} textRight={to_dt} />
                {!glb_sv.isInvestorUser() ? (
                    <View style={{ flexDirection: 'row', paddingVertical: dimensions.moderate(8) }}>
                        <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('password_trading')}</Text>

                        <View style={{ borderBottomColor: styles.PRIMARY__BORDER__COLOR, borderBottomWidth: 1, flex: 1 }}>
                            <TextInput
                                maxLength={6}
                                secureTextEntry
                                style={{
                                    fontSize: fontSizes.medium,
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                }}
                                value={passTrading}
                                onChangeText={(value) => {
                                    setPassTrading(value)
                                }}
                            />
                        </View>
                    </View>
                ) : null}
                <ButtonCustom text={t('common_Ok')} type={sellbuy_tp === 'buy' ? 'buy' : 'sell'} onPress={() => confirmOrder('Y')} />
                <ButtonCustom last text={t('common_Cancel')} type="back" onPress={() => confirmOrder('N')} />
            </ModalContent>
            {/* <View
                style={{
                    backgroundColor: styles.HEADER__BG__COLOR,
                    paddingHorizontal: 20,
                    paddingTop: 32,
                    paddingBottom: 8,
                    justifyContent: 'flex-start',
                    borderRadius: 4,
                    borderColor: 'rgba(0, 0, 0, 0.1)',
                }}> */}
            {/* <View style={{ alignItems: 'center' }}>
                    <IconSvg.CartIcon color={sellbuy_tp === 'buy' ? styles.UP__COLOR : styles.DOWN__COLOR} />
                </View> */}
            {/* <Text
                    style={{
                        marginVertical: 22,
                        fontSize: fontSizes.xmedium,
                        textAlign: 'center',
                        fontWeight: fontWeights.semiBold,
                        color: sellbuy_tp === 'buy' ? styles.UP__COLOR : styles.DOWN__COLOR,
                    }}>
                    {!isGTCOrder
                        ? sellbuy_tp === 'buy'
                            ? t('screen_confirm_advOrder_order_buy')
                            : t('screen_confirm_advOrder_order_sell')
                        : sellbuy_tp === 'buy'
                        ? t('screen_confirm_gtc_order_buy')
                        : t('screen_confirm_gtc_order_sell')}
                </Text> */}

            {/* <AccountModal /> */}

            {/* <View style={{ flexDirection: 'row', paddingVertical: dimensions.moderate(8) }}>
                    <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('short_symbol')}</Text>
                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal, flex: 1 }}>{stockCode}</Text>
                </View> */}

            {/* <View style={{ flexDirection: 'row', paddingVertical: dimensions.moderate(8) }}>
                    <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('order_tp')}</Text>
                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal, flex: 1 }}>{translateOrderTp(orderTp)}</Text>
                </View> */}

            {/* <View style={{ flexDirection: 'row', paddingVertical: dimensions.moderate(8) }}>
                    <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('qty')}</Text>
                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal, flex: 1 }}>{FormatNumber(qty)}</Text>
                </View> */}
            {/* {orderTp === '01' ? (
                    <View style={{ flexDirection: 'row', paddingVertical: dimensions.moderate(8) }}>
                        <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('price')}</Text>
                        <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal, flex: 1 }}>
                            {orderTp === '01' ? FormatNumber(price) : translateOrderTp(orderTp)}
                        </Text>
                    </View>
                ) : null} */}
            {/* {orderTp === '01' ? (
                    <View style={{ flexDirection: 'row', paddingVertical: dimensions.moderate(8) }}>
                        <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('trading_amt')}</Text>
                        <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal, flex: 1 }}>{FormatNumber(price * qty)}</Text>
                    </View>
                ) : null} */}
            {/* <View style={{ flexDirection: 'row', paddingVertical: dimensions.moderate(8) }}>
                    <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('effect_date')}</Text>
                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal, flex: 1 }}>{from_dt}</Text>
                </View>
                <View style={{ flexDirection: 'row', paddingVertical: dimensions.moderate(8) }}>
                    <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('expire_date')}</Text>
                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal, flex: 1 }}>{to_dt}</Text>
                </View> */}

            {/* {!glb_sv.isInvestorUser() ? (
                    <View style={{ flexDirection: 'row', paddingVertical: dimensions.moderate(8) }}>
                        <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('password_trading')}</Text>

                        <View style={{ borderBottomColor: styles.PRIMARY__BORDER__COLOR, borderBottomWidth: 1, flex: 1 }}>
                            <TextInput
                                value={passTrading}
                                onChangeText={(value) => {
                                    setPassTrading(value)
                                }}
                                secureTextEntry
                                maxLength={6}
                                style={{
                                    fontSize: fontSizes.medium,
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                }}
                            />
                        </View>
                    </View>
                ) : null} */}

            {/* <Button
                    onPress={() => confirmOrder('Y')}
                    transparent
                    block
                    style={{
                        backgroundColor: sellbuy_tp === 'buy' ? styles.UP__COLOR : styles.DOWN__COLOR,
                        justifyContent: 'center',
                        alignSelf: 'center',
                        marginTop: dimensions.vertical(25),
                        borderRadius: 8,
                        width: '100%',
                    }}>
                    <Text style={{ color: '#FFF', fontSize: fontSizes.small }}>{t('common_Ok')}</Text>
                </Button>
                <Button transparent block onPress={() => confirmOrder('N')} style={{ justifyContent: 'center', alignSelf: 'center', width: '100%' }}>
                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small, opacity: 0.34 }}>{t('common_Cancel')}</Text>
                </Button> */}
            {/* </View> */}
        </Modal>
    )
}

export default memo(ModalOrderConfirm)
