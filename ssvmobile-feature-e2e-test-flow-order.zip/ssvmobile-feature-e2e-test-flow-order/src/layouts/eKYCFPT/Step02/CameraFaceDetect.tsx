import React, { forwardRef, useContext, useEffect, useImperativeHandle, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Image, InteractionManager, PermissionsAndroid, Platform, ScrollView, StyleSheet, Text, View } from 'react-native'
import { RNCamera } from 'react-native-camera'
import Modal from 'react-native-modal'
import Svg, { ClipPath, Defs, Ellipse, Rect } from 'react-native-svg'
import Analytics, { EkycAnalyticEvents } from '@mts-utils/TrackingData/Analytics'

import EKYC_NOTE_01 from '../../../assets/images/common/formal_clothes.png'
import EKYC_NOTE_03 from '../../../assets/images/common/no_mask.png'
import EKYC_NOTE_02 from '../../../assets/images/common/no_sunglasses.png'
import ModalLoading from '../../../components/modal-loading'
import { ButtonCustom, ModalContent } from '../../../components/trading-component'
import { StoreContext } from '../../../store'
import { dimensions, fontSizes, fontWeights } from '../../../styles'
import { WIDTH } from '../../../styles/helper/dimensions'
import { glb_sv } from '../../../utils'
import CircularProgress from '../components/CircleProgressIndicator'
import EkycButton from '../components/EkycButton'
import { GuideIconAnimation } from '../components/GuideIconAnimation'
import { HintMessageUIView } from '../components/HintMessageUIView'
import ekycService from '../ekycService'
import { useCountdownPercent } from '../hooks/useCountdownPercent'
import { useHintMessage } from '../hooks/useHintMessage'
import { apiFPT, createFormData, fetchTimeout } from '../middleProcess'

const IS_DEBUG = false
const CAMERA_HEIGHT = 400
const FRAME_DETECTION = {
    width: 240,
    height: 300,
    center: {
        y: CAMERA_HEIGHT / 2 - 300 / 2,
        x: WIDTH / 2 - 240 / 2,
    },
    cameraHeight: CAMERA_HEIGHT,
}
const ZINDEX_LAYER = {
    OVERLAY: 1000,
    PROGRESS: 1100,
    HINT: 1200,
    LOADING: 1300,
    DEBUG_POINT: 1400,
}

const LENGHT_VIDEO = 6000 // miliseconds
const MAX_VIDEO_SIZE = 9 * 1024 * 1024 // byte

const NUMBER_OF_DETECT_FRONT_SUCCESS = Platform.select({ ios: 0, android: 5, default: 3 })
const NUMBER_OF_DETECT_SUCCESS_SMILE_LEFT_RIGHT = Platform.select({ ios: 0, android: 5, default: 1 })

const checkFrame = (face: Face, showHint: any) => {
    if (face) {
        const leftEarPosition = face.leftEarPosition || { x: 0, y: 0 }
        const rightEarPosition = face.rightEarPosition || { x: 0, y: 0 }
        const bottomMouthPosition = face.bottomMouthPosition || { x: 0, y: 0 }
        const rightEyePosition = face.rightEyePosition || { x: 0, y: 0 }

        const leftOK = leftEarPosition.x > WIDTH / 2 - FRAME_DETECTION.width / 2 // Tai trái nằm trong frame
        const rightOK = rightEarPosition.x < WIDTH / 2 + FRAME_DETECTION.width / 2 // Tai phải nằm trong frame
        const bottomOK = bottomMouthPosition.x < FRAME_DETECTION.cameraHeight / 2 + FRAME_DETECTION.height / 2 // Miệng nằm trong frame
        const topOK = rightEyePosition.x > FRAME_DETECTION.cameraHeight / 2 - FRAME_DETECTION.height / 2 // Mắt nằm trong frame

        const distanceOK = checkTooFar(face, showHint)

        // warning
        if (!leftOK || !rightOK || !bottomOK || !topOK || !distanceOK) {
            if (distanceOK) {
                showHint('put_your_face_in_frame')
            } else {
                showHint('move_the_camera_closer')
            }
        }
        if (leftOK && rightOK && bottomOK && topOK && distanceOK) {
            showHint('ok_keep_it_a_bit')
            return true
        }
    }
    return false
}
const checkFaceRight = (face: Face, showHint: any) => {
    // if (face) {
    //     const leftEarPosition = face.leftEarPosition || { x: 0, y: 0 }
    //     const rightEarPosition = face.rightEarPosition || { x: 0, y: 0 }
    //     const bottomMouthPosition = face.bottomMouthPosition || { x: 0, y: 0 }
    //     const rightEyePosition = face.rightEyePosition || { x: 0, y: 0 }
    //     const noseBasePosition = face.noseBasePosition || { x: 0, y: 0 }

    //     const leftOK = leftEarPosition.x > WIDTH / 2 - FRAME_DETECTION.width / 2 // Tai trái nằm trong frame
    //     const rightOK = rightEarPosition.x < WIDTH / 2 + FRAME_DETECTION.width / 2 // Tai phải nằm trong frame
    //     const bottomOK = bottomMouthPosition.x < FRAME_DETECTION.cameraHeight / 2 + FRAME_DETECTION.height / 2 // Miệng nằm trong frame
    //     const topOK = rightEyePosition.x > FRAME_DETECTION.cameraHeight / 2 - FRAME_DETECTION.height / 2 // Mắt nằm trong frame

    //     // FRAME_DETECTION.width / 6 : Một phần 6 độ rộng
    //     const noseRightOK = noseBasePosition.x > WIDTH / 2 + FRAME_DETECTION.width / 6 // Mũi nằm nửa bên phải
    //     // warning
    //     if (!leftOK || !rightOK || !bottomOK || !topOK || !noseRightOK) {
    //         if (noseRightOK) {
    //             showHint('put_your_face_in_frame')
    //         } else {
    //             showHint('turn_face_to_right')
    //         }
    //     }

    //     if (leftOK && rightOK && bottomOK && topOK && noseRightOK) {
    //         showHint('ok_keep_it_a_bit')
    //         return true
    //     }
    // }
    // return false
    return true
}
const checkFaceLeft = (face: Face, showHint: any) => {
    // if (face) {
    //     const leftEarPosition = face.leftEarPosition || { x: 0, y: 0 }
    //     const rightEarPosition = face.rightEarPosition || { x: 0, y: 0 }
    //     const bottomMouthPosition = face.bottomMouthPosition || { x: 0, y: 0 }
    //     const rightEyePosition = face.rightEyePosition || { x: 0, y: 0 }
    //     const noseBasePosition = face.noseBasePosition || { x: 0, y: 0 }

    //     const leftOK = leftEarPosition.x > WIDTH / 2 - FRAME_DETECTION.width / 2 // Tai trái nằm trong frame
    //     const rightOK = rightEarPosition.x < WIDTH / 2 + FRAME_DETECTION.width / 2 // Tai phải nằm trong frame
    //     const bottomOK = bottomMouthPosition.x < FRAME_DETECTION.cameraHeight / 2 + FRAME_DETECTION.height / 2 // Miệng nằm trong frame
    //     const topOK = rightEyePosition.x > FRAME_DETECTION.cameraHeight / 2 - FRAME_DETECTION.height / 2 // Mắt nằm trong frame

    //     // FRAME_DETECTION.width / 6 : Một phần 6 độ rộng
    //     const noseRightOK = noseBasePosition.x < WIDTH / 2 - FRAME_DETECTION.width / 6 // Mũi nằm nửa bên trái
    //     if (!leftOK || !rightOK || !bottomOK || !topOK || !noseRightOK) {
    //         if (noseRightOK) {
    //             showHint('put_your_face_in_frame')
    //         } else {
    //             showHint('turn_face_to_left')
    //         }
    //     }
    //     if (leftOK && rightOK && bottomOK && topOK && noseRightOK) {
    //         showHint('ok_keep_it_a_bit')
    //         return true
    //     }
    // }
    // return false
    return true
}

const checkSmile = (face: Face, showHint: any) => {
    if (face) {
        const leftEarPosition = face.leftEarPosition || { x: 0, y: 0 }
        const rightEarPosition = face.rightEarPosition || { x: 0, y: 0 }
        const bottomMouthPosition = face.bottomMouthPosition || { x: 0, y: 0 }
        const rightEyePosition = face.rightEyePosition || { x: 0, y: 0 }
        const noseBasePosition = face.noseBasePosition || { x: 0, y: 0 }

        const leftOK = leftEarPosition.x > WIDTH / 2 - FRAME_DETECTION.width / 2 // Tai trái nằm trong frame
        const rightOK = rightEarPosition.x < WIDTH / 2 + FRAME_DETECTION.width / 2 // Tai phải nằm trong frame
        const bottomOK = bottomMouthPosition.x < FRAME_DETECTION.cameraHeight / 2 + FRAME_DETECTION.height / 2 // Miệng nằm trong frame
        const topOK = rightEyePosition.x > FRAME_DETECTION.cameraHeight / 2 - FRAME_DETECTION.height / 2 // Mắt nằm trong frame

        const SmileOK = face?.smilingProbability > 0.5 // Cười
        if (!leftOK || !rightOK || !bottomOK || !topOK || !SmileOK) {
            if (SmileOK) {
                showHint('put_your_face_in_frame')
            } else {
                showHint('please_smile')
            }
        }
        if (leftOK && rightOK && bottomOK && topOK && SmileOK) {
            showHint('keep_face_in_3s')
            return true
        }
    }
    return false
}

const checkTooFar = (face: Face, showHint: any) => {
    // false nếu quá xa
    // true nếu khoảng cách hợp lý
    // Kiểm tra khoảng cách giữa 2 tai so với khoảng cách khung hình
    // Kiểm tra khoảng cách các điểm theo chiều dọc
    if (face) {
        const leftEarPosition = face.leftEarPosition || { x: 0, y: 0 }
        const rightEarPosition = face.rightEarPosition || { x: 0, y: 0 }
        const bottomMouthPosition = face.bottomMouthPosition || { x: 0, y: 0 }
        const rightEyePosition = face.rightEyePosition || { x: 0, y: 0 }

        const distance = Math.abs(leftEarPosition.x - rightEarPosition.x) // Khoảng cách 2 tai phải lớn hơn 53% chiều rộng tối đa cần kiểm tra: Đảm bảo user không nghiêng đầu khi quét khuôn mặt
        const verticalDistance = Math.abs(rightEyePosition.y - bottomMouthPosition.y) // Khoảng cách giữa mắt và miệng phải lớn hơn 23% chiều cao tối đa: Đảm báo user nhìn thẳng, không phải nhìn từ dưới lên hoặc từ trên xuống
        if (distance < FRAME_DETECTION.width * 0.5 || verticalDistance < FRAME_DETECTION.height * 0.2) {
            return false
        }
    }

    return true
}

const FACE_DETECT_STATUS = [
    {
        status: 0,
        message: 'invalid_face_position',
        hint: 'please_smile',
    },
    {
        status: 1,
        message: 'turn_face_right_success',
        hint: 'please_smile',
    },
    {
        status: 2,
        message: 'turn_face_left_success',
        hint: 'put_your_face_in_frame',
    },
    {
        status: 3,
        message: 'face_position_success',
        hint: 'please_smile',
    },
    {
        status: 4,
        message: 'smiling_success',
        hint: 'keep_face_in_3s',
    },
]
interface ICamreraFaceDetection {
    onProcessUploaded: (dataObject: object) => void
    switchStep: ISwitchStep
    activeStep: number
    subActiveStep: number
    forceRender: () => void
    onClearAllDataAndStartAgain: () => void
    isClearDataAndStartFromBegin: boolean
}
interface IFileCameraOuput {
    uri: string
}

export const CamreraFaceDetection = forwardRef(({ switchStep, subActiveStep, onProcessUploaded, activeStep, forceRender }: ICamreraFaceDetection, ref) => {
    useImperativeHandle(ref, () => ({
        resetDataScanFace() {
            handleReAuthenFaceID()
        },
    }))
    // @ts-ignore
    const { t } = useTranslation()
    const { styles } = useContext(StoreContext)

    const cameraRef = useRef<{ takePictureAsync: Function; recordAsync: Function }>(null)
    const [matchCount, setMatchCount] = useState(0)
    const [matchFaceLeftCount, setMatchFaceLeftCount] = useState(0)
    const [matchFaceRightCount, setMatchFaceRightCount] = useState(0)
    const [faceSmileCount, setFaceSmileCount] = useState(0)
    const [statusFaceDetection, setStatusFaceDetection] = useState(FACE_DETECT_STATUS[0])
    const [isRecording, setIsRecording] = useState(false)

    // ----------
    const [frontFace, setFrontFace] = useState({})
    // ---------
    const [isShowHint, messageHint, showHint] = useHintMessage()

    const videoInfoRef = useRef<object>({})
    const [fileVideoInfo, setFileVideoInfo] = useState<object>({})
    const [uploaded, setUploaded] = useState<any>(null)
    const [listMessage, setListMessage] = useState<string[]>([])
    const [loading, setLoading] = useState<boolean>(false)
    // const [loadingModal, setLoadingModal] = useState(false);
    const [isShowNote, setIsShowNote] = useState(false)

    const [ascPercent, descPercent, startCountDown, resetCounter] = useCountdownPercent()
    const percentInsecond = Math.round((descPercent * LENGHT_VIDEO) / (100 * 1000))

    const [alertModal, setAlertModal] = useState(false)

    const [guidanceModel, setGuidanceModel] = useState(true)

    useEffect(() => {
        if (activeStep === 2) {
            setIsShowNote(false)
        }
    }, [activeStep])

    useEffect(() => {
        if (activeStep === 1 && subActiveStep === 2) {
            setMatchCount(0)
            setMatchFaceLeftCount(0)
            setMatchFaceRightCount(0)
            setFaceSmileCount(0)
            setStatusFaceDetection(FACE_DETECT_STATUS[0])
            setIsRecording(false)
            setFrontFace({})
            setUploaded(false)
            setListMessage([])
            setLoading(false)
        }
    }, [activeStep, subActiveStep])

    useEffect(() => {
        // Có lỗi thì popup lỗi lên
        if (listMessage.length > 0) {
            setAlertModal(true)
            Analytics.logEvent(EkycAnalyticEvents.ekyc_step_two_verify_face_error)
            glb_sv.sendEKYCLogNewTracking({
                sEKYCLog: EkycAnalyticEvents.ekyc_step_two_verify_face_error,
                eKYCType: '4',
                reason: 'Verify face bị lỗi',
                ekycStep: '2',
            })
        } else {
            setAlertModal(false)
        }
    }, [listMessage])

    const startUseCameraAction = async (step: 'take_front_face' | 'record_video', type = 'photo') => {
        const options = { quality: 0.5, base64: true }
        let picture = {
            uri: '',
        }
        if (type === 'photo') {
            const iosOptions = { quality: 0.5, base64: false, width: 2000, mute: true }
            const androidOptions = { quality: 0.7, base64: false }
            picture = await cameraRef.current?.takePictureAsync(Platform.OS === 'ios' ? iosOptions : androidOptions)
        } else if (type === 'video') {
            setIsRecording(true)
            startCountDown(LENGHT_VIDEO, 5)
            picture = await cameraRef.current?.recordAsync({
                maxFileSize: MAX_VIDEO_SIZE,
                maxDuration: LENGHT_VIDEO / 1000,
                quality: RNCamera.Constants.VideoQuality['720p'],
            })
            videoInfoRef.current = picture
            setFileVideoInfo(picture)
            // @ts-ignore
            onUploadVideo(picture, frontFace)
        } else {
            return null
        }

        // const picture = await cameraRef.current.takePictureAsync(options)

        // console.log('file', picture)
        // if (Platform.OS === 'android' && (await hasAndroidPermission())) {
        //     CameraRoll.save(picture.uri)
        // }
        // if (Platform.OS === 'ios') {
        //     console.log('Save IOS')
        //     CameraRoll.save(picture.uri)
        // }

        if (step === 'take_front_face') {
            setFrontFace(picture)
        }
    }

    const fetchingCallback = (): any => {}

    const stopRecord = async () => {
        setIsRecording(false)
        // cameraRef.current?.stopRecording()
    }

    const handlerFace = ({ faces }: { faces: Face[] }) => {
        if (faces?.length === 0) return
        // console.log('faces', faces)
        if (statusFaceDetection.status === 0) {
            // Check khuôn mặt quay bên phải
            const isOk = checkFaceRight(faces[0], showHint)
            if (isOk) {
                setMatchFaceLeftCount((prev) => prev + 1)
                if (Platform.OS === 'ios' || matchFaceLeftCount > NUMBER_OF_DETECT_SUCCESS_SMILE_LEFT_RIGHT) {
                    setStatusFaceDetection(FACE_DETECT_STATUS[1])
                }
            } else {
                setMatchFaceLeftCount(0)
            }
        } else if (statusFaceDetection.status === 1) {
            // Check khuôn mặt quay bên trái
            const isOk = checkFaceLeft(faces[0], showHint)
            if (isOk) {
                setMatchFaceRightCount((prev) => prev + 1)
                if (Platform.OS === 'ios' || matchFaceRightCount > NUMBER_OF_DETECT_SUCCESS_SMILE_LEFT_RIGHT) {
                    setStatusFaceDetection(FACE_DETECT_STATUS[2])
                    // startUseCameraAction(3)
                }
            } else {
                setMatchFaceRightCount(0)
            }
        } else if (statusFaceDetection.status === 2) {
            // Check khuôn mặt nằm trong khung
            const isOk = checkFrame(faces[0], showHint)
            if (isOk) {
                setMatchCount((prev) => prev + 1)
                if (matchCount > NUMBER_OF_DETECT_FRONT_SUCCESS) {
                    setStatusFaceDetection(FACE_DETECT_STATUS[3])
                    startUseCameraAction('take_front_face', 'photo')
                }
            } else {
                setMatchCount(0)
            }
        } else if (statusFaceDetection.status === 3) {
            const isOk = checkFrame(faces[0], showHint)
            if (isOk) {
                setFaceSmileCount((prev) => prev + 1)
                showHint('keep_face_in_3s')
                if (Platform.OS === 'ios' || faceSmileCount > NUMBER_OF_DETECT_SUCCESS_SMILE_LEFT_RIGHT) {
                    setStatusFaceDetection(FACE_DETECT_STATUS[4])
                    startUseCameraAction('record_video', 'video')
                }
            } else {
                setFaceSmileCount(0)
                showHint('please_smile')
            }
        }

        // if (faces[0]) {
        //     setBox({
        //         boxs: {
        //             width: faces[0].bounds.size.width,
        //             height: faces[0].bounds.size.height,
        //             x: faces[0].bounds.origin.x,
        //             y: faces[0].bounds.origin.y,
        //             yawAngle: faces[0].yawAngle,
        //             rollAngle: faces[0].rollAngle,
        //         },
        //         rightEyePosition: faces[0].rightEyePosition, // Mắt trái
        //         leftEyePosition: faces[0].leftEyePosition, // Mắt phải
        //         bottomMouthPosition: faces[0].bottomMouthPosition, // Cằm
        //         leftCheekPosition: faces[0].leftCheekPosition, // Má bên trái
        //         leftEarPosition: faces[0].leftEarPosition, // Tai trái
        //         leftMouthPosition: faces[0].leftMouthPosition, // Miệng bên trái
        //         noseBasePosition: faces[0].noseBasePosition, // Vị trí mũi
        //         rightCheekPosition: faces[0].rightCheekPosition, // Má bên phải
        //         rightEarPosition: faces[0].rightEarPosition, // Má bên trái
        //         rightMouthPosition: faces[0].rightMouthPosition, // Miệng bên phải
        //         smilingProbability: faces[0].smilingProbability, // Xác xuất đang cười
        //         leftEyeOpenProbability: faces[0].leftEyeOpenProbability, // Xác xuất mở mắt
        //         rightEyeOpenProbability: faces[0].rightEyeOpenProbability, // Xác xuất mở mắt
        //     })
        // } else {
        //     setBox(null)
        // }
    }
    useEffect(() => {
        showHint(statusFaceDetection.hint)
    }, [statusFaceDetection])

    const PendingView = () => (
        <View
            style={{
                flex: 1,
                backgroundColor: 'lightgreen',
                justifyContent: 'center',
                alignItems: 'center',
            }}
        >
            <Text>Waiting</Text>
        </View>
    )
    const onRecordingEnd = (event: any) => {
        stopRecord()
    }

    const onUploadVideo = async (fileVideo: IFileCameraOuput, fileFace: IFileCameraOuput) => {
        resetCounter()
        if (!fileVideo || !fileVideo.uri || !fileFace || !fileFace.uri) return
        setLoading(true)
        try {
            const urlEnd = Platform.OS === 'ios' ? fileVideo.uri.replace('file://', '') : fileVideo.uri
            // @ts-ignore
            const fileData = await fetch(urlEnd)
            const {
                // @ts-ignore
                _bodyBlob: { _data: videoData },
            } = fileData

            const urlFaceEnd = Platform.OS === 'ios' ? fileFace.uri.replace('file://', '') : fileFace.uri
            // @ts-ignore
            const fileFaceData = await fetch(urlFaceEnd)
            const {
                // @ts-ignore
                _bodyBlob: { _data: dataFace },
            } = fileFaceData
            const timeout = 60000
            const mdmTp = Platform.OS === 'android' ? '03' : '04'
            const mwLoginID = Platform.OS === 'android' ? 'Android' : 'IOS'
            const body = createFormData(fileVideo, fileFace, {
                sec: glb_sv.activeCode,
                // Thông tin file hình ảnh chính diện khuôn mặt
                fileNameFace: dataFace.name,
                fileTypeFace: dataFace.type,
                sizeFace: dataFace.size,
                // Thông tin file video
                fileName: videoData.name,
                fileType: videoData.type,
                size: videoData.size,
                userId: glb_sv.objShareGlb.sessionInfo.userID, // userInfo.actn_curr
                step: '3',
                type: 'VIDEO',
                timeout,
                Mdmtp: mdmTp,
                MWLoginID: mwLoginID,
            })
            fetchTimeout(`${apiFPT}/upload/`, timeout, fetchingCallback, {
                method: 'POST',
                headers: { 'Content-Type': 'multipart/form-data' },
                body,
            })
                .then((response) => response.json())
                .then((data) => {
                    setLoading(false)
                    if (data.success === true) {
                        // switchStep.next()
                        onProcessUploaded(data)
                        if (data.errorCode !== 0) {
                            // Upload file thành công nhưng check logic chưa hợp lệ => Xác thực lại
                            setUploaded(false)
                            setListMessage(data.errorMessage)
                            //
                        } else {
                            setUploaded(true)
                        }
                    } else {
                        // Upload file không thành công => Xác thực lại
                        setUploaded(false)
                        setListMessage([data.error?.['message']])
                    }
                })
                .catch((error) => {
                    setLoading(false)
                    // Không connect được server || hết timeout => Xác thực lại
                    setUploaded(false)
                    if (error.name === 'AbortError') {
                        // Processing timeout
                        setListMessage(['request_hanlde_not_success_try_again'])
                    } else {
                        // network error or json parsing error
                        setListMessage(['Can_not_connected_to_server_plz_check_your_network'])
                    }
                })
        } catch (error) {
            console.warn('error try catch: ', error)
            setLoading(false)
            // Đọc file video || ảnh mặt trước kh được => Xác thực lại
            setUploaded(false)
            setListMessage(['file_is_error_please_take_again'])
        }
    }

    const handleReAuthenFaceID = () => {
        // Nhấn nút xác thực lại khuôn mặt = Ẩn button xác thực lại
        Analytics.logEvent(EkycAnalyticEvents.ekyc_step_two_verify_face_retry)
        setUploaded(null)
        setListMessage([])
        setStatusFaceDetection(FACE_DETECT_STATUS[0])

        setMatchCount(0)
        setMatchFaceLeftCount(0)
        setMatchFaceRightCount(0)
        setFaceSmileCount(0)

        setFrontFace({})

        if (Platform.OS !== 'ios') {
            forceRender() // Force render for cameraRef work correctly
        }
    }

    const resetDataProcessAgain = () => {
        ekycService.frontData = {}
        ekycService.backData = {}
        ekycService.videoData = {}
        ekycService.userData = {}
        ekycService.additionalData = {}

        handleReAuthenFaceID()
        InteractionManager.runAfterInteractions(() => {
            switchStep.goTo(0)
        })
    }

    return (
        <>
            {!guidanceModel && !alertModal ? (
                <ScrollView showsVerticalScrollIndicator={false}>
                    <HintMessageUIView messageHint={messageHint} progress={statusFaceDetection.status} zIndex={ZINDEX_LAYER.HINT} />
                    <View
                        style={{
                            paddingTop: 16,
                        }}
                    >
                        <RNCamera
                            androidCameraPermissionOptions={{
                                title: 'Permission to use camera',
                                message: 'We need your permission to use your camera',
                                buttonPositive: 'Ok',
                                buttonNegative: 'Cancel',
                            }}
                            captureAudio={false}
                            defaultVideoQuality={RNCamera.Constants.VideoQuality['720p']}
                            faceDetectionClassifications={RNCamera.Constants.FaceDetection.Classifications.all}
                            faceDetectionLandmarks={RNCamera.Constants.FaceDetection.Landmarks.all}
                            faceDetectionMode={RNCamera.Constants.FaceDetection.Mode.accurate} // Chậm nhưng chính xác hơn
                            pictureSize="1920x1080"
                            playSoundOnCapture={false}
                            ref={cameraRef}
                            style={UI.camera}
                            type={RNCamera.Constants.Type.front}
                            onFacesDetected={handlerFace}
                            onRecordingEnd={onRecordingEnd}
                        >
                            {({ camera, status, recordAudioPermissionStatus }) => {
                                if (status !== 'READY') return <PendingView />
                                return null
                            }}
                        </RNCamera>
                        <View style={{ position: 'absolute', zIndex: ZINDEX_LAYER.OVERLAY, height: CAMERA_HEIGHT }}>
                            <Svg height={CAMERA_HEIGHT + 100} width={WIDTH}>
                                <Defs>
                                    <ClipPath id="clip">
                                        <Rect fill="white" fillOpacity={1} height={CAMERA_HEIGHT + 100} width="100%" />
                                        <Ellipse
                                            cx={FRAME_DETECTION.center.x + FRAME_DETECTION.width / 2}
                                            cy={FRAME_DETECTION.center.y + FRAME_DETECTION.height / 2}
                                            fill="red"
                                            fillRule="evenodd"
                                            rx={FRAME_DETECTION.width * 0.6}
                                            ry={FRAME_DETECTION.width * 0.6}
                                        />
                                    </ClipPath>
                                </Defs>
                                <Ellipse
                                    cx={FRAME_DETECTION.center.x + FRAME_DETECTION.width / 2}
                                    cy={FRAME_DETECTION.center.y + FRAME_DETECTION.height / 2}
                                    fill={styles.PRIMARY__BG__COLOR}
                                    fillOpacity={ascPercent > 0 && ascPercent !== 100 ? 0.7 : 0}
                                    fillRule="evenodd"
                                    rx={FRAME_DETECTION.width * 0.6}
                                    ry={FRAME_DETECTION.width * 0.6}
                                />
                                <Rect
                                    clipPath="url(#clip)"
                                    fill={styles.PRIMARY__BG__COLOR}
                                    height={CAMERA_HEIGHT + 100}
                                    opacity="1"
                                    width="100%"
                                    x="0"
                                    y="0"
                                />
                            </Svg>
                        </View>
                        {ascPercent > 0 && ascPercent !== 100 ? (
                            <View style={[UI.progress, { borderWidth: IS_DEBUG ? 2 : 0, borderColor: styles.PRIMARY }]}>
                                <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                                    <CircularProgress
                                        activeStrokeSecondaryColor="yellow"
                                        activeStrokeWidth={20}
                                        duration={LENGHT_VIDEO / 5}
                                        inActiveStrokeColor={styles.SECOND__BG__COLOR}
                                        inActiveStrokeOpacity={0.5}
                                        inActiveStrokeWidth={15}
                                        radius={FRAME_DETECTION.width * 0.7}
                                        showProgressValue={false}
                                        title={t('keep_face_in_seconds', { seconds: percentInsecond > 0 ? percentInsecond : '' })}
                                        titleColor={styles.ERROR__COLOR}
                                        titleFontSize={24}
                                        titleStyle={{ fontWeight: '600' }}
                                        value={descPercent}
                                    />
                                </View>
                            </View>
                        ) : (
                            <View style={[UI.progress, { borderWidth: IS_DEBUG ? 2 : 0, borderColor: styles.PRIMARY }]}>
                                <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                                    <CircularProgress
                                        activeStrokeSecondaryColor="yellow"
                                        activeStrokeWidth={20}
                                        dashedStrokeConfig={{
                                            count: 50,
                                            width: 4,
                                        }}
                                        duration={500}
                                        inActiveStrokeColor={styles.ICON__PRIMARY}
                                        inActiveStrokeOpacity={0.5}
                                        inActiveStrokeWidth={15}
                                        progressValueStyle={{ fontWeight: '100', color: 'white', fontSize: 1 }}
                                        radius={FRAME_DETECTION.width * 0.7}
                                        value={(statusFaceDetection.status / 4) * 100}
                                    />
                                </View>
                            </View>
                        )}

                        <View style={{ alignItems: 'center', flex: 1, zIndex: ZINDEX_LAYER.HINT }}>
                            <Text style={{ fontSize: fontSizes.medium, color: styles.PRIMARY__CONTENT__COLOR, marginLeft: 8, flex: 1 }}>
                                {t<string>(messageHint)}
                            </Text>
                        </View>
                        <GuideIconAnimation progress={2} zIndex={ZINDEX_LAYER.OVERLAY} />
                        <View
                            style={{
                                alignItems: 'flex-start',
                                zIndex: ZINDEX_LAYER.OVERLAY,
                                paddingHorizontal: dimensions.moderate(16),
                            }}
                        >
                            <View style={[UI.row]}>
                                <View style={{ width: '33%' }}>
                                    <Image source={EKYC_NOTE_01} style={{ alignSelf: 'center', resizeMode: 'contain' }} />
                                    <Text style={{ color: styles.SECOND__CONTENT__COLOR, textAlign: 'center', paddingTop: 8 }}>
                                        {t<string>('formal_clothes')}
                                    </Text>
                                </View>
                                <View style={{ width: '33%' }}>
                                    <Image source={EKYC_NOTE_02} style={{ alignSelf: 'center', resizeMode: 'contain' }} />
                                    <Text style={{ color: styles.SECOND__CONTENT__COLOR, textAlign: 'center', paddingTop: 8 }}>
                                        {t<string>('no_sunglasses')}
                                    </Text>
                                </View>
                                <View style={{ width: '33%' }}>
                                    <Image source={EKYC_NOTE_03} style={{ alignSelf: 'center', resizeMode: 'contain' }} />
                                    <Text style={{ color: styles.SECOND__CONTENT__COLOR, textAlign: 'center', paddingTop: 8 }}>{t<string>('no_mask_hat')}</Text>
                                </View>
                            </View>

                            {listMessage.length > 0 && (
                                <View style={{ paddingTop: 10 }}>
                                    {listMessage.map((item) => (
                                        <Text key={item} style={{ fontSize: fontSizes.medium, color: 'orange' }}>
                                            {`- ${t(item)}`}
                                        </Text>
                                    ))}
                                </View>
                            )}
                        </View>
                    </View>
                </ScrollView>
            ) : (
                <></>
            )}
            {loading ? <ModalLoading content={t('common_processing')} maxVisibleLoading={60000} setLoading={setLoading} visible={loading} /> : null}
            <EkycButton text={t('common_button_previous')} onPress={() => switchStep.prev({ step: 1, subStep: 2 })} />
            <Modal
                hideModalContentWhileAnimating
                isVisible={guidanceModel}
                style={{ marginLeft: 5, marginRight: 5 }}
                useNativeDriver={true}
                onBackButtonPress={() => {
                    setGuidanceModel(false)
                }}
            >
                <ModalContent>
                    <View
                        style={{
                            paddingHorizontal: dimensions.moderate(16),
                            paddingBottom: dimensions.moderate(16),
                            alignItems: 'center',
                            flexDirection: 'column',
                            justifyContent: 'center',
                        }}
                    >
                        <Text
                            style={{
                                fontSize: fontSizes.xmedium,
                                fontWeight: fontWeights.bold,
                                color: styles.PRIMARY,
                                paddingBottom: dimensions.moderate(16),
                            }}
                        >
                            {t('scanning_face_guidance')}
                        </Text>
                        <Text
                            style={{
                                fontSize: fontSizes.normal,
                                color: styles.PRIMARY__CONTENT__COLOR,
                                paddingVertical: dimensions.moderate(16),
                            }}
                        >
                            {t('scanning_face_guidance_step_1')}
                        </Text>
                        <Text
                            style={{
                                fontSize: fontSizes.normal,
                                color: styles.PRIMARY__CONTENT__COLOR,
                            }}
                        >
                            {t('scanning_face_guidance_step_2')}
                        </Text>
                    </View>
                    <ButtonCustom
                        text={t('common_alert_agree')}
                        type="confirm"
                        onPress={() => {
                            setGuidanceModel(false)
                        }}
                    />
                </ModalContent>
            </Modal>
            <Modal
                hideModalContentWhileAnimating
                isVisible={alertModal}
                style={{ marginLeft: 5, marginRight: 5 }}
                useNativeDriver={true}
                onBackButtonPress={() => {
                    setAlertModal(false)
                    handleReAuthenFaceID()
                }}
            >
                <ModalContent>
                    <View
                        style={{
                            paddingHorizontal: dimensions.moderate(16),
                            alignItems: 'center',
                            flexDirection: 'column',
                            justifyContent: 'center',
                        }}
                    >
                        <Text
                            style={{
                                fontSize: fontSizes.xmedium,
                                fontWeight: fontWeights.bold,
                                color: styles.PRIMARY,
                                paddingBottom: dimensions.moderate(16),
                                textAlign: 'center',
                            }}
                        >
                            {t('re_scanning_face_guidance')}
                        </Text>
                        <Text
                            style={{
                                fontSize: fontSizes.normal,
                                color: styles.PRIMARY__CONTENT__COLOR,
                                paddingVertical: dimensions.moderate(16),
                            }}
                        >
                            {t('scanning_face_guidance_step_1')}
                        </Text>
                        <Text
                            style={{
                                fontSize: fontSizes.normal,
                                color: styles.PRIMARY__CONTENT__COLOR,
                            }}
                        >
                            {t('scanning_face_guidance_step_2')}
                        </Text>
                    </View>
                    <ButtonCustom
                        text={t('common_alert_agree')}
                        type="confirm"
                        onPress={() => {
                            setAlertModal(false)
                            handleReAuthenFaceID()
                        }}
                    />
                </ModalContent>
            </Modal>
        </>
    )
})

const UI = StyleSheet.create({
    camera: {
        flexGrow: 1,
        height: CAMERA_HEIGHT,
    },
    progress: {
        borderRadius: 400,
        borderWidth: 5,
        height: FRAME_DETECTION.height,
        left: FRAME_DETECTION.center.x,
        position: 'absolute',
        top: FRAME_DETECTION.cameraHeight / 2 - FRAME_DETECTION.height / 2,
        width: FRAME_DETECTION.width,
        zIndex: ZINDEX_LAYER.PROGRESS,
    },
    row: {
        alignContent: 'center',
        flexDirection: 'row',
        justifyContent: 'center',
        marginTop: dimensions.vertical(12),
        width: '100%',
    },
})

async function hasAndroidPermission() {
    const permission = PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE

    const hasPermission = await PermissionsAndroid.check(permission)
    if (hasPermission) {
        return true
    }

    const status = await PermissionsAndroid.request(permission)
    return status === 'granted'
}
