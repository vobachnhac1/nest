import React, { Component, createRef } from 'react'
import { Platform, StyleSheet } from 'react-native'
import WebView from 'react-native-webview'

import { glb_sv } from '../../../../utils'

const source = Platform.select({
    ios: require('../../../../basic-components/custom-chart/index.html'),
    android: { uri: 'file:///android_asset/index.html' },
})

// export default memo(WebviewChart)
export default class WebviewChart extends Component {
    constructor(props) {
        super(props)
        this.chartRef = createRef()

        this.state = {
            webviewKey: new Date().getTime(),
        }
        this.DATA_CATEGORY = []
        this.DATA_AMOUNT = []
        this.DATA_RATIO = []
    }

    componentWillReceiveProps(nextProps) {
        this.DATA_CATEGORY = nextProps.DATA_CATEGORY
        this.DATA_AMOUNT = nextProps.DATA_AMOUNT
        this.DATA_RATIO = nextProps.DATA_RATIO

        if (this.props !== nextProps) {
            this.chartRef &&
                this.chartRef.current.injectJavaScript(`
                window.DATA_CATEGORY = ${JSON.stringify(this.props.DATA_CATEGORY.reverse())};
                window.DATA_AMOUNT = ${JSON.stringify(this.props.DATA_AMOUNT.reverse())};
                window.DATA_RATIO = ${JSON.stringify(this.props.DATA_RATIO.reverse())};
            if (window.eventMarket) {
                window.eventMarket.next({ type: 'highchart-render', value: 'dataChartProfitLoss' })
            } else {
                setTimeout(() => {
                    window.eventMarket && window.eventMarket.next({ type: 'highchart-render', value: 'dataChartProfitLoss' })
                }, 1000);
            }
            true;
        `)
        }
    }

    shouldComponentUpdate(nextProps, nextState) {
        if (nextState.webviewKey !== this.state.webviewKey) {
            return true
        }
        if (nextProps.theme !== this.props.theme) {
            this.chartRef.current?.reload()
            return true
        }

        return false
    }

    reload = () => {
        this.setState({
            webviewKey: this.state.webviewKey + 1,
        })
    }

    render() {
        const {
            styles: { PRIMARY__CONTENT__COLOR, PRIMARY, REF__COLOR, UP__COLOR, PRIMARY__BG__COLOR, DIVIDER__COLOR, ICON__PRIMARY },
            theme,
            t,
        } = this.props

        return (
            <WebView
                allowUniversalAccessFromFileURLs={true}
                domStorageEnabled={true}
                injectedJavaScriptBeforeContentLoaded={`
                    window.chartName = 'ProfitLossCalculation';
                    window.value_of_profit_achieved_by_month = '${this.props.t('value_of_profit_achieved_by_month')}';
                    window.ratio_of_profit_achieved_by_month = '${this.props.t('ratio_of_profit_achieved_by_month')}';
                    window.statictis = '${this.props.t('statictis')}';
                    window.profit_or_loss_ratio = '${this.props.t('profit_or_loss_ratio')}';
                    window.ratio_index = '${this.props.t('ratio_index')}';
                    window.absolute_efficiency = '${this.props.t('absolute_efficiency')}';
                    window.compare_vnindex = '${this.props.t('compare_vnindex')}';
                    window.title_assets = '${this.props.t('stock_title')}';
                    window.title_cash = '${this.props.t('title_cash')}';
                    window.title_debt = '${this.props.t('common_debt')}';
                    window.workDate = '${glb_sv.objShareGlb.workDate}';
                    window.theme = '${theme}'
                    window.PRIMARY__CONTENT__COLOR = '${PRIMARY__CONTENT__COLOR}';
                    window.UP__COLOR = '${UP__COLOR}';
                    window.REF__COLOR = '${REF__COLOR}';
                    window.PRIMARY__BG__COLOR = '${PRIMARY__BG__COLOR}';
                    window.DIVIDER__COLOR = '${DIVIDER__COLOR}';
                    window.ICON__PRIMARY = '${ICON__PRIMARY}';
                    `}
                javaScriptEnabled
                source={source}
                // source={{
                //     uri: 'http://192.168.0.111:3001',
                // }}
                originWhitelist={['*']}
                ref={this.chartRef}
                scrollEnabled={false}
                style={UI.webView}
                androidLayerType="hardware"
                // androidHardwareAccelerationDisabled
                // onMessage={this.onMessage}
                onContentProcessDidTerminate={this.reload}
            />
        )
    }
}

const UI = StyleSheet.create({
    webView: {
        backgroundColor: 'transparent',
        flex: 1,
    },
})
