import { Platform } from 'react-native'

const IOS = Platform.OS === 'ios' ? true : false

// webClientId from firebase for login google
export default {
    webClientId: IOS
        ? '636291491225-bv0grcv3uas1q6kpuvn51si9klmqm81c.apps.googleusercontent.com'
        : '636291491225-m3mmgspnbf165j42t9k34h9brl7rcnud.apps.googleusercontent.com',
}
