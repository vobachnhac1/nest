import React, { memo, useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { StyleSheet, View } from 'react-native'
import DeviceInfo from 'react-native-device-info'
import { Row } from 'native-base'

import { BasicStockInfo } from '../../../components/stock-info'
import { StoreContext } from '../../../store'
import { dimensions } from '../../../styles'

const isTablet = DeviceInfo.isTablet()

const BlockBasicInfoStock = memo(
    ({
        t137,
        t137Color,
        t139,
        t139Color,
        t2661,
        t2661Color,
        t266,
        t266Color,
        t391,
        t397_t398,
        t3301,
        t3871,
        low_1y,
        high_1y,
        low_1w,
        high_1w,
        low_1m,
        high_1m,
    }) => {
        const { t } = useTranslation()
        const { styles } = useContext(StoreContext)
        return (
            <>
                <Row
                    style={{
                        paddingHorizontal: dimensions.moderate(8),
                        marginTop: dimensions.vertical(8),
                        marginBottom: dimensions.vertical(4),
                        justifyContent: 'space-between',
                    }}
                >
                    <View style={{ backgroundColor: styles.BUTTON__SECONDARY, ...UI.basicInfo }}>
                        <BasicStockInfo
                            figure1={t137}
                            figure1Color={t137Color}
                            figure2={t139}
                            figure2Color={t139Color}
                            name={t('open') + '/' + t('close_price')}
                        />
                    </View>
                    <View style={{ backgroundColor: styles.BUTTON__SECONDARY, ...UI.basicInfo }}>
                        <BasicStockInfo figure1={t2661} figure1Color={t2661Color} figure2={t266} figure2Color={t266Color} name={t('day_range')} type={'-'} />
                    </View>
                    <View style={{ backgroundColor: styles.BUTTON__SECONDARY, ...UI.basicInfo }}>
                        <BasicStockInfo figure={t391} name={t('volume')} />
                    </View>
                </Row>
                <Row style={{ paddingHorizontal: dimensions.moderate(8), marginBottom: dimensions.vertical(4), justifyContent: 'space-between' }}>
                    <View style={{ backgroundColor: styles.BUTTON__SECONDARY, ...UI.basicInfo }}>
                        <BasicStockInfo figure={t397_t398} name={t('volume_foreign_buy_sell')} />
                    </View>
                    <View style={{ backgroundColor: styles.BUTTON__SECONDARY, ...UI.basicInfo }}>
                        <BasicStockInfo figure={t3301} name={t('priceboard_foreign_room')} />
                    </View>
                    <View style={{ backgroundColor: styles.BUTTON__SECONDARY, ...UI.basicInfo }}>
                        <BasicStockInfo figure={t3871} name={t('value')} />
                    </View>
                </Row>
                {/* <Row style={{ paddingHorizontal: dimensions.moderate(8), marginBottom: dimensions.vertical(8), justifyContent: 'space-between' }}>
                    <View style={{ backgroundColor: styles.BUTTON__SECONDARY, ...UI.basicInfo }}>
                        <BasicStockInfo name={t('1_week_range')} figure1={low_1w} figure2={high_1w} type={'-'} />
                    </View>
                    <View style={{ backgroundColor: styles.BUTTON__SECONDARY, ...UI.basicInfo }}>
                        <BasicStockInfo name={t('1_month_range')} figure1={low_1m} figure2={high_1m} type={'-'} />
                    </View>
                    <View style={{ backgroundColor: styles.BUTTON__SECONDARY, ...UI.basicInfo }}>
                        <BasicStockInfo name={t('52_week_range')} figure1={low_1y} figure2={high_1y} type={'-'} />
                    </View>
                </Row> */}
            </>
        )
    },
)

const UI = StyleSheet.create({
    back_button: { height: 35, marginLeft: 10, paddingBottom: 0, paddingHorizontal: 6, paddingTop: 0 },
    basicInfo: {
        borderRadius: 4,
        flex: 2,
        marginHorizontal: 2,
        paddingHorizontal: dimensions.vertical(8),
        paddingVertical: dimensions.vertical(4),
    },
    flex1: {
        backgroundColor: '#000',
        flex: 1,
    },
    footer: {
        borderTopWidth: 0,
        elevation: 6,
        height: 70,
        marginBottom: -35,
        paddingBottom: 0,
        shadowOffset: {
            width: 0,
            height: -6,
        },
        shadowOpacity: 0.1,
        shadowRadius: 3.49,
    },
    header: {
        flexDirection: 'row',
        height: isTablet ? 50 : 40,
    },
    header_title: { alignItems: 'flex-start', borderRadius: 10, flexDirection: 'column', flex: 1, justifyContent: 'flex-start', padding: 0 },
    marginRight8: { marginRight: 8 },
    row_buysell: { flexDirection: 'row', justifyContent: 'space-evenly', paddingBottom: 24, paddingHorizontal: dimensions.moderate(16) },
    view_chart: { justifyContent: 'center', marginBottom: dimensions.halfIndent, paddingHorizontal: dimensions.halfIndent / 2 },
    view_chart_height: { height: 230, justifyContent: 'center' },
    view_price_t31: { alignItems: 'center', flexDirection: 'row' },
    width15: { width: dimensions.moderate(15) },
})

export default BlockBasicInfoStock
