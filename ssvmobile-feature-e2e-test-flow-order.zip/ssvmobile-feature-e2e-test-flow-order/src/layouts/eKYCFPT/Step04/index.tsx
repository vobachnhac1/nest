/**
 * STEP 4:
 * Econtract
 */

import React, { useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { InteractionManager, StyleSheet, TouchableOpacity, View } from 'react-native'
import Modal from 'react-native-modal'
import { ProgressBar } from 'react-native-paper'
import RenderHTML from 'react-native-render-html'
import ToastGlobal from 'react-native-toast-message'
import WebView from 'react-native-webview'
import ModalController from '@mts-components/appModal/modalControlller'
import { reqFunct } from '@mts-utils/index'
import Analytics, { EkycAnalyticEvents } from '@mts-utils/TrackingData/Analytics'
import Clipboard from '@react-native-clipboard/clipboard'
import CookieManager from '@react-native-cookies/cookies'
import { useNavigation } from '@react-navigation/native'
import { Fab, Icon } from 'native-base'

import { Text } from '../../../basic-components'
import ModalLoading from '../../../components/modal-loading'
import { ButtonCustom, ModalContent, RowDataModal } from '../../../components/trading-component'
import { StoreContext } from '../../../store'
import { fontSizes, IconSvg } from '../../../styles'
import { HIEGHT } from '../../../styles/helper/dimensions'
import { glb_sv, Screens, sendRequest } from '../../../utils'
import { ISwitchStep } from '..'

interface IFourthStep {
    switchStep: ISwitchStep
}
export interface IWebviewConfigEContract {
    url: string
    cookie_name: string
    cookie_value: string
    cookie_exp: string
    econtract_username: string
    econtract_password: string
    econtract_status?: 'CRE' | 'CUS' | 'FIN' | 'CAN' | 'REJ'
}

const ServiceInfo: { [key: string]: ISserviceInfo } = {
    GET_ECONTRACT_FOR_OPENACCOUNT: {
        reqFunct: reqFunct.GET_ECONTRACT_FOR_OPENACCOUNT,
        WorkerName: 'FOSqCommon',
        ServiceName: 'FOSqCommon_QueryEContractForSign',
        Operation: 'Q',
    },
}

export const FifthStep = ({ switchStep }: IFourthStep) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()
    const navigation = useNavigation()
    // const [visible, setVis ible] = useState(true);
    const [progress, setProgress] = useState(0)
    // const [isWebViewConfigOK, setIsWebViewConfigOK] = useState(false);
    // const [loadingWaitingWebview, setLoadingWaitingWebview] = useState(true);
    // const [isHintPassword, setIsHintPassword] = useState(false);
    // const [modalHintPass, setModalHintPass] = useState(false);
    // const [dataWebviewConfig, setDataWebviewConfig] = useState<IWebviewConfigEContract>({
    // 	url: '',
    // 	cookie_name: '',
    // 	cookie_value: '',
    // 	cookie_exp: '',
    // 	econtract_username: '',
    // 	econtract_password: ''
    // });
    // const intervalCheckEcontract = useRef<NodeJS.Timer>();

    // Comment lại phần này: Do với một số device yếu sẽ bị crash khi listen event (xử lý quá nhiều)
    // ---------------------------------------------------
    // useEffect(() => {
    // 	const commonEvent = glb_sv.commonEvent.subscribe((msg: any) => {
    // 		if (msg.type === eventList.NOTIFY_ECONTRACT_NEED_SIGN) {
    // 			console.log('NOTIFY_ECONTRACT_NEED_SIGN', msg);
    // 			const configWebview: IWebviewConfigEContract = msg.data || {};
    // 			if (configWebview.econtract_status === 'CRE') {
    // 				if (intervalCheckEcontract.current) {
    // 					clearInterval(intervalCheckEcontract.current)
    // 					setDataWebviewConfig(configWebview)
    // 				} else {
    // 					console.log("Vào else");
    // 					clearInterval(intervalCheckEcontract.current)
    //                     setDataWebviewConfig(configWebview)
    // 				}
    // 			}
    // 		}
    // 	});
    // 	return () => {
    // 		commonEvent.unsubscribe()
    // 	};
    // }, [])

    useEffect(() => {
        Analytics.logEvent(EkycAnalyticEvents.ekyc_step_four_timeout)

        InteractionManager.runAfterInteractions(() => {
            ModalController.showModal({
                icon: null,
                title: t('common_notify').toLocaleUpperCase(),
                colorTitle: styles.EKYC__COLOR,
                middleComponent: <EContractWaitingNoteContent />,
                titleOK: t('common_alert_agree').toLocaleUpperCase(),
                typeColor: styles.EKYC__COLOR,
                linkCallback: () => {
                    navigation.replace(Screens.ECONTRACT_MANAGEMENT, {})
                },
                showCancel: false,
            })
        })
    }, [])

    // useEffect(() => {
    // 	if (loadingWaitingWebview) {
    // 		intervalCheckEcontract.current = setInterval(() => {
    // 			getEcontractForOpenAccount()
    // 		}, 3000)
    // 	} else {
    // 		clearInterval(intervalCheckEcontract.current)
    // 	}
    // 	return () => clearInterval(intervalCheckEcontract.current);
    // }, [loadingWaitingWebview]);

    // const getEcontractForOpenAccount = () => {
    // 	// setRefreshing(true);
    // 	const InputParams = ['0','2']; // { is_econtr_tp,  is_status}
    // 	sendRequest(ServiceInfo.GET_ECONTRACT_FOR_OPENACCOUNT, InputParams, (_, message) => {
    // 		// setRefreshing(false);
    // 		if (Number(message['Result'] === 0)) {
    // 			return;
    // 		} else {
    // 			let jsondata;
    // 			if (!message['Data']) return;
    // 			try {
    // 				jsondata = JSON.parse(message['Data']);
    // 				if (jsondata && jsondata[0]) {
    // 					clearInterval(intervalCheckEcontract.current)
    // 					const contractData = jsondata[0];
    // 					const configWebview: IWebviewConfigEContract = {
    // 						url: contractData.c6,
    // 						cookie_name: contractData.c7,
    // 						cookie_value: contractData.c8,
    // 						cookie_exp: contractData.c9,
    // 						econtract_username: contractData.c10,
    // 						econtract_password: contractData.c11
    // 					};
    // 					setDataWebviewConfig(configWebview);
    // 					Analytics.logEvent(EkycAnalyticEvents.ekyc_step_four_finish);
    // 				}
    // 			} catch (err) {
    // 				console.log('getListEContractResutl -> err', err);
    // 				return;
    // 			}
    // 		}
    // 	});
    // };

    // useEffect(() => {

    // 	// set a cookie
    // 	if (dataWebviewConfig.url) {
    // 		CookieManager.set(dataWebviewConfig.url, {
    // 			name: dataWebviewConfig.cookie_name,
    // 			value: dataWebviewConfig.cookie_value,
    // 			path: '/'
    // 		}).then(done => {
    // 			console.log('CookieManager.set =>', done);
    // 			setIsWebViewConfigOK(true);
    // 			setLoadingWaitingWebview(false);
    // 		});
    // 	}
    // }, [dataWebviewConfig]);

    // console.log('log', callOptionWebview);
    // const onNavigationChange = e => {
    // 	console.log('e', e.url);
    // 	if (e.url?.includes('/login')) {
    // 		console.log('navigate to login');
    // 		setIsHintPassword(true);
    // 	} else {
    // 		setIsHintPassword(false);
    // 	}
    // 	CookieManager.get(dataWebviewConfig.url).then(cookies => {
    // 		console.log('CookieManager.get =>', cookies);
    // 	});
    // };

    // const copyEmail = (text: string) => {
    // 	setModalHintPass(false);
    // 	if (typeof text === 'string') {
    // 		Clipboard.setString(text);
    // 		ToastGlobal.show({
    // 			text2: t('copy_email_success'),
    // 			type: 'success'
    // 		});
    // 		return;
    // 	}
    // };
    // const copyPassword = (text: string) => {
    // 	setModalHintPass(false);
    // 	if (typeof text === 'string') {
    // 		Clipboard.setString(text);
    // 		ToastGlobal.show({
    // 			text2: t('copy_password_success'),
    // 			type: 'success'
    // 		});
    // 		return;
    // 	}
    // };

    const EContractWaitingNoteContent = () => {
        const escapeHtml = (text: string): string => {
            return text
                .replace(/&amp;/g, '&')
                .replace(/&lt;/g, '<')
                .replace(/&gt;/g, '>')
                .replace(/&quot/g, '"')
                .replace(/&#039;/g, "'")
        }
        const tagsStyles = {
            strong: {
                color: styles.EKYC__COLOR,
            },
        }

        return (
            <RenderHTML
                baseStyle={{
                    fontSize: fontSizes.normal,
                    color: styles.EKYC__SILVER,
                    overflow: 'visible',
                    textAlign: 'justify',
                    marginLeft: 8,
                    marginRight: 8,
                    marginBottom: 16,
                }}
                source={{
                    html: escapeHtml(t<string>('notify_ekyc_econtract_will_send_later') || ''),
                }}
                tagsStyles={tagsStyles}
            />
        )
    }

    // Prevent zoom in mobile
    // const INJECTEDJAVASCRIPT = `const meta = document.createElement('meta'); meta.setAttribute('content', 'width=device-width, initial-scale=0.5, maximum-scale=0.5, user-scalable=0'); meta.setAttribute('name', 'viewport'); document.getElementsByTagName('head')[0].appendChild(meta); `;

    return (
        <>
            <View style={UI.container}>
                <ProgressBar color={styles.PRIMARY} progress={progress} style={{ height: 2 }} />
                {/* {isWebViewConfigOK && dataWebviewConfig.url ? (
					<>
						<WebView
							cacheEnabled={false}
							source={{
								uri: dataWebviewConfig.url,
								headers: {
									Cookie: `${dataWebviewConfig.cookie_name}=${dataWebviewConfig.cookie_value}`
								}
							}}
							sharedCookiesEnabled={true}
							thirdPartyCookiesEnabled={true}
							onNavigationStateChange={onNavigationChange}
							onLoadStart={() => setVisible(true)}
							onError={() => setVisible(false)}
							originWhitelist={['*']}
							onLoadProgress={({ nativeEvent }) => {
								setProgress(nativeEvent.progress);
							}}
							textZoom={100}
							// fix thanh scroll trên webview hiện sai vị trí
							showsVerticalScrollIndicator={false}
							onLoad={() => setVisible(false)}
							injectedJavaScript={INJECTEDJAVASCRIPT}
							style={{ height: HIEGHT - 200 }}
							allowUniversalAccessFromFileURLs={true}
							javaScriptEnabled
						/>
					</>
				) : null} */}
                {/* {loadingWaitingWebview ? (
					<ModalLoading
						visible={loadingWaitingWebview}
						content={t('ekyc_prepare_econtract')}
						maxVisibleLoading={60000}
						showTimeoutMessage={false}
						setLoading={(loadingState) => {
							if (!dataWebviewConfig.url) {
								Analytics.logEvent(EkycAnalyticEvents.ekyc_step_four_timeout);
								navigation.navigate(Screens.ALERT_MODAL, {
									icon: null,
									title: t('common_notify').toLocaleUpperCase(),
									colorTitle: styles.EKYC__COLOR,
									middleComponent: <EContractWaitingNoteContent />,
									titleOK: t('common_alert_agree').toLocaleUpperCase(),
									typeColor: styles.EKYC__COLOR,
									// @ts-expect-error
									linkCallback: () => navigation.replace(Screens.HOME, {}),
									showCancel: false,
								});
							}
							setLoadingWaitingWebview(loadingState)
						}}
					/>
				) : null} */}
                {/* <Modal
					style={{ marginLeft: 5, marginRight: 5 }}
					isVisible={modalHintPass}
					useNativeDriver={true}
					hideModalContentWhileAnimating
					onBackButtonPress={() => {
						setModalHintPass(false);
					}}>
					<ModalContent title={t('acount_infomations')} iconComponent={<IconSvg.ErrorIcon color={styles.EKYC__COLOR} />}>
						<RowDataModal
							textLeft={t('email')}
							rightComponent={
								<View style={{ flex: 1, flexDirection: 'row', justifyContent: 'space-between' }}>
									<Text style={{ color: styles.PRIMARY__CONTENT__COLOR }}>******</Text>
									<TouchableOpacity onPress={() => copyEmail(dataWebviewConfig.econtract_username)}>
										<View>
											<Icon type='Feather' name='copy' style={{ color: styles.EKYC__COLOR, fontSize: 20, marginTop: -6 }} />
										</View>
									</TouchableOpacity>
								</View>
							}
						/>
						<View style={{ height: 8 }} />
						<RowDataModal
							textLeft={t('login_user_password')}
							rightComponent={
								<View style={{ flex: 1, flexDirection: 'row', justifyContent: 'space-between' }}>
									<Text style={{ color: styles.PRIMARY__CONTENT__COLOR }}>******</Text>
									<TouchableOpacity onPress={() => copyPassword(dataWebviewConfig.econtract_password)}>
										<View>
											<Icon type='Feather' name='copy' style={{ color: styles.EKYC__COLOR, fontSize: 20, marginTop: -6 }} />
										</View>
									</TouchableOpacity>
								</View>
							}
						/>
						<ButtonCustom
							text={t('common_alert_agree')}
							onPress={() => {
								setModalHintPass(false);
								// setIsShowReviewModal(false);
								// onBeforeRegisterEkyc();
							}}
							type='confirm'
						/>
					</ModalContent>
				</Modal> */}
            </View>
            {/* {isHintPassword ? (
				<Fab
					active={false}
					direction='down'
					containerStyle={{ top: 32, marginRight: 8, justifyContent: 'center', alignItems: 'center' }}
					style={{ backgroundColor: styles.EKYC__COLOR }}
					position='bottomRight'>
					<TouchableOpacity
						style={{ justifyContent: 'center', alignItems: 'center', width: '100%', height: '100%' }}
						onPress={() => setModalHintPass(true)}>
						<Icon type='Feather' name='copy' style={{ color: '#fff', fontSize: 24, paddingRight: 0 }} />
					</TouchableOpacity>
				</Fab>
			) : null} */}
        </>
    )
}

const UI = StyleSheet.create({
    container: {
        // flex: 1,
        // height: 600,
        alignContent: 'space-between',
        justifyContent: 'space-between',
    },
    image: {
        alignContent: 'flex-start',
        alignItems: 'center',
        height: 80,
        justifyContent: 'flex-start',
        marginVertical: 10,
    },
})
