import React, { useEffect, useState } from 'react'

import Text from '../Text'

const BlinkView = ({ style, children }) => {
    const [showText, setShowText] = useState(true)

    useEffect(() => {
        // Change the state every second or the time given by User.
        const interval = setInterval(() => {
            setShowText((showText) => !showText)
        }, 500)
        return () => clearInterval(interval)
    }, [])

    return <Text style={[style, { opacity: !showText ? 0 : 1 }]}>{children}</Text>
}

export default BlinkView
