import React, { useCallback, useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { FlatList, RefreshControl, TextInput, View } from 'react-native'
import AntDesign from 'react-native-vector-icons/AntDesign'
import { Container } from 'native-base'

import HeaderComponent from '../../../components/header'
import { ColTableData, RowTableData } from '../../../components/trading-component'
import HeaderList from '../../../components/trading-component/header-list'
import { StoreContext } from '../../../store'
import { dimensions, fontSizes } from '../../../styles'
import { eventList, FormatNumber, glb_sv, reqFunct, Screens, wait } from '../../../utils'
import sendRequest from '../../../utils/sendRequest'

// Khai báo ServiceInfo (nếu có)
const ServiceInfo = {
    GET_LIST_ANNOUNCEMENT_ORDER: {
        reqFunct: reqFunct.GET_LIST_ANNOUNCEMENT_ORDER, // Thêm giao dịch thông báo nộp tiền
        WorkerName: 'FOSqOrder01',
        ServiceName: 'FOSqOrder01_Common_0508_1',
        ClientSentTime: '0',
        Operation: 'I',
    },
}
// Khai báo component
const AnnouncementOrderLayout = ({ navigation }) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()
    const colSpan = [3, 3, 4]

    const advOrderListTemp = useRef([])
    const [originalAdvOrderList, setOriginalAdvOrderList] = useState([])
    const [filteredAdvOrderList, setFilteredAdvOrderList] = useState([])

    const [refreshing, setRefreshing] = useState(false)
    const [searchStockSymbol, setSearchStockSymbol] = useState('')

    useEffect(() => {
        getListAnnouncementOrder() // lấy danh sách lệnh quảng cáo
        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.LOGIN_SUCCESS) {
                // reCall service FOSq
                getListAnnouncementOrder()
            }
        })

        return () => {
            commonEvent.unsubscribe()
        }
    }, [refreshing])

    const getListAnnouncementOrder = () => {
        advOrderListTemp.current = []
        setOriginalAdvOrderList([])
        setFilteredAdvOrderList([])

        const inputParams = ['TODAY']
        sendRequest(ServiceInfo.GET_LIST_ANNOUNCEMENT_ORDER, inputParams, handleGetListAnnouncementOrder)
        // setRefreshing(false);
    }

    const filterOrderList = (stockSymbol) => {
        setSearchStockSymbol(stockSymbol.toUpperCase())
        if (stockSymbol.trim().length < 3) {
            setFilteredAdvOrderList(originalAdvOrderList)
            return
        }

        const newList = originalAdvOrderList.filter((item) => item.c2.includes(stockSymbol.toUpperCase().trim()))
        setFilteredAdvOrderList(newList)
    }

    const handleGetListAnnouncementOrder = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {}
            // jsondata.sort(compare);
            advOrderListTemp.current = advOrderListTemp.current.concat(jsondata)
            if (Number(message.Packet) <= 0) {
                const data = advOrderListTemp.current.map((item) => {
                    if (item.c0.length >= 6) {
                        item.c0 = item.c0.substr(0, 2) + ':' + item.c0.substr(2, 2) + ':' + item.c0.substr(4)
                    }
                    return item
                })

                setOriginalAdvOrderList(data)
                setFilteredAdvOrderList(data)
            }
        }
    }

    const onRefresh = useCallback(() => {
        setRefreshing(true)
        wait(300).then(() => setRefreshing(false))
    }, [])
    const ViewListAnnouncementOrder = ({ item }) => {
        return (
            <RowTableData
                type="table"
                onPress={() =>
                    navigation.navigate(Screens.DETAIL_ANNOUNCEMENT_ORDER, {
                        data: item,
                    })
                }
            >
                <ColTableData
                    colSpan={colSpan[0]}
                    text={item.c2}
                    typeOrder={item.c3 === '1' ? 'buy' : 'sell'}
                    // textAlign="left"
                />
                <ColTableData colSpan={colSpan[1]} text={FormatNumber(item.c5)} textAlign="left" />
                <ColTableData colSpan={colSpan[1]} text={FormatNumber(item.c4, 0, 0)} textAlign="center" />
                <ColTableData colSpan={colSpan[1]} text={item.c0} textAlign="right" />
            </RowTableData>
        )
    }
    return (
        <Container>
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft
                navigation={navigation}
                title={t('title_announcement_order')}
                titleAlgin="flex-start"
                transparent
            />
            <View style={{ backgroundColor: styles.PRIMARY__BG__COLOR, flex: 1 }}>
                <View style={{ height: 30, flexDirection: 'row', marginStart: dimensions.vertical(16) }}>
                    <AntDesign color={styles.SECOND__CONTENT__COLOR} name="search1" size={fontSizes.normal} style={{ marginRight: 5, alignSelf: 'center' }} />
                    <TextInput
                        autoCapitalize="characters"
                        maxLength={10}
                        placeholder={t('input_symbol')}
                        placeholderTextColor={styles.SECOND__CONTENT__COLOR}
                        style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal, padding: 0, paddingLeft: 8 }}
                        value={searchStockSymbol}
                        onChangeText={(text) => filterOrderList(text)}
                    />
                </View>
                <HeaderList typeHeader="AUNOUNCEMENT_ORDER" />
                <View>
                    <FlatList
                        data={filteredAdvOrderList}
                        keyExtractor={(item, index) => String(index)}
                        refreshControl={
                            <RefreshControl
                                refreshing={refreshing}
                                onRefresh={onRefresh}
                                // title={t('pull_refresh')}
                                // titleColor={styles.PRIMARY__CONTENT__COLOR}
                                tintColor={styles.PRIMARY__CONTENT__COLOR}
                            />
                        }
                        renderItem={ViewListAnnouncementOrder}
                        style={{
                            marginBottom: dimensions.vertical(32),
                            paddingHorizontal: dimensions.moderate(16),
                        }}
                    />
                </View>
            </View>
        </Container>
    )
}

export default AnnouncementOrderLayout
