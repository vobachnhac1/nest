import React, { memo } from 'react'
import { Platform, View } from 'react-native'
import { WebView } from 'react-native-webview'
import cloneDeep from 'lodash/cloneDeep'
import isEqual from 'lodash/isEqual'

import { StoreContext } from '../../../store'
import Chart from '../../f2-chart'

const IOS = Platform.OS === 'ios' ? true : false

const ChartBuySell = ({ TP }) => {
    if (!TP.length) return <View />
    const { styles } = React.useContext(StoreContext)
    const data = cloneDeep(TP).filter((e) => e.t132 !== 777777710000 && e.t133 !== 777777710000 && e.t132 !== 777777720000 && e.t133 !== 777777720000)

    const arr = data
        .map((e) => {
            return {
                qty: e.t1321,
                price: e.t132,
                type: 'buy',
            }
        })
        .concat(
            data.map((e) => {
                return {
                    qty: e.t1331,
                    price: e.t133,
                    type: 'sell',
                }
            }),
        )
    arr.push(
        {
            qty: 0,
            price: data[0] ? (data[0].t132 + data[0].t133) / 2 : 0,
            type: 'buy',
        },
        {
            qty: 0,
            price: data[0] ? (data[0].t132 + data[0].t133) / 2 : 0,
            type: 'sell',
        },
    )
    arr.sort(function (a, b) {
        if (a.price > b.price) return 1
        if (a.price < b.price) return -1
        return 0
    })

    return (
        <View style={{ height: 100, backgroundColor: styles.PRIMARY__BG__COLOR }}>
            <Chart
                data={arr.filter((e) => e.price !== 0)}
                initScript={IOS ? chartPriceIOS(arr.filter((e) => e.price !== 0)) : chartPriceAndroid(arr.filter((e) => e.price !== 0))}
                webView={WebView}
            />
        </View>
    )
}

export default memo(ChartBuySell, areEqual)

function areEqual(prevProps, nextProps) {
    if (isEqual(nextProps.TP, prevProps.TP)) return true
    else return false
}

const chartPriceAndroid = (data) => `
setTimeout(() => {
const chart = new F2.Chart({
  id: 'chart',
  pixelRatio: window.devicePixelRatio,
});
chart.source(${JSON.stringify(data)}, {
    price: {
        range: [ 0, 1 ],
        type: 'cat',
        tickCount: 5
    },
    qty: {
        tickCount: 3
    },
    grid: (text, index, total) => {
        return {
            stroke: '#cacaca'
        }
    },
});

chart.axis('price', {
    label: function label(text, index, total, arr) {
        return {
            text: formatNumber(text * 1),
            // text,
            fill: '#cacaca'
        };
    },
    grid: function grid(text) {
        return {
            stroke: '#888888',
            lineWidth: 0
        }
    },
    line: {
        stroke: 'transparent',
        lineWidth: 0
    }
});

chart.axis('qty', {
    position: 'right',
    label: function label(text) {
        return {
            text: formatNumber(text * 1),
            fill: '#cacaca'
        };
    },
    grid: function grid(text) {
        return {
            stroke: '#888888',
            lineWidth: 0
        }
    },
    line: {
        stroke: 'transparent',
        lineWidth: 0
    }
});

chart.legend(false)
chart.tooltip(false)
chart.line().position('price*qty')
.color('type', function(val) {
  if (val === 'buy') {
    return '#0EBE8A';
  } else if (val === 'sell') {
    return '#C11D48';
  }
}).style({
  lineWidth: 1
});;
chart.area().position('price*qty')
.color('type', function(val) {
    if (val === 'buy') {
        return '#0EBE8A';
      } else if (val === 'sell') {
        return '#C11D48';
      }
});

chart.render();
window.chart = chart;
},1000);
true;
`

const chartPriceIOS = (data) => `
const chart = new F2.Chart({
  id: 'chart',
  pixelRatio: window.devicePixelRatio,
});
chart.source(${JSON.stringify(data)}, {
    price: {
        range: [ 0, 1 ],
        tickCount: 5
    },
    qty: {
        tickCount: 3
    },
    grid: (text, index, total) => {
        return {
            stroke: '#cacaca'
        }
    },
});

chart.axis('price', {
    label: function label(text, index, total, arr) {
        return {
            text: formatNumber(text * 1),
            // text,
            fill: '#cacaca'
        };
    },
    grid: function grid(text) {
        return {
            stroke: '#888888',
            lineWidth: 0
        }
    },
    line: {
        stroke: 'transparent',
        lineWidth: 0
    }
});

chart.axis('qty', {
    position: 'right',
    label: function label(text) {
        return {
            text: formatNumber(text * 1),
            fill: '#cacaca'
        };
    },
    grid: function grid(text) {
        return {
            stroke: '#888888',
            lineWidth: 0
        }
    },
    line: {
        stroke: 'transparent',
        lineWidth: 0
    }
});

chart.legend(false)
chart.tooltip(false)
chart.line().position('price*qty')
.color('type', function(val) {
  if (val === 'buy') {
    return '#0EBE8A';
  } else if (val === 'sell') {
    return '#C11D48';
  }
}).style({
  lineWidth: 1
});;
chart.area().position('price*qty')
.color('type', function(val) {
    if (val === 'buy') {
        return '#0EBE8A';
      } else if (val === 'sell') {
        return '#C11D48';
      }
});

chart.render();
window.chart = chart;
true;
`
