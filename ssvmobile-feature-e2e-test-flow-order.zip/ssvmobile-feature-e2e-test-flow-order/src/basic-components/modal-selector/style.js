import { StyleSheet } from 'react-native'

const PADDING = 8
const BORDER_RADIUS = 5
const FONT_SIZE = 16
const HIGHLIGHT_COLOR = 'rgba(0,118,255,0.9)'

export default StyleSheet.create({
    cancelContainer: {
        alignSelf: 'stretch',
    },

    cancelStyle: {
        backgroundColor: 'rgba(255,255,255,0.8)',
        borderRadius: BORDER_RADIUS,
        padding: PADDING,
    },

    cancelTextStyle: {
        color: '#333',
        fontSize: FONT_SIZE,
        textAlign: 'center',
    },

    initValueTextStyle: {
        color: HIGHLIGHT_COLOR,
        fontSize: FONT_SIZE,
        textAlign: 'center',
    },

    optionContainer: {
        backgroundColor: 'rgba(255,255,255,0.8)',
        borderRadius: BORDER_RADIUS,
        flexShrink: 1,
        marginBottom: 8,
        padding: PADDING,
    },

    optionStyle: {
        borderBottomColor: '#ccc',
        borderBottomWidth: 1,
        padding: PADDING,
    },

    optionTextStyle: {
        color: '#333',
        fontSize: FONT_SIZE,
        textAlign: 'center',
    },

    overlayStyle: {
        backgroundColor: 'rgba(0,0,0,0.7)',
        flex: 1,
        justifyContent: 'center',
        padding: '5%',
    },

    sectionStyle: {
        borderBottomColor: '#ccc',
        borderBottomWidth: 1,
        padding: PADDING * 2,
    },

    sectionTextStyle: {
        fontSize: FONT_SIZE,
        textAlign: 'center',
    },

    selectStyle: {
        borderColor: '#ccc',
        borderRadius: BORDER_RADIUS,
        borderWidth: 1,
        padding: PADDING,
    },

    selectTextStyle: {
        color: HIGHLIGHT_COLOR,
        fontSize: FONT_SIZE,
        textAlign: 'center',
    },
})
