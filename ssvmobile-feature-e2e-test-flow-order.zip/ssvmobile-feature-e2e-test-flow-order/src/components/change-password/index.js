import React, { useContext, useLayoutEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { InteractionManager, Pressable } from 'react-native'
import RNRestart from 'react-native-restart'
import ToastGlobal from 'react-native-toast-message'
import ModalController from '@mts-components/appModal/modalControlller'
import getUniqueIdDevice from '@mts-utils/getUniqueIdDevice'
import { CommonActions } from '@react-navigation/native'
import { Container, Content, Form, Icon, Input, Item } from 'native-base'
import SyncStorage from 'sync-storage'

// import Spinner from 'react-native-loading-spinner-overlay';
import { Text } from '../../basic-components'
import HeaderComponent from '../../components/header'
import ModalLoading from '../../components/modal-loading'
import ModalAuthenOtp from '../../layouts/login/modal-authen-otp'
import { StoreContext } from '../../store'
import { dimensions, fontSizes, fontWeights, IconSvg } from '../../styles'
import { UIcomponent } from '../../styles/appUI'
import { dataCryption, glb_sv, reqFunct, Screens, sendRequest, socket_sv, STORE_KEY } from '../../utils'
import { ButtonCustom } from '../trading-component'

const ServiceInfo = {
    CHANGE_PASSWORD_LOGIN: {
        reqFunct: reqFunct.CHANGE_PASSWORD_LOGIN,
        WorkerName: 'FOSxID01',
        ServiceName: 'FOSxID01_Management',
        Operation: 'U',
        ClientSentTime: '0',
    },

    CHANGE_PASSWORD_ORDER: {
        reqFunct: reqFunct.CHANGE_PASSWORD_ORDER,
        WorkerName: 'FOSxAccount',
        ServiceName: 'FOSxAccount_0102_1',
        Operation: 'U',
        ClientSentTime: '0',
    },
}

export default function ChangePasswordLogin({ navigation, route }) {
    const { type } = route.params

    const { styles, setAuth } = useContext(StoreContext)
    const { t } = useTranslation()

    const curr_pass_ref = useRef(null)
    const emailRef = useRef(null)
    const phoneRef = useRef(null)
    const fgtPass_SendReqFlag = useRef(false)

    const [curr_pass, setcurr_pass] = useState('')
    const [new_pass, setnew_pass] = useState('')
    const [new_pass_cfm, setnew_pass_cfm] = useState('')

    const [disabled, setDisabled] = useState(true)

    const [showCurPass, setShowCurPass] = useState(false)
    const [showNewPass, setShowNewPass] = useState(false)
    const [showNewAgianPass, setShowNewAgianPass] = useState(false)

    const [spinner, setSpinner] = useState(false)

    const [timeOTP, setTimeOTP] = useState(0)
    const [visibleModalAuthen, setVisibleModalAuthen] = useState(false)

    const [typeSendOTP, setTypeSendOTP] = useState('')

    const [typeModalAuthen, setTypeModalAuthen] = useState('')

    const changePassword = () => {
        console.log('Change pass >>>>>>>>>>>>>>', { curr_pass, new_pass, new_pass_cfm, fgtPass_SendReqFlag })
        if (!curr_pass || curr_pass.trim().length < 6 || curr_pass.trim().length > 30) {
            curr_pass_ref.current && curr_pass_ref.current._root.focus()
            // Toast.show({
            //     text: t('login_pass_length'),
            //     type: 'warning',
            //     position: 'bottom'
            // })
            ToastGlobal.show({
                text2: t('login_pass_length'),
                type: 'warning',
            })
            return
        }
        if (!new_pass || new_pass.trim().length < 6 || new_pass.trim().length > 30) {
            emailRef.current && emailRef.current._root.focus()
            // Toast.show({
            //     text: t('chgLoginPass_newCode'),
            //     type: 'warning',
            //     position: 'bottom'
            // })
            ToastGlobal.show({
                text2: t('chgLoginPass_newCode'),
                type: 'warning',
            })
            return
        }
        if (!new_pass_cfm || new_pass_cfm.trim().length < 6 || new_pass_cfm.trim().length > 30) {
            phoneRef.current && phoneRef.current._root.focus()
            // Toast.show({
            //     text: t('login_pass_length'),
            //     type: 'warning',
            //     position: 'bottom'
            // })
            ToastGlobal.show({
                text2: t('login_pass_length'),
                type: 'warning',
            })
            return
        }
        if (new_pass_cfm !== new_pass) {
            phoneRef.current && phoneRef.current._root.focus()
            // Toast.show({
            //     text: t('pass_confirm_not_correct'),
            //     type: 'warning',
            //     position: 'bottom'
            // })
            ToastGlobal.show({
                text2: t('pass_confirm_not_correct'),
                type: 'warning',
            })
            return
        }

        if (fgtPass_SendReqFlag.current) {
            return
        }
        fgtPass_SendReqFlag.current = true

        const curpass = dataCryption.encryptString(curr_pass.trim())
        const newpass = dataCryption.encryptString(new_pass.trim())
        const InVal = ['chgpwd', glb_sv.credentials.username, curpass, newpass, newpass, getUniqueIdDevice()]
        sendRequest(ServiceInfo.CHANGE_PASSWORD_LOGIN, InVal, changePasswordResultProc, true, changePasswordResultProcTimeout)
        setTimeout(() => {
            setSpinner(true)
            setTimeOTP(0)
        }, 0)
    }

    const changeTradingPassword = (isAuthen) => {
        if (new_pass_cfm !== new_pass) {
            phoneRef.current && phoneRef.current._root.focus()
            ToastGlobal.show({
                text2: t('pass_confirm_not_correct'),
                type: 'warning',
            })
            return
        }

        if (!isAuthen) {
            navigation.navigate(Screens.OTP_MODAL, {
                transactionOTP: true,
                otp_Type: Number(glb_sv.objShareGlb.userInfo.c6),
                functCallback: changeTradingPassword,
            })
            return
        }

        if (fgtPass_SendReqFlag.current) {
            return
        }

        fgtPass_SendReqFlag.current = true
        const userID = glb_sv.objShareGlb.AcntMain
        if (!userID) return

        const curpass = dataCryption.encryptString(curr_pass.trim())
        const newpass = dataCryption.encryptString(new_pass.trim())
        const InVal = [userID, curpass, newpass]
        sendRequest(ServiceInfo.CHANGE_PASSWORD_ORDER, InVal, changePasswordOrderResultProc, true, changePasswordResultProcTimeout)
        setTimeout(() => {
            setSpinner(true)
        }, 0)
    }

    const changePasswordResultProcTimeout = ({ type }) => {
        fgtPass_SendReqFlag.current = false
        setSpinner(false)
        if (type === 'timeout') {
            // navigation.navigate(Screens.ALERT_MODAL, {
            // icon: <IconSvg.ErrorIcon color={styles.WARN__COLOR} />,
            // title: t('common_notify'),
            // content: t('request_hanlde_not_success_try_again'),
            // typeColor: styles.WARN__COLOR,
            // })

            ModalController.showModal({
                icon: <IconSvg.ErrorIcon color={styles.WARN__COLOR} />,
                title: t('common_notify'),
                content: t('request_hanlde_not_success_try_again'),
                typeColor: styles.WARN__COLOR,
            })
        }
    }

    const changePasswordOrderResultProc = (reqInfoMap, message) => {
        fgtPass_SendReqFlag.current = false
        setSpinner(false)
        const errmsg = message.Message
        if (Number(message.Result) === 0) {
            // navigation.navigate(Screens.ALERT_MODAL, {
            // title: t('common_notify'),
            // content: errmsg,
            // typeColor: styles.WARN__COLOR,
            // })
            ModalController.showModal({
                title: t('common_notify'),
                content: errmsg,
                typeColor: styles.WARN__COLOR,
            })
        } else {
            // navigation.navigate(Screens.ALERT_MODAL, {
            // title: t('common_notify'),
            // content: errmsg,
            // typeColor: styles.SUCCESS__COLOR,
            // linkCallback: () => (type === 'change_login' ? RNRestart.Restart() : navigation.pop()),
            // })
            ModalController.showModal({
                title: t('common_notify'),
                content: errmsg,
                typeColor: styles.SUCCESS__COLOR,
                linkCallback: () => (type === 'change_login' ? RNRestart.Restart() : navigation.pop()),
            })
        }
    }

    const changePasswordResultProc = (reqInfoMap, message) => {
        console.log('message', message)
        fgtPass_SendReqFlag.current = false
        setSpinner(false)
        const errmsg = message.Message
        if (Number(message.Result) === 0) {
            // navigation.navigate(Screens.ALERT_MODAL, {
            // icon: <IconSvg.ErrorIcon color={styles.WARN__COLOR} />,
            // title: t('common_notify'),
            // content: errmsg,
            // typeColor: styles.WARN__COLOR,
            // })
            ModalController.showModal({
                icon: <IconSvg.ErrorIcon color={styles.WARN__COLOR} />,
                title: t('common_notify'),
                content: errmsg,
                typeColor: styles.WARN__COLOR,
            })
        } else {
            let type = '',
                time = 'get_new_otp'
            try {
                type = message.Data ? JSON.parse(message.Data)[0].c0 : 'email'
                time = message.Data ? JSON.parse(message.Data)[0].c1 : 'get_new_otp'
            } catch (err) {
                console.log(err)
            }

            setTypeSendOTP(type === 'email' ? 'email' : 'phone')
            setTimeOTP(time === 'get_new_otp' ? 'get_new_otp' : Number(time))
            setTypeModalAuthen('change_password')
            InteractionManager.runAfterInteractions(() => {
                setTimeout(() => {
                    setVisibleModalAuthen(true)
                }, 500)
            })
        }
    }

    useLayoutEffect(() => {
        // console.log('useLayoutEffect type: ', type)
        if (type === 'change_login') {
            if (curr_pass && curr_pass.trim().length > 5 && new_pass && new_pass.trim().length > 5 && new_pass_cfm && new_pass_cfm.trim().length > 5) {
                setDisabled(false)
            } else {
                setDisabled(true)
            }
        } else {
            if (
                curr_pass &&
                curr_pass.trim().length > 3 &&
                curr_pass.trim().length < 7 &&
                new_pass &&
                new_pass.trim().length > 3 &&
                new_pass.trim().length < 7 &&
                new_pass_cfm &&
                new_pass_cfm.trim().length > 3 &&
                new_pass_cfm.trim().length < 7
            ) {
                setDisabled(false)
            } else {
                setDisabled(true)
            }
        }
    }, [curr_pass, new_pass, new_pass_cfm])

    const callbackAfterChangePassword = () => {
        // navigation.navigate(Screens.ALERT_MODAL, {
        // icon: <IconSvg.ErrorIcon color={styles.SUCCESS__COLOR} />,
        // title: t('common_notify'),
        // content: t('pass_login_is_change_success'),
        // typeColor: styles.SUCCESS__COLOR,
        // linkCallback: () => {
        //     setAuth(false)
        //     navigation.dispatch((state) => {
        //         const routes = state.routes.filter((r) => r.name !== Screens.CHANGE_PASSWORD && r.name !== Screens.USER_INFO)
        //         routes.push({ name: Screens.SIGN_IN })
        //         return CommonActions.reset({
        //             ...state,
        //             routes,
        //             index: routes.length - 1,
        //         })
        //     })
        //     socket_sv.disSocketTrading()
        //     glb_sv.LastConnectStatus = 'non_authen'
        //     SyncStorage.set(STORE_KEY.AutoLoginMode, false)
        // },
        // })
        ModalController.showModal({
            icon: <IconSvg.ErrorIcon color={styles.SUCCESS__COLOR} />,
            title: t('common_notify'),
            content: t('pass_login_is_change_success'),
            typeColor: styles.SUCCESS__COLOR,
            linkCallback: () => {
                setAuth(false)
                navigation.dispatch((state) => {
                    const routes = state.routes.filter((r) => r.name !== Screens.CHANGE_PASSWORD && r.name !== Screens.USER_INFO)
                    routes.push({ name: Screens.SIGN_IN })
                    return CommonActions.reset({
                        ...state,
                        routes,
                        index: routes.length - 1,
                    })
                })
                socket_sv.disSocketTrading()
                glb_sv.LastConnectStatus = 'non_authen'
                SyncStorage.set(STORE_KEY.AutoLoginMode, false)
            },
        })
    }

    const openModalResetPhoneCode = () => {
        setTimeOTP('get_new_otp')
        setTypeModalAuthen('change_phonecode')
        setTimeout(() => {
            setVisibleModalAuthen(true)
        }, 0)
    }

    return (
        <Container
            style={{
                backgroundColor: styles.PRIMARY__BG__COLOR,
            }}
        >
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft
                navigation={navigation}
                title={type === 'change_login' ? t('title_change_login_pass') : t('title_change_order_pass')}
                titleAlgin="flex-start"
                transparent
            />
            <Content style={{ paddingHorizontal: 10 }}>
                <Form style={UIcomponent.Form}>
                    <Item
                        regular
                        style={{
                            borderRadius: 8,
                            borderColor: styles.SECOND__BG__COLOR,
                            marginVertical: dimensions.halfVerticalIndent,
                            marginTop: dimensions.verticalIndent,
                            backgroundColor: styles.INPUT__BG,
                        }}
                    >
                        <Icon active name="lock" style={{ color: styles.PRIMARY__CONTENT__COLOR }} type="AntDesign" />
                        <Input
                            maxLength={type === 'change_login' ? 30 : 6}
                            placeholder={t('login_pass_curr')}
                            placeholderTextColor={styles.PLACEHODLER__COLOR}
                            ref={curr_pass_ref}
                            returnKeyType="next"
                            secureTextEntry={!showCurPass}
                            style={{
                                fontSize: fontSizes.medium,
                                color: styles.PRIMARY__CONTENT__COLOR,
                                backgroundColor: styles.INPUT__BG,
                            }}
                            textContentType="password"
                            value={curr_pass}
                            onChangeText={(value) => setcurr_pass(value)}
                            onSubmitEditing={() => emailRef.current._root.focus()}
                        />
                        {showCurPass ? (
                            <Icon
                                color={styles.BLUE__COLOR}
                                name="eye"
                                style={{ color: styles.BLUE__COLOR }}
                                type="AntDesign"
                                onPress={() => setShowCurPass((showCurPass) => !showCurPass)}
                            />
                        ) : (
                            <Icon
                                color={styles.PRIMARY__CONTENT__COLOR}
                                name="eye-with-line"
                                style={{ color: styles.PRIMARY__CONTENT__COLOR }}
                                type="Entypo"
                                onPress={() => setShowCurPass((showCurPass) => !showCurPass)}
                            />
                        )}
                    </Item>
                    <Item
                        regular
                        style={{
                            borderRadius: 8,
                            borderColor: styles.SECOND__BG__COLOR,
                            backgroundColor: styles.INPUT__BG,
                            marginVertical: dimensions.halfVerticalIndent,
                        }}
                    >
                        <Icon active name="lock" style={{ color: styles.PRIMARY__CONTENT__COLOR }} type="AntDesign" />
                        <Input
                            maxLength={type === 'change_login' ? 30 : 6}
                            placeholder={t('login_pass_new')}
                            placeholderTextColor={styles.PLACEHODLER__COLOR}
                            ref={emailRef}
                            returnKeyType="next"
                            secureTextEntry={!showNewPass}
                            style={{ fontSize: fontSizes.medium, color: styles.PRIMARY__CONTENT__COLOR, backgroundColor: styles.INPUT__BG }}
                            textContentType="newPassword"
                            value={new_pass}
                            onChangeText={(value) => setnew_pass(value)}
                            onSubmitEditing={() => phoneRef.current._root.focus()}
                        />
                        {showNewPass ? (
                            <Icon
                                color={styles.BLUE__COLOR}
                                name="eye"
                                style={{ color: styles.BLUE__COLOR }}
                                type="AntDesign"
                                onPress={() => setShowNewPass((showNewPass) => !showNewPass)}
                            />
                        ) : (
                            <Icon
                                color={styles.PRIMARY__CONTENT__COLOR}
                                name="eye-with-line"
                                style={{ color: styles.PRIMARY__CONTENT__COLOR }}
                                type="Entypo"
                                onPress={() => setShowNewPass((showNewPass) => !showNewPass)}
                            />
                        )}
                    </Item>
                    <Item
                        regular
                        style={{
                            borderRadius: 8,
                            borderColor: styles.SECOND__BG__COLOR,
                            backgroundColor: styles.INPUT__BG,
                            marginVertical: dimensions.halfVerticalIndent,
                        }}
                    >
                        <Icon active name="lock" style={{ color: styles.PRIMARY__CONTENT__COLOR }} type="AntDesign" />
                        <Input
                            maxLength={type === 'change_login' ? 30 : 6}
                            placeholder={t('login_pass_new_cfm')}
                            placeholderTextColor={styles.PLACEHODLER__COLOR}
                            ref={phoneRef}
                            secureTextEntry={!showNewAgianPass}
                            style={{ fontSize: fontSizes.medium, color: styles.PRIMARY__CONTENT__COLOR, backgroundColor: styles.INPUT__BG }}
                            textContentType="newPassword"
                            value={new_pass_cfm}
                            onChangeText={(value) => setnew_pass_cfm(value)}
                        />
                        {showNewAgianPass ? (
                            <Icon
                                color={styles.BLUE__COLOR}
                                name="eye"
                                style={{ color: styles.BLUE__COLOR }}
                                type="AntDesign"
                                onPress={() => setShowNewAgianPass((showNewAgianPass) => !showNewAgianPass)}
                            />
                        ) : (
                            <Icon
                                color={styles.PRIMARY__CONTENT__COLOR}
                                name="eye-with-line"
                                style={{ color: styles.PRIMARY__CONTENT__COLOR }}
                                type="Entypo"
                                onPress={() => setShowNewAgianPass((showNewAgianPass) => !showNewAgianPass)}
                            />
                        )}
                    </Item>
                </Form>

                <Text style={{ fontSize: fontSizes.normal, color: styles.WARN__COLOR, marginBottom: dimensions.verticalIndent * 2 }}>
                    {type === 'change_login' ? t('password_rule') : t('password_rule_place_order')}
                </Text>

                <ButtonCustom
                    disabled={disabled}
                    text={t('common_button_change_pass')}
                    type="confirm"
                    onPress={() => (type === 'change_login' ? changePassword() : changeTradingPassword())}
                />
                <Pressable style={{ marginTop: 10, alignItems: 'center' }} onPress={openModalResetPhoneCode}>
                    <Text style={{ fontSize: fontSizes.medium, fontWeight: fontWeights.bold, color: styles.PRIMARY__CONTENT__COLOR }}>
                        {t('forget_phone_code')}
                    </Text>
                </Pressable>
            </Content>

            {spinner ? <ModalLoading content={t('common_processing')} visible={spinner} /> : null}

            {visibleModalAuthen ? (
                <ModalAuthenOtp
                    callbackAfterChangePassword={callbackAfterChangePassword}
                    callBackLogin={() => null}
                    new_pass={new_pass}
                    setVisible={setVisibleModalAuthen}
                    time={timeOTP}
                    type={typeModalAuthen}
                    typeSendOTP={typeSendOTP}
                    visible={visibleModalAuthen}
                />
            ) : null}
        </Container>
    )
}
