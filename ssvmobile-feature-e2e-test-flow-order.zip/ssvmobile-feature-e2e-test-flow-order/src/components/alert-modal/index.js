import React, { memo, useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { InteractionManager, KeyboardAvoidingView, StyleSheet, TouchableWithoutFeedback, View } from 'react-native'
import { COLORS } from '@mts-styles/colors'
import { Button } from 'native-base'

import { Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { dimensions, fontSizes, fontWeights } from '../../styles'

const AlertModal = ({ navigation, route: { params } }) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()
    const notTouch = () => null

    const handleConfirm = () => {
        navigation.pop()
        // Waiting animation
        InteractionManager.runAfterInteractions(() => {
            setTimeout(() => {
                if (typeof params.linkCallback === 'function') params.linkCallback()
                else if (typeof params.onCallBack === 'function') params.onCallBack()
            }, 0)
        })
    }

    const handleCancel = () => {
        navigation.pop()
        InteractionManager.runAfterInteractions(() => {
            if (params.cancelCallBack) {
                params.cancelCallBack()
            } else if (!params.showCancel) {
                if (params.linkCallback) params.linkCallback()
            } else if (typeof params.onCallBack === 'function') params.onCallBack()
        })
    }

    return (
        <TouchableWithoutFeedback onPress={handleCancel}>
            <View style={[UI.AlertWrapper, { shadowColor: params.typeColor || styles.PRIMARY__BG__COLOR }]}>
                <KeyboardAvoidingView behavior="padding">
                    <View
                        style={[
                            UI.AlertView,
                            {
                                backgroundColor: styles.PRIMARY__BG__COLOR,
                                paddingBottom: params?.footerComponent ? dimensions.vertical(16) : dimensions.vertical(32),
                            },
                        ]}
                    >
                        {params.icon}
                        {params.title ? (
                            <Text style={[UI.AlertTextTitle, { color: params.colorTitle || styles.PRIMARY__CONTENT__COLOR }]} onPress={notTouch}>
                                {params.title}
                            </Text>
                        ) : (
                            <View style={{ height: dimensions.vertical(16) }} />
                        )}

                        <Text
                            style={[
                                UI.AlertTextContent,
                                {
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                    marginBottom: dimensions.moderate(params.middleComponent ? 0 : 32),
                                },
                            ]}
                            onPress={notTouch}
                        >
                            {params.content}
                        </Text>
                        {params.middleComponent ? params.middleComponent : null}
                        <View>
                            <Button block style={{ backgroundColor: styles.PRIMARY, width: dimensions.moderate(200) }} transparent onPress={handleConfirm}>
                                <Text style={{ color: COLORS.WHITE, fontSize: fontSizes.normal }}>{params.titleOK || t('common_Ok').toLocaleUpperCase()}</Text>
                            </Button>
                        </View>

                        {params.showCancel ? (
                            <View>
                                <Button block style={{ width: dimensions.moderate(200) }} transparent onPress={handleCancel}>
                                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal, opacity: 0.34 }}>
                                        {t('common_Cancel').toLocaleUpperCase()}
                                    </Text>
                                </Button>
                            </View>
                        ) : null}
                        <View style={{ width: '100%' }}>{params.footerComponent ? params.footerComponent : null}</View>
                    </View>
                </KeyboardAvoidingView>
            </View>
        </TouchableWithoutFeedback>
    )
}

export default memo(AlertModal)

const UI = StyleSheet.create({
    AlertTextContent: {
        fontSize: fontSizes.small,
        opacity: 0.64,
        textAlign: 'center',
    },
    AlertTextTitle: {
        fontSize: fontSizes.xmedium,
        fontWeight: fontWeights.semiBold,
        marginBottom: dimensions.vertical(16),
        marginTop: dimensions.vertical(32),
    },
    AlertView: {
        alignItems: 'center',
        borderRadius: 12,
        justifyContent: 'center',
        marginHorizontal: dimensions.moderate(18),
        paddingHorizontal: dimensions.moderate(28),
        paddingTop: dimensions.vertical(32),
    },
    AlertWrapper: {
        alignItems: 'center',
        backgroundColor: COLORS.TRANSPARENT,
        elevation: 18,
        flex: 1,
        justifyContent: 'center',
        shadowOffset: {
            width: 0,
            height: 0,
        },
        shadowOpacity: 0.48,
        shadowRadius: 11.95,
    },
})
