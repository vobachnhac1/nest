import React, { useContext, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { InteractionManager, View } from 'react-native'
import { getStatusBarHeight } from 'react-native-iphone-x-helper'
// import Spinner from 'react-native-loading-spinner-overlay'
import Modal from 'react-native-modal'
import ModalController from '@mts-components/appModal/modalControlller'
import moment from 'moment'
import { Button, Content } from 'native-base'

import IconBack from '../../assets/images/common/ic_back.svg'
import { FocusAwareStatusBar, Text, TextInput } from '../../basic-components'
import ModalLoading from '../../components/modal-loading'
import { ButtonCustom, RowData } from '../../components/trading-component'
import { useAlertModal, useAlertModalCommonCode, useModalOtpWhenErr } from '../../hoc'
import { StoreContext } from '../../store'
import { dimensions, fontSizes, IconSvg } from '../../styles'
import { dataCryption, eventList, FormatNumber, glb_sv, reqFunct, Screens, sendRequest } from '../../utils'

const ServiceInfo = {
    CANCEL_ADV_ORDER: {
        reqFunct: reqFunct.CANCEL_ADV_ORDER,
        WorkerName: 'FOSxOrder',
        ServiceName: 'FOSxOrder_0509_2',
        Operation: 'I',
        ClientSentTime: '0',
    },
}

const translateOrderTp = (value) => {
    if (value === '01') {
        return 'order_Limit'
    } else if (value === '02') {
        return 'order_Mp'
    } else if (value === '03') {
        return 'order_ATO'
    } else if (value === '04') {
        return 'order_ATC'
    } else if (value === '06') {
        return 'order_MOK'
    } else if (value === '07') {
        return 'order_MAK'
    } else if (value === '08') {
        return 'order_MTL'
    } else if (value === '15') {
        return 'order_PLO'
    } else return value
}

function AdvOrderDetail({ navigation, route }) {
    const { item } = route.params

    const { styles, theme } = useContext(StoreContext)
    const { t } = useTranslation()

    const [modalCancelOrder, setModalCancelOrder] = useState(false)
    const sendCancelOrderFlag = useRef(false)

    const [spinner, setSpinner] = useState(false)

    const [data, setData] = useState({ ...item })

    const [passTrading, setPassTrading] = useState('')

    const [appModelMessage, setAppModelMessage] = useState('')

    const colorOrderStatus = (value) => {
        if (value === '0') return styles.send_to_exchange_color
        else if (value === '1') return styles.send_to_exchange_color
        else if (value === '3') return styles.wait_to_match_color
        else if (value === '4') return styles.match_a_pieces_color
        else if (value === '5') return styles.match_a_pieces_color
        else if (value === '6') return ''
        else if (value === '7') return styles.reject_color
        else if (value === '8') return ''
        else if (value === '9') return ''
        else if (value === 'X') return styles.send_to_exchange_color
    }

    const sendCancelAdvOrder = () => {
        if (sendCancelOrderFlag.current) return
        sendCancelOrderFlag.current = true
        setModalCancelOrder(false)
        InteractionManager.runAfterInteractions(() => {
            setTimeout(() => {
                setSpinner(true)
                const passTradingEncryt = passTrading ? dataCryption.encryptString(passTrading) : ''
                const InputParams = [data.c17, data.c0, data.c1, passTradingEncryt, data.c22]
                sendRequest(ServiceInfo.CANCEL_ADV_ORDER, InputParams, handleSendCancelOrder, true, sendCancelOrderTimeout)
                setPassTrading('')
            }, 500)
        })
    }

    const sendCancelOrderTimeout = () => {
        sendCancelOrderFlag.current = false
        setSpinner(false)
        // navigation.navigate(Screens.ALERT_MODAL, {
        //     title: t('common_notify'),
        //     content: t('request_hanlde_not_success_try_again'),
        //     typeColor: styles.WARN__COLOR
        // })
    }

    const handleSendCancelOrder = (reqInfoMap, message) => {
        sendCancelOrderFlag.current = false
        setSpinner(false)
        if (Number(message.Result) === 0) {
            const { hasAlertCommonCode } = useAlertModalCommonCode(message, {})
            const { hasAlertErrOtp } = useModalOtpWhenErr(message, { continueVerify: !hasAlertCommonCode, callback: () => showModalAction() })
            useAlertModal(message, { continueVerify: !hasAlertErrOtp })
        } else {
            glb_sv.commonEvent.next({ type: eventList.REFRESH_ADVORDER_LIST })
            // setAppModelMessage(message.Message)
            //
            // navigation.navigate(Screens.ALERT_MODAL, {
            // icon: <IconSvg.ErrorIcon color={styles.SUCCESS__COLOR} />,
            // title: t('common_notify'),
            // content: message.Message,
            // typeColor: styles.SUCCESS__COLOR,
            // linkCallback: () => navigation.goBack(),
            // })
            ModalController.showModal({
                icon: <IconSvg.ErrorIcon color={styles.SUCCESS__COLOR} />,
                title: t('common_notify'),
                content: message.Message,
                typeColor: styles.SUCCESS__COLOR,
                linkCallback: () => navigation.goBack(),
            })
        }
    }

    const showModalAction = () => {
        setModalCancelOrder(true)
    }

    return (
        <View style={{ flex: 1, backgroundColor: styles.PRIMARY__BG__COLOR }}>
            <FocusAwareStatusBar backgroundColor={'transparent'} barStyle={theme.includes('DARK') ? 'light-content' : 'dark-content'} translucent={true} />
            <View
                style={{
                    flexDirection: 'row',
                    height: dimensions.vertical(35),
                    paddingHorizontal: dimensions.moderate(16),
                    marginTop: getStatusBarHeight() + 3,
                }}
            >
                <Button style={{ paddingTop: 0, paddingBottom: 0, height: dimensions.vertical(35) }} transparent onPress={() => navigation.pop()}>
                    <IconBack height={dimensions.moderate(24)} style={{ color: styles.ICON__PRIMARY }} width={dimensions.moderate(24)} />
                </Button>
                <View
                    style={{
                        flexDirection: 'column',
                        paddingHorizontal: dimensions.halfIndent,
                        justifyContent: 'center',
                        alignItems: 'flex-start',
                        flex: 1,
                    }}
                >
                    <Text style={{ fontSize: fontSizes.xmedium, color: styles.PRIMARY__CONTENT__COLOR }} onPress={() => navigation.pop()}>
                        {t('order_detail')}
                    </Text>
                </View>
            </View>

            {spinner ? <ModalLoading content={t('common_processing')} visible={spinner} /> : null}
            {/* <Spinner visible={spinner} textContent={'...'} textStyle={{ color: styles.PRIMARY__CONTENT__COLOR }} /> */}

            <Content>
                <RowData rightColor={data.c3 === '1' ? styles.UP__COLOR : styles.DOWN__COLOR} textLeft={t('hint_stock_search')} textRight={data.c4} />

                <RowData textLeft={t('qty')} textRight={FormatNumber(data.c6)} />

                <RowData textLeft={t('price')} textRight={FormatNumber(data.c7)} />

                <RowData textLeft={t('session')} textRight={data.c21} />

                <RowData textLeft={t('order')} textRight={t(translateOrderTp(data.c5))} />

                <RowData textLeft={t('effect_date')} textRight={data ? moment(data.c9, 'DDMMYYYY').format('DD/MM/YYYY') : ''} />
                <RowData textLeft={t('expire_date')} textRight={data ? moment(data.c10, 'DDMMYYYY').format('DD/MM/YYYY') : ''} />
                <RowData textLeft={t('place_order_time')} textRight={data ? moment(data.c12, 'DDMMYYYYHHmmss').format('DD/MM/YYYY HH:mm:ss') : ''} />

                <RowData rightColor={colorOrderStatus(data.c8)} textLeft={t('order_status')} textRight={data.c19} />

                {data.c8 === '2' || data.c8 === '3' ? null : (
                    <ButtonCustom
                        disabled={data.c8 === '2' || data.c8 === '3'}
                        text={t('info_cal_ord')}
                        type="cancel"
                        onPress={() => {
                            if (!glb_sv.checkOtp(navigation, showModalAction)) return
                            setModalCancelOrder(true)
                        }}
                    />
                )}
            </Content>

            {modalCancelOrder ? (
                <Modal
                    isVisible={modalCancelOrder}
                    useNativeDriver={true}
                    onBackButtonPress={() => {
                        setModalCancelOrder(false)
                        setPassTrading('')
                    }}
                    onBackdropPress={() => {
                        setModalCancelOrder(false)
                        setPassTrading('')
                    }}
                >
                    <View
                        style={{
                            backgroundColor: styles.HEADER__BG__COLOR,
                            paddingHorizontal: 20,
                            paddingTop: 32,
                            paddingBottom: 8,
                            justifyContent: 'flex-start',
                            borderRadius: 4,
                            borderColor: 'rgba(0, 0, 0, 0.1)',
                        }}
                    >
                        <View style={{ alignItems: 'center' }}>
                            <IconSvg.ErrorIcon color={styles.DOWN__COLOR} />
                        </View>
                        <Text style={{ marginVertical: 22, fontSize: fontSizes.big, color: styles.DOWN__COLOR, textAlign: 'center' }}>{t('info_cal_ord')}</Text>

                        <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal }}>{t('are_you_sure_you_want_cancel_order')}</Text>

                        {!glb_sv.isInvestorUser() ? (
                            <View style={{ flexDirection: 'row', paddingVertical: dimensions.moderate(8) }}>
                                <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('password_trading')}</Text>

                                <View style={{ borderBottomColor: styles.PRIMARY__BORDER__COLOR, borderBottomWidth: 1, flex: 1 }}>
                                    <TextInput
                                        maxLength={6}
                                        secureTextEntry
                                        style={{
                                            fontSize: fontSizes.medium,
                                            color: styles.PRIMARY__CONTENT__COLOR,
                                        }}
                                        value={passTrading}
                                        onChangeText={(value) => {
                                            setPassTrading(value)
                                        }}
                                    />
                                </View>
                            </View>
                        ) : null}

                        <Button
                            block
                            style={{
                                backgroundColor: styles.DOWN__COLOR,
                                justifyContent: 'center',
                                alignSelf: 'center',
                                marginTop: dimensions.vertical(25),
                                borderRadius: 8,
                                width: '100%',
                            }}
                            transparent
                            onPress={sendCancelAdvOrder}
                        >
                            <Text style={{ color: '#FFF', fontSize: fontSizes.small }}>{t('common_Ok')}</Text>
                        </Button>

                        <Button
                            block
                            style={{ justifyContent: 'center', alignSelf: 'center', width: '100%' }}
                            transparent
                            onPress={() => {
                                setModalCancelOrder(false)
                                setPassTrading('')
                            }}
                        >
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small, opacity: 0.34 }}>{t('common_Cancel')}</Text>
                        </Button>
                    </View>
                </Modal>
            ) : null}
        </View>
    )
}

export default AdvOrderDetail
