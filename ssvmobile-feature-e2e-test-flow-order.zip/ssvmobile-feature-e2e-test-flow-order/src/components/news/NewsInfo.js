import React, { useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { ActivityIndicator, View } from 'react-native'
import moment from 'moment'

import { Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { dimensions } from '../../styles'
import { glb_sv, reqFunct, Screens, sendRequest } from '../../utils'
import RowNews from './RowNews'

const ServiceInfo = {
    GET_NEWS_INTO_MARKET: {
        reqFunct: reqFunct.GET_NEWS_INTO_MARKET,
        WorkerName: 'FOSqNews',
        ServiceName: 'FOSqNews_NewsInfo',
        ClientSentTime: '0',
        Operation: 'Q',
    },
}

export default ({ type, navigation }) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()

    const [loading, setLoading] = useState(true)
    const [data, setData] = useState([])
    const newsList = useRef([])

    useEffect(() => {
        newsList.current = []
        const InputParams = ['03', type]
        sendRequest(ServiceInfo.GET_NEWS_INTO_MARKET, InputParams, getNewsResultProc, true, getNewsResultProcTimeout, null, 3000)
    }, [])

    const getNewsResultProcTimeout = () => {
        newsList.current = []
        setLoading(false)
    }

    const getNewsResultProc = (reqInfoMap, message) => {
        setLoading(false)
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata = []
            try {
                if (message.Data) {
                    jsondata = JSON.parse(glb_sv.filterStrBfParse(message.Data))
                }
            } catch (err) {
                console.error('getNewsResultProc error', err)
                return
            }
            newsList.current = newsList.current.concat(jsondata)
            if (Number(message.Packet) <= 0) {
                setData(newsList.current)
                console.log('getNewsResultProc -> newsList.current', newsList.current)
            }
        }
    }

    return (
        <View
            style={{ padding: dimensions.halfIndent, justifyContent: 'flex-start', alignItems: 'center', backgroundColor: styles.PRIMARY__BG__COLOR, flex: 1 }}
        >
            {loading ? (
                <View style={{ height: 200, justifyContent: 'center', alignItems: 'center' }}>
                    <ActivityIndicator />
                </View>
            ) : data.length ? (
                data.map((item) => (
                    <RowNews
                        key={item.c0}
                        link={item.c3}
                        styles={styles}
                        subtitle={item.c9 + ' ∙ ' + moment(item.c6, 'YYYYMMDDHHmmss').format('DD/MM HH:mm:ss')}
                        title={item.c4}
                        uri={item.c7}
                        onChange={(value) =>
                            navigation.navigate(Screens.NEWS_DETAIL, {
                                ...value,
                                idNews: item.c0,
                                isHTML: item.c15 === 'HTML',
                                c5: item.c15 === 'HTML' ? 'TEXT' : '',
                            })
                        }
                    />
                ))
            ) : (
                <Text style={{ color: styles.SECOND__CONTENT__COLOR }}>{t('common_NoDataFound')}</Text>
            )}
        </View>
    )
}
