import React, { Component, createRef } from 'react'
import { ActivityIndicator, Platform, StyleSheet, View } from 'react-native'
import deviceInfoModule from 'react-native-device-info'
import { ScrollView } from 'react-native-gesture-handler'
import { getStatusBarHeight } from 'react-native-status-bar-height'
import WebView from 'react-native-webview'

import { dimensions } from '../../../styles'
import { eventList, glb_sv } from '../../../utils'

const source = Platform.select({
    ios: require('../../../basic-components/custom-chart/index.html'),
    android: { uri: 'file:///android_asset/index.html' },
})

const isTable = deviceInfoModule.isTablet()
const hasNotch = deviceInfoModule.hasNotch()
const IOS = Platform.OS === 'ios' ? true : false

export default class ChartForeignerTrade extends Component {
    constructor(props) {
        super(props)
        this.chart = createRef()

        this.topFgrBuy =
            glb_sv.StatisticMarket.getStatisticData({
                key: props.exchange,
                time: '1D',
                topic: 'FRG_BUY_UP',
            }) || []
        this.topFgrSell =
            glb_sv.StatisticMarket.getStatisticData({
                key: props.exchange,
                time: '1D',
                topic: 'FRG_SELL_UP',
            }) || []

        this.state = {
            webviewKey: new Date().getTime(),
            loading: this.topFgrBuy.length === 0 && this.topFgrSell.length === 0 ? true : false,
        }
        this.height = this.props.height
    }

    componentDidMount() {
        this.eventMarket = glb_sv.eventMarket.subscribe((msg) => {
            if (msg.type === eventList.RESET_DATA) {
                this.chart.current &&
                    this.chart.current.injectJavaScript(`
                    window.topFgrBuy = [];
                    window.topFgrSell = [];
                    if (window.eventMarket) {
                        window.eventMarket.next({ type: 'highchart-realtime' })
                    }
                    true;
                `)
            }
            if (msg.type === eventList.UPDATE_STATISTIC && msg.time === '1D') {
                if (msg.key === this.props.exchange) {
                    const data = glb_sv.StatisticMarket.getStatisticData({
                        key: this.props.exchange,
                        time: '1D',
                        topic: msg.topic,
                    })
                    if (msg.topic === 'FRG_BUY_UP') {
                        this.topFgrBuy = data
                        this.chart.current &&
                            this.chart.current.injectJavaScript(`
                            window.topFgrBuy = ${JSON.stringify(data)};
                            if (window.eventMarket) {
                                window.eventMarket.next({ type: 'highchart-realtime' })
                            }
                            true;
                        `)
                    }
                    if (msg.topic === 'FRG_SELL_UP') {
                        this.topFgrSell = data
                        this.chart.current &&
                            this.chart.current.injectJavaScript(`
                            window.topFgrSell = ${JSON.stringify(data)};
                            if (window.eventMarket) {
                                window.eventMarket.next({ type: 'highchart-realtime' })
                            }
                            true;
                        `)
                    }
                }
            }

            if (msg.type === eventList.REQ_AFTER_SUB_FRG) {
                this.setState({ loading: false })
            }
        })

        setTimeout(() => {
            this.topFgrBuy =
                glb_sv.StatisticMarket.getStatisticData({
                    key: this.props.exchange,
                    time: '1D',
                    topic: 'FRG_BUY_UP',
                }) || []
            this.topFgrSell =
                glb_sv.StatisticMarket.getStatisticData({
                    key: this.props.exchange,
                    time: '1D',
                    topic: 'FRG_SELL_UP',
                }) || []
            this.chart.current &&
                this.chart.current.injectJavaScript(`
                window.topFgrBuy = ${JSON.stringify(this.topFgrBuy)};
                window.topFgrSell = ${JSON.stringify(this.topFgrSell)};
                if (window.eventMarket) {
                    window.eventMarket.next({ type: 'highchart-realtime' })
                }
                true;
            `)
        }, 2000)
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.exchange !== this.props.exchange) {
            this.topFgrBuy =
                glb_sv.StatisticMarket.getStatisticData({
                    key: nextProps.exchange,
                    time: '1D',
                    topic: 'FRG_BUY_UP',
                }) || []
            this.topFgrSell =
                glb_sv.StatisticMarket.getStatisticData({
                    key: nextProps.exchange,
                    time: '1D',
                    topic: 'FRG_SELL_UP',
                }) || []

            this.chart.current &&
                this.chart.current.injectJavaScript(`
                window.topFgrBuy = ${JSON.stringify(this.topFgrBuy)};
                window.topFgrSell = ${JSON.stringify(this.topFgrSell)};
                if (window.eventMarket) {
                    window.eventMarket.next({ type: 'highchart-realtime' })
                }
                true;
            `)
        }
        if (nextProps.t !== this.props.t) {
            this.topFgrBuy =
                glb_sv.StatisticMarket.getStatisticData({
                    key: nextProps.exchange,
                    time: '1D',
                    topic: 'FRG_BUY_UP',
                }) || []
            this.topFgrSell =
                glb_sv.StatisticMarket.getStatisticData({
                    key: nextProps.exchange,
                    time: '1D',
                    topic: 'FRG_SELL_UP',
                }) || []

            this.chart.current &&
                this.chart.current.injectJavaScript(`
                window.priceboard_total_value_foreign_buy = '${this.props.t('priceboard_total_value_foreign_buy')}';
                window.priceboard_total_value_foreign_sell = '${this.props.t('priceboard_total_value_foreign_sell')}';
                window.short_symbol = '${this.props.t('short_symbol')}';
                window.head_current_right = '${this.props.t('head_current_right')}';
                window.trade_total_net_value = '${this.props.t('trade_total_net_value')}';
                if (window.eventMarket) {
                    window.eventMarket.next({ type: 'change-language' })
                }
                true;
            `)
        }
    }
    getHeight = () => {
        // console.log('screen height==========>', dimensions.HIEGHT - this.height - (isTable ? 90 : (IOS && hasNotch ? 70 : 50)) - getStatusBarHeight(), this.height, dimensions.HIEGHT);
        return dimensions.HIEGHT - this.height - (isTable ? 90 : IOS && hasNotch ? 70 : 50) - getStatusBarHeight() - 5
    }

    componentWillUnmount() {
        this.eventMarket.unsubscribe()
    }

    reload = () => {
        this.setState({
            webviewKey: this.state.webviewKey + 1,
        })
    }

    shouldComponentUpdate(nextProps, nextState) {
        if (nextState.webviewKey !== this.state.webviewKey || nextState.loading !== this.state.loading) {
            return true
        }
        return false
    }

    render() {
        return (
            <>
                {this.state.loading && (
                    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
                        <ActivityIndicator />
                    </View>
                )}
                <WebView
                    allowUniversalAccessFromFileURLs={true}
                    androidHardwareAccelerationDisabled
                    androidLayerType="hardware"
                    domStorageEnabled={true}
                    source={source}
                    // source={{
                    //     uri: 'http://192.168.1.8:3000' || 'http://localhost:3000/',
                    // }}
                    injectedJavaScriptBeforeContentLoaded={`
                    window.priceboard_total_value_foreign_buy = '${this.props.t('priceboard_total_value_foreign_buy')}';
                    window.priceboard_total_value_foreign_sell = '${this.props.t('priceboard_total_value_foreign_sell')}';
                    window.short_symbol = '${this.props.t('short_symbol')}';
                    window.head_current_right = '${this.props.t('head_current_right')}';
                    window.trade_total_net_value = '${this.props.t('trade_total_net_value')}';
                    window.theme = '${this.props.theme}';
                    window.chartName = 'foreigner_trade';
                    window.topFgrBuy = ${JSON.stringify(this.topFgrBuy)};
                    window.topFgrSell = ${JSON.stringify(this.topFgrSell)}
                `}
                    javaScriptEnabled
                    key={this.state.webviewKey}
                    originWhitelist={['*']}
                    ref={this.chart}
                    scrollEnabled={false}
                    style={[styles.webView, { maxHeight: this.getHeight() }]}
                    onContentProcessDidTerminate={this.reload}
                />
            </>
        )
    }
}

const styles = StyleSheet.create({
    webView: {
        backgroundColor: 'transparent',
        flex: 1,
        maxHeight: '100%',
    },
})
