/* eslint-disable no-restricted-syntax */
import React, { useContext, useEffect, useRef } from 'react'
import { useTranslation } from 'react-i18next'
import { StyleSheet, View } from 'react-native'
import Modal from 'react-native-modal'
import reactotron from 'reactotron-react-native'
import ModalController from '@mts-components/appModal/modalControlller'
// import Spinner from 'react-native-loading-spinner-overlay'
import { ISwitchStep } from '@mts-layouts/eKYCFPT'
import { useSaveCurrentStep } from '@mts-layouts/eKYCFPT/hooks/useSaveCurrentStep'
import { useNavigation } from '@react-navigation/native'
import moment from 'moment'

import { Text } from '../../../../basic-components'
import { ButtonCustom, RowDataModal } from '../../../../components/trading-component'
import ModalContent from '../../../../components/trading-component/common/modal-content'
import { StoreContext } from '../../../../store'
import { StoreTrading } from '../../../../store-trading'
import { dimensions, fontSizes, IconSvg } from '../../../../styles'
import { eventList, glb_sv, reqFunct, Screens, sendRequest } from '../../../../utils'
import Analytics, { EkycAnalyticEvents } from '../../../../utils/TrackingData/Analytics'
import { configUIEkyc } from '../../config'
import ekycService from '../../ekycService'
import { removeSpecialSymbol, removeSpecialSymbolForAddress } from '../../helpers'

const ServiceInfo: IServiceInfo = {
    EKYC_UPDATE: {
        reqFunct: reqFunct.EKYC_UPDATE,
        WorkerName: 'FOSxID01',
        ServiceName: 'FOSxID01_EKYCMgt',
        ClientSentTime: '0',
        Operation: 'U',
        TimeOut: 20,
    },
    API_UPLOAD: {
        reqFunct: reqFunct.API_UPLOAD,
        WorkerName: 'FOSxCommon02',
        ServiceName: 'FOSxCommon02_Token_Mgt',
        ClientSentTime: '0',
        Operation: 'Q',
    },
    CHECK_DUPLICATE_INFO: {
        reqFunct: reqFunct.CHECK_DUPLICATE_INFO,
        WorkerName: 'FOSqAccount',
        ServiceName: 'FOSqAccount_Common_3',
        ClientSentTime: '0',
        Operation: 'Q',
    },
}
interface IModalConfirmAndReviewInfoProps {
    isShowReviewModal: boolean
    setIsShowReviewModal: React.Dispatch<React.SetStateAction<boolean>>
    loadingRegister: boolean
    setLoadingRegister: (loadingState: boolean) => void
    switchStep: ISwitchStep
}

const ModalConfirmAndReviewInfo = ({
    isShowReviewModal,
    setIsShowReviewModal,
    switchStep,
    loadingRegister,
    setLoadingRegister,
}: IModalConfirmAndReviewInfoProps) => {
    const { styles } = useContext(StoreContext)
    const { setUserInfo } = useContext(StoreTrading)
    const { t } = useTranslation()
    const {
        brokerInfo,
        remisierInfo,
        referrerCode: referrerCodeCreate,
        referrerName: referrerNameCreate,
        checkMargin,
        checkAutoPIA,
        jobID = '',
        positionID = '',
        checkFATCA,
        infomationDisclosureStock = '',
        voucherCode,
        isCheckBrokerageServices,
    } = ekycService.additionalData
    const flagEkycUpdate = useRef(false)
    const navigation = useNavigation()
    const { deleteData } = useSaveCurrentStep()
    const validate = () => {
        // if (!checkNote) return false
        return true
    }

    const updateUserInfo = () => {
        const { phone, email, id, name, birthday, idDate, idPlace, address, contactAddress, gender, bankLinkType, bankAccLink, bankAccNum } =
            ekycService.userData
        Analytics.logEvent(EkycAnalyticEvents.ekyc_touch_register, { phone, fullName: name })
        // ----------
        const compareFace = ekycService.videoData?.face_match?.similarity ? String(ekycService.videoData.face_match.similarity) : '100' // Tỉ lệ prob khuôn mặt

        if (flagEkycUpdate.current) return

        flagEkycUpdate.current = true
        setLoadingRegister(true)

        const {
            type,
            doe, // Ngày hết hạn của CCCD
            type_new,
        } = ekycService.frontData
        // Backend
        // 01	CMND
        // 02	Hộ chiếu
        // 03	GPKD
        // 04	Chứng thư khác
        // 05	Trading Code (TCNN)
        // 06	Trading Code (CNNN)
        // 07	Cơ quan chính phủ
        // 08	Căn cước công dân

        const inval = [
            'ekyc', // 0
            glb_sv.credentials.username,
            glb_sv.credentials.password,
            type_new === 'cmnd_09_front' || type_new === 'cmnd_12_front' ? '1' : '8',
            id?.trim(),
            removeSpecialSymbol(name || ''),
            moment(birthday).format('YYYYMMDD'),
            removeSpecialSymbol(address?.replace(/\n/g, ' ').trim() || ''),
            removeSpecialSymbolForAddress(contactAddress?.replace(/\n/g, ' ').trim() || ''),
            moment(idDate).format('YYYYMMDD'),
            removeSpecialSymbol(idPlace?.replace(/\n/g, ' ').trim() || ''), // 10
            gender, // 11
            'FPT_EKYC_Face_' + glb_sv.credentials.username, //type === 'normal' ? 'no_image' : dataRef.current.imageHashFace,
            'FPT_EKYC_Front_' + glb_sv.credentials.username, //type === 'normal' ? 'no_image' : dataRef.current.imageHashFront,
            'FPT_EKYC_Back_' + glb_sv.credentials.username, //type === 'normal' ? 'no_image' : dataRef.current.imageHashBack,
            String(compareFace),
            '', // 16 Signture 1
            '', // 17 Signture 2
            email?.trim().toLowerCase(), // 18 email
            phone?.trim(), // mobile
            brokerInfo?.brokerID ? brokerInfo.brokerID : '', // 20 Broker
            remisierInfo?.remisierID ? remisierInfo.remisierID : '', // 21 Remisier
            doe && moment(doe, 'DD/MM/YYYY').format('YYYYMMDD') !== 'Invalid date' ? moment(doe, 'DD/MM/YYYY').format('YYYYMMDD') : '', // 22 ngày sinh
            bankAccNum?.trim(), // 23 is_bank_act_no: Số TKNH
            bankAccNum?.trim() ? name : '', // 24 Tên tk ngân hàng của User
            bankAccLink ? (bankAccLink.c0 ? bankAccLink.c0 : '') : '', // 25 Mã ngân hàng
            bankLinkType == '0' && bankAccNum?.trim() ? 'Y' : 'N', // 26
            ekycService?.additionalData?.institutional || '', // 27 Tổ chức (Mặc định là công ty chứng khoán)
            referrerCodeCreate || '', // 28
            referrerNameCreate || '', // 29
            configUIEkyc.margin_check ? (checkMargin ? 'Y' : 'N') : '', // 30 Open Margin Account
            '', // 31 Birth place
            configUIEkyc.auto_PIA ? (checkAutoPIA ? 'Y' : 'N') : '', //  32: Auto PIA Y/N
            '', // 33: ID chữ ký
            jobID, // 34: Job ID
            configUIEkyc.is_FATCA ? (checkFATCA ? 'Y' : 'N') : '', // 35: Fata (Y/N)
            infomationDisclosureStock, // 36: DS mã CK liên quan, cách nhau dấu ;
            voucherCode || '', // 37: Mã khuyến mãi (Sau này sẽ apply chính sách khuyến mãi cho mở TK, em cứ truyền empty trước).
            configUIEkyc.brokerage_services_check ? (isCheckBrokerageServices ? '1' : '0') : '0', // 38 Register for brokerage services
            '', // eKYCWarningMessage.join(';'), // 39: Warning msg từ VNPT trả ra
            '', // 40: Tài khoản giao dịch
            ekycService?.dataForContract?.investment_purpose?.value, // 41: Mục tiêu đầu tư
            ekycService?.dataForContract?.yearly_revenue?.value, // 42: Thu nhập hàng năm
            ekycService?.dataForContract?.risk_level?.value, // 43: Mức độ chấp nhận rủi ro
            ekycService?.dataForContract?.investment_experiment?.value, // 44: Kinh nghiệm đầu tư
            ekycService?.dataForContract?.investment_knowledge?.value, // 45: Kiến thức đầu tư
            `${ekycService?.dataForContract?.has_account_in_other ? 'Y' : 'N'}${
                ekycService?.dataForContract?.list_account_in_other?.length
                    ? `|${
                          ekycService?.dataForContract?.list_account_in_other[0].account_number
                      }|${ekycService?.dataForContract?.list_account_in_other[0].securities_name?.trim()}`
                    : ''
            }`, // 46: TKGD tại CTCK khác
            ekycService?.dataForContract?.isInsider ? 'Y' : 'N', // 47: Khách hàng nắm giữ
            ekycService?.dataForContract?.isRelateCustHolder ? 'Y' : 'N', // 48: Người có liên quan
            ekycService?.additionalData?.checkFATCADetail || '2', // 49: Loại FATCA,
            '', // BE không biết field này dùng làm gì
            positionID, // 51: Chức vụ
        ]
        sendRequest(ServiceInfo.EKYC_UPDATE, inval, updateUserInfoResult, true, updateUserInfoTimeout, '', 20000)
    }

    const updateUserInfoResult = (reqInfoMap, message) => {
        flagEkycUpdate.current = false
        setLoadingRegister(false)
        if (Number(message.Result) === 0) {
            glb_sv.sendEKYCLogNewTracking({
                sEKYCLog: EkycAnalyticEvents.ekyc_step_three_error,
                eKYCType: '4',
                reason: message?.Message,
                ekycStep: '3',
            })
            // navigation.navigate(Screens.ALERT_MODAL, {
            // icon: <IconSvg.ErrorIcon color={styles.EKYC__COLOR} />,
            // title: t('common_notify').toLocaleUpperCase(),
            // colorTitle: styles.EKYC__COLOR,
            // content: message.Message,
            // typeColor: styles.EKYC__COLOR,
            // titleOK: t('common_alert_agree').toLocaleUpperCase(),
            // })
            ModalController.showModal({
                icon: <IconSvg.ErrorIcon color={styles.EKYC__COLOR} />,
                title: t('common_notify').toLocaleUpperCase(),
                colorTitle: styles.EKYC__COLOR,
                content: message.Message,
                typeColor: styles.EKYC__COLOR,
                titleOK: t('common_alert_agree').toLocaleUpperCase(),
            })
        } else {
            switchStep.next() // Chuyển sang bước ký hợp đồng điện tử
            // --------
            Analytics.logEvent(EkycAnalyticEvents.ekyc_step_three_verify_otp)
            glb_sv.sendEKYCLogNewTracking({
                sEKYCLog: EkycAnalyticEvents.ekyc_step_four_finish,
                eKYCType: '3',
                reason: 'Gửi thông tin tạo hợp đồng',
                ekycStep: '4',
            })
            deleteData({
                callback: () => console.log('ekyc done and delete current data'),
            })
            let json
            try {
                json = JSON.parse(message.Data)[0]
            } catch (err) {
                console.log(err)
                if (glb_sv.objShareGlb.userInfo) glb_sv.objShareGlb.userInfo.c9 = 'W'
                glb_sv.commonEvent.next({ type: eventList.EKYC_SUCCESS })
                return
            }
            if (json && json.c0 === 'W') {
                if (glb_sv.objShareGlb.userInfo) glb_sv.objShareGlb.userInfo.c9 = 'W'
                glb_sv.commonEvent.next({ type: eventList.EKYC_SUCCESS })
            } else {
                storeAccountInfo(json)

                if (glb_sv.objShareGlb.userInfo) glb_sv.objShareGlb.userInfo.c9 = 'A'
                glb_sv.commonEvent.next({ type: eventList.EKYC_SUCCESS })
            }
        }
    }

    const updateUserInfoTimeout = ({ type }) => {
        flagEkycUpdate.current = false
        setLoadingRegister(false)
        glb_sv.sendEKYCLogNewTracking({
            sEKYCLog: EkycAnalyticEvents.ekyc_step_four_timeout,
            eKYCType: '4',
            reason: 'Tạo hợp đồng hết thời gian',
            ekycStep: '4',
        })
        if (type === 'timeout') {
            // navigation.navigate(Screens.ALERT_MODAL, {
            //     icon: <IconSvg.ErrorIcon color={styles.EKYC__COLOR} />,
            //     title: t('common_notify').toLocaleUpperCase(),
            //     colorTitle: styles.EKYC__COLOR,
            //     content: t('request_hanlde_not_success_try_again'),
            //     typeColor: styles.WARN__COLOR,
            //     titleOK: t('common_alert_agree').toLocaleUpperCase(),
            // })
            ModalController.showModal({
                icon: <IconSvg.ErrorIcon color={styles.EKYC__COLOR} />,
                title: t('common_notify').toLocaleUpperCase(),
                colorTitle: styles.EKYC__COLOR,
                content: t('request_hanlde_not_success_try_again'),
                typeColor: styles.WARN__COLOR,
                titleOK: t('common_alert_agree').toLocaleUpperCase(),
            })
        }
    }

    const storeAccountInfo = (userInfo) => {
        const accountInfo = userInfo.c0
        const array_acnt = accountInfo.split('|').filter((e) => e !== '')
        const js_acntInfo: any = []
        const js_acntList: any = []
        // const js_acntListAll = []
        let acntMain = '',
            acntMainName = ''
        for (let i = 0; i < array_acnt.length; i++) {
            const acntInfo = array_acnt[i]
            const arr_info = acntInfo.split(',')

            if (arr_info[4] === 'Y') {
                acntMain = arr_info[0]
                acntMainName = arr_info[2]
            }
            const js_acnt = {
                AcntNo: arr_info[0],
                SubNo: arr_info[1],
                AcntNm: arr_info[2],
                IsOwnAcnt: arr_info[4],
                MarginYN: arr_info[3] === '2',
                ActType: arr_info[3],
            }
            const js_acntObj = {
                id: arr_info[0] + '.' + arr_info[1],
                name: arr_info[0] + '.' + arr_info[1] + ' - ' + arr_info[2],
            }
            js_acntInfo.push(js_acnt)
            js_acntList.push(js_acntObj)
            // js_acntListAll.push(js_acntObj)
        }

        glb_sv.objShareGlb.acntNoInfo = js_acntInfo
        glb_sv.objShareGlb.acntNoList = js_acntList
        // glb_sv.objShareGlb['acntNoListAll'] = js_acntListAll
        // --------------------
        glb_sv.objShareGlb.AcntMain = acntMain // -- chủ tài khoản lưu ký
        glb_sv.objShareGlb.AcntMainNm = acntMainName // -- Tên chủ tài khoản
        glb_sv.objShareGlb.workDate = userInfo.c16 // -- Ngày làm việc
        // glb_sv.objShareGlb['brokerId'] = userInfo['c24'] // -- ID nhân viên môi giới
        // glb_sv.objShareGlb['brokerNm'] = userInfo['c25'] // -- Tên nhân viên môi giới
        // glb_sv.objShareGlb['brokerEmail'] = userInfo['c26'] // -- Email nhân viên môi giới
        // glb_sv.objShareGlb['brokerMobile'] = userInfo['c27'] // -- Mobile nhân viên môi giới
        // glb_sv.objShareGlb['secCode'] = userInfo['c9'] // -- Tên nhân viên môi giới
        // glb_sv.objShareGlb['prdYN'] = userInfo['c31'] // -- User trình chiếu bảng điện hay không
        // glb_sv.objShareGlb['verify'] = Number(userInfo['c37']) || 0 // -- verify > 0 => Phải xác thực chứng chỉ số
        // glb_sv.objShareGlb['serialnum'] = userInfo['c38'] // -- serialNumber

        const sub_list: any = []
        const actn_list: any = []
        js_acntInfo.forEach((e) => {
            if (e.AcntNo === acntMain) sub_list.push(e.SubNo)
            if (!actn_list.find((temp) => temp.AcntNo === e.AcntNo))
                actn_list.push({
                    AcntNo: e.AcntNo,
                    actn_name: e.AcntNm,
                    key: e.AcntNo,
                    label: e.AcntNo + ' (' + e.AcntNm + ')',
                })
        })
        setUserInfo({
            actn_curr: acntMain,
            sub_curr: sub_list[0] || '00',
            actn_name: acntMainName,
            sub_list,
            actn_list,
        })

        glb_sv.userInfoAccount = {
            actn_curr: acntMain,
            sub_curr: sub_list[0] || '00',
            actn_name: acntMainName,
            sub_list,
            actn_list,
        }

        glb_sv.userInfo.actn_curr = acntMain
        glb_sv.userInfo.sub_curr = sub_list[0] || '00'

        glb_sv.authFlag = true
    }

    useEffect(() => {
        const { frontData, backData, videoData, userData, additionalData } = ekycService
        const dataLogFront = { ...frontData }
        dataLogFront.cropped_idcard_base64 = ''
        dataLogFront.face_base64 = ''
        const dataLogBack = { ...backData }
        dataLogBack.cropped_idcard_base64 = ''
        dataLogBack.face_base64 = ''
        const videoLog = { ...videoData }
        videoLog.image_face = ''
        videoLog.face_base64 = ''
    }, [])

    const onBeforeRegisterEkyc = () => {
        navigation.navigate(Screens.OTP_MODAL_WITHOUT_TYPE_OPTIONS, {
            OTPTarget: 'only_email', // [only_email, only_sms, only_iotp, both_email_sms]
            smsOTP: true,
            otp_Type: Number(glb_sv.objShareGlb.userInfo.c6),
            functCallback: updateUserInfo,
        })
    }

    return (
        <>
            <Modal
                hideModalContentWhileAnimating
                isVisible={isShowReviewModal}
                style={{ marginLeft: 5, marginRight: 5 }}
                useNativeDriver={true}
                onBackButtonPress={() => {
                    setIsShowReviewModal(false)
                }}
            >
                <ModalContent iconComponent={null} title={t('common_review_info')}>
                    <RowDataModal textLeft={t('common_full_name')} textRight={ekycService?.userData?.name} />
                    <RowDataModal textLeft={t('phone')} textRight={ekycService?.userData?.phone} />
                    <RowDataModal textLeft={t('email')} textRight={ekycService?.userData?.email} />
                    <RowDataModal textLeft={t('id_card_number')} textRight={ekycService?.userData?.id} />
                    <RowDataModal
                        textLeft={t('ekyc_birthday')}
                        textRight={ekycService?.userData?.birthday ? moment(ekycService?.userData?.birthday).format('DD/MM/YYYY') : '---'}
                    />
                    <RowDataModal textLeft={t('common_your_sex')} textRight={ekycService?.userData?.gender === 'M' ? t('common_male') : t('common_female')} />
                    <RowDataModal
                        textLeft={t('ekyc_issue_date')}
                        textRight={ekycService?.userData?.idDate ? moment(ekycService?.userData?.idDate).format('DD/MM/YYYY') : '---'}
                    />
                    <RowDataModal textLeft={t('addr_regit_per')} textRight={ekycService?.userData?.address} />
                    <RowDataModal last textLeft={t('contact_address')} textRight={ekycService?.userData?.contactAddress} />
                    <View style={UI.RowModal}>
                        <View style={{ paddingTop: 2 }}>
                            <IconSvg.CheckboxIcon active={checkMargin} colorActive={styles.PRIMARY} colorunActive={styles.PRIMARY__CONTENT__COLOR} />
                        </View>
                        <Text
                            style={{
                                fontSize: fontSizes.small,
                                color: styles.PRIMARY__CONTENT__COLOR,
                                marginLeft: dimensions.moderate(8),
                                marginRight: 16,
                            }}
                        >
                            {t<string>('active_act_trade_margin')}
                        </Text>
                    </View>

                    <ButtonCustom
                        disabled={loadingRegister}
                        isLoading={loadingRegister}
                        text={t('register')}
                        type="confirm"
                        onPress={() => {
                            Analytics.logEvent(EkycAnalyticEvents.ekyc_step_three_review_register)
                            glb_sv.sendEKYCLogNewTracking({
                                sEKYCLog: EkycAnalyticEvents.ekyc_step_three_review_register,
                                eKYCType: '3',
                                reason: 'Review thông tin đăng ký',
                                ekycStep: '3',
                            })
                            setIsShowReviewModal(false)
                            onBeforeRegisterEkyc()
                        }}
                    />
                    <ButtonCustom
                        last
                        text={t('common_Cancel')}
                        type="back"
                        onPress={() => {
                            Analytics.logEvent(EkycAnalyticEvents.ekyc_step_three_review_cancel)
                            glb_sv.sendEKYCLogNewTracking({
                                sEKYCLog: EkycAnalyticEvents.ekyc_step_three_review_cancel,
                                eKYCType: '3',
                                reason: 'Nhấn button cancel khi review thông tin đăng ký',
                                ekycStep: '3',
                            })
                            setIsShowReviewModal(false)
                        }}
                    />
                </ModalContent>
            </Modal>
        </>
    )
}

export default ModalConfirmAndReviewInfo

const UI = StyleSheet.create({
    RowModal: { alignItems: 'center', flexDirection: 'row', marginVertical: 4, paddingHorizontal: dimensions.moderate(16) },
})
