import React, { Component, createRef, useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { ActivityIndicator, Platform, StyleSheet, View } from 'react-native'
import WebView from 'react-native-webview'
import moment from 'moment'

import { RowTitleGroup } from '../../../../../components/trading-component'
import { useLoading } from '../../../../../hoc'
import { StoreContext } from '../../../../../store'
import { glb_sv, reqFunct, sendRequest } from '../../../../../utils'
import ChartWebview from './webview'

const ServiceInfo = {
    GET_HISTORY_ASSETS: {
        reqFunct: reqFunct.GET_HISTORY_ASSETS,
        WorkerName: 'FOSqAsset',
        ServiceName: 'FOSqAsset_Online_1',
        Operation: 'Q',
    },
}

export const ChartProfitLossColumn = ({ userInfo }) => {
    const { theme, styles } = useContext(StoreContext)
    const [loading, setLoading] = useLoading(false)
    const { t } = useTranslation()
    const [dataChart, setDataChart] = useState([])

    useEffect(() => {
        getHistoryProfitLoss()
    }, [userInfo])

    // ------ service
    const getHistoryProfitLoss = () => {
        setLoading(true)
        const inputParams = [
            '03',
            moment(glb_sv.objShareGlb.workDate, 'YYYYMMDD').subtract(12, 'months').format('YYYYMMDD'),
            glb_sv.objShareGlb.workDate,
            glb_sv.objShareGlb.AcntMain,
        ]
        sendRequest(ServiceInfo.GET_HISTORY_ASSETS, inputParams, getHistoryProfitLossResult, true, getHistoryProfitLossTimeout)
    }

    const getHistoryProfitLossTimeout = () => {
        console.log('getHistoryProfitLossTimeout')
    }

    const getHistoryProfitLossResult = (reqInfoMap, message) => {
        setLoading(false)
        if (Number(message.Result) === 0) {
            return
        } else {
            let data = []
            try {
                data = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {}
            setDataChart(data)
        }
    }

    return (
        <>
            <RowTitleGroup
                hasDivider
                text={`${t('statictis')} ${moment(glb_sv.objShareGlb.workDate, 'YYYYMMDD').subtract(12, 'months').format('MM/YYYY')} --> ${moment(
                    glb_sv.objShareGlb.workDate,
                    'YYYYMMDD',
                ).format('MM/YYYY')}`}
            />
            <View style={{ height: 250 }}>
                {loading ? (
                    <View style={{ alignItems: 'center', justifyContent: 'center' }}>
                        <ActivityIndicator color={styles.PRIMARY} />
                    </View>
                ) : null}
                <ChartWebview dataChart={JSON.stringify(dataChart)} styles={styles} t={t} theme={theme} />
            </View>
        </>
    )
}
