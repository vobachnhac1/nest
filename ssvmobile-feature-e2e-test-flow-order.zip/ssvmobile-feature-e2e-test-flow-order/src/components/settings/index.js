import React, { useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { Col, Container, Content, ListItem } from 'native-base'

import CONFIG_SOURCE, { ENV } from '../../assets/config'
import IconBack from '../../assets/images/common/ic_arrow_right.svg'
import IconBell from '../../assets/images/common/ic_bell.svg'
import IconVolPrice from '../../assets/images/common/ic_pencil_ruler.svg'
import IconTimer from '../../assets/images/common/ic_timer.svg'
import Language from '../../assets/images/common/language.svg'
import Server from '../../assets/images/common/server.svg'
import SettingDisplay from '../../assets/images/common/setting-display.svg'
import { Text } from '../../basic-components'
import { ImmediateCheckCodePush } from '../../components/code-push'
import HeaderComponent from '../../components/header'
import { StoreContext } from '../../store'
import { dimensions, fontSizes } from '../../styles'
import { glb_sv, Screens, socket_sv } from '../../utils'

const CONFIG = CONFIG_SOURCE[CONFIG_SOURCE.active_code]

function Settings({ navigation }) {
    const { language, theme, currentNodeServer, styles, authFlag, timeoutConnect } = useContext(StoreContext)
    const { t } = useTranslation()

    const getLangage = (key) => {
        if (key === 'VI') return 'Tiếng Việt'
        if (key === 'EN') return 'English'
        if (key === 'CN') return '中文'
        if (key === 'ZH') return '中文'
        if (key === 'KO') return '한국어'
    }

    const onPressCheckUpdate = () => {
        ImmediateCheckCodePush()
    }

    return (
        <Container>
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft={true}
                navigation={navigation}
                title={t('app_settings')}
                titleAlgin="flex-start"
            />
            <Content style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
                <ListItem icon noBorder style={{ marginVertical: dimensions.halfVerticalIndent }} underlayColor="transparent">
                    <Col size={2}>
                        <SettingDisplay fill={styles.PRIMARY__CONTENT__COLOR} />
                    </Col>
                    <Col size={19} onPress={() => navigation.navigate(Screens.DISPLAY)}>
                        <Text style={{ fontSize: fontSizes.medium, color: styles.PRIMARY__CONTENT__COLOR }}>{t('ui_setting')}</Text>
                        <Text style={{ fontSize: fontSizes.smallest, color: styles.PRIMARY__CONTENT__COLOR }}>
                            {theme == 'DARK' ? t('dark_theme') : t('light_theme')}
                        </Text>
                    </Col>
                    <Col size={2}>
                        <IconBack style={{ color: styles.ICON__PRIMARY }} />
                    </Col>
                </ListItem>
                <ListItem icon noBorder style={{ marginVertical: dimensions.halfVerticalIndent }} underlayColor="transparent">
                    <Col size={2}>
                        <Language fill={styles.PRIMARY__CONTENT__COLOR} />
                    </Col>
                    <Col size={19} onPress={() => navigation.navigate(Screens.LANGUAGE)}>
                        <Text style={{ fontSize: fontSizes.medium, color: styles.PRIMARY__CONTENT__COLOR }}>{t('lang_setting')}</Text>
                        <Text style={{ fontSize: fontSizes.smallest, color: styles.PRIMARY__CONTENT__COLOR }}>{getLangage(language)}</Text>
                    </Col>
                    <Col size={2}>
                        <IconBack style={{ color: styles.ICON__PRIMARY }} />
                    </Col>
                </ListItem>
                {glb_sv.configInfo.server_node_list.length > 1 ? (
                    <ListItem icon noBorder style={{ marginVertical: dimensions.halfVerticalIndent }} underlayColor="transparent">
                        <Col size={2}>
                            <Server fill={styles.PRIMARY__CONTENT__COLOR} />
                        </Col>
                        <Col size={19} onPress={() => navigation.navigate(Screens.SERVER)}>
                            <Text style={{ fontSize: fontSizes.medium, color: styles.PRIMARY__CONTENT__COLOR }}>{t('server_setting')}</Text>
                            <Text style={{ fontSize: fontSizes.smallest, color: styles.PRIMARY__CONTENT__COLOR }}>
                                {t(socket_sv.server_node_list[currentNodeServer].key_name) +
                                    ' ' +
                                    t(socket_sv.server_node_list[currentNodeServer].key_name_note)}
                            </Text>
                        </Col>
                        <Col size={2}>
                            <IconBack style={{ color: styles.ICON__PRIMARY }} />
                        </Col>
                    </ListItem>
                ) : null}
                <ListItem
                    icon
                    noBorder
                    style={{ marginVertical: dimensions.halfVerticalIndent }}
                    underlayColor="transparent"
                    onPress={() => navigation.navigate(Screens.SETTING_PRICE_QUANTY)}
                >
                    <Col size={2}>
                        <IconVolPrice fill={styles.PRIMARY__CONTENT__COLOR} />
                    </Col>
                    <Col size={19}>
                        <Text style={{ fontSize: fontSizes.medium, color: styles.PRIMARY__CONTENT__COLOR }}>{t('price_qty_unit_setting')}</Text>
                    </Col>
                    <Col size={2}>
                        <IconBack style={{ color: styles.ICON__PRIMARY }} />
                    </Col>
                </ListItem>

                <ListItem
                    icon
                    noBorder
                    style={{ marginVertical: dimensions.halfVerticalIndent }}
                    underlayColor="transparent"
                    onPress={() => navigation.navigate(Screens.NOTIFY)}
                >
                    <Col size={2}>
                        <IconBell fill={styles.PRIMARY__CONTENT__COLOR} />
                    </Col>
                    <Col size={19}>
                        <Text style={{ fontSize: fontSizes.medium, color: styles.PRIMARY__CONTENT__COLOR }}>{t('notify_setting')}</Text>
                    </Col>
                    <Col size={2}>
                        <IconBack style={{ color: styles.ICON__PRIMARY }} />
                    </Col>
                </ListItem>
                {ENV === 'CONFIG_TEST' ? (
                    <>
                        <ListItem
                            icon
                            noBorder
                            style={{ marginVertical: dimensions.halfVerticalIndent }}
                            underlayColor="transparent"
                            onPress={() => navigation.navigate(Screens.DEV_TOOLS, {})}
                        >
                            <Col size={2}>
                                <IconBell fill={styles.PRIMARY__CONTENT__COLOR} />
                            </Col>
                            <Col size={19}>
                                <Text style={{ fontSize: fontSizes.medium, color: styles.PRIMARY__CONTENT__COLOR }}>{t('Dev tools')}</Text>
                            </Col>
                            <Col size={2}>
                                <IconBack style={{ color: styles.ICON__PRIMARY }} />
                            </Col>
                        </ListItem>
                        <ListItem
                            icon
                            noBorder
                            style={{ marginVertical: dimensions.halfVerticalIndent }}
                            underlayColor="transparent"
                            onPress={onPressCheckUpdate}
                        >
                            <Col size={2}>
                                <IconBell fill={styles.PRIMARY__CONTENT__COLOR} />
                            </Col>
                            <Col size={19}>
                                <Text style={{ fontSize: fontSizes.medium, color: styles.PRIMARY__CONTENT__COLOR }}>{t('check_update')}</Text>
                            </Col>
                            <Col size={2}>
                                <IconBack style={{ color: styles.ICON__PRIMARY }} />
                            </Col>
                        </ListItem>
                    </>
                ) : null}

                {authFlag ? (
                    <ListItem activeOpacity={0.6} icon noBorder underlayColor="transparent" onPress={() => navigation.navigate(Screens.TIMEOUT_CONNECT)}>
                        <Col size={2}>
                            <IconTimer fill={styles.PRIMARY__CONTENT__COLOR} />
                        </Col>
                        <Col size={9.5}>
                            <Text style={{ fontSize: fontSizes.medium, color: styles.PRIMARY__CONTENT__COLOR }}>{t('time_stay_connected')}</Text>
                        </Col>
                        <Col size={9.5}>
                            <Text numberOfLines={1} style={{ fontSize: fontSizes.medium, textAlign: 'right', color: styles.PRIMARY__CONTENT__COLOR }}>
                                {t(timeoutConnect)}
                            </Text>
                        </Col>
                        <Col size={2}>
                            <IconBack style={{ color: styles.ICON__PRIMARY }} />
                        </Col>
                    </ListItem>
                ) : null}
            </Content>
        </Container>
    )
}

export default Settings
