import React, { memo, useContext } from 'react'
import { Keyboard, StyleSheet, View } from 'react-native'
import { FloatingLabelInput, FloatingLabelProps } from 'react-native-floating-label-input'

import { StoreContext } from '../../store'
import { dimensions as dm, fontSizes as fs, fontWeights as fw } from '../../styles'
import Text from '../Text'

/**
 * Lưu ý:  Nếu dùng component này ở dạng select và dùng nhiều icon như select, delete,...
 * Thì thêm "pointerEvents="none""
 * Icon delete,... thì viết đạng position absolute phía ngoài
 */
interface ICustomFloatInput extends FloatingLabelProps {
    errCtrl?: { error: boolean; message: string }
    small?: boolean
    isInputModal?: boolean
    isSelectInput?: boolean
    label: string
    [key: string]: any
}

const CustomFloatInput = ({ errCtrl, small, isInputModal, isSelectInput, label, ...props }: ICustomFloatInput) => {
    const { styles } = useContext(StoreContext)
    return (
        <View
            pointerEvents={isSelectInput ? 'none' : 'auto'}
            style={{ borderBottomColor: styles.DIVIDER__COLOR, borderBottomWidth: isInputModal ? 1 : 0, marginHorizontal: isInputModal ? 16 : 0 }}
        >
            <FloatingLabelInput
                containerStyles={{
                    backgroundColor: isInputModal ? 'transparent' : styles.INPUT__BG,
                    borderRadius: 8,
                    paddingLeft: small ? 6 : isInputModal ? 0 : 16,
                    height: dm.moderate(56),
                    borderWidth: 1,
                    borderColor: errCtrl?.error ? '#EB5C55' : 'transparent',
                }}
                customLabelStyles={{
                    fontSizeFocused: fs.verySmall,
                    colorFocused: styles.SECOND__CONTENT__COLOR,
                    colorBlurred: styles.SECOND__CONTENT__COLOR,
                    topBlurred: -4,
                    leftFocused: 0,
                    leftBlurred: 0,
                }}
                inputStyles={{
                    top: 8,
                    fontSize: fs.medium,
                    color: styles.PRIMARY__CONTENT__COLOR,
                }}
                label={label}
                labelStyles={{
                    paddingTop: 8,
                    left: 0,
                }}
                {...props}
            />
            {errCtrl?.error && <Text style={UI.ErrorStyle}>{errCtrl?.message}</Text>}
        </View>
    )
}

export default memo(CustomFloatInput)

const UI = StyleSheet.create({
    ErrorBorder: {
        borderColor: '#EB5C55',
        borderWidth: 1,
    },
    ErrorStyle: {
        color: '#EB5C55',
        fontSize: fs.smallest,
        fontStyle: 'italic',
        fontWeight: fw.light,
    },
})
