import React, { useCallback, useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { FlatList, Image, Pressable, RefreshControl, StyleSheet, View } from 'react-native'
import { TouchableOpacity } from 'react-native-gesture-handler'
import Modal from 'react-native-modal'
import DateTimePickerModal from 'react-native-modal-datetime-picker'
import Svg, { Path } from 'react-native-svg'
import ToastGlobal from 'react-native-toast-message'
import ModalController from '@mts-components/appModal/modalControlller'
import moment from 'moment'
import { Col, Container, Content, Row, Text } from 'native-base'

import IconCalendar from '../../../assets/images/common/calendar.svg'
import IconArrDown from '../../../assets/images/common/ic_arrow_down.svg'
import IC_EXCHANGE_MONEY from '../../../assets/images/common/ic_exchange_money.png'
import { CustomFloatInput } from '../../../basic-components'
import Account from '../../../components/account'
import HeaderComponent from '../../../components/header'
import { ModalBottomContent, ModalBottomRowSelect, RowTitleGroup } from '../../../components/trading-component'
import { StoreContext } from '../../../store'
import { StoreTrading } from '../../../store-trading'
import { dimensions as dm, fontSizes as fs, IconSvg } from '../../../styles'
import { eventList, FormatNumber, glb_sv, reqFunct, Screens, wait } from '../../../utils'
import sendRequest from '../../../utils/sendRequest'

// Khai báo ServiceInfo (nếu có)
const ServiceInfo = {
    KEY_EXCHANGE_STATEMENT_QUERY: {
        reqFunct: reqFunct.KEY_EXCHANGE_STATEMENT_QUERY, //Lấy "Số dư hiện tại"
        WorkerName: 'FOSqTransaction',
        ServiceName: 'FOSqTransaction_OnlineTrans_1',
        Operation: 'Q',
    },
}
// Khai báo component
const GDList = [
    { index: 0, value: '%', label: 'view_all' },
    { index: 1, value: '1', label: 'stock_exchange' },
    { index: 2, value: '2', label: 'transaction_cash' },
]
const StatementExchangeLayout = ({ navigation }) => {
    const { styles, theme, language } = useContext(StoreContext)
    const { userInfo } = useContext(StoreTrading)

    const { t } = useTranslation()
    const histOrdListTemple = useRef([])
    // All orther state
    const [activeStep, setActiveStep] = useState(0)
    const [visibleTypeTranstation, setVisibleTypeTranstation] = useState(false)
    const [newsList, setList] = useState([])
    const [typeTranstation, setTypeTranstation] = useState(GDList[0].value)
    const [labelTypeTranstation, setLabelTypeTranstation] = useState(GDList[0].label)
    const [visibleDatePickerFrom, setVisibleDatePickerFrom] = useState(false)
    const [visibleDatePickerTo, setVisibleDatePickerTo] = useState(false)
    const [refreshing, setRefreshing] = useState(false)

    const [from_dt, setFromDt] = useState(moment(glb_sv.objShareGlb.workDate).subtract(1, 'months').toDate())
    const [to_dt, setToDt] = useState(moment(glb_sv.objShareGlb.workDate).toDate())

    // End define form bussiness state
    // -------------------------------------------   Dùng useEffect get các dữ liệu cần thiết còn thiếu
    // -------------------------------------------   Viết các hàm để set lại bussiness form state. Nên viết đúng một chuẩn duy nhất để dễ control
    useEffect(() => {
        getOrderList()
    }, [userInfo, typeTranstation])

    const getOrderList = (from, to, typeTran = typeTranstation) => {
        if (!userInfo.actn_curr) {
            ToastGlobal.show({
                type: 'warning',
                text2: t('warning_account_is_empty'),
            })
            return
        }

        histOrdListTemple.current = []
        setList([])

        const inputParams = [
            moment(from || from_dt).format('YYYYMMDD'),
            moment(to || to_dt).format('YYYYMMDD'),
            userInfo.actn_curr,
            userInfo.sub_curr,
            // typeTranstation,
            typeTran,
        ]
        sendRequest(ServiceInfo.KEY_EXCHANGE_STATEMENT_QUERY, inputParams, handleGetListAnnouncementOrder)
    }

    const handleGetListAnnouncementOrder = (reqInfoMap, message) => {
        setRefreshing(false)
        if (Number(message.Result) === 0) {
            if (message.Code == 'XXXXX5' || message.Code === '080063' || message.Code === '010012') {
            } else {
                // navigation.navigate(Screens.ALERT_MODAL, {
                // title: t('common_notify'),
                // content: message.Message,
                // typeColor: styles.WARN__COLOR,
                // })
                ModalController.showModal({
                    title: t('common_notify'),
                    content: message.Message,
                    typeColor: styles.WARN__COLOR,
                })
            }
        } else {
            let jsondata = []
            try {
                if (!message.Data) {
                } else {
                    jsondata = JSON.parse(glb_sv.filterStrBfParse(message.Data))
                    console.log(jsondata)
                }
            } catch (err) {
                // getOrderListFlag.current = false
                // return
            }
            // histOrdListTemple.current = histOrdListTemple.current.concat(jsondata);
            if (Number(message.Packet) <= 0) {
                // let data = histOrdListTemple.current.slice();
                filterData(jsondata)
                // setDataListStatement(jsondata)
            }
        }
    }
    const filterData = (data) => {
        const convertData = data.map((item, i) => {
            item.c11 = transDate(item.c11) + ' ' + transTime(item.c11)
            item.c0 = transDate(item.c0)
            item.MCK = item.c2 + '.' + item.c3

            if (item.c4.trim().length === 0) {
                item.c6 = FormatNumber(item.c7) + ' VND'
                item.checkGD = true
            } else {
                if (Number(item.c6)) {
                    item.c6 = FormatNumber(item.c6) + ' ' + t('share')
                    item.checkGD = false
                } else {
                    item.MCK = item.c2 + '.' + item.c3
                    item.c6 = FormatNumber(item.c7) + ' VND'
                    item.checkGD = false
                }
            }
            return item
        })
        setList(convertData)
    }
    const _onClickBackButton = () => {
        if (activeStep === 0) navigation.goBack()
    }
    const hideDatePicker = () => {
        setVisibleDatePickerFrom(false)
        setVisibleDatePickerTo(false)
    }
    const filterCheckBoxTranstation = (dataFilter = typeTranstation, datalabelGD = labelTypeTranstation) => {
        setTypeTranstation(dataFilter)
        setLabelTypeTranstation(datalabelGD)

        setTimeout(() => {
            setVisibleTypeTranstation(false)
        }, 500)
    }
    const transDate = (value) => {
        if (value === '' || value == null) return value
        const day = value.substr(0, 2)
        const month = value.substr(2, 2)
        const year = value.substr(4, 4)
        return day + '/' + month + '/' + year
    }

    const transTime = (value) => {
        if (value === '' || value == null) return value
        const day = value.substr(8, 2)
        const month = value.substr(10, 2)
        const year = value.substr(12, 2)
        return day + ':' + month + ':' + year
    }

    // const onRefresh = useCallback(() => {
    // setRefreshing(true)
    // wait(300).then(() => getOrderList())

    // console.log(TAG, 'getOrderList from ', moment(from_dt).format('YYYYMMDD'), ' to ', moment(to_dt).format('YYYYMMDD'))
    // }, [])

    const onRefresh = () => {
        setRefreshing(true)
        wait(300).then(() => getOrderList())
    }

    const getColorTransaction = (oparator) => {
        if (oparator === '+') return styles.GREEN__COLOR
        if (oparator === '-') return styles.NOTIFY__ERROR
        return styles.PRIMARY__CONTENT__COLOR
    }

    const ViewListStatementChange = ({ item, index }) => {
        console.log('item', item)

        return (
            <>
                <Row
                    key={index}
                    style={{ ...UI.Row_view, paddingVertical: 5 }}
                    onPress={() => navigation.navigate(Screens.DETAIL_STATEMENT_EXCHANGE, { data: item })}
                >
                    <Col size={3} style={{ alignSelf: 'center' }}>
                        {item.checkGD ? (
                            <Image resizeMode="contain" source={IC_EXCHANGE_MONEY} style={{ width: 'auto', height: '100%', marginRight: 5 }} />
                        ) : (
                            <View
                                style={{
                                    width: 36,
                                    height: 36,
                                    borderRadius: 18,
                                    textAlign: 'center',
                                    backgroundColor: styles.PRIMARY,
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    // lineHeight: 30,
                                }}
                            >
                                <Text
                                    style={{
                                        fontSize: fs.tiny,
                                        fontWeight: '600',
                                        color: '#ffffff',
                                    }}
                                >
                                    {item.c4}
                                </Text>
                            </View>
                        )}
                    </Col>
                    <Col size={24}>
                        <Row>
                            <Text
                                style={{
                                    color: styles.PRIMARY__CONTENT__COLOR,
                                    fontSize: fs.miniSmall,
                                }}
                            >
                                {item.c12}
                            </Text>
                        </Row>
                        <Row>
                            <Col size={12}>
                                <Text
                                    style={{
                                        color: styles.SECOND__CONTENT__COLOR,
                                        fontSize: fs.verySmall,
                                    }}
                                >
                                    {item.c0}
                                </Text>
                            </Col>
                            <Col size={12}>
                                <Text
                                    style={{
                                        color: getColorTransaction(item.c5),
                                        fontSize: fs.verySmall,
                                        textAlign: 'right',
                                        fontWeight: 'bold',
                                    }}
                                >
                                    {item.c5}
                                    {item.c6}
                                </Text>
                            </Col>
                        </Row>
                    </Col>
                </Row>
                <View
                    style={{
                        borderBottomColor: styles.DIVIDER__COLOR,
                        borderBottomWidth: 1,
                    }}
                />
            </>
        )
    }

    return (
        <Container>
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft
                leftButtonLink={_onClickBackButton}
                navigation={navigation}
                title={t('statement_transaction')}
                titleAlgin="flex-start"
                transparent
            />
            <Content
                refreshControl={
                    <RefreshControl
                        refreshing={refreshing}
                        onRefresh={onRefresh}
                        // title={t('pull_refresh')}
                        // titleColor={styles.PRIMARY__CONTENT__COLOR}
                        tintColor={styles.PRIMARY__CONTENT__COLOR}
                    />
                }
                style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}
            >
                <Account navigation={navigation} />
                <View style={{ ...UI.container }}>
                    <Modal
                        hideModalContentWhileAnimating={true}
                        isVisible={visibleTypeTranstation}
                        style={UI.bottomModal}
                        useNativeDriver={true}
                        onBackButtonPress={() => setVisibleTypeTranstation(false)}
                        onBackdropPress={() => setVisibleTypeTranstation(false)}
                    >
                        <ModalBottomContent title={t('transaction_type')}>
                            {GDList.map((item, index) => (
                                <ModalBottomRowSelect
                                    checked={typeTranstation === item.value}
                                    key={index}
                                    text={t(item.label)}
                                    onPress={() => filterCheckBoxTranstation(item.value, item.label)}
                                />
                            ))}
                        </ModalBottomContent>
                    </Modal>
                </View>

                <DateTimePickerModal
                    cancelTextIOS={t('common_Cancel')}
                    confirmTextIOS={t('common_Ok')}
                    date={from_dt}
                    headerTextIOS=""
                    isDarkModeEnabled={theme.includes('DARK')}
                    isVisible={visibleDatePickerFrom}
                    locale={language === 'VI' ? 'vi_VN' : 'en_US'}
                    mode="date"
                    onCancel={hideDatePicker}
                    onConfirm={(value) => {
                        setVisibleDatePickerFrom(false)
                        setFromDt(value)
                        getOrderList(value)
                        // console.log(TAG, 'From date value: ', value)
                    }}
                />

                <DateTimePickerModal
                    cancelTextIOS={t('common_Cancel')}
                    confirmTextIOS={t('common_Ok')}
                    date={to_dt}
                    headerTextIOS=""
                    isDarkModeEnabled={theme.includes('DARK')}
                    isVisible={visibleDatePickerTo}
                    locale={language === 'VI' ? 'vi_VN' : 'en_US'}
                    mode="date"
                    onCancel={hideDatePicker}
                    onConfirm={(value) => {
                        setVisibleDatePickerTo(false)
                        setToDt(value)
                        getOrderList(null, value)
                        // console.log(TAG, 'To date value: ', value)
                    }}
                />

                <Pressable
                    onPress={() => {
                        setVisibleTypeTranstation(true)
                    }}
                >
                    <View pointerEvents="none" style={UI.RowFilter}>
                        <CustomFloatInput
                            label={t('transaction_type')}
                            staticLabel
                            value={t(`${labelTypeTranstation}`)}
                            editable={false}
                            // rightComponent={<IconSelect />}
                            rightComponent={<IconArrDown style={{ color: styles.PRIMARY__CONTENT__COLOR, marginVertical: dm.vertical(20), marginRight: 5 }} />}
                        />
                    </View>
                </Pressable>

                <Row>
                    <Col size={12}>
                        <Pressable onPress={() => setVisibleDatePickerFrom(true)}>
                            <View pointerEvents="none" style={UI.GroupInput}>
                                <CustomFloatInput
                                    animationDuration={100}
                                    editable={false}
                                    label={t('common_from_date')}
                                    numberOfLines={1}
                                    rightComponent={
                                        <IconCalendar fill={styles.PRIMARY__CONTENT__COLOR} style={{ marginVertical: dm.vertical(20), marginRight: 5 }} />
                                    }
                                    staticLabel
                                    value={moment(from_dt).format('DD/MM/YYYY')}
                                />
                            </View>
                        </Pressable>
                    </Col>
                    <Col size={12}>
                        <Pressable
                            onPress={() => {
                                setVisibleDatePickerTo(true)
                            }}
                        >
                            <View pointerEvents="none" style={UI.GroupInput}>
                                <CustomFloatInput
                                    animationDuration={100}
                                    editable={false}
                                    label={t('common_to_date')}
                                    numberOfLines={1}
                                    rightComponent={
                                        <IconCalendar fill={styles.PRIMARY__CONTENT__COLOR} style={{ marginVertical: dm.vertical(20), marginRight: 5 }} />
                                    }
                                    staticLabel
                                    value={moment(to_dt).format('DD/MM/YYYY')}
                                />
                            </View>
                        </Pressable>
                    </Col>
                </Row>
                {/* ///////////////////////////////////////////////////////// */}
                <RowTitleGroup hasDivider text={t('transaction_history')} />
                <FlatList
                    data={newsList}
                    keyExtractor={(item, index) => String(index)}
                    renderItem={ViewListStatementChange}
                    style={{
                        marginBottom: dm.vertical(32),
                        paddingHorizontal: dm.moderate(16),
                    }}
                    showsVerticalScrollIndicator={false}
                    // refreshing={refreshing}
                    // onRefresh={onRefresh}
                />
            </Content>
        </Container>
    )
}

export default StatementExchangeLayout

const UI = StyleSheet.create({
    Button: {
        alignItems: 'center',
        borderRadius: 8,
        height: dm.moderate(28),
        justifyContent: 'center',
        width: dm.moderate(28),
    },
    GroupInput: {
        marginVertical: dm.moderate(4),
        paddingHorizontal: dm.halfIndent,
    },
    RowFilter: {
        marginHorizontal: dm.moderate(8),
        marginVertical: dm.vertical(8),
    },
    Row_Modal: {
        height: dm.vertical(24),
        marginVertical: dm.vertical(16),
    },
    bottomModal: {
        justifyContent: 'flex-end',
        margin: 0,
    },
    container: {
        alignItems: 'center',
        backgroundColor: '#ffffff',
        flex: 1,
        justifyContent: 'center',
    },
    margin_top_row: {
        marginBottom: dm.moderate(24),
        marginHorizontal: dm.moderate(16),
        marginTop: dm.moderate(16),
    },
    modalContent: {
        backgroundColor: 'white',
        borderColor: 'rgba(0, 0, 0, 0.1)',
        borderTopLeftRadius: 5,
        borderTopRightRadius: 5,
        paddingBottom: 40,
    },
    page: {
        flex: 1,
        flexDirection: 'column',
    },
    stepIndicator: {
        marginBottom: dm.vertical(8),
        marginTop: dm.vertical(24),
    },
})

const secondIndicatorStyles = {
    stepIndicatorSize: 32,
    currentStepIndicatorSize: 32,
    separatorStrokeWidth: 3,
    currentStepStrokeWidth: 4,
    stepStrokeCurrentColor: '#60B44A',
    stepStrokeWidth: 2,
    separatorStrokeFinishedWidth: 4,
    stepStrokeFinishedColor: '#60B44A',
    stepStrokeUnFinishedColor: '#aaaaaa',
    separatorFinishedColor: '#60B44A',
    separatorUnFinishedColor: '#aaaaaa',
    stepIndicatorFinishedColor: '#60B44A',
    stepIndicatorUnFinishedColor: '#ffffff',
    stepIndicatorCurrentColor: '#ffffff',
    stepIndicatorLabelFontSize: 13,
    currentStepIndicatorLabelFontSize: 13,
    stepIndicatorLabelCurrentColor: '#60B44A',
    stepIndicatorLabelFinishedColor: '#ffffff',
    stepIndicatorLabelUnFinishedColor: '#aaaaaa',
    labelColor: '#999999',
    labelSize: 13,
    currentStepLabelColor: '#60B44A',
}
