## [3.0.50](http://10.22.10.14:8001/coretrading/ssvmobile/compare/v3.100.1...v3.0.50) (2023-04-21)


### Bug Fixes

* fix add brokerID ekyc [#1877](http://10.22.10.14:8001/coretrading/ssvmobile/issues/1877) ([b180f0a](http://10.22.10.14:8001/coretrading/ssvmobile/commits/b180f0ae88198d0e112f19b2b1af5784cd9b0a5a))
* hot fix crash when coolieValue null econtract ([e12b1f0](http://10.22.10.14:8001/coretrading/ssvmobile/commits/e12b1f091b0d324eca67864d1184e96056289ca4))
* hot fix date time ekyc step 4 ([16b295f](http://10.22.10.14:8001/coretrading/ssvmobile/commits/16b295fac7eb6c152356518c622e5146ecc70fd5))
* remove ekyc vnpt and fix crash app when choose image signature ([2e1a2f1](http://10.22.10.14:8001/coretrading/ssvmobile/commits/2e1a2f1211e75196b6b17e9dc857c2f8f86d6c0c))
* show warning step scan face to step confirm info ([c9946e4](http://10.22.10.14:8001/coretrading/ssvmobile/commits/c9946e4c851fb4c6f1abf48c305b1ae099f6aaa3))
* task [#1079](http://10.22.10.14:8001/coretrading/ssvmobile/issues/1079) change text "register_account" ([bde3005](http://10.22.10.14:8001/coretrading/ssvmobile/commits/bde30051541937df98afa3d0b14da74bd737e495))


### Features

* add checking user exit for each EKYC step [#2002](http://10.22.10.14:8001/coretrading/ssvmobile/issues/2002) ([2cdc058](http://10.22.10.14:8001/coretrading/ssvmobile/commits/2cdc0586d1784a10f59b028caef7da81067d71ac))
* config build uat ([4dc7f58](http://10.22.10.14:8001/coretrading/ssvmobile/commits/4dc7f5893652fe9a8c06daa3b040ba8d01daa4d7))
* config deeplink and dynamic link mobile ([d9b747e](http://10.22.10.14:8001/coretrading/ssvmobile/commits/d9b747ed8b431007c1dd0ca0d2e7ae52266ed344))
* config firebase crashlytics ([ac46525](http://10.22.10.14:8001/coretrading/ssvmobile/commits/ac46525cb38092c7d7c57a33084a0e914bc6c007))
* config push notification uat ([5082f6b](http://10.22.10.14:8001/coretrading/ssvmobile/commits/5082f6b94160c2ef036d9b6c306b4b772ecd8984))
* config theme color ([bf6432e](http://10.22.10.14:8001/coretrading/ssvmobile/commits/bf6432e3d0702398b7ca6ed76fa3e47628eecd76))
* fix sort matching price [#1752](http://10.22.10.14:8001/coretrading/ssvmobile/issues/1752) ([2a2abea](http://10.22.10.14:8001/coretrading/ssvmobile/commits/2a2abeaff64c45a869957de780564abf04bcab4c))
* improve ekyc skip left,right ([8d41855](http://10.22.10.14:8001/coretrading/ssvmobile/commits/8d41855d0b43bcc1b27e06e2d26bdf2f3da1307b))
* improve take image national id card ([2005867](http://10.22.10.14:8001/coretrading/ssvmobile/commits/20058679706bdf38bc96fbc0f929eb486b87b726))
* Move recommendation to first tab and add button "ORTHER" ([024cc56](http://10.22.10.14:8001/coretrading/ssvmobile/commits/024cc56d6a85514d63bc0c8a5389c4afc0c359e6))
* remove bug snap ([44e3eb5](http://10.22.10.14:8001/coretrading/ssvmobile/commits/44e3eb55da3aec7aa6fd6e5a332d33f397e91953))
* renew cookie when exprition ([2ee056a](http://10.22.10.14:8001/coretrading/ssvmobile/commits/2ee056a46a352e052b287707cc829cf380772143))
* task [#1716](http://10.22.10.14:8001/coretrading/ssvmobile/issues/1716) change popup notification e-contract ([b3124af](http://10.22.10.14:8001/coretrading/ssvmobile/commits/b3124af8fa5443d0ecd6073d85de59f53bbe9e58))
* Update base UI for R1416 ([5bef0f7](http://10.22.10.14:8001/coretrading/ssvmobile/commits/5bef0f75a11a87dfce08d2b17e52490e3a974fbc))
* update build uat ([0bb63ad](http://10.22.10.14:8001/coretrading/ssvmobile/commits/0bb63adce1f7af34fbc425c18894d8286a61d0b4))
* update call show modal ([1b4a59c](http://10.22.10.14:8001/coretrading/ssvmobile/commits/1b4a59c13e5a5061d7e463400632208bbe9edd8d))
* update ekyc flow task 1777 ([431f853](http://10.22.10.14:8001/coretrading/ssvmobile/commits/431f853909747f19b01f55e21793de1b18edbfed))
* update ekyc new UI ([7828974](http://10.22.10.14:8001/coretrading/ssvmobile/commits/7828974721cc47abe16ef757b994bbe97bddd1af))
* update ekyc step ([b834218](http://10.22.10.14:8001/coretrading/ssvmobile/commits/b8342184f8e10f211a9cc8b0ad7343b19c6da2cd))
* update ekyc tracking step log ([e5bb2fd](http://10.22.10.14:8001/coretrading/ssvmobile/commits/e5bb2fda4f0e06aea7e1fb42a25554ed1d498551))
* update flow ekyc ([4cce3d1](http://10.22.10.14:8001/coretrading/ssvmobile/commits/4cce3d1f05c01d18101092a4a2f06c9b75e12ede))
* update new event tracking analytis ([05232af](http://10.22.10.14:8001/coretrading/ssvmobile/commits/05232afa7ec80a845229bb285becce65d8a0aa14))
* update new modal ([ffd94e0](http://10.22.10.14:8001/coretrading/ssvmobile/commits/ffd94e0a605243871527309cd49babc966cd0c55))
* update params ekyc log ([e67b5d3](http://10.22.10.14:8001/coretrading/ssvmobile/commits/e67b5d3f381d44ff5349e5a6ed1ba8b970833885))
* update tracking ekyc step ([63fa34c](http://10.22.10.14:8001/coretrading/ssvmobile/commits/63fa34c997babcd9893eecbf1270eeaeb14ea9e2))
* update tracking ga4 rm1745 ([9044a90](http://10.22.10.14:8001/coretrading/ssvmobile/commits/9044a9009b1971e984d64e58a0d4b2eee86b61b8))
* update workflow call create e-contract ([5ea457a](http://10.22.10.14:8001/coretrading/ssvmobile/commits/5ea457aeae2a38d0d595a6080922d5c51464452e))


### Reverts

* Revert "chore: fix arrow string language" ([b7f9d40](http://10.22.10.14:8001/coretrading/ssvmobile/commits/b7f9d40be5d0354e7d191e81a25c4500c4f3a32f))
* logic setListEContract ([6a37c5b](http://10.22.10.14:8001/coretrading/ssvmobile/commits/6a37c5b8bc7514941e966810fa6f0765c1c16852))



## [3.100.1](http://10.22.10.14:8001/coretrading/ssvmobile/compare/v3.100.0...v3.100.1) (2023-03-10)



# [3.100.0](http://10.22.10.14:8001/coretrading/ssvmobile/compare/v3.0.37...v3.100.0) (2023-03-10)


### Bug Fixes

* config build ([ab17d32](http://10.22.10.14:8001/coretrading/ssvmobile/commits/ab17d32a6bd0d4f46423ca8d52f54637615ea209))
* revert file ([e55ce39](http://10.22.10.14:8001/coretrading/ssvmobile/commits/e55ce391320bc1771f33074925a348bd34479236))


### Features

* Add new feature occupation and position ([01fd5de](http://10.22.10.14:8001/coretrading/ssvmobile/commits/01fd5dec63f29a19cdd2c03802b0a1edf7df5df6))
* config bum version ([9289209](http://10.22.10.14:8001/coretrading/ssvmobile/commits/92892092f598d11b56460ebb299723b4491c1bf9))
* **finance:** [#1292](http://10.22.10.14:8001/coretrading/ssvmobile/issues/1292) update radar chart profit and lot ([00545c7](http://10.22.10.14:8001/coretrading/ssvmobile/commits/00545c700c1514905eccac6a2b9987810b6b4e0c))
* hide function Register margin service for accounts SSTA/IICA/081F [#1513](http://10.22.10.14:8001/coretrading/ssvmobile/issues/1513) ([e05bb60](http://10.22.10.14:8001/coretrading/ssvmobile/commits/e05bb60ee7083a23aa4795c3f140056c9909ad3a))
* iOTP on MTS [#858](http://10.22.10.14:8001/coretrading/ssvmobile/issues/858) ([162ebb2](http://10.22.10.14:8001/coretrading/ssvmobile/commits/162ebb23c2b966e65b9aa1ed9c20bfb4ee1e037f))
* test new feature ([9f9dd15](http://10.22.10.14:8001/coretrading/ssvmobile/commits/9f9dd1571162252f446afb72e1c63cfd7db99193))
* update changelog ([414fc84](http://10.22.10.14:8001/coretrading/ssvmobile/commits/414fc84dd2adbccef8a563c16c8f95f35c80ed36))
* update changelog 3.0.46 ([2e4912d](http://10.22.10.14:8001/coretrading/ssvmobile/commits/2e4912dbefcb3d26f68cba1da25e8648680ba03f))
* update changelog 3.0.47 ([f5c8b79](http://10.22.10.14:8001/coretrading/ssvmobile/commits/f5c8b7980a5a1460204de1dcd1765bee38bdeda5))
* update changelog 3.0.47 ([1bccb86](http://10.22.10.14:8001/coretrading/ssvmobile/commits/1bccb86d19f68e8a4bd0a876ae3a20498645f29e))
* update changelog 3.0.48 ([38e885a](http://10.22.10.14:8001/coretrading/ssvmobile/commits/38e885ae2bb2f9b89bb1d94976c7f495e21c0c02))
* update color and status "hold" list recomendation [#1532](http://10.22.10.14:8001/coretrading/ssvmobile/issues/1532) ([c784c39](http://10.22.10.14:8001/coretrading/ssvmobile/commits/c784c39f2f238eaa4bf60fbe32a3e7de5a8fef55))
* update test ([d67488b](http://10.22.10.14:8001/coretrading/ssvmobile/commits/d67488b794f722b4fe9505de21043fbdc827c5e0))
* update test ([22cab4c](http://10.22.10.14:8001/coretrading/ssvmobile/commits/22cab4c04ecfa9d4f836641493ba6d6f8fa66cd1))



## [3.0.37](http://10.22.10.14:8001/coretrading/ssvmobile/compare/b8be8324a80ccc70ecc37748fe2f985622993ce0...v3.0.37) (2023-02-23)


### Bug Fixes

* **Finance:** fix data table and change title incomeStatement table ([8491fa2](http://10.22.10.14:8001/coretrading/ssvmobile/commits/8491fa2617c8bafd1d3d194c445bfad85832ce70))
* hotfix crash app when view econtract ([dc0a06b](http://10.22.10.14:8001/coretrading/ssvmobile/commits/dc0a06bb70f1e9fbb392d050f92962da45a8beeb))
* overlap layout header on iphone 14 pro ([478137f](http://10.22.10.14:8001/coretrading/ssvmobile/commits/478137f35e2733388bb6f86d6a2d0ad82ceaa5e1))


### Features

* config build env for uat and prod ([16be072](http://10.22.10.14:8001/coretrading/ssvmobile/commits/16be0722572c1d9511a0c056ed26baf91b4cd7de))
* config env uat, prod for android ([128b73a](http://10.22.10.14:8001/coretrading/ssvmobile/commits/128b73ac0672747e1158ce8528cd41b70565305b))
* config fastlane auto build ([14ce143](http://10.22.10.14:8001/coretrading/ssvmobile/commits/14ce143a529d96b5ff078694315a68213d77dc7b))
* config fastlane auto build android and ios ([01c1d8a](http://10.22.10.14:8001/coretrading/ssvmobile/commits/01c1d8a9e4cce41ebc0ebd5c9544c5c4b646f7fd))
* config gen change log ([53b12a2](http://10.22.10.14:8001/coretrading/ssvmobile/commits/53b12a2ba83b8e5112e7359fbe5322a6f137d72d))
* set up Husky and commitlint ([4629571](http://10.22.10.14:8001/coretrading/ssvmobile/commits/462957153652e8a1893a344b7af71c0085c5a721))
* setup commit lint ([70d9707](http://10.22.10.14:8001/coretrading/ssvmobile/commits/70d9707b5918c5444d48b2ce5f38f6de1845ddb6))
* update source uat ([b8be832](http://10.22.10.14:8001/coretrading/ssvmobile/commits/b8be8324a80ccc70ecc37748fe2f985622993ce0))


### Reverts

* Revert "chore: test update language" ([81611f3](http://10.22.10.14:8001/coretrading/ssvmobile/commits/81611f37497513eeeec1ec59f9943a4d21ed835b))



