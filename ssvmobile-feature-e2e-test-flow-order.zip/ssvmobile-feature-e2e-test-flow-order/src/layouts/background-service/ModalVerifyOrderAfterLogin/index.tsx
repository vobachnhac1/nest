import React, { memo, useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { InteractionManager, TouchableOpacity, View } from 'react-native'
import Modal from 'react-native-modal'
import ModalController from '@mts-components/appModal/modalControlller'
import useSafeModalState, { GLOBAL_MODAL_KEY } from '@mts-hooks/useSafeModalState'
import moment from 'moment'

import { Text } from '../../../basic-components'
import { ButtonCustom, ModalByView, ModalContent } from '../../../components/trading-component'
import { useUpdateEffect } from '../../../hoc'
import { StoreContext } from '../../../store'
import { StoreTrading } from '../../../store-trading'
import { dimensions, dimensions as dm, fontSizes, fontSizes as fs, IconSvg } from '../../../styles'
import { eventList, glb_sv, reqFunct, Screens, sendRequest } from '../../../utils'

// Khai báo ServiceInfo (nếu có)
const ServiceInfo: { [key: string]: ISserviceInfo } = {
    GET_CONFIRM_ORDER_LIST: {
        reqFunct: reqFunct.GET_CONFIRM_ORDER_LIST,
        WorkerName: 'FOSqOrder01',
        ServiceName: 'FOSqOrder01_Verify_Order',
        Operation: 'Q',
    },
}
const ModalVerifyOrderAfterLogin = () => {
    const { styles, applicationSettings } = useContext(StoreContext)
    const { userInfo } = useContext(StoreTrading)
    const { t } = useTranslation()
    // @ts-expect-error
    const navigation = glb_sv.navigation

    // All orther state
    const [isOpenModal, setIsOpenModal] = useSafeModalState(GLOBAL_MODAL_KEY.ModalConfirmOrderAfterLogin)
    const [lisUnconfirmOrder, setLisUnconfirmOrder] = useState([])

    // Start define all bussiness state

    useEffect(() => {
        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.SHOW_MODAL_CONFIRM_ORDER) {
                if (lisUnconfirmOrder.length === 0 && glb_sv.isInvestorUser()) {
                    // Nếu trước đó chưa check và là user thường (skip broker user)
                    getOrderList(moment(glb_sv.objShareGlb.workDate).subtract(1, 'months').toDate(), moment(glb_sv.objShareGlb.workDate).toDate())
                }
            }
        })
        return () => {
            commonEvent.unsubscribe()
        }
    }, [userInfo])

    const showModalRegisteriOtp = () => {
        if (glb_sv.objShareGlb.userInfo.c6 !== '5' && glb_sv.objShareGlb.userInfo.c9 !== 'N') {
            if (!glb_sv.configInfo?.application_style?.is_iotp_off) {
                if (!applicationSettings.app_settings?.iotp_modal_dont_ask_again) {
                    // Nếu user đã check iotp_modal_dont_ask_again thì skip
                    // Nếu chưa check thì show alert đăng kí iOTP
                    InteractionManager.runAfterInteractions(() => {
                        // navigation.navigate(Screens.ALERT_MODAL, {
                        // icon: <IconSvg.ErrorIcon color={styles.PRIMARY} />,
                        // title: t('common_notify'),
                        // content: t(t('notify_user_register_iotp')),
                        // footerComponent: <ComponentCheckDontAskIOTPAgain />,
                        // typeColor: styles.PRIMARY,
                        // showCancel: true,
                        //     linkCallback: () => navigation.navigate(Screens.ACTIVE_OTP),
                        // })
                        ModalController.showModal({
                            icon: <IconSvg.ErrorIcon color={styles.PRIMARY} />,
                            title: t('common_notify'),
                            content: t(t('notify_user_register_iotp')),
                            footerComponent: <ComponentCheckDontAskIOTPAgain />,
                            typeColor: styles.PRIMARY,
                            showCancel: true,
                            linkCallback: () => {
                                navigation.navigate(Screens.ACTIVE_OTP)
                            },
                        })
                    })
                }
            }
        }
    }

    const hideModal = () => {
        setIsOpenModal(false)
        showModalRegisteriOtp()
    }
    const navigate2OrderConfirm = () => {
        setIsOpenModal(false)
        navigation.navigate(Screens.VERIFY_ORDER, {})
    }
    const getOrderList = (start, from) => {
        if (!userInfo.actn_curr) {
            showModalRegisteriOtp()
            return
        }

        const InputParams = [
            userInfo.actn_curr,
            '%',
            moment(start).format('YYYYMMDD'),
            moment(from).format('YYYYMMDD'),
            'N', // Chưa confirm (%|Y|N)
        ]

        sendRequest(ServiceInfo.GET_CONFIRM_ORDER_LIST, InputParams, handleGetListOrderConfirmList)
    }

    const handleGetListOrderConfirmList = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            showModalRegisteriOtp()
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
                // console.log('handleGetListOrderConfirmList: ', jsondata)
                if (jsondata?.length !== 0) {
                    setIsOpenModal(true)
                    setLisUnconfirmOrder(jsondata)
                } else {
                    showModalRegisteriOtp()
                }
            } catch (err) {
                showModalRegisteriOtp()
            }
        }
    }

    return (
        <>
            {isOpenModal ? (
                <ModalByView isVisible={isOpenModal} useNativeDriver={true} onBackButtonPress={hideModal} onBackdropPress={hideModal}>
                    <ModalContent iconComponent={<IconSvg.ErrorIcon color={styles.WARN__COLOR} />} title={t('order_confirm')} type="notify">
                        <View style={{ height: 8 }} />
                        <View style={{ justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingHorizontal: dm.moderate(16) }}>
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fs.normal, textAlign: 'center' }}>
                                {t<string>('warn_has_not_confirm_order')}
                            </Text>
                        </View>

                        <ButtonCustom text={t('common_Ok')} type="confirm" onPress={navigate2OrderConfirm} />
                        <ButtonCustom last text={'common_Cancel'} type="back" onPress={hideModal} />
                    </ModalContent>
                </ModalByView>
            ) : null}
        </>
    )
}

const ComponentCheckDontAskIOTPAgain = () => {
    const { styles, applicationSettings, setApplicationSettings } = useContext(StoreContext)
    const { t } = useTranslation()

    const [isCheck, setIsCheck] = useState(applicationSettings?.app_settings?.iotp_modal_dont_ask_again)

    useUpdateEffect(() => {
        setApplicationSettings((prevConfig) => {
            const newConfig = { ...prevConfig }
            newConfig.app_settings.iotp_modal_dont_ask_again = isCheck
            return newConfig
        })
    }, [isCheck])

    const onChangeCheckDontAskAgain = () => {
        // glb_sv.commonEvent.next({ type: eventList.CANCEL_AND_CLOSE_ALERT_MODAL })
        setIsCheck(!applicationSettings?.app_settings?.iotp_modal_dont_ask_again)
    }

    return (
        <View
            style={{
                marginBottom: 16,
                flexDirection: 'row',
                alignItems: 'flex-start',
                borderRadius: 12,
                marginHorizontal: dimensions.moderate(16),
            }}
        >
            <TouchableOpacity
                activeOpacity={0.9}
                style={{ flexDirection: 'row', alignItems: 'center', marginTop: dimensions.vertical(16) }}
                onPress={onChangeCheckDontAskAgain}
            >
                <View style={{ paddingTop: 2 }}>
                    <IconSvg.CheckboxIcon active={isCheck} colorActive={styles.PRIMARY} colorunActive={styles.PRIMARY__CONTENT__COLOR} />
                </View>
                <Text
                    style={{
                        fontSize: fontSizes.small,
                        color: styles.PRIMARY__CONTENT__COLOR,
                        marginLeft: dimensions.moderate(8),
                        marginRight: 16,
                    }}
                >
                    {t<string>('dont_ask_me_again')}
                </Text>
            </TouchableOpacity>
        </View>
    )
}

export default memo(ModalVerifyOrderAfterLogin)
