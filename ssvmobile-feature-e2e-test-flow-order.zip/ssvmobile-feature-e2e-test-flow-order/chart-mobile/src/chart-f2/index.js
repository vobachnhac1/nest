import React, { PureComponent } from 'react'
import F2 from '@antv/f2'
import dayjs from 'dayjs'
import cloneDeep from 'lodash/cloneDeep'
import throttle from 'lodash/throttle'

// const colorIndexLight = ['#0B90FF', '#D100E3', '#03BD85']
// const colorIndexDark = ['#14B3FF', '#CB42DE', '#22AE89']
const colorIndexLight = ['#196EEE', '#FF0099', '#23AE5A']
const colorIndexDark = ['#196EEE', '#FF0199', '#07923D']
const colorIndexLightBlur = ['#1658BC', '#BD0272', '#06923D']
const colorIndexDarkBlur = ['#1658BC', '#BD0272', '#06923D']
/**
      "HSX|I|HSXIndex",
      "HNX|I|HNXIndex",
      "HNX|I|HNXUpcomIndex",
      "HSX|I|VN30",
      "HNX|I|HNX30"
**/

function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms))
}

export default class Chart extends PureComponent {
    constructor(props) {
        super(props)
        window.dataMarket = window.dataMarket || []
        this.timezone = new Date().getTimezoneOffset()
        this.throttled = throttle(
            () => {
                const now = dayjs().add(this.timezone + 420, 'minutes')
                if (dayjs(dayjs().format('YYYY-MM-DD') + ' 10:00:00', 'YYYY-MM-DD HH:mm:ss') - now > 0) {
                    if (this.chart) this.chart.changeData([...window.dataMarket])
                } else {
                    const newData = parseDataIndex(window.dataMarket)
                    if (this.chart) this.chart.changeData(newData)
                }
            },
            1000,
            { trailing: true },
        )
    }

    async componentDidMount() {
        this.eventMarket = window.eventMarket.subscribe((msg) => {
            if (msg.type === 'f2-history') {
                const newData = parseDataIndex(window.dataMarket)
                if (this.chart) this.chart.changeData(newData)
                else
                    setTimeout(() => {
                        this.throttled()
                    }, 1100)
            }
            if (msg.type === 'f2-realtime') {
                // if (!window.dataMarket.length) return; // fix đầu ngày không có dữ liệu
                if (window.dataMarket.length) {
                    const lastNode = window.dataMarket[window.dataMarket.length - 1]
                    if (lastNode && msg.newIndexNode) {
                        if (lastNode.time < msg.newIndexNode.time) {
                            window.dataMarket.push(msg.newIndexNode)
                            this.throttled()
                        }
                    }
                } else {
                    window.dataMarket.push(msg.newIndexNode)
                    this.throttled()
                }
            }
            if (msg.type === 'change_color_f2') {
                if (window.active === msg.data) return
                window.active = msg.data
                this.changeColor()
            }
            if (msg.type === 'f2_theme') {
                window.theme = msg.data
                this.changeColor()
            }
        })
        await sleep(1000)
        this.chart = new F2.Chart({
            id: 'chart-market',
            pixelRatio: window.devicePixelRatio,
            theme: 'dark',
            animate: false,
        })
        this.chart.source(parseDataIndex(window.dataMarket))
        this.chart.scale('time', {
            mask: 'HH:mm',
            type: 'timeCat',
            range: [0, 1],
            tickCount: 5,
        })
        this.chart.tooltip(false)
        this.chart.legend(false)
        this.chart.axis('time', {
            label: function label(text, index, total) {
                const textCfg = {
                    text,
                }
                if (index === 0) {
                    textCfg.textAlign = 'left'
                } else if (index === total - 1) {
                    textCfg.textAlign = 'right'
                }
                return textCfg
            },
            line: {
                stroke: 'transparent',
                lineWidth: 0,
            },
        })
        this.chart.axis('ratio', {
            position: 'right',
            label: function label(text) {
                return {
                    text: Math.round(text * 100) / 100 + '%',
                    fill: '#cacaca',
                }
            },
            grid: {
                type: 'line',
                stroke: 'transparent',
                lineWidth: 0,
                lineDash: [0],
            },
        })
        this.chart
            .line()
            .position('time*ratio')
            .color('S', function (type) {
                if (window.theme === 'LIGHT') {
                    if (type === window.listIndex[0]) {
                        return window.active === type ? colorIndexLight[0] : colorIndexLightBlur[0]
                    }
                    if (type === window.listIndex[1]) {
                        return window.active === type ? colorIndexLight[1] : colorIndexLightBlur[1]
                    }
                    if (type === window.listIndex[2]) {
                        return window.active === type ? colorIndexLight[2] : colorIndexLightBlur[2]
                    }
                } else {
                    if (type === window.listIndex[0]) {
                        return window.active === type ? colorIndexDark[0] : colorIndexDarkBlur[0]
                    }
                    if (type === window.listIndex[1]) {
                        return window.active === type ? colorIndexDark[1] : colorIndexDarkBlur[1]
                    }
                    if (type === window.listIndex[2]) {
                        return window.active === type ? colorIndexDark[2] : colorIndexDarkBlur[2]
                    }
                }
            })
            .size('S', function (type) {
                if (type === window.listIndex[0]) {
                    return window.active === type ? 2.5 : 1
                }
                if (type === window.listIndex[1]) {
                    return window.active === type ? 2.5 : 1
                }
                if (type === window.listIndex[2]) {
                    return window.active === type ? 2.5 : 1
                }
                return 1
            })
        this.chart.render()
    }

    componentWillUnmount() {
        this.eventMarket.unsubscribe()
        this.unmount = true
    }

    changeColor = () => {
        this.chart.clear()

        const now = dayjs().add(this.timezone + 420, 'minutes')
        let data = []
        if (dayjs(dayjs().format('YYYY-MM-DD') + ' 10:00:00', 'YYYY-MM-DD HH:mm:ss') - now > 0) {
            data = [...window.dataMarket]
        } else {
            data = parseDataIndex(window.dataMarket)
        }

        this.chart.source(data)
        this.chart.scale('time', {
            mask: 'HH:mm',
            type: 'timeCat',
            range: [0, 1],
            tickCount: 5,
        })
        this.chart.tooltip(false)
        this.chart.legend(false)
        this.chart.axis('time', {
            label: function label(text, index, total) {
                const textCfg = {
                    text,
                }
                if (index === 0) {
                    textCfg.textAlign = 'left'
                } else if (index === total - 1) {
                    textCfg.textAlign = 'right'
                }
                return textCfg
            },
            line: {
                stroke: 'transparent',
                lineWidth: 0,
            },
        })
        this.chart.axis('ratio', {
            position: 'right',
            label: function label(text) {
                return {
                    text: Math.round(text * 100) / 100 + '%',
                    fill: '#cacaca',
                }
            },
            grid: {
                type: 'line',
                stroke: 'transparent',
                lineWidth: 0,
                lineDash: [0],
            },
        })
        this.chart
            .line()
            .position('time*ratio')
            .color('S', function (type) {
                if (window.theme === 'LIGHT') {
                    if (type === window.listIndex[0]) {
                        return window.active === type ? colorIndexLight[0] : colorIndexLightBlur[0]
                    }
                    if (type === window.listIndex[1]) {
                        return window.active === type ? colorIndexLight[1] : colorIndexLightBlur[1]
                    }
                    if (type === window.listIndex[2]) {
                        return window.active === type ? colorIndexLight[2] : colorIndexLightBlur[2]
                    }
                } else {
                    if (type === window.listIndex[0]) {
                        return window.active === type ? colorIndexDark[0] : colorIndexDarkBlur[0]
                    }
                    if (type === window.listIndex[1]) {
                        return window.active === type ? colorIndexDark[1] : colorIndexDarkBlur[1]
                    }
                    if (type === window.listIndex[2]) {
                        return window.active === type ? colorIndexDark[2] : colorIndexDarkBlur[2]
                    }
                }
            })
            .size('S', function (type) {
                if (type === window.listIndex[0]) {
                    return window.active === type ? 2.5 : 1
                }
                if (type === window.listIndex[1]) {
                    return window.active === type ? 2.5 : 1
                }
                if (type === window.listIndex[2]) {
                    return window.active === type ? 2.5 : 1
                }
            })
            .animate(false)
        this.chart.render()
    }

    render() {
        return <canvas id="chart-market" />
    }
}

// // fix xử lý last data
function parseDataIndex(data) {
    const data1 = data.filter((e) => e.S === window.listIndex[0])
    const newData1 = chartConvert2Minutes(data1)
    const data2 = window.listIndex[1] ? data.filter((e) => e.S === window.listIndex[1]) : []
    const newData2 = chartConvert2Minutes(data2)
    const data3 = window.listIndex[2] ? data.filter((e) => e.S === window.listIndex[2]) : []
    const newData3 = chartConvert2Minutes(data3)
    return newData1.concat(newData2).concat(newData3)
}

function chartConvert2Minutes(data) {
    const arr = []
    for (let index = 0; index < data.length; index++) {
        const curItem = data[index]
        const prevItem = arr[arr.length - 1]
        const obj = cloneDeep(curItem)
        if (!arr.length) {
            arr.push(obj)
        } else {
            const momentCur = dayjs(curItem.time)
            const momentPrev = dayjs(prevItem.time)
            if (momentCur.minute() === momentPrev.minute() && momentCur.hour() === momentPrev.hour()) {
                // if (index === data.length - 1) {
                //     obj.time = momentCur.add(1, 'second').valueOf();
                //     arr.push(obj);
                // } else {
                //     prevItem.C = curItem.C;
                //     prevItem.V = prevItem.V + curItem.V;
                // }
                prevItem.C = curItem.C
                prevItem.ratio = curItem.ratio
                prevItem.V = prevItem.V + curItem.V
                continue
            } else {
                arr.push(obj)
            }
        }
    }
    return arr
}
