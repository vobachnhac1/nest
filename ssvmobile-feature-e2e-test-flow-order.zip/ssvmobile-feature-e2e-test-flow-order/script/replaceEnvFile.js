const fs = require('fs')
const fse = require('fs-extra')

function replaceEnvFile(source, destination) {
    try {
        const rootDir = process.cwd()
        const sourceFile = `${rootDir}/${source}`
        const destFile = `${rootDir}/${destination}`
        const data = fs.readFileSync(sourceFile, 'utf8')
        fs.writeFileSync(destFile, data, 'utf8')
    } catch (error) {
        console.error(error)
        process.exit(1) //error to not run next script command
    }
}

function replaceFolder(source, destination) {
    try {
        fse.copySync(source, destination, { overwrite: true })
    } catch (error) {
        console.error(error)
        process.exit(1) //error to not run next script command
    }
}

function replaceImge(source, destination) {
    fs.readFile(source, function (err, data) {
        if (err) throw err
        fs.writeFile(destination, data, function (err) {
            if (err) throw err
            console.log("It's saved!")
        })
    })
}

module.exports = { replaceEnvFile, replaceFolder, replaceImge }
