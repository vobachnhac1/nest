import React, { useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { useNavigation } from '@react-navigation/native'

import { StoreContext } from '../store'
import { alertType, eventList, glb_sv, Screens } from '../utils'

/**
 * Hàm có tác dụng: gọi otp khi có error
 *  TODO: Typescript
 */

interface IUseAlertModalOptions {
    icon?: React.ReactNode
    title?: string
    content?: string
    typeColor?: string
    callback?: (...args: any[]) => void
    continueVerify: boolean
    titleOK: string
}

const useAlertModal = (message: IServiceRespone, { icon, title, content, typeColor, callback, continueVerify, titleOK }: IUseAlertModalOptions) => {
    if (!continueVerify) return { hasAlert: false }
    // --------------------
    glb_sv.commonEvent.next({
        type: eventList.SHOW_ALERT,
        alertType: alertType.COMMON_ALERT,
        message,
        icon,
        title,
        content,
        typeColor,
        callback,
        titleOK,
    })
    return { hasAlert: true }
}

export default useAlertModal
