import React, { useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { Dimensions } from 'react-native'
import WebView from 'react-native-webview'
import ModalLoading from '@mts-components/modal-loading'
import { Container } from 'native-base'

import HeaderComponent from '../../../../components/header'
import useLoading from '../../../../hoc/useLoading'
import { StoreContext } from '../../../../store'

const { width, height } = Dimensions.get('window')

const ContractFileView = ({ navigation, route }) => {
    const { styles } = useContext(StoreContext)
    const { uri, contractName } = route?.params
    const { t } = useTranslation()
    const [loadingConfirm, setLoadingConfirm] = useLoading(true)

    return (
        <Container>
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft={true}
                navigation={navigation}
                title={contractName || t('econtract_detail_contract')}
                titleAlgin="flex-start"
            />
            <WebView
                cacheEnabled
                originWhitelist={['*']}
                scrollEnabled
                source={{ uri: uri }}
                startInLoadingState={true}
                style={{ width: width, height: height }}
                useWebKit={true}
                onLoad={() => setLoadingConfirm(false)}
            />
            {loadingConfirm ? <ModalLoading content={t('common_processing')} setLoading={setLoadingConfirm} visible={loadingConfirm} /> : null}
        </Container>
    )
}

export default ContractFileView
