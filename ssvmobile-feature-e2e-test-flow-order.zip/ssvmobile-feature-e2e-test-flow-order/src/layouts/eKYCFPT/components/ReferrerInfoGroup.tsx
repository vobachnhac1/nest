import React, { useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { ActivityIndicator, StyleSheet, TextInput, View } from 'react-native'

import { Text } from '../../../basic-components'
import { RowTitleGroup } from '../../../components/trading-component'
import useLoading from '../../../hoc/useLoading'
import { StoreContext } from '../../../store'
import { dimensions as dm, fontSizes as fs, fontWeights as fw } from '../../../styles'
import { sendRequest } from '../../../utils'

const ServiceInfo: IServiceInfo = {
    CheckNameReferrerCode: {
        WorkerName: 'FOSqAccount',
        ServiceName: 'FOSqAccount_Common_1',
        Operation: 'Q',
    },
}
interface IReferrerInfoGroupProps {
    onChangeReferrerInfo: (callbackData: { refCode: string; refName: string; institutional: string | '02' }) => void
    showRefCodeInput: boolean
    showRefNameInput: boolean
    institutional: '02' | '06' | '' | string
}
//  default institutional === 02 --> Loại tổ chức giới thiệu --> Có thể chọn trong tương lại giống SSV
export const ReferrerInfoGroup = ({ onChangeReferrerInfo = () => null, showRefCodeInput, showRefNameInput, institutional = '02' }: IReferrerInfoGroupProps) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()
    const [referrerCode, setReferrerCode] = useState('')
    const [referrerName, setReferrerName] = useState('')
    const [checking, setChecking] = useLoading(false)
    //------------------------
    const timeOutCheckName = useRef<any>(null)
    useEffect(() => {
        setReferrerName('')
        setChecking(true)
        if (timeOutCheckName.current) {
            clearTimeout(timeOutCheckName.current)
        }
        timeOutCheckName.current = setTimeout(() => {
            setChecking(false)
            checkNameByReferrerCode()
        }, 1000)
    }, [referrerCode])

    useEffect(() => {
        onChangeReferrerInfo({
            refCode: referrerCode,
            refName: referrerName,
            institutional,
        })
    }, [referrerCode, referrerName])

    const checkNameByReferrerCode = () => {
        const inval = ['07', institutional, referrerCode.trim()]
        sendRequest(ServiceInfo.CheckNameReferrerCode, inval, resultCheckNameReferrerCode)
    }

    const resultCheckNameReferrerCode = (reqInfoMap, message: IServiceRespone) => {
        if (Number(message.Result) === 0) {
        } else {
            let jsondata: IServiceResponeData[] = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {
                return
            }
            setReferrerName(jsondata[0]?.c0 || '')
        }
    }

    return (
        <>
            <View style={[UI.row, { alignItems: 'center' }, { display: showRefCodeInput ? 'flex' : 'none' }]}>
                <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fs.small, flex: 4 }}>{t<string>('referrer_code')}</Text>
                <View
                    style={{
                        flex: 5,
                        backgroundColor: styles.INPUT__BG,
                        paddingHorizontal: 10,
                        paddingVertical: 8,
                        borderRadius: 4,
                    }}
                >
                    <TextInput
                        autoCapitalize="none"
                        placeholder={t('enter_referrer_code')}
                        placeholderTextColor={styles.PLACEHODLER__COLOR}
                        returnKeyType="next"
                        style={{
                            fontSize: fs.small,
                            color: styles.PRIMARY__CONTENT__COLOR,
                            textAlignVertical: 'center',
                        }}
                        value={referrerCode}
                        onChangeText={(value) => {
                            setReferrerCode(value)
                        }}
                    />
                </View>
            </View>

            <View style={[UI.row, { alignItems: 'center' }, { display: showRefNameInput ? 'flex' : 'none' }]}>
                <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fs.small, flex: 4 }}>{t<string>('referrer_name')}</Text>
                <View
                    style={{
                        flex: 5,
                        backgroundColor: styles.INPUT__BG,
                        paddingHorizontal: 10,
                        paddingVertical: 8,
                        borderRadius: 4,
                    }}
                >
                    <TextInput
                        autoCapitalize="none"
                        editable={institutional !== '02'}
                        placeholder={institutional === '02' ? '' : t('enter_referrer_name')}
                        placeholderTextColor={styles.PLACEHODLER__COLOR}
                        returnKeyType="done"
                        style={{
                            fontSize: fs.small,
                            color: styles.PRIMARY__CONTENT__COLOR,
                            textAlignVertical: 'center',
                        }}
                        value={referrerName}
                        onChangeText={(value) => {
                            setReferrerName(value)
                        }}
                    />
                    {checking ? (
                        <View style={{ position: 'absolute', right: 16, top: 6 }}>
                            <ActivityIndicator color={styles.PRIMARY__CONTENT__COLOR} />
                        </View>
                    ) : null}
                </View>
            </View>
        </>
    )
}

const UI = StyleSheet.create({
    BlankSpace: {
        height: 10,
        width: dm.moderate(40),
    },
    ButtonDelete: {
        alignItems: 'center',
        height: '100%',
        justifyContent: 'center',
        position: 'absolute',
        right: 0,
    },
    GroupInput: {
        marginVertical: dm.halfVerticalIndent,
        paddingHorizontal: dm.halfIndent,
    },
    RowInput: {
        marginLeft: dm.moderate(8),
        marginVertical: dm.vertical(8),
    },
    modal: {
        justifyContent: 'flex-end',
        margin: 0,
    },
    row: {
        alignItems: 'center',
        borderRadius: 12,
        flexDirection: 'row',
        marginHorizontal: dm.moderate(16),
        marginTop: dm.vertical(12),
    },
})
