import React, { memo, useContext } from 'react'
import { Platform, Pressable } from 'react-native'
import AntDesign from 'react-native-vector-icons/AntDesign'
import { NavigationProp, ParamListBase } from '@react-navigation/native'
import { Body, Button, Header, Left, Right, Title, View } from 'native-base'

import IconBack from '../../assets/images/common/ic_back.svg'
import { Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { dimensions, fontSizes, fontWeights } from '../../styles'

const IOS = Platform.OS === 'ios' ? true : false

interface IHeaderComponent {
    navigation?: NavigationProp<ParamListBase>
    title?: string
    colorTitle?: string
    isShowLeft?: boolean
    leftButtonIcon?: any
    leftButtonLink?: Function
    transparent?: boolean
    hasTabs?: boolean
    titleAlgin?: 'center' | 'flex-start' | 'flex-end'
    changeTitle?: Function
    rightText?: string
    colorRightText?: string
    rightButtonLink?: Function
    rightButtonIcon?: any
    rightButtonSize?: number
    titleBigger?: boolean
    isShowRight?: boolean
    isShowRight2?: boolean
    rightButtonLink2?: Function
    rightButtonIcon2?: Function
    rightComponent?: any
    maxTitleLine?: number
}

const HeaderComponent = ({
    navigation,
    title,
    colorTitle,
    isShowLeft,
    leftButtonIcon,
    leftButtonLink,
    transparent,
    hasTabs,
    titleAlgin,
    changeTitle,
    rightText,
    colorRightText,
    rightButtonLink,
    rightButtonIcon,
    rightButtonSize,
    titleBigger,
    isShowRight,
    isShowRight2,
    rightButtonLink2,
    rightButtonIcon2,
    rightComponent,
    maxTitleLine,
}: IHeaderComponent) => {
    const { styles, theme, connected } = useContext(StoreContext)
    return (
        <Header
            androidStatusBarColor={transparent ? styles.PRIMARY__BG__COLOR : styles.PRIMARY__BG__COLOR}
            iosBarStyle={['DARK', 'CN_DARK'].includes(theme) ? 'light-content' : 'dark-content'}
            style={[
                { backgroundColor: transparent ? styles.PRIMARY__BG__COLOR : styles.PRIMARY__BG__COLOR, borderBottomWidth: 0 },
                IOS ? { height: 40 } : null,
                hasTabs ? { height: 55 } : null,
                connected ? null : { paddingTop: 0, height: 56 },
            ]}
            transparent
        >
            <Left style={{ width: 35, flex: 0, alignItems: 'center', justifyContent: 'center' }}>
                {isShowLeft ? (
                    <Pressable hitSlop={10} onPress={() => (leftButtonLink ? leftButtonLink() : navigation.goBack())}>
                        <IconBack height={dimensions.moderate(24)} style={{ color: styles.ICON__PRIMARY }} width={dimensions.moderate(24)} />
                    </Pressable>
                ) : (
                    <View />
                )}
            </Left>
            <Body style={{ flex: 3, alignItems: titleAlgin || 'center' }}>
                <Text
                    numberOfLines={maxTitleLine || 2}
                    style={{
                        color: colorTitle || styles.PRIMARY__CONTENT__COLOR,
                        fontSize: titleBigger ? fontSizes.big : fontSizes.xmedium,
                        fontWeight: titleBigger ? fontWeights.medium : fontWeights.semiBold,
                    }}
                    onPress={() => changeTitle && changeTitle()}
                >
                    {title}
                </Text>
            </Body>
            {isShowRight2 || isShowRight || rightComponent ? (
                <Right style={{ flex: 2, alignItems: 'center' }}>
                    {isShowRight2 ? (
                        <Button transparent onPress={() => rightButtonLink2 && rightButtonLink2()}>
                            {rightText ? (
                                <Title
                                    style={{
                                        color: colorRightText || styles.PRIMARY__CONTENT__COLOR,
                                        fontSize: fontSizes.xxmedium,
                                        fontWeight: fontWeights.normal,
                                    }}
                                >
                                    {rightText}
                                </Title>
                            ) : null}
                            {rightButtonIcon2 ? <AntDesign color={styles.PRIMARY__CONTENT__COLOR} name={rightButtonIcon2} size={dimensions.iconSize} /> : null}
                        </Button>
                    ) : null}
                    {isShowRight ? (
                        <Button transparent onPress={() => rightButtonLink && rightButtonLink()}>
                            {rightText ? (
                                <Title
                                    style={{
                                        color: colorRightText || styles.PRIMARY__CONTENT__COLOR,
                                        fontSize: fontSizes.xmedium,
                                        fontWeight: fontWeights.normal,
                                    }}
                                >
                                    {rightText}
                                </Title>
                            ) : null}
                            {rightButtonIcon ? (
                                <AntDesign
                                    color={colorRightText || styles.PRIMARY__CONTENT__COLOR}
                                    name={rightButtonIcon}
                                    size={rightButtonSize || dimensions.iconSize}
                                />
                            ) : null}
                        </Button>
                    ) : null}
                    {rightComponent ? rightComponent : null}
                </Right>
            ) : null}
        </Header>
    )
}
export default memo(HeaderComponent)
