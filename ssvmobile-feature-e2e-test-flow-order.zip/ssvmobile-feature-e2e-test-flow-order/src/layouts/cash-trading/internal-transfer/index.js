import React, { useContext, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { InteractionManager, Keyboard, RefreshControl, StyleSheet, View } from 'react-native'
import Modal from 'react-native-modal'
import StepIndicator from 'react-native-step-indicator'
import Svg, { Circle, ClipPath, Defs, G, Path } from 'react-native-svg'
import ToastGlobal from 'react-native-toast-message'
import { Container, Content, Tab, Tabs } from 'native-base'

import HeaderComponent from '../../../components/header'
import ModalLoading from '../../../components/modal-loading'
import { ButtonCustom, ModalContent, RowDataModal } from '../../../components/trading-component'
import { useAlertModal, useAlertModalCommonCode, useModalOtpWhenErr } from '../../../hoc'
import { StoreContext } from '../../../store'
import { StoreTrading } from '../../../store-trading'
import { dimensions as dm, IconSvg } from '../../../styles'
import { FormatNumber, glb_sv, reqFunct, Screens, wait } from '../../../utils'
import sendRequest from '../../../utils/sendRequest'
import StepOne from './step-one'
import StepTwo from './step-two'

// Khai báo ServiceInfo (nếu có)
const ServiceInfo = {
    CONFIRM_TRAN_SAME_ACT: {
        reqFunct: reqFunct.CONFIRM_TRAN_SAME_ACT, // Chuyển tiền cùng tài khoản
        WorkerName: 'FOSxCash',
        ServiceName: 'FOSxCash_0201_3',
        Operation: 'I',
    },
    CONFIRM_TRAN_DIFF_ACT: {
        reqFunct: reqFunct.CONFIRM_TRAN_DIFF_ACT, // Chuyển tiền khác tài khoản
        WorkerName: 'FOSxCash',
        ServiceName: 'FOSxCash_0201_2',
        Operation: 'I',
    },
}
const initErrCtrl = [
    {
        error: false,
        message: 'warning_trans_account',
    },
    {
        error: false,
        message: 'warning_cash_input',
    },
]
// Khai báo component
const InternalTranferLayout = ({ navigation }) => {
    const { styles } = useContext(StoreContext)
    const { userInfo } = useContext(StoreTrading)

    const { t } = useTranslation()
    // All orther state
    const [activeStep, setActiveStep] = useState(0)
    const [isOpenModal, setIsOpenModal] = useState(false)
    const [refreshing, setRefreshing] = React.useState(false)
    const [errCtrl, setErrCtrl] = useState(initErrCtrl)

    // Start define all bussiness state
    const [cashAvailable, setCashAvailable] = useState({})
    const [amoutTransfer, setAmoutTransfer] = useState('')

    const [objSubReceive, setObjSubReceive] = useState({})

    const [loadingConfirm, setLoadingConfirm] = useState(false)

    // End define form bussiness state
    // -------------------------------------------   Dùng useEffect get các dữ liệu cần thiết còn thiếu

    // -------------------------------------------   Viết các hàm để set lại bussiness form state. Nên viết đúng một chuẩn duy nhất để dễ control
    const onRefresh = React.useCallback(() => {
        setRefreshing(true)
        wait(300).then(() => setRefreshing(false))
    }, [])

    const switchStep = {
        goTo: (step) => setActiveStep(step),
        next: () => setActiveStep(activeStep + 1),
        prev: () => setActiveStep(activeStep - 1),
        submit: () => _handleSubmit(),
        onFinish: () => _checkValueBfSend(),
        getCurrent: () => {
            return activeStep
        },
    }

    const _handleSubmit = () => {
        if (userInfo.actn_curr === objSubReceive.c0) {
            confirmTransferCash()
        }
        if (userInfo.actn_curr !== objSubReceive.c0) {
            confirmTransferCashDiffAct()
        }
    }

    const hideModal = () => {
        setIsOpenModal(false)
    }
    const _resetInput = () => {
        onRefresh()
        Keyboard.dismiss()
        switchStep.goTo(0)
        hideModal()
    }
    const _onClickBackButton = () => {
        if (activeStep > 0) switchStep.prev()
        if (activeStep === 0) navigation.goBack()
    }

    const _checkValueBfSend = () => {
        hideModal()
        _validateValue()
        if (errCtrl.filter((item) => item.error === true).length === 0) {
            //----------------
            const isAuthenOTP = glb_sv.checkOtp(navigation, () => {
                setTimeout(() => {
                    setIsOpenModal((prev) => true)
                }, 100)
            })
            if (isAuthenOTP) {
                setIsOpenModal(true)
            }
            //---------------
        }
        return
    }

    const _validateValue = (inputIndex) => {
        const newErrCtrl = [...initErrCtrl]
        if (inputIndex === 0) newErrCtrl[0].error = !objSubReceive.c2?.length
        if (inputIndex === 1) newErrCtrl[1].error = Number(amoutTransfer) <= 0 || !amoutTransfer
        if (!inputIndex && inputIndex !== 0) {
            // check all
            newErrCtrl[0].error = !objSubReceive.c2?.length
            newErrCtrl[1].error = Number(amoutTransfer) <= 0 || !amoutTransfer
        }
        setErrCtrl(newErrCtrl)
    }

    // -------------------------------------------   Khai báo các hàm gửi (request) lên server
    const confirmTransferCash = () => {
        hideModal()
        InteractionManager.runAfterInteractions(() => {
            const InputParams = [userInfo.actn_curr, userInfo.sub_curr, objSubReceive.c0, objSubReceive.c1, String(amoutTransfer), '']
            sendRequest(ServiceInfo.CONFIRM_TRAN_SAME_ACT, InputParams, handleconfirmTransferCash)
            setLoadingConfirm(true)
        })
    }

    const confirmTransferCashDiffAct = () => {
        hideModal()
        InteractionManager.runAfterInteractions(() => {
            const InputParams = [
                userInfo.actn_curr,
                userInfo.sub_curr,
                '4',
                '1',
                '',
                '',
                String(amoutTransfer),
                '0',
                '',
                '',
                '',
                '',
                '',
                '',
                '',
                objSubReceive.c0,
                objSubReceive.c1,
            ]
            sendRequest(ServiceInfo.CONFIRM_TRAN_DIFF_ACT, InputParams, handleconfirmTransferCash)
            setLoadingConfirm(true)
        })
    }

    const handleconfirmTransferCash = (reqInfoMap, message) => {
        setLoadingConfirm(false)
        // -- process after get result --
        if (Number(message.Result) === 0) {
            const { hasAlertCommonCode } = useAlertModalCommonCode(message, {})
            const { hasAlertErrOtp } = useModalOtpWhenErr(message, { continueVerify: !hasAlertCommonCode, callback: () => setIsOpenModal((prev) => true) })
            useAlertModal(message, { continueVerify: !hasAlertErrOtp })
        } else {
            ToastGlobal.show({
                type: 'success',
                text2: message.Message,
            })
            _resetInput()
        }
    }

    // -------------------------------------------   Khai báo các hàm gửi (request) và nhận (handle respone) dữ liệu từ server

    const renderStepIndicator = (params) => {
        if (params.position === 0) {
            return (
                <View>
                    <Svg fill="none" height={30} viewBox="0 0 30 30" width={30} xmlns="http://www.w3.org/2000/svg">
                        <Circle cx={15} cy={15} fill={params.position <= switchStep.getCurrent() ? '#60B44A' : '#D1D5DB'} r={15} />
                        <Path
                            d="M15 21.916l1.469-.339-1.13-1.13-.34 1.47zM14.71 20.949l.243-1.053.002-.008a.493.493 0 01.004-.013l.004-.012a.176.176 0 01.015-.032.27.27 0 01.008-.013l.005-.008a.21.21 0 01.015-.02l.01-.01.004-.005 3.275-3.275c-.914-1.88-2.605-3-4.545-3-1.423 0-2.737.609-3.7 1.714C9.078 16.328 8.531 17.88 8.5 19.6c.574.289 2.93 1.401 5.249 1.401.32 0 .641-.018.96-.051zM15.548 19.951l3.889-3.888 1.414 1.414-3.889 3.888-1.414-1.414zM13.75 13a2.5 2.5 0 100-5 2.5 2.5 0 000 5zM21.5 16.416a1 1 0 00-1.707-.707l1.414 1.414a.994.994 0 00.293-.707z"
                            fill="#fff"
                        />
                    </Svg>
                </View>
            )
        }
        if (params.position === 1) {
            return (
                <View>
                    <Svg fill="none" height={30} viewBox="0 0 30 30" width={30} xmlns="http://www.w3.org/2000/svg">
                        <Circle cx={15} cy={15} fill={params.position <= switchStep.getCurrent() ? '#60B44A' : '#D1D5DB'} opacity={1} r={15} />
                        <Path
                            d="M15 8.5A6.507 6.507 0 008.5 15c0 3.584 2.916 6.5 6.5 6.5s6.5-2.916 6.5-6.5-2.916-6.5-6.5-6.5zm-1.188 9.762l-2.518-2.8.743-.668 1.75 1.944 4.15-4.942.767.642-4.892 5.824z"
                            fill={'#fff'}
                            // opacity={0.1}
                        />
                    </Svg>
                </View>
            )
        }
    }

    return (
        <Container>
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft
                leftButtonLink={_onClickBackButton}
                navigation={navigation}
                title={t('title_money_transfer')}
                titleAlgin="flex-start"
                transparent
            />
            <Content
                refreshControl={
                    <RefreshControl
                        refreshing={refreshing}
                        onRefresh={onRefresh} // title={t('pull_refresh')}
                        // titleColor={styles.PRIMARY__CONTENT__COLOR}
                        tintColor={styles.PRIMARY__CONTENT__COLOR}
                    />
                }
                style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}
            >
                <View style={UI.stepIndicator}>
                    <StepIndicator
                        currentPosition={activeStep}
                        customStyles={secondIndicatorStyles}
                        labels={[t('choose_account'), t('trading_confirm')]}
                        renderStepIndicator={renderStepIndicator}
                        stepCount={2}
                        onPress={switchStep.goTo}
                    />
                </View>
                <Tabs locked page={activeStep} renderTabBar={() => <View />} style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
                    <Tab heading={<View />} style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
                        <StepOne
                            cashAvailable={cashAvailable}
                            navigation={navigation}
                            refreshing={refreshing}
                            setCashAvailable={setCashAvailable}
                            switchStep={switchStep}
                            onRefresh={onRefresh}
                        />
                    </Tab>
                    <Tab heading={<View />} style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
                        <StepTwo
                            _validateValue={_validateValue}
                            amoutTransfer={amoutTransfer}
                            cashAvailable={cashAvailable}
                            errCtrl={errCtrl}
                            navigation={navigation}
                            objSubReceive={objSubReceive}
                            setAmoutTransfer={setAmoutTransfer}
                            setCashAvailable={setCashAvailable}
                            setErrCtrl={setErrCtrl}
                            setObjSubReceive={setObjSubReceive}
                            switchStep={switchStep}
                            onRefresh={onRefresh}
                        />
                    </Tab>
                </Tabs>
            </Content>
            {/* **************************************** Modal submit ******************************************/}
            {isOpenModal && (
                <Modal isVisible={isOpenModal} useNativeDriver={true} onBackButtonPress={hideModal} onBackdropPress={hideModal}>
                    <ModalContent
                        iconComponent={
                            <Svg fill="none" height={32} viewBox="0 0 33 32" width={33} xmlns="http://www.w3.org/2000/svg">
                                <G clipPath="url(#prefix__clip0)" fill="#2ECC71">
                                    <Path d="M8.927 8.917a10.052 10.052 0 017.13-2.953 10.048 10.048 0 017.13 2.953c.4.4.762.829 1.086 1.283V9.12a6.295 6.295 0 00-6.288-6.288h-7.8V.063L.057 6.444l7.258 4.574c.44-.765.98-1.469 1.612-2.101zM32.058 25.649L24.8 21.075a10.07 10.07 0 01-1.611 2.101 10.046 10.046 0 01-7.13 2.953 10.044 10.044 0 01-7.13-2.953c-.4-.4-.762-.829-1.086-1.283v1.081a6.295 6.295 0 006.288 6.288h7.8v2.769l10.128-6.382z" />
                                    <Path d="M7.85 16.047a8.206 8.206 0 1016.411 0 8.206 8.206 0 00-16.411 0zm5.081-1.334c0-1.16.842-2.134 2.524-2.37v-1.118h1.447v1.098c.76.071 1.498.266 2.083.595l-.729 1.754c-.708-.36-1.375-.534-2-.534-.708 0-.934.206-.934.452 0 .862 3.97.143 3.97 2.79 0 1.109-.8 2.073-2.39 2.35v1.14h-1.447v-1.088c-1.026-.062-2.02-.34-2.637-.719l.78-1.764c.677.4 1.58.656 2.37.656.688 0 .934-.143.934-.39 0-.903-3.97-.174-3.97-2.852z" />
                                </G>
                                <Defs>
                                    <ClipPath id="prefix__clip0">
                                        <Path d="M0 0h32v32H0z" fill="#fff" transform="translate(.057)" />
                                    </ClipPath>
                                </Defs>
                            </Svg>
                        }
                        title={t('trading_confirm')}
                        type="confirm"
                    >
                        <RowDataModal dataSub={[userInfo.actn_curr, userInfo.sub_curr]} textLeft={t('trans_sub_account')} textRight={userInfo.actn_curr} />
                        <RowDataModal dataSub={[objSubReceive.c0, objSubReceive.c1]} textLeft={t('receive_sub_account')} textRight={objSubReceive.c0} />
                        <RowDataModal last textLeft={t('transfer_amount')} textRight={FormatNumber(amoutTransfer)} />
                        <ButtonCustom text={t('common_button_confirm')} type="confirm" onPress={switchStep.submit} />
                        <ButtonCustom last text={t('common_Cancel')} type="back" onPress={hideModal} />
                    </ModalContent>
                </Modal>
            )}
            {loadingConfirm && <ModalLoading content={t('common_processing')} visible={loadingConfirm} />}
        </Container>
    )
}

export default InternalTranferLayout

const UI = StyleSheet.create({
    Badge_Sub_Small: {
        alignItems: 'center',
        borderRadius: 4,
        height: dm.moderate(16),
        justifyContent: 'center',
        marginLeft: 4,
        width: dm.moderate(16),
    },
    Row_Modal: {
        height: dm.vertical(24),
        marginVertical: dm.vertical(16),
    },
    page: {
        flex: 1,
        flexDirection: 'column',
    },
    stepIndicator: {
        marginBottom: dm.vertical(8),
        marginTop: dm.vertical(24),
    },
})

const secondIndicatorStyles = {
    stepIndicatorSize: 32,
    currentStepIndicatorSize: 32,
    separatorStrokeWidth: 3,
    currentStepStrokeWidth: 4,
    stepStrokeCurrentColor: '#60B44A',
    stepStrokeWidth: 2,
    separatorStrokeFinishedWidth: 4,
    stepStrokeFinishedColor: '#60B44A',
    stepStrokeUnFinishedColor: '#aaaaaa',
    separatorFinishedColor: '#60B44A',
    separatorUnFinishedColor: '#aaaaaa',
    stepIndicatorFinishedColor: '#60B44A',
    stepIndicatorUnFinishedColor: '#ffffff',
    stepIndicatorCurrentColor: '#ffffff',
    stepIndicatorLabelFontSize: 13,
    currentStepIndicatorLabelFontSize: 13,
    stepIndicatorLabelCurrentColor: '#60B44A',
    stepIndicatorLabelFinishedColor: '#ffffff',
    stepIndicatorLabelUnFinishedColor: '#aaaaaa',
    labelColor: '#999999',
    labelSize: 13,
    currentStepLabelColor: '#60B44A',
}
