import React, { useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { Pressable, StyleSheet, View } from 'react-native'
import { useNavigation, useRoute } from '@react-navigation/native'
import { Button } from 'native-base'

import { Text } from '../../../basic-components'
import { StoreContext } from '../../../store'
import { dimensions, fontSizes, fontWeights } from '../../../styles'
import { eventList, FormatNumber, glb_sv, Screens } from '../../../utils'

export const RowExpandStock = ({ section }) => {
    const { t } = useTranslation()
    const { styles } = useContext(StoreContext)
    const navigation = useNavigation()
    const route = useRoute()

    const getOrder = (t55, sell_buy) => {
        glb_sv.objLastOrder.orderTp = '01'
        glb_sv.objLastOrder.stockCode = t55
        glb_sv.objLastOrder.price = 0
        glb_sv.objLastOrder.qty = 0
        const currentRoute = route.name
        // console.log('currentRoute', currentRoute)
        if (currentRoute !== Screens.PLACE_ORDER_TAB) {
            // màn hình tài sản # màn hình lệnh
            navigation.navigate(Screens.PLACE_ORDER_TAB, {
                t55,
                sell_buy,
            })
        } else {
            // Tab tài sản nằm trong màn hình lệnh
            glb_sv.commonEvent.next({
                type: eventList.ORDER,
                buysell_tp: 'sell',
                stk_cd: t55,
            })
        }
    }

    const openExpectedRightInfo = () => {
        if (glb_sv.configInfo.application_style.is_show_expected_rights_screen) {
            navigation.navigate(Screens.EXPECT_RIGHT_INFO)
        }
    }

    return (
        <View
            style={[
                {
                    borderBottomColor: styles.DIVIDER__COLOR,
                    backgroundColor: styles.SECOND__BG__COLOR,
                },
                UI.ExpandWrap,
            ]}
        >
            <View style={UI.renderContentWrap}>
                <View>
                    <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small }}>{t('quantity_wait_trading')}</Text>
                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small }}>{FormatNumber(section.c5)}</Text>
                </View>
                <Pressable onPress={openExpectedRightInfo}>
                    <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small }}>{t('head_right_quanlity')}</Text>
                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small }}>{FormatNumber(section.c14)}</Text>
                </Pressable>
                <View>
                    <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small }}>{t('quantity_blockade')}</Text>
                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small }}>{FormatNumber(section.c7)}</Text>
                </View>
                <View>
                    <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small }}>{t('quantity_sale_wait_settlement')}</Text>
                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small }}>
                        {Number(section.c8) > 0 || Number(section.c9) > 0 || Number(section.c10) > 0 ? '- ' : ' '}
                        {FormatNumber(Number(section.c8) + Number(section.c9) + Number(section.c10))}
                    </Text>
                </View>
            </View>
            <View style={UI.renderContentRow2}>
                <Pressable style={{ alignSelf: 'center', justifyContent: 'center', flex: 1 }} onPress={openExpectedRightInfo}>
                    <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small }}>{t('wait_for')}</Text>
                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small }}>
                        {section.c11 == 0 && section.c12 == 0 && section.c13 == 0 && 0}
                        {section.c11 > 0 && `T0: ${FormatNumber(section.c11)}`}
                        {Number(section.c11) > 0 && (Number(section.c12) > 0 || Number(section.c13) > 0) && '|'}
                        {section.c12 > 0 && `T1: ${FormatNumber(section.c12)}`}
                        {Number(section.c12) > 0 && Number(section.c13) > 0 && '|'}
                        {section.c13 > 0 && `T2: ${FormatNumber(section.c13)}`}
                        {/* T0: {FormatNumber(section['c11'])} | T1: {FormatNumber(section['c12'])} | T2: {FormatNumber(section['c13'])} */}
                    </Text>
                </Pressable>
                <View style={{ flex: 1 }}>
                    <Button
                        block
                        style={[
                            {
                                backgroundColor: styles.UP__COLOR,
                            },
                            UI.Button,
                        ]}
                        onPress={() => getOrder(section.c2, 'buy')}
                    >
                        <Text style={UI.TextButtonUI}>{t('place_order')}</Text>
                    </Button>
                </View>
            </View>
        </View>
    )
}

const UI = StyleSheet.create({
    Button: {
        borderRadius: 5,
        flex: 1,
        height: dimensions.vertical(40, 0.5),
        marginVertical: dimensions.indent,
    },
    ExpandWrap: {
        borderBottomWidth: 1,
        flexDirection: 'column',
        marginHorizontal: dimensions.moderate(4),
        paddingHorizontal: dimensions.moderate(4),
        paddingTop: dimensions.moderate(4),
    },
    TextButtonUI: { color: 'white', fontSize: fontSizes.small, fontWeight: fontWeights.bold },
    renderContentRow2: { alignItems: 'center', display: 'flex', flexDirection: 'row', justifyContent: 'space-between' },
    renderContentWrap: { display: 'flex', flexDirection: 'row', justifyContent: 'space-between', marginVertical: dimensions.moderate(5) },
})
