import React, { memo, useContext } from 'react'
import { useTranslation } from 'react-i18next'
import { Row } from 'react-native-easy-grid'
import Svg, { Path } from 'react-native-svg'
import moment from 'moment'

import { Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { dimensions, fontSizes } from '../../styles'

const HistoryChangeInfo = ({ tradStatus, timeIndex }) => {
    const { styles } = useContext(StoreContext)
    const { t } = useTranslation()

    return (
        <Row style={{ paddingHorizontal: dimensions.moderate(8) }}>
            <Svg height={16} viewBox="0 0 16 16" width={16} xmlns="http://www.w3.org/2000/svg">
                <Path d="M8 1.5a6.5 6.5 0 100 13 6.5 6.5 0 000-13zM11 9H8a.5.5 0 01-.5-.5V4a.5.5 0 111 0v4H11a.5.5 0 010 1z" fill={styles.ICON__CLOCK} />
            </Svg>
            <Text style={{ fontSize: fontSizes.tiny, color: styles.HEADER__CONTENT__COLOR }}> {t(tradStatus)}</Text>
            {timeIndex && tradStatus !== 'priceboard_Not_traded' ? (
                <Text style={{ fontSize: fontSizes.tiny, color: styles.HEADER__CONTENT__COLOR }}>
                    {' '}
                    {moment(timeIndex, 'YYYYMMDD-HH:mm:ss').format('HH:mm DD/MM')}
                    {/* Asia/Ho_Chi_Minh */}
                </Text>
            ) : null}
        </Row>
    )
}

export default memo(HistoryChangeInfo)
