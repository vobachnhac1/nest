import React, { memo, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { InteractionManager, StyleSheet, TouchableOpacity, View } from 'react-native'
import Modal from 'react-native-modal'
import DateTimePickerModal from 'react-native-modal-datetime-picker'
import { SwipeListView } from 'react-native-swipe-list-view'
import ToastGlobal from 'react-native-toast-message'
import AntDesign from 'react-native-vector-icons/AntDesign'
import ModalController from '@mts-components/appModal/modalControlller'
import moment from 'moment'
import { Body, Button, Row } from 'native-base'

import { enhance, Text, TextInput } from '../../basic-components'
import AccountModal from '../../components/account/account-modal'
import { StoreContext } from '../../store'
import { StoreTrading } from '../../store-trading'
import { dimensions, fontSizes, fontWeights, IconSvg } from '../../styles'
import { dataCryption, eventList, FormatNumber, glb_sv, reqFunct, Screens, sendRequest } from '../../utils'

const ServiceInfo = {
    GET_ADV_ORDER_LIST: {
        reqFunct: reqFunct.GET_ADV_ORDER_LIST,
        WorkerName: 'FOSqOrder01',
        ServiceName: 'FOSqOrder01_0509_1',
        Operation: 'Q',
        ClientSentTime: '0',
    },
    CANCEL_ADV_ORDER: {
        reqFunct: reqFunct.CANCEL_ADV_ORDER,
        WorkerName: 'FOSxOrder',
        ServiceName: 'FOSxOrder_0509_2',
        Operation: 'I',
        ClientSentTime: '0',
    },
}

const ListStatus = [
    { label: 'common_all', value: '%' },
    { label: 'wait_to_process', value: '1' },
    { label: 'processed', value: '2' },
    { label: 'common_Cancel', value: '3' },
    { label: 'wait_tranfer', value: '4' },
    { label: 'reject', value: '9' },
]

const translateOrderTp = (value) => {
    if (value === '01') {
        return 'order_Limit'
    } else if (value === '02') {
        return 'order_Mp'
    } else if (value === '03') {
        return 'order_ATO'
    } else if (value === '04') {
        return 'order_ATC'
    } else if (value === '06') {
        return 'order_MOK'
    } else if (value === '07') {
        return 'order_MAK'
    } else if (value === '08') {
        return 'order_MTL'
    } else if (value === '15') {
        return 'order_PLO'
    } else return value
}

function AdvanceOrderList({ navigation, refreshing, isGTCOrder }) {
    const { styles, theme, language } = useContext(StoreContext)
    const { userInfo } = useContext(StoreTrading)

    const { t } = useTranslation()
    const [list, setList] = useState([])
    const listTemple = useRef([])

    const [options, setOptions] = useState({
        orderStatus: '%',
        stock: '',
        from_dt: glb_sv.objShareGlb.workDate
            ? moment(glb_sv.objShareGlb.workDate, 'YYYYMMDD').subtract(15, 'day').toDate()
            : moment().subtract(15, 'day').toDate(),
        to_dt: glb_sv.objShareGlb.workDate ? moment(glb_sv.objShareGlb.workDate, 'YYYYMMDD').add(15, 'day').toDate() : moment().add(15, 'day').toDate(),
    })

    const optionsRef = useRef({
        orderStatus: '%',
        stock: '',
        from_dt: glb_sv.objShareGlb.workDate
            ? moment(glb_sv.objShareGlb.workDate, 'YYYYMMDD').subtract(15, 'day').toDate()
            : moment().subtract(15, 'day').toDate(),
        to_dt: glb_sv.objShareGlb.workDate ? moment(glb_sv.objShareGlb.workDate, 'YYYYMMDD').add(15, 'day').toDate() : moment().add(15, 'day').toDate(),
    })

    const [isDatePickerFrom, setisDatePickerFrom] = useState(false)
    const [isDatePickerTo, setisDatePickerTo] = useState(false)

    const [visibleStatus, setVisibleStatus] = useState(false)

    const timeOutSearch = useRef(null)

    const [modalCancelOrder, setModalCancelOrder] = useState(false)
    const [data, setData] = useState({})

    const sendCancelOrderFlag = useRef(false)
    const timeoutGetListOrder = useRef(null)

    const itemAction = useRef(null)

    const [passTrading, setPassTrading] = useState('')

    useEffect(() => {
        if (timeoutGetListOrder.current) clearTimeout(timeoutGetListOrder.current)
        timeoutGetListOrder.current = setTimeout(() => {
            getAdvOrderList()
        }, 1000)

        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.REFRESH_ADVORDER_LIST) {
                if (timeoutGetListOrder.current) clearTimeout(timeoutGetListOrder.current)
                timeoutGetListOrder.current = setTimeout(() => {
                    getAdvOrderList()
                }, 1000)
            }
        })

        return () => {
            commonEvent.unsubscribe()
        }
    }, [userInfo])
    useEffect(() => {
        // Khi pull refresh thì lấy lại danh sách lệnh
        if (refreshing) getAdvOrderList()
    }, [refreshing])

    const getAdvOrderList = () => {
        if (!userInfo.actn_curr) {
            ToastGlobal.show({
                type: 'warning',
                text2: t('warning_account_is_empty'),
            })
            return
        }

        listTemple.current = []
        setList([])

        const start_dt = moment(optionsRef.current.from_dt).format('YYYYMMDD')
        const end_dt = moment(optionsRef.current.to_dt).format('YYYYMMDD')
        const InputParams = ['2', userInfo.actn_curr, userInfo.sub_curr, start_dt, end_dt, '%', '%']
        sendRequest(ServiceInfo.GET_ADV_ORDER_LIST, InputParams, getAdvOrderListResultProc, true, getAdvOrderListTimeout, '', 0, 'equal_service')
    }

    const getAdvOrderListTimeout = () => null

    const getAdvOrderListResultProc = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) {
                console.log('getHotNewsResultProc error', err)
                return
            }
            listTemple.current = listTemple.current.concat(jsondata)
            if (Number(message.Packet) <= 0) {
                filterData()
            }
        }
    }

    const changeOrderDetail = useCallback((item) => {
        navigation.navigate(Screens.ADVORDER_DETAIL, { stockCode: item.c4, orderID: item.c0, item })
    }, [])

    const renderItem = useCallback(({ item }) => {
        return (
            <RowItem
                c19={item.c19}
                c3={item.c3}
                c4={item.c4}
                c6={item.c6}
                c7={item.c7}
                c8={item.c8}
                changeOrderDetail={changeOrderDetail}
                item={item}
                styles={styles}
                t={t}
            />
        )
    })

    const renderHiddenItem = (data) => {
        return <HiddenItemWithActions data={data} showModalCancel={showModalCancel} />
    }

    const showModalCancel = (item) => {
        if (item) itemAction.current = item
        if (!itemAction.current) return
        if (!glb_sv.checkOtp(navigation, showModalCancel)) return
        setData(itemAction.current)
        setModalCancelOrder(true)
    }

    const getListOrderByStock = (name) => {
        optionsRef.current.stock = name
        setOptions({ ...optionsRef.current })
        if (timeOutSearch.current) clearTimeout(timeOutSearch.current)
        timeOutSearch.current = setTimeout(() => {
            filterData()
        }, 500)
    }

    const filterData = () => {
        let data = listTemple.current.slice()
        const { stock, orderStatus } = optionsRef.current
        if (stock) {
            data = data.filter((e) => e.c4.includes(stock) || stock.includes(e.c4))
        }
        if (orderStatus !== '%') {
            data = data.filter((e) => e.c8 === orderStatus)
        }
        if (isGTCOrder) {
            data = data.filter((e) => e.c24 === 'G')
        } else {
            data = data.filter((e) => e.c24 !== 'G')
        }

        const result = data.reduce(function (accumulator, currentValue, currentIndex, array) {
            const obj = accumulator.find((e) => e.title === currentValue.c22)
            if (obj) {
                obj.data.push(currentValue)
            } else {
                accumulator.push({
                    title: currentValue.c22,
                    data: [currentValue],
                })
            }
            return accumulator
        }, [])
        setList(result)
    }

    const textSectionHeaderStyle = useMemo(
        () => enhance([{ color: styles.PRIMARY, fontSize: fontSizes.medium, backgroundColor: styles.PRIMARY__BG__COLOR, paddingVertical: 5 }]),
        [],
    )

    const hideDatePicker = () => {
        setisDatePickerFrom(false)
        setisDatePickerTo(false)
    }

    const sendCancelAdvOrder = () => {
        if (sendCancelOrderFlag.current) return
        sendCancelOrderFlag.current = true
        setModalCancelOrder(false)
        InteractionManager.runAfterInteractions(() => {
            const passTradingEncryt = passTrading ? dataCryption.encryptString(passTrading) : ''
            const InputParams = [data.c17, data.c0, data.c1, passTradingEncryt, data.c22]
            sendRequest(ServiceInfo.CANCEL_ADV_ORDER, InputParams, handleSendCancelOrder, true, sendCancelOrderTimeout)
            setPassTrading('')
        })
    }

    const sendCancelOrderTimeout = () => {
        sendCancelOrderFlag.current = false
        // navigation.navigate(Screens.ALERT_MODAL, {
        //     title: t('common_notify'),
        //     content: t('request_hanlde_not_success_try_again'),
        //     typeColor: styles.WARN__COLOR
        // })
    }

    const handleSendCancelOrder = (reqInfoMap, message) => {
        sendCancelOrderFlag.current = false
        if (Number(message.Result) === 0) {
            if (message.Code === 'XXXXX5' || message.Code === '080063' || message.Code === '010012') {
                // navigation.navigate(Screens.ALERT_MODAL, {
                // icon: <IconSvg.ErrorIcon color={styles.WARN__COLOR} />,
                // title: t('common_notify'),
                // content: t('request_hanlde_not_success_try_again'),
                // typeColor: styles.WARN__COLOR,
                // })
                ModalController.showModal({
                    icon: <IconSvg.ErrorIcon color={styles.WARN__COLOR} />,
                    title: t('common_notify'),
                    content: t('request_hanlde_not_success_try_again'),
                    typeColor: styles.WARN__COLOR,
                })
            } else if (glb_sv.otpCases.includes(message.Code)) {
                glb_sv.objShareGlb.sessionInfo.Otp = ''

                let data
                try {
                    data = JSON.parse(message.Data)[0]
                } catch (error) {
                    return
                }

                const otp_Type = Number(data.c1)
                const expTimeOtp = Number(data.c2)
                let reqOtpMessage = 'OTP'
                if (Number(data.c1) === 2) {
                    //-- dạng thẻ ma trận
                    reqOtpMessage = 'OTP ' + data.c3
                }
                navigation.navigate(Screens.OTP_MODAL, {
                    time: expTimeOtp,
                    type: reqOtpMessage,
                    hasOTP: false,
                    otp_Type,
                    msg: message.Message,
                    functCallback: sendCancelAdvOrder,
                })
            } else {
                // navigation.navigate(Screens.ALERT_MODAL, {
                // icon: <IconSvg.ErrorIcon color={styles.WARN__COLOR} />,
                // title: t('common_notify'),
                // content: message.Message,
                // typeColor: styles.WARN__COLOR,
                // })
                ModalController.showModal({
                    icon: <IconSvg.ErrorIcon color={styles.WARN__COLOR} />,
                    title: t('common_notify'),
                    content: message.Message,
                    typeColor: styles.WARN__COLOR,
                })
            }
        } else {
            // navigation.navigate(Screens.ALERT_MODAL, {
            // icon: <IconSvg.ErrorIcon color={styles.SUCCESS__COLOR} />,
            // title: t('common_notify'),
            // content: message.Message,
            // typeColor: styles.SUCCESS__COLOR,
            // })
            ModalController.showModal({
                icon: <IconSvg.ErrorIcon color={styles.SUCCESS__COLOR} />,
                title: t('common_notify'),
                content: message.Message,
                typeColor: styles.SUCCESS__COLOR,
            })
            if (timeoutGetListOrder.current) clearTimeout(timeoutGetListOrder.current)
            timeoutGetListOrder.current = setTimeout(() => {
                getAdvOrderList()
            }, 1000)
        }
    }

    return (
        <View style={{ minHeight: 200 }}>
            <View style={{ flexDirection: 'column', justifyContent: 'space-between' }}>
                <Row
                    style={{
                        paddingTop: dimensions.vertical(4),
                        borderColor: styles.DIVIDER__COLOR,
                        borderTopWidth: 4,
                        marginBottom: 4,
                    }}
                />

                <Text
                    style={{
                        color: styles.PRIMARY__CONTENT__COLOR,
                        fontSize: fontSizes.medium,
                        fontWeight: fontWeights.bold,
                    }}
                >
                    {isGTCOrder ? t('gtc_order_list') : t('title_history_order')}
                </Text>
            </View>

            <View style={{ height: 30, marginTop: dimensions.halfIndent, flexDirection: 'row' }}>
                <Body style={{ justifyContent: 'flex-start', flexDirection: 'row' }}>
                    <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.normal }} onPress={() => setisDatePickerFrom(true)}>
                        {t('common_from_date')}
                        {'  '}
                    </Text>
                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal }} onPress={() => setisDatePickerFrom(true)}>
                        {moment(options.from_dt).format('DD/MM/YYYY')}
                    </Text>
                </Body>
                <Body style={{ justifyContent: 'flex-end', flexDirection: 'row' }}>
                    <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.normal }} onPress={() => setisDatePickerTo(true)}>
                        {t('common_to_date')}
                        {'  '}
                    </Text>
                    <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal }} onPress={() => setisDatePickerTo(true)}>
                        {moment(options.to_dt).format('DD/MM/YYYY')}
                    </Text>
                </Body>
            </View>
            <View style={{ height: 30, flexDirection: 'row' }}>
                <Body style={{ flexDirection: 'row', justifyContent: 'flex-start', flex: 1.5 }}>
                    <AntDesign color={styles.SECOND__CONTENT__COLOR} name="search1" size={fontSizes.normal} style={{ marginRight: 5, alignSelf: 'center' }} />
                    <TextInput
                        autoCapitalize="characters"
                        maxLength={10}
                        placeholder={t('input_symbol')}
                        placeholderTextColor={styles.SECOND__CONTENT__COLOR}
                        style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal, padding: 0, flex: 1 }}
                        value={options.stock}
                        onChangeText={(text) => getListOrderByStock(text)}
                    />
                </Body>
                <Body style={{ flexDirection: 'row', justifyContent: 'flex-end' }}>
                    <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.normal }} onPress={() => setVisibleStatus(true)}>
                        {options.orderStatus === '1'
                            ? t('wait_to_process')
                            : options.orderStatus === '2'
                            ? t('processed')
                            : options.orderStatus === '3'
                            ? t('common_Cancel')
                            : options.orderStatus === '4'
                            ? t('wait_tranfer')
                            : options.orderStatus === '9'
                            ? t('reject')
                            : t('common_all')}
                    </Text>
                    <AntDesign color={styles.SECOND__CONTENT__COLOR} name="caretdown" size={fontSizes.normal} onPress={() => setVisibleStatus(true)} />
                </Body>
            </View>

            <View
                style={{
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    borderBottomWidth: 0,
                    paddingVertical: dimensions.halfIndent / 2,
                }}
            >
                <Text style={{ color: styles.HEADER__CONTENT__COLOR, fontSize: fontSizes.verySmall, fontWeight: fontWeights.medium, flex: 0.7 }}>
                    {t('short_symbol')}
                </Text>

                <View style={{ flex: 1 }}>
                    <Text style={{ color: styles.HEADER__CONTENT__COLOR, fontSize: fontSizes.verySmall, fontWeight: fontWeights.medium, textAlign: 'right' }}>
                        {t('price')}
                    </Text>
                    <Text style={{ color: styles.HEADER__CONTENT__COLOR, fontSize: fontSizes.verySmall, fontWeight: fontWeights.medium, textAlign: 'right' }}>
                        {t('qty')}
                    </Text>
                </View>

                <View style={{ flex: 1 }}>
                    <Text style={{ color: styles.HEADER__CONTENT__COLOR, fontSize: fontSizes.verySmall, fontWeight: fontWeights.medium, textAlign: 'right' }}>
                        {t('effect_date_short')}
                    </Text>
                    <Text style={{ color: styles.HEADER__CONTENT__COLOR, fontSize: fontSizes.verySmall, fontWeight: fontWeights.medium, textAlign: 'right' }}>
                        {t('expire_date_short')}
                    </Text>
                </View>

                <Text
                    style={{
                        color: styles.HEADER__CONTENT__COLOR,
                        fontSize: fontSizes.verySmall,
                        fontWeight: fontWeights.medium,
                        flex: 1,
                        textAlign: 'right',
                    }}
                >
                    {t('order_status')}
                </Text>
            </View>

            <SwipeListView
                disableRightSwipe
                extraData={list}
                keyExtractor={(item, index) => index.toString()}
                renderHiddenItem={renderHiddenItem}
                renderItem={renderItem}
                renderSectionHeader={({ section: { title } }) => <Text style={textSectionHeaderStyle}>{moment(title, 'YYYYMMDD').format('DD/MM/YYYY')}</Text>}
                rightOpenValue={-70}
                scrollEnabled={false}
                sections={list}
                useSectionList={true}
            />

            {visibleStatus ? (
                <Modal
                    isVisible={visibleStatus}
                    style={UI.modal}
                    useNativeDriver={true}
                    onBackButtonPress={() => setVisibleStatus(false)}
                    onBackdropPress={() => setVisibleStatus(false)}
                >
                    <View
                        style={{
                            backgroundColor: styles.PRIMARY__BG__COLOR,
                            padding: dimensions.moderate(24),
                            justifyContent: 'flex-start',
                            borderTopLeftRadius: 12,
                            borderTopRightRadius: 12,
                        }}
                    >
                        <Text
                            style={{
                                marginBottom: dimensions.vertical(24),
                                fontSize: fontSizes.xmedium,
                                color: styles.PRIMARY__CONTENT__COLOR,
                                fontWeight: fontWeights.semiBold,
                            }}
                        >
                            {t('order_status')}
                        </Text>

                        {ListStatus.map((item) => (
                            <TouchableOpacity
                                key={item.value}
                                style={UI.row}
                                onPress={() => {
                                    optionsRef.current.orderStatus = item.value
                                    setOptions({ ...optionsRef.current })
                                    setVisibleStatus(false)
                                    filterData()
                                }}
                            >
                                <IconSvg.CheckboxIcon
                                    active={options.orderStatus === item.value}
                                    colorActive={styles.PRIMARY}
                                    colorunActive={styles.PRIMARY__CONTENT__COLOR}
                                />
                                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.medium, marginLeft: dimensions.moderate(12) }}>
                                    {t(item.label)}
                                </Text>
                            </TouchableOpacity>
                        ))}
                    </View>
                </Modal>
            ) : null}

            {isDatePickerFrom ? (
                <DateTimePickerModal
                    cancelTextIOS={t('common_Cancel')}
                    confirmTextIOS={t('common_Ok')}
                    date={options.from_dt}
                    headerTextIOS=""
                    isDarkModeEnabled={theme.includes('DARK')}
                    isVisible={isDatePickerFrom}
                    locale={language === 'VI' ? 'vi_VN' : 'en_US'}
                    mode="date"
                    onCancel={hideDatePicker}
                    onConfirm={(value) => {
                        setisDatePickerFrom(false)
                        optionsRef.current.from_dt = value
                        setOptions({ ...optionsRef.current })
                        getAdvOrderList()
                    }}
                />
            ) : null}

            {isDatePickerTo ? (
                <DateTimePickerModal
                    cancelTextIOS={t('common_Cancel')}
                    confirmTextIOS={t('common_Ok')}
                    date={options.to_dt}
                    headerTextIOS=""
                    isDarkModeEnabled={theme.includes('DARK')}
                    isVisible={isDatePickerTo}
                    locale={language === 'VI' ? 'vi_VN' : 'en_US'}
                    mode="date"
                    onCancel={hideDatePicker}
                    onConfirm={(value) => {
                        setisDatePickerTo(false)
                        optionsRef.current.to_dt = value
                        setOptions({ ...optionsRef.current })
                        getAdvOrderList()
                    }}
                />
            ) : null}

            {modalCancelOrder ? (
                <Modal
                    isVisible={modalCancelOrder}
                    useNativeDriver={true}
                    onBackButtonPress={() => {
                        setModalCancelOrder(false)
                        setPassTrading('')
                    }}
                    onBackdropPress={() => {
                        setModalCancelOrder(false)
                        setPassTrading('')
                    }}
                >
                    <View
                        style={{
                            backgroundColor: styles.HEADER__BG__COLOR,
                            paddingHorizontal: 20,
                            paddingTop: 32,
                            paddingBottom: 8,
                            justifyContent: 'flex-start',
                            borderRadius: 4,
                            borderColor: 'rgba(0, 0, 0, 0.1)',
                        }}
                    >
                        <View style={{ alignItems: 'center' }}>
                            <IconSvg.ErrorIcon color={styles.DOWN__COLOR} />
                        </View>
                        <Text
                            style={{
                                marginVertical: 22,
                                fontSize: fontSizes.xmedium,
                                textAlign: 'center',
                                fontWeight: fontWeights.semiBold,
                                color: styles.DOWN__COLOR,
                            }}
                        >
                            {t('info_cal_ord_cfm')}
                        </Text>

                        <AccountModal actn_curr={data.c0} sub_curr={data.c1} />

                        <View style={{ flexDirection: 'row', paddingVertical: dimensions.moderate(8) }}>
                            <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('short_symbol')}</Text>
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal, flex: 1 }}>{data.c4}</Text>
                        </View>

                        <View style={{ flexDirection: 'row', paddingVertical: dimensions.moderate(8) }}>
                            <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('effect_date')}</Text>
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal, flex: 1 }}>
                                {data ? moment(data.c9, 'DDMMYYYY').format('DD/MM/YYYY') : ''}
                            </Text>
                        </View>

                        <View style={{ flexDirection: 'row', paddingVertical: dimensions.moderate(8) }}>
                            <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('expire_date')}</Text>
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal, flex: 1 }}>
                                {data ? moment(data.c10, 'DDMMYYYY').format('DD/MM/YYYY') : ''}
                            </Text>
                        </View>

                        <View style={{ flexDirection: 'row', paddingVertical: dimensions.moderate(8) }}>
                            <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('session')}</Text>
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal, flex: 1 }}>{data.c21}</Text>
                        </View>

                        <View style={{ flexDirection: 'row', paddingVertical: dimensions.moderate(8) }}>
                            <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('order_tp')}</Text>
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal, flex: 1 }}>{t(translateOrderTp(data.c5))}</Text>
                        </View>

                        <View style={{ flexDirection: 'row', paddingVertical: dimensions.moderate(8) }}>
                            <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('qty')}</Text>
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal, flex: 1 }}>{FormatNumber(data.c6)}</Text>
                        </View>

                        {data.c5 === '01' ? (
                            <View style={{ flexDirection: 'row', paddingVertical: dimensions.moderate(8) }}>
                                <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('price')}</Text>
                                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.normal, flex: 1 }}>{FormatNumber(data.c7)}</Text>
                            </View>
                        ) : null}

                        {!glb_sv.isInvestorUser() ? (
                            <View style={{ flexDirection: 'row', paddingVertical: dimensions.moderate(8) }}>
                                <Text style={{ color: styles.SECOND__CONTENT__COLOR, fontSize: fontSizes.small, flex: 1 }}>{t('password_trading')}</Text>

                                <View style={{ borderBottomColor: styles.PRIMARY__BORDER__COLOR, borderBottomWidth: 1, flex: 1 }}>
                                    <TextInput
                                        maxLength={6}
                                        secureTextEntry
                                        style={{
                                            fontSize: fontSizes.medium,
                                            color: styles.PRIMARY__CONTENT__COLOR,
                                        }}
                                        value={passTrading}
                                        onChangeText={(value) => {
                                            setPassTrading(value)
                                        }}
                                    />
                                </View>
                            </View>
                        ) : null}

                        <Button
                            block
                            style={{
                                backgroundColor: styles.DOWN__COLOR,
                                justifyContent: 'center',
                                alignSelf: 'center',
                                marginTop: dimensions.vertical(25),
                                borderRadius: 8,
                                width: '100%',
                            }}
                            transparent
                            onPress={sendCancelAdvOrder}
                        >
                            <Text style={{ color: '#FFF', fontSize: fontSizes.small }}>{t('common_Ok')}</Text>
                        </Button>

                        <Button
                            block
                            style={{ justifyContent: 'center', alignSelf: 'center', width: '100%' }}
                            transparent
                            onPress={() => {
                                setModalCancelOrder(false)
                                setPassTrading('')
                            }}
                        >
                            <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fontSizes.small, opacity: 0.34 }}>{t('common_Cancel')}</Text>
                        </Button>
                    </View>
                </Modal>
            ) : null}
        </View>
    )
}

export default memo(AdvanceOrderList)

function areEqual(prev, next) {
    return true
}

const RowItem = memo(({ c4, c3, c7, c6, c19, c8, styles, t, item, changeOrderDetail }) => {
    const colorOrderStatus = (value) => {
        if (value === '1') return styles.send_to_exchange_color
        else if (value === '2') return styles.match_a_pieces_color
        else if (value === '3') return styles.reject_color
        else if (value === '4') return styles.wait_to_match_color
        else if (value === '9') return styles.reject_color
        return styles.PRIMARY__CONTENT__COLOR
    }

    return (
        <TouchableOpacity
            style={{
                flexDirection: 'row',
                paddingVertical: dimensions.halfIndent,
                borderBottomWidth: 1,
                borderBottomColor: styles.DIVIDER__COLOR,
                backgroundColor: styles.PRIMARY__BG__COLOR,
                alignItems: 'center',
            }}
            onPress={() => changeOrderDetail(item)}
        >
            <View style={{ flexDirection: 'row', flex: 0.8, alignItems: 'center' }}>
                <View
                    style={{
                        width: 18,
                        height: 18,
                        borderRadius: 9,
                        backgroundColor: c3 === '1' ? styles.UP__COLOR : styles.DOWN__COLOR,
                        alignItems: 'center',
                        justifyContent: 'center',
                    }}
                >
                    <Text style={{ color: '#FFF', fontSize: dimensions.moderate(8), fontWeight: fontWeights.medium, marginLeft: 1.8 }}>
                        {c3 === '1' ? t('buy_short') : t('sell_short')}
                    </Text>
                </View>
                <Text
                    style={{
                        color: styles.PRIMARY__CONTENT__COLOR,
                        fontSize: c4.length > 3 ? fontSizes.smallest : fontSizes.verySmall,
                        fontWeight: fontWeights.medium,
                    }}
                >
                    {'  '}
                    {c4}
                </Text>
            </View>
            <View style={{ flex: 1 }}>
                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, textAlign: 'right' }}>{FormatNumber(c7, 0, 0)}</Text>
                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, textAlign: 'right' }}>{FormatNumber(c6, 0, 1)}</Text>
            </View>
            <View style={{ flex: 1 }}>
                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, textAlign: 'right' }}>{moment(item.c9, 'DDMMYYYY').format('DD/MM/YYYY')}</Text>
                <Text style={{ color: styles.PRIMARY__CONTENT__COLOR, textAlign: 'right' }}>{moment(item.c10, 'DDMMYYYY').format('DD/MM/YYYY')}</Text>
            </View>

            <Text style={{ color: colorOrderStatus(c8), textAlign: 'right', flex: 1 }}>{c19}</Text>
        </TouchableOpacity>
    )
})

const HiddenItemWithActions = memo((props) => {
    const { data, showModalCancel } = props

    const { styles } = useContext(StoreContext)

    return (
        <View style={[UI.rowBack, { borderBottomColor: styles.DIVIDER__COLOR }]}>
            <TouchableOpacity
                disabled={data.item.c8 === '2' || data.item.c8 === '3'}
                style={[UI.backRightBtn, UI.backRightBtnRight]}
                onPress={() => showModalCancel(data.item)}
            >
                <AntDesign color={data.item.c8 === '2' || data.item.c8 === '3' ? styles.SECOND__CONTENT__COLOR : styles.DOWN__COLOR} name="delete" size={22} />
            </TouchableOpacity>
        </View>
    )
}, areEqual)

const UI = StyleSheet.create({
    backRightBtn: {
        alignItems: 'flex-end',
        flex: 1,
        justifyContent: 'center',
        paddingRight: 17,
        position: 'absolute',
        width: 75,
    },
    backRightBtnLeft: {
        right: 75,
    },
    backRightBtnRight: {
        borderBottomRightRadius: 5,
        borderTopRightRadius: 5,
        right: 0,
    },
    modal: {
        justifyContent: 'flex-end',
        margin: 0,
    },
    row: {
        alignItems: 'center',
        flexDirection: 'row',
        marginBottom: dimensions.vertical(12),
        padding: dimensions.moderate(7),
    },
    rowBack: {
        alignItems: 'center',
        borderBottomWidth: 1,
        borderRadius: 5,
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingLeft: 15,
    },
    rowFront: {
        backgroundColor: '#FFF',
        borderRadius: 5,
        elevation: 5,
        height: 60,
        margin: 5,
        marginBottom: 15,
        shadowColor: '#999',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.8,
        shadowRadius: 2,
    },
    trash: {
        height: 22,
        marginRight: 7,
        width: 22,
    },
})
