import React, { useContext, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { InteractionManager, Keyboard, RefreshControl, StyleSheet, View } from 'react-native'
import Modal from 'react-native-modal'
import StepIndicator from 'react-native-step-indicator'
import Svg, { Circle, ClipPath, Defs, G, Path } from 'react-native-svg'
import ToastGlobal from 'react-native-toast-message'
import { Container, Content, Tab, Tabs } from 'native-base'

import HeaderComponent from '../../../components/header'
import ModalLoading from '../../../components/modal-loading'
import { ButtonCustom, ModalContent, RowDataModal } from '../../../components/trading-component'
import { useAlertModal, useAlertModalCommonCode, useModalOtpWhenErr } from '../../../hoc'
import { StoreContext } from '../../../store'
import { StoreTrading } from '../../../store-trading'
import { dimensions as dm } from '../../../styles'
import { FormatNumber, glb_sv, reqFunct, wait } from '../../../utils'
import sendRequest from '../../../utils/sendRequest'
import StepOne from './step-one'
import StepTwo from './step-two'

// Khai báo ServiceInfo (nếu có)
const ServiceInfo = {
    KEY_ADD_STOCK_TRANSFER: {
        reqFunct: reqFunct.KEY_ADD_STOCK_TRANSFER, // Thêm giao dịch thông báo nộp tiền
        WorkerName: 'FOSxStock',
        ServiceName: 'FOSxStock_0302_6',
        Operation: 'I',
    },
}
const initErrCtrl = [
    {
        error: false,
        message: 'warning_cash_input',
    },
]
// Khai báo component
const StockOnAccount = ({ navigation }) => {
    const { styles } = useContext(StoreContext)
    const { userInfo } = useContext(StoreTrading)
    const { t } = useTranslation()
    // All orther state
    const [activeStep, setActiveStep] = useState(0)
    const [isOpenModal, setIsOpenModal] = useState(false)
    const [refreshing, setRefreshing] = React.useState(false)
    const [errCtrl, setErrCtrl] = useState(initErrCtrl)
    // Start define all bussiness state
    const [dataSubCurrTransfer, setDataSubCurrTransfer] = useState({})
    const [actReceive, setActReceive] = useState({})
    const [amountMove, setAmountMove] = useState(0)
    const [sub_curr2, setSub_curr2] = useState('')
    const [checkChangeData, setCheckChangeData] = useState(true)
    const [stkList, setStkList] = useState({})

    const [loadingConfirm, setLoadingConfirm] = useState(false)

    //   const [resetReceived, setResetReceived] = useState('');
    // End define form bussiness state
    // -------------------------------------------   Dùng useEffect get các dữ liệu cần thiết còn thiếu
    // -------------------------------------------   Viết các hàm để set lại bussiness form state. Nên viết đúng một chuẩn duy nhất để dễ control
    const onRefresh = React.useCallback(() => {
        setRefreshing(true)
        // glb_sv.checkLoadHistory = !glb_sv.checkLoadHistory;
        wait(300).then(() => setRefreshing(false))
    }, [])

    const switchStep = {
        goTo: (step) => setActiveStep(step),
        next: () => setActiveStep(activeStep + 1),
        prev: () => setActiveStep(activeStep - 1),
        submit: () => confirmTranferStock(),
        onFinish: () => _checkValueBfSend(),
        getCurrent: () => {
            return activeStep
        },
    }
    const hideModal = () => {
        setIsOpenModal(false)
    }
    const _resetInput = () => {
        setSub_curr2(null), setAmountMove(0), switchStep.goTo(0)
        Keyboard.dismiss()
    }
    const _onClickBackButton = () => {
        if (activeStep > 0) switchStep.prev()
        if (activeStep === 0) navigation.goBack()
    }
    const _validateValue = () => {
        setErrCtrl(initErrCtrl)
        const newErrCtrl = [...errCtrl]
        newErrCtrl[0].error = Number(amountMove) <= 0 || amountMove === undefined
        setErrCtrl(newErrCtrl)
    }
    const _checkValueBfSend = () => {
        if (sub_curr2) {
        } else {
            hideModal()
            ToastGlobal.show({
                text2: t('select_receive_bank_acnt'), //t('pass_confirm_not_correct'),
                type: 'warning',
            })
            return
        }
        Keyboard.dismiss
        _validateValue()
        // if (Number(amountMove)<= 0) { // Lớn hơn tài sản hiện có
        //     hideModal()
        //     ToastGlobal.show({
        //         text2: 'Khối lượng chứng khoán phải lớn hơn 0', //t('pass_confirm_not_correct'),
        //         type: 'warning',
        //     })
        //     return
        // }
        // if (Number(dataSubCurrTransfer.stockAmount) <= Number(amountMove) ) { // Lớn hơn tài sản hiện có
        //     hideModal()
        //     ToastGlobal.show({
        //         text2: 'Số lượng chứng khoáng vượt quá chứng khoáng đang có', //t('pass_confirm_not_correct'),
        //         type: 'warning',
        //     })
        //     return
        // }
        if (errCtrl.filter((item) => item.error === true).length === 0) {
            //----------------
            const isAuthenOTP = glb_sv.checkOtp(navigation, () => {
                setTimeout(() => {
                    setIsOpenModal((prev) => true)
                }, 100)
            })
            if (isAuthenOTP) {
                setIsOpenModal(true)
            }
            //---------------
        }
        return
    }

    // -------------------------------------------   Khai báo các hàm gửi (request) lên server
    const confirmTranferStock = () => {
        setIsOpenModal(false)
        InteractionManager.runAfterInteractions(() => {
            const inputParams = [
                userInfo.actn_curr,
                userInfo.sub_curr,
                dataSubCurrTransfer.codeCk,
                sub_curr2,
                String(amountMove), // Bank recieve account no
                '0',
                '0',
                '0', // Ngân hàng nhận
                glb_sv.objShareGlb.workDate, // Ngày hiện tại
                '', // Ghi chú
            ]
            sendRequest(ServiceInfo.KEY_ADD_STOCK_TRANSFER, inputParams, handleConfirmTranferStock)
            setLoadingConfirm(true)
        })
    }

    // -------------------------------------------   Khai báo các hàm gửi (request) và nhận (handle respone) dữ liệu từ server
    const handleConfirmTranferStock = (reqInfoMap, message) => {
        setLoadingConfirm(false)
        // -------------
        if (Number(message.Result) === 0) {
            const { hasAlertCommonCode } = useAlertModalCommonCode(message, {})
            const { hasAlertErrOtp } = useModalOtpWhenErr(message, { continueVerify: !hasAlertCommonCode, callback: () => setIsOpenModal((prev) => true) })
            useAlertModal(message, { continueVerify: !hasAlertErrOtp })
        } else {
            _resetInput()
            ToastGlobal.show({
                type: 'success',
                text2: message.Message,
            })
            setCheckChangeData(!checkChangeData)
        }
    }

    const renderStepIndicator = (params) => {
        if (params.position === 0) {
            return (
                <View>
                    <Svg fill="none" height={30} viewBox="0 0 30 30" width={30} xmlns="http://www.w3.org/2000/svg">
                        <Circle cx={15} cy={15} fill={params.position <= switchStep.getCurrent() ? '#60B44A' : '#D1D5DB'} r={15} />
                        <Path
                            d="M15 21.916l1.469-.339-1.13-1.13-.34 1.47zM14.71 20.949l.243-1.053.002-.008a.493.493 0 01.004-.013l.004-.012a.176.176 0 01.015-.032.27.27 0 01.008-.013l.005-.008a.21.21 0 01.015-.02l.01-.01.004-.005 3.275-3.275c-.914-1.88-2.605-3-4.545-3-1.423 0-2.737.609-3.7 1.714C9.078 16.328 8.531 17.88 8.5 19.6c.574.289 2.93 1.401 5.249 1.401.32 0 .641-.018.96-.051zM15.548 19.951l3.889-3.888 1.414 1.414-3.889 3.888-1.414-1.414zM13.75 13a2.5 2.5 0 100-5 2.5 2.5 0 000 5zM21.5 16.416a1 1 0 00-1.707-.707l1.414 1.414a.994.994 0 00.293-.707z"
                            fill="#fff"
                        />
                    </Svg>
                </View>
            )
        }
        if (params.position === 1) {
            return (
                <View>
                    <Svg fill="none" height={30} viewBox="0 0 30 30" width={30} xmlns="http://www.w3.org/2000/svg">
                        <Circle cx={15} cy={15} fill={params.position <= switchStep.getCurrent() ? '#60B44A' : '#D1D5DB'} opacity={1} r={15} />
                        <Path
                            d="M15 8.5A6.507 6.507 0 008.5 15c0 3.584 2.916 6.5 6.5 6.5s6.5-2.916 6.5-6.5-2.916-6.5-6.5-6.5zm-1.188 9.762l-2.518-2.8.743-.668 1.75 1.944 4.15-4.942.767.642-4.892 5.824z"
                            fill={'#fff'}
                            // opacity={0.1}
                        />
                    </Svg>
                </View>
            )
        }
    }
    const func = (step) => {
        switchStep.goTo(0)
    }
    // s
    return (
        <Container>
            <HeaderComponent
                colorTitle={styles.PRIMARY__CONTENT__COLOR}
                isShowLeft
                leftButtonLink={_onClickBackButton}
                navigation={navigation}
                title={t('title_stock_transfer_short')}
                titleAlgin="flex-start"
                transparent
            />
            <Content
                refreshControl={
                    <RefreshControl
                        refreshing={refreshing}
                        onRefresh={onRefresh} // title={t('pull_refresh')}
                        // titleColor={styles.PRIMARY__CONTENT__COLOR}
                        tintColor={styles.PRIMARY__CONTENT__COLOR}
                    />
                }
                style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}
            >
                <View style={UI.stepIndicator}>
                    <StepIndicator
                        currentPosition={activeStep}
                        customStyles={secondIndicatorStyles}
                        labels={[t('choose_account'), t('trading_confirm')]}
                        renderStepIndicator={renderStepIndicator}
                        stepCount={2}
                        onPress={func}
                    />
                </View>
                <Tabs locked page={activeStep} renderTabBar={() => <View />} style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
                    <Tab heading={<View />} key={1} style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
                        <StepOne
                            amountMove={amountMove}
                            checkChangeData={checkChangeData}
                            navigation={navigation}
                            refreshing={refreshing}
                            setAmountMove={setAmountMove}
                            setCheckChangeData={setCheckChangeData}
                            setDataSubCurrTransfer={setDataSubCurrTransfer} // công
                            setRefreshing={setRefreshing}
                            setStkList={setStkList}
                            setSub_curr2={setSub_curr2}
                            stkList={stkList}
                            sub_curr2={sub_curr2}
                            switchStep={switchStep}
                            onRefresh={onRefresh}
                        />
                    </Tab>
                    <Tab heading={<View />} key={2} style={{ backgroundColor: styles.PRIMARY__BG__COLOR }}>
                        <StepTwo
                            actReceive={actReceive}
                            amountMove={amountMove}
                            dataSubCurrTransfer={dataSubCurrTransfer} // công
                            errCtrl={errCtrl}
                            navigation={navigation}
                            refreshing={refreshing}
                            setActReceive={setActReceive}
                            setAmountMove={setAmountMove}
                            setErrCtrl={setErrCtrl}
                            setRefreshing={setRefreshing}
                            setStkList={setStkList}
                            setSub_curr2={setSub_curr2}
                            stkList={stkList}
                            sub_curr2={sub_curr2}
                            switchStep={switchStep}
                        />
                    </Tab>
                </Tabs>
            </Content>
            {/* **************************************** Modal submit ******************************************/}
            {isOpenModal && (
                <Modal isVisible={isOpenModal} useNativeDriver={true} onBackButtonPress={hideModal} onBackdropPress={hideModal}>
                    <ModalContent
                        iconComponent={
                            <Svg fill="none" height={32} viewBox="0 0 33 32" width={33} xmlns="http://www.w3.org/2000/svg">
                                <G clipPath="url(#prefix__clip0)" fill="#2ECC71">
                                    <Path d="M5.754 23.077V0H4.217A4.111 4.111 0 00.11 4.106v20.275a5.343 5.343 0 013.501-1.304h2.143zM24.93 15.934c.201 0 .402.008.6.021V0H7.625v23.077h8.547c.834-4.07 4.444-7.143 8.758-7.143zM13.305 5.511h6.264v1.871h-6.264V5.511zM11.19 9.574h10.496v1.871H11.189V9.574zM17.213 29.381H4.853V27.51h11.534a8.906 8.906 0 01-.396-2.62H3.61a3.56 3.56 0 00-3.555 3.556A3.56 3.56 0 003.611 32H19.54a9.007 9.007 0 01-2.327-2.62z" />
                                    <Path d="M24.93 17.746a7.135 7.135 0 00-7.127 7.127c0 3.93 3.197 7.126 7.127 7.126 3.93 0 7.126-3.197 7.126-7.126a7.135 7.135 0 00-7.126-7.127zm-.001 2.86c.526 0 .915.43.937.938.023.506-.447.937-.937.937-.526 0-.915-.43-.938-.937-.022-.507.448-.938.938-.938zm.94 7.92h-1.875v-4.8h1.875v4.8z" />
                                </G>
                                <Defs>
                                    <ClipPath id="prefix__clip0">
                                        <Path d="M0 0h32v32H0z" fill="#fff" transform="translate(.056)" />
                                    </ClipPath>
                                </Defs>
                            </Svg>
                        }
                        title={t('trading_confirm')}
                        type="confirm"
                    >
                        <RowDataModal
                            dataSub={[dataSubCurrTransfer.dataActn_curr, dataSubCurrTransfer.dataSub_curr]}
                            textLeft={t('trans_sub_account')}
                            textRight={dataSubCurrTransfer.dataActn_curr}
                        />
                        <RowDataModal
                            textLeft={t('receive_sub_account')}
                            textRight={dataSubCurrTransfer.dataActn_curr}
                            dataSub={[dataSubCurrTransfer.dataActn_curr, sub_curr2]}
                            // textRight={bankTransfer?.label}
                        />
                        <RowDataModal textLeft={t('symbol_short')} textRight={dataSubCurrTransfer.codeCk} />
                        <RowDataModal last textLeft={t('qty')} textRight={FormatNumber(amountMove)} />
                        <ButtonCustom text={t('common_button_confirm')} type="confirm" onPress={confirmTranferStock} />
                        <ButtonCustom last text={t('common_Cancel')} type="back" onPress={hideModal} />
                    </ModalContent>
                </Modal>
            )}
            {loadingConfirm && <ModalLoading content={t('common_processing')} visible={loadingConfirm} />}
        </Container>
    )
}

export default StockOnAccount

const UI = StyleSheet.create({
    Button: {
        alignItems: 'center',
        borderRadius: 8,
        height: dm.moderate(28),
        justifyContent: 'center',
        width: dm.moderate(28),
    },
    Row_Modal: {
        height: dm.vertical(24),
        marginVertical: dm.vertical(16),
    },
    container: {
        backgroundColor: '#ffffff',
        flex: 1,
    },
    page: {
        flex: 1,
        flexDirection: 'column',
    },
    stepIndicator: {
        marginBottom: dm.vertical(8),
        marginTop: dm.vertical(24),
        // marginVertical: 50,
    },
})

const secondIndicatorStyles = {
    stepIndicatorSize: 32,
    currentStepIndicatorSize: 32,
    separatorStrokeWidth: 3,
    currentStepStrokeWidth: 4,
    stepStrokeCurrentColor: '#60B44A',
    stepStrokeWidth: 2,
    separatorStrokeFinishedWidth: 4,
    stepStrokeFinishedColor: '#60B44A',
    stepStrokeUnFinishedColor: '#aaaaaa',
    separatorFinishedColor: '#60B44A',
    separatorUnFinishedColor: '#aaaaaa',
    stepIndicatorFinishedColor: '#60B44A',
    stepIndicatorUnFinishedColor: '#ffffff',
    stepIndicatorCurrentColor: '#ffffff',
    stepIndicatorLabelFontSize: 13,
    currentStepIndicatorLabelFontSize: 13,
    stepIndicatorLabelCurrentColor: '#60B44A',
    stepIndicatorLabelFinishedColor: '#ffffff',
    stepIndicatorLabelUnFinishedColor: '#aaaaaa',
    labelColor: '#999999',
    labelSize: 13,
    currentStepLabelColor: '#60B44A',
}
