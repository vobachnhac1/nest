const { replaceEnvFile, replaceFolder, replaceImge } = require('./replaceEnvFile')

replaceEnvFile('.env.uat', '.env')

replaceEnvFile('fastlane/.env.uat', 'fastlane/.env')

replaceEnvFile('android/app/google-services-uat.json', 'android/app/google-services.json')

replaceEnvFile('ios/SSVMobile/GoogleService-Info-uat.plist', 'ios/SSVMobile/GoogleService-Info.plist')
replaceEnvFile('ios/SSVMobile/Info-uat.plist', 'ios/SSVMobile/Info.plist')

replaceFolder('ios/SSVMobile/Images.xcassets/AppIconUat.appiconset', 'ios/SSVMobile/Images.xcassets/AppIcon.appiconset')

replaceImge('android/app/src/main/res/drawable/ic_launcher_uat.png', 'android/app/src/main/res/drawable/ic_launcher.png')
console.log('replace dev uat success')
