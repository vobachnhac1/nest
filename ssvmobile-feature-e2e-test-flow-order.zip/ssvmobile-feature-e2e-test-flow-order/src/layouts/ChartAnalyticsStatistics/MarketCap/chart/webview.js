import React, { memo, useEffect, useRef, useState } from 'react'
import { ActivityIndicator, InteractionManager, View } from 'react-native'

import { useCustomInteraction } from '../../../../hoc'
import { StoreContext } from '../../../../store'
import { eventList, FormatNumber, glb_sv, sendRequest, subcribeFunctStream, wait } from '../../../../utils'
import WebviewRenderChart from './webview-chart'

const ServiceInfo = {
    getMarketCapData: {
        WorkerName: 'FOSqMkt03',
        ServiceName: 'FOSqMkt03_MarketCap',
        Operation: 'Q',
    },
}

const listStockMarketCap = {
    HSX: [],
    HNX: [],
    UPC: [],
}

const WebviewChart = ({ exchange, height }) => {
    useCustomInteraction()
    const { theme, styles } = React.useContext(StoreContext)
    // ------
    const [dataMarketCap, setDataMarketCap] = useState([])
    const chartRef = useRef(null)
    const dataRef = useRef([])
    const [loading, setLoading] = useState(false)
    const [dataChart, setDataChart] = useState([])
    const [updateSeq, setUpdateSeq] = useState(1)
    const isSub = useRef(true)
    // -------
    useEffect(() => {
        let timeout
        subcribeFunctStream(
            'UNSUB',
            ['MDDS|SI'],
            dataMarketCap.map((s) => s.c0),
        )
        timeout = setTimeout(() => {
            setLoading(false)
        }, 1000)
        // console.log('listStockMarketCap', listStockMarketCap)
        if (listStockMarketCap[exchange].length === 0) {
            setLoading(true)
            getMarketCapData()
        } else {
            setLoading(true)
            InteractionManager.runAfterInteractions(() => {
                setDataMarketCap(listStockMarketCap[exchange])
            })
        }

        const eventMarket = glb_sv.eventMarket.subscribe((msg) => {
            if (msg.type === eventList.RESET_DATA) {
                setDataChart(dataChart)
            }
            if (msg.type === eventList.FOCUS_MARKET) {
                if (msg.value === true && !isSub.current) {
                    isSub.current = true
                    subcribeFunctStream(
                        'SUB',
                        ['MDDS|SI'],
                        listStockMarketCap[exchange].map((s) => s.c0),
                    )
                }
                if (msg.value === false && isSub.current) {
                    isSub.current = false
                    subcribeFunctStream(
                        'UNSUB',
                        ['MDDS|SI'],
                        listStockMarketCap[exchange].map((s) => s.c0),
                    )
                }
            }
        })

        const commonEvent = glb_sv.commonEvent.subscribe((msg) => {
            if (msg.type === eventList.REQ_GET_MKT_INF_FIRST) {
                isSub.current = true
                subcribeFunctStream(
                    'SUB',
                    ['MDDS|SI'],
                    listStockMarketCap[exchange].map((s) => s.c0),
                )
            }
        })

        return () => {
            clearTimeout(timeout)
            eventMarket.unsubscribe()
            commonEvent.unsubscribe()
            subcribeFunctStream(
                'UNSUB',
                ['MDDS|SI'],
                listStockMarketCap[exchange].map((s) => s.c0),
            )
        }
    }, [exchange])

    useEffect(() => {
        subcribeFunctStream(
            'SUB',
            ['MDDS|SI'],
            dataMarketCap.map((s) => s.c0),
        )
        convertedAndUpdateData()
        // ------
        const interval = setInterval(() => {
            convertedAndUpdateData()
        }, 3000)
        return () => {
            clearInterval(interval)
        }
    }, [dataMarketCap])
    //------
    const convertedAndUpdateData = () => {
        //-----
        InteractionManager.runAfterInteractions(() => {
            const convertedData = dataMarketCap.map((item, index) => {
                // if (item.c0 === 'ORTHERS') return
                const { U29, U30, t332, t333, ref, t31, t31_color, t31_incr_per } = glb_sv.StockMarket[item.c0] || {}
                return {
                    name: `${item.c0} (${FormatNumber(t31_incr_per, 2)}%)`,
                    value: Number(item.c1),
                    color: getColor(t31, ref, U29 || t332, U30 || t333),
                    ratioChange: t31_incr_per,
                    tooltip: `<b>${item.c0} (${FormatNumber(t31_incr_per, 2)}%)</b>: ${FormatNumber(item.c1, 2, 0, 'short')}`,
                }
            })
            setDataChart(convertedData)
            wait(300).then(() => setUpdateSeq(setUpdateSeq + 1))
        })
    }

    // -----
    const getMarketCapData = () => {
        setLoading(true)
        const InputParams = ['TOP', '50', exchange]
        sendRequest(ServiceInfo.getMarketCapData, InputParams, handleGetMarketCapData)
    }
    const handleGetMarketCapData = (reqInfoMap, message) => {
        if (Number(message.Result) === 0) {
            return
        } else {
            let jsondata = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
            } catch (err) { }
            dataRef.current = dataRef.current.concat(jsondata)
            if (Number(message.Packet) <= 0) {
                InteractionManager.runAfterInteractions(() => {
                    setDataMarketCap(jsondata)
                    listStockMarketCap[exchange] = jsondata
                    dataRef.current = []
                })
            }
        }
    }
    // -----
    const getColor = (value, ref, ceil, floor) => {
        if (value === 0) return styles.REF__COLOR
        if (value === ceil) return styles.CEIL__COLOR
        if (value === floor) return styles.FLOOR__COLOR
        if (value > ref) return styles.UP__COLOR
        if (value < ref) return styles.DOWN__COLOR
        return styles.REF__COLOR
    }

    return (
        <>
            {loading ? (
                <View style={{ alignItems: 'center', justifyContent: 'center' }}>
                    <ActivityIndicator color={styles.PRIMARY} size={24} />
                </View>
            ) : null}
            <View style={{ flex: 1 }}>
                <WebviewRenderChart
                    dataChart={JSON.stringify(dataChart)}
                    exchang={exchange}
                    height={height}
                    loading={loading}
                    theme={theme}
                    updateSeq={updateSeq}
                />
            </View>
        </>
    )
}

export default memo(WebviewChart)
