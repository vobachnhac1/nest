import React, { memo, useContext, useEffect, useMemo, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Pressable, ScrollView, StyleSheet, View } from 'react-native'
import { remove } from 'lodash'
import { Button, Row } from 'native-base'

import IconArrowRight from '../../assets/images/common/ic_arrow_right.svg'
import { ModalSelector, Text } from '../../basic-components'
import { StoreContext } from '../../store'
import { StoreTrading } from '../../store-trading'
import { dimensions as dm, fontSizes as fs, fontWeights as fw } from '../../styles'
import { glb_sv, Screens } from '../../utils'

const Account = ({ navigation, noPadding, showSubAll, isAll, changeAll, changeSub }) => {
    const { t } = useTranslation()
    const { styles } = useContext(StoreContext)
    const { userInfo = {}, setUserInfo } = useContext(StoreTrading)

    const [visibleModalAct, setVisibleModalAct] = useState(false)

    useEffect(() => {
        changeAll && changeAll(true)
    }, [])

    const changeSubAct = (item) => {
        changeAll && changeAll(false)
        if (item === userInfo.sub_curr) return
        setUserInfo({ ...userInfo, sub_curr: item })
        glb_sv.userInfoAccount = { ...userInfo, sub_curr: item }
        glb_sv.userInfo.sub_curr = item
        changeSub && changeSub({ ...userInfo, sub_curr: item })
    }

    const changeActMain = (item) => {
        const js_acntInfo = glb_sv.objShareGlb.acntNoInfo
        const sub_list = []
        js_acntInfo.forEach((e) => {
            if (e.AcntNo === item.AcntNo) sub_list.push(e.SubNo)
        })
        setUserInfo({
            ...userInfo,
            actn_curr: item.AcntNo,
            sub_curr: sub_list[0],
            actn_name: item.actn_name,
            sub_list,
        })
        glb_sv.userInfo.actn_curr = item.AcntNo
        glb_sv.userInfo.sub_curr = sub_list[0]
        glb_sv.userInfoAccount = {
            ...userInfo,
            actn_curr: item.AcntNo,
            sub_curr: sub_list[0],
            actn_name: item.actn_name,
            sub_list,
        }
        changeSub &&
            changeSub({
                ...userInfo,
                actn_curr: item.AcntNo,
                sub_curr: sub_list[0],
                actn_name: item.actn_name,
                sub_list,
            })
    }

    const initValue = userInfo.actn_list.find((e) => e.AcntNo === userInfo.actn_curr)
        ? userInfo.actn_list.find((e) => e.AcntNo === userInfo.actn_curr).label
        : ''

    const StyleTextActnCurr = useMemo(() => StyleSheet.flatten([{ color: styles.PRIMARY__CONTENT__COLOR, fontSize: fs.small }]), [styles])

    const StyleTextActnName = useMemo(() => StyleSheet.flatten([{ color: styles.SECOND__CONTENT__COLOR, fontSize: fs.smallest }]), [styles])

    const StyleButtonAll = useMemo(
        () =>
            StyleSheet.flatten([
                {
                    backgroundColor: isAll ? styles.PRIMARY : styles.BUTTON__SECONDARY,
                    marginVertical: dm.vertical(4),
                    height: dm.moderate(32),
                    width: dm.moderate(32),
                    marginLeft: 6,
                    marginRight: 2,
                    justifyContent: 'center',
                    borderRadius: 8,
                },
            ]),
        [styles, isAll],
    )

    const StyleTextButtonAll = useMemo(
        () =>
            StyleSheet.flatten([
                {
                    color: isAll ? 'white' : styles.PRIMARY__CONTENT__COLOR,
                    fontSize: fs.small,
                    fontWeight: isAll ? fw.bold : fw.medium,
                    textAlign: 'center',
                },
            ]),
        [styles, isAll],
    )

    const StyleCommonRow = useMemo(
        () =>
            StyleSheet.flatten([
                {
                    paddingTop: noPadding ? 0 : dm.vertical(16),
                    paddingBottom: noPadding ? 0 : dm.vertical(4),
                    paddingHorizontal: noPadding ? 0 : dm.moderate(16),
                },
            ]),
        [noPadding],
    )

    const verifyUserAction = () => {
        if (glb_sv.isInvestorUser()) {
            if (userInfo.actn_list.length > 1) {
                setVisibleModalAct(true)
            }
        } else {
            navigation.navigate(Screens.ACCOUNT_SEARCH_SCREEN, { updateInfo: (data, list) => updateUserInfo(data, list) })
        }
    }

    const updateUserInfo = (data, list) => {
        // console.log(TAG, 'updateUserInfo data:', data)
        // console.log(TAG, 'updateUserInfo list:', list)

        // if (list.length < 1) {
        //     return
        // }

        if (glb_sv.recentSearchAccount.length > 0 && glb_sv.recentSearchAccount.some((item) => item?.actn_curr == data?.actn_curr)) {
            remove(glb_sv.recentSearchAccount, {
                actn_curr: data.actn_curr,
            })
            glb_sv.recentSearchAccount.unshift(data)
        } else {
            glb_sv.recentSearchAccount.unshift(data)
        }
        setUserInfo(data)
        glb_sv.userInfoAccount = data
        glb_sv.userInfo.actn_curr = data.acntMain
        glb_sv.userInfo.sub_curr = '00'

        // const acnt_js = list.map(item => ({
        //     AcntNm: item['c2'],
        //     AcntNo: item['c0'],
        //     ActType: "1",
        //     IsOwnAcnt: "Y",
        //     MarginYN: true,
        //     SubNo: item['c1']
        // }))

        // glb_sv.objShareGlb['acntNoInfo'] = acnt_js;

        // changeActMain({
        //     AcntNm: list[0]['c2'],
        //     AcntNo: list[0]['c0'],
        //     ActType: "1",
        //     IsOwnAcnt: "Y",
        //     MarginYN: true,
        //     SubNo: list[0]['c1']
        // });

        // glb_sv.refreshAccount = true;
    }

    return (
        <Row style={StyleCommonRow}>
            {userInfo.actn_name ? (
                <View style={UI.view1}>
                    <Pressable onPress={verifyUserAction}>
                        <View style={UI.name_act}>
                            <Text numberOfLines={1} style={StyleTextActnCurr}>
                                {userInfo.actn_curr}
                            </Text>
                            <Text numberOfLines={1} style={StyleTextActnName}>
                                {userInfo.actn_name}
                            </Text>
                        </View>
                    </Pressable>

                    <View style={UI.view_button}>
                        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                            {showSubAll ? (
                                <Button style={StyleButtonAll} onPress={changeAll}>
                                    <Text style={StyleTextButtonAll}>ALL</Text>
                                </Button>
                            ) : null}
                            {userInfo.sub_list.map((item) => (
                                <Button
                                    key={item}
                                    style={[
                                        UI.button_other,
                                        {
                                            backgroundColor: isAll
                                                ? styles.BUTTON__SECONDARY
                                                : item === userInfo.sub_curr
                                                ? styles.PRIMARY
                                                : styles.BUTTON__SECONDARY,
                                        },
                                    ]}
                                    onPress={() => changeSubAct(item)}
                                >
                                    <Text
                                        style={[
                                            UI.text_button_other,
                                            {
                                                color: isAll
                                                    ? styles.PRIMARY__CONTENT__COLOR
                                                    : item === userInfo.sub_curr
                                                    ? 'white'
                                                    : styles.PRIMARY__CONTENT__COLOR,
                                                fontWeight: isAll ? fw.medium : item === userInfo.sub_curr ? fw.bold : fw.medium,
                                            },
                                        ]}
                                    >
                                        {item}
                                    </Text>
                                </Button>
                            ))}
                        </ScrollView>
                    </View>
                </View>
            ) : (
                <Pressable style={{ flex: 1, alignItems: 'center' }} onPress={verifyUserAction}>
                    <View style={{ flex: 1, flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
                        <Text style={{ color: styles.PRIMARY__CONTENT__COLOR }}>{t('account_in_advance')}</Text>
                    </View>
                </Pressable>
            )}

            {(userInfo.actn_list.length > 1 || !glb_sv.isInvestorUser()) && (
                <View style={UI.last_icon}>
                    <Pressable hitSlop={6} onPress={verifyUserAction}>
                        <View style={UI.right_arrow_view}>
                            <IconArrowRight style={{ color: styles.PRIMARY__CONTENT__COLOR }} />
                        </View>
                    </Pressable>
                </View>
            )}

            {visibleModalAct ? (
                <ModalSelector
                    accessible={true}
                    cancelText={t('common_Cancel')}
                    data={userInfo.actn_list}
                    initValue={initValue}
                    selectedItemTextStyle={{ color: styles.PRIMARY }}
                    supportedOrientations={['portrait']}
                    visible={visibleModalAct}
                    onChange={(option) => changeActMain(option)}
                    onModalClose={() => setVisibleModalAct(false)}
                />
            ) : null}
        </Row>
    )
}
export default memo(Account)

const UI = StyleSheet.create({
    Common__Row: {
        paddingBottom: dm.vertical(4),
        paddingTop: dm.vertical(16),
    },
    button_other: {
        borderRadius: 8,
        height: dm.moderate(32),
        justifyContent: 'center',
        marginLeft: 6,
        marginRight: 2,
        marginVertical: dm.vertical(4),
        width: dm.moderate(32),
    },
    icon_name_act: {
        alignSelf: 'center',
        paddingHorizontal: 8,
        paddingTop: 8,
        paddingVertical: 5,
    },
    last_icon: {
        alignItems: 'flex-end',
        justifyContent: 'center',
        width: 35,
    },
    name_act: {
        paddingTop: 8,
        paddingVertical: 5,
        // flex: 3
    },
    right_arrow_view: {
        alignItems: 'center',
        aspectRatio: 1,
        height: 35,
        justifyContent: 'center',
    },
    text_button_other: {
        fontSize: fs.small,
        textAlign: 'center',
    },
    view1: {
        flex: 1,
        flexDirection: 'row',
    },
    view_button: {
        alignItems: 'center',
        flexDirection: 'row',
        flex: 1,
        marginLeft: dm.moderate(12),
    },
})
