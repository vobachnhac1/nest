import React, { useState, useRef, useContext, useEffect } from 'react';
import useLoading from '../useLoading';
import { StoreContext } from '../../store';
import { InteractionManager } from 'react-native';
/**
 * Dùng để hiển thị modal theo thứ tự tránh bị Crash hoặc Block trên IOS
 * @param {string} modalKey
 * @returns [isModalOpen, setIsModalOpen]
 *
 */

export type TGLOBAL_MODAL_KEY = 'ModalConfirmOrderAfterLogin' | 'AdvertisingModal' | 'ModalNewReleaseNotes' | 'ModalAuthenOTP' | 'ModalNotifyNewVersion';
export const GLOBAL_MODAL_KEY: { [key in TGLOBAL_MODAL_KEY]: TGLOBAL_MODAL_KEY} = {
	ModalConfirmOrderAfterLogin: 'ModalConfirmOrderAfterLogin',
	AdvertisingModal: 'AdvertisingModal',
    ModalNewReleaseNotes: 'ModalNewReleaseNotes',
    ModalAuthenOTP: 'ModalAuthenOTP',
    ModalNotifyNewVersion: 'ModalNotifyNewVersion',
};
const ListCheckModal = Object.keys(GLOBAL_MODAL_KEY);

const useSafeModalState = (
	modalKey: TGLOBAL_MODAL_KEY
): [isModalOpen: boolean, setIsModalOpen: (isOpen: boolean) => void] => {
	const [isModalOpen, _setIsModalOpen] = useState(false);
	const { masterModalState, setMasterModalState } = useContext(StoreContext);

	useEffect(() => {
		// Tìm xem cái modal nào sẽ được hiển thị tiếp theo
		const nextModal = ListCheckModal.find(key => {
			return masterModalState[key];
		});
		
		// Nếu modal fiếp theo = modal hiện tại thi setIsOpen bằng true
		if (nextModal === modalKey) {
			// setTimeout(() => {
				console.log('nextModal === modalKey', { nextModal, modalKey });
				_setIsModalOpen(prev => true);
			// }, 100);
		}
        // console.log({ nextModal, isEqual: nextModal === modalKey });
	}, [masterModalState]);
	// ------
	const setIsModalOpen = (isOpen: boolean) => {
		console.log('setIsMasterModalOpen: ', modalKey, isOpen);
        setMasterModalState(prev => ({ ...prev, [modalKey]: isOpen }));
        if (!isOpen) {
            _setIsModalOpen(false)
        }
	};
    // console.log({ modalKey, masterModalState, isModalOpen });
	return [isModalOpen, setIsModalOpen];
};

export default useSafeModalState;
