import React, { useContext, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { InteractionManager } from 'react-native'
import ToastGlobal from 'react-native-toast-message'
import ModalController from '@mts-components/appModal/modalControlller'
import { EKYC_TRACKING_STEP, useSaveCurrentStep } from '@mts-layouts/eKYCFPT/hooks/useSaveCurrentStep'
import { removeAccents } from '@mts-utils/formatString/formatString'
import { sensitiveWordsRegex, specialCharactersRegex } from '@mts-utils/regex_checker'
import moment from 'moment'

import { StoreContext } from '../../../../store'
import { StoreTrading } from '../../../../store-trading'
import { IconSvg } from '../../../../styles'
import { glb_sv, reqFunct, Screens, sendRequest } from '../../../../utils'
import Analytics, { EkycAnalyticEvents } from '../../../../utils/TrackingData/Analytics'
import { configUIEkyc } from '../../config'
import ekycService from '../../ekycService'

const ServiceInfo: IServiceInfo = {
    EKYC_UPDATE: {
        reqFunct: reqFunct.EKYC_UPDATE,
        WorkerName: 'FOSxID01',
        ServiceName: 'FOSxID01_EKYCMgt',
        ClientSentTime: '0',
        Operation: 'U',
        TimeOut: 20,
    },
    API_UPLOAD: {
        reqFunct: reqFunct.API_UPLOAD,
        WorkerName: 'FOSxCommon02',
        ServiceName: 'FOSxCommon02_Token_Mgt',
        ClientSentTime: '0',
        Operation: 'Q',
    },
    CHECK_DUPLICATE_INFO: {
        reqFunct: reqFunct.CHECK_DUPLICATE_INFO,
        WorkerName: 'FOSqAccount',
        ServiceName: 'FOSqAccount_Common_3',
        ClientSentTime: '0',
        Operation: 'Q',
    },
}

export const useStepEkycInfo = ({ navigation, userData = {}, switchStep }) => {
    const { styles, theme, language } = useContext(StoreContext)
    const { setUserInfo } = useContext(StoreTrading)
    const { t } = useTranslation()

    //#region Thông tin CMT/CCCD
    const [phone, setPhone] = useState<string>(ekycService?.userData?.phone || '')
    const { saveData } = useSaveCurrentStep()
    // email đã được thu thập ở bước 1
    const defaultEmail = ekycService?.userData?.email || '' // Email phải lấy data ở bước 1:
    const [email, setEmail] = useState<string>(defaultEmail)
    const [id, setID] = useState<string>('')
    const [fullName, setFullName] = useState<string>('-')
    const [birthday, setBirthday] = useState<Date | null | undefined>(null)
    const [addr, setAddr] = useState<string>('-')
    const [addrContact, setAddrContact] = useState<string>('')
    const [gender, setGender] = useState<'O' | 'M' | 'F'>('O')
    const [idDate, setIDDate] = useState<null | Date | undefined>(null)
    const [idPlace, setIDPlace] = useState<string>('-')
    //#endregion

    //#region Cho phép chỉnh sửa các thông tin đọc từ CMT/CCCD
    const permanentAddressEditable = configUIEkyc.hasOwnProperty('is_permanent_address_editable') ? configUIEkyc.is_permanent_address_editable : false // Chỉnh sửa địa chỉ thường trú
    const issueDateEditable = configUIEkyc.hasOwnProperty('is_issue_date_editable') ? configUIEkyc.is_issue_date_editable : false
    const issuePlaceEditable = configUIEkyc.hasOwnProperty('is_issue_place_editable') ? configUIEkyc.is_issue_place_editable : false
    const birthdayEditable = configUIEkyc.hasOwnProperty('is_birthday_editable') ? configUIEkyc.is_birthday_editable : false // Ngày sinh có được edit không

    const checkDuplicateInfo = configUIEkyc.hasOwnProperty('is_check_duplicate_step_1') ? !configUIEkyc.is_check_duplicate_step_1 : false // Đã check ở bước 1 => không check bước 4
    //#endregion

    const [isAuthen, setAuthen] = useState(true)
    const [hintCommonEmail, setHintCommonEmail] = useState(false)

    const [modalBirthday, setModalBirthday] = useState(false)
    const [modalIssueDate, setModalIssueDate] = useState(false)

    const [addressDetails, setAddressDetails] = useState<{ province?: any; district?: any; ward?: any; detailsAdress?: string }>({})

    const [jobInfo, setJobInfo] = useState<{ occupation?: any; position?: any }>({})

    //#endregion

    //#region Thông tin hình ảnh 3 phần
    const [imageFront, setImageFront] = useState(!userData.imagesFront || userData.imagesFront.includes('null') ? '' : userData.imagesFront)
    const [imageBack, setImageBack] = useState(!userData.imagesBack || userData.imagesBack.includes('null') ? '' : userData.imagesBack)
    const [imageFace, setImageFace] = useState(!userData.imagesFace || userData.imagesFace.includes('null') ? '' : userData.imagesFace)
    //#endregion

    //#region Thông tin ref
    const scrollViewRef = useRef<any>(null)

    const phoneRef = useRef<any>(null)
    const emailRef = useRef<any>(null)
    const idRef = useRef<any>(null)
    const addrContactRef = useRef<any>(null)
    const nameRef = useRef<any>(null)
    const addrRef = useRef<any>(null)
    const idPlaceRef = useRef<any>(null)
    //#endregion

    useEffect(() => {
        if (typeof ekycService.frontData === 'object' && ekycService.frontData.hasOwnProperty('name')) {
            const {
                id, // Số ID
                name, // Tên
                dob, // Ngày sinh
                sex, // Giới tính
                address, // Thường trú
                doe, // Ngày hết hạn
                contactAddress, // Địa chỉ liên lạc
                cropped_idcard_base64, // Base64 hình ảnh mặt trước
            } = ekycService.frontData
            !!id && id.length > 0 && setID(id)
            !!name && name.length > 0 && setFullName(name)
            !!dob && dob.length > 0 && setBirthday(moment(dob, 'DD/MM/YYYY').toDate())
            !!sex && sex.length > 0 && setGender(sex === 'N/A' ? 'O' : sex === 'NAM' ? 'M' : 'F')
            !!address && address.length > 0 && setAddr(address)
            !!contactAddress && contactAddress.length > 0 && setAddrContact(contactAddress)
            !!cropped_idcard_base64 && cropped_idcard_base64.length > 0 && setImageFront('data:image/jpeg;base64,' + cropped_idcard_base64)
            if (checkDuplicateInfo) {
                checkUserInfoExist(name, dob)
            }
            // if (!!name && name.length > 0 && !!dob && !!dob.length > 0) {
            //     // Check user tồn tại
            // }
        }
        if (typeof ekycService.backData === 'object' && ekycService.backData.hasOwnProperty('issue_date')) {
            const {
                issue_date, // Ngày cấp
                issue_loc, // Nơi cấp
                cropped_idcard_base64, // Base64 hình ảnh mặt sau
            } = ekycService.backData
            !!issue_date && issue_date.length > 0 && setIDDate(moment(issue_date, 'DD/MM/YYYY').toDate())
            !!issue_loc && issue_loc.length > 0 && setIDPlace(issue_loc)
            !!cropped_idcard_base64 && cropped_idcard_base64.length > 0 && setImageBack('data:image/jpeg;base64,' + cropped_idcard_base64)
        }
        if (typeof ekycService.videoData === 'object' && ekycService.videoData?.liveness?.is_live) {
            const {
                image_face, // Base64 hình ảnh chính diện khuôn mặt
            } = ekycService.videoData
            !!image_face && image_face.length > 0 && setImageFace('data:image/jpeg;base64,' + image_face)
        }

        const ekycEvent = ekycService.ekycEvent.subscribe((msg) => {
            if (msg.type === 'SAVE_DATA' && msg.step !== 4) {
                saveCurrentData()
            }
        })

        return () => {
            // second
            ekycEvent.unsubscribe()
        }
    }, [])

    const checkUserInfoExist = (name, birday) => {
        if (!name || !birday) return
        if (!isAuthen) return // Nếu Ekyc failed thì không cần gọi service check
        // ------------
        const inval = ['CHK_NAME_BIRDT', name, birday && birday.length === 10 ? moment(birday, 'DD/MM/YYYY').format('YYYYMMDD') : birday]
        sendRequest(ServiceInfo.CHECK_DUPLICATE_INFO, inval, checkUserInfoExistResult)
    }

    const checkUserInfoExistResult = (reqInfoMap, message: IServiceRespone) => {
        if (Number(message.Result) === 0) {
        } else {
            let jsondata: IServiceResponeData[] = []
            try {
                jsondata = message.Data ? JSON.parse(message.Data) : []
                if (jsondata[0].c0 === 'Y') {
                    InteractionManager.runAfterInteractions(() => {
                        // navigation.navigate(Screens.ALERT_MODAL, {
                        // icon: <IconSvg.ErrorIcon color={styles.INFO__COLOR} />,
                        // title: t('common_notify').toLocaleUpperCase(),
                        // colorTitle: styles.EKYC__COLOR,
                        // content: message.Message,
                        // titleOK: t('continue').toLocaleUpperCase(),
                        // typeColor: styles.INFO__COLOR,
                        // linkCallback: () => navigation.pop(),
                        // showCancel: true,
                        // cancelCallBack: () => navigation.pop(),
                        // })
                        ModalController.showModal({
                            icon: <IconSvg.ErrorIcon color={styles.INFO__COLOR} />,
                            title: t('common_notify').toLocaleUpperCase(),
                            colorTitle: styles.EKYC__COLOR,
                            content: message.Message,
                            titleOK: t('continue').toLocaleUpperCase(),
                            typeColor: styles.INFO__COLOR,
                            linkCallback: () => navigation.pop(),
                            showCancel: true,
                            cancelCallBack: () => navigation.pop(),
                        })
                    })
                }
            } catch (err) {
                return
            }
        }
    }

    const hideDatePicker = () => {
        setModalBirthday(false)
        setModalIssueDate(false)
    }

    const validate = () => {
        if (!id || id === '-') return false
        if (!fullName || fullName === '-') return false
        if (!birthday) return false
        if (moment(birthday).format('YYYYMMDD') === 'Invalid date') return false
        if (!addr || addr === '-') return false
        if (!addrContact || addrContact === '-') return false
        if (!idDate) return false
        if (moment(idDate).format('YYYYMMDD') === 'Invalid date') return false
        if (!idPlace || idPlace === '-') return false
        // if (!checkNote) return false
        if (!isAuthen) return false
        // if (gender !== 'M' && gender !== 'F') return false
        return true
    }

    const handleContinueAndSaveData = () => {
        if (!phone || !phone.trim()) {
            ToastGlobal.show({
                text2: t('common_plz_input_your_mobile_number'),
                type: 'warning',
            })
            phoneRef.current.focus()
            return
        }

        if (phone.trim().length !== 10) {
            ToastGlobal.show({
                type: 'warning',
                text2: t('common_plz_mobile_number_length'),
            })
            phoneRef.current.focus()
            return
        }

        if (!email || !email.trim()) {
            ToastGlobal.show({
                text2: t('common_plz_input_your_email_address'),
                type: 'warning',
            })
            emailRef.current.focus()
            return
        }

        if (!id || !id.trim() || id === '-') {
            ToastGlobal.show({
                text2: t('common_plz_input_your_email_address'),
                type: 'warning',
            })
            idRef.current.focus()
            return
        }
        if (!fullName || !fullName.trim() || fullName === '-') {
            ToastGlobal.show({
                text2: t('common_plz_input_full_name'),
                type: 'warning',
            })
            nameRef.current.focus()
            return
        }
        if (!birthday || moment(birthday).format('YYYYMMDD') === 'Invalid date') {
            setModalBirthday(true)
            return
        }
        if (!idDate || moment(idDate).format('YYYYMMDD') === 'Invalid date') {
            setModalIssueDate(true)
            return
        }

        if (!addr || !addr.trim() || addr === '-') {
            ToastGlobal.show({
                text2: t('common_plz_input_your_home_address'),
                type: 'warning',
            })
            addrRef.current.focus()
            return
        }
        if (addr?.trim().length < 8) {
            ToastGlobal.show({
                text2: t('permanent_address_min_8_character'),
                type: 'warning',
            })
            addrRef.current?.focus()
            return
        }

        if (addr.match(sensitiveWordsRegex)) {
            ToastGlobal.show({
                text2: t('permanent_address_have_sensitive_words'),
                type: 'warning',
            })
            addrRef.current?.focus()
            return
        }

        if (!specialCharactersRegex.test(removeAccents(addr))) {
            ToastGlobal.show({
                text2: t('permanent_address_have_special_characters'),
                type: 'warning',
            })
            addrRef.current?.focus()
            return
        }
        if (!addrContact || !addrContact.trim() || addrContact === '-') {
            ToastGlobal.show({
                text2: t('common_plz_input_your_home_address_contact'),
                type: 'warning',
            })
            addrContactRef.current?.focus()
            return
        }

        if (addrContact?.trim().length < 8) {
            ToastGlobal.show({
                text2: t('contact_address_min_8_character'),
                type: 'warning',
            })
            addrContactRef.current?.focus()
            return
        }

        if (addrContact.match(sensitiveWordsRegex)) {
            ToastGlobal.show({
                text2: t('contact_address_have_sensitive_words'),
                type: 'warning',
            })
            addrContactRef.current?.focus()
            return
        }

        if (!specialCharactersRegex.test(removeAccents(addrContact))) {
            ToastGlobal.show({
                text2: t('contact_address_have_special_characters'),
                type: 'warning',
            })
            addrContactRef.current?.focus()
            return
        }

        if (!idPlace || !idPlace.trim() || idPlace === '-') {
            ToastGlobal.show({
                text2: t('common_plz_input_register_place_of_certificates'),
                type: 'warning',
            })
            idPlaceRef.current.focus()
            return
        }
        if (gender !== 'M' && gender !== 'F') {
            ToastGlobal.show({
                text2: t('common_plz_input_your_gender'),
                type: 'warning',
            })
            return
        }
        // --------- Check địa chỉ
        if (!addressDetails?.province?.value) {
            ToastGlobal.show({
                text2: t('ekyc_common_plz_input_province'),
                type: 'warning',
            })
            return
        }
        if (!addressDetails?.district?.value) {
            ToastGlobal.show({
                text2: t('ekyc_common_plz_input_district'),
                type: 'warning',
            })
            return
        }
        if (!addressDetails?.ward?.value) {
            ToastGlobal.show({
                text2: t('ekyc_common_plz_input_ward'),
                type: 'warning',
            })
            return
        }
        if (!addressDetails?.detailsAdress) {
            ToastGlobal.show({
                text2: t('ekyc_common_plz_input_address_details'),
                type: 'warning',
            })
            return
        }
        if (addressDetails?.detailsAdress.length < 8) {
            ToastGlobal.show({
                text2: t('contact_address_min_15_character'),
                type: 'warning',
            })
            addrContactRef.current?.focus()
            return
        }

        if (!jobInfo?.occupation?.value || !jobInfo?.position?.value) {
            ToastGlobal.show({
                text2: t('ekyc_job_info_required'),
                type: 'warning',
            })
            return
        }

        Analytics.logEvent(EkycAnalyticEvents.ekyc_step_two_touch_update_info)
        glb_sv.sendEKYCLogNewTracking({
            sEKYCLog: EkycAnalyticEvents.ekyc_step_two_touch_update_info,
            eKYCType: '3',
            reason: 'Xác nhận thông tin, update thêm thông tin',
            ekycStep: '2',
        })
        saveCurrentData()

        switchStep.next()
    }

    const saveCurrentData = () => {
        // Lưu data
        ekycService.userData = {
            ...ekycService.userData,
            phone: phone,
            email: email,
            id: id,
            name: fullName,
            birthday: birthday,
            gender: gender,
            idDate: idDate,
            idPlace: idPlace,
            address: addr,
            contactAddress: addrContact,
            // bankLinkType: bankLinkType,
            // bankAccLink: bankAccLink,
            // bankAccNum: bankAccNum,
        }

        saveData(ekycService, EKYC_TRACKING_STEP.PERSONAL_INFO_DONE)
    }

    const onChangeContactAddress = (addr, addressDetails) => {
        setAddrContact(addr)
        setAddressDetails({
            province: addressDetails.province,
            district: addressDetails.district,
            ward: addressDetails.ward,
            detailsAdress: addressDetails.detailsAdress,
        })
    }

    function onChangedJobInfo(occupation: any, position: any): void {
        setJobInfo({
            occupation: occupation,
            position: position,
        })

        ekycService.additionalData.jobID = occupation.value
        ekycService.additionalData.positionID = position.value
    }

    const onChangeFATCA = (fatca: '0' | '1' | '2') => {
        console.log('onChangeFATCA', fatca)
        // --- save FATCA: Yếu tố Hoa kỳ Y/N
        ekycService.additionalData.checkFATCADetail = fatca
        ekycService.additionalData.checkFATCA = fatca === '0' || fatca === '1'
    }

    return {
        setID,
        nameRef,
        hintCommonEmail,
        idRef,
        id,
        setHintCommonEmail,
        setEmail,
        email,
        scrollViewRef,
        styles,
        phoneRef,
        t,
        phone,
        setPhone,
        emailRef,
        addrContactRef,
        fullName,
        setFullName,
        setModalBirthday,
        birthdayEditable,
        idPlaceRef,
        birthday,
        setGender,
        issueDateEditable,
        setModalIssueDate,
        gender,
        setIDPlace,
        idDate,
        issuePlaceEditable,
        idPlace,
        addrRef,
        permanentAddressEditable,
        setAddr,
        addr,
        imageFront,
        imageBack,
        imageFace,
        onChangeContactAddress,
        onChangedJobInfo,
        isAuthen,
        handleContinueAndSaveData,
        validate,
        theme,
        modalBirthday,
        language,
        setBirthday,
        modalIssueDate,
        hideDatePicker,
        setIDDate,
        // removeEmpty,
    }
}
