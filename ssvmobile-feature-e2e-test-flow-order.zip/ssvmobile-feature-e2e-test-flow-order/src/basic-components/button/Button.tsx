import * as React from 'react'
import { TouchableOpacity } from 'react-native'

import { enhance } from '../handle'
import { stylesView } from './Button.presets'
import { ButtonProps } from './Button.props'

const ButtonComponent = (props: ButtonProps) => {
    const { preset = 'primary', tx, text, style: styleOverride = {}, textStyle: textStyleOverride = {}, children, ...rest } = props

    const viewStyle = React.useMemo(() => enhance([stylesView[preset], styleOverride]), [styleOverride])

    const content = React.useMemo(() => children, [children])

    return (
        <TouchableOpacity style={viewStyle} {...rest}>
            {content}
        </TouchableOpacity>
    )
}
export const Button = React.memo(ButtonComponent)
// export default Button
