/**
 * Eslint for React Native from Altisss Develop Team
 * Document for extends rules:
 * --- Eslint Plugin React Native: https://github.com/facebook/react-native/blob/main/packages/eslint-config-react-native-community/index.js
 *
 * TODO: Review and Update config every 3 months
 * Update Log:
 * 25/07/2021: First time config
 * 25/10/2021: ...
 *
 */

module.exports = {
    env: {
        es6: true,
    },
    extends: [
        //format
        '@react-native-community',
        'plugin:prettier/recommended',
    ],
    parserOptions: {
        sourceType: 'module',
    },
    plugins: [
        //format
        '@typescript-eslint',
        'prettier',
        'extra-rules',
        'simple-import-sort',
        'import',
        'detox',
    ],

    settings: {
        react: {
            version: 'detect',
        },
        'import/extensions': ['.js', '.jsx'],
    },
    overrides: [
        {
            files: ['*.js'],
            parser: 'babel-eslint',
            plugins: ['flowtype'],
            rules: {
                // Flow Plugin
                // The following rules are made available via `eslint-plugin-flowtype`

                'flowtype/define-flow-type': 1,
                'flowtype/use-flow-type': 1,
            },
        },
        {
            files: ['*.{spec,test}.{js,ts,tsx}', '**/__{mocks,tests}__/**/*.{js,ts,tsx}'],
            env: {
                jest: true,
                'jest/globals': true,
            },
            rules: {
                'react-native/no-inline-styles': 0,
                quotes: [1, 'single', { avoidEscape: true, allowTemplateLiterals: true }],
            },
        },
    ],
    ignorePatterns: ['**/build/'],
    rules: {
        // Variables
        '@typescript-eslint/no-unused-vars': [1, { vars: 'all', args: 'after-used', ignoreRestSiblings: true }],
        'no-shadow': [1],
        '@typescript-eslint/no-shadow': [1, { ignoreTypeValueShadow: true, ignoreFunctionTypeParameterNameValueShadow: true }],
        'no-undef': 2,
        'no-undefined': 2,
        'no-unused-vars': 0,
        'no-use-before-define': 0,
        'object-curly-spacing': 0,
        'react/jsx-indent-props': 0,
        // "react/jsx-closing-bracket-location": [2, "after-props"],
        'react/wrap-multilines': 0,
        // 'react/prop-types': [2, { ignore: ['navigation', 'route', 'data', 'state', 'item'] }],
        'react/jsx-sort-props': [
            2,
            {
                callbacksLast: true,
                ignoreCase: true,
            },
        ],
        'new-cap': 0,
        semi: 0,
        'no-else-return': 0,
        'react-native/no-unused-styles': 2,
        'react-native/sort-styles': [2, 'asc', { ignoreClassNames: false, ignoreStyleProperties: false }],
        'react-native/split-platform-components': 2,
        // "react-native/no-inline-styles": 2,
        'react-native/no-color-literals': 2,
        'react-native/no-raw-text': 2,
        // 'max-lines-per-function': ['error', {max: 120}],
        'max-lines-per-function': 0,
        'no-underscore-dangle': 2,
        'constructor-super': 2,
        'no-const-assign': 2,
        'no-dupe-class-members': 2,
        'no-dupe-args': 2,
        'no-dupe-keys': 2,
        'no-duplicate-case': 2,
        'no-duplicate-imports': 1,
        'no-this-before-super': 2,
        'no-var': 1,
        'no-confusing-arrow': 1,
        'no-useless-escape': 0,
        'no-console': ['error', { allow: ['warn', 'error'] }],
        'linebreak-style': 0,
        'arrow-parens': 0,
        'no-nested-ternary': 2,
        'prefer-const': 'error',
        // 'extra-rules/no-commented-out-code': 'error',
        'simple-import-sort/imports': [
            'error',
            {
                groups: [
                    ['^\\u0000'],
                    ['^react', '^@?\\w'],
                    ['^(@api|@assets|@components|@configs|@hooks|@screens|@services|@types2|@utils|@storybook-utils)(/.*|$)'],
                ],
            },
        ],
        'simple-import-sort/exports': 'error',
        'sort-imports': 'off',
        'import/first': 'error',
        'import/newline-after-import': 'error',
        'import/no-duplicates': 'error',
        // 'import/order': ['error', {'newlines-between': 'always'}],
    },
    globals: {
        __DEV__: true,
        __dirname: false,
        __fbBatchedBridgeConfig: false,
        AbortController: false,
        alert: false,
        cancelAnimationFrame: false,
        cancelIdleCallback: false,
        clearImmediate: true,
        clearInterval: false,
        clearTimeout: false,
        console: false,
        document: false,
        ErrorUtils: false,
        escape: false,
        Event: false,
        EventTarget: false,
        exports: false,
        fetch: false,
        FileReader: false,
        FormData: false,
        global: false,
        Headers: false,
        Intl: false,
        Map: true,
        module: false,
        navigator: false,
        process: false,
        Promise: true,
        requestAnimationFrame: true,
        requestIdleCallback: true,
        require: false,
        Set: true,
        setImmediate: true,
        setInterval: false,
        setTimeout: false,
        URL: false,
        URLSearchParams: false,
        WebSocket: true,
        window: false,
        XMLHttpRequest: false,
    },
}
