import React, { Component } from 'react'
import { Animated, StyleSheet, TextInput, View } from 'react-native'
import { func, number, object, string } from 'prop-types'

export default class FloatingTitleTextInputField extends Component {
    static propTypes = {
        attrName: string.isRequired,
        title: string.isRequired,
        value: string.isRequired,
        updateMasterState: func.isRequired,
        keyboardType: string,
        titleActiveSize: number, // to control size of title when field is active
        titleInActiveSize: number, // to control size of title when field is inactive
        titleActiveColor: string, // to control color of title when field is active
        titleInactiveColor: string, // to control color of title when field is active
        textInputStyles: object,
        otherTextInputProps: object,
    }

    static defaultProps = {
        keyboardType: 'default',
        titleActiveSize: 11.5,
        titleInActiveSize: 15,
        titleActiveColor: 'black',
        titleInactiveColor: 'dimgrey',
        textInputStyles: {},
        otherTextInputAttributes: {},
    }

    constructor(props) {
        super(props)
        const { value } = this.props
        this.position = new Animated.Value(value ? 1 : 0)
        this.state = {
            isFieldActive: false,
        }
    }

    _handleFocus = () => {
        if (!this.state.isFieldActive) {
            this.setState({ isFieldActive: true })
            Animated.timing(this.position, {
                toValue: 1,
                duration: 150,
            }).start()
        }
    }

    _handleBlur = () => {
        if (this.state.isFieldActive && !this.props.value) {
            this.setState({ isFieldActive: false })
            Animated.timing(this.position, {
                toValue: 0,
                duration: 150,
            }).start()
        }
    }

    _onChangeText = (updatedValue) => {
        const { attrName, updateMasterState } = this.props
        updateMasterState(attrName, updatedValue)
    }

    _returnAnimatedTitleStyles = () => {
        const { isFieldActive } = this.state
        const { titleActiveColor, titleInactiveColor, titleActiveSize, titleInActiveSize } = this.props

        return {
            top: this.position.interpolate({
                inputRange: [0, 1],
                outputRange: [14, 8],
            }),
            fontSize: isFieldActive ? titleActiveSize : titleInActiveSize,
            color: isFieldActive ? titleActiveColor : titleInactiveColor,
        }
    }

    render() {
        return (
            <View style={Styles.container}>
                <Animated.Text style={[Styles.titleStyles, this._returnAnimatedTitleStyles()]}>{this.props.title}</Animated.Text>
                <TextInput
                    keyboardType={this.props.keyboardType}
                    style={[Styles.textInput, this.props.textInputStyles]}
                    underlineColorAndroid="transparent"
                    value={this.props.value}
                    onBlur={this._handleBlur}
                    onChangeText={this._onChangeText}
                    onFocus={this._handleFocus}
                    {...this.props.otherTextInputProps}
                />
            </View>
        )
    }
}

const Styles = StyleSheet.create({
    container: {
        backgroundColor: 'gray',
        borderRadius: 6,
        borderStyle: 'solid',
        borderWidth: 0.5,
        paddingVertical: 8,
        width: '100%',
    },
    textInput: {
        color: 'black',
        fontFamily: 'OpenSans-Regular',
        fontSize: 15,
        marginTop: 20,
    },
    titleStyles: {
        fontFamily: 'OpenSans-Regular',
        left: 4,
        position: 'absolute',
    },
})

function getFontWeight(wei) {
    if (['100', '200', '300'].includes(wei)) return 'OpenSans-Light'
    if (['500', '600'].includes(wei)) return 'OpenSans-SemiBold'
    if (['700', '800', '900'].includes(wei)) return 'OpenSans-ExtraBold'
    return 'OpenSans-Regular'
}
